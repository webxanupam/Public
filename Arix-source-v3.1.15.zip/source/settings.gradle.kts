pluginManagement {
    repositories {
        google()
        // v3.1.14 — plugin resolution also hits Maven Central for AGP's
        // transitive dependencies; keep the Google-hosted mirror ahead of
        // mavenCentral() here as well so 429 rate limits fail over.
        maven { url = uri("https://maven-central.storage-download.googleapis.com/maven2") }
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        // v3.1.13 — Maven Central occasionally rate-limits CI hosts (HTTP 429);
        // the Google-hosted Maven Central mirror is a drop-in fallback kept
        // ahead of mavenCentral() so Gradle fails over instead of erroring out.
        maven { url = uri("https://maven-central.storage-download.googleapis.com/maven2") }
        mavenCentral()
    }
}

rootProject.name = "Arix"
include(":shared")

val sharedOnly = providers.gradleProperty("arix.sharedOnly").orNull.toBoolean()
if (!sharedOnly) {
    include(":app")
    include(":terminal-emulator")
    include(":terminal-view")

    project(":terminal-emulator").projectDir = file("third_party/termux/terminal-emulator")
    project(":terminal-view").projectDir = file("third_party/termux/terminal-view")
}
