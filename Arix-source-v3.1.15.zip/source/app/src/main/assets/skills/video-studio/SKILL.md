---
name: Video Studio
description: Make a finished explainer video from a prompt - YouTube Shorts, reels, explainers, slideshows - with graphics DRAWN LIVE from the script (the agent writes the shapes for every scene), the user's own talking presenter with phoneme lip-sync, voiceover and word-synced captions. Researches the topic first. Use for any request to make, create, generate or edit a video, short, reel, clip or voiceover.
compatibility: Arix 3.x (Termux runtime with ffmpeg, python, Pillow, numpy, onnxruntime)
metadata:
  short-description: Researched explainer video with live-drawn graphics and a talking presenter
  strong-keywords: tiktok reel reels voiceover subtitle subtitles slideshow explainer vlog
  keywords: video movie animation narration captions presenter character lipsync footage clip short youtube
  negative-keywords: play watch listen stream song music trailer download
---

# Video Studio

Prompt -> RESEARCH -> script -> render -> deliver. Drawings, reactions, thumbnail, effects and sound are generated on-device
from the narration; you only spend AI effort where the output needs it.
Output is a dark cinematic reel: glowing HUD, kinetic captions, a perspective floor, live-drawn glass-UI graphics, a talking
presenter that gestures and reacts, camera moves and synthesized sound effects. A fresh colour theme is generated per video.
Free and on-device; no AI-generated live footage - say so if the user expects it.

## Use AI only when needed (default = cheap and fast)
1. Write ONLY the narration per scene (plus `research`). Do NOT hand-write `draw` lines: every scene without `draw` is drawn
   automatically and locally (`popkit/autodraw.py`, switch off with `"autodraw": false`).
2. Skip `plan_video.py`, skip image viewing. Run `make_video.py spec.json --check DIR` once: it is text-only output
   (`ok`, `auto_drawn`, `lint`). Open a preview PNG only for a scene named in `lint`.
3. Write a custom `draw` only for a scene that lint flags or where an exact diagram matters (a specific formula, map, flow). Everything else stays automatic.
4. Render once. The summary line already has `sync.ratio`, `lint`, `voice`; run `verify.py` and look at `sheet.jpg` only if one of them is bad.
5. Faster renders: `--res 720` is about twice as fast as 1080 and is fine for drafts; render 1080 once for the final.

Scripts live in `SK=$HOME/.arix/skills/video-studio` (Termux); otherwise use the folder holding this SKILL.md.

## Pipeline

### 1. Understand
Topic, length (Shorts 30-50 s; explainer 60-120 s), aspect `9:16` (default) / `16:9` / `1:1`, language (English only; the voice is always am_puck). Ask ONE short question only if a wrong guess wastes the render.

### 2. RESEARCH FIRST (mandatory)
`web_search` (2-4 angles) + `fetch_url` on the best 3-5 pages, or `python3 $SK/scripts/research.py "<topic>" --out research.json`.
Keep facts only if two sources agree. The renderer REFUSES specs without `research` (>= 2 sources, >= 3 facts; exit 2).
Personal/creative videos: `"research": {"waived": "<why>"}`.

### 3. Preflight
`sh $SK/scripts/setup.sh doctor` once; install what is missing
(`sh $SK/scripts/setup.sh all`, tell the user the size first).

### 4. Write the spec (compact - this is the only authoring step)
Scene 1 is the hook (<= 8 words). One idea per scene, 8-18 narration words, 6-10 scenes. Minimal scene: `{"narration": "..."}`; add `draw` only when needed (above).
```json
{"style": "cinema", "aspect": "9:16",
 "research": {"sources": [{"title": "..", "url": ".."}, {"title": "..", "url": ".."}], "facts": ["..", "..", ".."]},
 "voice": {"speed": 1.0},
 "scenes": [
  {"narration": "Why does one website load instantly, while another crawls?",
   "tag": "WEB SPEED", "ghost": "SPEED", "mood": "excited", "cam": "punch", "tint": "accent2",
   "acts": [{"on": "crawls", "do": "shrug", "dur": 1.1}],
   "sfx": [{"on": "instantly", "do": "ding"}],
   "draw": ["search 320 62 470 text=mysite.com on=website",
            "ring 175 235 66 0.96 text=0.1s tint=mint on=instantly",
            "ring 465 235 66 0.22 text=6s tint=red on=crawls"]}]}
```
Full example: `$SK/examples/cdn_explainer.json`.

**`draw`** is a list of one-line shapes in a 640x380 space (9:16; the default size is set per aspect) - `kind args key=value`:
- components: `card x y w h title= sub=` `term x y w h title= lines='a|b|c' step=` `check x y w text=` `num x y text size label=`
  `chip x y text hot=1` `search x y w text=` `file x y w name= sub=` `bars x y w h vals=3,5,9 labels='a|b'` `ring x y r pct text=`
  `spark x y w h vals=` `globe x y r` `badge x y text` `beam x y w h` `frame x y w h`. Options: `tint=accent|accent2|mint|red|..`,
  `tilt=ax,ay` (3D tilt), `loop=float|pulse|spin|wobble|blink|orbit|shake|swing|breathe|bob`.
- raw shapes: `r x y w h radius` `c cx cy r` `e cx cy rx ry` `l x1 y1 x2 y2 ..` `p x y x y ..` `d <svg path>` `a cx cy r a0 a1`
  `t x y text size w=maxwidth`, with `f=fill s=stroke w=linewidth o=opacity glow=colour grad=c1,c2 sh=1` and `k Mia x y h pose mood` (stick figure).
- animation on any shape: `on=<spoken word or index>` pins it to the narration; `in=pop|fade|rise|left|right|grow|draw|type|flip|drop|stamp`;
  `dl=` delay; `du=` duration; `mv=dx,dy,at,dur` move; `lp=` loop. Long path arrays and `defs`/`use`/`rep` are also supported.
- Colours: real names for real objects (blue, gold, skin...), theme names (`accent`, `accent2..4`, `tint`, `bg`, `white`, `dim`) for design.
- Texts always get `w=` (max width). No invented facts: numbers and names come from `research.facts`.

**Scene fields** (all optional): `tag` HUD label, `ghost` big background word, `tint`, `layout: "hero"` (big presenter, no graphic).
- `mood`: happy excited surprised sad angry thinking confused laugh confident calm neutral - sets face, eyes, brows and the default body action.
- `act` (whole scene) / `acts: [{"on": word|index, "at": sec, "do": name, "dur": s}]`: wave wave2 present explain cheer think point point2
  shrug surprise laugh sad angry clap nod shake bow lean idea confused success facepalm fail caution hips presenting.
  Unless a scene sets `act` or `acts` (or `"auto_react": false`), the reaction is chosen from the script itself: questions give confused/think, words like fast/better give success, slow/crash give fail, secret/tip give idea, never/warning give caution, hello/welcome give wave, look/click give point, and long stretches without a cue alternate front, hips and presenting (`scripts/popkit/reactions.py`).
  The presenter plays whole reaction poses from the character sheets (no arm bending): front, wave, point, think, open, cross, idea, confused,
  presenting, caution, success, facepalm, fail, hips; each is lip-synced. Hands, arms, head and body move on speech beats automatically; use `acts`
  to land a reaction on the exact word (shrug on "crawls", point on "here", cheer on the result).
- `cam`: push pull drift_r drift_l rise tilt punch shake orbit none (default cycles per scene); `cams: [{"on": word, "do": "punch", "dur": .6}]`.
- `sfx: [{"on": word|"at": sec, "do": name, "gain": 1, "repeat": n}]`: whoosh swipe slide pop tick click clap ding bell notify success impact
  riser sparkle buzz shutter boing type. Scene changes, element entrances, typing, camera punches and the subscribe tap already
  get sounds automatically; add `sfx` only where the script needs a specific sound. `"sfx": false` at top level mutes them.
- Presenter lip-sync is phoneme based (A E I O U F/V L M/B/P S/Z CH/J Rest).

The closing scene is added automatically: the channel `webxanupam` (no space) with avatar, `@webxanupam` handle, a tapped Subscribe
button, bell and Follow pill, narrated "subscribe and follow webxanupam on YouTube". `"outro": false` opts out.

### 5. Render - ONE high-quality render
```
python3 $SK/scripts/make_video.py spec.json video.mp4
```
1080p, x264 CRF 17, frames rendered in parallel (`ARIX_RENDER_WORKERS=N`). Run long renders in the background and poll
(`nohup ... > render.log 2>&1 &`; `[render] frame N/M`; last stdout line is a JSON summary with `sync.ratio`, `lint`).
Exit 2 = refused (missing research or a scene without a drawing). `--res 720` only if the user wants smaller.

### 6. Verify (only when the summary shows a problem)
```
python3 $SK/scripts/verify.py video.mp4 --expect-audio --sheet sheet.jpg
```
Checks caption words land on voice (>= 92 %), A/V length, empty lint, presenter on screen, research recorded. Fix and re-render on
`problems` (max 2 retries), then LOOK at `sheet.jpg`: each drawing must show what its narration says, nothing cut off or overlapping.

### 7. Deliver
Copy to device storage (`mkdir -p /device/Download && cp video.mp4 /device/Download/<slug>.mp4`) or send the file. Report location,
duration, voice engine, sources, anything that fell back. Offer title, description, hashtags. `arix_file_share` uploads PUBLICLY - say so first.

## Presenter
The presenter is the user's own character (`assets/characters/anupam`: flat-vector boy, cream "webXanupam" tee), split into animated
parts (head, body, two arms) with a vector face - never redrawn. To change the artwork replace `source.png` and run
`python3 scripts/build_character_assets.py`.

## Rules
- No copyrighted music/footage/logos; music only if the user supplies a file (`"music": "bed.mp3"`).
- Shorts under 60 s (180 s ceiling). One render per video. Be honest about what could not be verified.
- On errors read the last log lines; fix the cause (missing package -> setup.sh; lint -> simplify or split the scene).


## Thumbnail
Every render writes `<out>_thumbnail.png`. For vertical (9:16) videos the same image is also the first 3 frames. Spec key `thumbnail`: `false` to disable, or an object with `title`, `highlight`, `sub`, `badge`, `pose`, `tint`, `in_video`. Default title is the first narration sentence (max 6 words).


## Drawing every scene live (default) and checking it
Every scene is drawn live from what its own narration says. Scenes without `draw` are filled by `popkit/autodraw.py` (labels use the narration's own words); a hand-written `draw` always wins (labels use the narration's own words, `on=` is a word that is actually spoken).
Before rendering, run `python3 scripts/make_video.py spec.json --check DIR`: it builds the scenes, writes one preview PNG per scene (open them) and fails on
- components or texts that overlap each other, shapes outside the drawing area, text that does not fit;
- a drawing that mentions nothing of what the narration says (draw what the scene is about) or has no labels;
- `on=` words that are never spoken in that scene (they would never trigger).
Fix the spec until it prints `"ok": true`, then render.
Presenter gestures are layout-aware: sideways poses (presenting, point) are replaced by open-hand poses where they would point away from the picture; the pointing pose is kept for "subscribe / follow / click" lines.


## Illustration library
`popkit/library.py` holds ready-made illustrations (blogging, Blogger themes, HTML/CSS, JavaScript, APIs, AI, security, cloud, git, SEO, YouTube, social, email, automation, dashboards and more). They are picked automatically when the narration uses their words, so no `draw` is needed for those scenes; `"library": false` disables them. For a topic they do not cover, write a `draw` yourself.
