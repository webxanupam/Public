"""render.py - the Pop video renderer.

One absolute timeline drives EVERYTHING:
  voice (master wav)  ->  word times  ->  caption bubble, element triggers, lip-sync
Frames are composed in Python (cached sprites) and piped to ffmpeg together with the
master audio, so video and sound are the same length by construction.
"""
import json
import math
import os
import re
import subprocess
import sys
import time
from collections import OrderedDict

from PIL import Image, ImageChops

from . import cards, cine, components, timing
from .lipsync import LipSync, fallback_state
from .character import make_character
from .motion import Motion
from . import camera, sfx
from .gfx import (THEME, COLORS, apply_theme, cine_theme, make_theme, paper_theme, BG, GREY, INK, ORANGE, PURPLE, WHITE, Canvas, SS, background, clamp, color, ease_in_out,
                  ease_out_back, ease_out_cubic, measure, pill, pill_size)

FPS = 30
SAFE = 14

LAYOUTS = {
    "9:16": dict(W=720, H=1280, out=(1080, 1920), content=(30, 96, 660, 790),
                 main=dict(x=40, top=919, scale=0.70, bub_x=262, bub_cy=984, bub_w=420),
                 hero=dict(x=135, top=604, scale=1.50, content=(30, 96, 660, 440), cap_cy=1150, cap_w=620)),
    "1:1": dict(W=720, H=720, out=(1080, 1080), content=(30, 40, 660, 400),
                main=dict(x=26, top=462, scale=0.62, bub_x=232, bub_cy=548, bub_w=450),
                hero=dict(x=225, top=370, scale=0.9, content=(30, 36, 660, 320), cap_cy=662, cap_w=560)),
    "16:9": dict(W=1280, H=720, out=(1920, 1080), content=(330, 34, 900, 520),
                 main=dict(x=34, top=380, scale=0.85, bub_x=330, bub_cy=640, bub_w=760),
                 hero=dict(x=490, top=250, scale=1.0, content=(60, 30, 1160, 220), cap_cy=640, cap_w=900)),
}

BUBBLE_SIZE = 27
GAP = 20

def log(msg):
    sys.stderr.write(msg + "\n")
    sys.stderr.flush()

def norm_word(w):
    return re.sub(r"[^\w]", "", w, flags=re.UNICODE).lower()

def chunk_words(words, max_words=5, max_chars=30):
    """words: [(text, start, end)] -> list of chunks (list of word indices)."""
    chunks, cur, chars = [], [], 0
    for i, (t, s, e) in enumerate(words):
        cur.append(i)
        chars += len(t) + 1
        end_punct = t[-1:] in ".!?"
        soft = t[-1:] in ",;:"
        nxt_len = len(words[i + 1][0]) + 1 if i + 1 < len(words) else 0
        if end_punct or (soft and len(cur) >= 3) or len(cur) >= max_words or (chars + nxt_len > max_chars and len(cur) >= 2):
            chunks.append(cur)
            cur, chars = [], 0
    if cur:
        chunks.append(cur)
    return chunks

class Bubble:
    """Caption sprite factory. Styles: bubble / pill (boxed, active word on a chip) and doodle (plain handwriting, active word highlighted)."""

    def __init__(self, scale, max_w, style="bubble"):
        self.scale = scale
        self.max_w = max_w
        self.style = style
        self.cache = OrderedDict()
        self.kind = "handm" if style == "doodle" else "sans"
        self.fs = 42 if style == "doodle" else BUBBLE_SIZE

    def _layout(self, texts):
        sp = measure(" ", self.kind, self.fs)[0] + 4
        lines, cur, w = [], [], 0.0
        inner = self.max_w - (10 if self.style == "doodle" else 44)
        for i, t in enumerate(texts):
            ww = measure(t, self.kind, self.fs)[0] + 6
            if cur and w + sp + ww > inner:
                lines.append(cur)
                cur, w = [], 0.0
            w += (sp if cur else 0) + ww
            cur.append((i, ww))
        if cur:
            lines.append(cur)
        return lines, sp

    def size(self, texts):
        lines, sp = self._layout(texts)
        lw = [sum(ww for _, ww in ln) + sp * (len(ln) - 1) for ln in lines]
        w = max(lw) + (12 if self.style == "doodle" else 40)
        h = len(lines) * self.fs * (1.2 if self.style == "doodle" else 1.5) + (10 if self.style == "doodle" else 22)
        return w, h

    def sprite(self, ck, texts, active):
        key = (ck, active)
        sp = self.cache.get(key)
        if sp is not None:
            self.cache.move_to_end(key)
            return sp
        lines, space = self._layout(texts)
        w, h = self.size(texts)
        if self.style == "doodle":
            c = Canvas(w + 8, h + 8, self.scale)
            y = 4.0
            for ln in lines:
                lw = sum(ww for _, ww in ln) + space * (len(ln) - 1)
                x = 4 + (w - lw) / 2
                for (i, ww) in ln:
                    t = texts[i]
                    if i == active:
                        c.rrect(x - 2, y + self.fs * 0.5, ww + 4, self.fs * 0.5, 6, fill=(255, 224, 96))
                        col = (17, 17, 17)
                    else:
                        col = (95, 95, 95) if (active is None or i < active) else (150, 150, 150)
                    c.text(x + ww / 2, y + self.fs * 0.62, t, self.fs, fill=col, kind=self.kind, anchor="mm")
                    x += ww + space
                y += self.fs * 1.2
            im = c.finish()
            self.cache[key] = (im, 4)
            if len(self.cache) > 80:
                self.cache.popitem(last=False)
            return self.cache[key]
        tail = 14 if self.style == "bubble" else 0
        c = Canvas(w + tail + 12, h + 12, self.scale)
        ox, oy = 4 + tail, 4
        if tail:
            ty = oy + h / 2
            c.poly([(ox + 2, ty - 12), (ox - tail, ty), (ox + 2, ty + 12)], fill=INK)
            c.poly([(ox + 5, ty - 8), (ox - tail + 5, ty), (ox + 5, ty + 8)], fill=WHITE)
        c.box(ox, oy, w, h, r=16, lw=3, shadow=(4, 4))
        if tail:
            ty = oy + h / 2
            c.poly([(ox + 3.5, ty - 9), (ox - tail + 6.2, ty), (ox + 3.5, ty + 9)], fill=WHITE)
        y = oy + 11
        for ln in lines:
            lw = sum(ww for _, ww in ln) + space * (len(ln) - 1)
            x = ox + (w - lw) / 2
            for (i, ww) in ln:
                t = texts[i]
                if i == active:
                    c.rrect(x - 2, y + 2, ww + 4, BUBBLE_SIZE * 1.32, 9, fill=PURPLE)
                    c.text(x + ww / 2, y + BUBBLE_SIZE * 0.68, t, BUBBLE_SIZE, fill=WHITE, anchor="mm")
                else:
                    col = INK if (active is None or i < active) else GREY
                    c.text(x + ww / 2, y + BUBBLE_SIZE * 0.68, t, BUBBLE_SIZE, fill=col, anchor="mm")
                x += ww + space
            y += BUBBLE_SIZE * 1.5
        im = c.finish()
        self.cache[key] = (im, tail + 4)
        if len(self.cache) > 80:
            self.cache.popitem(last=False)
        return self.cache[key]

_R = None


def _render_chunk(rng):
    r, bg = _R
    out = []
    for fi in range(rng[0], rng[1]):
        out.append(r.compose(fi / float(FPS), bg).tobytes())
    return out

class Placed:
    def __init__(self, el, trig):
        self.el = el
        self.trig = trig
        self.x = self.y = 0.0
        self.f = 1.0
        self.is_label = False

class Scene:
    def __init__(self, idx, spec):
        self.idx = idx
        self.spec = spec
        self.text = str(spec.get("narration", "")).strip()
        self.layout_kind = spec.get("layout", "main")
        self.mood = spec.get("mood", "happy")
        self.audio = None
        self.words = []
        self.t0 = 0.0
        self.dur = 0.0
        self.placed = []
        self.chunks = []
        self.fit = 1.0
        self.tag = ""
        self.tint = (255, 138, 61)

def parse_label(lab):
    if not lab:
        return None
    if isinstance(lab, str):
        lab = {"text": lab}
    d = dict(lab)
    d["type"] = "chip"
    d.setdefault("color", "orange")
    d.setdefault("size", 26)
    return d

def resolve_trigger(el, i, n, words, speech_end):
    """seconds after scene start at which element i of n appears."""
    if el.at is not None:
        return max(0.0, float(el.at))
    if el.on is not None and words:
        if isinstance(el.on, int):
            k = max(0, min(len(words) - 1, el.on))
            return max(0.0, words[k][1] - 0.05)
        want = norm_word(str(el.on))
        for (t, s, e) in words:
            if norm_word(t) == want:
                return max(0.0, s - 0.05)
    if not words:
        return 0.15 + 0.35 * i

    span = max(0.6, speech_end - words[0][1])
    k = int(round(i * (len(words) - 1) / max(1, n))) if n > 1 else 0
    t = words[min(k, len(words) - 1)][1] - 0.08
    return max(0.05 + 0.05 * i, t)

def fit_stack(placed, region, gap):
    """Lay out `placed` elements top-to-bottom in region (x,y,w,h); uniform shrink factor
    f if they do not fit, so nothing can leave the region. Returns f."""
    rx, ry, rw, rh = region
    f = 1.0
    for _ in range(4):
        for p in placed:
            p.el.max_h = max(60.0, (rh - gap * max(0, len(placed) - 1)) / f / max(1, len(placed)) * (1.6 if len(placed) > 1 else 1.0))
            p.el.layout(rw / f)
        total = sum(p.el.h for p in placed) + gap / f * max(0, len(placed) - 1)
        need = total * f
        if need <= rh + 0.5 or f <= 0.55:
            break
        f = max(0.55, f * rh / need * 0.995)
    total = (sum(p.el.h for p in placed) + gap / f * max(0, len(placed) - 1)) * f
    y = ry + (0 if total > 0.62 * rh else (rh - total) * 0.34)
    for p in placed:
        p.f = f
        w = min(p.el.w * f, rw)
        p.x = rx + (rw - p.el.w * f) / 2
        p.y = y
        y += p.el.h * f + gap
    return f, total

class Renderer:
    def __init__(self, spec, base_dir, work, aspect="9:16", out_w=None, voice_mod=None, offline=False):
        self.spec = spec
        self.base = base_dir
        self.work = work
        self.aspect = aspect if aspect in LAYOUTS else "9:16"
        self.L = LAYOUTS[self.aspect]
        ow, oh = self.L["out"]
        if out_w:
            oh = int(round(oh * out_w / ow))
            ow = int(out_w)
        self.OW, self.OH = ow - ow % 2, oh - oh % 2
        self.S = self.OW / float(self.L["W"])
        self.voice = voice_mod
        self.style = str(spec.get("style") or "cinema").lower()
        self.doodle = self.style == "doodle"
        self.cine = self.style == "cinema"
        self.cap_cine = self.cine
        self.theme = self._choose_theme(spec)
        char_cfg = spec.get("character") if isinstance(spec.get("character"), dict) else {}
        self.char_on = char_cfg.get("enabled", True) is not False
        self.char = make_character() if self.char_on else None
        self.plain_caps = self.doodle or self.cine or not self.char_on
        if self.cine:
            self.L = self._cine_layout(self.L)
        elif not self.char_on:
            self.L = self._plain_layout(self.L)
        self.bg_cache = {}
        self.particles = None
        self.charfx = cine.CharFx(self.S) if self.cine else None
        self.hud_cache = {}
        self.ghost_cache = {}
        self.mood_default = char_cfg.get("mood", "happy")
        self.scenes = []
        self.master = None
        self.env = None
        self.total = 0.0
        self.lint = []
        self.sprite_cache = OrderedDict()

    @staticmethod
    def _plain_layout(L):
        L = dict(L)
        W, H = L["W"], L["H"]
        hero = dict(L["hero"])
        if H > W:
            L["content"] = (30, 70, 660, 1000)
            hero["cap_cy"] = 1170
        elif H == W:
            L["content"] = (30, 30, 660, 570)
            hero["cap_cy"] = 665
        else:
            L["content"] = (60, 26, 1160, 560)
            hero["cap_cy"] = 665
        L["hero"] = hero
        return L

    @staticmethod
    def _cine_layout(L):
        L = dict(L)
        W, H = L["W"], L["H"]
        if H > W:
            L["content"] = (36, 150, 648, 380)
            L["main"] = dict(cx=360, feet=1246, k=0.74, bub_x=0, bub_cy=0, bub_w=0)
            L["hero"] = dict(cx=360, feet=1252, k=0.80, content=(36, 176, 648, 340), cap_cy=596, cap_w=640)
            L["hud_y"] = 100
        elif H == W:
            L["content"] = (28, 70, 430, 380)
            L["main"] = dict(cx=560, feet=714, k=0.62, bub_x=0, bub_cy=0, bub_w=0, cap_cx=240)
            L["hero"] = dict(cx=560, feet=714, k=0.64, content=(28, 70, 430, 380), cap_cy=590, cap_w=430, cap_cx=240)
            L["main"].update(cap_cy=590, cap_w=430)
            L["hud_y"] = 24
        else:
            L["content"] = (60, 96, 780, 340)
            L["main"] = dict(cx=1040, feet=716, k=0.84, bub_x=0, bub_cy=0, bub_w=0, cap_cx=450, cap_cy=585, cap_w=800)
            L["hero"] = dict(cx=1040, feet=716, k=0.86, content=(60, 96, 780, 340), cap_cy=585, cap_w=800, cap_cx=450)
            L["hud_y"] = 24
        return L

    @staticmethod
    def _char_geom(cfg):
        if "k" in cfg:
            return cfg["k"], cfg["cx"], cfg["feet"]
        sc = cfg["scale"]
        return sc * 0.5, cfg["x"] + 150 * sc, cfg["top"] + 400 * sc

    def _choose_theme(self, spec):
        """Doodle: the paper look. Otherwise a freshly generated look whose hue differs from the previous video's."""
        if self.doodle:
            return apply_theme(paper_theme())
        path = os.path.join(os.path.expanduser("~"), ".arix", "video-studio-last-hue")
        last = None
        try:
            last = float(open(path).read().strip())
        except Exception:
            pass
        seed = str(spec.get("theme_seed") or "") + " ".join(str(sc.get("narration", ""))[:60] for sc in (spec.get("scenes") or [])[:2]) + str(time.time())
        th = (cine_theme if self.cine else make_theme)(seed, last)
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            open(path, "w").write("%.4f" % th["hue"])
        except Exception:
            pass
        return apply_theme(th)

    def build(self):
        vcfg = dict(self.spec.get("voice") or {})
        t = 0.0
        specs = self.spec.get("scenes") or []
        for i, sp in enumerate(specs):
            sp = dict(sp)
            sc = Scene(i, sp)
            sa = timing.synth_scene(sc.text, self.voice, self.work, i, vcfg) if sc.text else timing.SceneAudio()
            sc.audio = sa
            sc.words = sa.words
            sc.speech_end = sa.speech_dur

            region = self.L["content"] if sc.layout_kind != "hero" else self.L["hero"]["content"]
            label = parse_label(sp.get("label"))
            sc.tag = str(sp.get("tag") or (label or {}).get("text") or "")
            sc.tint = cine.tint_rgb(sp.get("tint"), COLORS)
            if self.cine:
                label = None
            raw = sp.get("visual") or sp.get("elements") or []
            if isinstance(raw, dict):
                raw = [raw]
            els = []
            if label:
                lab_el = cards.build(label, self.base)
                lab_el.layout(region[2])
                lp = Placed(lab_el, 0.05)
                lp.is_label = True
                els.append(lp)
            defs = dict(self.spec.get("defs") or {})
            defs.update(sp.get("defs") or {})
            light = 0.0
            components.DEFAULT_TINT = tuple(sc.tint) if self.cine else None
            vis = [cards.build(dict(r, defs=defs, cast=self.spec.get("cast") or {}, light=light, size=r.get("size")) if isinstance(r, dict) and r.get("type") == "draw" else r, self.base) for r in raw]
            body = []
            for j, el in enumerate(vis):
                pl = Placed(el, resolve_trigger(el, j, len(vis), sc.words, sc.speech_end))
                el.sync = (sc.words, pl.trig)
                body.append(pl)
                for msg in el.lint():
                    self.lint.append({"scene": sc.idx + 1, "problem": msg, "element": el.type})

            ry = region[1]
            if els:
                lp = els[0]
                lp.f = 1.0
                lp.x = region[0] + (region[2] - lp.el.w) / 2
                lp.y = ry + 6
                ry += lp.el.h + 28
            reg = (region[0], ry, region[2], region[1] + region[3] - ry)
            sc.fit, total = fit_stack(body, reg, GAP) if body else (1.0, 0)
            sc.placed = els + body
            sc.t0 = t
            lead = 0.0
            last_trig = max([p.trig + min(1.2, p.el.anim_end) for p in sc.placed] + [0])
            pad = float(sp.get("pad", 0.55))
            sc.dur = max(sc.speech_end + pad, float(sp.get("min_seconds", 0)), last_trig + 0.3, 1.4 if not sc.text else 0.0)
            sc.dur = round(sc.dur * FPS) / float(FPS)
            sc.chunks = chunk_words(sc.words) if sc.words else []
            self.scenes.append(sc)
            t += sc.dur
            self._lint_scene(sc, reg)
        self.total = t
        self._master()

    def _master(self):
        np = timing.np
        n = int(math.ceil(self.total * timing.SR))
        if np is None or not any(sc.audio.samples is not None for sc in self.scenes):
            self.master = None
            self.env = None
            return
        m = np.zeros(n + timing.SR, dtype=np.float32)
        for sc in self.scenes:
            a = sc.audio.samples
            if a is not None:
                s = int(round(sc.t0 * timing.SR))
                m[s:s + len(a)] += a[: max(0, len(m) - s)]
        self.master = m[:n]
        self.env = timing.envelope(self.master)

    def sfx_events(self):
        ev = []
        if self.spec.get("sfx") is False:
            return ev
        for sc in self.scenes:
            sp = sc.spec
            t0 = sc.t0
            if sc.idx == 0:
                ev.append((0.02, "riser" if len(self.scenes) > 1 else "whoosh", 0.5))
            else:
                ev.append((t0 - 0.04, "whoosh" if sc.idx % 2 else "swipe", 1.0))
            for p in sc.placed:
                if p.is_label:
                    continue
                tt = t0 + p.trig
                ev.append((tt, "pop", 0.8))
                if p.el.type in ("draw",):
                    for (ts, nm) in p.el.sfx_times():
                        ev.append((tt + ts, nm, 0.55 if nm == "tick" else 0.6))
            mo = self._motion(sc)
            act = mo.act
            if act == "cheer":
                ev.append((t0 + 0.05, "sparkle", 0.9))
            elif act == "surprise":
                ev.append((t0 + 0.05, "boing", 0.8))
            elif act == "angry":
                ev.append((t0 + 0.05, "impact", 0.5))
            elif act == "clap":
                x = 0.25
                while x < sc.dur - 0.3:
                    ev.append((t0 + x, "clap", 0.9))
                    x += 0.31
            for (g0, dur, name) in mo.timed:
                if name == "clap":
                    x = 0.0
                    while x < dur:
                        ev.append((t0 + g0 + x, "clap", 0.9))
                        x += 0.31
                elif name in ("cheer", "wave2"):
                    ev.append((t0 + g0, "sparkle", 0.7))
                elif name == "surprise":
                    ev.append((t0 + g0, "boing", 0.7))
            plan = self._cam_plan(sc)
            for (c0, d, name) in plan.timed:
                if name in ("punch", "shake"):
                    ev.append((t0 + c0, "impact", 0.55 if name == "punch" else 0.4))
            if plan.base == "punch":
                ev.append((t0 + 0.02, "impact", 0.45))
            for a in (sp.get("sfx") or []):
                if not isinstance(a, dict):
                    continue
                name = str(a.get("do") or a.get("name") or "pop")
                at = mo._when(a) if (a.get("on") is not None or a.get("at") is not None) else 0.0
                rep = int(a.get("repeat", 1))
                gap = float(a.get("gap", 0.18))
                for r in range(max(1, rep)):
                    ev.append((t0 + at + r * gap, name, float(a.get("gain", 1.0))))
            if sp.get("outro"):
                for e in sc.placed:
                    if e.el.type == "subscribe":
                        tg = t0 + e.el.toggle
                        ev += [(t0 + 0.2, "success", 0.7), (tg - 0.04, "click", 1.0), (tg + 0.04, "ding", 1.0), (tg + 0.12, "sparkle", 0.9), (tg + 0.3, "bell", 0.9), (tg + 0.9, "notify", 0.8)]
        return ev

    def _final_audio(self):
        np = timing.np
        n = int(math.ceil(self.total * timing.SR))
        base = self.master if self.master is not None else np.zeros(n, dtype=np.float32)
        out = np.zeros(n, dtype=np.float32)
        out[: len(base)] += base[:n]
        if self.spec.get("sfx") is not False:
            fx = sfx.mix(self.total, self.sfx_events(), float(self.spec.get("sfx_level", 1.0)))
            out[: len(fx)] += fx[:n]
        pk = float(np.abs(out).max()) if len(out) else 0.0
        if pk > 0.98:
            out *= 0.98 / pk
        return out

    def _lint_scene(self, sc, region):
        W, H = self.L["W"], self.L["H"]
        for p in sc.placed:
            w, h = p.el.w * p.f, p.el.h * p.f
            box = (p.x, p.y, p.x + w, p.y + h)
            where = f"scene {sc.idx + 1} {p.el.type}"
            if box[0] < SAFE - 0.5 or box[2] > W - SAFE + 0.5 or box[1] < SAFE - 0.5 or box[3] > H - SAFE + 0.5:
                self.lint.append({"scene": sc.idx + 1, "problem": "outside canvas safe area", "element": where, "box": [round(v, 1) for v in box]})
            rx, ry, rw, rh = region
            if not p.is_label and box[3] > ry + rh + 1.0:
                self.lint.append({"scene": sc.idx + 1, "problem": "overflows its region", "element": where, "box": [round(v, 1) for v in box]})
        self._lint_semantics(sc)
        if sc.fit < 0.7:
            self.lint.append({"scene": sc.idx + 1, "problem": f"too much content: shrunk to {sc.fit:.2f}x - split into two scenes", "element": "scene"})

    def _lint_semantics(self, sc):
        from .autodraw import _key_tokens, _norm
        draws = [p.el for p in sc.placed if p.el.type == "draw" and hasattr(p.el, "items")]
        if not draws or not sc.text:
            return
        texts = []
        for el in draws:
            for it in el.items:
                if it.k == "text":
                    texts.append(str(it.sh.get("text", "")))
        texts += [str(sc.spec.get("tag") or ""), str(sc.spec.get("ghost") or "")]
        blob_words = [w for w in re.split(r"\W+", " ".join(texts).lower()) if len(w) >= 3]
        toks = sc.text.split()
        keys = [_norm(toks[i]) for i in _key_tokens(toks, 8)]
        if keys and texts and not any(k.startswith(w) or w.startswith(k) for k in keys if len(k) >= 3 for w in blob_words):
            self.lint.append({"scene": sc.idx + 1, "problem": "drawing does not mention anything the narration says (key words: %s) - draw what this scene is about" % ", ".join(keys[:5]), "element": "draw"})
        elif keys and not [t for t in texts if t.strip()]:
            self.lint.append({"scene": sc.idx + 1, "problem": "drawing has no labels - add text that names what the narration talks about (%s)" % ", ".join(keys[:4]), "element": "draw"})
        spoken = {norm_word(w[0]) for w in sc.words}
        if spoken:
            bad = set()
            for el in draws:
                for it in el.items:
                    on = it.sh.get("on")
                    if isinstance(on, str) and on.strip() and norm_word(on) not in spoken:
                        bad.add(on)
            if bad:
                self.lint.append({"scene": sc.idx + 1, "problem": "on= word(s) not spoken in this scene, so they never trigger: %s" % ", ".join(sorted(bad)[:4]), "element": "draw"})

    def _sprite(self, p, lt):
        el = p.el
        sc_total = self.S * p.f
        key = (id(el), el.key(lt), round(sc_total, 4))
        hit = self.sprite_cache.get(key)
        if hit is not None:
            self.sprite_cache.move_to_end(key)
            return hit
        M = el.margin
        c = Canvas(el.w + 2 * M, el.h + 2 * M, sc_total)
        el.paint(c, M, M, lt)
        im = c.finish()
        if el.rot:
            im = im.rotate(-el.rot, resample=Image.BICUBIC, expand=True)
        self.sprite_cache[key] = im
        if len(self.sprite_cache) > 48:
            self.sprite_cache.popitem(last=False)
        return im

    def scene_at(self, t):
        lo = 0
        for sc in self.scenes:
            if t < sc.t0 + sc.dur - 1e-9:
                return sc
        return self.scenes[-1]

    def env_at(self, t):
        if self.env is None:
            return None
        i = int(t * 100)
        a = self.env[max(0, i - 2): i + 3]
        return float(a.mean()) if len(a) else 0.0

    def word_at(self, sc, lt):
        for k, (tx, s, e) in enumerate(sc.words):
            if s - 0.02 <= lt < e + 0.06:
                return k
        return None

    def _bg_for(self, tint):
        key = (self.OW, self.OH, tint)
        im = self.bg_cache.get(key)
        if im is None:
            im = cine.make_bg(self.OW, self.OH, self.S, tint)
            self.bg_cache[key] = im
        return im

    def _hud(self, sc):
        im = self.hud_cache.get(sc.idx)
        if im is None:
            c = Canvas(648, 40, self.S)
            c.ellipse(8, 20, 4.2, 4.2, fill=sc.tint)
            num = "%02d / %02d" % (sc.idx + 1, len(self.scenes))
            c.text(22, 20, num, 15, fill=(246, 246, 250), kind="mono", anchor="lm", spacing=1.1)
            tw = measure(num, "mono", 15)[0] + 1.1 * len(num)
            if sc.tag:
                c.text(22 + tw + 8, 20, "-  " + sc.tag.upper(), 15, fill=(140, 144, 158), kind="mono", anchor="lm", spacing=1.1)
            im = c.finish()
            self.hud_cache[sc.idx] = im
        return im

    def _ghost(self, sc):
        if sc.idx not in self.ghost_cache:
            txt = sc.spec.get("ghost") or sc.tag
            self.ghost_cache[sc.idx] = cine.ghost_sprite(txt, self.L["W"], self.L["H"], 0, self.S, sc.tint) if txt else None
        return self.ghost_cache[sc.idx]

    def _cine_frame(self, sc, t, lt_scene):
        S = self.S
        base = self._bg_for(sc.tint)
        if sc.idx > 0 and lt_scene < 0.5:
            prev = self._bg_for(self.scenes[sc.idx - 1].tint)
            frame = Image.blend(prev, base, ease_in_out(lt_scene / 0.5)) if prev is not base else base.copy()
        else:
            frame = base.copy()
        if self.particles is None:
            self.particles = cine.Particles(self.OW, self.OH, S)
        self.particles.draw(frame, t, sc.tint)
        g = self._ghost(sc)
        if g is not None:
            cap_cy = self.L["hero"]["cap_cy"] * S
            gy = int(cap_cy - g.height / 2 + math.sin(t * 0.6) * 4 * S)
            frame.paste(g, (int(self.L["hero"].get("cap_cx", self.L["W"] / 2) * S - g.width / 2), gy), g)
        return frame

    def _cine_hud(self, frame, sc, t):
        S = self.S
        hud = self._hud(sc)
        hy = self.L.get("hud_y", 100) * S
        frame.paste(hud, (int(36 * S), int(hy)), hud)
        from PIL import ImageDraw
        d = ImageDraw.Draw(frame)
        y = int(hy + 40 * S)
        x0, x1 = int(36 * S), int((self.L["W"] - 36) * S)
        th = max(1, int(round(2 * S)))
        d.rectangle([x0, y, x1, y + th - 1], fill=(30, 31, 40))
        p = clamp(t / max(0.1, self.total))
        d.rectangle([x0, y, x0 + int((x1 - x0) * p), y + th - 1], fill=sc.tint)
        return frame

    def compose(self, t, bg):
        th = getattr(self, "_thumb", None)
        if th is not None:
            if t < self._thumb_hold:
                return th.copy()
            x = (t - self._thumb_hold) / 0.22
            if x < 1.0:
                x = x * x * (3 - 2 * x)
                return Image.blend(th, self._compose(t, bg), x)
        return self._compose(t, bg)

    def _compose(self, t, bg):
        sc = self.scene_at(t)
        lt_scene = t - sc.t0
        frame = self._cine_frame(sc, t, lt_scene) if self.cine else bg.copy()
        S = self.S
        out_fade = clamp((lt_scene - (sc.dur - 0.2)) / 0.2)
        for n, p in enumerate(sc.placed):
            lt = lt_scene - p.trig
            if lt < 0:
                continue
            sp = self._sprite(p, lt)
            if self.cine:
                e = ease_out_cubic(lt / 0.5)
                alpha = clamp(lt / 0.2)
                scl = 0.94 + 0.06 * e
                dy = ((1 - e) * 26 + math.sin(t * 0.8 + n * 1.7) * 2.6) * S
            else:
                pop = ease_out_back(lt / 0.34)
                alpha = clamp(lt / 0.16)
                scl = 0.78 + 0.22 * pop
                dy = 0.0
            if out_fade > 0:
                scl *= 1 - 0.1 * out_fade
                alpha *= 1 - out_fade
            w, h = sp.size
            cx = (p.x + p.el.w * p.f / 2) * S
            cy = (p.y + p.el.h * p.f / 2) * S + dy
            if scl < 0.999 or alpha < 0.999:
                nw, nh = max(1, int(w * scl)), max(1, int(h * scl))
                sp2 = sp.resize((nw, nh), Image.BILINEAR) if (nw, nh) != (w, h) else sp
                if alpha < 0.999:
                    a = sp2.getchannel("A").point(lambda v, al=alpha: int(v * al))
                    sp2 = sp2.copy()
                    sp2.putalpha(a)
                frame.paste(sp2, (int(cx - nw / 2), int(cy - nh / 2)), sp2)
            else:
                frame.paste(sp, (int(cx - w / 2), int(cy - h / 2)), sp)
        if self.char_on:
            self._draw_char(frame, sc, t, lt_scene)
        if self.cine:
            frame = camera.apply(frame, self._cam(sc, lt_scene), self.OW, self.OH)
            self._cine_hud(frame, sc, t)
        if sc.words:
            self._draw_caption(frame, sc, lt_scene)
        if self.cine and sc.idx > 0 and lt_scene < 0.18:
            fa = (1 - lt_scene / 0.18) * 0.12
            frame = Image.blend(frame, Image.new("RGB", frame.size, (255, 236, 220)), fa)
        return frame

    def _cam_plan(self, sc):
        cache = self.__dict__.setdefault("_cam_cache", {})
        if sc.idx not in cache:
            cache[sc.idx] = camera.Plan(sc, len(self.scenes))
        return cache[sc.idx]

    def _cam(self, sc, lt):
        return self._cam_plan(sc).state(lt)

    def _lipsync(self, sc):
        cache = self.__dict__.setdefault("_ls_cache", {})
        if sc.idx not in cache:
            cache[sc.idx] = LipSync(sc.words) if sc.words else None
        return cache[sc.idx]

    def _motion(self, sc):
        cache = self.__dict__.setdefault("_mo_cache", {})
        if sc.idx not in cache:
            m = Motion(sc, self.mood_default)
            m.layout = "above" if self.OH > self.OW else "side"
            m.cta = bool(sc.spec.get("outro")) or bool(re.search(r"\b(subscribe|follow|click|tap|link)\b", sc.text or "", re.I))
            cache[sc.idx] = m
        return cache[sc.idx]

    def _draw_char(self, frame, sc, t, lt_scene):
        S = self.S
        hero = sc.layout_kind == "hero"
        cfg = self.L["hero"] if hero else self.L["main"]
        k, cx, feet = self._char_geom(cfg)
        kk = S * k
        ls = self._lipsync(sc)

        def mouth_at(dt):
            kw_ = self.word_at(sc, lt_scene + dt)
            sp_ = kw_ is not None
            env_ = self.env_at(t + dt)
            if env_ is None:
                env_ = (0.5 + 0.5 * math.sin((t + dt) * 14)) * 0.8 if sp_ else 0.0
            if ls is not None:
                return ls.state(lt_scene + dt, env_ if self.env is not None else (0.7 if sp_ else 0.0), sp_)
            return fallback_state(t + dt, env_, sp_)

        kw = self.word_at(sc, lt_scene)
        speaking = kw is not None
        env = self.env_at(t)
        if env is None:
            env = (0.5 + 0.5 * math.sin(t * 14)) * 0.8 if speaking else 0.0
        mouth = mouth_at(0.0)
        pose = self._motion(sc).pose(lt_scene, t, mouth, self.char.blink_state(t), env)
        pose["mouth_s"] = (mouth_at(-0.04), mouth, mouth_at(0.04))
        pop = 1.0
        if lt_scene < 0.5 and (sc.idx == 0 or hero):
            pop = ease_out_back(lt_scene / 0.5)
        sprite = self.char.draw(kk, pose)
        w, h = sprite.size
        fx, fy = self.char.feet
        px = cx * S - fx * kk
        py = feet * S - fy * kk
        if pop < 0.999:
            pop = max(0.02, pop)
            nw, nh = max(1, int(w * pop)), max(1, int(h * pop))
            sprite = sprite.resize((nw, nh), Image.BILINEAR)
            px += fx * kk - fx * kk * pop
            py += fy * kk - fy * kk * pop
            w, h = nw, nh
        foot = (fx * kk * pop, fy * kk * pop, 118 * kk * pop)
        if self.cine:
            self.charfx.paste(frame, sprite, int(px), int(py), sc.tint, foot)
        else:
            frame.paste(sprite, (int(px), int(py)), sprite)

    def _draw_caption(self, frame, sc, lt_scene):
        S = self.S
        hero = sc.layout_kind == "hero" or self.plain_caps
        cfg = self.L["hero"] if hero else self.L["main"]
        if not sc.words:
            return
        ci = None
        for n, ch in enumerate(sc.chunks):
            first = sc.words[ch[0]][1] - 0.06
            nxt = sc.words[sc.chunks[n + 1][0]][1] - 0.06 if n + 1 < len(sc.chunks) else sc.dur
            if first <= lt_scene < nxt:
                ci = n
                break
        if ci is None:
            return
        ch = sc.chunks[ci]
        texts = [sc.words[i][0] for i in ch]
        active = None
        for j, i in enumerate(ch):
            s, e = sc.words[i][1], sc.words[i][2]
            if lt_scene >= s:
                active = j
        last_end = sc.words[ch[-1]][2]
        if active == len(ch) - 1 and lt_scene > last_end + 0.12:
            active = len(ch)
        bub = self._bubble(hero)
        sp_ck = (sc.idx, ci)
        if self.cap_cine:
            im, tail = bub.sprite(sp_ck, texts, active, sc.tint)
            age = lt_scene - (sc.words[ch[0]][1] - 0.06)
            e = ease_out_cubic(age / 0.16)
            if e < 0.999:
                im = im.copy()
                im.putalpha(im.getchannel("A").point(lambda v, al=e: int(v * al)))
            bw, bh = im.size
            frame.paste(im, (int(cfg.get("cap_cx", self.L["W"] / 2) * S - bw / 2), int(cfg["cap_cy"] * S - bh / 2 + (1 - e) * 16 * S)), im)
            return
        im, tail = bub.sprite(sp_ck, texts, active)
        bw, bh = im.size
        if hero:
            bx = (self.L["W"] * S - bw) / 2
            by = cfg["cap_cy"] * S - bh / 2
        else:
            bx = cfg["bub_x"] * S - tail * S
            by = cfg["bub_cy"] * S - bh / 2
        bx = min(max(bx, SAFE * S), self.OW - bw - SAFE * S)
        by = min(max(by, SAFE * S), self.OH - bh - SAFE * S)
        frame.paste(im, (int(bx), int(by)), im)

    def _bubble(self, hero):
        key = "hero" if hero else "main"
        if not hasattr(self, "_bubbles"):
            self._bubbles = {}
        if key not in self._bubbles:
            cfg = self.L["hero"] if hero else self.L["main"]
            if self.cap_cine:
                self._bubbles[key] = cine.Caption(self.S, cfg["cap_w"] - 20)
            else:
                style = "doodle" if self.plain_caps else ("pill" if hero else "bubble")
                self._bubbles[key] = Bubble(self.S, cfg["cap_w"] if hero else cfg["bub_w"], style)
        return self._bubbles[key]

    def lint_captions(self):
        """Every caption chunk must fit its bubble inside the canvas and clear the character."""
        for sc in self.scenes:
            hero = sc.layout_kind == "hero" or self.plain_caps
            cfg = self.L["hero"] if hero else self.L["main"]
            bub = self._bubble(hero)
            for ch in sc.chunks:
                texts = [sc.words[i][0] for i in ch]
                w, h = bub.size(texts)
                if hero:
                    x0, x1 = (self.L["W"] - w) / 2, (self.L["W"] + w) / 2
                else:
                    x0, x1 = cfg["bub_x"] - 14, cfg["bub_x"] + w
                if x0 < SAFE - 0.5 or x1 > self.L["W"] - SAFE + 0.5:
                    self.lint.append({"scene": sc.idx + 1, "problem": "caption bubble leaves the canvas", "element": " ".join(texts)})

    def sync_report(self):
        """Fraction of words whose time span actually carries voice energy."""
        if self.env is None:
            return {"checked": 0, "voiced": 0, "ratio": None}
        n = ok = 0
        worst = []
        for sc in self.scenes:
            for (tx, s, e) in sc.words:
                a, b = int((sc.t0 + s) * 100), max(int((sc.t0 + e) * 100), int((sc.t0 + s) * 100) + 1)
                seg = self.env[a:b]
                n += 1
                m = float(seg.mean()) if len(seg) else 0.0
                if m >= 0.14:
                    ok += 1
                else:
                    worst.append((round(sc.t0 + s, 2), tx))
        return {"checked": n, "voiced": ok, "ratio": round(ok / n, 3) if n else None, "silent_words": worst[:8]}

    def render(self, out_path, music=None, music_volume=0.14, crf=17, preset="veryfast", progress=True):
        self.build()
        self.lint_captions()
        total_frames = int(round(self.total * FPS))
        self._thumb, self.thumbnail_path = None, None
        tcfg = self.spec.get("thumbnail")
        if tcfg is not False and self.scenes:
            try:
                from .thumbnail import make_thumbnail
                img = make_thumbnail(self, self.spec)
                self.thumbnail_path = os.path.splitext(out_path)[0] + "_thumbnail.png"
                img.save(self.thumbnail_path, optimize=True)
                cfg = tcfg if isinstance(tcfg, dict) else {}
                in_video = cfg.get("in_video")
                if in_video is None:
                    in_video = self.OH > self.OW
                if in_video:
                    self._thumb = img
                    self._thumb_hold = 3.0 / FPS
            except Exception as e:
                log("thumbnail skipped: %s" % e)
                self._thumb = None
        wav = os.path.join(self.work, "master.wav")
        if timing.np is not None:
            timing.write_wav(wav, self._final_audio())
        else:
            import wave
            with wave.open(wav, "wb") as w:
                w.setnchannels(1)
                w.setsampwidth(2)
                w.setframerate(timing.SR)
                w.writeframes(b"\x00\x00" * int(timing.SR * self.total))
        cmd = ["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{self.OW}x{self.OH}",
               "-r", str(FPS), "-i", "-", "-i", wav]
        if music and os.path.isfile(music):
            cmd += ["-stream_loop", "-1", "-i", music,
                    "-filter_complex", f"[2:a]volume={music_volume},afade=t=out:st={max(0, self.total - 1.5):.2f}:d=1.5[m];[1:a][m]amix=inputs=2:duration=first:dropout_transition=0[a]",
                    "-map", "0:v", "-map", "[a]"]
        else:
            cmd += ["-map", "0:v", "-map", "1:a"]
        cmd += ["-c:v", "libx264", "-preset", preset, "-crf", str(crf), "-profile:v", "high", "-pix_fmt", "yuv420p",
                "-r", str(FPS), "-c:a", "aac", "-b:a", "160k", "-t", f"{self.total:.3f}", "-movflags", "+faststart", out_path]
        tmp = out_path + ".part"
        cmd[-1] = tmp
        cmd[-1:-1] = ["-f", "mp4"]
        proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stderr=subprocess.PIPE)
        bg = None if self.cine else background(self.OW, self.OH, self.S)
        t_start = time.time()
        workers = self._workers(total_frames)
        ok = False
        try:
            if workers > 1:
                self._render_parallel(proc, total_frames, bg, workers, progress)
            else:
                for fi in range(total_frames):
                    frame = self.compose(fi / float(FPS), bg)
                    proc.stdin.write(frame.tobytes())
                    if progress and fi % 45 == 0:
                        self._progress(fi, total_frames, t_start)
            proc.stdin.close()
            err = proc.stderr.read().decode("utf-8", "replace")
            rc = proc.wait()
            if rc != 0:
                raise RuntimeError("ffmpeg failed: " + err[-600:])
            os.replace(tmp, out_path)
            ok = True
        except BrokenPipeError:
            err = proc.stderr.read().decode("utf-8", "replace")
            proc.wait()
            raise RuntimeError("ffmpeg stopped early: " + err[-600:])
        finally:
            if not ok:
                try:
                    if proc.poll() is None:
                        proc.kill()
                        proc.wait()
                except Exception:
                    pass
                try:
                    os.remove(tmp)
                except OSError:
                    pass
            try:
                self.sprite_cache.clear()
            except Exception:
                pass
        return dict(duration=round(self.total, 3), frames=total_frames, size=[self.OW, self.OH], thumbnail=self.thumbnail_path,
                    render_seconds=round(time.time() - t_start, 1))

    @staticmethod
    def _progress(done, total, t_start):
        el = time.time() - t_start
        eta = el / max(1, done) * (total - done) if done else 0.0
        log("[render] frame %d/%d  %d%%  elapsed %ds  eta %ds" % (done, total, int(100 * done / max(1, total)), el, eta))

    @staticmethod
    def _workers(total_frames):
        try:
            env = int(os.environ.get("ARIX_RENDER_WORKERS", "0"))
        except ValueError:
            env = 0
        if env > 0:
            return env
        n = os.cpu_count() or 1
        if total_frames < 90 or n < 2 or not hasattr(os, "fork"):
            return 1
        return max(1, min(n, 6))

    def _render_parallel(self, proc, total_frames, bg, workers, progress):
        import multiprocessing as mp
        from collections import deque
        for sc in self.scenes:
            self._bg_for(sc.tint) if self.cine else None
        t0p = time.time()
        global _R
        _R = (self, bg)
        chunk = 8
        ranges = [(a, min(total_frames, a + chunk)) for a in range(0, total_frames, chunk)]
        ctx = mp.get_context("fork")
        with ctx.Pool(workers) as pool:
            pending = deque()
            nxt = 0
            done = 0
            while done < len(ranges):
                while nxt < len(ranges) and len(pending) < workers * 2:
                    pending.append(pool.apply_async(_render_chunk, (ranges[nxt],)))
                    nxt += 1
                for blob in pending.popleft().get():
                    proc.stdin.write(blob)
                done += 1
                if progress and done % 6 == 0:
                    self._progress(min(total_frames, done * chunk), total_frames, t0p)

    def preview(self, out_dir):
        from .gfx import background
        os.makedirs(out_dir, exist_ok=True)
        self.build()
        self.lint_captions()
        bg = None if self.cine else background(self.OW, self.OH, self.S)
        paths = []
        for sc in self.scenes:
            last = max([p.trig + min(1.2, p.el.anim_end) for p in sc.placed] + [0.3])
            t = sc.t0 + min(sc.dur - 0.05, last + 0.35)
            fr = self.compose(t, bg)
            p = os.path.join(out_dir, "scene_%02d.png" % (sc.idx + 1))
            fr.save(p)
            paths.append(p)
        return paths

    def report(self):
        return dict(
            scenes=[dict(index=sc.idx + 1, start=round(sc.t0, 3), duration=round(sc.dur, 3), narration=sc.text,
                         layout=sc.layout_kind, fit=round(sc.fit, 3), voice_engine=sc.audio.engine,
                         words=[[w, round(s, 3), round(e, 3)] for (w, s, e) in sc.words],
                         elements=[dict(type=p.el.type, appears=round(p.trig, 2),
                                        box=[round(p.x, 1), round(p.y, 1), round(p.el.w * p.f, 1), round(p.el.h * p.f, 1)])
                                   for p in sc.placed]) for sc in self.scenes],
            theme=self.theme, lint=self.lint, sync=self.sync_report(), logical=[self.L["W"], self.L["H"]])
