#!/usr/bin/env python3
"""make_video.py - Video Studio renderer (live drawn graphics, frame-exact sync).

  python3 make_video.py spec.json out.mp4 [--res 1080] [--workdir DIR]
                         [--music FILE] [--no-research-check] [--allow-undrawn]

Every scene's picture is drawn live from the shapes the agent wrote for it. Captions, drawing
reveals and lip-sync all read the same word timings measured from the voice.
Writes <out>.report.json (layout lint, sync score, word timings) and prints a JSON
summary as the last stdout line. Exit 0 = success, 1 = failed, 2 = refused (see message).
See ../SKILL.md for the spec format.
"""
import argparse, json, os, shutil, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("spec")
    ap.add_argument("out", nargs="?", default="check.mp4")
    ap.add_argument("--res", type=int, default=0, help="output width in px (default 1080)")
    ap.add_argument("--workdir", default=None)
    ap.add_argument("--music", default=None)
    ap.add_argument("--no-research-check", action="store_true")
    ap.add_argument("--allow-undrawn", action="store_true", help="render scenes that have no drawing (captions + presenter only)")
    ap.add_argument("--plan", default=None)
    ap.add_argument("--keep", action="store_true")
    ap.add_argument("--check", default=None, metavar="DIR", help="build + lint only: write one preview PNG per scene into DIR and print the layout/semantic problems (no video)")
    a = ap.parse_args()

    try:
        import PIL
    except ImportError:
        sys.exit("Pillow is missing. Run: sh scripts/setup.sh core")
    if not shutil.which("ffmpeg"):
        sys.exit("ffmpeg is missing. Run: sh scripts/setup.sh core")

    import voice
    from popkit import spec as specmod
    from popkit.render import Renderer

    spec_path = os.path.abspath(a.spec)
    spec = json.load(open(spec_path, encoding="utf-8"))
    if a.plan and os.path.isfile(a.plan):
        spec.setdefault("plan", json.load(open(a.plan, encoding="utf-8")))
    base = os.path.dirname(spec_path)

    problems = specmod.check_research(spec)
    if problems and not a.no_research_check:
        print("REFUSED: " + problems, file=sys.stderr)
        print(json.dumps({"ok": False, "refused": problems}))
        return 2

    from popkit.autodraw import autodraw
    spec = autodraw(spec)
    spec = specmod.expand(spec)
    missing = specmod.validate(spec)
    if missing and not a.allow_undrawn:
        print("REFUSED: " + "; ".join(missing[:6]), file=sys.stderr)
        print(json.dumps({"ok": False, "refused": missing}))
        return 2
    spec = specmod.normalize(spec)
    work = a.workdir or tempfile.mkdtemp(prefix="popvid_")
    os.makedirs(work, exist_ok=True)
    out = os.path.abspath(a.out)
    os.makedirs(os.path.dirname(out) or ".", exist_ok=True)

    r = Renderer(spec, base, work, aspect=spec.get("aspect", "9:16"), out_w=a.res or None, voice_mod=voice)
    if a.check:
        try:
            paths = r.preview(a.check)
        except Exception as e:
            print(json.dumps({"ok": False, "error": str(e)}))
            return 1
        auto = {i: sc.get("auto_kind") for i, sc in enumerate(spec.get("scenes") or []) if sc.get("auto_kind")}
        print(json.dumps({"ok": not r.lint, "auto_drawn": auto, "previews": paths, "lint": r.lint}, ensure_ascii=False))
        if not a.keep and not a.workdir:
            shutil.rmtree(work, ignore_errors=True)
        return 0 if not r.lint else 1
    try:
        info = r.render(out, music=a.music or (os.path.join(base, spec["music"]) if spec.get("music") else None),
                        music_volume=float(spec.get("music_volume", 0.14)))
    except Exception as e:
        import traceback
        traceback.print_exc()
        print(f"ERROR: {e}", file=sys.stderr)
        print(json.dumps({"ok": False, "error": str(e)}))
        return 1
    rep = r.report()
    rep.update(info)
    rep["research"] = bool(problems is None)
    rep["character"] = r.char.name if r.char_on else None
    with open(os.path.splitext(out)[0] + ".report.json", "w", encoding="utf-8") as f:
        json.dump(rep, f, ensure_ascii=False, indent=1)
    engines = sorted({sc.audio.engine for sc in r.scenes if sc.audio and sc.audio.engine})
    summary = dict(ok=True, out=out, duration=info["duration"], size=info["size"], scenes=len(r.scenes),
                   voice_engine=engines[0] if engines else None, voice="am_puck", character=rep["character"],
                   sync=rep["sync"], lint=len(rep["lint"]), render_seconds=info["render_seconds"],
                   report=os.path.splitext(out)[0] + ".report.json", thumbnail=info.get("thumbnail"))
    if rep["lint"]:
        summary["lint_problems"] = rep["lint"][:6]
    print(json.dumps(summary, ensure_ascii=False))
    if not a.keep and not a.workdir:
        shutil.rmtree(work, ignore_errors=True)
    return 0

if __name__ == "__main__":
    sys.exit(main())
