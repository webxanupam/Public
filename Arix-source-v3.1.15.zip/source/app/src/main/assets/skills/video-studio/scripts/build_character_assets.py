#!/usr/bin/env python3
"""build_character_assets.py - splits the presenter artwork (assets/characters/anupam/source.png) into animation parts.

Maintainer tool (needs numpy + scipy + Pillow); the renderer itself only needs Pillow + numpy and the produced PNGs.
  python3 build_character_assets.py [source.png] [out_dir]

Parts (all at half resolution, same coordinate frame 512x768): body (torso+legs, neck stub, no arms), head (face features
erased - the renderer draws eyes/brows/mouth as vectors so they can move), arm_l / arm_r (hem to fingertips, sliced and bent
at render time) and sleeve_l / sleeve_r (cap that hides the arm root). meta.json holds pivots and face geometry.
"""
import json
import os
import sys

import numpy as np
from PIL import Image, ImageDraw
from scipy import ndimage as ndi

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = sys.argv[2] if len(sys.argv) > 2 else os.path.join(HERE, "..", "assets", "characters", "anupam")
SRC = sys.argv[1] if len(sys.argv) > 1 else os.path.join(OUT, "source.png")
SKIN = (254, 199, 165)
HEAD_CUT = 478
HEAD_OVERLAP = 10

src = Image.open(SRC).convert("RGB")
a = np.asarray(src).astype(np.int32)
H, W = a.shape[:2]

def cutout():
    bgc = np.median(np.concatenate([a[:40, :40].reshape(-1, 3), a[:40, -40:].reshape(-1, 3)]), axis=0)
    diff = np.abs(a - bgc).max(axis=2)
    sat = a.max(axis=2) - a.min(axis=2)
    cand = (diff < 46) & (sat < 20)
    lab, n = ndi.label(cand)
    keep = set(np.unique(np.concatenate([lab[0], lab[-1], lab[:, 0], lab[:, -1]]))) - {0}
    for (x, y) in [(372, 850), (368, 900), (362, 960), (652, 850), (656, 900), (662, 960), (329, 962), (695, 962), (330, 958), (694, 958)]:
        if lab[y, x]:
            keep.add(int(lab[y, x]))
    bg = np.isin(lab, list(keep))
    fg = ~bg
    lab2, n2 = ndi.label(fg)
    sizes = ndi.sum(fg, lab2, range(1, n2 + 1))
    fg = lab2 == (1 + int(np.argmax(sizes)))
    fg = ndi.binary_fill_holes(fg)
    fg = ndi.binary_erosion(fg, iterations=1)
    al = ndi.gaussian_filter(fg.astype(np.float32), 0.9)
    al = np.clip((al - 0.25) / 0.6, 0, 1)
    return al

alpha = cutout()
rgb = a.copy()

def erase_face():
    def P(pts):
        return [(330 + x / 3.0, 250 + y / 3.0) for x, y in pts]
    m = Image.new("L", (W, H), 0)
    d = ImageDraw.Draw(m)
    for cx in (447, 585):
        d.ellipse([cx - 55, 340 - 34, cx + 55, 340 + 34], fill=255)
    d.polygon(P([(250, 96), (300, 80), (380, 98), (440, 128), (466, 165), (462, 200), (425, 178), (370, 142), (300, 122), (258, 120)]), fill=255)
    d.polygon(P([(625, 172), (650, 128), (720, 98), (800, 82), (884, 90), (894, 118), (840, 124), (770, 134), (702, 154), (660, 182)]), fill=255)
    d.rectangle([482, 402, 550, 422], fill=255)
    mk = np.asarray(m) > 0
    dark = (a.sum(axis=2) < 3 * 215) | (np.abs(a - np.array(SKIN)).max(axis=2) > 38)
    rgb[mk & dark & (alpha > 0.5)] = SKIN

erase_face()

full = np.dstack([rgb, (alpha * 255).astype(np.uint8)]).astype(np.uint8)
img = Image.fromarray(full, "RGBA")

def half(im):
    return im.resize((im.width // 2, im.height // 2), Image.BOX)


def poly_mask(points, size):
    m = Image.new("L", size, 0)
    ImageDraw.Draw(m).polygon(points, fill=255)
    return m

def arm(side):
    if side == "l":
        top = [(268, 744), (310, 714), (320, 708), (380, 726), (381, 780), (372, 800), (372, 925), (354, 1000), (352, 1014), (268, 1014)]
    else:
        top = [(1024 - x, y) for x, y in [(268, 744), (310, 714), (320, 708), (380, 726), (381, 780), (372, 800), (372, 925), (354, 1000), (352, 1014), (268, 1014)]]
    m = poly_mask(top, img.size)
    inside = (np.asarray(m) > 0) & (alpha > 0.5)
    lab, n = ndi.label(inside)
    sizes = ndi.sum(inside, lab, range(1, n + 1))
    comp = lab == (1 + int(np.argmax(sizes)))
    greyish = ((a.max(axis=2) - a.min(axis=2)) < 26) & (a.sum(axis=2) > 3 * 135)
    comp = comp & ~greyish
    comp = ndi.binary_dilation(comp, iterations=2) & (alpha > 0.02) & (np.asarray(m) > 0) & ~greyish
    lab2, n2 = ndi.label(comp)
    if n2 > 1:
        comp = lab2 == (1 + int(np.argmax(ndi.sum(comp, lab2, range(1, n2 + 1)))))
    m = Image.fromarray((comp * 255).astype(np.uint8))
    layer = img.copy()
    al = np.minimum(np.asarray(layer.getchannel("A")), np.asarray(m))
    layer.putalpha(Image.fromarray(al.astype(np.uint8)))
    return layer, m

arm_l, ml = arm("l")
arm_r, mr = arm("r")

body = img.copy()
ba = np.asarray(body.getchannel("A")).copy()
ba[:HEAD_CUT - HEAD_OVERLAP] = 0
ba[np.asarray(ml) > 0] = 0
ba[np.asarray(mr) > 0] = 0
lab_b, n_b = ndi.label(ba > 8)
if n_b > 1:
    sz = ndi.sum(ba > 8, lab_b, range(1, n_b + 1))
    ba = np.where(lab_b == (1 + int(np.argmax(sz))), ba, 0)
body.putalpha(Image.fromarray(ba.astype(np.uint8)))

head = img.copy()
ha = np.asarray(head.getchannel("A")).copy()
ha[HEAD_CUT:] = 0
head.putalpha(Image.fromarray(ha))

def sleeve(side):
    if side == "l":
        pts = [(262, 560), (396, 560), (396, 727), (380, 727), (322, 704), (283, 693), (262, 690)]
    else:
        pts = [(1024 - x, y) for x, y in [(262, 560), (396, 560), (396, 727), (380, 727), (322, 704), (283, 693), (262, 690)]]
    m = poly_mask(pts, img.size)
    layer = img.copy()
    al = np.minimum(np.asarray(img.getchannel("A")), np.asarray(m))
    al = np.where(np.asarray(ml) > 0, 0, al)
    al = np.where(np.asarray(mr) > 0, 0, al)
    al[:HEAD_CUT] = 0
    layer.putalpha(Image.fromarray(al.astype(np.uint8)))
    return layer

sl = sleeve("l")
sr = sleeve("r")

SLEEVE_IN_L, SLEEVE_IN_R = 190, 322


def torso_without_sleeves(part):
    arr = np.asarray(part).copy()
    rows = np.arange(298, 377)
    t = (rows - 298) / 78.0
    edge_l = 176 + (SLEEVE_IN_L + 2 - 176) * (t ** 0.6)
    cx = 257.0
    shirt = arr[330, 240, :3].astype(np.float32)
    S = 4
    h = 80
    w = arr.shape[1]
    keep = Image.new("L", (w * S, h * S), 0)
    kd = ImageDraw.Draw(keep)
    ptsl = [(edge_l[k] * S, k * S) for k in range(len(rows))]
    ptsr = [((2 * cx - edge_l[k]) * S, k * S) for k in range(len(rows))]
    kd.polygon(ptsl + [(cx * S, 77 * S), (cx * S, 0)], fill=255)
    kd.polygon(ptsr + [(cx * S, 77 * S), (cx * S, 0)], fill=255)
    keep = np.asarray(keep.resize((w, h), Image.LANCZOS)).astype(np.float32) / 255.0
    band = arr[298:378].astype(np.float32)
    out_side = np.zeros((h, w), np.float32)
    out_side[:, :SLEEVE_IN_L + 1] = 1
    out_side[:, SLEEVE_IN_R - 1:] = 1
    a_old = band[:, :, 3] / 255.0
    new_a = np.where(out_side > 0, keep, a_old)
    for c in range(3):
        band[:, :, c] = np.where(out_side > 0, shirt[c], band[:, :, c])
    band[:, :, 3] = new_a * 255.0
    arr[298:378] = band.astype(np.uint8)
    out = Image.fromarray(arr, "RGBA")
    ink4 = Image.new("RGBA", (w * S, 80 * S), (0, 0, 0, 0))
    d4 = ImageDraw.Draw(ink4)
    d4.line([(edge_l[k] * S, k * S) for k in range(len(rows))], fill=(34, 26, 28, 255), width=int(1.8 * S))
    d4.line([((2 * cx - edge_l[k]) * S, k * S) for k in range(len(rows))], fill=(34, 26, 28, 255), width=int(1.8 * S))
    ink4 = ink4.resize((w, 80), Image.LANCZOS)
    layer = Image.new("RGBA", out.size, (0, 0, 0, 0))
    layer.paste(ink4, (0, 298))
    out.alpha_composite(layer)
    return out


def feather(part, side):
    arr = np.asarray(part).astype(np.float32)
    w = arr.shape[1]
    xs = np.arange(w, dtype=np.float32)
    if side == "l":
        ramp = np.clip((SLEEVE_IN_L + 12 - xs) / 12.0, 0, 1)
        ramp = np.where(xs >= SLEEVE_IN_L + 12, 0.0, 1.0) * 0 + np.clip((SLEEVE_IN_L + 12 - xs) / 12.0, 0, 1)
    else:
        ramp = np.clip((xs - (SLEEVE_IN_R - 12)) / 12.0, 0, 1)
    arr[..., 3] *= ramp[None, :]
    return Image.fromarray(arr.astype(np.uint8), "RGBA")


SHOULDER_Y = 305


def extend_arm(part, allow):
    arr = np.asarray(part).copy()
    a = arr[..., 3]
    for x in range(arr.shape[1]):
        col = np.where(a[SHOULDER_Y:420, x] > 200)[0]
        if len(col) == 0:
            continue
        y0 = SHOULDER_Y + int(col[0])
        if y0 > SHOULDER_Y:
            for y in range(SHOULDER_Y, y0):
                if allow[y, x]:
                    arr[y, x] = arr[y0 + 1, x]
    return Image.fromarray(arr, "RGBA")


os.makedirs(OUT, exist_ok=True)
for name, im in [("body", body), ("head", head), ("arm_l", arm_l), ("arm_r", arm_r), ("sleeve_l", sl), ("sleeve_r", sr)]:
    hp = half(im)
    if name == "body":
        torso_without_sleeves(hp).save(os.path.join(OUT, "body_ns.png"), optimize=True)
    if name.startswith("sleeve_"):
        hp = feather(hp, name[-1])
    if name in ("arm_l", "arm_r"):
        hp = extend_arm(hp, np.asarray(half(sl if name[-1] == "l" else sr).getchannel("A")) > 8)
    hp.save(os.path.join(OUT, name + ".png"), optimize=True)

FEET_Y = int(np.where(alpha > 0.5)[0].max() // 2) - 2
meta = {
    "w": W // 2, "h": H // 2,
    "head_pivot": [257, HEAD_CUT // 2 - 2],
    "feet_y": FEET_Y,
    "feet_x": 257,
    "arm_l": {"sleeve_pivot": [175, 305], "pivot": [175, SHOULDER_Y], "top": SHOULDER_Y, "bottom": 504, "win": [136, 196], "hem": 0},
    "arm_r": {"sleeve_pivot": [330, 305], "pivot": [330, SHOULDER_Y], "top": SHOULDER_Y, "bottom": 504, "win": [310, 370], "hem": 0},
    "face": {
        "eye_l": [229.0, 169.0], "eye_r": [286.0, 169.0], "eye_rx": 17.5, "eye_ry": 12.4, "iris": 10.0,
        "brow_l": [[208.5, 141.5], [223.5, 139.5], [243.5, 151.5]], "brow_r": [[270.0, 152.5], [295.0, 141.5], [313.5, 141.0]],
        "mouth": [257.0, 205.5], "mouth_w": 27.0,
        "ink": [24, 17, 18], "mink": [140, 84, 72], "lip": [150, 62, 58], "iris_col": [74, 52, 46], "skin": list(SKIN)
    }
}
json.dump(meta, open(os.path.join(OUT, "meta.json"), "w"), indent=1)
print("ok", OUT)
