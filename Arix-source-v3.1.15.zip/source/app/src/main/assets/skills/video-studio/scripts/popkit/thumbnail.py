import colorsys
import math
import random
import re
import unicodedata

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

from .gfx import clean, get_font, measure, mix

STOP = set("a an the and or but of to in on at for with from by is are was were be been it its this that these those you your we our they their i me my as if so do does did how what why when who which can will just not no yes than then into about over more most very".split())

POSE_RULES = [
    ("fail", r"\b(fail|failed|mistake|mistakes|wrong|worst|never|stop|dead|broke|broken)\b|गलती|नाकाम"),
    ("caution", r"\b(warning|danger|careful|avoid|risk|scam|trap|beware)\b|खतरा|सावधान"),
    ("idea", r"\b(secret|secrets|hidden|trick|tricks|hack|hacks|idea|ideas|truth|genius|tip|tips)\b|राज़|राज|ट्रिक|आइडिया"),
    ("success", r"\b(win|wins|best|top|free|easy|fast|faster|boost|grow|growth|profit|rich|success|master|ultimate)\b|\d|फ्री|आसान|सफल"),
    ("confused", r"\?|\b(why|how|what|really|myth|myths)\b|क्यों|कैसे|क्या"),
    ("think", r"\b(vs|versus|compare|explained|guide|works|work)\b"),
]



def _first_sentence(text):
    text = re.sub(r"\s+", " ", text or "").strip()
    m = re.match(r"(.+?[.!?])(\s|$)", text)
    return (m.group(1) if m else text).strip(" .!")


def _auto_title(spec, scenes):
    t = spec.get("title")
    if isinstance(t, str) and t.strip():
        return t.strip()
    for sc in scenes:
        s = _first_sentence(sc.text)
        if s:
            return s
    return "WATCH THIS"


def _isw(ch):
    return ch.isalnum() or unicodedata.category(ch).startswith("M") or ch in "_"


def _strip_edges(w):
    i, j = 0, len(w)
    while i < j and not _isw(w[i]):
        i += 1
    while j > i and not (_isw(w[j - 1]) or w[j - 1] in "?!%$"):
        j -= 1
    return w[i:j]


def _core(w):
    return "".join(ch for ch in w if _isw(ch))


def _shorten(text, limit=6):
    text = clean(text or "").strip()
    q = text.endswith("?")
    parts = [x for x in re.split(r"[,;:\u2013-]\s+", text) if x.strip()]
    if len(text.split()) > limit and parts and len(parts[0].split()) >= 3:
        text = parts[0]
    ws = [_strip_edges(w) for w in text.split()]
    ws = [w for w in ws if w]
    cut = len(ws) > limit
    ws = ws[:limit]
    while cut and len(ws) > 2 and (ws[-1].lower() in STOP):
        ws.pop()
    if q and not cut and ws and not ws[-1].endswith("?"):
        ws[-1] += "?"
    return ws


def _pick_highlight(words):
    best, bi = None, -1
    for i, w in enumerate(words):
        core = _core(w)
        if not core:
            continue
        if re.search(r"\d", core):
            return i
        if core.lower() in STOP:
            continue
        sc = len(core) + (2 if i > 0 else 0)
        if best is None or sc > best:
            best, bi = sc, i
    return bi if bi >= 0 else len(words) - 1


def _pick_pose(text, avail):
    low = text.lower()
    for name, pat in POSE_RULES:
        if name in avail and re.search(pat, low):
            return name
    return "presenting" if "presenting" in avail else "front"


def _hsv(rgb):
    r, g, b = [c / 255.0 for c in rgb]
    return colorsys.rgb_to_hsv(r, g, b)


def _rgb(h, s, v):
    r, g, b = colorsys.hsv_to_rgb(h % 1.0, max(0, min(1, s)), max(0, min(1, v)))
    return (int(r * 255), int(g * 255), int(b * 255))


def _palette(tint):
    h, s, v = _hsv(tint)
    s = max(0.55, min(0.95, s))
    main = _rgb(h, s, 1.0)
    alt = _rgb(h + 0.5, 0.65, 1.0)
    warm = _rgb(h + 0.12, 0.85, 1.0)
    deep = _rgb(h, 0.8, 0.22)
    return main, alt, warm, deep


def _radial(w, h, cx, cy, rx, ry, power=1.6):
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    d = np.sqrt(((xx - cx) / rx) ** 2 + ((yy - cy) / ry) ** 2)
    return np.clip(1.0 - d, 0, 1) ** power


def _background(W, H, main, alt, deep, portrait, cx, cy):
    yy = np.linspace(0, 1, H, dtype=np.float32)[:, None, None]
    top = np.array(mix((4, 4, 9), deep, 0.55), np.float32)[None, None, :]
    bot = np.array(mix((10, 8, 16), deep, 1.0), np.float32)[None, None, :]
    img = top * (1 - yy) + bot * yy
    img = np.broadcast_to(img, (H, W, 3)).copy()
    g1 = _radial(W, H, cx, cy, W * (0.85 if portrait else 0.55), H * (0.5 if portrait else 0.95), 1.5)[:, :, None]
    img = img + g1 * (np.array(main, np.float32)[None, None, :] * 0.62)
    g2 = _radial(W, H, W * (0.05 if portrait else 0.02), H * 0.08, W * 0.7, H * 0.5, 2.0)[:, :, None]
    img = img + g2 * (np.array(alt, np.float32)[None, None, :] * 0.28)
    xx = np.arange(W, dtype=np.float32)[None, :]
    yy2 = np.arange(H, dtype=np.float32)[:, None]
    ang = -0.52
    proj = xx * math.cos(ang) + yy2 * math.sin(ang)
    period = max(W, H) * 0.19
    band = np.clip(np.abs(((proj / period) % 1.0) - 0.5) * 2.0, 0, 1)
    streak = (np.clip((0.12 - band) / 0.12, 0, 1) ** 2)[:, :, None]
    img = img + streak * 16.0
    step = max(18, int(min(W, H) * 0.026))
    dots = np.zeros((H, W), np.float32)
    r = max(1, step // 12)
    for oy in range(-r, r + 1):
        for ox in range(-r, r + 1):
            if ox * ox + oy * oy <= r * r:
                ys = np.arange(step // 2 + oy, H, step)
                xs = np.arange(step // 2 + ox, W, step)
                ys = ys[(ys >= 0) & (ys < H)]
                xs = xs[(xs >= 0) & (xs < W)]
                dots[np.ix_(ys, xs)] = 1.0
    img = img + dots[:, :, None] * 9.0
    vy, vx = np.mgrid[0:H, 0:W].astype(np.float32)
    vd = np.sqrt(((vx - W / 2) / (W * 0.72)) ** 2 + ((vy - H / 2) / (H * 0.72)) ** 2)
    img = img * (1.0 - np.clip(vd - 0.45, 0, 1)[:, :, None] * 0.75)
    rs = np.random.RandomState(7)
    img = img + rs.normal(0, 2.2, (H, W, 1)).astype(np.float32)
    return Image.fromarray(np.clip(img, 0, 255).astype(np.uint8), "RGB").convert("RGBA")


def _layout_title(words, hi, kind, maxw, maxh, maxlines, start):
    size = start
    while size >= 28:
        pad = size * 0.16
        lines, cur, curw = [], [], 0.0
        sp = measure(" ", kind, size)[0]
        for i, w in enumerate(words):
            ww = measure(w, kind, size)[0] + (2 * pad if i == hi else 0)
            add = ww if not cur else sp + ww
            if cur and curw + add > maxw:
                lines.append(cur)
                cur, curw = [i], ww
            else:
                cur.append(i)
                curw += add
        if cur:
            lines.append(cur)
        widest = max(sum(measure(words[i], kind, size)[0] + (2 * pad if i == hi else 0) for i in ln) + sp * (len(ln) - 1) for ln in lines)
        if len(lines) <= maxlines and len(lines) * size * 1.2 <= maxh and widest <= maxw and all(measure(words[i], kind, size)[0] <= maxw - 2 * pad for ln in lines for i in ln):
            return size, lines, pad
        size -= 3
    return 28, [[i] for i in range(len(words))], 28 * 0.16


def _draw_title(W, H, words, hi, box, main, alt, warm, kind="sans", maxlines=4, align="left"):
    x0, y0, x1, y1 = box
    maxw, maxh = x1 - x0, y1 - y0
    size, lines, pad = _layout_title(words, hi, kind, maxw, maxh, maxlines, int(maxh / 1.1))
    lh = size * 1.2
    total = lh * len(lines)
    y = y0 + (maxh - total) / 2.0
    font = get_font(kind, size)
    sp = measure(" ", kind, size)[0]
    stroke = max(3, int(size * 0.085))
    glow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    shadow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    face = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    pill = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    gd, sd, fd = ImageDraw.Draw(glow), ImageDraw.Draw(shadow), ImageDraw.Draw(face)
    hi_box = None
    for ln in lines:
        widths = [measure(words[i], kind, size)[0] + (2 * pad if i == hi else 0) for i in ln]
        lw = sum(widths) + sp * (len(ln) - 1)
        x = x0 if align == "left" else x0 + (maxw - lw) / 2.0
        for i, wd in zip(ln, widths):
            tx = x + (pad if i == hi else 0)
            ty = y + size * 0.02
            if i == hi:
                hi_box = (x, y + size * 0.06, x + wd, y + lh - size * 0.02)
                fd.text((tx, ty), words[i], font=font, fill=(14, 12, 22, 255))
            else:
                sd.text((tx + size * 0.045, ty + size * 0.07), words[i], font=font, fill=(0, 0, 0, 210), stroke_width=stroke, stroke_fill=(0, 0, 0, 210))
                gd.text((tx, ty), words[i], font=font, fill=main + (255,), stroke_width=stroke + int(size * 0.05), stroke_fill=main + (255,))
                fd.text((tx, ty), words[i], font=font, fill=(255, 255, 255, 255), stroke_width=stroke, stroke_fill=(8, 6, 14, 255))
            x += wd + sp
        y += lh
    out = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    out.alpha_composite(glow.filter(ImageFilter.GaussianBlur(size * 0.16)))
    if hi_box is not None:
        bx0, by0, bx1, by1 = hi_box
        r = (by1 - by0) * 0.26
        pd = ImageDraw.Draw(pill)
        pd.rounded_rectangle((bx0 + size * 0.05, by0 + size * 0.07, bx1 + size * 0.05, by1 + size * 0.07), radius=r, fill=(0, 0, 0, 200))
        grad = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        gdr = ImageDraw.Draw(grad)
        steps = int(by1 - by0)
        for j in range(steps):
            f = j / max(1, steps - 1)
            gdr.rectangle((bx0, by0 + j, bx1, by0 + j + 1), fill=mix(warm, main, f) + (255,))
        m = Image.new("L", (W, H), 0)
        ImageDraw.Draw(m).rounded_rectangle((bx0, by0, bx1, by1), radius=r, fill=255)
        pill.paste(grad, (0, 0), m)
        ring = Image.new("L", (W, H), 0)
        ImageDraw.Draw(ring).rounded_rectangle((bx0, by0, bx1, by1), radius=r, outline=255, width=max(2, int(size * 0.035)))
        pill.paste(Image.new("RGBA", (W, H), (255, 255, 255, 255)), (0, 0), ring)
        cx, cy = (bx0 + bx1) / 2, (by0 + by1) / 2
        comb = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        comb.alpha_composite(pill)
        hf = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        hd = ImageDraw.Draw(hf)
        hd.text((bx0 + pad, by0 - size * 0.04), words[hi], font=font, fill=(14, 12, 22, 255))
        comb.alpha_composite(hf)
        rot = comb.rotate(3.0, resample=Image.BICUBIC, center=(cx, cy))
        out.alpha_composite(shadow)
        out.alpha_composite(face)
        out.alpha_composite(rot)
        return out, (size, lines)
    out.alpha_composite(shadow)
    out.alpha_composite(face)
    return out, (size, lines)


def _pill_badge(W, H, text, x, y, main, size, align="left"):
    font = get_font("sans", size)
    tw = measure(text, "sans", size)[0]
    dot = size * 0.62
    padx = size * 0.7
    w = tw + dot + padx * 2 + size * 0.35
    h = size * 1.75
    if align == "center":
        x = x - w / 2
    layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    d.rounded_rectangle((x, y, x + w, y + h), radius=h / 2, fill=(10, 9, 16, 235), outline=main + (255,), width=max(2, int(size * 0.1)))
    cy = y + h / 2
    d.ellipse((x + padx * 0.8, cy - dot / 2, x + padx * 0.8 + dot, cy + dot / 2), fill=(255, 40, 60, 255))
    tri = [(x + padx * 0.8 + dot * 0.34, cy - dot * 0.2), (x + padx * 0.8 + dot * 0.34, cy + dot * 0.2), (x + padx * 0.8 + dot * 0.72, cy)]
    d.polygon(tri, fill=(255, 255, 255, 255))
    d.text((x + padx * 0.8 + dot + size * 0.4, y + (h - size * 1.25) / 2 - size * 0.02), text, font=font, fill=(255, 255, 255, 255))
    return layer, (x, y, x + w, y + h)


def _kicker(W, H, text, x, y, main, warm, size):
    font = get_font("sans", size)
    tw = measure(text, "sans", size)[0]
    padx = size * 0.8
    w, h = tw + padx * 2, size * 1.7
    layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    d.rounded_rectangle((x, y, x + w, y + h), radius=h * 0.22, fill=mix(warm, main, 0.4) + (255,))
    d.text((x + padx, y + (h - size * 1.25) / 2 - size * 0.02), text, font=font, fill=(14, 12, 22, 255))
    return layer, w, h


def _character(renderer, pose_name, target_h, max_w):
    ch = renderer.char
    from .motion import Motion
    sc = renderer.scenes[0]
    try:
        p = Motion(sc, renderer.mood_default).pose(0.6, 0.6, ("A", "O", 0.5, 0.66), ch.blink_state(0.6), 0.6)
    except Exception:
        p = {}
    p = dict(p)
    p.update(pa=pose_name, pb=None, pw=0.0)
    p["mouth_s"] = (("A", "O", 0.35, 0.62),) * 3
    p["mouth"] = ("A", "O", 0.35, 0.62)
    p["rot"] = 0.0
    for key in ("bob", "dy", "head_dy", "sy"):
        if key in p and key != "sy":
            p[key] = 0.0
    sprite = ch.draw(1.0, p)
    bb = sprite.getchannel("A").point(lambda v: 255 if v > 24 else 0).getbbox()
    if not bb:
        return None
    k = min(target_h / float(bb[3] - bb[1]), max_w / float(bb[2] - bb[0]))
    sprite = ch.draw(k, p)
    bb = sprite.getchannel("A").point(lambda v: 255 if v > 24 else 0).getbbox()
    return sprite.crop(bb)


def _sticker(sprite, main, edge):
    w, h = sprite.size
    pad = int(edge * 12)
    big = Image.new("RGBA", (w + pad * 2, h + pad * 2), (0, 0, 0, 0))
    big.paste(sprite, (pad, pad))
    a = big.getchannel("A")
    grow = a.filter(ImageFilter.GaussianBlur(edge * 0.55)).point(lambda v: 255 if v > 18 else 0)
    grow = grow.filter(ImageFilter.GaussianBlur(edge * 0.28)).point(lambda v: 255 if v > 128 else 0)
    white = Image.new("RGBA", big.size, (255, 255, 255, 255))
    white.putalpha(grow)
    halo = Image.new("RGBA", big.size, main + (255,))
    halo.putalpha(grow.filter(ImageFilter.GaussianBlur(edge * 3.2)).point(lambda v: int(min(255, v * 1.4))))
    shadow = Image.new("RGBA", big.size, (0, 0, 0, 255))
    shadow.putalpha(grow.filter(ImageFilter.GaussianBlur(edge * 1.4)).point(lambda v: int(v * 0.6)))
    out = Image.new("RGBA", big.size, (0, 0, 0, 0))
    out.alpha_composite(halo)
    sh = Image.new("RGBA", big.size, (0, 0, 0, 0))
    sh.alpha_composite(shadow, (int(edge * 0.4), int(edge * 0.9)))
    out.alpha_composite(sh)
    out.alpha_composite(white)
    out.alpha_composite(big)
    return out


def _sparkle(d, x, y, r, col):
    d.polygon([(x, y - r), (x + r * 0.22, y - r * 0.22), (x + r, y), (x + r * 0.22, y + r * 0.22), (x, y + r), (x - r * 0.22, y + r * 0.22), (x - r, y), (x - r * 0.22, y - r * 0.22)], fill=col)


def make_thumbnail(r, spec):
    cfg = spec.get("thumbnail")
    cfg = cfg if isinstance(cfg, dict) else {}
    W, H = r.OW, r.OH
    portrait = H >= W
    sc0 = r.scenes[0]
    tint = tuple(cfg["tint"]) if isinstance(cfg.get("tint"), (list, tuple)) and len(cfg["tint"]) == 3 else tuple(sc0.tint)
    main, alt, warm, deep = _palette(tint)
    title = str(cfg.get("title") or _auto_title(spec, r.scenes))
    words = _shorten(title.upper(), 6)
    hl = cfg.get("highlight")
    hi = None
    if isinstance(hl, str) and hl.strip():
        key = _core(hl.upper())
        for i, w in enumerate(words):
            if _core(w) == key:
                hi = i
                break
    if hi is None:
        hi = _pick_highlight(words)
    badge = str(cfg.get("badge") or spec.get("channel") or "webxanupam")
    kick = cfg.get("sub") or cfg.get("kicker")
    use_char = bool(r.char_on and r.char is not None)
    cx_char = W * (0.5 if portrait else 0.77)
    cy_glow = H * (0.72 if portrait else 0.55)
    if not use_char:
        base = r.compose(min(1.0, sc0.dur * 0.5), None).convert("RGBA")
        dark = Image.new("RGBA", base.size, (4, 4, 10, 255))
        img = Image.blend(base, dark, 0.52)
        g = _radial(W, H, W / 2, H * 0.55, W * 0.9, H * 0.7, 1.4)[:, :, None]
        glow = np.array(img, np.float32)
        glow[:, :, :3] += g * np.array(main, np.float32)[None, None, :] * 0.25
        img = Image.fromarray(np.clip(glow, 0, 255).astype(np.uint8), "RGBA")
    else:
        img = _background(W, H, main, alt, deep, portrait, cx_char, cy_glow)
    d = ImageDraw.Draw(img)
    if use_char:
        rng = random.Random(11)
        rad = min(W, H) * (0.43 if portrait else 0.46)
        ring = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        rd = ImageDraw.Draw(ring)
        for j, (rr, al) in enumerate(((rad, 150), (rad * 1.18, 70), (rad * 1.38, 30))):
            rd.ellipse((cx_char - rr, cy_glow - rr, cx_char + rr, cy_glow + rr), outline=main + (al,), width=max(2, int(W * 0.004)))
        img.alpha_composite(ring)
        d = ImageDraw.Draw(img)
        for _ in range(16):
            ang = rng.random() * math.tau
            dist = rad * (0.9 + rng.random() * 0.7)
            sx, sy = cx_char + math.cos(ang) * dist, cy_glow + math.sin(ang) * dist * 0.9
            if 0.03 * W < sx < 0.97 * W and 0.04 * H < sy < 0.97 * H:
                _sparkle(d, sx, sy, min(W, H) * (0.008 + rng.random() * 0.016), (255, 255, 255, int(120 + rng.random() * 120)))
    if portrait:
        title_box = (W * 0.07, H * (0.145 if kick else 0.125), W * 0.93, H * 0.415)
        badge_xy = (W * 0.5, H * 0.04)
        bsize = W * 0.038
        align = "center"
        maxlines = 4
    else:
        title_box = (W * 0.05, H * (0.28 if kick else 0.16), W * 0.56, H * 0.9)
        badge_xy = (W * 0.05, H * 0.06)
        bsize = H * 0.04
        align = "left"
        maxlines = 4
    pose_name = None
    if use_char:
        avail = set(getattr(r.char, "rx_meta", {}) or {})
        pose_name = cfg.get("pose") if cfg.get("pose") in avail else _pick_pose(title + " " + " ".join(sc0.text.split()[:14]), avail)
        if portrait:
            th, mw = H * 0.56, W * 0.92
        else:
            th, mw = H * 0.97, W * 0.42
        sprite = _character(r, pose_name, th, mw)
        if sprite is not None:
            sticker = _sticker(sprite, main, max(4, min(W, H) * 0.008))
            sx = int(cx_char - sticker.width / 2)
            sy = int(H * (1.02 if portrait else 1.03) - sticker.height + (sticker.height - sprite.height) // 2)
            img.paste(sticker, (sx, sy), sticker)
    layer, (size, lines) = _draw_title(W, H, words, hi, title_box, main, alt, warm, align=align, maxlines=maxlines)
    img.alpha_composite(layer)
    if kick:
        ksz = (W if portrait else H) * (0.032 if portrait else 0.042)
        _, kw, kh = _kicker(W, H, clean(str(kick)).upper(), 0, 0, main, warm, ksz)
        kx = (W - kw) / 2 if portrait else title_box[0]
        ky = H * 0.075 + bsize * 2.2 if portrait else H * 0.155
        kl, _, _ = _kicker(W, H, clean(str(kick)).upper(), kx, ky, main, warm, ksz)
        img.alpha_composite(kl)
    bl, _ = _pill_badge(W, H, badge, badge_xy[0], badge_xy[1], main, bsize, align=("center" if portrait else "left"))
    img.alpha_composite(bl)
    bar = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    bd = ImageDraw.Draw(bar)
    th_ = max(4, int(H * 0.006))
    bd.rectangle((0, H - th_, W, H), fill=main + (255,))
    img.alpha_composite(bar)
    return img.convert("RGB")
