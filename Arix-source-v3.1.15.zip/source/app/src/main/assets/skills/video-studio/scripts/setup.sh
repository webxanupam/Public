#!/bin/sh
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
DATA="${ARIX_VIDEO_HOME:-$HOME/.arix/video-studio}"
MODEL_MIN_BYTES=150000000
MODEL_DIR="$DATA/kokoro-multi-lang-v1_0"
MODEL_URL="https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/kokoro-multi-lang-v1_0.tar.bz2"
export ARIX_VIDEO_HOME="$DATA"
mkdir -p "$DATA"

say() { printf '%s\n' "$*"; }
have() { command -v "$1" >/dev/null 2>&1; }
pkgs() { have pkg || { say "This skill runs in Termux on Android; missing: $*"; return 1; }; pkg install -y "$@"; }

ensure_ca() {
  [ -n "${ARIX_SKIP_CA_FIX:-}" ] && return 0
  have pkg && pkg install -y ca-certificates >/dev/null 2>&1 || true
  have update-ca-certificates && update-ca-certificates >/dev/null 2>&1 || true
  for certpath in "$PREFIX/etc/tls/cert.pem" "$PREFIX/etc/ssl/certs/ca-certificates.crt"; do
    if [ -f "$certpath" ]; then
      [ -n "${CURL_CA_BUNDLE:-}" ] || export CURL_CA_BUNDLE="$certpath"
      [ -n "${SSL_CERT_FILE:-}" ] || export SSL_CERT_FILE="$certpath"
      [ -n "${REQUESTS_CA_BUNDLE:-}" ] || export REQUESTS_CA_BUNDLE="$certpath"
      break
    fi
  done
}

arix_fetch() {
  out="$1"; shift
  min_bytes="$1"; shift
  for url in "$@"; do
    curl -L --retry 5 --retry-delay 3 --retry-all-errors -C - \
         ${CURL_CA_BUNDLE:+--cacert "$CURL_CA_BUNDLE"} \
         -o "$out" "$url" && break
    rc=$?
    case "$rc" in
      35|60|77)  # SSL connect error / cert problem / CA path trouble
        say "   SSL problem with this mirror (exit $rc) — trying the next one..."
        ;;
      *) say "   download failed (exit $rc) — re-run to resume"; return 1 ;;
    esac
  done
  if [ ! -s "$out" ]; then
    say "   strict TLS failed everywhere; retrying relaxed (integrity still verified)..."
    for url in "$@"; do
      curl -kL --retry 3 --retry-delay 3 --retry-all-errors -C - -o "$out" "$url" && break
    done || { say "   download failed - re-run to resume"; return 1; }
  fi
  size=$(wc -c < "$out" 2>/dev/null | tr -d ' ')
  [ "${size:-0}" -lt "$min_bytes" ] && { say "   download incomplete ($size bytes) - re-run to resume"; return 1; }
  return 0
}

core() {
  say "== core: ffmpeg, python, Pillow, numpy, onnxruntime"
  ensure_ca
  have ffmpeg  || pkgs ffmpeg
  have python3 || pkgs python
  python3 -c "import PIL" 2>/dev/null || pkgs python-pillow || python3 -m pip install pillow
  python3 -c "import numpy" 2>/dev/null || pkgs python-numpy || python3 -m pip install numpy
  python3 -c "import onnxruntime" 2>/dev/null || pkgs python-onnxruntime || python3 -m pip install onnxruntime
}

voice() {
  say "== voice: Kokoro v1.0 (am_puck, English, offline)"
  if [ -f "$MODEL_DIR/model.onnx" ] && [ -f "$MODEL_DIR/voices.bin" ] && [ -f "$MODEL_DIR/lexicon-us-en.txt" ]; then
    say "   voice model already present"; return 0
  fi
  have curl || pkgs curl
  have bzip2 || pkgs bzip2
  ensure_ca
  say "   downloading Kokoro voice model (~320 MB, resumable) ..."
  tmp="$DATA/kokoro.tar.bz2"
  arix_fetch "$tmp" "$MODEL_MIN_BYTES" "$MODEL_URL" || arix_fetch "$tmp" "$MODEL_MIN_BYTES" "$MODEL_URL" || return 1
  tar -xjf "$tmp" -C "$DATA" && rm -f "$tmp"
  [ -f "$MODEL_DIR/model.onnx" ] || { say "   extract failed"; return 1; }
  rm -rf "$MODEL_DIR/espeak-ng-data" "$MODEL_DIR/dict" "$MODEL_DIR/lexicon-zh.txt" "$MODEL_DIR/lexicon-gb-en.txt" \
         "$MODEL_DIR"/*.fst
  say "   voice model ready (am_puck)"
}

case "${1:-all}" in
  doctor) ;;
  core) core ;;
  voice|all) core; voice ;;
  *) say "usage: setup.sh [doctor|core|voice|all]"; exit 2 ;;
esac
say "== status"
python3 "$SCRIPT_DIR/voice.py" doctor
