import math

from PIL import Image, ImageDraw

from .cards import El, _q
from .character import make_character
from .fx import blit, halo
from .gfx import COLORS, THEME, Canvas, clamp, ease_out_back, ease_out_cubic, mix

YT_RED = (236, 32, 38)
WHITE = (255, 255, 255)
ORANGE = (255, 142, 44)
_avatar = {}

def _portrait(px):
    im = _avatar.get(px)
    if im is None:
        im = make_character().portrait(px)
        _avatar[px] = im
    return im

def _bell(c, cx, cy, r, swing, fill, ink):
    pts = []
    for i in range(0, 21):
        a = math.pi + math.pi * i / 20.0
        pts.append((math.cos(a) * r * 0.72, math.sin(a) * r * 0.78 + r * 0.05))
    pts += [(r * 0.86, r * 0.62), (r * 1.0, r * 0.74), (-r * 1.0, r * 0.74), (-r * 0.86, r * 0.62)]
    ca, sa = math.cos(swing), math.sin(swing)
    px, py = 0.0, -r * 0.95

    def rot(p):
        x, y = p[0] - px, p[1] - py
        return (cx + px + x * ca - y * sa, cy + py + x * sa + y * ca)
    c.poly([rot(p) for p in pts], fill=fill, outline=ink, lw=1.6)
    kx, ky = rot((0, r * 0.98))
    c.ellipse(kx, ky, r * 0.2, fill=ink)

def _glow(c, drawfn, color, rad, strength, pad=40):
    tmp = Canvas(c.w, c.h, c.scale, ox=c.ox, oy=c.oy)
    drawfn(tmp)
    hl, p = halo(tmp.im, color, rad * c.k, strength)
    blit(c.im, hl, -p, -p)

class Subscribe(El):
    type = "subscribe"

    def __init__(self, spec):
        super().__init__(spec)
        self.name = str(spec.get("name", "webxanupam")).replace(" ", "").lower()
        self.handle = str(spec.get("handle", "@webxanupam")).replace(" ", "").lower()
        self.toggle = float(spec.get("toggle_at", 2.6))
        self.anim_end = self.toggle + 2.4

    def layout(self, width):
        self.w = min(width - 8, self.max_w or width, 560)
        self.h = 338

    def key(self, lt):
        return int(round(min(max(lt, 0.0), self.anim_end) * 30))

    def _letters(self, c, cx, y, text, size, t0, lt, accent):
        widths = [c.text_width(ch, size, "sans") for ch in text]
        total = sum(widths)
        x = cx - total / 2.0
        for i, ch in enumerate(text):
            a = clamp((lt - t0 - i * 0.045) / 0.28)
            if a > 0:
                e = ease_out_back(a)
                col = ORANGE if ch == "x" else WHITE
                c.text(x + widths[i] / 2, y + (1 - e) * 22, ch, size * (0.7 + 0.3 * e), fill=col, anchor="mm")
            x += widths[i]

    def paint(self, c, ox, oy, lt):
        tint = COLORS["accent"] if THEME.get("cine") else (120, 90, 255)
        W = self.w
        cx = ox + W / 2.0
        a0 = ease_out_back(clamp(lt / 0.5))
        ar = 46 * a0
        ay = oy + 50
        if ar > 2:
            def ring(t):
                t.ellipse(cx, ay, ar + 3, outline=tint, lw=4)
            pulse = 0.6 + 0.25 * math.sin(lt * 4.0)
            _glow(c, ring, tint, 12, pulse)
            c.ellipse(cx, ay, ar + 3.5, fill=tint)
            c.ellipse(cx, ay, ar + 0.5, fill=(26, 28, 40))
            d = int(2 * ar * c.k)
            if d > 4:
                im = _portrait(max(8, d)).resize((d, d), Image.LANCZOS) if d != max(8, d) else _portrait(d)
                mask = Image.new("L", (d, d), 0)
                ImageDraw.Draw(mask).ellipse([0, 0, d - 1, d - 1], fill=255)
                out = Image.new("RGBA", (d, d), (0, 0, 0, 0))
                out.paste(im, (0, 0), mask)
                c.paste(out, cx - ar, ay - ar)
            for i in range(3):
                ang = lt * 1.6 + i * 2.094
                c.ellipse(cx + math.cos(ang) * (ar + 11), ay + math.sin(ang) * (ar + 11), 2.6, fill=mix(tint, WHITE, 0.4))
            bw = clamp((lt - 0.25) / 0.4)
            if bw > 0:
                e = ease_out_back(bw)
                bx, by = cx + ar * 0.78, ay + ar * 0.62
                c.rrect(bx - 20 * e, by - 14 * e, 40 * e, 28 * e, 8 * e, fill=YT_RED, outline=(26, 28, 40), lw=2.2)
                c.poly([(bx - 4 * e, by - 7 * e), (bx - 4 * e, by + 7 * e), (bx + 8 * e, by)], fill=WHITE)
        ty = oy + 126
        self._letters(c, cx, ty, self.name, 56 if W > 420 else 46, 0.55, lt, tint)
        ul = ease_out_cubic(clamp((lt - 1.15) / 0.45))
        if ul > 0:
            uw = min(W - 90, 330) * ul
            c.rrect(cx - uw / 2, ty + 36, uw * 0.58, 5, 2.5, fill=WHITE)
            c.rrect(cx - uw / 2 + uw * 0.58, ty + 36, uw * 0.42, 5, 2.5, fill=ORANGE)
        hs = clamp((lt - 1.4) / 0.4)
        if hs > 0:
            e = ease_out_back(hs)
            hw = c.text_width(self.handle, 21, "mono") + 82
            hh = 34
            hy = ty + 70
            c.rrect(cx - hw / 2 * e, hy - hh / 2 * e, hw * e, hh * e, hh / 2 * e, fill=(24, 26, 36), outline=mix(tint, (60, 62, 80), 0.5), lw=1.4)
            if e > 0.8:
                c.rrect(cx - hw / 2 + 12, hy - 8, 22, 16, 4, fill=YT_RED)
                c.poly([(cx - hw / 2 + 20, hy - 4), (cx - hw / 2 + 20, hy + 4), (cx - hw / 2 + 27, hy)], fill=WHITE)
                c.text(cx - hw / 2 + 44, hy + 1, self.handle, 21, fill=(226, 230, 242), kind="mono", anchor="lm")
        bs = ease_out_back(clamp((lt - 1.7) / 0.45))
        bw_, bh_ = min(W - 60, 400), 56
        by0 = ty + 98
        done = lt > self.toggle
        if bs > 0.02:
            sc = bs
            if self.toggle - 0.15 < lt < self.toggle + 0.25:
                sc *= 1.0 - 0.06 * math.sin(clamp((lt - (self.toggle - 0.15)) / 0.4) * math.pi)
            w2, h2 = bw_ * sc, bh_ * sc
            bx2, by2 = cx - w2 / 2, by0 + (bh_ - h2) / 2
            col = (54, 58, 76) if done else YT_RED
            if not done:
                def btn(t):
                    t.rrect(bx2, by2, w2, h2, 16 * sc, outline=YT_RED, lw=3)
                _glow(c, btn, YT_RED, 10, 0.5 + 0.2 * math.sin(lt * 5))
            c.rrect(bx2, by2, w2, h2, 16 * sc, fill=col)
            label = "Subscribed" if done else "Subscribe"
            c.text(cx - 14, by0 + bh_ / 2 + 1, label, 25 * sc, fill=WHITE if not done else (232, 236, 246), anchor="mm")
            sw = math.sin((lt - self.toggle) * 17) * 0.6 * max(0.0, 1.0 - (lt - self.toggle) / 1.5) if done else math.sin(lt * 9) * 0.12
            _bell(c, bx2 + w2 - 40 * sc, by0 + bh_ / 2 + 2, 12 * sc, sw, (255, 214, 64) if done else WHITE, col)
            if lt < self.toggle + 0.5 and lt > 1.8:
                p = ease_out_cubic(clamp((lt - 1.8) / max(0.2, self.toggle - 1.9)))
                px = cx + 60 + (1 - p) * 120
                py = by0 + bh_ * 0.6 + (1 - p) * 90
                if lt > self.toggle - 0.05:
                    c.ellipse(px, py, 10 + (lt - self.toggle + 0.05) * 70, outline=WHITE, lw=2)
                c.ellipse(px, py, 9, fill=WHITE, outline=(20, 22, 30), lw=2)
        if done:
            x = lt - self.toggle
            for i in range(18):
                ang = i * (2 * math.pi / 18) + 0.3
                sp = 90 + (i % 3) * 38
                dist = sp * (1 - math.exp(-x * 3.2))
                r = max(0.0, 5.0 * (1 - x / 1.1))
                if r > 0.6:
                    col = (ORANGE, YT_RED, WHITE, tint)[i % 4]
                    c.ellipse(cx + math.cos(ang) * dist, by0 + bh_ / 2 + math.sin(ang) * dist * 0.8, r, fill=col)
        fs = clamp((lt - self.toggle - 0.45) / 0.4) if done else 0
        if fs > 0:
            e = ease_out_back(fs)
            txt = "Follow  " + self.handle
            fw = c.text_width(txt, 22, "sans") + 70
            fy = by0 + bh_ + 36
            c.rrect(cx - fw / 2 * e, fy - 19 * e, fw * e, 38 * e, 19 * e, fill=(24, 26, 36), outline=tint, lw=2)
            if e > 0.85:
                c.text(cx + 12, fy + 1, txt, 22, fill=(240, 242, 250), anchor="mm")
                kx = cx - fw / 2 + 24
                c.ellipse(kx, fy, 10, fill=tint)
                c.line([(kx - 4.5, fy), (kx - 1, fy + 3.5), (kx + 5, fy - 3.5)], w=2.4, fill=(16, 18, 26))
