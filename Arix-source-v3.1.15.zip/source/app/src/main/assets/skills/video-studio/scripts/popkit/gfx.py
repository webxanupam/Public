"""gfx.py - drawing toolkit for the Pop renderer.

All geometry is in LOGICAL units (the layout canvas is 720 x 1280 for 9:16).
A Canvas renders at  scale * SS  pixels per unit and is box-filtered down by SS
when finished, so every shape and every glyph is smoothly anti-aliased.
"""
import math
import os
import re

from PIL import Image, ImageChops, ImageDraw, ImageFont

SS = 2

BG = (233, 236, 241)
DOT = (203, 208, 218)
INK = (23, 23, 28)
WHITE = (255, 255, 255)
GREY = (164, 169, 182)
GREY_D = (110, 116, 130)
ORANGE = (255, 138, 61)
PURPLE = (108, 71, 240)
GREEN = (31, 170, 122)
PINK = (240, 71, 107)
YELLOW = (255, 200, 64)
BLUE = (64, 140, 255)
RED = (235, 70, 70)
TEAL = (46, 143, 114)
SKY = (214, 226, 255)
CREAM = (255, 246, 226)
BAR_BG = (233, 236, 241)
BGTEXT = INK
THEME = {"name": "paper", "pattern": "dots", "grad": None, "blobs": []}

COLORS = {
    "orange": ORANGE, "purple": PURPLE, "green": GREEN, "pink": PINK, "yellow": YELLOW,
    "blue": BLUE, "red": RED, "teal": TEAL, "ink": INK, "white": WHITE, "grey": GREY,
    "brown": (139, 94, 60), "sky": SKY, "cream": CREAM, "black": (10, 10, 14), "lime": (150, 214, 60),
    "gold": (245, 180, 30), "navy": (28, 44, 110), "skin": (246, 196, 160),
    "dim": (142, 148, 164), "soft": (226, 228, 236), "panel": (20, 22, 30), "panel2": (36, 40, 54), "mint": (52, 211, 153),
}

def color(c, default=ORANGE):
    if c is None:
        return default
    if isinstance(c, (tuple, list)) and len(c) >= 3:
        return tuple(int(v) for v in c[:3])
    if isinstance(c, str):
        k = c.strip().lower()
        if k in COLORS:
            return COLORS[k]
        try:
            h = k.lstrip("#")
            return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
        except Exception:
            return default
    return default

def mix(a, b, t):
    return tuple(int(round(a[i] + (b[i] - a[i]) * t)) for i in range(3))

def ideal_text_on(bg):
    lum = 0.299 * bg[0] + 0.587 * bg[1] + 0.114 * bg[2]
    return INK if lum > 150 else WHITE

def clamp(x, a=0.0, b=1.0):
    return a if x < a else b if x > b else x

def ease_out_cubic(t):
    t = clamp(t)
    return 1 - (1 - t) ** 3

def ease_in_out(t):
    t = clamp(t)
    return 3 * t * t - 2 * t * t * t

def ease_out_back(t, s=1.70158):
    t = clamp(t) - 1
    return 1 + t * t * ((s + 1) * t + s)

def ease_out_bounce(t):
    t = clamp(t)
    if t < 1 / 2.75:
        return 7.5625 * t * t
    if t < 2 / 2.75:
        t -= 1.5 / 2.75
        return 7.5625 * t * t + 0.75
    if t < 2.5 / 2.75:
        t -= 2.25 / 2.75
        return 7.5625 * t * t + 0.9375
    t -= 2.625 / 2.75
    return 7.5625 * t * t + 0.984375


_HERE = os.path.dirname(os.path.abspath(__file__))
_FONT_DIRS = [
    os.path.join(_HERE, "..", "..", "assets", "fonts"),
    "/usr/share/fonts/truetype/google-fonts",
    "/usr/share/fonts/truetype/dejavu",
    "/system/fonts",
]
_FONT_FILES = {
    "sans": ["Poppins-Bold.ttf", "DejaVuSans-Bold.ttf", "Roboto-Bold.ttf"],
    "sansm": ["Poppins-Medium.ttf", "Poppins-Bold.ttf", "DejaVuSans.ttf"],
    "hand": ["Caveat.ttf", "Poppins-BoldItalic.ttf", "DejaVuSans-Bold.ttf"],
    "handm": ["Caveat.ttf", "Poppins-Medium.ttf", "DejaVuSans.ttf"],
    "mono": ["JetBrainsMono-Regular.ttf", "DejaVuSansMono.ttf", "DroidSansMono.ttf"],
    "serif": ["Lora-Italic-Variable.ttf", "LiberationSerif-Italic.ttf", "DejaVuSerif-Italic.ttf", "DejaVuSans-Bold.ttf"],
}
_font_cache = {}
_path_cache = {}

def font_path(kind):
    if kind in _path_cache:
        return _path_cache[kind]
    found = None
    for name in _FONT_FILES.get(kind, _FONT_FILES["sans"]):
        for d in _FONT_DIRS:
            p = os.path.normpath(os.path.join(d, name))
            if os.path.isfile(p):
                found = p
                break
        if found:
            break
    _path_cache[kind] = found
    return found

def get_font(kind, px):
    px = max(4, int(round(px)))
    key = (kind, px)
    f = _font_cache.get(key)
    if f is None:
        p = font_path(kind)
        try:
            f = ImageFont.truetype(p, px) if p else ImageFont.load_default()
            if p and os.path.basename(p) == "Caveat.ttf":
                f.set_variation_by_axes([700 if kind == "hand" else 520])
            elif p and os.path.basename(p).startswith("Lora"):
                f.set_variation_by_axes([500])
        except Exception:
            f = ImageFont.load_default()
        _font_cache[key] = f
    return f

_REPL = {"\u2192": "->", "\u279c": "->", "\u2713": "v", "\u2717": "x", "\u2014": "-", "\u2026": "...", "\u201c": '"', "\u201d": '"',
         "\u2018": "'", "\u2019": "'", "\u00a0": " "}

def clean(s):
    """Replace glyphs the bundled fonts lack (arrows, check marks, curly quotes)."""
    for k, v in _REPL.items():
        if k in s:
            s = s.replace(k, v)
    return s

def measure(text, kind, size):
    """Logical width/height of `text` at logical `size` (uses a 4x font for precision)."""
    text = clean(text)
    f = get_font(kind, size * 4)
    w = f.getlength(text) / 4.0
    return w, size * 1.25



class Canvas:
    """RGBA drawing surface in logical units. (ox, oy) is the logical position of the surface's top-left corner."""

    def __init__(self, w, h, scale, bg=(0, 0, 0, 0), ox=0.0, oy=0.0):
        self.w, self.h = float(w), float(h)
        self.scale = float(scale)
        self.k = self.scale * SS
        self.ox, self.oy = float(ox), float(oy)
        self.im = Image.new("RGBA", (max(1, int(math.ceil(w * self.k))), max(1, int(math.ceil(h * self.k)))), bg)
        self.d = ImageDraw.Draw(self.im)

    def P(self, v):
        return v * self.k

    def _px(self, x, y):
        return ((x - self.ox) * self.k, (y - self.oy) * self.k)

    def _box(self, x, y, w, h):
        x0, y0 = self._px(x, y)
        return [x0, y0, x0 + w * self.k - 1, y0 + h * self.k - 1]

    def rrect(self, x, y, w, h, r=12, fill=None, outline=None, lw=0):
        if w * self.k < 2 or h * self.k < 2:
            return
        r = max(0.0, min(r, (w * self.k - 2) / 2.0 / self.k, (h * self.k - 2) / 2.0 / self.k))
        self.d.rounded_rectangle(self._box(x, y, w, h), radius=r * self.k, fill=fill,
                                 outline=outline, width=max(0, int(round(lw * self.k))) if outline else 0)

    def box(self, x, y, w, h, r=14, fill=WHITE, ink=INK, lw=3, shadow=(5, 5), shadow_color=None):
        """The signature look: thick ink outline + hard offset shadow."""
        if shadow:
            self.rrect(x + shadow[0], y + shadow[1], w, h, r, fill=shadow_color or ink)
        self.rrect(x, y, w, h, r, fill=fill, outline=ink, lw=lw)

    def ellipse(self, cx, cy, rx, ry=None, fill=None, outline=None, lw=0):
        ry = rx if ry is None else ry
        if rx * self.k < 1.5 or ry * self.k < 1.5:
            return
        x0, y0 = self._px(cx - rx, cy - ry)
        self.d.ellipse([x0, y0, x0 + 2 * rx * self.k - 1, y0 + 2 * ry * self.k - 1],
                       fill=fill, outline=outline, width=max(0, int(round(lw * self.k))) if outline else 0)

    def blob(self, cx, cy, rx, ry, fill, ink=INK, lw=3):
        self.ellipse(cx, cy, rx + lw / 2, ry + lw / 2, fill=ink)
        self.ellipse(cx, cy, rx - lw / 2, ry - lw / 2, fill=fill)

    def line(self, pts, w=3, fill=INK, round_caps=True):
        P = [self._px(x, y) for x, y in pts]
        wk = max(1, int(round(w * self.k)))
        self.d.line(P, fill=fill, width=wk, joint="curve")
        if round_caps and wk > 3:
            r = wk / 2.0
            for (x, y) in (P[0], P[-1]):
                self.d.ellipse([x - r, y - r, x + r, y + r], fill=fill)

    def poly(self, pts, fill=None, outline=None, lw=0, round_join=True):
        P = [self._px(x, y) for x, y in pts]
        if fill is not None:
            self.d.polygon(P, fill=fill)
        if outline is not None and lw > 0:
            self.line(list(pts) + [pts[0]], w=lw, fill=outline)

    def _mask(self, pts):
        P = [self._px(x, y) for x, y in pts]
        x0 = max(0, int(min(p[0] for p in P)))
        y0 = max(0, int(min(p[1] for p in P)))
        x1 = min(self.im.width, int(max(p[0] for p in P)) + 1)
        y1 = min(self.im.height, int(max(p[1] for p in P)) + 1)
        w, h = x1 - x0, y1 - y0
        if w < 2 or h < 2:
            return None
        mask = Image.new("L", (w, h), 0)
        ImageDraw.Draw(mask).polygon([(x - x0, y - y0) for x, y in P], fill=255)
        return x0, y0, w, h, mask

    def fill_alpha(self, pts, rgb, a):
        m = self._mask(pts)
        if m is None:
            return
        x0, y0, w, h, mask = m
        layer = Image.new("RGBA", (w, h), tuple(rgb) + (255,))
        layer.putalpha(mask.point(lambda v, al=a: int(v * al)))
        self.im.alpha_composite(layer, (x0, y0))

    def gradient(self, pts, c1, c2, a1=1.0, a2=1.0, vertical=True):
        m = self._mask(pts)
        if m is None:
            return
        x0, y0, w, h, mask = m
        n = h if vertical else w
        col = Image.new("RGBA", (1, n) if vertical else (n, 1))
        px = col.load()
        for i in range(n):
            t = i / float(max(1, n - 1))
            rgb = mix(c1, c2, t)
            al = int(255 * (a1 + (a2 - a1) * t))
            px[(0, i) if vertical else (i, 0)] = rgb + (al,)
        layer = col.resize((w, h))
        layer.putalpha(ImageChops.multiply(layer.getchannel("A"), mask))
        self.im.alpha_composite(layer, (x0, y0))

    def hatch(self, pts, base, seed=0, spacing=7.0):
        import random
        m = self._mask(pts)
        if m is None:
            return
        x0, y0, w, h, mask = m
        k = self.k
        layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        dl = ImageDraw.Draw(layer)
        lum = 0.299 * base[0] + 0.587 * base[1] + 0.114 * base[2]
        tone = mix(base, WHITE if lum < 150 else INK, 0.2)
        rnd = random.Random(seed)
        sp = spacing * k
        lwk = max(1, int(round(1.3 * k)))
        c = -float(h)
        while c < w:
            t = 0.0
            while t < 1.0:
                a, b = t, min(1.0, t + rnd.uniform(0.18, 0.5))
                dl.line([(c + h * a, h - h * a), (c + h * b, h - h * b)], fill=tone + (140,), width=lwk)
                t = b + rnd.uniform(0.02, 0.12)
            c += sp * rnd.uniform(0.8, 1.25)
        layer.putalpha(ImageChops.multiply(layer.getchannel("A"), mask))
        self.im.alpha_composite(layer, (x0, y0))

    def arc(self, cx, cy, r, a0, a1, w=3, fill=INK):
        k = self.k
        x0, y0 = self._px(cx - r, cy - r)
        self.d.arc([x0, y0, x0 + 2 * r * k, y0 + 2 * r * k], a0, a1, fill=fill, width=max(1, int(round(w * k))))

    def bezier(self, p0, p1, p2, p3, w=3, fill=INK, n=40):
        pts = []
        for i in range(n + 1):
            t = i / n
            u = 1 - t
            x = u ** 3 * p0[0] + 3 * u * u * t * p1[0] + 3 * u * t * t * p2[0] + t ** 3 * p3[0]
            y = u ** 3 * p0[1] + 3 * u * u * t * p1[1] + 3 * u * t * t * p2[1] + t ** 3 * p3[1]
            pts.append((x, y))
        self.line(pts, w=w, fill=fill)
        return pts

    def arrow(self, p0, p1, w=4, fill=PURPLE, head=12):
        self.line([p0, p1], w=w, fill=fill)
        ang = math.atan2(p1[1] - p0[1], p1[0] - p0[0])
        for s in (-1, 1):
            a = ang + math.pi + s * 0.5
            self.line([p1, (p1[0] + head * math.cos(a), p1[1] + head * math.sin(a))], w=w, fill=fill)

    def text(self, x, y, s, size, fill=INK, kind="sans", anchor="la", spacing=0.0):
        s = clean(s)
        f = get_font(kind, size * self.k)
        px, py = self._px(x, y)
        if spacing:
            tw = sum(f.getlength(ch) + spacing * self.k for ch in s) - spacing * self.k
            cx = px - tw / 2 if anchor[0] == "m" else (px - tw if anchor[0] == "r" else px)
            for ch in s:
                self.d.text((cx, py), ch, font=f, fill=fill, anchor="l" + anchor[1:])
                cx += f.getlength(ch) + spacing * self.k
            return
        self.d.text((px, py), s, font=f, fill=fill, anchor=anchor)

    def text_width(self, s, size, kind="sans"):
        return measure(s, kind, size)[0]

    def paste(self, sprite_rgba, x, y):
        px, py = self._px(x, y)
        self.im.alpha_composite(sprite_rgba, (int(round(px)), int(round(py))))

    def finish(self):
        w = max(1, int(round(self.w * self.scale)))
        h = max(1, int(round(self.h * self.scale)))
        if SS == 1:
            return self.im
        if self.im.width == w * SS and self.im.height == h * SS:
            return self.im.reduce(SS)
        return self.im.resize((w, h), Image.BOX)

def pill(c, x, y, text, fill=ORANGE, size=22, pad_x=16, pad_y=8, kind="sans", fg=None, lw=3, shadow=(4, 4)):
    """Draw a label chip at (x,y); returns (w,h)."""
    fg = fg or ideal_text_on(fill)
    w, h = pill_size(text, size, pad_x, pad_y, kind)
    c.box(x, y, w, h, r=min(14, h / 2), fill=fill, lw=lw, shadow=shadow)
    c.text(x + pad_x, y + h / 2 + 1, text, size, fill=fg, kind=kind, anchor="lm")
    return w, h

def pill_size(text, size=22, pad_x=16, pad_y=8, kind="sans"):
    return measure(text, kind, size)[0] + pad_x * 2, size * 1.25 + pad_y * 2 - 4

_THEME_KEYS = ("BG", "DOT", "PURPLE", "ORANGE", "GREEN", "PINK", "BLUE", "YELLOW", "TEAL", "RED", "BGTEXT", "BAR_BG")

def make_theme(seed, last_hue=None):
    """A new look for every video, generated (not picked from a list): base hue, light or dark page, accent hues spread
    around the wheel, a gradient, two soft colour glows and a pattern."""
    import colorsys
    import hashlib
    import random
    rnd = random.Random(int(hashlib.sha1(str(seed).encode("utf-8")).hexdigest()[:12], 16))
    hue = rnd.random()
    if last_hue is not None:
        while min(abs(hue - last_hue), 1 - abs(hue - last_hue)) < 0.14:
            hue = rnd.random()
    dark = rnd.random() < 0.5

    def hsv(h, s, v):
        r, g, b = colorsys.hsv_to_rgb(h % 1.0, max(0, min(1, s)), max(0, min(1, v)))
        return (int(r * 255), int(g * 255), int(b * 255))
    offs = [0.0, 0.09, 0.20, 0.33, 0.47, 0.62, 0.80]
    rnd.shuffle(offs)
    sat, val = (0.58, 0.97) if dark else (0.70, 0.90)
    acc = [hsv(hue + o, sat + rnd.uniform(-0.06, 0.06), val + rnd.uniform(-0.05, 0.03)) for o in offs]
    names = ["PURPLE", "ORANGE", "GREEN", "PINK", "BLUE", "YELLOW", "TEAL"]
    th = dict(zip(names, acc))
    th["RED"] = hsv(0.99, 0.72, 0.92)
    if dark:
        th["BG"] = hsv(hue, 0.55, 0.16)
        th["DOT"] = hsv(hue, 0.45, 0.30)
        top, bot = hsv(hue + 0.02, 0.60, 0.28), hsv(hue - 0.03, 0.62, 0.10)
        th["BGTEXT"] = hsv(hue, 0.06, 0.98)
    else:
        th["BG"] = hsv(hue, 0.07, 0.96)
        th["DOT"] = hsv(hue, 0.14, 0.82)
        top, bot = hsv(hue + 0.02, 0.05, 0.99), hsv(hue - 0.03, 0.16, 0.93)
        th["BGTEXT"] = INK
    th["BAR_BG"] = th["BG"]
    th["grad"] = (top, bot)
    th["pattern"] = rnd.choice(["dots", "grid", "diag", "waves", "dots"])
    th["blobs"] = [(rnd.uniform(0.7, 1.0), rnd.uniform(0.0, 0.25), rnd.uniform(0.5, 0.8), acc[0], 0.36 if dark else 0.30),
                   (rnd.uniform(0.0, 0.3), rnd.uniform(0.75, 1.0), rnd.uniform(0.5, 0.8), acc[3], 0.30 if dark else 0.24)]
    th["dark"] = dark
    th["hue"] = hue
    th["name"] = "g%02x%02x%02x" % th["BG"]
    return th

def paper_theme():
    th = {"PURPLE": (226, 70, 58), "ORANGE": (250, 203, 60), "GREEN": (150, 200, 170), "PINK": (238, 150, 150),
          "BLUE": (167, 205, 226), "YELLOW": (250, 236, 170), "TEAL": (120, 175, 160), "RED": (226, 70, 58),
          "BG": (250, 250, 247), "DOT": (234, 234, 229), "BGTEXT": (20, 20, 20), "BAR_BG": (250, 250, 247)}
    th.update(grad=None, pattern="paper", blobs=[], dark=False, hue=0.0, name="paper-doodle", doodle=True)
    return th

def cine_theme(seed, last_hue=None):
    import colorsys
    import hashlib
    import random
    rnd = random.Random(int(hashlib.sha1(str(seed).encode("utf-8")).hexdigest()[:12], 16))
    hue = rnd.random()
    if last_hue is not None:
        while min(abs(hue - last_hue), 1 - abs(hue - last_hue)) < 0.14:
            hue = rnd.random()

    def hsv(h, s, v):
        r, g, b = colorsys.hsv_to_rgb(h % 1.0, s, v)
        return (int(r * 255), int(g * 255), int(b * 255))
    prim = hsv(hue, 0.80, 1.0)
    cool = hsv(hue + 0.55, 0.62, 1.0)
    hot = hsv(hue + 0.33, 0.70, 1.0)
    gold = hsv(hue + 0.12, 0.78, 1.0)
    th = {"PURPLE": prim, "ORANGE": cool, "GREEN": hot, "PINK": gold, "BLUE": cool, "YELLOW": gold, "TEAL": hot, "RED": (255, 86, 86),
          "BG": (8, 8, 12), "DOT": (30, 30, 40), "BGTEXT": (246, 246, 250), "BAR_BG": (8, 8, 12)}
    th.update(grad=None, pattern="none", blobs=[], dark=True, hue=hue, cine=True, name="cine%02x%02x%02x" % prim)
    return th

def apply_theme(th):
    """Re-colour the whole toolkit (this module AND every sibling that imported the colours by value)."""
    import sys
    g = globals()
    for k in _THEME_KEYS:
        if k in th:
            g[k] = th[k]
    COLORS.update({"accent": g["PURPLE"], "accent2": g["ORANGE"], "accent3": g["GREEN"], "accent4": g["PINK"],
                   "bg": g["BG"], "bgtext": g["BGTEXT"], "tint": mix(g["PURPLE"], WHITE, 0.8), "shade": mix(g["PURPLE"], INK, 0.55)})
    THEME.clear()
    THEME.update(name=th["name"], pattern=th.get("pattern", "dots"), grad=th.get("grad"), blobs=th.get("blobs", []),
                 dark=bool(th.get("dark")), hue=th.get("hue"), doodle=bool(th.get("doodle")), cine=bool(th.get("cine")))
    _bg_cache.clear()
    pkg = __name__.rpartition(".")[0]
    for mname, mod in list(sys.modules.items()):
        if mod is None or not mname.startswith(pkg + ".") or mod is sys.modules.get(__name__):
            continue
        for k in _THEME_KEYS:
            if k in th and hasattr(mod, k):
                setattr(mod, k, g[k])
    return THEME["name"]

_bg_cache = {}

def _blend_blob(im, cx, cy, rad, col, strength):
    """Soft radial colour glow (numpy-free: a blurred ellipse)."""
    from PIL import ImageFilter
    W, H = im.size
    layer = Image.new("RGB", (W, H), col)
    m = Image.new("L", (W, H), 0)
    r = rad * max(W, H) * 0.5
    ImageDraw.Draw(m).ellipse([cx * W - r, cy * H - r, cx * W + r, cy * H + r], fill=int(255 * strength))
    m = m.filter(ImageFilter.GaussianBlur(r * 0.45))
    im.paste(layer, (0, 0), m)

def background(W, H, scale):
    """Themed page: gradient + soft colour glows + pattern (cached per size and theme)."""
    key = (W, H, THEME["name"])
    if key in _bg_cache:
        return _bg_cache[key]
    im = Image.new("RGB", (W, H), BG)
    if THEME.get("grad"):
        top, bot = THEME["grad"]
        col = Image.new("RGB", (1, H))
        px = col.load()
        for y in range(H):
            px[0, y] = mix(top, bot, y / float(max(1, H - 1)))
        im = col.resize((W, H))
    for (cx, cy, rad, c, st) in THEME.get("blobs", []):
        _blend_blob(im, cx, cy, rad, c, st)
    d = ImageDraw.Draw(im)
    step = 28 * scale
    pat = THEME.get("pattern", "dots")
    if pat == "dots":
        r = max(1.0, 1.6 * scale)
        y = step / 2
        while y < H:
            x = step / 2
            while x < W:
                d.ellipse([x - r, y - r, x + r, y + r], fill=DOT)
                x += step
            y += step
    elif pat == "paper":
        lw = max(1, int(round(1.0 * scale)))
        s2 = 44 * scale
        x = 0.0
        while x < W:
            d.line([(x, 0), (x, H)], fill=DOT, width=lw)
            x += s2
        y = 0.0
        while y < H:
            d.line([(0, y), (W, y)], fill=DOT, width=lw)
            y += s2
    elif pat == "grid":
        lw = max(1, int(round(1.0 * scale)))
        s2 = step * 1.6
        x = 0
        while x < W:
            d.line([(x, 0), (x, H)], fill=DOT, width=lw)
            x += s2
        y = 0
        while y < H:
            d.line([(0, y), (W, y)], fill=DOT, width=lw)
            y += s2
    elif pat == "diag":
        lw = max(1, int(round(1.2 * scale)))
        s2 = step * 1.5
        k = -H
        while k < W:
            d.line([(k, 0), (k + H, H)], fill=DOT, width=lw)
            k += s2
    elif pat == "waves":
        lw = max(1, int(round(1.4 * scale)))
        s2 = step * 2.2
        y = s2 / 2
        while y < H:
            pts = [(x, y + math.sin(x / (40.0 * scale) + y / (90.0 * scale)) * 7 * scale) for x in range(0, W + 8, 8)]
            d.line(pts, fill=DOT, width=lw)
            y += s2
    _bg_cache[key] = im
    return im

def fit_lines(text, maxw, size, min_size=11, kind="sans", max_lines=2):
    """Largest font size (<= size) at which `text` fits `maxw`, wrapping at spaces / slashes up to max_lines.
    Returns (lines, size). Last resort: shrink to min_size and ellipsise - text NEVER leaves its box."""
    text = clean(str(text))
    sz = float(size)
    while sz >= min_size:
        if measure(text, kind, sz)[0] <= maxw:
            return [text], sz
        if max_lines >= 2:
            toks = [t for t in re.split(r"(?<=[/ -])", text) if t != ""]
            best = None
            for cut in range(1, len(toks)):
                a, b = "".join(toks[:cut]).strip(), "".join(toks[cut:]).strip()
                w = max(measure(a, kind, sz)[0], measure(b, kind, sz)[0])
                if w <= maxw and (best is None or w < best[0]):
                    best = (w, [a, b])
            if best:
                return best[1], sz
        sz -= 1
    out = text
    while len(out) > 2 and measure(out + "...", kind, min_size)[0] > maxw:
        out = out[:-1]
    return [out + "..." if out != text else out], float(min_size)
