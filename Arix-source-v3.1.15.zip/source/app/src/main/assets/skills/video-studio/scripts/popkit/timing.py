"""timing.py - voice synthesis + word-level timing for frame-exact sync.

Single source of truth: the narration text. Every sentence is synthesized on its own
(so its exact duration is known), concatenated into the master track at known
offsets, and every word is then aligned INSIDE its sentence against the real
audio envelope (pauses at commas are snapped to detected silences). Captions and
animation triggers read these same times - they cannot drift from the voice.
"""
import os
import re
import sys
import wave

try:
    import numpy as np
except Exception:
    np = None

SR = 24000
HOP = 240

_VOW = re.compile(r"[aeiouyAEIOUY]+")

def syllables(token):
    core = re.sub(r"[^A-Za-z0-9']", "", token)
    if not core:
        return 1
    if core.isdigit():
        return max(1, len(core) // 2 + 1)
    n = len(_VOW.findall(core))
    if core.lower().endswith("e") and n > 1 and not core.lower().endswith(("le", "ee")):
        n -= 1
    n += len(re.findall(r"[A-Z]", core[1:])) // 2
    if core.isupper() and len(core) <= 5:
        n = len(core)
    return max(1, n)

def split_sentences(text, max_len=150):
    text = re.sub(r"\s+", " ", text.strip())
    parts = re.split(r"(?<=[.!?])\s+", text)
    out = []
    for p in parts:
        while len(p) > max_len:
            cut = max(p.rfind(", ", 0, max_len), p.rfind("; ", 0, max_len), p.rfind(" - ", 0, max_len))
            if cut < 40:
                cut = p.rfind(" ", 0, max_len)
            if cut < 20:
                cut = max_len
            out.append(p[:cut + 1].strip())
            p = p[cut + 1:].strip()
        if p:
            out.append(p)
    return out or [text]

def read_wav(path):
    with wave.open(path, "rb") as w:
        n, sr, ch, sw = w.getnframes(), w.getframerate(), w.getnchannels(), w.getsampwidth()
        raw = w.readframes(n)
    if sw != 2:
        raise ValueError("only 16-bit wav supported")
    a = np.frombuffer(raw, dtype="<i2").astype(np.float32) / 32768.0
    if ch > 1:
        a = a.reshape(-1, ch).mean(axis=1)
    if sr != SR:
        x = np.linspace(0, len(a) - 1, int(len(a) * SR / sr))
        a = np.interp(x, np.arange(len(a)), a).astype(np.float32)
    return a

def write_wav(path, samples):
    pcm = (np.clip(samples, -1, 1) * 32767).astype("<i2")
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm.tobytes())

def envelope(a):
    """RMS envelope, 10 ms frames, normalised to the 95th percentile (0..1)."""
    n = len(a) // HOP
    if n == 0:
        return np.zeros(1, dtype=np.float32)
    fr = a[:n * HOP].reshape(n, HOP)
    rms = np.sqrt((fr * fr).mean(axis=1))
    p = float(np.percentile(rms, 95)) or 1e-6
    return np.clip(rms / p, 0, 1.2).astype(np.float32)

def trim(a, keep=0.05):
    """Trim leading/trailing silence, keeping `keep` seconds."""
    env = envelope(a)
    idx = np.where(env > 0.06)[0]
    if idx.size == 0:
        return a
    s = max(0, int(idx[0] * HOP - keep * SR))
    e = min(len(a), int((idx[-1] + 1) * HOP + keep * SR))
    return a[s:e]

_PAUSE_END = tuple(",;:.!?—-…")

def align_words(tokens, a, speech_start=None, speech_end=None):
    """Return [(start, end)] seconds for each token inside the audio `a` (one sentence).

    Strategy: words get time proportional to their syllable count between detected
    silences; silences found in the envelope are matched (in order) to the token
    boundaries that end with punctuation so a comma pause lands exactly where the
    voice actually pauses.
    """
    n = len(tokens)
    if n == 0:
        return []
    env = envelope(a)
    dur = len(a) / float(SR)
    idx = np.where(env > 0.07)[0]
    t0 = (idx[0] * HOP / SR) if idx.size else 0.0
    t1 = ((idx[-1] + 1) * HOP / SR) if idx.size else dur
    if speech_start is not None:
        t0 = speech_start
    if speech_end is not None:
        t1 = speech_end
    t1 = max(t1, t0 + 0.05 * n)
    w = [max(1.0, float(syllables(t))) for t in tokens]

    pauses = []
    lo = int(t0 * 100)
    hi = int(t1 * 100)
    run = None
    for i in range(lo + 5, min(hi - 5, len(env))):
        if env[i] < 0.07:
            run = i if run is None else run
        else:
            if run is not None and i - run >= 9:
                pauses.append((run / 100.0, i / 100.0))
            run = None
    bounds = [i for i, t in enumerate(tokens[:-1]) if t[-1:] in _PAUSE_END]
    cursor = t0
    start_i = 0
    used = 0
    spans = [None] * n
    total_w = sum(w)
    pause_total = sum(e - s for s, e in pauses)

    def assign(i0, i1, a0, a1):
        """words i0..i1 inclusive share [a0, a1] by syllable weight."""
        ww = sum(w[i0:i1 + 1]) or 1.0
        c = a0
        for k in range(i0, i1 + 1):
            d = (a1 - a0) * w[k] / ww
            spans[k] = (c, c + d)
            c += d

    for b in bounds:
        if used >= len(pauses):
            break

        share = sum(w[start_i:b + 1]) / max(1e-6, sum(w[start_i:]))
        pred = cursor + share * max(0.05, (t1 - cursor - sum(e - s for s, e in pauses[used:])))
        best, bi = None, None
        for j in range(used, len(pauses)):
            d = abs(pauses[j][0] - pred)
            if best is None or d < best:
                best, bi = d, j
        tol = max(0.35, 0.22 * (t1 - t0))
        if bi is not None and best <= tol and pauses[bi][0] > cursor + 0.04 * (b - start_i + 1):
            assign(start_i, b, cursor, pauses[bi][0])
            cursor = pauses[bi][1]
            start_i = b + 1
            used = bi + 1
    assign(start_i, n - 1, cursor, t1)
    return spans

class SceneAudio:
    def __init__(self):
        self.samples = None
        self.words = []
        self.speech_dur = 0.0
        self.engine = None

def estimate_words(tokens, wpm=150.0):
    """No audio: timings from syllable counts (captions-only videos)."""
    sps = wpm / 60.0 * 1.45
    t = 0.18
    out = []
    for tok in tokens:
        d = max(0.14, syllables(tok) / sps)
        out.append((tok, t, t + d))
        t += d + (0.16 if tok[-1:] in ",;:" else 0.28 if tok[-1:] in ".!?" else 0.02)
    return out

def synth_scene(text, voice, workdir, idx, vcfg):
    """Synthesize `text` sentence by sentence. Returns SceneAudio (never raises)."""
    out = SceneAudio()
    tokens_all = text.split()
    enabled = (vcfg or {}).get("enabled", True) and np is not None
    if not enabled:
        out.words = estimate_words(tokens_all)
        out.speech_dur = out.words[-1][2] if out.words else 0.0
        return out
    lead = 0.12
    pieces = [np.zeros(int(lead * SR), dtype=np.float32)]
    cur = lead
    words = []
    sent_gap = float((vcfg or {}).get("sentence_gap", 0.28))
    used_engine = None
    for si, sent in enumerate(split_sentences(text)):
        wav = os.path.join(workdir, f"voice_{idx}_{si}.wav")
        eng, dur = voice.say(sent, wav, speed=float((vcfg or {}).get("speed", 1.0)))
        toks = sent.split()
        if eng is None or not os.path.isfile(wav):

            est = estimate_words(toks)
            d = est[-1][2] + 0.2 if est else 0.5
            pieces.append(np.zeros(int(d * SR), dtype=np.float32))
            words += [(t, cur + s, cur + e) for t, s, e in est]
            cur += d
            continue
        used_engine = used_engine or eng
        a = trim(read_wav(wav), keep=0.03)
        spans = align_words(toks, a)
        for tok, (s, e) in zip(toks, spans):
            words.append((tok, cur + s, cur + e))
        pieces.append(a)
        cur += len(a) / float(SR)
        gap = sent_gap if sent[-1:] in ".!?" else sent_gap * 0.6
        pieces.append(np.zeros(int(gap * SR), dtype=np.float32))
        cur += gap
    out.samples = np.concatenate(pieces)
    out.words = words
    out.engine = used_engine
    out.speech_dur = words[-1][2] if words else 0.0
    return out
