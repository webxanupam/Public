import math

import numpy as np

SR = 24000

def _t(d):
    return np.arange(int(SR * d), dtype=np.float32) / SR

def _rng(seed):
    return np.random.RandomState(seed)

def _lp(x, a):
    y = np.empty_like(x)
    acc = 0.0
    if np.isscalar(a):
        a = np.full(len(x), a, dtype=np.float32)
    for i in range(len(x)):
        acc += a[i] * (x[i] - acc)
        y[i] = acc
    return y / max(1.0, float(np.abs(y).max()))

def _lp_fast(x, a):
    if np.isscalar(a):
        n = len(x)
        k = int(max(1, round(1.0 / max(a, 1e-3))))
        if k <= 1:
            return x
        c = np.cumsum(np.insert(x, 0, 0.0))
        out = (c[k:] - c[:-k]) / k
        return np.concatenate([np.full(k - 1, out[0] if len(out) else 0.0, dtype=np.float32), out]).astype(np.float32)[:n]
    return _lp(x, a)

def _env(n, a=0.01, r=0.2, power=1.0):
    t = np.arange(n, dtype=np.float32) / SR
    d = n / SR
    e = np.minimum(1.0, t / max(a, 1e-4)) * np.exp(-(t / max(r, 1e-3)) * power)
    return e.astype(np.float32)

def whoosh(d=0.5, lo=0.04, hi=0.5, seed=1):
    n = int(SR * d)
    noise = _rng(seed).randn(n).astype(np.float32)
    u = np.linspace(0, 1, n, dtype=np.float32)
    a = lo + (hi - lo) * np.abs(np.sin(u * math.pi)) ** 1.5
    y = _lp(noise, a) - 0.5 * _lp(noise, a * 0.25)
    env = np.sin(u * math.pi) ** 2
    y = y * env
    return y / (np.abs(y).max() + 1e-6) * 0.9

def swipe(d=0.22, seed=2):
    return whoosh(d, 0.12, 0.7, seed)

def pop(d=0.14, f0=620.0, f1=180.0):
    t = _t(d)
    f = f1 + (f0 - f1) * np.exp(-t * 38)
    ph = 2 * math.pi * np.cumsum(f) / SR
    y = np.sin(ph) * _env(len(t), 0.001, 0.045)
    return y.astype(np.float32) * 0.9

def tick(d=0.035, seed=3, tone=2600.0):
    t = _t(d)
    n = _rng(seed).randn(len(t)).astype(np.float32)
    y = (n - _lp_fast(n, 0.3)) * _env(len(t), 0.0004, 0.008)
    y += np.sin(2 * math.pi * tone * t) * _env(len(t), 0.0004, 0.01) * 0.6
    return y / (np.abs(y).max() + 1e-6) * 0.7

def click(d=0.05, seed=4):
    return tick(d, seed, 1500.0)

def clap(d=0.09, seed=5):
    t = _t(d)
    n = _rng(seed).randn(len(t)).astype(np.float32)
    band = _lp(n, 0.35) - _lp(n, 0.04)
    y = band * (_env(len(t), 0.0005, 0.018) + 0.5 * np.roll(_env(len(t), 0.0005, 0.02), int(0.012 * SR)))
    return y / (np.abs(y).max() + 1e-6) * 0.9

def _bellish(freqs, amps, d, decay):
    t = _t(d)
    y = np.zeros(len(t), np.float32)
    for f, a in zip(freqs, amps):
        y += a * np.sin(2 * math.pi * f * t) * np.exp(-t * decay * (1 + f / 4000.0))
    y *= np.minimum(1.0, t / 0.002)
    return y / (np.abs(y).max() + 1e-6) * 0.85

def ding(d=0.9):
    return _bellish([1318.5, 1975.5, 2637.0], [1.0, 0.45, 0.2], d, 4.2)

def bell(d=1.2):
    return _bellish([880.0, 2434.0, 4752.0, 1320.0], [1.0, 0.55, 0.3, 0.4], d, 3.0)

def notify(d=0.5):
    a = _bellish([988.0, 1976.0], [1.0, 0.3], 0.3, 7.0)
    b = _bellish([1318.5, 2637.0], [1.0, 0.3], 0.38, 6.0)
    y = np.zeros(int(SR * d), np.float32)
    y[: len(a)] += a
    s = int(0.12 * SR)
    y[s: s + len(b)] += b[: len(y) - s]
    return y * 0.9

def success(d=0.8):
    y = np.zeros(int(SR * d), np.float32)
    for i, f in enumerate([523.25, 659.25, 783.99, 1046.5]):
        n = _bellish([f, f * 2], [1.0, 0.3], 0.5, 5.0)
        s = int(i * 0.09 * SR)
        y[s: s + len(n)] += n[: len(y) - s] * 0.8
    return y / max(1.0, float(np.abs(y).max()))

def impact(d=0.55, seed=6):
    t = _t(d)
    f = 38 + 70 * np.exp(-t * 22)
    ph = 2 * math.pi * np.cumsum(f) / SR
    y = np.sin(ph) * _env(len(t), 0.002, 0.16)
    n = _rng(seed).randn(len(t)).astype(np.float32)
    y += _lp(n, 0.08) * _env(len(t), 0.001, 0.05) * 0.9
    return y / (np.abs(y).max() + 1e-6) * 0.95

def riser(d=1.2, seed=7):
    n = int(SR * d)
    noise = _rng(seed).randn(n).astype(np.float32)
    u = np.linspace(0, 1, n, dtype=np.float32)
    a = 0.02 + 0.5 * u ** 2
    y = _lp(noise, a) * u ** 1.6
    t = u * d
    f = 220 + 900 * u ** 2
    y += 0.35 * np.sin(2 * math.pi * np.cumsum(f) / SR) * u ** 2
    return y / (np.abs(y).max() + 1e-6) * 0.8

def sparkle(d=0.7, seed=8):
    r = _rng(seed)
    y = np.zeros(int(SR * d), np.float32)
    for i in range(9):
        f = r.uniform(2400, 5200)
        s = int(r.uniform(0, 0.4) * SR)
        n = _bellish([f, f * 1.5], [1.0, 0.4], 0.18, 20.0)
        y[s: s + len(n)] += n[: len(y) - s] * r.uniform(0.35, 0.8)
    return y / (np.abs(y).max() + 1e-6) * 0.8

def buzz(d=0.35):
    t = _t(d)
    y = np.sign(np.sin(2 * math.pi * 96 * t)) * 0.5 + np.sin(2 * math.pi * 142 * t) * 0.3
    return (y * _env(len(t), 0.003, 0.2)).astype(np.float32)

def shutter(d=0.2):
    a = click(0.05, 11)
    b = click(0.06, 12)
    y = np.zeros(int(SR * d), np.float32)
    y[: len(a)] += a
    s = int(0.09 * SR)
    y[s: s + len(b)] += b[: len(y) - s] * 0.8
    return y / max(1.0, float(np.abs(y).max()))

def boing(d=0.35):
    t = _t(d)
    f = 260 + 120 * np.sin(2 * math.pi * 9 * t) * np.exp(-t * 7)
    y = np.sin(2 * math.pi * np.cumsum(f) / SR) * _env(len(t), 0.002, 0.14)
    return y.astype(np.float32) * 0.8

def slide(d=0.3):
    return whoosh(d, 0.06, 0.35, 21)

def type_key(d=0.03, seed=0):
    return tick(d, 30 + seed % 7, 2200.0 + 150 * (seed % 5))

def step(d=0.11, seed=41):
    n = int(SR * d)
    noise = _rng(seed).randn(n).astype(np.float32)
    y = _lp_fast(noise, 0.12) * _env(n, 0.002, 0.03)
    t = _t(d)
    y = y + 0.6 * np.sin(2 * math.pi * 95 * t) * _env(n, 0.002, 0.04)
    return y / (np.abs(y).max() + 1e-6) * 0.8

def flutter(d=0.5, seed=43):
    n = int(SR * d)
    noise = _rng(seed).randn(n).astype(np.float32)
    t = _t(d)
    y = _lp_fast(noise, 0.35) * (0.5 + 0.5 * np.sign(np.sin(2 * math.pi * 21 * t))) * np.sin(math.pi * t / d)
    return y / (np.abs(y).max() + 1e-6) * 0.7

def snap(d=0.22):
    t = _t(d)
    n = len(t)
    noise = _rng(47).randn(n).astype(np.float32)
    y = (noise * _env(n, 0.0005, 0.012) + 0.7 * np.sin(2 * math.pi * 1500 * t) * _env(n, 0.0005, 0.03))
    return y / (np.abs(y).max() + 1e-6) * 0.85

def gasp(d=0.3):
    n = int(SR * d)
    noise = _rng(49).randn(n).astype(np.float32)
    u = np.linspace(0, 1, n, dtype=np.float32)
    y = _lp_fast(noise, 0.2) * np.clip(np.sin(math.pi * u), 0, None) ** 1.5
    return y / (np.abs(y).max() + 1e-6) * 0.6

def thud(d=0.25):
    t = _t(d)
    n = len(t)
    f = 70 + 80 * np.exp(-t * 30)
    y = np.sin(2 * math.pi * np.cumsum(f) / SR) * _env(n, 0.002, 0.09)
    return y.astype(np.float32) * 0.9

def twinkle(d=0.5):
    return sparkle()

def _chirp(d, f0, f1, seed):
    t = _t(d)
    f = f0 + (f1 - f0) * (t / d) ** 0.7
    ph = 2 * math.pi * np.cumsum(f + 120 * np.sin(2 * math.pi * 28 * t)) / SR
    return (np.sin(ph) * np.clip(np.sin(math.pi * t / d), 0, None) ** 1.2).astype(np.float32)

LIB = {
    "whoosh": whoosh, "swipe": swipe, "slide": slide, "pop": pop, "tick": tick, "click": click, "clap": clap, "ding": ding,
    "bell": bell, "notify": notify, "success": success, "impact": impact, "boom": impact, "riser": riser, "sparkle": sparkle,
    "buzz": buzz, "error": buzz, "shutter": shutter, "boing": boing, "type": type_key,
       "step": step, "flutter": flutter, "snap": snap, "gasp": gasp, "thud": thud, "twinkle": twinkle,
}
GAIN = {"whoosh": 0.42, "swipe": 0.4, "slide": 0.35, "pop": 0.36, "tick": 0.3, "click": 0.4, "clap": 0.45, "ding": 0.36, "bell": 0.34,
        "notify": 0.34, "success": 0.36, "impact": 0.5, "boom": 0.5, "riser": 0.34, "sparkle": 0.3, "buzz": 0.3, "error": 0.3,
        "shutter": 0.4, "boing": 0.34, "type": 0.22, "step": 0.3, "flutter": 0.22, "snap": 0.4, "gasp": 0.3, "thud": 0.4, "twinkle": 0.3}

_cache = {}

def sound(name):
    y = _cache.get(name)
    if y is None:
        fn = LIB.get(name)
        if fn is None:
            return None
        y = fn().astype(np.float32)
        _cache[name] = y
    return y / max(1.0, float(np.abs(y).max()))

def mix(total, events, level=1.0):
    n = int(math.ceil(total * SR)) + SR
    out = np.zeros(n, np.float32)
    for (t, name, gain, *rest) in events:
        y = sound(name)
        if y is None or t < 0:
            continue
        s = int(round(t * SR))
        if s >= n:
            continue
        seg = y[: n - s]
        out[s: s + len(seg)] += seg * GAIN.get(name, 0.3) * gain * level
    return out[: int(math.ceil(total * SR))]
