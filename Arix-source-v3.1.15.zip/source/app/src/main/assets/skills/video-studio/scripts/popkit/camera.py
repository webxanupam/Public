import math

from PIL import Image

SHOTS = {
    "establish": ("pull", 1.0, 0.45),
    "wide": ("drift", 1.0, 0.5),
    "medium": ("hold", 1.45, 0.62),
    "close": ("push", 2.1, 0.4),
    "extreme_close": ("push", 2.8, 0.4),
    "track": ("track", 1.4, 0.55),
    "pan": ("pan", 1.25, 0.5),
    "tilt_up": ("tilt_up", 1.25, 0.5),
    "tilt_down": ("tilt_down", 1.25, 0.5),
    "push": ("push", 1.6, 0.55),
    "pull": ("pull", 1.6, 0.55),
    "object": ("object", 1.5, 0.5),
}

AUTO = ["push", "drift_r", "pull", "drift_l", "punch", "push", "tilt", "pull"]

def _ease(x):
    x = 0.0 if x < 0 else (1.0 if x > 1 else x)
    return 1 - (1 - x) ** 3

def _w(s):
    return "".join(ch for ch in str(s).lower() if ch.isalnum())

def _move(name, lt, dur, x):
    z, dx, dy, rot = 1.0, 0.0, 0.0, 0.0
    p = lt / max(0.4, dur)
    p = min(1.0, max(0.0, p))
    if name == "push":
        z = 1.0 + 0.085 * p
        dy = -6 * p
    elif name == "pull":
        z = 1.09 - 0.085 * p
    elif name == "drift_r":
        z = 1.06
        dx = -26 + 52 * p
    elif name == "drift_l":
        z = 1.06
        dx = 26 - 52 * p
    elif name == "rise":
        z = 1.07
        dy = 22 - 44 * p
    elif name == "tilt":
        z = 1.07 + 0.02 * p
        rot = -1.6 + 3.2 * p
    elif name == "punch":
        k = math.exp(-x * 7.0)
        z = 1.0 + 0.1 * k + 0.03 * p
    elif name == "shake":
        k = math.exp(-x * 4.5)
        dx = 9 * k * math.sin(x * 62)
        dy = 7 * k * math.sin(x * 51 + 1)
        rot = 0.7 * k * math.sin(x * 44)
        z = 1.03
    elif name == "orbit":
        z = 1.07
        dx = 24 * math.sin(p * math.pi * 2)
        dy = 8 * math.sin(p * math.pi * 4)
        rot = 1.1 * math.sin(p * math.pi * 2)
    return z, dx, dy, rot

class Plan:
    def __init__(self, sc, n):
        self.dur = sc.dur
        c = sc.spec.get("cam")
        self.base = str(c).lower() if c else ("push" if sc.spec.get("outro") else AUTO[sc.idx % len(AUTO)])
        self.idx = sc.idx
        self.timed = []
        self.shot = str(sc.spec.get("shot") or "").lower().replace("-", "_").replace(" ", "_")
        if self.shot in ("tracking",):
            self.shot = "track"
        if self.shot in ("establishing",):
            self.shot = "establish"
        if self.shot not in SHOTS:
            self.shot = ""
        self.zoom = float(sc.spec.get("zoom") or 0.0)
        fo = sc.spec.get("focus")
        pt = lambda v, d: (float(v[0]), float(v[1])) if isinstance(v, (list, tuple)) and len(v) >= 2 else d
        self.focus_ref = fo if isinstance(fo, dict) else None
        self.focus0 = pt(fo, (0.5, 0.62)) if not isinstance(fo, dict) else (0.5, 0.62)
        self.focus1 = self.focus0
        name = SHOTS.get(self.shot, SHOTS["wide"])[0] if self.shot else ""
        if name == "pan":
            self.focus0, self.focus1 = (self.focus0[0] - 0.22, self.focus0[1]), (self.focus0[0] + 0.22, self.focus0[1])
        elif name == "tilt_up":
            self.focus0, self.focus1 = (self.focus0[0], 0.72), (self.focus0[0], 0.28)
        elif name == "tilt_down":
            self.focus0, self.focus1 = (self.focus0[0], 0.28), (self.focus0[0], 0.72)
        elif name == "track" and isinstance(fo, (list, tuple)) and len(fo) >= 4:
            self.focus0, self.focus1 = (float(fo[0]), float(fo[1])), (float(fo[2]), float(fo[3]))
        ws = sc.words
        for a in (sc.spec.get("cams") or []):
            if not isinstance(a, dict):
                continue
            t0 = 0.0
            if a.get("at") is not None:
                t0 = float(a["at"])
            elif ws and a.get("on") is not None:
                on = a["on"]
                if isinstance(on, int):
                    t0 = ws[max(0, min(len(ws) - 1, on))][1]
                else:
                    for (tx, s, e) in ws:
                        if _w(tx) == _w(on):
                            t0 = s
                            break
            self.timed.append((t0, float(a.get("dur", 0.7)), str(a.get("do") or "punch").lower()))

    def shot_state(self, lt, focus_fn):
        name, zoom, fy = SHOTS.get(self.shot, SHOTS["wide"])
        if self.zoom:
            zoom = self.zoom
        p = min(1.0, max(0.0, lt / max(0.5, self.dur)))
        e = p * p * (3 - 2 * p)
        f0 = self.focus0
        f1 = self.focus1
        fx = f0[0] + (f1[0] - f0[0]) * e
        fy2 = f0[1] + (f1[1] - f0[1]) * e
        if name in ("track", "object") and focus_fn is not None:
            q = focus_fn(lt)
            if q is not None:
                fx, fy2 = q
        z = 1.0
        if name == "pull":
            z = zoom - (zoom - 1.0) * e
        elif name == "push":
            z = 1.0 + (zoom - 1.0) * e
        elif name == "drift":
            z = 1.0 + 0.06 * e
        elif name in ("pan", "tilt_up", "tilt_down"):
            z = zoom
        else:
            z = zoom if self.idx >= 0 else 1.0
        if name == "hold" or name == "track" or name == "object":
            z = zoom * (1.0 + 0.03 * e)
        if self.idx > 0 and lt < 0.3:
            z *= 1 + 0.03 * (1 - _ease(lt / 0.3))
        return z, fx, fy2

    def state(self, lt):
        z, dx, dy, rot = 1.0, 0.0, 0.0, 0.0
        if self.base != "none":
            z, dx, dy, rot = _move(self.base, lt, self.dur, lt)
        for (t0, d, name) in self.timed:
            x = lt - t0
            if 0 <= x <= d:
                z2, dx2, dy2, r2 = _move(name, x, d, x)
                z *= z2
                dx += dx2
                dy += dy2
                rot += r2
        if self.idx > 0 and lt < 0.3:
            e = _ease(lt / 0.3)
            sg = 1 if self.idx % 2 else -1
            dx += sg * (1 - e) * 46
            z *= 1 + 0.05 * (1 - e)
        return z, dx, dy, rot

def apply(frame, st, W, H):
    z, dx, dy, rot = st
    if abs(z - 1) < 0.0008 and abs(dx) < 0.3 and abs(dy) < 0.3 and abs(rot) < 0.02:
        return frame
    sc = W / 720.0 if W <= H else W / 1280.0
    dx *= sc
    dy *= sc
    mx = max(0.0, (z - 1) * W / 2.0)
    my = max(0.0, (z - 1) * H / 2.0)
    dx = max(-mx, min(mx, dx))
    dy = max(-my, min(my, dy))
    cx, cy = W / 2.0, H / 2.0
    if abs(rot) < 0.02 and z >= 1.0:
        bx0 = min(max(cx - cx / z - dx, 0.0), W - W / z)
        by0 = min(max(cy - cy / z - dy, 0.0), H - H / z)
        return frame.resize(frame.size, Image.BILINEAR, box=(bx0, by0, bx0 + W / z, by0 + H / z))
    a = math.radians(rot)
    ca, sa = math.cos(a) / z, math.sin(a) / z
    c0 = cx - (ca * cx - sa * cy) - dx / z * 0 - dx
    c1 = cy - (sa * cx + ca * cy) - dy
    return frame.transform(frame.size, Image.AFFINE, (ca, -sa, c0, sa, ca, c1), resample=Image.BILINEAR)

