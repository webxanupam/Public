"""spec.py - research gate, spec validation and the closing subscribe scene."""

OUTRO_TEXT = "If this helped, subscribe and follow webxanupam on YouTube. See you in the next one!"

def check_research(spec):
    """None when the spec carries its research; otherwise a message telling the agent what to do."""
    r = spec.get("research")
    if isinstance(r, dict):
        if r.get("waived"):
            return None
        srcs = r.get("sources") or []
        facts = r.get("facts") or []
        if len(srcs) >= 2 and len(facts) >= 3:
            return None
        return ("research is incomplete: need >= 2 sources and >= 3 facts (found %d sources, %d facts). "
                "Run web_search + fetch_url (or scripts/research.py), then fill spec.research." % (len(srcs), len(facts)))
    return ("spec has no `research` block. Research the topic FIRST (web_search + fetch_url, or "
            "`python3 scripts/research.py \"<topic>\" --out research.json`), write the facts you use into "
            "spec.research = {\"sources\": [{title,url}], \"facts\": [...]} and base the script on them. "
            "For purely personal/creative videos set spec.research = {\"waived\": \"<reason>\"}.")

def _kinds(els):
    for e in els:
        if isinstance(e, dict):
            yield str(e.get("type", "")).lower()

def expand(spec):
    """Shorthand -> full elements: scene `draw` (shape list) and scene `headline` (text or list of lines)."""
    spec = dict(spec)
    out = []
    style = str(spec.get("style") or "cinema").lower()
    asp = spec.get("aspect", "9:16")
    dsize = [400, 400] if style == "doodle" else ([640, 380] if asp == "9:16" else ([420, 330] if asp == "1:1" else [760, 310]))
    for sc in spec.get("scenes") or []:
        sc = dict(sc)
        vis = sc.get("visual") or sc.get("elements") or []
        vis = [vis] if isinstance(vis, dict) else list(vis)
        dr = sc.pop("draw", None)
        if dr is not None:
            el = dict(dr) if isinstance(dr, dict) and "shapes" in dr else {"shapes": dr}
            el["type"] = "draw"
            el.setdefault("size", sc.pop("size", dsize))
            vis.append(el)
        hl = sc.pop("headline", None)
        if hl is not None:
            vis.insert(0, {"type": "headline", "lines": [hl] if isinstance(hl, str) else list(hl), "under": sc.pop("under", None)})
        sc["visual"] = vis
        out.append(sc)
    spec["scenes"] = out
    return spec

def validate(spec):
    """Every scene needs its own drawing. Returns a list of problems (empty when the spec is complete)."""
    problems = []
    scenes = spec.get("scenes") or []
    if not scenes:
        problems.append("spec.scenes is empty")
    for i, sc in enumerate(scenes):
        vis = sc.get("visual") or sc.get("elements") or []
        if isinstance(vis, dict):
            vis = [vis]
        if sc.get("outro"):
            continue
        if not str(sc.get("narration", "")).strip():
            problems.append("scene %d has no narration" % (i + 1))
        if not any(k in ("draw", "image", "photo") for k in _kinds(vis)):
            problems.append("scene %d has no drawing: author a {\"type\": \"draw\", \"shapes\": [...]} picture drawn from what "
                            "its narration says" % (i + 1))
    return problems

def _has_subscribe(sc):
    vis = sc.get("visual") or []
    if isinstance(vis, dict):
        vis = [vis]
    return any(k in ("subscribe", "outro") for k in _kinds(vis))

def normalize(spec):
    """Adds the closing 'subscribe and follow @webxanupam' scene (spec.outro=false opts out)."""
    spec = dict(spec)
    scenes = [dict(s) for s in (spec.get("scenes") or [])]
    if spec.get("outro", True) is not False and scenes:
        if _has_subscribe(scenes[-1]):
            scenes[-1].setdefault("layout", "hero")
        else:
            scenes.append({
                "narration": OUTRO_TEXT,
                "label": {"text": "see you soon", "color": "pink"},
                "mood": "happy", "layout": "hero", "outro": True,
                "visual": [
                    {"type": "subscribe", "name": "webxanupam", "handle": "@webxanupam", "toggle_at": 2.6},
                ]})
    spec["scenes"] = scenes
    return spec
