#!/usr/bin/env python3
"""plan_video.py - turn the request into a production plan (no rendering).

  python3 plan_video.py "make a 40s reel on how GPT works, hindi" --json plan.json

Reads only what the request states outright: aspect, length.
The agent then researches, writes the script and DRAWS every scene itself.
"""
import argparse
import json
import re
import sys

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("request")
    ap.add_argument("--json")
    a = ap.parse_args()
    r = a.request
    low = r.lower()
    m = re.search(r"(\d{2,3})\s*(?:s|sec|seconds)\b", low)
    target = int(m.group(1)) if m else (35 if re.search(r"short|reel|tiktok|shorts", low) else 75)
    aspect = "16:9" if re.search(r"youtube video|landscape|16:9|horizontal", low) else "1:1" if ("square" in low or "1:1" in low) else "9:16"
    plan = dict(
        request=r, aspect=aspect, target_seconds=target, scenes=max(5, round(target / 4.6)),
        research_queries=[r, r + " explained", r + " statistics facts"],
        notes=["Research FIRST (web_search + fetch_url), put sources+facts in spec.research",
               "Scene 1 = hook (<= 8 words); one idea per scene",
               "Scenes without a drawing are illustrated automatically from their narration (popkit/autodraw.py); author a {\"type\": \"draw\"} picture yourself for anything specific",
               "The closing subscribe + follow scene is added automatically"],
    )
    txt = json.dumps(plan, ensure_ascii=False, indent=1)
    if a.json:
        open(a.json, "w", encoding="utf-8").write(txt)
    print(txt)

if __name__ == "__main__":
    sys.exit(main())
