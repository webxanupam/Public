import math

POSES = {
    "stand": dict(ls=-12, le=8, rs=12, re=-8, lh=-7, lk=0, rh=7, rk=0, lean=0, tilt=0),
    "wave": dict(ls=-12, le=8, rs=150, re=28, lh=-7, lk=0, rh=7, rk=0, lean=0, tilt=-6),
    "walk": dict(ls=26, le=14, rs=-22, re=-10, lh=-24, lk=8, rh=22, rk=-28, lean=4, tilt=0),
    "run": dict(ls=70, le=70, rs=-72, re=-60, lh=-50, lk=10, rh=36, rk=-72, lean=14, tilt=0),
    "point": dict(ls=-12, le=8, rs=96, re=6, lh=-7, lk=0, rh=7, rk=0, lean=2, tilt=0),
    "cheer": dict(ls=-158, le=-10, rs=158, re=10, lh=-10, lk=0, rh=10, rk=0, lean=0, tilt=0),
    "shrug": dict(ls=-62, le=70, rs=62, re=-70, lh=-7, lk=0, rh=7, rk=0, lean=0, tilt=8),
    "think": dict(ls=-12, le=8, rs=34, re=118, lh=-7, lk=0, rh=7, rk=0, lean=0, tilt=10),
    "sit": dict(ls=-16, le=30, rs=16, re=-30, lh=-86, lk=88, rh=86, rk=-88, lean=0, tilt=0),
    "sad": dict(ls=-4, le=4, rs=4, re=-4, lh=-6, lk=0, rh=6, rk=0, lean=12, tilt=18),
    "panic": dict(ls=-60, le=-118, rs=60, re=118, lh=-14, lk=0, rh=14, rk=0, lean=-2, tilt=0),
    "scared": dict(ls=-120, le=-40, rs=120, re=40, lh=-14, lk=10, rh=14, rk=-10, lean=-6, tilt=0),
    "push": dict(ls=-78, le=-6, rs=-72, re=-4, lh=-10, lk=0, rh=28, rk=-32, lean=22, tilt=0),
    "fall": dict(ls=-150, le=-20, rs=140, re=30, lh=-40, lk=26, rh=50, rk=-30, lean=32, tilt=24),
    "carry": dict(ls=-58, le=-60, rs=58, re=60, lh=-7, lk=0, rh=7, rk=0, lean=0, tilt=0),
    "thumbsup": dict(ls=-12, le=8, rs=62, re=106, lh=-7, lk=0, rh=7, rk=0, lean=0, tilt=-4),
    "reach": dict(ls=-12, le=8, rs=128, re=-4, lh=-7, lk=0, rh=7, rk=0, lean=4, tilt=0),
    "fight": dict(ls=-60, le=120, rs=60, re=-120, lh=-20, lk=10, rh=14, rk=-22, lean=4, tilt=0),
}
MOODS = ("neutral", "happy", "sad", "angry", "surprised", "scared", "laugh", "think", "sleepy", "smirk", "shout", "cry")
UP, LO, TORSO, THIGH, SHIN, HEAD_R, H = 32.0, 30.0, 50.0, 42.0, 42.0, 31.0, 200.0
INK = "ink"


def _pt(o, ang, ln):
    a = math.radians(ang)
    return (o[0] + math.sin(a) * ln, o[1] + math.cos(a) * ln)


def _r(p):
    return [round(p[0], 1), round(p[1], 1)]


def _line(pts, lw=5.5, **kw):
    d = {"t": "line", "pts": [_r(p) for p in pts], "stroke": INK, "lw": lw}
    d.update(kw)
    return d


def _path(d, **kw):
    out = {"t": "path", "d": d}
    out.update(kw)
    return out


def _eyes(x, ey, look, rx, ry):
    out = []
    for sx in (-1, 1):
        cx = sx * 11.5 + look
        out.append({"t": "ellipse", "cx": x(cx), "cy": ey, "rx": rx, "ry": ry, "fill": INK})
        out.append({"t": "ellipse", "cx": x(cx + 1.3), "cy": round(ey - ry * 0.38, 1), "rx": round(rx * 0.36, 2), "ry": round(rx * 0.36, 2), "fill": "white"})
        out.append({"t": "ellipse", "cx": x(cx - 1.2), "cy": round(ey + ry * 0.42, 1), "rx": round(rx * 0.17, 2), "ry": round(rx * 0.17, 2), "fill": "white", "opacity": 0.8})
    return out


def _face(mood, f, look, blink=False):
    x = lambda v: round(v * f, 1)
    out = []
    ey = -3.0
    if blink and mood not in ("laugh", "sleepy"):
        out += [_line([(x(-16), ey + 1), (x(-7), ey + 1)], 3.4), _line([(x(7), ey + 1), (x(16), ey + 1)], 3.4)]
    elif mood in ("sleepy",):
        out += [_line([(x(-17), ey), (x(-7), ey + 1)], 3.4), _line([(x(7), ey + 1), (x(17), ey)], 3.4)]
    elif mood in ("laugh", "happy"):
        out += [_path("M %s %s Q %s %s %s %s" % (x(-17), ey + 3, x(-11.5), ey - 5, x(-6), ey + 3), stroke=INK, lw=3.6),
                _path("M %s %s Q %s %s %s %s" % (x(6), ey + 3, x(11.5), ey - 5, x(17), ey + 3), stroke=INK, lw=3.6)] if mood == "laugh" else [
            *_eyes(x, ey, look, 4.0, 6.2)]
    elif mood in ("surprised", "scared", "shout"):
        out += _eyes(x, ey, look, 4.2, 7.2)
    else:
        out += _eyes(x, ey, look, 3.8, 6.0)
    brows = {
        "angry": ((-19, -13, -6, -7), (6, -7, 19, -13)),
        "sad": ((-19, -9, -6, -15), (6, -15, 19, -9)),
        "scared": ((-19, -9, -6, -17), (6, -17, 19, -9)),
        "cry": ((-19, -9, -6, -15), (6, -15, 19, -9)),
        "surprised": ((-18, -16, -6, -19), (6, -19, 18, -16)),
        "shout": ((-18, -13, -6, -18), (6, -18, 18, -13)),
        "think": ((-18, -14, -6, -15), (6, -19, 18, -17)),
        "smirk": ((-18, -14, -6, -15), (6, -19, 18, -17)),
        "happy": ((-18, -15, -6, -17), (6, -17, 18, -15)),
    }.get(mood)
    if brows:
        a, b = brows
        out.append(_path("M %s %s Q %s %s %s %s" % (x(a[0]), a[1], x((a[0] + a[2]) / 2), (a[1] + a[3]) / 2 - 3, x(a[2]), a[3]), stroke=INK, lw=3.4))
        out.append(_path("M %s %s Q %s %s %s %s" % (x(b[0]), b[1], x((b[0] + b[2]) / 2), (b[1] + b[3]) / 2 - 3, x(b[2]), b[3]), stroke=INK, lw=3.4))
    my = 13.0
    if mood in ("happy",):
        out.append(_path("M %s %s Q %s %s %s %s Q %s %s %s %s Z" % (x(-11), my - 2, x(0), my + 18, x(11), my - 2, x(0), my + 1, x(-11), my - 2), fill="#7d1d24", stroke=INK, lw=3.4))
        out.append({"t": "ellipse", "cx": 0, "cy": my + 8, "rx": 5.2, "ry": 2.6, "fill": "#ef6f7d"})
    elif mood == "laugh":
        out.append(_path("M %s %s Q %s %s %s %s Q %s %s %s %s Z" % (x(-14), my - 4, x(0), my + 22, x(14), my - 4, x(0), my - 8, x(-14), my - 4),
                         fill="#7d1d24", stroke=INK, lw=3.4))
        out.append({"t": "ellipse", "cx": 0, "cy": my + 9, "rx": 6.5, "ry": 3.2, "fill": "#ef6f7d"})
    elif mood in ("sad", "cry"):
        out.append(_path("M %s %s Q %s %s %s %s" % (x(-9), my + 6, x(0), my - 5, x(9), my + 6), stroke=INK, lw=3.6))
    elif mood in ("shout", "scared"):
        out.append({"t": "ellipse", "cx": 0, "cy": my + 2, "rx": 13, "ry": 10 if mood == "shout" else 8, "fill": "white", "stroke": INK, "lw": 3.6})
    elif mood == "surprised":
        out.append({"t": "ellipse", "cx": 0, "cy": my + 2, "rx": 5.5, "ry": 7.5, "fill": "white", "stroke": INK, "lw": 3.4})
    elif mood == "angry":
        out.append(_path("M %s %s L %s %s L %s %s L %s %s L %s %s" % (x(-11), my + 4, x(-5), my, x(0), my + 4, x(5), my, x(11), my + 4), stroke=INK, lw=3.4))
    elif mood == "smirk":
        out.append(_path("M %s %s Q %s %s %s %s" % (x(-8), my + 2, x(3), my + 9, x(12), my - 3), stroke=INK, lw=3.6))
    elif mood == "think":
        out.append(_line([(x(-7), my + 3), (x(7), my + 1)], 3.6))
    elif mood == "sleepy":
        out.append({"t": "ellipse", "cx": 0, "cy": my + 3, "rx": 4, "ry": 4.5, "fill": "white", "stroke": INK, "lw": 3.2})
    else:
        out.append(_line([(x(-7), my + 2), (x(7), my + 2)], 3.6))
    if mood in ("scared", "panic", "shout"):
        for (dx, dy, s) in ((-40, -18, 1), (-46, -4, 0.8), (40, -18, 1), (46, -4, 0.8)):
            out.append(_path("M %s %s Q %s %s %s %s Q %s %s %s %s" % (x(dx), dy - 5 * s, x(dx + 4 * s), dy, x(dx), dy + 4 * s, x(dx - 4 * s), dy, x(dx), dy - 5 * s),
                             fill="white", stroke=INK, lw=2.6))
    if mood == "cry":
        out += [_path("M %s %s Q %s %s %s %s" % (x(-11.5), 5, x(-14), 18, x(-12), 28), stroke="blue", lw=3.4),
                _path("M %s %s Q %s %s %s %s" % (x(11.5), 5, x(14), 18, x(12), 28), stroke="blue", lw=3.4)]
    if mood == "angry":
        out.append(_path("M %s %s L %s %s M %s %s L %s %s" % (x(30), -34, x(38), -40, x(34), -26, x(44), -28), stroke="red", lw=3.2))
    return out


def _hair(kind, f, color):
    x = lambda v: round(v * f, 1)
    r = HEAD_R
    top = -r
    if kind == "none":
        return []
    if kind == "tuft":
        return [_path("M %s %s Q %s %s %s %s" % (x(-2), top + 1, x(-4), top - 18, x(-24), top - 20), stroke=INK, lw=4.2),
                _path("M %s %s Q %s %s %s %s" % (x(3), top + 1, x(10), top - 17, x(27), top - 14), stroke=INK, lw=4.2),
                _path("M %s %s Q %s %s %s %s" % (x(-9), top + 2, x(-14), top - 14, x(-30), top - 8), stroke=INK, lw=3.6),
                _path("M %s %s Q %s %s %s %s" % (x(0), top, x(1), top - 22, x(-6), top - 30), stroke=INK, lw=3.8),
                _path("M %s %s Q %s %s %s %s" % (x(9), top + 3, x(18), top - 8, x(31), top - 1), stroke=INK, lw=3.4)]
    if kind == "spiky":
        out = []
        for dx, ln in ((-18, 12), (-9, 18), (0, 22), (9, 18), (18, 12)):
            out.append(_line([(x(dx), top + 5 - abs(dx) * 0.12), (x(dx * 1.15), top - ln)], 4.2))
        return out
    if kind == "curly":
        out = []
        for dx in (-18, -9, 0, 9, 18):
            out.append({"t": "circle", "cx": x(dx), "cy": top - 2 - (1 - abs(dx) / 22.0) * 3, "r": 7.5, "fill": color or "ink", "stroke": INK, "lw": 3})
        return out
    if kind == "bun":
        return [{"t": "circle", "cx": 0, "cy": top - 10, "r": 11, "fill": color or "ink", "stroke": INK, "lw": 3.4},
                _path("M %s %s Q %s %s %s %s" % (x(-22), top + 8, 0, top - 6, x(22), top + 8), stroke=INK, lw=4)]
    if kind == "long":
        return [_path("M %s %s Q %s %s %s %s" % (x(-26), -6, x(-30), top - 4, 0, top + 1), stroke=INK, lw=4),
                _path("M %s %s Q %s %s %s %s" % (x(26), -6, x(30), top - 4, 0, top + 1), stroke=INK, lw=4),
                _line([(x(-29), -8), (x(-31), 26)], 4.4), _line([(x(29), -8), (x(31), 26)], 4.4)]
    return []


def _extras(opts, f):
    x = lambda v: round(v * f, 1)
    r = HEAD_R
    out = []
    kinds = opts if isinstance(opts, (list, tuple)) else [opts]
    for k in kinds:
        if k == "cap":
            out.append(_path("M %s %s Q %s %s %s %s L %s %s L %s %s Z" % (x(-r), -8, 0, -r - 24, x(r), -8, x(r + 17), -6, x(-r), -8), fill="accent", stroke=INK, lw=3.6))
        elif k == "hat":
            out += [{"t": "rect", "x": -24, "y": -r - 22, "w": 48, "h": 26, "r": 4, "fill": "ink", "stroke": INK, "lw": 3},
                    {"t": "rect", "x": -36, "y": -r + 2, "w": 72, "h": 7, "r": 3, "fill": "ink", "stroke": INK, "lw": 3}]
        elif k == "glasses":
            out += [{"t": "circle", "cx": x(-11.5), "cy": -3, "r": 10, "stroke": INK, "lw": 2.8},
                    {"t": "circle", "cx": x(11.5), "cy": -3, "r": 10, "stroke": INK, "lw": 2.8},
                    _line([(x(-1.5), -3), (x(1.5), -3)], 2.8)]
        elif k == "crown":
            out.append({"t": "poly", "pts": [_r((x(-20), -r + 4)), _r((x(-23), -r - 20)), _r((x(-10), -r - 8)), _r((0, -r - 24)), _r((x(10), -r - 8)),
                                             _r((x(23), -r - 20)), _r((x(20), -r + 4))], "fill": "accent2", "stroke": INK, "lw": 3.2})
        elif k == "beard":
            out.append(_path("M %s %s Q %s %s %s %s" % (x(-26), 8, 0, 56, x(26), 8), stroke=INK, lw=4))
        elif k == "scarf":
            out.append(_line([(x(-17), r + 3), (x(17), r + 5)], 11, stroke=INK))
            out.append(_line([(x(-17), r + 3), (x(17), r + 5)], 7.2, stroke="#e53935"))
    return out


def _scarf_tails(f, hc_off, sway):
    x = lambda v: round(v * f, 1)
    y0 = hc_off + 4
    out = []
    for i, (dy, ln, w) in enumerate(((0, 52, 9), (7, 40, 8))):
        sw = sway * (1 + 0.35 * i)
        p = "M %s %s C %s %s %s %s %s %s" % (x(-14), y0 + dy, x(-14 - ln * 0.35), y0 + dy + 3 + sw * 2, x(-14 - ln * 0.7), y0 + dy + 6 + sw * 3, x(-14 - ln), y0 + dy + 14 + sw * 5)
        out.append(_path(p, stroke=INK, lw=w + 3.4))
        out.append(_path(p, stroke="#e53935", lw=w))
    return out



def figure(pose="stand", mood="happy", color=None, x=0, y=0, h=H, facing=1, extras=None, hair="tuft", lw=6.8, angles=None,
           name=None, act=None, outfit=None, look=None, blink=False, contact=True, shadow=True, light=0.0, tx=0.0, flut=0.0, **motion):
    p = dict(POSES.get(pose, POSES["stand"]))
    p.update(angles or {})
    if mood not in MOODS:
        mood = "neutral"
    f = -1 if facing < 0 else 1
    for k in p:
        p[k] = p[k] * f
    s = h / H
    hip = (0.0, -(THIGH + SHIN) + 2.0)
    lean = p["lean"]
    sh = (hip[0] + math.sin(math.radians(lean)) * TORSO, hip[1] - math.cos(math.radians(lean)) * TORSO)
    tilt = p["tilt"]
    hc = (sh[0] + math.sin(math.radians(tilt)) * (HEAD_R + 3), sh[1] - math.cos(math.radians(tilt)) * (HEAD_R + 3))
    ink = color or INK

    def limb(root, a1, a2, l1, l2):
        m = _pt(root, a1, l1)
        e = _pt(m, a2, l2)
        return [root, m, e]

    def leg(a1, a2):
        return limb(hip, a1, a2, THIGH, SHIN)

    def arm(a1, a2):
        return limb(sh, a1, a2, UP, LO)

    shapes = []
    shapes = []
    if outfit:
        shapes.append(_line([_pt(sh, 180 + lean, -8), hip], 26, stroke=outfit, opacity=0.5))
    leg_feet = []
    for a1, k1 in ((p["lh"], p["lk"]), (p["rh"], p["rk"])):
        pts = leg(a1, a1 + k1)
        foot = _pt(pts[2], 90 * f, 11)
        leg_feet.append(pts[2][1])
        shapes.append(_line(pts + [foot], lw, stroke=ink))
    shapes.append(_line([hip, sh], lw + 0.5, stroke=ink))
    if "scarf" in (extras if isinstance(extras, (list, tuple)) else [extras]):
        shapes.append({"t": "group", "x": round(hc[0], 1), "y": round(hc[1], 1), "rot": tilt, "shapes": _scarf_tails(f, HEAD_R, flut + 0.25 * lean / 10.0)})
    if "cape" in (extras if isinstance(extras, (list, tuple)) else [extras]):
        shapes.append({"t": "poly", "pts": [_r((sh[0] - 4 * f, sh[1] + 2)), _r((sh[0] - 40 * f, hip[1] + 14)), _r((sh[0] - 22 * f, hip[1] + 32)), _r((sh[0] + 6 * f, sh[1] + 28))],
                       "fill": "accent", "stroke": INK, "lw": 3})
    hands = []
    hand_pts = []
    for key in ("l", "r"):
        a1, rel = p[key + "s"], p[key + "e"]
        pts = arm(a1, a1 + rel)
        a = dict(t="line", pts=[_r(q) for q in pts], stroke=ink, lw=lw)
        if act == "talk" and key == "r":
            a.update(loop="wobble", amp=0.3, speed=1.8, pivot=_r(sh))
        shapes.append(a)
        ang = a1 + rel
        hand_pts.append(pts[2])
        hands.append({"t": "ellipse", "cx": round(pts[2][0], 1), "cy": round(pts[2][1], 1), "rx": 7.2, "ry": 5.6, "fill": "white", "stroke": INK,
                      "lw": 3.4, "rot": round(90 - ang, 1)})
    head = {"t": "group", "x": round(hc[0], 1), "y": round(hc[1], 1), "rot": tilt, "shapes": []}
    hs = head["shapes"]
    hfill = "white"
    hs.append({"t": "ellipse", "cx": round(-HEAD_R * 0.98, 1), "cy": 2, "rx": 5.4, "ry": 8, "fill": hfill, "stroke": INK, "lw": 3.4})
    hs.append({"t": "ellipse", "cx": round(HEAD_R * 0.98, 1), "cy": 2, "rx": 5.4, "ry": 8, "fill": hfill, "stroke": INK, "lw": 3.4})
    hs.append({"t": "circle", "cx": 0, "cy": 0, "r": HEAD_R, "fill": hfill, "stroke": INK, "lw": 5})
    hs += _hair(hair, f, None)
    hs += _face(mood, f, (1.6 if look is None else 2.6 * look) * (f if look is None else 1.0), blink)
    if extras:
        hs += _extras(extras, f)
    shapes.append(head)
    shapes += hands
    feet_y = max(leg_feet) if leg_feet else 0.0
    dy = -feet_y if contact else 0.0
    inner = {"t": "group", "x": tx, "y": round(dy, 1), "shapes": shapes}
    top = []
    if shadow:
        sx = round(-light * 16, 1)
        top += [{"t": "ellipse", "cx": sx, "cy": 1.5, "rx": 44, "ry": 9, "fill": "black", "opacity": 0.12},
                {"t": "ellipse", "cx": sx, "cy": 1.5, "rx": 31, "ry": 6, "fill": "black", "opacity": 0.16}]
    top.append(inner)
    g = {"t": "group", "x": x, "y": y, "scale": s, "shapes": top}
    g["_joints"] = {"lh": [round(hand_pts[0][0] + tx, 1), round(hand_pts[0][1] + dy, 1)], "rh": [round(hand_pts[1][0] + tx, 1), round(hand_pts[1][1] + dy, 1)],
                    "head": [round(hc[0] + tx, 1), round(hc[1] + dy, 1)], "feet": [round(tx, 1), 0.0]}
    if act == "walk":
        g["loop"] = "float"
        g["amp"] = 3
    if act == "bounce":
        g["loop"] = "float"
        g["amp"] = 7
    if name:
        shapes.append({"t": "text", "x": 0, "y": 30, "text": name, "size": 24, "kind": "handm", "anchor": "mm", "w": 150, "fill": "bgtext"})
    for k in ("delay", "on", "in", "dur", "out", "out_at", "move", "loop", "amp", "speed", "rot", "opacity"):
        if k in motion:
            g[k] = motion[k]
    return g


def _ease(u):
    u = 0.0 if u < 0 else (1.0 if u > 1 else u)
    return u * u * (3 - 2 * u)

def _overshoot(u):
    u = 0.0 if u < 0 else (1.0 if u > 1 else u)
    c = 1.35
    return 1 + (c + 1) * (u - 1) ** 3 + c * (u - 1) ** 2

def _blend_pose(a, b, u):
    return {k: a[k] + (b[k] - a[k]) * u for k in a}

def _keyed(keys, t, lag, base_pose):
    ks = sorted([k for k in keys if isinstance(k, dict)], key=lambda k: float(k.get("at", 0)))
    tt = t - lag
    cur = dict(POSES.get(ks[0].get("pose", base_pose), POSES["stand"])) if ks else dict(POSES.get(base_pose, POSES["stand"]))
    cur.update(ks[0].get("angles") or {}) if ks else None
    for i in range(1, len(ks)):
        a0 = float(ks[i].get("at", 0))
        dur = float(ks[i].get("dur", 0.45))
        tgt = dict(POSES.get(ks[i].get("pose", "stand"), POSES["stand"]))
        tgt.update(ks[i].get("angles") or {})
        if tt <= a0:
            break
        u = (tt - a0) / max(0.08, dur)
        if u < 1.0:
            ant = float(ks[i].get("anticipate", 0.0))
            e = _overshoot(u) if ks[i].get("overshoot", True) else _ease(u)
            if ant and u < 0.25:
                e = -ant * math.sin(u / 0.25 * math.pi)
            cur = _blend_pose(cur, tgt, e)
            break
        cur = tgt
    return cur

def _mood_at(keys, t, mood):
    out = mood
    for k in sorted([k for k in (keys or []) if isinstance(k, dict)], key=lambda k: float(k.get("at", 0))):
        if t >= float(k.get("at", 0)) and k.get("mood"):
            out = k["mood"]
    return out

def _gait(act, t, speed, base):
    v = 1.0 if act == "walk" else 1.7
    cyc = 1.15 * speed * v
    ph = 2 * math.pi * cyc * t
    amp = 26 if act == "walk" else 46
    kn = 44 if act == "walk" else 78
    s1, s2 = math.sin(ph), math.sin(ph + math.pi)
    c1, c2 = math.cos(ph), math.cos(ph + math.pi)
    base["lh"] = amp * s1
    base["rh"] = amp * s2
    base["lk"] = -kn * max(0.0, c1) - 6
    base["rk"] = -kn * max(0.0, c2) - 6
    arm_amp = 30 if act == "walk" else 62
    base["ls"] = -arm_amp * s1 * 0.9
    base["rs"] = -arm_amp * s2 * 0.9
    base["le"] = 8 + (12 if act == "walk" else 58)
    base["re"] = -(8 + (12 if act == "walk" else 58))
    base["lean"] = 4 + (0 if act == "walk" else 13)
    base["tilt"] = 0.5 * math.sin(ph * 2)
    return base, 1.6 * math.sin(ph)

def animated(args, t, light=0.0):
    a = dict(args)
    keys = a.pop("keys", None)
    act = a.get("act")
    speed = float(a.pop("speed", 1.0) or 1.0)
    pose_name = a.get("pose", "stand")
    base = dict(POSES.get(pose_name, POSES["stand"]))
    hold = {k: float(v) for k, v in (a.get("angles") or {}).items() if k in base}
    base.update(hold)
    if keys:
        body = _keyed(keys, t, 0.0, pose_name)
        arms = _keyed(keys, t, 0.07, pose_name)
        head = _keyed(keys, t, 0.12, pose_name)
        base = dict(body)
        for k in ("ls", "le", "rs", "re"):
            base[k] = arms[k]
        base["tilt"] = head["tilt"]
        a["mood"] = _mood_at(keys, t, a.get("mood", "happy"))
    tx = 0.0
    breath = math.sin(t * 2 * math.pi / 3.3)
    sway = math.sin(t * 2 * math.pi / 5.1)
    idle = act not in ("walk", "run")
    mv = a.get("move") if isinstance(a.get("move"), dict) else None
    until = a.pop("until", None)
    if until is None and mv:
        until = float(mv.get("at", 0) or 0) + float(mv.get("dur", 0.6) or 0.6)
    if act in ("walk", "run"):
        gb, gtx = _gait(act, min(t, until) if until is not None else t, speed, dict(base))
        if until is not None and t > until:
            w = _ease((t - until) / 0.45)
            rest = dict(POSES.get(pose_name if pose_name not in ("walk", "run") else "stand", POSES["stand"]))
            base = _blend_pose(gb, rest, w)
            tx = gtx * (1 - w)
        else:
            base, tx = gb, gtx
        for k in ("ls", "le", "rs", "re"):
            if k in hold:
                base[k] = hold[k] + (1.6 * math.sin(t * 7.0 + len(k)) if act == "run" else 0.0)
    elif act == "talk":
        e = 0.5 + 0.5 * math.sin(t * 2 * math.pi * 0.9)
        base["rs"] = base["rs"] + 26 * e
        base["re"] = base["re"] - 22 * e
        base["tilt"] = base["tilt"] + 3 * math.sin(t * 3.1)
    elif act == "wave":
        base["rs"] = 150 + 6 * math.sin(t * 5)
        base["re"] = 20 + 26 * math.sin(t * 9)
    elif act == "bounce":
        pass
    if idle:
        base["lean"] += 0.9 * breath
        base["tilt"] += 1.2 * sway + 0.5 * breath
        base["ls"] += 1.6 * breath
        base["rs"] -= 1.6 * breath
        tx += 1.2 * sway
    a["angles"] = dict(base)
    a["pose"] = "stand"
    blink = (t % 3.7) < 0.12
    a["blink"] = blink
    look = a.get("look")
    a["look"] = look
    a["tx"] = tx
    a["flut"] = math.sin(t * 4.2) * 0.8 + 0.5 * math.sin(t * 7.3) + (0.8 if act in ("run", "walk") else 0.0)
    a["light"] = light
    a["act"] = None
    return figure(**{k: v for k, v in a.items() if k in _FIG_KEYS})

_FIG_KEYS = ("pose", "mood", "color", "x", "y", "h", "facing", "extras", "hair", "lw", "angles", "name", "act", "outfit", "look", "blink", "contact", "shadow", "light", "tx", "flut",
             "delay", "on", "in", "dur", "out", "out_at", "move", "loop", "amp", "rot", "opacity", "until", "until_on")
