import bisect
import json
import math
import os as _os
import random

from collections import OrderedDict

import numpy as np

from PIL import Image, ImageChops, ImageDraw, ImageFilter

CHAR_DIR = _os.path.normpath(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "..", "..", "assets", "characters", "anupam"))
CANVAS = 768
OFFX = (CANVAS - 512) // 2
SS = 4
WRIST_Y = 446
ELBOW_Y = 402.0
ELBOW_W = 46.0

VIS = {
    "REST": (26.0, 0.0, 0.0),
    "A": (22.0, 12.5, 0.0),
    "E": (26.0, 8.0, 0.0),
    "I": (25.0, 5.0, 0.0),
    "O": (11.0, 12.0, 1.0),
    "U": (8.0, 8.0, 1.0),
    "FV": (21.0, 4.0, 0.0),
    "L": (18.0, 8.5, 0.0),
    "MBP": (22.0, 0.0, 0.0),
    "SZ": (22.0, 3.2, 0.0),
    "CHJ": (14.0, 8.0, 0.6),
}
TEETH = {"A": 0.5, "E": 0.7, "I": 0.8, "FV": 1.0, "SZ": 1.0, "CHJ": 0.5, "L": 0.55}
TONGUE = {"A": 0.8, "O": 0.8, "U": 0.5, "L": 1.0, "E": 0.3, "CHJ": 0.4}


def _bez(p0, p1, p2, n=18):
    return [((1 - t) ** 2 * p0[0] + 2 * (1 - t) * t * p1[0] + t * t * p2[0],
             (1 - t) ** 2 * p0[1] + 2 * (1 - t) * t * p1[1] + t * t * p2[1]) for t in [i / float(n) for i in range(n + 1)]]

def _stroke(d, pts, w, fill, taper=None):
    n = len(pts)
    for i, (x, y) in enumerate(pts):
        r = w / 2.0
        if taper:
            u = i / float(max(1, n - 1))
            r *= taper[0] + (taper[1] - taper[0]) * (1 - abs(2 * u - 1))
        d.ellipse([x - r, y - r, x + r, y + r], fill=fill)
        if i:
            px, py = pts[i - 1]
            d.line([px, py, x, y], fill=fill, width=max(1, int(round(r * 2))))

class PartCharacter:
    name = "anupam"
    is_parts = True

    def __init__(self):
        self.meta = json.load(open(_os.path.join(CHAR_DIR, "meta.json")))
        self.available = _os.path.isfile(_os.path.join(CHAR_DIR, "body.png"))
        self._src = {}
        self._scaled = {}
        self._arm_cache = OrderedDict()
        self._face_cache = OrderedDict()
        self._blinks = None
        self.feet = (OFFX + self.meta["feet_x"], self.meta["feet_y"])
        hp = _os.path.join(CHAR_DIR, "hands", "meta.json")
        self.hand_meta = json.load(open(hp)) if _os.path.exists(hp) else {}
        self._hand_src_cache = {}
        rp = _os.path.join(CHAR_DIR, "reactions", "meta.json")
        self.rx_meta = json.load(open(rp)) if _os.path.exists(rp) else {}
        self._rx_cache = OrderedDict()

    def _part(self, name):
        im = self._src.get(name)
        if im is None:
            im = Image.open(_os.path.join(CHAR_DIR, name + ".png")).convert("RGBA")
            self._src[name] = im
        return im

    def _hand_src(self, name, side):
        key = (name, side)
        im = self._hand_src_cache.get(key)
        if im is None:
            im = Image.open(_os.path.join(CHAR_DIR, "hands", name + ".png")).convert("RGBA")
            if side == "r":
                im = im.transpose(Image.FLIP_LEFT_RIGHT)
            self._hand_src_cache[key] = im
        return im

    def blink_state(self, t):
        if self._blinks is None:
            rnd = random.Random(7)
            tt, out = 1.1, []
            while tt < 3600:
                out.append(tt)
                tt += rnd.uniform(2.3, 4.8)
                if rnd.random() < 0.14:
                    out.append(tt - 1.9 + 0.32)
            self._blinks = sorted(out)
        i = bisect.bisect_right(self._blinks, t) - 1
        if i < 0:
            return 0
        d = t - self._blinks[i]
        if d < 0.05:
            return 1
        if d < 0.12:
            return 2
        if d < 0.17:
            return 1
        return 0

    def _prep(self, k):
        key = round(k, 4)
        hit = self._scaled.get(key)
        if hit is not None:
            return hit
        if len(self._scaled) > 3:
            self._scaled.clear()
            self._arm_cache.clear()
            self._face_cache.clear()

        def sc(im):
            return im.resize((max(1, int(round(im.width * k))), max(1, int(round(im.height * k)))), Image.HAMMING)
        P = {"k": k}
        body = self._part("body")
        P["body"] = sc(body)
        ns = _os.path.join(CHAR_DIR, "body_ns.png")
        P["body_ns"] = sc(self._part("body_ns")) if _os.path.exists(ns) else P["body"]
        head = self._part("head")
        hb = head.getbbox()
        pad = 26
        hb = (max(0, hb[0] - pad), max(0, hb[1] - pad), min(head.width, hb[2] + pad), min(head.height, hb[3] + pad))
        P["head_box"] = hb
        hc = head.crop(hb)
        P["head"] = hc.resize((max(1, int(round(hc.width * k))), max(1, int(round(hc.height * k)))), Image.HAMMING)
        for s in ("l", "r"):
            P["sleeve_" + s] = sc(self._part("sleeve_" + s))
            arm = self._part("arm_" + s)
            m = self.meta["arm_" + s]
            layer = sc(arm)
            top = int(round(m["top"] * k))
            wy = int(round(WRIST_Y * k))
            bot = min(layer.height, wy + int(round(3 * k)))
            x0, x1 = int(round(m["win"][0] * k)), int(round(m["win"][1] * k))
            U = 3
            win = layer.crop((x0, top, x1, bot)).convert("RGBa")
            win = win.resize(((x1 - x0) * U, (bot - top) * U), Image.BICUBIC)
            arr = np.asarray(win).astype(np.float32)
            row = np.asarray(layer.getchannel("A"))[wy - 2]
            xs = np.where(row > 128)[0]
            wx = float((xs.min() + xs.max()) / 2.0)
            rel = layer.crop((x0, wy - int(round(10 * k)), x1, layer.height))
            rel = rel.crop((0, 0, rel.width, int(round((512 - WRIST_Y + 10) * k))))
            hands = {"relaxed": (rel, (wx - x0, 10.0 * k))}
            for hn, hm in self.hand_meta.items():
                him = self._hand_src(hn, s)
                hs = k / 2.0
                him = him.resize((max(1, int(round(him.width * hs))), max(1, int(round(him.height * hs)))), Image.LANCZOS)
                hands[hn] = (him, (hm["anchor"][0] * hs, 5.0 * k))
            P["arm_" + s] = layer
            P["mesh_" + s] = {"arr": arr, "x0": x0, "top": top, "bot": bot, "U": U, "wx": wx, "wy": wy}
            P["hands_" + s] = hands
        self._scaled[key] = P
        return P

    @staticmethod
    def _sm(x, c, w):
        u = np.clip((x - (c - w)) / (2.0 * w), 0.0, 1.0)
        return u * u * (3 - 2 * u)

    def _arm(self, P, side, sh, el, wr, hand="relaxed"):
        k = P["k"]
        sh = max(-25.0, min(155.0, sh))
        el = max(-100.0, min(100.0, el))
        wr = max(-22.0, min(22.0, wr))
        key = (round(k, 4), side, int(round(sh * 1.5)), int(round(el * 1.5)), int(round(wr * 1.5)), hand)
        hit = self._arm_cache.get(key)
        if hit is not None:
            self._arm_cache.move_to_end(key)
            return hit
        sg = 1 if side == "l" else -1
        m = self.meta["arm_" + side]
        size = int(CANVAS * k)
        offx = OFFX * k
        if abs(sh) < 0.3 and abs(el) < 0.3 and abs(wr) < 0.3 and hand == "relaxed":
            out = Image.new("RGBA", (size, size), (0, 0, 0, 0))
            out.alpha_composite(P["arm_" + side], (int(round(offx)), 0))
            self._store(key, out)
            return out
        px, py = m["pivot"][0] * k, m["pivot"][1] * k
        A = P["mesh_" + side]
        arr, U, x0, top, bot = A["arr"], A["U"], A["x0"], A["top"], A["bot"]
        H, W = arr.shape[:2]
        total = float(max(1, int(round(m["bottom"] * k)) - top))
        ec = (ELBOW_Y - m["top"]) / float(m["bottom"] - m["top"])
        ew = ELBOW_W / float(m["bottom"] - m["top"])
        step = 1.0 / U
        rows = (np.arange(H) + 0.5) * step
        frac = np.clip(rows / total, 0.0, 1.0)
        ang = sh + el * self._sm(frac, ec, ew)
        phi = np.radians(sg * ang)
        sn, cs = np.sin(phi), np.cos(phi)
        d0 = top - py
        nx0 = offx + px - sn[0] * d0
        ny0 = py + cs[0] * d0
        cx = nx0 + np.cumsum(-sn * step) - 0.5 * step * (-sn)
        cy = ny0 + np.cumsum(cs * step) - 0.5 * step * cs
        lat = (np.arange(W) + 0.5) * step + x0 - px
        D = 2
        X = (cx[:, None] + lat[None, :] * cs[:, None]) * D
        Y = (cy[:, None] + lat[None, :] * sn[:, None]) * D
        ix = np.floor(X).astype(np.int64).ravel()
        iy = np.floor(Y).astype(np.int64).ravel()
        bx0, bx1 = int(ix.min()) - 2, int(ix.max()) + 3
        by0, by1 = int(iy.min()) - 2, int(iy.max()) + 3
        bx0 -= bx0 % D
        by0 -= by0 % D
        bw = bx1 - bx0 + (-(bx1 - bx0) % D)
        bh = by1 - by0 + (-(by1 - by0) % D)
        flat = (iy - by0) * bw + (ix - bx0)
        cnt = np.bincount(flat, minlength=bw * bh).astype(np.float32)
        chan = []
        for c in range(4):
            chan.append(np.bincount(flat, weights=arr[..., c].ravel(), minlength=bw * bh).astype(np.float32))
        acc = np.stack(chan, axis=-1).reshape(bh, bw, 4)
        cnt = cnt.reshape(bh, bw)
        for _ in range(2):
            hole = cnt == 0
            if not hole.any():
                break
            pa = np.pad(acc, ((1, 1), (1, 1), (0, 0)))
            pc = np.pad(cnt, 1)
            sa = sum(pa[1 + dy:1 + dy + bh, 1 + dx:1 + dx + bw] for dy in (-1, 0, 1) for dx in (-1, 0, 1))
            sc_ = sum(pc[1 + dy:1 + dy + bh, 1 + dx:1 + dx + bw] for dy in (-1, 0, 1) for dx in (-1, 0, 1))
            fill = hole & (sc_ >= 3)
            acc = np.where(fill[..., None], sa / np.maximum(sc_, 1)[..., None], acc)
            cnt = np.where(fill, 1.0, cnt)
        avg = acc / np.maximum(cnt, 1.0)[..., None]
        avg = avg.reshape(bh // D, D, bw // D, D, 4).mean(axis=(1, 3))
        al = avg[..., 3:4]
        rgb = np.where(al > 0.5, avg[..., :3] * 255.0 / np.maximum(al, 1.0), 0.0)
        piece = Image.fromarray(np.clip(np.concatenate([rgb, al], axis=2), 0, 255).astype(np.uint8), "RGBA")
        out = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        self._paste_at(out, piece, bx0 // D, by0 // D)
        jw = int(min(H - 1, max(0, (A["wy"] - top) * U)))
        latw = A["wx"] - px
        wxp = cx[jw] + latw * cs[jw]
        wyp = cy[jw] + latw * sn[jw]
        him, (ax, ay) = P["hands_" + side].get(hand, P["hands_" + side]["relaxed"])
        phd = sg * (float(ang[jw]) + wr)
        pr = math.radians(phd)
        sp, cp = math.sin(pr), math.cos(pr)
        lx, ly = him.width / 2.0 - ax, him.height / 2.0 - ay
        self._put_strip(out, him, phd, wxp + lx * cp - ly * sp, wyp + lx * sp + ly * cp)
        self._store(key, out)
        return out

    @staticmethod
    def _put_strip(out, im, phi_deg, cx, cy):
        w, h = im.size
        a = math.radians(phi_deg)
        ca, sa = math.cos(a), math.sin(a)
        bw = int(abs(w * ca) + abs(h * sa)) + 3
        bh = int(abs(w * sa) + abs(h * ca)) + 3
        x0 = int(math.floor(cx - bw / 2.0))
        y0 = int(math.floor(cy - bh / 2.0))
        pcx, pcy = cx - x0, cy - y0
        c0 = w / 2.0 - (ca * pcx + sa * pcy)
        c1 = h / 2.0 - (-sa * pcx + ca * pcy)
        patch = im.convert("RGBa").transform((bw, bh), Image.AFFINE, (ca, sa, c0, -sa, ca, c1), resample=Image.BICUBIC).convert("RGBA")
        PartCharacter._paste_at(out, patch, x0, y0)

    @staticmethod
    def _paste_at(out, im, x, y):
        sx, sy = max(0, -x), max(0, -y)
        ex, ey = min(im.width, out.width - x), min(im.height, out.height - y)
        if ex <= sx or ey <= sy:
            return
        out.alpha_composite(im.crop((sx, sy, ex, ey)), (x + sx, y + sy))

    @staticmethod
    def _paste_clip(out, im, cx, cy):
        x = int(round(cx - im.width / 2.0))
        y = int(round(cy - im.height / 2.0))
        sx = max(0, -x)
        sy = max(0, -y)
        ex = min(im.width, out.width - x)
        ey = min(im.height, out.height - y)
        if ex <= sx or ey <= sy:
            return
        out.alpha_composite(im.crop((sx, sy, ex, ey)), (x + sx, y + sy))

    def _sleeve(self, P, side, sh):
        k = P["k"]
        psi = max(0.0, min(34.0, 0.3 * sh))
        if psi < 0.4:
            return P["sleeve_" + side]
        key = ("sl", round(k, 4), side, int(round(psi * 2)))
        hit = self._arm_cache.get(key)
        if hit is not None:
            self._arm_cache.move_to_end(key)
            return hit
        sg = 1 if side == "l" else -1
        m = self.meta["arm_" + side]
        px, py = m["sleeve_pivot"][0] * k, m["sleeve_pivot"][1] * k
        base = P["sleeve_" + side]
        pad = int(60 * k)
        big = Image.new("RGBA", (base.width + 2 * pad, base.height + 2 * pad), (0, 0, 0, 0))
        big.paste(base, (pad, pad))
        rot = big.rotate(-sg * psi, resample=Image.BICUBIC, center=(px + pad, py + pad))
        out = rot.crop((pad, pad, pad + base.width, pad + base.height))
        self._store(key, out)
        return out

    def _store(self, key, im):
        self._arm_cache[key] = im
        if len(self._arm_cache) > 160:
            self._arm_cache.popitem(last=False)

    def _face(self, P, f):
        k = P["k"]
        key = (round(k, 4), f["mouth"], f["blink"], f["look"], f["eyes"], f["shape"], f["brow"], f["smile"], f["blush"])
        hit = self._face_cache.get(key)
        if hit is not None:
            self._face_cache.move_to_end(key)
            return hit
        fc = self.meta["face"]
        ink = tuple(fc["ink"])
        s = k * SS
        bx0, by0, bx1, by1 = P["head_box"]
        X0, Y0, X1, Y1 = 196, 126, 328, 224
        w, h = int((X1 - X0) * s), int((Y1 - Y0) * s)
        lay = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        d = ImageDraw.Draw(lay)

        def T(x, y):
            return ((x - X0) * s, (y - Y0) * s)
        lx, ly = f["look"]
        eyes = f["eyes"]
        blink = f["blink"]
        o = {0: 1.0, 1: 0.45, 2: 0.0}[blink] * eyes
        shape = f["shape"]
        for key_e, outer in (("eye_l", -1), ("eye_r", 1)):
            cx, cy = fc[key_e]
            rx, ry = fc["eye_rx"], fc["eye_ry"]
            if shape == "happy":
                pts = _bez(T(cx - rx * 0.95, cy + ry * 0.45), T(cx, cy - ry * 1.05), T(cx + rx * 0.95, cy + ry * 0.45))
                _stroke(d, pts, 4.8 * s, ink)
            elif shape == "squint":
                self._eye(lay, d, T, s, cx, cy, rx, ry * 0.5, 1.0, outer, fc, lx * 0.6, 0.0, 0.9)
            elif o < 0.14:
                pts = _bez(T(cx - rx * 1.0, cy + ry * 0.22), T(cx, cy + ry * 0.72), T(cx + rx * 1.0, cy + ry * 0.22))
                _stroke(d, pts, 4.2 * s, ink)
                wing = [T(cx + outer * rx * 0.95, cy + ry * 0.26), T(cx + outer * rx * 1.22, cy - ry * 0.05)]
                _stroke(d, wing, 3.0 * s, ink)
            else:
                self._eye(lay, d, T, s, cx, cy, rx, ry, o, outer, fc, lx, ly, 1.06 if eyes > 1.05 else 1.0)
        by, tilt, inn = f["brow"]
        for key_b, sgn in (("brow_l", -1), ("brow_r", 1)):
            p0, pm, p1 = [list(p) for p in fc[key_b]]
            cx = (p0[0] + p1[0]) / 2.0
            cy = (p0[1] + p1[1]) / 2.0
            c2 = (2 * pm[0] - (p0[0] + p1[0]) / 2.0, 2 * pm[1] - (p0[1] + p1[1]) / 2.0)
            pts3 = []
            for (x, y) in (p0, c2, p1):
                dx, dy = x - cx, y - cy
                a = math.radians(tilt * -sgn)
                rx_ = dx * math.cos(a) - dy * math.sin(a)
                ry_ = dx * math.sin(a) + dy * math.cos(a)
                pts3.append((cx + rx_, cy + ry_ + by))
            inner = 2 if sgn == -1 else 0
            pts3[inner] = (pts3[inner][0], pts3[inner][1] + inn)
            pts = _bez(T(*pts3[0]), T(*pts3[1]), T(*pts3[2]))
            _stroke(d, pts, 8.2 * s, ink, taper=(0.45, 1.0))
        self._mouth(lay, d, T, f["mouth"], f["smile"], s, fc)
        lay = lay.resize((max(1, int(round((X1 - X0) * k))), max(1, int(round((Y1 - Y0) * k)))), Image.LANCZOS)
        res = (lay, X0, Y0)
        self._face_cache[key] = res
        if len(self._face_cache) > 260:
            self._face_cache.popitem(last=False)
        return res

    def _eye(self, lay, d, T, s, cx, cy, rx, ry, o, outer, fc, lx, ly, wide):
        ink = tuple(fc["ink"])
        rx = rx * wide
        ryo = ry * (0.4 + 0.6 * o)
        ccy = cy + ry * (1 - o) * 0.4
        w, h = lay.size
        n = 36
        pts = []
        for i in range(n):
            t = 2 * math.pi * i / n
            ct, st = math.cos(t), math.sin(t)
            x = rx * (abs(ct) ** 0.8) * (1 if ct >= 0 else -1)
            y = ryo * (abs(st) ** 0.9) * (1 if st >= 0 else -1)
            y += (0.22 * ryo * (x / rx) * outer * -1) if rx else 0.0
            pts.append(T(cx + x, ccy + y))
        mask = Image.new("L", (w, h), 0)
        ImageDraw.Draw(mask).polygon(pts, fill=255)
        base = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        bd = ImageDraw.Draw(base)
        bd.polygon(pts, fill=(250, 248, 246, 255))
        ir = fc.get("iris", 9.0) * (0.55 + 0.45 * o)
        icx = cx + lx * 3.2 - outer * 0.0
        icy = ccy + ly * 2.0 + 0.4
        ic = T(icx, icy)
        ico = tuple(fc.get("iris_col", [74, 52, 46])) + (255,)
        ry_i = ir * (1.08 if o > 0.9 else 1.0)
        bd.ellipse([ic[0] - ir * s, ic[1] - ry_i * s, ic[0] + ir * s, ic[1] + ry_i * s], fill=ico)
        pr = ir * 0.58
        bd.ellipse([ic[0] - pr * s, ic[1] - pr * 1.05 * s, ic[0] + pr * s, ic[1] + pr * 1.05 * s], fill=(26, 18, 18, 255))
        hr = ir * 0.3
        hx, hy = ic[0] - ir * 0.32 * s, ic[1] - ir * 0.36 * s
        bd.ellipse([hx - hr * s, hy - hr * s, hx + hr * s, hy + hr * s], fill=(255, 255, 255, 255))
        hr2 = ir * 0.14
        hx2, hy2 = ic[0] + ir * 0.34 * s, ic[1] + ir * 0.3 * s
        bd.ellipse([hx2 - hr2 * s, hy2 - hr2 * s, hx2 + hr2 * s, hy2 + hr2 * s], fill=(255, 255, 255, 235))
        shade = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        sd = ImageDraw.Draw(shade)
        top = [T(cx + rx * (u / 10.0 * 2 - 1) * 1.0, ccy - ryo * 0.95 * (1 - (u / 10.0 * 2 - 1) ** 2) ** 0.5) for u in range(11)]
        sd.polygon(top + [T(cx + rx, ccy - ryo * 0.2), T(cx - rx, ccy - ryo * 0.2)], fill=(120, 110, 112, 110))
        base.alpha_composite(shade)
        lay.paste(base, (0, 0), mask)
        lid = [T(cx + rx * (u / 14.0 * 2 - 1), ccy - ryo * 1.02 * (1 - (u / 14.0 * 2 - 1) ** 2) ** 0.5 + 0.22 * ryo * (u / 14.0 * 2 - 1) * -outer * -1) for u in range(15)]
        if outer < 0:
            lid = lid[::-1]
        _stroke(d, lid, 4.8 * s, ink, taper=(0.55, 1.0))
        ex = T(cx + outer * rx * 1.2, ccy - ryo * 0.42)
        _stroke(d, [lid[-1], ex], 2.4 * s, ink)
        low = [T(cx + rx * (u / 8.0 * 2 - 1) * 0.92, ccy + ryo * 0.96 * (1 - (u / 8.0 * 2 - 1) ** 2) ** 0.5) for u in range(9)]
        _stroke(d, low, 1.3 * s, (150, 100, 88, 200))

    def _mouth(self, lay, d, T, mouth, smile, s, fc):
        ink = tuple(fc.get("mink", fc["ink"]))
        a, b, wgt, f = mouth
        wa, ha, ra = VIS.get(a, VIS["REST"])
        wb, hb, rb = VIS.get(b, VIS["REST"])
        w = wa + (wb - wa) * wgt
        h = ha + (hb - ha) * wgt
        rr = ra + (rb - ra) * wgt
        tl = TEETH.get(a, 0) * (1 - wgt) + TEETH.get(b, 0) * wgt
        tg = TONGUE.get(a, 0) * (1 - wgt) + TONGUE.get(b, 0) * wgt
        rw = VIS["REST"][0]
        w = rw + (w - rw) * f
        h = h * f
        cx, cy = fc["mouth"]
        sm = 3.8 + smile
        half = w / 2.0
        if h < 1.4:
            k = sm / 3.8
            pts = _bez(T(cx - half, cy - 3.0 * k), T(cx, cy + 3.4 + sm * 0.2), T(cx + half, cy - 4.0 * k), 20)
            _stroke(d, pts, 3.0 * s, ink, taper=(0.75, 1.0))
            return
        top = h * 0.34
        bot = h * 0.66
        n = 40
        poly = []
        for i in range(n):
            t = 2 * math.pi * i / n
            ct, st = math.cos(t), math.sin(t)
            e = 1.0 - 0.28 * (1 - rr)
            x = half * (abs(ct) ** e) * (1 if ct >= 0 else -1)
            u = x / half if half else 0.0
            y = (-top if st < 0 else bot) * (abs(st) ** (1.0 if rr > 0.5 else 0.85))
            y = y - sm * 0.55 * (u * u) * (1 - rr * 0.6) + sm * 0.2
            poly.append(T(cx + x, cy + y))
        clip = Image.new("L", lay.size, 0)
        ImageDraw.Draw(clip).polygon(poly, fill=255)
        fillimg = Image.new("RGBA", lay.size, (72, 24, 30, 255))
        miny = min(p[1] for p in poly)
        maxy = max(p[1] for p in poly)
        minx = min(p[0] for p in poly)
        maxx = max(p[0] for p in poly)
        if tg > 0.05:
            tw = (maxx - minx) * 0.6
            tm = Image.new("L", lay.size, 0)
            tc = (minx + maxx) / 2.0
            ImageDraw.Draw(tm).ellipse([tc - tw / 2, maxy - (maxy - miny) * (0.5 * tg + 0.1), tc + tw / 2, maxy + (maxy - miny) * 0.5], fill=255)
            fillimg.paste((214, 96, 104, 255), (0, 0), tm)
        if tl > 0.05:
            tm = Image.new("L", lay.size, 0)
            ImageDraw.Draw(tm).rectangle([minx, miny - 2 * s, maxx, miny + (maxy - miny) * 0.38 * tl + 1.0 * s], fill=255)
            fillimg.paste((250, 246, 240, 255), (0, 0), tm)
        lay.paste(fillimg, (0, 0), clip)
        pts = poly + [poly[0]]
        _stroke(d, pts, 2.5 * s, ink)

    def _rx_sprite(self, name, k):
        key = (name, round(k, 4))
        hit = self._rx_cache.get(key)
        if hit is not None:
            return hit
        if len(self._rx_cache) > 12:
            self._rx_cache.clear()
        im = Image.open(_os.path.join(CHAR_DIR, "reactions", name + ".png")).convert("RGBA")
        s = k * 512.0 / im.width
        im = im.resize((int(round(im.width * s)), int(round(im.height * s))), Image.LANCZOS)
        self._rx_cache[key] = im
        return im

    def _rx_clean(self, name, k):
        key = ("m", name, round(k, 4))
        hit = self._rx_cache.get(key)
        if hit is not None:
            return hit
        m = self.rx_meta[name]
        x0, y0, x1, y1 = m["box"]
        im = Image.open(_os.path.join(CHAR_DIR, "reactions", name + "_m.png")).convert("RGBA")
        bx = (int(round(x0 * k)), int(round(y0 * k)))
        im = im.resize((max(1, int(round((x1 - x0) * k))), max(1, int(round((y1 - y0) * k)))), Image.LANCZOS)
        self._rx_cache[key] = (im, bx)
        return im, bx

    @staticmethod
    def _mouth_vec(st):
        a, b, u, f = st
        va, vb = VIS.get(a, VIS["REST"]), VIS.get(b, VIS["REST"])
        u = max(0.0, min(1.0, u))
        f = max(0.0, min(1.0, f))
        w = (va[0] + (vb[0] - va[0]) * u) / 26.0
        o = (va[1] + (vb[1] - va[1]) * u) * f / 12.5
        r = va[2] + (vb[2] - va[2]) * u
        te = TEETH.get(a, 0.0) * (1 - u) + TEETH.get(b, 0.0) * u
        tn = TONGUE.get(a, 0.0) * (1 - u) + TONGUE.get(b, 0.0) * u
        return (w, o, r, te, tn, f)

    def _rx_mouth(self, im, name, pose, k):
        m = self.rx_meta[name]
        sts = pose.get("mouth_s")
        if not sts:
            mo = pose.get("mouth")
            sts = (mo if isinstance(mo, tuple) else ("REST", "REST", 0.0, 0.0),)
        wts = (0.25, 0.5, 0.25) if len(sts) == 3 else (1.0,)
        vec = [0.0] * 6
        for st, wt in zip(sts, wts):
            for n_, v in enumerate(self._mouth_vec(st)):
                vec[n_] += v * wt
        wd, o, rnd, te, tn, f = vec
        rc, ro, rt = m["rest"]
        s = min(1.0, f / 0.3)
        s = s * s * (3 - 2 * s)
        o = min(m.get("omax", 1.2), ro + (o - ro) * s)
        wd = 1.0 + (wd - 1.0) * s
        rnd = rnd * s
        te = max(te, rt * (1.0 - s)) if o > 0.1 else te
        if ro > 0.1 and o > 0.1:
            te = max(te, rt * 0.7)
        tn = tn * s + (0.6 if ro > 0.1 else 0.0) * (1.0 - s)
        clean, (bx, by) = self._rx_clean(name, k)
        cx, cy = m["mouth"][0] * k - bx, m["mouth"][1] * k - by
        S = 4
        W, H = clean.size
        lay = clean.copy()
        big = Image.new("RGBA", (W * S, H * S), (0, 0, 0, 0))
        d = ImageDraw.Draw(big)
        hw = m["hw"] * k * S * 0.86 * max(0.35, min(1.0, wd)) * (1.0 - 0.5 * min(1.0, rnd))
        depth = m["hw"] * k * S * 0.95 * (0.45 + 0.55 * min(1.0, wd / 0.85))
        ex = 0.75 - 0.3 * min(1.0, rnd)
        n = 32
        curve = rc
        top, bot = [], []
        for i in range(n + 1):
            x = -1.0 + 2.0 * i / n
            q = 1.0 - x * x
            yt = cy * S + curve * hw * 0.3 * q
            yb = yt + max(0.0, o) * depth * q ** ex
            top.append((cx * S + x * hw, yt))
            bot.append((cx * S + x * hw, yb))
        ink = (68, 30, 32, 255)
        lw = max(2, int(S * (0.9 + 0.35 * k)))
        if o > 0.06:
            d.polygon(top + bot[::-1], fill=(116, 42, 48, 255))
            span = max(b_[1] - t_[1] for t_, b_ in zip(top, bot))
            if tn > 0.2 and span > 6 * S * k * 0.5:
                d.ellipse([cx * S - hw * 0.46, cy * S + curve * hw * 0.3 + span * 0.42, cx * S + hw * 0.46, cy * S + curve * hw * 0.3 + span * 1.05], fill=(224, 114, 108, 255))
            if te > 0.2:
                th = span * 0.36 * min(1.0, te)
                d.polygon(top + [(x, y + th * max(0.0, 1.0 - ((x - cx * S) / hw) ** 2) ** 0.6) for (x, y) in top[::-1]], fill=(252, 250, 247, 255))
            mk = Image.new("L", big.size, 0)
            ImageDraw.Draw(mk).polygon(top + bot[::-1], fill=255)
            ov = Image.new("RGBA", big.size, (0, 0, 0, 0))
            ov.paste(big, (0, 0), mk)
            big = ov
            d = ImageDraw.Draw(big)
        d.line(top, fill=ink, width=lw, joint="curve")
        if o > 0.06:
            d.line(bot, fill=ink, width=lw, joint="curve")
        big = big.resize((W, H), Image.LANCZOS)
        ang = -m["tilt"]
        if abs(ang) > 0.1:
            big = big.rotate(ang, resample=Image.BICUBIC, center=(cx, cy))
        lay.alpha_composite(big)
        sm = Image.new("L", (W, H), 0)
        ImageDraw.Draw(sm).ellipse([W * 0.06, H * 0.06, W * 0.94, H * 0.94], fill=255)
        sm = sm.filter(ImageFilter.GaussianBlur(max(1.0, min(W, H) * 0.12)))
        im.paste(lay, (bx, by), sm)

    def _rx_pose(self, name, k, pose):
        m = self.rx_meta[name]
        im = self._rx_sprite(name, k).copy()
        self._rx_mouth(im, name, pose, k)
        return im

    def _xform(self, canvas, k, pose):
        rot_b = pose.get("rot", 0.0)
        sy = pose.get("sy", 1.0)
        sxx = pose.get("sx", 1.0)
        ty = k * (0.7 * pose.get("dy", 0.0) + 0.6 * pose.get("head_dy", 0.0)) if pose.get("pa") else 0.0
        if abs(rot_b) > 0.03 or abs(sy - 1) > 0.002 or abs(sxx - 1) > 0.002 or abs(ty) > 0.05:
            fx, fy = self.feet[0] * k, self.feet[1] * k
            a = math.radians(rot_b)
            ca, sa = math.cos(a), math.sin(a)
            m00, m01, m10, m11 = ca / sxx, sa / sy, -sa / sxx, ca / sy
            c0 = fx - (m00 * fx + m01 * fy)
            c1 = fy - (m10 * fx + m11 * fy) - ty
            if pose.get("pa"):
                x0 = max(0, int(OFFX * k) - int(0.12 * 512 * k))
                x1 = min(canvas.width, int((OFFX + 512) * k) + int(0.12 * 512 * k))
                part = canvas.crop((x0, 0, x1, canvas.height)).convert("RGBa")
                part = part.transform(part.size, Image.AFFINE, (m00, m01, c0 + (m00 - 1.0) * x0, m10, m11, c1 + m10 * x0), resample=Image.BILINEAR).convert("RGBA")
                out = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
                out.paste(part, (x0, 0))
                return out
            canvas = canvas.convert("RGBa").transform(canvas.size, Image.AFFINE, (m00, m01, c0, m10, m11, c1), resample=Image.BICUBIC).convert("RGBA")
        return canvas

    def _draw_reaction(self, k, pose):
        size = int(CANVAS * k)
        offx = int(round(OFFX * k))
        pa = pose.get("pa", "front")
        if pa not in self.rx_meta:
            pa = "front"
        a = self._rx_pose(pa, k, pose)
        pb = pose.get("pb")
        pw = float(pose.get("pw", 0.0))
        if pb and pb in self.rx_meta and pb != pa and pw > 0.01:
            b = self._rx_pose(pb, k, pose)
            w = pw * pw * (3 - 2 * pw)
            a = Image.blend(a.convert("RGBa"), b.convert("RGBa"), w).convert("RGBA")
        canvas = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        canvas.alpha_composite(a, (offx, 0)) if offx + a.width <= size else canvas.paste(a.crop((0, 0, size - offx, a.height)), (offx, 0))
        return self._xform(canvas, k, pose)

    def draw(self, k, pose):
        if self.rx_meta and pose.get("pa"):
            return self._draw_reaction(k, pose)
        P = self._prep(k)
        size = int(CANVAS * k)
        canvas = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        offx = int(round(OFFX * k))
        arms = {}
        for side, key in (("l", "armL"), ("r", "armR")):
            sh, el, wr, front = pose.get(key, (0, 0, 0, 0))
            arms[side] = (self._arm(P, side, sh, el, wr, pose.get("hand" + side.upper(), "relaxed")), front)
        sl = {}
        for side, key in (("l", "armL"), ("r", "armR")):
            sl[side] = self._sleeve(P, side, pose.get(key, (0, 0, 0, 0))[0])
        for side in ("l", "r"):
            if not arms[side][1]:
                canvas.alpha_composite(arms[side][0])
                canvas.alpha_composite(sl[side], (offx, 0))
        canvas.alpha_composite(P["body"], (offx, 0))
        for side in ("l", "r"):
            if arms[side][1]:
                canvas.alpha_composite(arms[side][0])
                canvas.alpha_composite(sl[side], (offx, 0))
        hb = P["head_box"]
        head = P["head"].copy()
        f = {
            "mouth": self._qmouth(pose.get("mouth")),
            "blink": int(pose.get("blink", 0)),
            "look": (round(pose.get("look", (0, 0))[0], 1), round(pose.get("look", (0, 0))[1], 1)),
            "eyes": round(pose.get("eyes", 1.0), 2),
            "shape": pose.get("shape", "round"),
            "brow": (round(pose.get("brow_y", 0.0), 1), round(pose.get("brow_tilt", 0.0), 1), round(pose.get("brow_in", 0.0), 1)),
            "smile": round(pose.get("smile", 0.0), 1),
            "blush": 0,
        }
        fl, fx0, fy0 = self._face(P, f)
        head.alpha_composite(fl, (int(round((fx0 - hb[0]) * k)), int(round((fy0 - hb[1]) * k))))
        pvx, pvy = self.meta["head_pivot"]
        pv = ((pvx - hb[0]) * k, (pvy - hb[1]) * k)
        rot = pose.get("head_rot", 0.0)
        hd = head.convert("RGBa").rotate(rot, resample=Image.BICUBIC, center=pv).convert("RGBA") if abs(rot) > 0.05 else head
        hx = offx + hb[0] * k + pose.get("head_dx", 0.0) * k
        hy = hb[1] * k + pose.get("head_dy", 0.0) * k
        self._paste_clip(canvas, hd, hx + hd.width / 2.0, hy + hd.height / 2.0)
        rot_b = pose.get("rot", 0.0)
        sy = pose.get("sy", 1.0)
        sxx = pose.get("sx", 1.0)
        if abs(rot_b) > 0.03 or abs(sy - 1) > 0.002 or abs(sxx - 1) > 0.002:
            fx, fy = self.feet[0] * k, self.feet[1] * k
            a = math.radians(rot_b)
            ca, sa = math.cos(a), math.sin(a)
            m00, m01, m10, m11 = ca / sxx, sa / sy, -sa / sxx, ca / sy
            c0 = fx - (m00 * fx + m01 * fy)
            c1 = fy - (m10 * fx + m11 * fy)
            canvas = canvas.convert("RGBa").transform(canvas.size, Image.AFFINE, (m00, m01, c0, m10, m11, c1), resample=Image.BICUBIC).convert("RGBA")
        return canvas

    def portrait(self, size, pose=None):
        k = 1.0
        im = self.draw(k, dict(pose or {"shape": "happy", "smile": 2.5}))
        hb = self._part("head").getbbox()
        cx = OFFX + (hb[0] + hb[2]) / 2.0
        cy = (hb[1] + hb[3]) / 2.0 + 6
        half = max(hb[2] - hb[0], hb[3] - hb[1]) / 2.0 + 6
        box = (int(cx - half), int(cy - half), int(cx + half), int(cy + half))
        return im.crop(box).resize((size, size), Image.LANCZOS)

    @staticmethod
    def _qmouth(m):
        if not isinstance(m, tuple):
            return ("REST", "REST", 0.0, 0.0)
        a, b, w, f = m
        w = round(max(0.0, min(1.0, w)) * 6) / 6.0
        f = round(max(0.0, min(1.0, f)) * 8) / 8.0
        if w == 0:
            b = a
        return (a, b, w, f)

def make_character():
    c = PartCharacter()
    if not c.available:
        raise RuntimeError("character parts missing in %s - run scripts/build_character_assets.py" % CHAR_DIR)
    return c
