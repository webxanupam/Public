"""draw.py - the live vector drawing element.

Nothing here is a template: the agent describes the picture for each scene as shapes, paths and text, and this
module draws and animates them frame by frame. Animations can be tied to spoken words.

Element:  {"type": "draw", "size": [W, H], "shapes": [ ... ]}   (shape coordinates live in a W x H space)

Shape (all keys optional except `t`):
  t        rect | circle | ellipse | line | poly | path | arc | text | group
  fill     colour: orange purple green pink yellow blue red teal brown sky cream gold lime navy skin black ink white grey
           (true colours), accent accent2 accent3 accent4 tint shade bg bgtext (this video's generated theme) or "#rrggbb"
  stroke   colour;  lw  stroke width;  shadow  true -> hard ink offset shadow;  opacity 0..1
  rect     x y w h r            circle  cx cy r            ellipse  cx cy rx ry
  line     pts [[x,y],...]      poly    pts (closed)       arc      cx cy r a0 a1 (degrees)
  path     d "M x y L x y C x1 y1 x2 y2 x y Q x1 y1 x y Z" (absolute or relative letters)
  text     x y text size kind(sans|sansm|hand|mono) anchor(mm|lm|rm|la..) w(max width, shrinks to fit)
  group    x y rot scale shapes [ ... ]   (children are drawn relative to x,y)
  rot (deg) / scale / pivot [x,y]   transform a shape about its centre or `pivot`
  delay    seconds after the element appears        on  word index or word text: start when it is spoken
  in       pop | fade | rise | left | right | grow | draw | type | none      dur  seconds (default 0.45)
  out      fade | pop  with `out_at` (seconds after the element appears)
  loop     float | pulse | spin | wobble | blink | orbit      amp  speed  around [x,y] (orbit centre)
  move     {"by": [dx, dy], "at": seconds, "dur": seconds}   slide the shape
"""
import math
import re

from PIL import Image

from .cards import El, KEY_FPS
from .compact import parse_shape
from .fx import blit, halo, persp_coeffs, project, np
from . import components, stickman

_STICK_KEYS = ("pose", "mood", "color", "x", "y", "h", "facing", "extras", "hair", "lw", "angles", "name", "act", "outfit", "look")
_DYN_ACTS = ("walk", "run", "talk", "wave", "idle", "bounce")
def np_available():
    return np is not None


_TEXT_CACHE = {}
_MOTION_KEYS = ("delay", "on", "in", "dur", "out", "out_at", "move", "loop", "amp", "speed", "rot", "opacity")
from .gfx import (THEME, mix, ease_out_bounce, BLUE, GREEN, GREY, INK, ORANGE, PINK, PURPLE, WHITE, YELLOW, Canvas, clamp, color, ease_in_out,
                  ease_out_back, ease_out_cubic, fit_lines, measure)

IN_DEFAULT_DUR = 0.45
_NUM = re.compile(r"[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?")
_CMD = re.compile(r"[MmLlHhVvCcSsQqTtZz]")

def _unscale_move(args):
    mv = args.get("move")
    if not isinstance(mv, dict):
        return args
    s = max(0.05, _num(args.get("h"), stickman.H) / float(stickman.H))
    mv = dict(mv)
    if isinstance(mv.get("by"), (list, tuple)) and len(mv["by"]) >= 2:
        mv["by"] = [_num(mv["by"][0]) / s, _num(mv["by"][1]) / s]
    if mv.get("arc"):
        mv["arc"] = _num(mv["arc"]) / s
    return dict(args, move=mv)

def _num(v, d=0.0):
    try:
        return float(v)
    except Exception:
        return d

def _bez3(p0, p1, p2, p3, n=18):
    out = []
    for i in range(1, n + 1):
        t = i / float(n)
        u = 1 - t
        out.append((u ** 3 * p0[0] + 3 * u * u * t * p1[0] + 3 * u * t * t * p2[0] + t ** 3 * p3[0],
                    u ** 3 * p0[1] + 3 * u * u * t * p1[1] + 3 * u * t * t * p2[1] + t ** 3 * p3[1]))
    return out

def _bez2(p0, p1, p2, n=14):
    out = []
    for i in range(1, n + 1):
        t = i / float(n)
        u = 1 - t
        out.append((u * u * p0[0] + 2 * u * t * p1[0] + t * t * p2[0], u * u * p0[1] + 2 * u * t * p1[1] + t * t * p2[1]))
    return out

def parse_path(d):
    """SVG path subset -> list of (points, closed)."""
    toks = []
    for m in re.finditer(r"[MmLlHhVvCcSsQqTtZz]|[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?", d or ""):
        toks.append(m.group(0))
    subs, cur, closed = [], [], False
    x = y = sx = sy = 0.0
    cmd = None
    last_c = None
    i = 0

    def take(n):
        nonlocal i
        vals = []
        for _ in range(n):
            if i >= len(toks) or _CMD.fullmatch(toks[i]):
                return None
            vals.append(float(toks[i]))
            i += 1
        return vals
    while i < len(toks):
        if _CMD.fullmatch(toks[i]):
            cmd = toks[i]
            i += 1
            if cmd in "Zz":
                if cur:
                    subs.append((cur, True))
                    cur = []
                x, y = sx, sy
                last_c = None
                continue
        if cmd is None:
            break
        rel = cmd.islower()
        c = cmd.upper()
        if c == "M":
            v = take(2)
            if v is None:
                break
            if cur:
                subs.append((cur, False))
            x, y = (x + v[0], y + v[1]) if rel else (v[0], v[1])
            sx, sy = x, y
            cur = [(x, y)]
            cmd = "l" if rel else "L"
            last_c = None
        elif c == "L":
            v = take(2)
            if v is None:
                break
            x, y = (x + v[0], y + v[1]) if rel else (v[0], v[1])
            cur.append((x, y))
            last_c = None
        elif c == "H":
            v = take(1)
            if v is None:
                break
            x = x + v[0] if rel else v[0]
            cur.append((x, y))
            last_c = None
        elif c == "V":
            v = take(1)
            if v is None:
                break
            y = y + v[0] if rel else v[0]
            cur.append((x, y))
            last_c = None
        elif c == "C":
            v = take(6)
            if v is None:
                break
            p1 = (x + v[0], y + v[1]) if rel else (v[0], v[1])
            p2 = (x + v[2], y + v[3]) if rel else (v[2], v[3])
            p3 = (x + v[4], y + v[5]) if rel else (v[4], v[5])
            cur.extend(_bez3((x, y), p1, p2, p3))
            x, y = p3
            last_c = p2
        elif c == "S":
            v = take(4)
            if v is None:
                break
            p1 = (2 * x - last_c[0], 2 * y - last_c[1]) if last_c else (x, y)
            p2 = (x + v[0], y + v[1]) if rel else (v[0], v[1])
            p3 = (x + v[2], y + v[3]) if rel else (v[2], v[3])
            cur.extend(_bez3((x, y), p1, p2, p3))
            x, y = p3
            last_c = p2
        elif c == "Q":
            v = take(4)
            if v is None:
                break
            p1 = (x + v[0], y + v[1]) if rel else (v[0], v[1])
            p2 = (x + v[2], y + v[3]) if rel else (v[2], v[3])
            cur.extend(_bez2((x, y), p1, p2))
            x, y = p2
            last_c = None
        elif c == "T":
            v = take(2)
            if v is None:
                break
            p2 = (x + v[0], y + v[1]) if rel else (v[0], v[1])
            cur.extend(_bez2((x, y), (x, y), p2))
            x, y = p2
            last_c = None
        else:
            break
    if cur:
        subs.append((cur, False))
    return subs

def _ellipse_pts(cx, cy, rx, ry, n=None):
    n = n or max(28, int(max(rx, ry) * 1.2))
    n = min(n, 120)
    return [(cx + math.cos(2 * math.pi * i / n) * rx, cy + math.sin(2 * math.pi * i / n) * ry) for i in range(n)]

def _rrect_pts(x, y, w, h, r):
    r = max(0.0, min(r, w / 2.0, h / 2.0))
    if r < 0.5:
        return [(x, y), (x + w, y), (x + w, y + h), (x, y + h)]
    pts = []
    for (ccx, ccy, a0) in ((x + w - r, y + r, -90), (x + w - r, y + h - r, 0), (x + r, y + h - r, 90), (x + r, y + r, 180)):
        for i in range(9):
            a = math.radians(a0 + 90 * i / 8.0)
            pts.append((ccx + math.cos(a) * r, ccy + math.sin(a) * r))
    return pts

def _arc_pts(cx, cy, r, a0, a1):
    n = max(8, int(abs(a1 - a0) / 5))
    return [(cx + math.cos(math.radians(a0 + (a1 - a0) * i / n)) * r, cy + math.sin(math.radians(a0 + (a1 - a0) * i / n)) * r)
            for i in range(n + 1)]

def _bbox(pts):
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    return min(xs), min(ys), max(xs), max(ys)

def _path_len(pts):
    return sum(math.hypot(pts[i + 1][0] - pts[i][0], pts[i + 1][1] - pts[i][1]) for i in range(len(pts) - 1))

def _cut(pts, frac):
    """First `frac` of a polyline by length."""
    total = _path_len(pts)
    if total <= 0 or frac >= 1:
        return pts
    target = total * max(0.0, frac)
    out = [pts[0]]
    run = 0.0
    for i in range(len(pts) - 1):
        seg = math.hypot(pts[i + 1][0] - pts[i][0], pts[i + 1][1] - pts[i][1])
        if run + seg >= target:
            t = (target - run) / seg if seg else 0
            out.append((pts[i][0] + (pts[i + 1][0] - pts[i][0]) * t, pts[i][1] + (pts[i + 1][1] - pts[i][1]) * t))
            return out
        out.append(pts[i + 1])
        run += seg
    return out

def _rot(pt, ang, pv):
    ca, sa = math.cos(ang), math.sin(ang)
    x, y = pt[0] - pv[0], pt[1] - pv[1]
    return (pv[0] + x * ca - y * sa, pv[1] + x * sa + y * ca)

def _resample(pts, step):
    out = [pts[0]]
    for a, b in zip(pts, pts[1:]):
        dx, dy = b[0] - a[0], b[1] - a[1]
        n = max(1, int(math.hypot(dx, dy) // step))
        for i in range(1, n + 1):
            out.append((a[0] + dx * i / n, a[1] + dy * i / n))
    return out


def _sketch(seq, seed, lw, boil, which):
    if len(seq) < 2:
        return seq
    pts = _resample(seq, 6.0)
    amp = min(1.6, 0.3 + 0.2 * lw) * (1.0 if which == 0 else 1.7)
    ph = boil * 1.3 + which * 2.1
    sd = seed * 1.37 + which * 5.0
    out = []
    s = 0.0
    n = len(pts)
    for i, p in enumerate(pts):
        if i:
            s += math.hypot(p[0] - pts[i - 1][0], p[1] - pts[i - 1][1])
        a = pts[max(0, i - 1)]
        b = pts[min(n - 1, i + 1)]
        dx, dy = b[0] - a[0], b[1] - a[1]
        ln = math.hypot(dx, dy) or 1.0
        o = amp * (math.sin(s * 0.045 + sd + ph) + 0.55 * math.sin(s * 0.13 + sd * 2.1 + ph * 1.3)) / 1.55
        out.append((p[0] - dy / ln * o, p[1] + dx / ln * o))
    return out



class _Item:
    """One drawable shape, flattened from the group tree, with the inherited transform baked in."""

    def __init__(self, sh, parent):
        self.sh = sh
        self.k = str(sh.get("t", sh.get("type", "rect"))).lower()
        self.parent = parent

class Draw(El):
    type = "draw"

    def __init__(self, spec):
        super().__init__(spec)
        size = spec.get("size") or [400, 400]
        self.W = max(40.0, _num(size[0], 400))
        self.H = max(40.0, _num(size[1] if len(size) > 1 else size[0], 400))
        self.shapes = spec.get("shapes") or []
        self.defs = spec.get("defs") if isinstance(spec.get("defs"), dict) else {}
        self.cast = spec.get("cast") if isinstance(spec.get("cast"), dict) else {}
        self.sync = None
        self.items = []
        self.loops = False
        self.anim_end = 0.0
        self.warn = []
        self._gseed = 1
        self.dyn = []
        self.dyn_ok = True
        self.anchors = {}
        self.joints = {}
        self.actors = []
        self._jc = {}
        self.light = _num(spec.get("light"), 0.0)
        self._flatten(self.shapes, (0.0, 0.0, 0.0, 1.0), {}, 0.0)
        if self.loops:
            self.anim_end = 1e6
        if not self.items:
            self.warn.append("draw element has no shapes")

    def _flatten(self, shapes, xf, inherit, delay):
        gx, gy, grot, gsc = xf
        for sh in shapes:
            if isinstance(sh, str):
                sh = parse_shape(sh)
            if not isinstance(sh, dict) or not sh:
                continue
            kind = str(sh.get("t", sh.get("type", "rect"))).lower()
            if kind == "stick":
                look = dict(self.cast.get(str(sh.get("who", "")), {})) if isinstance(self.cast, dict) else {}
                args = {k: v for k, v in sh.items() if k not in ("t", "type", "who", "show_name")}
                for k, v in look.items():
                    args.setdefault(k, v)
                if sh.get("show_name") and sh.get("who"):
                    args["name"] = sh["who"]
                args.pop("name", None) if not args.get("name") else None
                self.actors.append({"id": sh.get("id") or sh.get("who"), "x": gx + _num(args.get("x")) * gsc, "y": gy + _num(args.get("y")) * gsc,
                                    "h": _num(args.get("h"), 200.0) * gsc, "facing": -1 if _num(args.get("facing"), 1) < 0 else 1,
                                    "mx": _num((args.get("move") or {}).get("by", [0, 0])[0]) * gsc if isinstance(args.get("move"), dict) else 0.0,
                                    "delay": delay + _num(sh.get("delay"), 0.0), "act": str(args.get("act", "")).lower()})
                args = _unscale_move(args)
                if self.dyn_ok and (args.get("keys") or str(args.get("act", "")).lower() in _DYN_ACTS or args.get("live")):
                    rec = {"args": args, "xf": xf, "inherit": dict(inherit), "delay": delay + _num(sh.get("delay"), 0.0), "id": sh.get("id")}
                    self.dyn.append(rec)
                    it = _Item({"t": "dyn"}, None)
                    it.k = "dyn"
                    it.rec = rec
                    it.idx = len(self.items)
                    it.loop = "dyn"
                    it.on = None
                    it.delay = rec["delay"]
                    it.dur = 0.05
                    it.anim_in = "none"
                    it.move = None
                    it.out = ""
                    it.out_at = -1.0
                    self.loops = True
                    self.items.append(it)
                    continue
                fig = stickman.figure(**{k: v for k, v in args.items() if k in _STICK_KEYS or k in _MOTION_KEYS})
                sh = fig
                kind = "group"
            if kind in components.KINDS:
                sh = components.expand(kind, sh)
                kind = "group"
            if kind == "use":
                body = self.defs.get(str(sh.get("ref", "")))
                if body is None:
                    self.warn.append("use: unknown def '%s'" % sh.get("ref"))
                    continue
                sh = dict(sh, t="group", shapes=body)
                kind = "group"
            if kind == "rep":
                n = max(1, min(60, int(_num(sh.get("n"), 2))))
                for i in range(n):
                    g = {k: v for k, v in sh.items() if k not in ("t", "n", "dx", "dy", "dscale", "drot", "ddelay")}
                    g.update(t="group", x=_num(sh.get("x")) + i * _num(sh.get("dx")), y=_num(sh.get("y")) + i * _num(sh.get("dy")),
                             scale=_num(sh.get("scale"), 1.0) * (1 + i * _num(sh.get("dscale"))),
                             rot=_num(sh.get("rot")) + i * _num(sh.get("drot")), delay=_num(sh.get("delay")) + i * _num(sh.get("ddelay")))
                    self._flatten([g], xf, inherit, delay)
                continue
            props = dict(inherit)
            for key in ("fill", "stroke", "lw", "shadow", "opacity", "in", "dur", "loop", "amp", "speed", "kind", "on", "out", "out_at", "hatch", "sketch", "move", "around", "cid", "ckind"):
                if key in sh and kind == "group":
                    props[key] = sh[key]
            d0 = delay + _num(sh.get("delay"), 0.0)
            if kind == "group":
                if sh.get("loop") and "_ph" not in props:
                    props["_ph"] = self._gseed
                    self._gseed += 1
                nx, ny = _num(sh.get("x"), 0.0), _num(sh.get("y"), 0.0)
                gs = _num(sh.get("scale"), 1.0)
                gr = _num(sh.get("rot"), 0.0)
                cx, cy = gx + nx * gsc, gy + ny * gsc
                if sh.get("id"):
                    mv0 = sh.get("move") if isinstance(sh.get("move"), dict) else props.get("move")
                    self.anchors[str(sh["id"])] = {"pos": (cx, cy), "move": mv0 if isinstance(mv0, dict) else None, "delay": d0,
                                                   "loop": str(sh.get("loop", props.get("loop", ""))).lower(), "amp": _num(sh.get("amp", props.get("amp")), 0.0),
                                                   "speed": _num(sh.get("speed", props.get("speed")), 1.0), "xf": (gx, gy, grot, gsc), "rot": _num(sh.get("rot"), 0.0)}
                if sh.get("tilt") is not None:
                    props["tilt"] = sh["tilt"]
                    props["_tpv"] = (cx, cy)
                    if "persp" in sh:
                        props["persp"] = sh["persp"]

                self._flatten(sh.get("shapes") or [], (cx, cy, grot + gr, gsc * gs), props, d0)
                continue
            it = _Item(dict(props, **sh), None)
            it.xf = (gx, gy, grot, gsc)
            it.delay = d0
            it.idx = len(self.items)
            it.on = sh.get("on")
            anim_in = str(it.sh.get("in", "pop")).lower()
            it.anim_in = anim_in
            it.dur = max(0.05, _num(it.sh.get("dur"), IN_DEFAULT_DUR if anim_in != "type" else 1.2))
            it.loop = str(it.sh.get("loop", "")).lower()
            if it.loop:
                self.loops = True
            mv = it.sh.get("move")
            it.move = mv if isinstance(mv, dict) else None
            it.out = str(it.sh.get("out", "fade" if it.sh.get("out_on") is not None else "")).lower()
            it.out_at = _num(it.sh.get("out_at"), -1.0)
            self.items.append(it)
            if it.on is None:
                self.anim_end = max(self.anim_end, it.delay + it.dur + (_num(it.move.get("at"), 0) + _num(it.move.get("dur"), 0.6) if it.move else 0))
            else:
                self.anim_end = max(self.anim_end, 6.0)
            if it.out and it.out_at >= 0:
                self.anim_end = max(self.anim_end, it.out_at + 0.5)

    def sfx_times(self):
        out, seen = [], set()
        for it in self.items:
            if it.anim_in in ("none", "") or getattr(it, "loop", "") and it.anim_in == "none":
                continue
            t0 = self._start(it)
            if it.anim_in == "type":
                x = 0.0
                while x < min(it.dur, 1.0):
                    out.append((t0 + x, "type"))
                    x += 0.07
                continue
            q = int(round(t0 / 0.12))
            if q in seen or t0 < 0.1:
                continue
            seen.add(q)
            out.append((t0, "tick"))
            if len(out) > 16:
                break
        return out

    def layout(self, width):
        avail_w = min(width - 12, self.max_w or width - 12)
        f = avail_w / self.W
        if self.max_h:
            f = min(f, self.max_h / self.H)
        self.f = max(0.2, min(f, 2.2))
        self.w = self.W * self.f
        self.h = self.H * self.f

    def key(self, lt):
        if self.anim_end >= 1e5:
            base = int(round(max(lt, 0.0) * KEY_FPS))
        else:
            base = int(round(min(max(lt, 0.0), self.anim_end) * KEY_FPS))
        if THEME.get("doodle"):
            return (base, int(max(lt, 0.0) * 6) % 97)
        return base

    def _find_word(self, on):
        if not self.sync or on is None:
            return None
        words, trig = self.sync
        if isinstance(on, int):
            return max(0, min(len(words) - 1, on)) if words else None
        want = re.sub(r"[^\w]", "", str(on), flags=re.UNICODE).lower()
        for n, (t, s, e) in enumerate(words):
            if re.sub(r"[^\w]", "", t, flags=re.UNICODE).lower() == want:
                return n
        return None

    def _word_t(self, on):
        k = self._find_word(on)
        if k is None:
            return None
        words, trig = self.sync
        return max(0.0, words[k][1] - 0.05 - trig)

    def _start(self, it):
        if it.on is None or not self.sync:
            return it.delay
        wt = self._word_t(it.on)
        if wt is None:
            return it.delay
        return wt + it.delay

    def _resolve_item(self, it):
        if getattr(it, "_resolved", False) or not self.sync:
            return
        it._resolved = True
        st = self._start(it)
        oo = it.sh.get("out_on")
        if oo is not None:
            wt = self._word_t(oo)
            if wt is not None:
                it.out_at = max(0.0, wt - st)
                if not it.out:
                    it.out = "fade"
        mv = it.move
        if isinstance(mv, dict) and mv.get("on") is not None:
            wt = self._word_t(mv["on"])
            if wt is not None:
                it.move = dict(mv, at=max(0.0, wt - st))

    def _resolved_args(self, rec):
        args = rec["args"]
        if not self.sync:
            return args
        out = dict(args)
        d0 = rec["delay"]
        mv = args.get("move")
        if isinstance(mv, dict) and mv.get("on") is not None:
            wt = self._word_t(mv["on"])
            if wt is not None:
                out["move"] = dict(mv, at=max(0.0, wt - d0))
        ks = args.get("keys")
        if isinstance(ks, list):
            nk = []
            for k in ks:
                if isinstance(k, dict) and k.get("on") is not None:
                    wt = self._word_t(k["on"])
                    if wt is not None:
                        k = dict(k, at=max(0.0, wt - d0))
                nk.append(k)
            out["keys"] = nk
        un = args.get("until_on")
        if un is not None:
            wt = self._word_t(un)
            if wt is not None:
                out["until"] = max(0.0, wt - d0)
        return out

    def _geom(self, it):
        """-> (kind, data) in the shape's own space (before transforms)."""
        sh = it.sh
        k = it.k
        n = _num
        if k == "rect":
            x, y, w, h = n(sh.get("x")), n(sh.get("y")), n(sh.get("w"), 40), n(sh.get("h"), 40)
            return "poly", [_rrect_pts(x, y, w, h, n(sh.get("r"), 0))], True
        if k == "circle":
            r = n(sh.get("r"), 20)
            return "poly", [_ellipse_pts(n(sh.get("cx")), n(sh.get("cy")), r, r)], True
        if k == "ellipse":
            return "poly", [_ellipse_pts(n(sh.get("cx")), n(sh.get("cy")), n(sh.get("rx"), 30), n(sh.get("ry"), 20))], True
        if k == "poly":
            pts = [(n(p[0]), n(p[1])) for p in (sh.get("pts") or []) if len(p) >= 2]
            return "poly", [pts], True
        if k == "line":
            pts = [(n(p[0]), n(p[1])) for p in (sh.get("pts") or []) if len(p) >= 2]
            return "poly", [pts], False
        if k == "arc":
            return "poly", [_arc_pts(n(sh.get("cx")), n(sh.get("cy")), n(sh.get("r"), 30), n(sh.get("a0"), 0), n(sh.get("a1"), 180))], False
        if k == "path":
            subs = parse_path(str(sh.get("d", "")))
            return "multi", subs, None
        if k == "text":
            return "text", (n(sh.get("x")), n(sh.get("y"))), None
        return "poly", [[]], False

    @staticmethod
    def _center(kind, data):
        if kind == "text":
            return data
        if kind == "multi":
            pts = [p for sub, _ in data for p in sub]
        else:
            pts = [p for sub in data for p in sub]
        if not pts:
            return (0.0, 0.0)
        x0, y0, x1, y1 = _bbox(pts)
        return ((x0 + x1) / 2.0, (y0 + y1) / 2.0)

    def _fig(self, rec, lt):
        args = dict(self._resolved_args(rec))
        keep = {k: v for k, v in args.items() if k in _STICK_KEYS or k in _MOTION_KEYS or k in ("keys", "speed", "contact", "shadow", "blink", "until")}
        fig = stickman.animated(keep, max(lt - rec["delay"], 0.0), self.light)
        joints = fig.pop("_joints", None)
        return fig, joints

    def _abs_joints(self, rec, fig, joints, lt):
        gx, gy, grot, gsc = rec["xf"]
        sc = _num(fig.get("scale"), 1.0)
        fx, fy = _num(fig.get("x")), _num(fig.get("y"))
        mdx = mdy = 0.0
        mv = self._resolved_args(rec).get("move")
        if isinstance(mv, dict):
            fake = _Item({"t": "dyn", "in": "none"}, None)
            fake.idx = 0
            fake.anim_in = "none"
            fake.dur = 0.05
            fake.loop = ""
            fake.move = mv
            fake.out = ""
            fake.out_at = -1.0
            am = self._animate(fake, lt - rec["delay"])
            mdx, mdy = am["dx"], am["dy"]
        res = {}
        for name, (jx, jy) in joints.items():
            px, py = fx + (jx + mdx) * sc, fy + (jy + mdy) * sc
            if grot:
                px, py = _rot((px, py), math.radians(grot), (0.0, 0.0))
            res[name] = (gx + px * gsc, gy + py * gsc)
        return res

    def _dyn_items(self, rec, lt):
        save = self.items
        seed, aend, nw = self._gseed, self.anim_end, len(self.warn)
        self.items = []
        try:
            fig, joints = self._fig(rec, lt)
            self._flatten([fig], rec["xf"], rec["inherit"], rec["delay"])
            out = self.items
        finally:
            self.items = save
            self._gseed, self.anim_end = seed, aend
            del self.warn[nw:]
        if joints and rec.get("id"):
            self.joints[str(rec["id"])] = self._abs_joints(rec, fig, joints, lt)
        return out

    def _joint_of(self, key, lt):
        for rec in self.dyn:
            if str(rec.get("id")) == key:
                ck = (key, int(round(lt * 120)))
                hit = self._jc.get(ck)
                if hit is None:
                    fig, joints = self._fig(rec, lt)
                    hit = self._abs_joints(rec, fig, joints, lt) if joints else {}
                    if len(self._jc) > 64:
                        self._jc.clear()
                    self._jc[ck] = hit
                return hit
        return self.joints.get(key)

    def _anchor_pos(self, ref, lt):
        if isinstance(ref, (list, tuple)) and len(ref) >= 2:
            return (_num(ref[0]), _num(ref[1]))
        if not isinstance(ref, dict):
            return (0.0, 0.0)
        off = ref.get("off") or [0, 0]
        key = str(ref.get("of", ref.get("stick", "")))
        jt = self._joint_of(key, lt)
        if jt:
            j = jt.get(str(ref.get("joint", "rh")))
            if j:
                return (j[0] + _num(off[0]), j[1] + _num(off[1]))
        an = self.anchors.get(key)
        if an:
            fake = _Item({"t": "dyn", "in": "none", "loop": an["loop"], "amp": an["amp"], "speed": an["speed"]}, None)
            fake.idx = 0
            fake.anim_in = "none"
            fake.dur = 0.05
            fake.loop = an["loop"]
            fake.move = an["move"]
            fake.out = ""
            fake.out_at = -1.0
            a = self._animate(fake, lt - an["delay"])
            ang = math.radians(an["rot"] + a["rot"])
            ox_, oy_ = _num(off[0]), _num(off[1])
            if ang:
                ox_, oy_ = _rot((ox_, oy_), ang, (0.0, 0.0))
            gx, gy, grot, gsc = an["xf"]
            return (an["pos"][0] + (a["dx"] + ox_) * gsc, an["pos"][1] + (a["dy"] + oy_) * gsc)
        return (_num(off[0]), _num(off[1]))

    def _paint_rope(self, c, ox, oy, f, lt, it):
        sh = it.sh
        self._resolve_item(it)
        an = self._animate(it, lt - self._start(it))
        if not an["visible"] or an["alpha"] <= 0.004:
            return
        a = self._anchor_pos(sh.get("a"), lt)
        b = self._anchor_pos(sh.get("b"), lt)
        dx, dy = b[0] - a[0], b[1] - a[1]
        ln = math.hypot(dx, dy) or 1.0
        slack = max(0.0, _num(sh.get("slack"), 0.12))
        wind = _num(sh.get("wind"), 1.0)
        sag = ln * slack * (0.6 + 0.4 * math.sin(lt * 1.7 * wind + 0.8)) * _num(sh.get("sagk"), 1.0)
        nx, ny = -dy / ln, dx / ln
        sway = _num(sh.get("sway"), 6.0) * math.sin(lt * 2.3 * wind + ln * 0.01)
        ctrl = ((a[0] + b[0]) / 2 + sway * nx, (a[1] + b[1]) / 2 + sag + sway * ny)
        pts = _bez2(a, ctrl, b, 28)
        gx, gy, grot, gsc = it.xf
        tp = [(p[0] * f + ox, p[1] * f + oy) for p in pts]
        stroke = color(sh.get("stroke"), INK) if sh.get("stroke") is not None else INK
        lw = _num(sh.get("lw"), 2.2) * f
        c.line(tp, w=max(1.2, lw), fill=stroke)

    def paint(self, c, ox, oy, lt):
        f = self.f
        self._boil = int(max(lt, 0.0) * 6) % 97 if THEME.get("doodle") else 0
        expanded = []
        for it in self.items:
            if it.k == "dyn":
                expanded += self._dyn_items(it.rec, lt)
            else:
                expanded.append(it)
        for it in expanded:
            if it.k == "rope":
                self._paint_rope(c, ox, oy, f, lt, it)
            else:
                self._paint_item(c, ox, oy, f, lt, it)

    def _animate(self, it, t):
        """-> dict(alpha, scale, dx, dy, rot, draw, type) for local time t (seconds since this shape's start)."""
        a = dict(alpha=1.0, scale=1.0, dx=0.0, dy=0.0, rot=0.0, draw=1.0, type=1.0, visible=True, tax=0.0, tay=0.0, sy=1.0)
        if t < 0:
            a["visible"] = False
            return a
        p = clamp(t / it.dur)
        m = it.anim_in
        if m == "pop":
            a["scale"] = ease_out_back(p)
            a["alpha"] = clamp(p * 3)
        elif m == "fade":
            a["alpha"] = ease_in_out(p)
        elif m == "rise":
            a["dy"] = (1 - ease_out_cubic(p)) * 26
            a["alpha"] = clamp(p * 2.5)
        elif m == "left":
            a["dx"] = -(1 - ease_out_cubic(p)) * 46
            a["alpha"] = clamp(p * 2.5)
        elif m == "right":
            a["dx"] = (1 - ease_out_cubic(p)) * 46
            a["alpha"] = clamp(p * 2.5)
        elif m == "grow":
            a["scale"] = ease_out_cubic(p)
        elif m == "flip":
            e = ease_out_cubic(p)
            a["tax"] = (1 - e) * 52
            a["tay"] = -(1 - e) * 38
            a["dy"] = (1 - e) * 34
            a["alpha"] = clamp(p * 3)
        elif m == "growy":
            a["sy"] = ease_out_back(p)
            a["alpha"] = clamp(p * 4)
        elif m == "drop":
            a["dy"] = -(1 - ease_out_bounce(p)) * 64
            a["alpha"] = clamp(p * 5)
        elif m == "stamp":
            a["scale"] = 1 + (1 - ease_out_cubic(p)) * 0.8
            a["rot"] = (1 - ease_out_cubic(p)) * -8
            a["alpha"] = clamp(p * 4)
        elif m == "up":
            a["dy"] = (1 - ease_out_cubic(p)) * 60
            a["alpha"] = clamp(p * 3)
        elif m == "down":
            a["dy"] = -(1 - ease_out_cubic(p)) * 60
            a["alpha"] = clamp(p * 3)
        elif m == "draw":
            a["draw"] = ease_in_out(p)
        elif m == "type":
            a["type"] = p
        if it.out and it.out_at >= 0 and t >= it.out_at:
            q = clamp((t - it.out_at) / 0.35)
            if it.out == "pop":
                a["scale"] *= 1 - ease_out_cubic(q)
            a["alpha"] *= 1 - q
            if q >= 1:
                a["visible"] = False
        if it.loop:
            amp = _num(it.sh.get("amp"), 0.0)
            sp = _num(it.sh.get("speed"), 1.0)
            ph = (t + 0.37 * (_num(it.sh.get('_ph'), it.idx) % 7)) * sp
            if it.loop == "float":
                a["dy"] += math.sin(ph * 2.2) * (amp or 5)
            elif it.loop == "pulse":
                a["scale"] *= 1 + math.sin(ph * 3.0) * (amp or 0.06)
            elif it.loop == "spin":
                a["rot"] += (t * sp) * (amp or 90)
            elif it.loop == "wobble":
                a["rot"] += math.sin(ph * 3.0) * (amp or 8)
            elif it.loop == "blink":
                a["alpha"] *= 0.55 + 0.45 * math.sin(ph * 4.0)
            elif it.loop == "shake":
                a["dx"] += math.sin(ph * 38.0) * (amp or 2.5)
                a["rot"] += math.sin(ph * 31.0) * 1.2
            elif it.loop == "swing":
                a["rot"] += math.sin(ph * 2.4) * (amp or 12)
            elif it.loop == "breathe":
                a["scale"] *= 1 + math.sin(ph * 2.0) * (amp or 0.025)
                a["dy"] -= math.sin(ph * 2.0) * 1.2
            elif it.loop == "bob":
                a["dy"] += math.sin(ph * 2.2) * (amp or 5)
        if it.sh.get("tilt") and it.loop:
            ph2 = (t + 0.37 * (_num(it.sh.get("_ph"), it.idx) % 7))
            a["tay"] += math.sin(ph2 * 1.3) * 5.0
            a["tax"] += math.sin(ph2 * 0.9) * 3.0
        if it.move:
            at = _num(it.move.get("at"), 0.0)
            md = max(0.05, _num(it.move.get("dur"), 0.6))
            by = it.move.get("by") or [0, 0]
            q = ease_in_out(clamp((t - at) / md))
            a["dx"] += _num(by[0]) * q
            a["dy"] += _num(by[1]) * q - _num(it.move.get("arc"), 0.0) * math.sin(math.pi * q)
        return a

    def _paint_item(self, c, ox, oy, f, lt, it):
        self._resolve_item(it)
        t0 = self._start(it)
        t = lt - t0
        an = self._animate(it, t)
        if not an["visible"] or an["alpha"] <= 0.004:
            return
        sh = it.sh
        kind, data, closed = self._geom(it)
        gx, gy, grot, gsc = it.xf
        cx0, cy0 = self._center(kind, data)
        pv = sh.get("pivot")
        pvt = (_num(pv[0]), _num(pv[1])) if isinstance(pv, (list, tuple)) and len(pv) >= 2 else (cx0, cy0)
        own_sc = _num(sh.get("scale"), 1.0)
        own_rot = math.radians(_num(sh.get("rot"), 0.0) + an["rot"])
        sc_anim = an["scale"]
        orbit_d = (0.0, 0.0)
        if it.loop == "orbit":
            around = sh.get("around") or [self.W / 2, self.H / 2]
            ang = math.radians(t * _num(sh.get("speed"), 1.0) * (_num(sh.get("amp"), 0.0) or 60))
            nc = _rot((cx0, cy0), ang, (_num(around[0]), _num(around[1])))
            orbit_d = (nc[0] - cx0, nc[1] - cy0)
        tl = sh.get("tilt")
        tilt = None
        if isinstance(tl, (list, tuple)) and len(tl) >= 2:
            tpv = sh.get("_tpv") or (gx, gy)
            tilt = (_num(tl[0]) + an["tax"], _num(tl[1]) + an["tay"], (_num(tpv[0]), _num(tpv[1])), _num(sh.get("persp"), 700.0))

        def tf(p):
            x, y = p
            x = pvt[0] + (x - pvt[0]) * own_sc * sc_anim
            y = pvt[1] + (y - pvt[1]) * own_sc * sc_anim * an["sy"]
            if own_rot:
                x, y = _rot((x, y), own_rot, pvt)
            x += an["dx"] + orbit_d[0]
            y += an["dy"] + orbit_d[1]
            if grot:
                x, y = _rot((x, y), math.radians(grot), (0.0, 0.0))
            u, v = gx + x * gsc, gy + y * gsc
            if tilt is not None:
                u, v = project(u, v, tilt[2], tilt[0], tilt[1], tilt[3])
            return (u * f + ox, v * f + oy)

        fill = color(sh.get("fill"), None) if sh.get("fill") is not None else None
        stroke = color(sh.get("stroke"), None) if sh.get("stroke") is not None else None
        lw = _num(sh.get("lw"), 3.0 if stroke is not None else 0.0) * f * gsc
        alpha = clamp(an["alpha"] * _num(sh.get("opacity"), 1.0))
        glow = sh.get("glow")
        gcol = None
        if glow:
            gcol = color(glow, None) if glow is not True else (stroke or fill or ORANGE)
        rects = []
        subs = []
        if kind != "text":
            subs = data if kind == "multi" else [(s_, closed) for s_ in data]
            tps = []
            for pts, cl in subs:
                tp = [tf(p) for p in pts] if len(pts) >= 2 else []
                tps.append(tp)
                rects += tp
        else:
            tps = []
        gr = _num(sh.get("gr"), 10.0) * f
        need_layer = alpha < 0.985 or gcol is not None
        target = c
        layer = None
        if need_layer:
            if kind == "text":
                cx, cy = tf((_num(sh.get("x")), _num(sh.get("y"))))
                ext = max(self._text_extent(sh, f, gsc), 40.0) + gr * 3 + 20
                x0, y0, x1, y1 = cx - ext, cy - ext * 0.6, cx + ext, cy + ext * 0.6
            elif rects:
                pad = lw + gr * 3 + 6
                x0 = min(p[0] for p in rects) - pad
                y0 = min(p[1] for p in rects) - pad
                x1 = max(p[0] for p in rects) + pad
                y1 = max(p[1] for p in rects) + pad
            else:
                return
            x0, y0 = max(c.ox, x0), max(c.oy, y0)
            x1, y1 = min(c.ox + c.w, x1), min(c.oy + c.h, y1)
            if x1 - x0 < 2 or y1 - y0 < 2:
                return
            layer = Canvas(x1 - x0, y1 - y0, c.scale, ox=x0, oy=y0)
            target = layer
        if kind == "text":
            self._text(target, it, tf, an, f, gsc, tilt, ox, oy)
        else:
            sketchy = bool(THEME.get("doodle")) and sh.get("sketch", True) is not False
            fa = sh.get("fa")
            grad = sh.get("grad")
            shadow = sh.get("shadow")
            for si, ((pts, cl), tp) in enumerate(zip(subs, tps)):
                if len(tp) < 2:
                    continue
                prog = an["draw"]
                if prog < 0.999:
                    seq = tp + ([tp[0]] if cl and stroke is not None else [])
                    if sketchy:
                        seq = _sketch(seq, it.idx * 7 + si * 3, lw, self._boil, 0)
                    cut = _cut(seq, prog)
                    if len(cut) >= 2 and stroke is not None:
                        target.line(cut, w=lw or 3 * f, fill=stroke)
                    if cl and fill is not None and prog > 0.55 and len(tp) >= 3:
                        target.fill_alpha(tp, fill, clamp((prog - 0.55) / 0.45))
                    continue
                if shadow and not sketchy and (fill is not None or stroke is not None):
                    off = 4.5 * f if shadow is True else _num(shadow, 4.5) * f
                    sp = [(x + off, y + off) for x, y in tp]
                    if cl and fill is not None:
                        target.poly(sp, fill=INK)
                    elif stroke is not None:
                        target.line(sp, w=lw or 3 * f, fill=INK)
                if cl and len(tp) >= 3:
                    if isinstance(grad, (list, tuple)) and len(grad) >= 2:
                        ga = sh.get("ga") or [1.0, 1.0]
                        target.gradient(tp, color(grad[0], INK), color(grad[1], INK), _num(ga[0], 1.0), _num(ga[1], 1.0))
                    elif fill is not None:
                        if fa is not None and _num(fa, 1.0) < 0.995:
                            target.fill_alpha(tp, fill, _num(fa, 1.0))
                        else:
                            target.poly(tp, fill=fill)
                        if sketchy and sh.get("hatch", True) is not False and tuple(fill) != tuple(WHITE):
                            xs = [p[0] for p in tp]
                            ys = [p[1] for p in tp]
                            if (max(xs) - min(xs)) * (max(ys) - min(ys)) > 1400:
                                target.hatch(tp, fill, seed=it.idx * 13 + si)
                if stroke is not None and lw > 0:
                    seq = tp + [tp[0]] if cl else tp
                    if sketchy:
                        if cl and it.k in ("circle", "ellipse") and len(seq) > 14:
                            seq = seq + seq[1:max(3, len(seq) // 9)]
                        target.line(_sketch(seq, it.idx * 7 + si * 3, lw, self._boil, 0), w=lw, fill=stroke)
                        xs = [p[0] for p in tp]
                        ys = [p[1] for p in tp]
                        if (max(xs) - min(xs)) + (max(ys) - min(ys)) > 70 and lw >= 2.2:
                            target.line(_sketch(seq, it.idx * 7 + si * 3, lw, self._boil, 1), w=lw * 0.45, fill=stroke)
                    else:
                        target.line(seq, w=lw, fill=stroke)
                elif cl is False and fill is not None and stroke is None:
                    target.line(tp, w=3 * f, fill=fill)
        if layer is not None:
            im = layer.im
            px0 = int(round((layer.ox - c.ox) * c.k))
            py0 = int(round((layer.oy - c.oy) * c.k))
            if alpha < 1:
                a = im.getchannel("A").point(lambda v, al=alpha: int(v * al))
                im.putalpha(a)
            if gcol is not None:
                hl, pad = halo(im, gcol, gr * c.k * 0.5, _num(sh.get("gs"), 0.9) * alpha)
                blit(c.im, hl, px0 - pad, py0 - pad)
            blit(c.im, im, px0, py0)

    def _text_extent(self, sh, f, gsc):
        s = str(sh.get("text", ""))
        size = _num(sh.get("size"), 28)
        w = measure(s, str(sh.get("kind", "sans")), size)[0]
        if sh.get("w"):
            w = min(w, _num(sh.get("w")))
        return max(w, size) * f * gsc * 0.6 + size * f * gsc

    def _text(self, target, it, tf, an, f, gsc, tilt=None, ox=0.0, oy=0.0):
        sh = it.sh
        s = str(sh.get("text", ""))
        if an["type"] < 0.999:
            s = s[: int(len(s) * an["type"])]
        if not s:
            return
        x, y = _num(sh.get("x")), _num(sh.get("y"))
        size = _num(sh.get("size"), 28)
        maxw = sh.get("w")
        kind = str(sh.get("kind", "sans"))
        fill = color(sh.get("fill"), INK)
        px, py = tf((x, y))
        sz = size * f * gsc * an["scale"] * _num(sh.get("scale"), 1.0)
        lines = [s]
        if maxw:
            mw = _num(maxw) * f * gsc
            full = str(sh.get("text", ""))
            lines, sz2 = fit_lines(full, mw, max(8.0, sz), min_size=max(7.0, sz * 0.55), kind=kind, max_lines=int(_num(sh.get("lines"), 2)))
            if an["type"] < 0.999:
                lines = [s]
            sz = sz2
        anchor = str(sh.get("anchor", "mm"))
        lh = sz * 1.15
        y0 = py - (len(lines) - 1) * lh / 2.0 if anchor[1:2] == "m" else py
        ang = _num(sh.get("rot"), 0.0) + an["rot"]
        spacing = _num(sh.get("ls"), 0.0) * f * gsc
        ext = _num(sh.get("extrude"), 0.0)

        def draw_lines(cv, dx=0.0, dy=0.0, col=fill):
            for i, ln in enumerate(lines):
                cv.text(px + dx, y0 + i * lh + dy, ln, sz, fill=col, kind=kind, anchor=anchor, spacing=spacing)

        if ext > 0:
            depth = int(min(14, ext))
            dark = tuple(int(v * 0.35) for v in fill)
            for j in range(depth, 0, -1):
                draw_lines(target, j * 1.1 * f, j * 1.1 * f, mix(dark, fill, 0.25 + 0.25 * (1 - j / float(depth))))
        if tilt is not None or abs(ang) > 0.5:
            tw = max(measure(ln, kind, sz)[0] + spacing * len(ln) for ln in lines)
            wmax = tw + sz * 0.8
            hbox = lh * len(lines) + sz * 0.6
            if anchor[0] == "l":
                bx0 = px - sz * 0.4
            elif anchor[0] == "r":
                bx0 = px - tw - sz * 0.4
            else:
                bx0 = px - wmax / 2
            by0 = y0 - lh * 0.6
            bx0 = max(target.ox, bx0)
            by0 = max(target.oy, by0)
            tmp = Canvas(min(wmax, target.ox + target.w - bx0), min(hbox, target.oy + target.h - by0), target.scale, ox=bx0, oy=by0)
            ck = (tuple(lines), round(sz, 2), kind, tuple(fill), round(spacing, 2), anchor, round(px - bx0, 1), round(y0 - by0, 1), round(tmp.w, 1), round(tmp.h, 1), target.scale)
            im = _TEXT_CACHE.get(ck)
            if im is None:
                draw_lines(tmp)
                im = tmp.im
                if len(_TEXT_CACHE) > 160:
                    _TEXT_CACHE.clear()
                _TEXT_CACHE[ck] = im
            if tilt is not None and np_available():
                gxq = [(bx0, by0), (bx0 + tmp.w, by0), (bx0 + tmp.w, by0 + tmp.h), (bx0, by0 + tmp.h)]
                quad = []
                for (qx, qy) in gxq:
                    u, v = (qx - ox) / f, (qy - oy) / f
                    u2, v2 = project(u, v, tilt[2], tilt[0], tilt[1], tilt[3])
                    quad.append((u2 * f + ox, v2 * f + oy))
                qx0, qy0 = min(p[0] for p in quad), min(p[1] for p in quad)
                qx1, qy1 = max(p[0] for p in quad), max(p[1] for p in quad)
                k = target.k
                size_px = (max(2, int((qx1 - qx0) * k)), max(2, int((qy1 - qy0) * k)))
                dst = [((p[0] - qx0) * k, (p[1] - qy0) * k) for p in quad]
                src = [(0, 0), (im.width, 0), (im.width, im.height), (0, im.height)]
                co = persp_coeffs(dst, src)
                if co is not None:
                    im = im.transform(size_px, Image.PERSPECTIVE, co, Image.BILINEAR)
                    blit(target.im, im, round((qx0 - target.ox) * k), round((qy0 - target.oy) * k))
                    return
            if abs(ang) > 0.5:
                cx_, cy_ = (px - bx0) * tmp.k, (py - by0) * tmp.k
                im = im.rotate(-ang, resample=Image.BICUBIC, center=(cx_, cy_))
            blit(target.im, im, round((bx0 - target.ox) * target.k), round((by0 - target.oy) * target.k))
            return
        draw_lines(target)

    def _text_boxes(self):
        boxes = []
        for it in self.items:
            if it.k != "text" or it.out:
                continue
            sh = it.sh
            s = str(sh.get("text", ""))
            size = _num(sh.get("size"), 28)
            kind = str(sh.get("kind", "sans"))
            mw = measure(s, kind, size)[0]
            if sh.get("w"):
                lim = _num(sh.get("w"))
                if mw > lim:
                    lines = 2 if int(_num(sh.get("lines"), 2)) >= 2 else 1
                    mw = lim
                    size = size * 0.8
                    hh = size * 1.15 * lines
                else:
                    hh = size * 1.15
            else:
                hh = size * 1.15
            gx, gy, grot, gsc = it.xf
            x = gx + _num(sh.get("x")) * gsc
            y = gy + _num(sh.get("y")) * gsc
            mw *= gsc
            hh *= gsc
            anc = str(sh.get("anchor", "mm"))
            left = x - mw / 2 if anc[0] == "m" else (x if anc[0] == "l" else x - mw)
            top = y - hh / 2 if anc[1:2] == "m" else (y if anc[1:2] == "a" else y - hh)
            boxes.append((left, top, left + mw, top + hh, s, self._start(it), it))
        return boxes

    def component_boxes(self):
        boxes = {}
        for it in self.items:
            cid = it.sh.get("cid")
            if cid is None or it.k == "dyn":
                continue
            gx, gy, grot, gsc = it.xf
            if it.k == "text":
                continue
            kind, data, closed = self._geom(it)
            pts = [p for sub in (data if kind == "poly" else [s for s, _ in data]) for p in sub] if kind in ("poly", "multi") else []
            if not pts:
                continue
            x0, y0, x1, y1 = _bbox(pts)
            if it.sh.get("move"):
                continue
            b = boxes.setdefault(cid, [1e9, 1e9, -1e9, -1e9, str(it.sh.get("ckind"))])
            b[0], b[1] = min(b[0], gx + x0 * gsc), min(b[1], gy + y0 * gsc)
            b[2], b[3] = max(b[2], gx + x1 * gsc), max(b[3], gy + y1 * gsc)
        return list(boxes.values())

    def lint(self):
        problems = list(self.warn)
        cb = [b for b in self.component_boxes() if b[4] not in ("beam", "frame", "spark", "globe")]
        for i in range(len(cb)):
            for j in range(i + 1, len(cb)):
                a, b = cb[i], cb[j]
                ox_ = min(a[2], b[2]) - max(a[0], b[0])
                oy_ = min(a[3], b[3]) - max(a[1], b[1])
                if ox_ > 6 and oy_ > 6:
                    amin = min((a[2] - a[0]) * (a[3] - a[1]), (b[2] - b[0]) * (b[3] - b[1]))
                    if ox_ * oy_ > 0.12 * amin:
                        problems.append("%s and %s overlap - move one" % (a[4], b[4]))
        tb = self._text_boxes()
        for i in range(len(tb)):
            for j in range(i + 1, len(tb)):
                a, b = tb[i], tb[j]
                ox_ = min(a[2], b[2]) - max(a[0], b[0])
                oy_ = min(a[3], b[3]) - max(a[1], b[1])
                if ox_ > 4 and oy_ > 0.45 * min(a[3] - a[1], b[3] - b[1]):
                    problems.append("texts overlap: '%s' and '%s' - move one" % (a[4][:20], b[4][:20]))
        for it in self.items:
            kind, data, closed = self._geom(it)
            if kind in ("poly", "multi"):
                pts = [p for sub in data for p in (sub[0] if kind == "multi" else sub)]
                if pts:
                    x0, y0, x1, y1 = _bbox(pts)
                    gx, gy, grot, gsc = it.xf
                    if grot == 0 and (gx + x0 * gsc < -self.W * 0.06 or gy + y0 * gsc < -self.H * 0.06
                                      or gx + x1 * gsc > self.W * 1.06 or gy + y1 * gsc > self.H * 1.06):
                        problems.append("shape '%s' leaves the %gx%g drawing area" % (it.k, self.W, self.H))
            elif it.k == "text":
                s = str(it.sh.get("text", ""))
                size = _num(it.sh.get("size"), 28)
                mw = measure(s, str(it.sh.get("kind", "sans")), size)[0]
                x = _num(it.sh.get("x"))
                anc = str(it.sh.get("anchor", "mm"))
                lim = _num(it.sh.get("w"), 0)
                if not lim:
                    left = x - mw / 2 if anc[0] == "m" else (x if anc[0] == "l" else x - mw)
                    right = left + mw
                    gx, gy, grot, gsc = it.xf
                    if grot == 0 and (gx + left * gsc < -2 or gx + right * gsc > self.W + 2):
                        problems.append("text '%s' is wider than the drawing area (give it \"w\" to auto-fit)" % s[:24])
        return problems
