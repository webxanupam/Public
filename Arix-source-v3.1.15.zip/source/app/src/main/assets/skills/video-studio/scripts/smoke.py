import json
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent

SPECS = {
    "en_916": {"aspect": "9:16", "scenes": [
        {"narration": "Why does your phone battery die so fast?"},
        {"narration": "Sleep affects memory, mood, and focus."}]},
    "en_169": {"aspect": "16:9", "scenes": [
        {"narration": "First, the browser asks the server for the page. Then the server sends back the data."}]},
    "en_11": {"aspect": "1:1", "scenes": [
        {"narration": "Electric cars cost less to run than petrol cars, but they take longer to charge."}]},
}


def check(name, spec, work):
    spec = dict(spec, style="cinema", autodraw=True, research={"waived": "smoke"})
    path = work / f"{name}.json"
    path.write_text(json.dumps(spec, ensure_ascii=False), encoding="utf-8")
    out = work / name
    run = subprocess.run(
        [sys.executable, str(HERE / "make_video.py"), str(path), "--check", str(out), "--no-research-check"],
        capture_output=True, text=True,
    )
    shots = list(out.glob("scene_*.png")) if out.exists() else []
    ok = run.returncode == 0 and len(shots) >= len(spec["scenes"])
    print(("ok   " if ok else "FAIL ") + name, f"{len(shots)} previews")
    if not ok:
        print(run.stdout[-800:], run.stderr[-800:])
    return ok


def main():
    with tempfile.TemporaryDirectory() as tmp:
        work = Path(tmp)
        results = [check(n, s, work) for n, s in SPECS.items()]
    sys.exit(0 if all(results) else 1)


if __name__ == "__main__":
    main()
