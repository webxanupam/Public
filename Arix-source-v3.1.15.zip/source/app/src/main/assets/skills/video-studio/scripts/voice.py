#!/usr/bin/env python3
"""voice.py - offline English narration for Video Studio (Android/Termux).

One engine: Kokoro v1.0 through onnxruntime, voice am_puck. Text is phonemized from the model's own
lexicon (lexicon-us-en.txt), so no espeak or other phonemizer is needed.

CLI:
  python voice.py doctor
  python voice.py say "Hello" out.wav [--speed 1.0]
  python voice.py selftest
"""
import json, os, re, shutil, subprocess, sys, wave

DATA = os.environ.get("ARIX_VIDEO_HOME") or os.path.join(os.path.expanduser("~"), ".arix", "video-studio")
MODEL_DIR = os.environ.get("KOKORO_DIR") or os.path.join(DATA, "kokoro-multi-lang-v1_0")
VOICE = "am_puck"
SPEAKER = 18
ENGINE = "kokoro_onnx"
SR = 24000
FILES = ("model.onnx", "voices.bin", "tokens.txt", "lexicon-us-en.txt")

def _model_ok():
    return all(os.path.isfile(os.path.join(MODEL_DIR, f)) for f in FILES)

def _has_onnx():
    try:
        import onnxruntime, numpy
        return True
    except Exception:
        return False

def ffmpeg_caps():
    if not shutil.which("ffmpeg"):
        return {"ffmpeg_libass": False, "ffmpeg_x264": False}
    try:
        flt = subprocess.run(["ffmpeg", "-hide_banner", "-filters"], capture_output=True, text=True, timeout=30).stdout
        enc = subprocess.run(["ffmpeg", "-hide_banner", "-encoders"], capture_output=True, text=True, timeout=30).stdout
    except Exception:
        return {"ffmpeg_libass": False, "ffmpeg_x264": False}
    has = lambda text, name: any(l.split()[1:2] == [name] for l in text.splitlines() if l.strip())
    return {"ffmpeg_libass": has(flt, "ass"), "ffmpeg_x264": has(enc, "libx264")}

def doctor():
    ok = _model_ok() and _has_onnx()
    return {**ffmpeg_caps(), "data_dir": DATA, "kokoro_model": _model_ok(), "kokoro_model_dir": MODEL_DIR,
            "onnxruntime_numpy": _has_onnx(), "ffmpeg": bool(shutil.which("ffmpeg")),
            "ffprobe": bool(shutil.which("ffprobe")), "engine": ENGINE if ok else None, "voice": VOICE}

def wav_duration(path):
    with wave.open(path, "rb") as w:
        return w.getnframes() / float(w.getframerate())

_K = {}

def _load():
    if _K:
        return _K
    import numpy as np, onnxruntime as ort
    so = ort.SessionOptions()
    so.intra_op_num_threads = max(1, min(4, os.cpu_count() or 2))
    _K["sess"] = ort.InferenceSession(os.path.join(MODEL_DIR, "model.onnx"), so, providers=["CPUExecutionProvider"])
    _K["voices"] = np.fromfile(os.path.join(MODEL_DIR, "voices.bin"), dtype=np.float32).reshape(-1, 510, 256)
    vocab = {}
    for line in open(os.path.join(MODEL_DIR, "tokens.txt"), encoding="utf-8").read().split("\n"):
        line = line.rstrip("\r")
        if not line:
            continue
        tok, _, idx = line.rpartition(" ")
        if idx.isdigit():
            vocab[tok if tok else " "] = int(idx)
    lex = {}
    for line in open(os.path.join(MODEL_DIR, "lexicon-us-en.txt"), encoding="utf-8"):
        parts = line.split()
        if len(parts) > 1 and parts[0] not in lex:
            lex[parts[0]] = parts[1:]
    _K["vocab"], _K["lex"] = vocab, lex
    return _K

LETTERS = {"a": "ay", "b": "bee", "c": "see", "d": "dee", "e": "ee", "f": "eff", "g": "gee", "h": "aitch", "i": "eye",
           "j": "jay", "k": "kay", "l": "el", "m": "em", "n": "en", "o": "oh", "p": "pea", "q": "queue", "r": "are",
           "s": "ess", "t": "tee", "u": "you", "v": "vee", "w": "double you", "x": "ex", "y": "why", "z": "zee"}
OVERRIDE = {"webxanupam": ["web", "zah", "new", "pum"], "arix": ["air", "ex"], "tiktok": ["tick", "tock"],
            "github": ["git", "hub"], "javascript": ["java", "script"], "youtube": ["you", "tube"]}
ONES = "zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen".split()
TENS = "_ _ twenty thirty forty fifty sixty seventy eighty ninety".split()
SUFFIX = (("ing", ["ɪ", "ŋ"]), ("ed", ["d"]), ("es", ["z"]), ("ly", ["l", "i"]), ("s", ["z"]))

def _num(n):
    if n < 20:
        return [ONES[n]]
    if n < 100:
        return [TENS[n // 10]] + ([ONES[n % 10]] if n % 10 else [])
    if n < 1000:
        return [ONES[n // 100], "hundred"] + (["and"] + _num(n % 100) if n % 100 else [])
    for size, name in ((10 ** 9, "billion"), (10 ** 6, "million"), (1000, "thousand")):
        if n >= size:
            return _num(n // size) + [name] + (_num(n % size) if n % size else [])
    return []

def _number_words(tok):
    t = tok.replace(",", "")
    if "." in t:
        whole, _, frac = t.partition(".")
        return _number_words(whole) + ["point"] + [ONES[int(c)] for c in frac if c.isdigit()]
    n = int(t)
    if 1100 <= n <= 2099 and n % 100 and not 2000 <= n <= 2009:
        return _num(n // 100) + (["oh"] if n % 100 < 10 else []) + _num(n % 100)
    return _num(n)

def _lookup(w, lex, depth=0):
    if w in OVERRIDE and depth == 0:
        out = []
        for p in OVERRIDE[w]:
            out += (_lookup(p, lex, 1) or _spell(p, lex)) + [" "]
        return out[:-1]
    if w in lex:
        return list(lex[w])
    if w.endswith("'s") and w[:-2] in lex:
        return list(lex[w[:-2]]) + ["z"]
    for suf, ph in SUFFIX:
        if w.endswith(suf) and len(w) - len(suf) >= 3:
            base = w[:-len(suf)]
            for b in (base, base + "e", base[:-1] if len(base) > 2 and base[-1] == base[-2] else None):
                if b and b in lex:
                    return list(lex[b]) + ph
    if depth < 3:
        for cut in range(len(w) - 3, 2, -1):
            head, tail = w[:cut], w[cut:]
            if head in lex:
                rest = _lookup(tail, lex, depth + 1)
                if rest:
                    return list(lex[head]) + [" "] + rest
    return None

def _spell(w, lex):
    out = []
    for c in w:
        if c in LETTERS:
            for part in LETTERS[c].split():
                out += list(lex.get(part, []))
            out.append(" ")
    return out[:-1] if out else []

def _word_phones(raw, lex):
    w = raw.lower().strip("'")
    if not w:
        return []
    ph = _lookup(w, lex)
    if ph is None:
        ph = _spell(w, lex)
    elif raw.isupper() and len(raw) <= 4 and w not in lex:
        ph = _spell(w, lex)
    return ph

TOKEN = re.compile(r"[A-Za-z]+(?:'[A-Za-z]+)*|\d+(?:[.,]\d+)*|[,.;:!?—…]")

def _ids(text, k):
    text = text.replace("–", "-").replace("’", "'").replace("-", " ").replace("/", " ").replace("&", " and ").replace("%", " percent")
    vocab, lex = k["vocab"], k["lex"]
    seq = []
    for m in TOKEN.findall(text):
        if m[0].isdigit():
            try:
                words = _number_words(m)
            except Exception:
                words = []
            parts = [p for w in words for p in (_lookup(w, lex) or []) + [" "]]
            ph = parts[:-1]
        elif m in ",.;:!?—…":
            if seq and seq[-1] == " ":
                seq.pop()
            seq.append(m)
            continue
        else:
            ph = _word_phones(m, lex)
        if not ph:
            continue
        if seq and seq[-1] not in (" ",):
            seq.append(" ")
        seq += ph
    return [vocab[p] for p in seq if p in vocab]

def _chunks(text, limit=300):
    out = []
    for p in re.split(r"(?<=[.!?;:])\s+", text.strip()):
        while len(p) > limit:
            cut = p.rfind(",", 0, limit)
            cut = cut if cut > 40 else p.rfind(" ", 0, limit)
            cut = cut if cut > 0 else limit
            out.append(p[:cut + 1].strip())
            p = p[cut + 1:]
        if p.strip():
            out.append(p.strip())
    return out

def _infer(ids, speed):
    import numpy as np
    k = _load()
    ids = ids[:509]
    style = k["voices"][SPEAKER][len(ids)].reshape(1, 256)
    tokens = np.array([[0] + ids + [0]], dtype=np.int64)
    audio = k["sess"].run(None, {"tokens": tokens, "style": style, "speed": np.array([speed], dtype=np.float32)})[0].reshape(-1)
    act = np.where(np.abs(audio) > 0.01 * max(float(np.abs(audio).max()), 1e-6))[0]
    if act.size:
        m = int(SR * 0.06)
        audio = audio[max(0, act[0] - m): act[-1] + m]
    return audio

def _write_wav(path, samples):
    import numpy as np
    pcm = (np.clip(samples, -1, 1) * 32767).astype("<i2")
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm.tobytes())

def _synth(text, out, speed):
    import numpy as np
    k = _load()
    gap = np.zeros(int(SR * 0.16), dtype=np.float32)
    pieces = []
    for chunk in _chunks(text):
        ids = _ids(chunk, k)
        if ids:
            pieces += [_infer(ids, speed), gap]
    if not pieces:
        raise RuntimeError("no phonemes produced")
    _write_wav(out, np.concatenate(pieces[:-1]))

def selftest():
    import numpy as np
    k = _load()
    ids = _ids("Hello, this is a test of Arix video studio in 2026.", k)
    a = _infer(ids, 1.0)
    rms = float(np.sqrt((a ** 2).mean()))
    print(json.dumps({"voice": VOICE, "ids": len(ids), "seconds": round(a.size / SR, 2), "rms": round(rms, 4)}))
    return a.size > SR * 0.5 and rms > 0.005

TARGET_RMS = 0.19

def _polish(path):
    try:
        import numpy as np
        with wave.open(path, "rb") as w:
            sr, n = w.getframerate(), w.getnframes()
            raw = w.readframes(n)
        a = np.frombuffer(raw, dtype="<i2").astype(np.float32) / 32768.0
        if len(a) < sr // 20:
            return
        hop = max(1, sr // 100)
        fr = a[: len(a) // hop * hop].reshape(-1, hop)
        rms = np.sqrt((fr ** 2).mean(axis=1))
        act = rms[rms > max(0.01, 0.25 * float(np.percentile(rms, 95)))]
        if len(act) < 5:
            return
        cur = float(np.sqrt((act ** 2).mean()))
        y = a * min(8.0, TARGET_RMS / max(cur, 1e-4))
        knee = 0.7
        m = np.abs(y) > knee
        y[m] = np.sign(y[m]) * (knee + (0.97 - knee) * np.tanh((np.abs(y[m]) - knee) / (0.97 - knee)))
        if sr == SR:
            _write_wav(path, y)
    except Exception:
        pass

def say(text, out, speed=1.0):
    """Write `text` to a WAV with am_puck. Returns (engine, seconds), or (None, None) if the model is missing."""
    if not (_model_ok() and _has_onnx()):
        print("[voice] Kokoro model or onnxruntime missing; run scripts/setup.sh", file=sys.stderr)
        return None, None
    try:
        _synth(text, out, float(speed))
        if os.path.isfile(out) and os.path.getsize(out) > 200:
            _polish(out)
            return ENGINE, wav_duration(out)
    except Exception as ex:
        print(f"[voice] synthesis failed: {ex}", file=sys.stderr)
    return None, None

if __name__ == "__main__":
    a = sys.argv[1:]
    if not a or a[0] == "doctor":
        print(json.dumps(doctor(), indent=2))
    elif a[0] == "selftest":
        sys.exit(0 if selftest() else 1)
    elif a[0] == "say" and len(a) >= 3:
        e, d = say(a[1], a[2], float(a[a.index("--speed") + 1]) if "--speed" in a else 1.0)
        print(json.dumps({"engine": e, "seconds": d, "voice": VOICE}))
    else:
        sys.exit(__doc__)
