"""popkit - the Video Studio renderer: live vector drawing, the presenter, captions and lip-sync."""
VERSION = "5.0.0"
