import math

DEFAULT_TINT = None
KINDS = ("beam", "frame", "card", "term", "check", "num", "chip", "search", "file", "bars", "ring", "spark", "globe", "badge")
_PASS = ("delay", "on", "in", "dur", "out", "out_at", "move", "loop", "amp", "speed", "rot", "opacity", "tilt", "persp", "scale")


def _lines(v):
    if v is None:
        return []
    if isinstance(v, (list, tuple)):
        return [str(x) for x in v]
    return [s for s in str(v).split("|") if s != ""]


def _f(sh, k, d):
    try:
        return float(sh.get(k, d))
    except Exception:
        return float(d)


def _group(sh, shapes):
    g = {"t": "group", "x": _f(sh, "x", 0), "y": _f(sh, "y", 0), "shapes": shapes}
    for k in _PASS:
        if k in sh:
            g[k] = sh[k]
    return g


def _glass(w, h, tint, glow=True, r=14, dim=False):
    d = {"t": "rect", "x": -w / 2, "y": -h / 2, "w": w, "h": h, "r": r, "grad": ["panel2", "panel"], "ga": [0.96, 0.96],
         "stroke": "dim" if dim else tint, "lw": 1.5}
    if glow and not dim:
        d.update(glow=tint, gr=11, gs=0.55)
    return d


_CID = [0]


def expand(kind, sh):
    tint = sh.get("tint") or (list(DEFAULT_TINT) if DEFAULT_TINT else "accent")
    fn = globals().get("_" + kind)
    if not fn:
        return None
    g = _group(sh, fn(sh, tint))
    _CID[0] += 1
    g["cid"] = _CID[0]
    g["ckind"] = kind
    return g


def _card(sh, tint):
    w, h = _f(sh, "w", 300), _f(sh, "h", 84)
    title, sub = str(sh.get("title", "")), str(sh.get("sub", ""))
    lines = _lines(sh.get("lines"))
    out = [_glass(w, h, tint)]
    out.append({"t": "circle", "cx": -w / 2 + 22, "cy": -h / 2 + (26 if (sub or lines) else h / 2), "r": 5, "fill": tint, "glow": tint, "gr": 5})
    ty = -h / 2 + (26 if (sub or lines) else h / 2)
    out.append({"t": "text", "x": -w / 2 + 38, "y": ty, "text": title, "size": 25, "kind": "sans", "anchor": "lm", "w": w - 56, "lines": 1, "fill": "white"})
    yy = ty + 24
    if sub:
        out.append({"t": "text", "x": -w / 2 + 38, "y": yy, "text": sub, "size": 13, "kind": "mono", "anchor": "lm", "w": w - 56, "lines": 1, "fill": "dim"})
        yy += 20
    for i, ln in enumerate(lines):
        out.append({"t": "text", "x": -w / 2 + 20, "y": yy + i * 19, "text": ln, "size": 13, "kind": "mono", "anchor": "lm", "w": w - 40, "lines": 1, "fill": "dim" if i else "soft", "in": "type", "delay": 0.35 + i * 0.45, "dur": 0.6})
    return out


def _term(sh, tint):
    w, h = _f(sh, "w", 330), _f(sh, "h", 190)
    lines = _lines(sh.get("lines"))
    out = [_glass(w, h, tint, dim=bool(sh.get("dim")))]
    for i, col in enumerate(("#ff5f57", "#febc2e", "#28c840")):
        out.append({"t": "circle", "cx": -w / 2 + 16 + i * 15, "cy": -h / 2 + 15, "r": 4.2, "fill": col})
    if sh.get("title"):
        out.append({"t": "text", "x": -w / 2 + 70, "y": -h / 2 + 15, "text": str(sh["title"]), "size": 12, "kind": "mono", "anchor": "lm", "w": w - 90, "lines": 1, "fill": "dim"})
    out.append({"t": "line", "pts": [[-w / 2 + 1, -h / 2 + 30], [w / 2 - 1, -h / 2 + 30]], "stroke": "dim", "lw": 0.8, "opacity": 0.5})
    step = _f(sh, "step", 0.9)
    for i, ln in enumerate(lines):
        pre = "> " if (i == 0 and sh.get("prompt", True)) else ""
        col = "soft" if i == 0 else ("mint" if ln.startswith("✓") or ln.startswith("v ") else "dim")
        out.append({"t": "text", "x": -w / 2 + 16, "y": -h / 2 + 52 + i * 24, "text": pre + ln, "size": 15, "kind": "mono", "anchor": "lm", "w": w - 30, "lines": 1,
                    "fill": col, "in": "type", "delay": 0.4 + i * step, "dur": min(1.6, 0.25 + 0.04 * len(ln))})
    return out


def _check(sh, tint):
    w, h = _f(sh, "w", 320), _f(sh, "h", 46)
    out = [_glass(w, h, tint)]
    out.append({"t": "circle", "cx": -w / 2 + 26, "cy": 0, "r": 10.5, "fill": sh.get("ok", "mint")})
    out.append({"t": "line", "pts": [[-w / 2 + 20.5, 0.5], [-w / 2 + 25, 5], [-w / 2 + 32, -4]], "stroke": "#0b0d12", "lw": 2.6})
    out.append({"t": "text", "x": -w / 2 + 48, "y": 0, "text": str(sh.get("text", sh.get("title", ""))), "size": 18, "kind": "mono", "anchor": "lm", "w": w - 64, "lines": 1, "fill": "white"})
    return out


def _num(sh, tint):
    size = _f(sh, "size", 120)
    out = [{"t": "text", "x": 0, "y": 0, "text": str(sh.get("text", "")), "size": size, "kind": "sans", "anchor": "mm", "w": _f(sh, "w", 360), "lines": 1,
            "fill": sh.get("color", "white"), "glow": sh.get("glow", tint), "gr": 16, "gs": 0.8, "extrude": _f(sh, "extrude", 8)}]
    if sh.get("label"):
        out.append({"t": "text", "x": 0, "y": size * 0.62, "text": str(sh["label"]).upper(), "size": 15, "kind": "mono", "anchor": "mm", "w": _f(sh, "w", 360), "lines": 1,
                    "fill": tint, "ls": 3.2})
    return out


def _chip(sh, tint):
    text = str(sh.get("text", ""))
    fs = _f(sh, "size", 13)
    k = fs / 13.0
    w = _f(sh, "w", max(70 * k, (12 + 9.2 * len(text) + 26) * k))
    h = _f(sh, "h", 28 * k)
    out = [_glass(w, h, tint, glow=bool(sh.get("glow", False)), r=h / 2 - 2, dim=not sh.get("hot"))]
    out.append({"t": "circle", "cx": -w / 2 + 13 * k, "cy": 0, "r": 3 * k, "fill": tint})
    out.append({"t": "text", "x": -w / 2 + 24 * k, "y": 0.5, "text": text, "size": fs, "kind": "mono", "anchor": "lm", "w": w - 32 * k, "lines": 1, "fill": "soft"})
    return out


def _search(sh, tint):
    w, h = _f(sh, "w", 340), _f(sh, "h", 46)
    out = [_glass(w, h, tint, r=h / 2)]
    out.append({"t": "circle", "cx": -w / 2 + 24, "cy": -1, "r": 6.5, "stroke": "soft", "lw": 2})
    out.append({"t": "line", "pts": [[-w / 2 + 29, 4], [-w / 2 + 34, 9]], "stroke": "soft", "lw": 2})
    out.append({"t": "text", "x": -w / 2 + 46, "y": 0, "text": str(sh.get("text", "")), "size": 17, "kind": "mono", "anchor": "lm", "w": w - 110, "lines": 1, "fill": "white",
                "in": "type", "dur": 1.0, "delay": 0.3})
    out.append({"t": "circle", "cx": w / 2 - 24, "cy": 0, "r": 15, "fill": tint, "glow": tint, "gr": 8, "gs": 0.6})
    out.append({"t": "poly", "pts": [[w / 2 - 30, 5], [w / 2 - 17, -1], [w / 2 - 30, -6], [w / 2 - 27, -0.5]], "fill": "#0b0d12"})
    return out


def _file(sh, tint):
    w, h = _f(sh, "w", 300), _f(sh, "h", 78)
    out = [_glass(w, h, tint)]
    out.append({"t": "rect", "x": -w / 2 + 14, "y": -h / 2 + 14, "w": 38, "h": h - 28, "r": 8, "fill": tint})
    for i in range(4):
        out.append({"t": "rect", "x": -w / 2 + 28, "y": -h / 2 + 18 + i * 8, "w": 10, "h": 4, "r": 1, "fill": "#0b0d12"})
    out.append({"t": "text", "x": -w / 2 + 66, "y": -8, "text": str(sh.get("name", sh.get("title", ""))), "size": 21, "kind": "sans", "anchor": "lm", "w": w - 84, "lines": 1, "fill": "white"})
    if sh.get("sub"):
        out.append({"t": "text", "x": -w / 2 + 66, "y": 15, "text": str(sh["sub"]), "size": 13, "kind": "mono", "anchor": "lm", "w": w - 84, "lines": 1, "fill": "dim"})
    return out


def _bars(sh, tint):
    w, h = _f(sh, "w", 300), _f(sh, "h", 160)
    vals = sh.get("vals") or [3, 5, 4, 7, 9]
    vals = [float(v) for v in (vals if isinstance(vals, (list, tuple)) else [vals])]
    mx = max(vals) or 1.0
    n = len(vals)
    gap = w / n
    bw = gap * 0.58
    out = [{"t": "line", "pts": [[-w / 2, h / 2], [w / 2, h / 2]], "stroke": "dim", "lw": 1.2}]
    labels = _lines(sh.get("labels"))
    for i, v in enumerate(vals):
        bh = max(4.0, (h - 8) * v / mx)
        cx = -w / 2 + gap * (i + 0.5)
        hot = i == n - 1 or sh.get("all")
        out.append({"t": "rect", "x": cx - bw / 2, "y": h / 2 - bh, "w": bw, "h": bh, "r": 4, "fill": tint if hot else "panel2", "stroke": tint if not hot else None,
                    "lw": 1.2, "glow": tint if hot else None, "gr": 9, "gs": 0.6, "in": "growy", "pivot": [cx, h / 2], "delay": 0.12 * i, "dur": 0.55})
        if i < len(labels):
            out.append({"t": "text", "x": cx, "y": h / 2 + 16, "text": labels[i], "size": 12, "kind": "mono", "anchor": "mm", "w": gap - 4, "lines": 1, "fill": "dim", "in": "fade", "delay": 0.12 * i})
    return out


def _ring(sh, tint):
    r = _f(sh, "r", 60)
    pct = max(0.0, min(1.0, _f(sh, "pct", 0.75)))
    pts = []
    n = max(8, int(60 * pct))
    for i in range(n + 1):
        a = math.radians(-90 + 360 * pct * i / n)
        pts.append([round(r * math.cos(a), 1), round(r * math.sin(a), 1)])
    out = [{"t": "circle", "cx": 0, "cy": 0, "r": r, "stroke": "panel2", "lw": 9},
           {"t": "line", "pts": pts, "stroke": tint, "lw": 9, "glow": tint, "gr": 8, "gs": 0.7, "in": "draw", "dur": 0.9}]
    if sh.get("text") is not None:
        out.append({"t": "text", "x": 0, "y": 0, "text": str(sh["text"]), "size": r * 0.62, "kind": "sans", "anchor": "mm", "w": r * 1.5, "lines": 1, "fill": "white", "in": "fade", "delay": 0.3})
    return out


def _spark(sh, tint):
    w, h = _f(sh, "w", 300), _f(sh, "h", 110)
    vals = sh.get("vals") or [2, 3, 2.5, 4, 5, 4.5, 7, 9]
    vals = [float(v) for v in (vals if isinstance(vals, (list, tuple)) else [vals])]
    lo, hi = min(vals), max(vals)
    span = (hi - lo) or 1.0
    n = len(vals)
    pts = [[round(-w / 2 + w * i / (n - 1), 1), round(h / 2 - h * (v - lo) / span, 1)] for i, v in enumerate(vals)]
    out = [{"t": "line", "pts": pts, "stroke": tint, "lw": 3.4, "glow": tint, "gr": 8, "gs": 0.7, "in": "draw", "dur": 1.1},
           {"t": "circle", "cx": pts[-1][0], "cy": pts[-1][1], "r": 5.5, "fill": "white", "glow": tint, "gr": 7, "in": "pop", "delay": 1.1}]
    return out


def _globe(sh, tint):
    r = _f(sh, "r", 50)
    out = [{"t": "circle", "cx": 0, "cy": 0, "r": r, "stroke": tint, "lw": 1.8, "glow": tint, "gr": 6, "gs": 0.5}]
    for k in (0.35, 0.7):
        out.append({"t": "ellipse", "cx": 0, "cy": 0, "rx": r * k, "ry": r, "stroke": tint, "lw": 1.1, "opacity": 0.75})
    for k in (-0.55, 0.0, 0.55):
        out.append({"t": "ellipse", "cx": 0, "cy": r * k, "rx": r * math.sqrt(max(0.05, 1 - k * k)), "ry": r * 0.16, "stroke": tint, "lw": 1.1, "opacity": 0.75})
    return out


def _badge(sh, tint):
    text = str(sh.get("text", ""))
    w = _f(sh, "w", 12 + 11 * len(text) + 30)
    h = _f(sh, "h", 34)
    return [{"t": "rect", "x": -w / 2, "y": -h / 2, "w": w, "h": h, "r": 9, "fill": tint, "glow": tint, "gr": 9, "gs": 0.6},
            {"t": "text", "x": 0, "y": 1, "text": text, "size": 18, "kind": "sans", "anchor": "mm", "w": w - 16, "lines": 1, "fill": "#0b0d12"}]


def _beam(sh, tint):
    w, h = _f(sh, "w", 260), _f(sh, "h", 380)
    return [{"t": "poly", "pts": [[-w * 0.12, -h / 2], [w * 0.12, -h / 2], [w / 2, h / 2], [-w / 2, h / 2]], "grad": [tint, "bg"], "ga": [0.34, 0.0]}]


def _frame(sh, tint):
    w, h = _f(sh, "w", 320), _f(sh, "h", 400)
    L = _f(sh, "len", 34)
    out = []
    for sx in (-1, 1):
        for sy in (-1, 1):
            cx, cy = sx * w / 2, sy * h / 2
            out.append({"t": "line", "pts": [[cx - sx * L, cy], [cx, cy], [cx, cy - sy * L]], "stroke": tint, "lw": 3, "glow": tint, "gr": 6, "gs": 0.6,
                        "in": "grow", "delay": 0.05 * (sx + 1) + 0.03 * (sy + 1)})
    return out
