import re
import shlex


def _norm(w):
    return re.sub(r"[^\w]", "", str(w), flags=re.UNICODE).lower()


def _q(s, bar=False):
    s = re.sub(r"[\"'=" + ("" if bar else "|") + "]", "", str(s)).strip()
    return shlex.quote(s)


class Ctx:
    def __init__(self, tokens, hits, W, H):
        self.tokens = tokens
        self.hits = hits
        self.W = W
        self.H = H

    def kw(self, n=0, cap=14, default="idea"):
        if not self.hits:
            return default
        t = self.tokens[self.hits[min(n, len(self.hits) - 1)]]
        t = re.sub(r"^[^\w]+|[^\w]+$", "", t, flags=re.UNICODE).lower()
        return t[:cap] or default

    def on(self, n=0):
        if not self.hits:
            return "0"
        i = self.hits[min(n, len(self.hits) - 1)]
        w = _norm(self.tokens[i])
        return str(i) if (not w or w.isdigit()) else _q(self.tokens[i])

    def x(self, f):
        return int(self.W * f)

    def y(self, f):
        return int(self.H * f)

    def box(self, fx, fy, fw, fh, r=8, f="accent", n=0, extra=""):
        w, h = self.W * fw, self.H * fh
        return "r %d %d %d %d %d f=%s %s" % (self.W * fx - w / 2, self.H * fy - h / 2, w, h, r, f, extra)

    def dot(self, fx, fy, fr, f="accent", n=0, extra=""):
        return "c %d %d %d f=%s %s" % (self.W * fx, self.H * fy, self.H * fr, f, extra)

    def line(self, fx1, fy1, fx2, fy2, s="accent", w=2, n=0, extra=""):
        return "l %d %d %d %d s=%s w=%s in=draw %s" % (self.W * fx1, self.H * fy1, self.W * fx2, self.H * fy2, s, w, extra)

    def text(self, fx, fy, text, size=18, f="white", n=0, mw=0.3, extra=""):
        return "t %d %d %s %d w=%d f=%s %s" % (self.W * fx, self.H * fy, _q(text), size, self.W * mw, f, extra)

    def chip(self, fx, fy, text=None, hot=1, n=0, delay=0.1):
        return "chip %d %d %s size=19 hot=%d on=%s in=drop delay=%.2f" % (self.W * fx, self.H * fy, _q(text if text is not None else self.kw(n)), hot, self.on(n), delay)

    def bars(self, fx, fy, fw, fh, vals, n=0, extra=""):
        return "bars %d %d %d %d vals=%s on=%s %s" % (self.W * fx, self.H * fy, self.W * fw, self.H * fh, vals, self.on(n), extra)

    def comp(self, kind, fx, fy, fw=None, fh=None, n=0, extra=""):
        parts = [kind, str(self.x(fx)), str(self.y(fy))]
        if fw is not None:
            parts.append(str(int(self.W * fw)))
        if fh is not None:
            parts.append(str(int(self.H * fh)))
        return " ".join(parts) + " on=%s %s" % (self.on(n), extra)


def _blog_post(c):
    return [
        c.box(0.5, 0.5, 0.66, 0.86, 14, "panel2", 0, "s=accent w=2 glow=accent"),
        c.box(0.5, 0.3, 0.58, 0.3, 8, "accent2", 0, "o=0.55 in=rise"),
        c.dot(0.34, 0.24, 0.07, "gold", 0, "in=pop dl=0.3"),
        "p %d %d %d %d %d %d f=accent o=0.8 in=rise dl=0.2" % (c.W * 0.3, c.H * 0.45, c.W * 0.45, c.H * 0.25, c.W * 0.6, c.H * 0.45),
        c.box(0.5, 0.58, 0.5, 0.045, 3, "white", 0, "in=left dl=0.4"),
        c.box(0.46, 0.66, 0.42, 0.03, 3, "dim", 0, "in=left dl=0.55"),
        c.box(0.48, 0.73, 0.46, 0.03, 3, "dim", 0, "in=left dl=0.7"),
        "badge %d %d PUBLISH on=%s in=pop dl=0.9" % (c.W * 0.5, c.H * 0.89, c.on(0)),
    ], "THE BLOG POST"


def _blogger_theme(c):
    out = [
        c.box(0.42, 0.5, 0.74, 0.82, 12, "panel2", 0, "s=accent w=2 glow=accent"),
        c.box(0.42, 0.2, 0.7, 0.1, 6, "accent", 0, "in=rise"),
        c.box(0.62, 0.5, 0.3, 0.5, 6, "dim", 0, "o=0.5 in=right dl=0.2"),
        c.box(0.27, 0.42, 0.34, 0.2, 6, "accent2", 0, "o=0.7 in=pop dl=0.3"),
        c.box(0.27, 0.66, 0.34, 0.2, 6, "accent3", 0, "o=0.7 in=pop dl=0.45"),
    ]
    for i, col in enumerate(("accent", "accent2", "accent3", "accent4")):
        out.append(c.dot(0.92, 0.22 + 0.17 * i, 0.055, col, 0, "in=pop dl=%.2f s=white w=1.5" % (0.5 + 0.12 * i)))
    out.append(c.chip(0.42, 0.93, c.kw(0), 1, 0))
    return out, "THE THEME"


def _blog_layout(c):
    out = [
        c.box(0.5, 0.13, 0.84, 0.14, 8, "accent", 0, "in=rise"),
        c.box(0.3, 0.5, 0.5, 0.42, 8, "panel2", 0, "s=accent2 w=2 in=left dl=0.2"),
        c.box(0.74, 0.5, 0.24, 0.42, 8, "panel2", 0, "s=accent3 w=2 in=right dl=0.3"),
        c.box(0.5, 0.87, 0.84, 0.1, 8, "dim", 0, "o=0.6 in=rise dl=0.4"),
        c.text(0.5, 0.13, "header", 16, "bg", 0, 0.3),
        c.text(0.3, 0.5, "posts", 16, "white", 0, 0.3),
        c.text(0.74, 0.5, "widgets", 14, "white", 0, 0.2),
        c.text(0.5, 0.87, c.kw(0), 14, "white", 0, 0.3),
    ]
    return out, "THE LAYOUT"


def _seo(c):
    return [
        c.comp("search", 0.5, 0.17, 0.84, None, 0, "text=%s" % _q(c.kw(0, 22))),
        c.bars(0.3, 0.62, 0.4, 0.5, "9,6,4,2", 0, "labels=1st|2nd|3rd|4th"),
        c.comp("ring", 0.77, 0.6, None, None, 1, "r=%d pct=0.82 text=%s" % (c.H * 0.22, _q("TOP"))),
        c.chip(0.77, 0.93, c.kw(1), 1, 1),
    ], "GET FOUND"


def _traffic(c):
    return [
        "spark %d %d %d %d vals=2,3,2.6,4,5.2,4.8,7,9 tint=mint on=%s" % (c.W * 0.5, c.H * 0.52, c.W * 0.8, c.H * 0.55, c.on(0)),
        "badge %d %d %s on=%s in=drop" % (c.W * 0.28, c.H * 0.1, _q(c.kw(0, 14).upper()), c.on(0)),
        c.chip(0.74, 0.1, c.kw(1), 0, 1),
    ], "MORE VISITORS"


def _earn(c):
    out = []
    for i, (fx, fy) in enumerate(((0.3, 0.7), (0.46, 0.58), (0.62, 0.46), (0.78, 0.34))):
        out.append(c.dot(fx, fy, 0.1, "gold", 0, "s=white w=2 in=pop dl=%.2f glow=gold" % (0.2 * i)))
        out.append(c.text(fx, fy, "$", 26, "bg", 0, 0.1, "dl=%.2f" % (0.2 * i)))
    out.append(c.line(0.22, 0.86, 0.86, 0.16, "mint", 3, 0))
    out.append(c.chip(0.5, 0.93, c.kw(0), 1, 0))
    return out, "EARN FROM IT"


def _domain(c):
    return [
        c.comp("search", 0.5, 0.2, 0.84, None, 0, "text=%s" % _q(c.kw(0, 14) + ".com")),
        c.comp("globe", 0.5, 0.62, None, None, 0, "r=%d" % (c.H * 0.24)),
        c.chip(0.18, 0.84, c.kw(1), 0, 1),
        c.chip(0.82, 0.84, "online", 1, 0),
    ], "GO ONLINE"


def _html_css(c):
    return [
        c.comp("term", 0.27, 0.5, 0.46, 0.72, 0, "title=index.html lines=%s step=0.6" % _q("<div class=card>|<h1>hello</h1>|</div>", True)),
        c.comp("term", 0.76, 0.5, 0.4, 0.72, 1, "title=style.css lines=%s step=0.6" % _q(".card {|color: pink;|}", True)),
        c.chip(0.5, 0.93, c.kw(0), 1, 0),
    ], "HTML + CSS"


def _js_code(c):
    return [
        c.comp("term", 0.5, 0.46, 0.84, 0.72, 0, "title=script.js lines=%s step=0.7" % _q("function %s() {|  return true;|}" % (re.sub(r"\W", "", c.kw(0, 12, True)) or "run"))),
        c.chip(0.28, 0.9, "{ }", 1, 0),
        c.chip(0.72, 0.9, c.kw(1), 0, 1),
    ], "THE CODE"


def _js_dom(c):
    out = [c.dot(0.5, 0.15, 0.07, "accent", 0, "in=pop")]
    kids = ((0.26, 0.45), (0.74, 0.45))
    for i, (fx, fy) in enumerate(kids):
        out.append(c.line(0.5, 0.15, fx, fy, "accent2", 2, 0, "dl=%.2f" % (0.2 + 0.2 * i)))
        out.append(c.dot(fx, fy, 0.06, "accent2", 0, "in=pop dl=%.2f" % (0.3 + 0.2 * i)))
    for i, fx in enumerate((0.12, 0.4, 0.6, 0.88)):
        px = kids[0][0] if i < 2 else kids[1][0]
        out.append(c.line(px, 0.45, fx, 0.75, "accent3", 2, 0, "dl=%.2f" % (0.5 + 0.1 * i)))
        out.append(c.dot(fx, 0.75, 0.05, "accent3", 0, "in=pop dl=%.2f" % (0.6 + 0.1 * i)))
    out.append(c.chip(0.5, 0.93, c.kw(0), 1, 0))
    return out, "THE PAGE TREE"


def _js_async(c):
    out = []
    for i, (fx, label) in enumerate(((0.17, "call"), (0.5, "wait"), (0.83, "then"))):
        out.append(c.comp("card", fx, 0.42, 0.28, 0.3, 0, "title=%s in=pop delay=%.2f" % (label, 0.2 * i)))
        if i:
            out.append(c.line(fx - 0.19, 0.42, fx - 0.15, 0.42, "accent", 3, 0, "dl=%.2f" % (0.2 * i)))
    out.append(c.dot(0.5, 0.74, 0.04, "gold", 0, "loop=pulse"))
    out.append(c.chip(0.5, 0.92, c.kw(0), 1, 0))
    return out, "ASYNC"


def _js_events(c):
    return [
        c.box(0.26, 0.45, 0.28, 0.2, 10, "accent", 0, "in=pop glow=accent"),
        c.text(0.26, 0.45, "click", 20, "bg", 0, 0.24),
        c.line(0.42, 0.45, 0.58, 0.45, "mint", 3, 0, "dl=0.3"),
        c.comp("term", 0.77, 0.45, 0.38, 0.5, 1, "title=handler lines=%s step=0.6" % _q("onclick()|run()", True)),
        c.chip(0.5, 0.88, c.kw(0), 1, 0),
    ], "EVENTS"


def _api(c):
    return [
        c.comp("card", 0.2, 0.3, 0.3, 0.26, 0, "title=client in=left"),
        c.comp("card", 0.8, 0.3, 0.3, 0.26, 1, "title=server in=right"),
        c.line(0.36, 0.26, 0.64, 0.26, "accent", 3, 0, "dl=0.3"),
        c.line(0.64, 0.36, 0.36, 0.36, "mint", 3, 1, "dl=0.6"),
        c.comp("term", 0.5, 0.74, 0.7, 0.34, 1, "title=response.json lines=%s step=0.6" % _q("{ \"ok\": true }|{ \"data\": [] }", True)),
    ], "API CALL"


def _ai_neural(c):
    out = []
    layers = ((0.2, 3), (0.5, 4), (0.8, 2))
    pts = []
    for fx, n in layers:
        col = [(fx, 0.2 + 0.6 * (k + 0.5) / n) for k in range(n)]
        pts.append(col)
    for a, b in zip(pts, pts[1:]):
        for (x1, y1) in a:
            for (x2, y2) in b:
                out.append(c.line(x1, y1, x2, y2, "dim", 1, 0, "o=0.6"))
    for li, col in enumerate(pts):
        for k, (x, y) in enumerate(col):
            out.append(c.dot(x, y, 0.055, ("accent", "accent2", "mint")[li], 0, "in=pop dl=%.2f glow=accent" % (0.1 * (li * 3 + k))))
    out.append(c.chip(0.5, 0.94, c.kw(0), 1, 0))
    return out, "HOW AI THINKS"


def _ai_chat(c):
    return [
        c.box(0.34, 0.24, 0.5, 0.2, 14, "dim", 0, "in=left"),
        c.text(0.34, 0.24, c.kw(0, 18), 18, "white", 0, 0.44),
        c.box(0.66, 0.52, 0.5, 0.2, 14, "accent", 1, "in=right dl=0.4 glow=accent"),
        c.text(0.66, 0.52, "...", 24, "bg", 1, 0.3, "loop=blink"),
        c.box(0.34, 0.8, 0.5, 0.2, 14, "dim", 1, "in=left dl=0.9"),
        c.text(0.34, 0.8, c.kw(1, 18), 18, "white", 1, 0.44, "dl=0.9"),
    ], "AI CHAT"


def _ai_prompt(c):
    return [
        c.comp("card", 0.17, 0.42, 0.28, 0.3, 0, "title=prompt in=left"),
        c.comp("ring", 0.5, 0.42, None, None, 1, "r=%d pct=0.9 text=AI" % (c.H * 0.2)),
        c.comp("card", 0.83, 0.42, 0.28, 0.3, 1, "title=answer in=right delay=0.5"),
        c.line(0.32, 0.42, 0.4, 0.42, "accent", 3, 0),
        c.line(0.6, 0.42, 0.68, 0.42, "mint", 3, 1, "dl=0.5"),
        c.chip(0.5, 0.86, c.kw(0), 1, 0),
    ], "PROMPT TO ANSWER"


def _ai_agent(c):
    out = [c.dot(0.5, 0.5, 0.13, "accent", 0, "in=pop glow=accent"), c.text(0.5, 0.5, "AI", 28, "bg", 0, 0.15)]
    for i, (fx, fy, label) in enumerate(((0.16, 0.16, "search"), (0.84, 0.16, "code"), (0.16, 0.84, "files"), (0.84, 0.84, "web"))):
        out.append(c.line(0.5, 0.5, fx, fy, "accent2", 2, 0, "dl=%.2f" % (0.2 + 0.15 * i)))
        out.append(c.chip(fx, fy, label, 0, 0, 0.2 + 0.15 * i))
    out.append(c.chip(0.5, 0.93, c.kw(0), 1, 0))
    return out, "AI WITH TOOLS"


def _ai_image(c):
    return [
        c.box(0.5, 0.42, 0.62, 0.66, 14, "panel2", 0, "s=accent w=2 glow=accent"),
        c.dot(0.38, 0.28, 0.07, "gold", 0, "in=pop dl=0.4"),
        "p %d %d %d %d %d %d f=accent2 o=0.85 in=rise dl=0.3" % (c.W * 0.26, c.H * 0.64, c.W * 0.42, c.H * 0.36, c.W * 0.58, c.H * 0.64),
        "p %d %d %d %d %d %d f=accent o=0.85 in=rise dl=0.45" % (c.W * 0.48, c.H * 0.64, c.W * 0.62, c.H * 0.44, c.W * 0.74, c.H * 0.64),
        c.comp("search", 0.5, 0.88, 0.8, None, 0, "text=%s" % _q(c.kw(0, 20))),
    ], "AI IMAGE"


def _ai_training(c):
    return [
        c.comp("file", 0.2, 0.3, 0.3, None, 0, "name=data.csv sub=examples"),
        c.comp("ring", 0.2, 0.74, None, None, 1, "r=%d pct=0.7 text=learn" % (c.H * 0.16)),
        "spark %d %d %d %d vals=9,7.6,6,4.5,3.2,2.2,1.6 tint=mint on=%s" % (c.W * 0.64, c.H * 0.5, c.W * 0.55, c.H * 0.6, c.on(1)),
        c.chip(0.64, 0.9, c.kw(0), 1, 0),
    ], "TRAINING"


def _security(c):
    return [
        "p %d %d %d %d %d %d %d %d %d %d %d %d f=accent s=white w=2 glow=accent on=%s in=pop" % (
            c.W * 0.5, c.H * 0.1, c.W * 0.72, c.H * 0.2, c.W * 0.72, c.H * 0.55, c.W * 0.5, c.H * 0.86, c.W * 0.28, c.H * 0.55, c.W * 0.28, c.H * 0.2, c.on(0)),
        c.box(0.5, 0.52, 0.14, 0.2, 5, "bg", 0, "dl=0.3"),
        c.dot(0.5, 0.44, 0.045, "bg", 0, "s=white w=3 dl=0.3"),
        c.chip(0.5, 0.95, c.kw(0), 1, 0),
    ], "STAY SAFE"


def _database(c):
    out = []
    for i, fy in enumerate((0.7, 0.5, 0.3)):
        out.append(c.box(0.5, fy, 0.34, 0.14, 4, "accent2" if i % 2 else "accent", 0, "in=rise dl=%.2f" % (0.15 * i)))
        out.append("e %d %d %d %d f=accent3 o=0.9 on=%s dl=%.2f" % (c.W * 0.5, c.H * (fy - 0.07), c.W * 0.17, c.H * 0.035, c.on(0), 0.15 * i))
    out.append(c.chip(0.5, 0.92, c.kw(0), 1, 0))
    return out, "WHERE DATA LIVES"


def _cloud(c):
    return [
        c.dot(0.4, 0.26, 0.11, "accent", 0, "in=pop"),
        c.dot(0.52, 0.2, 0.14, "accent", 0, "in=pop dl=0.1"),
        c.dot(0.64, 0.28, 0.1, "accent", 0, "in=pop dl=0.2"),
        c.box(0.52, 0.32, 0.34, 0.1, 6, "accent", 0, "dl=0.2"),
        c.box(0.5, 0.74, 0.3, 0.1, 6, "panel2", 0, "s=accent2 w=2 in=rise dl=0.4"),
        c.box(0.5, 0.88, 0.3, 0.1, 6, "panel2", 0, "s=accent2 w=2 in=rise dl=0.55"),
        c.line(0.5, 0.4, 0.5, 0.67, "mint", 3, 0, "dl=0.4"),
        c.chip(0.82, 0.8, c.kw(0), 1, 0),
    ], "IN THE CLOUD"


def _git(c):
    out = [c.line(0.12, 0.35, 0.88, 0.35, "accent", 4, 0), c.line(0.35, 0.35, 0.5, 0.7, "accent2", 4, 0, "dl=0.3"), c.line(0.5, 0.7, 0.75, 0.7, "accent2", 4, 0, "dl=0.4"), c.line(0.75, 0.7, 0.88, 0.35, "accent2", 4, 0, "dl=0.5")]
    for i, (fx, fy, col) in enumerate(((0.12, 0.35, "accent"), (0.35, 0.35, "accent"), (0.62, 0.35, "accent"), (0.88, 0.35, "mint"), (0.5, 0.7, "accent2"), (0.75, 0.7, "accent2"))):
        out.append(c.dot(fx, fy, 0.055, col, 0, "in=pop s=white w=2 dl=%.2f" % (0.1 * i)))
    out.append(c.chip(0.5, 0.92, c.kw(0), 1, 0))
    return out, "VERSIONS"


def _responsive(c):
    return [
        c.box(0.5, 0.45, 0.5, 0.52, 8, "panel2", 0, "s=accent w=2 in=rise"),
        c.box(0.5, 0.45, 0.44, 0.4, 4, "accent2", 0, "o=0.5 dl=0.2"),
        c.box(0.5, 0.78, 0.62, 0.05, 3, "dim", 0, "dl=0.3"),
        c.box(0.15, 0.62, 0.14, 0.4, 8, "panel2", 0, "s=accent3 w=2 in=left dl=0.4"),
        c.box(0.85, 0.66, 0.2, 0.32, 8, "panel2", 0, "s=accent4 w=2 in=right dl=0.5"),
        c.chip(0.5, 0.94, c.kw(0), 1, 0),
    ], "ANY SCREEN"


def _speed(c):
    return [
        c.comp("ring", 0.5, 0.46, None, None, 0, "r=%d pct=0.95 text=%s tint=mint" % (c.H * 0.3, _q("FAST"))),
        "p %d %d %d %d %d %d %d %d f=gold glow=gold in=pop dl=0.5 on=%s" % (c.W * 0.5, c.H * 0.2, c.W * 0.46, c.H * 0.5, c.W * 0.5, c.H * 0.5, c.W * 0.48, c.H * 0.72, c.on(0)),
        c.chip(0.5, 0.94, c.kw(0), 1, 0),
    ], "SPEED"


def _video(c):
    return [
        c.box(0.5, 0.42, 0.7, 0.56, 14, "panel2", 0, "s=accent w=2 glow=accent"),
        "p %d %d %d %d %d %d f=red on=%s in=pop dl=0.3" % (c.W * 0.46, c.H * 0.3, c.W * 0.46, c.H * 0.54, c.W * 0.6, c.H * 0.42, c.on(0)),
        c.box(0.5, 0.78, 0.7, 0.03, 2, "dim", 0, "in=left dl=0.4"),
        c.box(0.36, 0.78, 0.42, 0.03, 2, "red", 0, "in=left dl=0.6"),
        c.chip(0.5, 0.92, c.kw(0), 1, 0),
    ], "ON VIDEO"


def _social(c):
    out = []
    pts = ((0.5, 0.5), (0.2, 0.24), (0.8, 0.24), (0.2, 0.78), (0.8, 0.78))
    for i, (fx, fy) in enumerate(pts[1:]):
        out.append(c.line(0.5, 0.5, fx, fy, "accent2", 2, 0, "dl=%.2f" % (0.15 * i)))
    for i, (fx, fy) in enumerate(pts):
        out.append(c.dot(fx, fy, 0.085 if i == 0 else 0.065, ("accent", "accent2", "accent3", "accent4", "mint")[i], 0, "in=pop dl=%.2f" % (0.12 * i)))
    out.append(c.chip(0.5, 0.94, c.kw(0), 1, 0))
    return out, "SHARE IT"


def _email(c):
    return [
        c.box(0.5, 0.48, 0.62, 0.52, 10, "panel2", 0, "s=accent w=2 glow=accent"),
        "l %d %d %d %d %d %d s=accent w=3 on=%s in=draw" % (c.W * 0.19, c.H * 0.24, c.W * 0.5, c.H * 0.5, c.W * 0.81, c.H * 0.24, c.on(0)),
        c.box(0.5, 0.64, 0.4, 0.03, 2, "dim", 0, "dl=0.4"),
        c.box(0.46, 0.7, 0.32, 0.03, 2, "dim", 0, "dl=0.5"),
        c.chip(0.5, 0.9, c.kw(0), 1, 0),
    ], "IN THE INBOX"


def _workflow(c):
    out = []
    for i, (fx, label) in enumerate(((0.15, "start"), (0.38, "step"), (0.62, "step"), (0.85, "done"))):
        out.append(c.comp("card", fx, 0.42, 0.2, 0.24, 0, "title=%s in=pop delay=%.2f" % (label, 0.2 * i)))
        if i:
            out.append(c.line(fx - 0.125, 0.42, fx - 0.1, 0.42, "mint", 3, 0, "dl=%.2f" % (0.2 * i)))
    out.append(c.dot(0.5, 0.76, 0.07, "accent2", 0, "loop=spin s=white w=3 o=0.8"))
    out.append(c.chip(0.5, 0.94, c.kw(0), 1, 0))
    return out, "AUTOMATE IT"


def _mobile(c):
    out = [c.box(0.5, 0.5, 0.3, 0.9, 20, "panel2", 0, "s=accent w=3 glow=accent in=rise")]
    for i in range(6):
        out.append(c.box(0.42 + 0.16 * (i % 2), 0.3 + 0.18 * (i // 2), 0.11, 0.12, 8, ("accent", "accent2", "accent3", "accent4", "mint", "gold")[i], 0, "in=pop dl=%.2f" % (0.12 * i)))
    out.append(c.chip(0.86, 0.5, c.kw(0), 1, 0))
    return out, "THE APP"


def _bug(c):
    return [
        c.comp("term", 0.5, 0.4, 0.8, 0.5, 0, "title=console lines=%s step=0.6" % _q("run|error: undefined|fix applied", True)),
        c.dot(0.18, 0.82, 0.07, "red", 0, "in=pop dl=0.4 glow=red"),
        c.line(0.18, 0.82, 0.3, 0.82, "red", 2, 0, "dl=0.5"),
        c.chip(0.56, 0.86, c.kw(0), 1, 0),
    ], "FIND THE BUG"


def _dashboard(c):
    return [
        c.comp("ring", 0.2, 0.3, None, None, 0, "r=%d pct=0.75 text=KPI" % (c.H * 0.18)),
        c.bars(0.62, 0.32, 0.5, 0.4, "3,5,4,7,9", 0),
        "spark %d %d %d %d vals=2,4,3,6,5,8,9 tint=mint on=%s" % (c.W * 0.5, c.H * 0.76, c.W * 0.84, c.H * 0.3, c.on(0)),
        c.chip(0.5, 0.95, c.kw(0), 1, 0),
    ], "THE NUMBERS"


def _shop(c):
    return [
        c.box(0.5, 0.5, 0.4, 0.28, 6, "accent", 0, "in=rise glow=accent"),
        c.line(0.2, 0.28, 0.3, 0.28, "white", 4, 0),
        c.line(0.3, 0.28, 0.34, 0.5, "white", 4, 0, "dl=0.2"),
        c.dot(0.4, 0.76, 0.055, "white", 0, "in=pop dl=0.3"),
        c.dot(0.62, 0.76, 0.055, "white", 0, "in=pop dl=0.4"),
        c.chip(0.5, 0.92, c.kw(0), 1, 0),
    ], "ONLINE STORE"


def _tools(c):
    out = []
    for i, label in enumerate(("plan", "build", "ship")):
        out.append("check %d %d w=%d text=%s on=%s in=slide delay=%.2f" % (c.W * 0.5, c.H * (0.22 + 0.27 * i), c.W * 0.8, _q(label + " " + c.kw(0, 12)), c.on(0), 0.2 * i))
    return out, "THE TOOLKIT"


def _keywords(c):
    out = []
    spots = ((0.3, 0.3), (0.7, 0.28), (0.2, 0.6), (0.6, 0.55), (0.82, 0.72), (0.4, 0.82))
    for i, (fx, fy) in enumerate(spots[:max(3, min(len(c.hits), 6))]):
        k = i % max(1, len(c.hits))
        out.append(c.chip(fx, fy, c.kw(k, 12) if i < len(c.hits) else ["ideas", "topics", "niche"][i % 3], 1 if i == 0 else 0, k, 0.1 * i))
    return out, "KEYWORDS"


LIBRARY = [
    ("blog_post", _blog_post, "blogger blogspot blog blogs blogging blogpost post posts article articles publish writer writing", "write writes written content author draft"),
    ("blogger_theme", _blogger_theme, "theme themes template templates xml skin design designs", "layout style styles colors color custom customize"),
    ("blog_layout", _blog_layout, "layout widget widgets sidebar header footer gadget gadgets navbar menu", "section sections page pages"),
    ("seo", _seo, "seo ranking rank ranks google keyword keywords organic serp indexing index", "search searches found results"),
    ("traffic", _traffic, "traffic visitors visitor views pageviews audience readers reach", "grow growth more users"),
    ("earn", _earn, "adsense monetize monetization earn earning earnings income affiliate sponsor sponsors", "money revenue profit"),
    ("domain", _domain, "domain domains hosting host url website websites dns custom", "online site sites"),
    ("html_css", _html_css, "html css stylesheet styling markup tag tags", "page web style"),
    ("js_code", _js_code, "javascript js typescript node nodejs function functions script scripts", "code coding program programming developer"),
    ("js_dom", _js_dom, "dom document element elements queryselector tree nodes node", "page html browser"),
    ("js_async", _js_async, "async await promise promises callback callbacks asynchronous timeout fetching", "wait then later"),
    ("js_events", _js_events, "event events click clicks onclick listener listeners button buttons", "handler handle"),
    ("api", _api, "api apis endpoint endpoints rest request requests response http fetch json", "server client data"),
    ("ai_neural", _ai_neural, "neural network networks deep learning machine ml brain", "model models layers"),
    ("ai_chat", _ai_chat, "chatbot chatgpt chat assistant llm gpt claude gemini conversation", "ai talk reply ask asks"),
    ("ai_prompt", _ai_prompt, "prompt prompts prompting instruction instructions", "ai answer output generate generates"),
    ("ai_agent", _ai_agent, "agent agents agentic autonomous", "ai automate"),
    ("ai_image", _ai_image, "midjourney diffusion text-to-image illustration illustrations generated image images artwork", "ai picture pictures photo"),
    ("ai_training", _ai_training, "training train trained dataset datasets finetune fine-tune epoch epochs", "ai model learn learns data"),
    ("security", _security, "security secure shield encryption encrypted password passwords hacker hackers hacking privacy firewall", "safe protect protection"),
    ("database", _database, "database databases sql storage mysql mongodb", "data store stored"),
    ("cloud", _cloud, "cloud server servers aws azure deploy deployment hosting", "online host"),
    ("git", _git, "git github commit commits branch branches repository repo merge version", "code source"),
    ("responsive", _responsive, "responsive mobile-friendly devices desktop tablet screen screens", "phone laptop"),
    ("speed", _speed, "speed performance lighthouse pagespeed faster optimize optimization loading", "fast slow quick"),
    ("video", _video, "youtube video videos shorts subscribe channel vlog thumbnail reel reels", "watch play views"),
    ("social", _social, "social facebook instagram twitter share sharing viral followers community", "network people"),
    ("email", _email, "email emails newsletter newsletters inbox subscribers mailchimp", "mail message"),
    ("workflow", _workflow, "automation automate workflow workflows zapier pipeline pipelines", "steps process"),
    ("mobile", _mobile, "android app apps ios play-store", "phone mobile"),
    ("bug", _bug, "bug bugs debug debugging error errors exception crash fix fixes", "problem issue"),
    ("dashboard", _dashboard, "dashboard analytics metrics kpi report reports statistics stats", "numbers data"),
    ("shop", _shop, "ecommerce shop shopify store cart checkout product products dropshipping", "buy sell selling"),
    ("tools", _tools, "toolkit workflow productivity checklist plugins plugin extensions extension tools tool", "plan build ship"),
    ("keywords", _keywords, "tags tag niche topics topic hashtags hashtag categories category", "keyword keywords ideas"),
]


def _compile(rows):
    out = []
    for name, fn, strong, weak in rows:
        out.append((name, fn, set(strong.split()), set(weak.split())))
    return out


_LIB = _compile(LIBRARY)


def _hit(norm_tok, words):
    if norm_tok in words:
        return True
    if len(norm_tok) >= 5:
        return any(len(w) >= 4 and (norm_tok.startswith(w) or (len(w) >= 6 and w.startswith(norm_tok))) for w in words)
    return False


def match(tokens, used=()):
    rows = _LIB
    low = [_norm(t) for t in tokens]
    best = None
    for name, fn, strong, weak in rows:
        s_hits = [i for i, t in enumerate(low) if t and _hit(t, strong)]
        w_hits = [i for i, t in enumerate(low) if t and _hit(t, weak)]
        score = 3 * len({low[i] for i in s_hits}) + len({low[i] for i in w_hits})
        if not s_hits or score < 3:
            continue
        if name in list(used)[-2:]:
            score -= 2
        if best is None or score > best[0]:
            best = (score, name, fn, sorted(set(s_hits + w_hits)))
    return best


def build(tokens, W, H, used=()):
    got = match(tokens, used)
    if not got or got[0] < 3:
        return None
    score, name, fn, hits = got
    ctx = Ctx(tokens, hits, W, H)
    shapes, tag = fn(ctx)
    return name, shapes, tag
