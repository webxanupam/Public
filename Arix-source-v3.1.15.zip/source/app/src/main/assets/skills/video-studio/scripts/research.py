#!/usr/bin/env python3
"""research.py - quick, dependency-free fact gathering for a video topic.

  python3 research.py "GPT full form" [--out research.json] [--pages 3]

Uses Wikipedia (search + extracts) and DuckDuckGo's HTML endpoint. Prints/writes JSON:
  {"topic", "sources": [{"title","url"}], "facts": ["..."], "snippets": ["..."]}
Paste `sources` and `facts` you actually USE into spec.research. Prefer the agent's own
web_search + fetch_url tools when available - this script is the offline-tool fallback.
"""
import argparse, html, json, re, sys, urllib.parse, urllib.request

UA = {"User-Agent": "Mozilla/5.0 (Linux; Android 13) ArixVideoStudio/4"}

def get(url, timeout=20):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", "replace")

def wiki(topic, pages):
    base = f"https://en.wikipedia.org/w/api.php"
    q = urllib.parse.urlencode({"action": "query", "list": "search", "srsearch": topic, "format": "json", "srlimit": pages})
    hits = json.loads(get(base + "?" + q)).get("query", {}).get("search", [])
    out = []
    for h in hits[:pages]:
        title = h["title"]
        q2 = urllib.parse.urlencode({"action": "query", "prop": "extracts", "exintro": 1, "explaintext": 1,
                                     "titles": title, "format": "json", "redirects": 1})
        pg = json.loads(get(base + "?" + q2)).get("query", {}).get("pages", {})
        text = next(iter(pg.values()), {}).get("extract", "")
        out.append({"title": title, "url": f"https://en.wikipedia.org/wiki/" + urllib.parse.quote(title.replace(" ", "_")),
                    "text": text})
    return out

def ddg(topic, n=6):
    page = get("https://html.duckduckgo.com/html/?q=" + urllib.parse.quote(topic))
    res = []
    for m in re.finditer(r'<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)</a>.*?class="result__snippet"[^>]*>(.*?)</a>', page, re.S):
        href = html.unescape(m.group(1))
        mm = re.search(r"uddg=([^&]+)", href)
        if mm:
            href = urllib.parse.unquote(mm.group(1))
        strip = lambda s: html.unescape(re.sub(r"<[^>]+>", "", s)).strip()
        res.append({"title": strip(m.group(2)), "url": href, "snippet": strip(m.group(3))})
        if len(res) >= n:
            break
    return res

def sentences(text):
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+", text) if 30 <= len(s.strip()) <= 220]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("topic")
    ap.add_argument("--out")
    ap.add_argument("--pages", type=int, default=3)
    a = ap.parse_args()
    sources, facts, snippets, errors = [], [], [], []
    try:
        for p in wiki(a.topic, a.pages):
            sources.append({"title": p["title"] + " - Wikipedia", "url": p["url"]})
            ss = sentences(p["text"])
            ss.sort(key=lambda s: (-bool(re.search(r"\d", s)), len(s)))
            facts += ss[:3]
    except Exception as e:
        errors.append(f"wikipedia: {e}")
    try:
        for r in ddg(a.topic):
            sources.append({"title": r["title"], "url": r["url"]})
            snippets.append(r["snippet"])
    except Exception as e:
        errors.append(f"duckduckgo: {e}")
    out = {"topic": a.topic, "sources": sources, "facts": facts[:12], "snippets": snippets, "errors": errors}
    txt = json.dumps(out, ensure_ascii=False, indent=1)
    if a.out:
        open(a.out, "w", encoding="utf-8").write(txt)
    print(txt)
    return 0 if sources else 1

if __name__ == "__main__":
    sys.exit(main())
