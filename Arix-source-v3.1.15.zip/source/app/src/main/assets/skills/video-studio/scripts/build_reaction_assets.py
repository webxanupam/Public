import json
import math
import os

import numpy as np
from PIL import Image, ImageFilter

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.normpath(os.path.join(HERE, "..", "assets", "characters", "anupam"))
SHEETS = {"a": (os.path.join(OUT, "reactions_sheet.jpg"), 1.425), "b": (os.path.join(OUT, "reactions_sheet2.jpg"), 0.92)}
RX = os.path.join(OUT, "reactions")
UP = 3
BASE_MOUTH = (257.0, 205.5)

POSES = {
    "idea": dict(rest=(0.5, 0.6, 0.7), mo=(40, 16), sh="b", cell=(0, 0, 470, 975), mouth=(210, 228), mw=66, tilt=-3),
    "confused": dict(rest=(-0.35, 0, 0), mo=(18, 7), sh="b", cell=(470, 0, 1130, 975), mouth=(897, 239), mw=32, tilt=-10),
    "presenting": dict(rest=(0.5, 0.5, 0.7), mo=(23, 14), sh="b", cell=(1130, 0, 1647, 975), mouth=(1342, 231), mw=44, tilt=8),
    "caution": dict(rest=(-0.3, 0, 0), mo=(17, 7), sh="b", cell=(1647, 0, 2048, 975), mouth=(1848, 235), mw=30, tilt=5),
    "success": dict(rest=(0.55, 0.45, 1.0), mo=(31, 15), sh="b", cell=(0, 1030, 375, 1985), mouth=(203, 1266), mw=60, tilt=0),
    "facepalm": dict(rest=(-0.3, 0, 0), mo=(12, 7), sh="b", cell=(375, 1030, 705, 1985), mouth=(568, 1287), mw=20, tilt=12),
    "fail": dict(rest=(-0.35, 0, 0), mo=(16, 7), sh="b", cell=(705, 1030, 1060, 1985), mouth=(857, 1286), mw=26, tilt=4),
    "hips": dict(rest=(0.45, 0.45, 0.7), mo=(25, 12), sh="b", cell=(1060, 1030, 1450, 1985), mouth=(1241, 1267), mw=46, tilt=-12),
    "front": dict(hwd=18, rest=(0.35, 0.0, 0), mo=(20, 6), sh="a", cell=(0, 0, 230, 600), mouth=(120, 140), mw=28, tilt=0, eyes=[(100, 116), (140, 116)], ery=9),
    "wave": dict(hwd=22, rest=(0.5, 0.55, 0.7), mo=(22, 13), sh="a", cell=(0, 640, 215, 1254), mouth=(130, 775), mw=34, tilt=-4, eyes=None, ery=0),
    "point": dict(hwd=20, rest=(0.45, 0.3, 1.0), mo=(21, 13), sh="a", cell=(215, 640, 440, 1254), mouth=(337, 776), mw=36, tilt=20, eyes=None, ery=0),
    "think": dict(hwd=12, rest=(-0.05, 0, 0), mo=(13, 6), sh="a", cell=(440, 640, 635, 1254), mouth=(535, 772), mw=22, tilt=14, eyes=None, ery=0),
    "open": dict(rest=(0.5, 0.5, 0.7), mo=(14, 9), sh="a", cell=(635, 640, 895, 1254), mouth=(757, 780), mw=26, tilt=-4, eyes=[(727, 757), (777, 757)], ery=9),
    "cross": dict(hwd=15, rest=(0.3, 0, 0), mo=(14, 6), sh="a", lowmin=120, cell=(1045, 640, 1254, 1254), mouth=(1147, 771), mw=28, tilt=-14, eyes=None, ery=0),
}


def bg_model(a, seen):
    h, w = a.shape[:2]
    ys, xs = np.nonzero(seen)
    sel = np.random.RandomState(1).choice(len(ys), min(6000, len(ys)), replace=False)
    ys, xs = ys[sel], xs[sel]
    X = np.stack([np.ones_like(xs), xs / float(w), ys / float(h)], axis=1).astype(np.float64)
    coef = [np.linalg.lstsq(X, a[ys, xs, c].astype(np.float64), rcond=None)[0] for c in range(3)]
    gy, gx = np.mgrid[0:h, 0:w]
    G = np.stack([np.ones((h, w)), gx / float(w), gy / float(h)], axis=2)
    return np.stack([G @ coef[c] for c in range(3)], axis=2)


def flood(cand, h, w):
    seen = np.zeros((h, w), bool)
    stack = [(0, x) for x in range(w)] + [(h - 1, x) for x in range(w)] + [(y, 0) for y in range(h)] + [(y, w - 1) for y in range(h)]
    stack = [p for p in stack if cand[p]]
    for p in stack:
        seen[p] = True
    while stack:
        y, x = stack.pop()
        for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            ny, nx = y + dy, x + dx
            if 0 <= ny < h and 0 <= nx < w and cand[ny, nx] and not seen[ny, nx]:
                seen[ny, nx] = True
                stack.append((ny, nx))
    return seen


def cut(sheet, cell, upper, lowmin=700, lowd=120):
    from scipy import ndimage
    c = sheet.crop(cell).convert("RGB")
    c = c.resize((c.width * UP, c.height * UP), Image.BICUBIC)
    a = np.asarray(c).astype(np.float64)
    h, w = a.shape[:2]
    edge = np.concatenate([a[0], a[-1], a[:, 0], a[:, -1]])
    bg0 = np.median(edge, axis=0)
    d0 = np.abs(a - bg0).sum(axis=2)
    seen = flood(d0 < 54, h, w)
    bg = bg_model(a, seen)
    d = np.abs(a - bg).sum(axis=2)
    sat = a.max(axis=2) - a.min(axis=2)
    rows = np.arange(h)[:, None] < upper * UP
    hole = (d < 46) & (sat < 26) & rows
    lab, n = ndimage.label(hole)
    if n:
        sizes = ndimage.sum(np.ones_like(lab), lab, range(1, n + 1))
        big = np.isin(lab, 1 + np.nonzero(sizes >= 2 * UP * UP)[0])
        seen = seen | big
        punch = big
    else:
        punch = np.zeros((h, w), bool)
    low = (d < lowd) & (sat < 26) & ~rows
    lab, n = ndimage.label(low)
    if n:
        sizes = ndimage.sum(np.ones_like(lab), lab, range(1, n + 1))
        lowbig = np.isin(lab, 1 + np.nonzero(sizes >= lowmin * UP * UP)[0])
        seen = seen | lowbig
        punch = punch | lowbig
    seen = seen | flood((d < 54) & (sat < 30), h, w)
    fg = ~seen
    lab, n = ndimage.label(fg)
    if n > 1:
        sizes = ndimage.sum(np.ones_like(lab), lab, range(1, n + 1))
        fg = np.isin(lab, 1 + np.nonzero(sizes >= 0.012 * sizes.max())[0])
    fg = ndimage.binary_fill_holes(fg) & ~punch
    core = ndimage.binary_erosion(fg, iterations=2 * UP)
    dist, idx = ndimage.distance_transform_edt(~core, return_indices=True)
    col = np.where(core[:, :, None], a, a[idx[0], idx[1]])
    band = ndimage.binary_dilation(fg, iterations=3 * UP)
    soft = np.clip((d - 14.0) / 46.0, 0.0, 1.0)
    raw = np.where(core, 1.0, np.where(band, soft, 0.0))
    raw = ndimage.gaussian_filter(raw, 0.8 * UP)
    alpha = np.clip((raw - 0.45) * 2.4 + 0.5, 0.0, 1.0)
    out = np.dstack([np.clip(col, 0, 255), alpha * 255.0]).astype(np.uint8)
    return Image.fromarray(out, "RGBA")


def clean_mouth(canvas, box, path):
    import cv2
    x0, y0, x1, y1 = box
    crop = canvas.crop(box)
    rgb = np.asarray(crop.convert("RGB")).copy()
    a = np.asarray(crop.getchannel("A"))
    h, w = rgb.shape[:2]
    f = rgb.astype(np.float32)
    skin = (f[:, :, 0] > 225) & (f[:, :, 1] > 165) & (f[:, :, 1] < 225) & (f[:, :, 2] > 130) & (f[:, :, 2] < 205) & (f[:, :, 0] - f[:, :, 2] > 30)
    med = np.median(f[skin], axis=0) if skin.sum() > 20 else np.array([250, 205, 175], np.float32)
    dist = np.abs(f - med).sum(axis=2)
    yy, xx = np.mgrid[0:h, 0:w]
    ell = ((xx - w / 2.0) / (w / 2.0)) ** 2 + ((yy - h / 2.0) / (h / 2.0)) ** 2 <= 1.0
    ell &= (yy > 1) & (yy < h - 2)
    core = ((dist > 55) & ell & (a > 200)).astype(np.uint8)
    n, lab = cv2.connectedComponents(core)
    stats = None
    if n > 1:
        sizes = [(lab == i).sum() for i in range(1, n)]
        ys, xs = np.nonzero(lab == 1 + int(np.argmax(sizes)))
        if len(xs) > 12:
            mx, my = xs.mean(), ys.mean()
            cov = np.cov(np.stack([xs - mx, ys - my]))
            ang = 0.5 * math.atan2(2 * cov[0, 1], cov[0, 0] - cov[1, 1])
            u = (xs - mx) * math.cos(ang) + (ys - my) * math.sin(ang)
            lo, hi = np.percentile(u, 1), np.percentile(u, 99)
            mid = (lo + hi) / 2.0
            stats = (x0 + mx + mid * math.cos(ang), y0 + my + mid * math.sin(ang), (hi - lo) / 2.0, math.degrees(ang))
    mask = ((dist > 22) & ell & (a > 200)).astype(np.uint8) * 255
    mask = cv2.dilate(mask, np.ones((7, 7), np.uint8), iterations=1)
    out = cv2.inpaint(rgb, mask, 4, cv2.INPAINT_TELEA)
    out = cv2.GaussianBlur(out, (0, 0), 1.2) * 0 + out
    res = Image.fromarray(out, "RGB").convert("RGBA")
    res.putalpha(crop.getchannel("A"))
    res.save(path, optimize=True)
    return stats


def main():
    os.makedirs(RX, exist_ok=True)
    meta = {}
    for name, p in POSES.items():
        path, SCALE = SHEETS[p["sh"]]
        sheet = Image.open(path)
        im = cut(sheet, p["cell"], p["mouth"][1] - p["cell"][1] + (235 if p["sh"] == "a" else 330), p.get("lowmin", 700), p.get("lowd", 120))
        x0, y0 = p["cell"][0], p["cell"][1]
        w, h = int(round(im.width * SCALE / UP)), int(round(im.height * SCALE / UP))
        im = im.resize((w, h), Image.LANCZOS)
        mx, my = (p["mouth"][0] - x0) * SCALE, (p["mouth"][1] - y0) * SCALE
        dx = int(round(BASE_MOUTH[0] - mx))
        dy = int(round(BASE_MOUTH[1] - my))
        canvas = Image.new("RGBA", (512, 768), (0, 0, 0, 0))
        canvas.paste(im, (dx, dy))
        canvas.save(os.path.join(RX, name + ".png"), optimize=True)
        hw, hh = p["mo"]
        sx = hw * 1.5 + 3
        sy = (hh + abs(math.sin(math.radians(p["tilt"]))) * hw * 0.7) * 1.3 + 2
        sy = max(sy, hw * 0.8 + 2)
        box = [int(round(mx + dx - sx * SCALE)), int(round(my + dy - sy * SCALE)), int(round(mx + dx + sx * SCALE)), int(round(my + dy + sy * SCALE))]
        st = clean_mouth(canvas, box, os.path.join(RX, name + "_m.png"))
        e = None
        if p.get("eyes"):
            e = [[round((ex - x0) * SCALE + dx, 1), round((ey - y0) * SCALE + dy, 1)] for ex, ey in p["eyes"]]
        m0 = (mx + dx, my + dy)
        hw0 = hw * SCALE
        good = bool(st and abs(st[0] - m0[0]) < 18 and abs(st[1] - m0[1]) < 9 and 0.55 * hw0 < st[2] < 1.7 * hw0)
        meta[name] = {
            "mouth": [round(st[0], 1), round(st[1], 1)] if good else [round(m0[0], 1), round(m0[1], 1)],
            "mw": round(p["mw"] * SCALE, 1),
            "tilt": round(max(-30.0, min(30.0, st[3])), 1) if good else p["tilt"],
            "eyes": e,
            "ery": round(p.get("ery", 0) * SCALE, 1),
            "box": box,
            "rest": list(p["rest"]),
            "hw": round(st[2], 1) if good else float(p.get("hwd", round(hw0, 1))),
            "omax": {"facepalm": 0.35, "fail": 0.55, "think": 0.8}.get(name, 1.2),
            "auto": good,
        }
    json.dump(meta, open(os.path.join(RX, "meta.json"), "w"), indent=1)


main()
