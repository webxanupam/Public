import math
import random

from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageOps

from .fx import halo
from .gfx import BG, Canvas, color, measure, mix

SANS_SIZE = 50
DARK = (11, 11, 15)


def tint_rgb(spec_tint, theme_colors):
    if spec_tint is None:
        return theme_colors["accent"]
    return color(spec_tint, theme_colors["accent"])


def make_bg(W, H, scale, tint):
    top = mix((5, 5, 8), tint, 0.04)
    bot = mix((9, 8, 12), tint, 0.09)
    col = Image.new("RGB", (1, H))
    px = col.load()
    for y in range(H):
        px[0, y] = mix(top, bot, y / float(max(1, H - 1)))
    im = col.resize((W, H))
    rad = ImageOps.invert(Image.radial_gradient("L"))

    def glow(cx, cy, rw, rh, strength, c):
        m = rad.resize((max(2, int(rw * 2)), max(2, int(rh * 2))), Image.BICUBIC).point(lambda v: int(v * strength))
        layer = Image.new("RGB", m.size, c)
        im.paste(layer, (int(cx * W - rw), int(cy * H - rh)), m)

    glow(0.5, 0.60, W * 0.95, H * 0.42, 0.34, mix(tint, (0, 0, 0), 0.42))
    glow(0.5, 0.80, W * 0.55, H * 0.12, 0.30, mix(tint, (0, 0, 0), 0.25))
    glow(0.5, 0.04, W * 0.7, H * 0.10, 0.18, mix(tint, (0, 0, 0), 0.55))
    overlay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(overlay)
    hy = H * 0.76
    lw = max(1, int(round(1.0 * scale)))
    ga = mix(tint, (255, 255, 255), 0.25)
    n = 9
    for i in range(1, n + 1):
        y = hy + (H - hy) * (i / float(n)) ** 1.8
        d.line([(0, y), (W, y)], fill=ga + (int(10 + 26 * i / n),), width=lw)
    for k in range(-9, 10):
        d.line([(W / 2 + k * W * 0.035, hy), (W / 2 + k * W * 0.26, H)], fill=ga + (22,), width=lw)
    fade = Image.linear_gradient("L").resize((W, H))
    ov_a = ImageChops.multiply(overlay.getchannel("A"), fade)
    overlay.putalpha(ov_a)
    im = im.convert("RGBA")
    im.alpha_composite(overlay)
    vig = ImageOps.invert(rad).resize((W, H), Image.BICUBIC).point(lambda v: int(v * 0.55))
    black = Image.new("RGBA", (W, H), (0, 0, 0, 255))
    black.putalpha(vig)
    im.alpha_composite(black)
    return im.convert("RGB")


class Particles:
    def __init__(self, W, H, scale, n=34):
        rnd = random.Random(11)
        self.W, self.H, self.s = W, H, scale
        self.p = [(rnd.random(), rnd.random(), rnd.uniform(0.012, 0.05), rnd.uniform(0.9, 2.2), rnd.random() * 6.28) for _ in range(n)]

    def draw(self, frame, t, tint):
        d = ImageDraw.Draw(frame)
        W, H = self.W, self.H
        for (x, y, v, r, ph) in self.p:
            yy = (y - t * v) % 1.0
            xx = x + math.sin(t * 0.4 + ph) * 0.012
            a = 0.25 + 0.35 * (0.5 + 0.5 * math.sin(t * 1.3 + ph))
            c = mix((20, 20, 26), mix(tint, (255, 255, 255), 0.55), a)
            rr = r * self.s
            d.ellipse([xx * W - rr, yy * H - rr, xx * W + rr, yy * H + rr], fill=c)


def ghost_sprite(text, W, H, cy, scale, tint):
    text = str(text).upper().strip()
    if not text:
        return None
    c = Canvas(W / scale, 240, scale)
    size = 190
    tw = measure(text, "sans", size)[0]
    if tw > 780:
        size = size * 780 / tw
    c.text(W / scale / 2, 120, text, size, fill=mix((0, 0, 0), tint, 0.5) + (46,), kind="sans", anchor="mm")
    return c.finish()


class Caption:
    def __init__(self, scale, max_w, pill=False):
        self.scale = scale
        self.max_w = max_w
        self.pill = pill
        self.cache = {}
        self.fs = SANS_SIZE
        self.pad = 13
        self.gap = 16

    def _slots(self, texts):
        out = []
        for t in texts:
            a = measure(t, "sans", self.fs)[0]
            b = measure(t, "serif", self.fs + 4)[0]
            out.append(max(a, b) + 2 * self.pad)
        return out

    def _lines(self, texts):
        slots = self._slots(texts)
        lines, cur, w = [], [], 0.0
        for i, sw in enumerate(slots):
            if cur and w + self.gap + sw > self.max_w:
                lines.append(cur)
                cur, w = [], 0.0
            w += (self.gap if cur else 0) + sw
            cur.append((i, sw))
        if cur:
            lines.append(cur)
        return lines

    def size(self, texts):
        lines = self._lines(texts)
        w = max(sum(sw for _, sw in ln) + self.gap * (len(ln) - 1) for ln in lines)
        return w + 20, len(lines) * self.fs * 1.5 + 14

    def sprite(self, ck, texts, active, tint):
        key = (ck, active, tint)
        hit = self.cache.get(key)
        if hit is not None:
            return hit, 0
        lines = self._lines(texts)
        w, h = self.size(texts)
        c = Canvas(w, h, self.scale)
        y = 8 + self.fs * 0.75
        if self.pill:
            bw = max(sum(sw for _, sw in ln) + self.gap * (len(ln) - 1) for ln in lines) + 22
            c.rrect((w - bw) / 2, 2, bw, h - 4, 26, fill=(14, 16, 26, 168))
        for ln in lines:
            lw = sum(sw for _, sw in ln) + self.gap * (len(ln) - 1)
            x = (w - lw) / 2
            for (i, sw) in ln:
                t = texts[i]
                cx = x + sw / 2
                if self.pill:
                    hot = active is not None and i == active
                    done = active is None or i < active
                    col = (255, 214, 38) if hot else ((250, 250, 252) if done else (190, 194, 206))
                    c.text(cx, y, t, self.fs, fill=col, kind="sans", anchor="mm")
                elif active is not None and i == active:
                    tw = measure(t, "sans", self.fs)[0]
                    c.rrect(cx - tw / 2 - self.pad, y - self.fs * 0.62, tw + 2 * self.pad, self.fs * 1.24, 13, fill=tint)
                    c.text(cx, y, t, self.fs, fill=DARK, kind="sans", anchor="mm")
                elif active is None or i < active:
                    c.text(cx, y, t, self.fs, fill=(247, 247, 250), kind="sans", anchor="mm")
                else:
                    c.text(cx, y, t, self.fs + 4, fill=(138, 140, 152), kind="serif", anchor="mm")
                x += sw + self.gap
            y += self.fs * 1.5
        im = c.finish()
        if len(self.cache) > 120:
            self.cache.clear()
        self.cache[key] = im
        return im, 0


class CharFx:
    def __init__(self, S):
        self.S = S
        self.cache = {}
        self.under = {}

    def paste(self, frame, sprite, x, y, tint, foot=None):
        w, h = sprite.size
        key = id(sprite)
        hit = self.cache.get(key)
        if hit is None or hit[0] is not sprite or hit[2] != tint:
            hl, pad = halo(sprite, tint, 5.0 * self.S, 0.34)
            if len(self.cache) > 80:
                self.cache.clear()
            hit = (sprite, hl, tint, pad)
            self.cache[key] = hit
        _, hl, _, pad = hit
        fx, fy, fw = foot if foot else (w / 2.0, h * 0.96, w * 0.5)
        uk = (int(fw), tint)
        ug = self.under.get(uk)
        if ug is None:
            ew, eh = int(fw * 1.7), int(fw * 0.42)
            lay = Image.new("RGBA", (ew, eh), (0, 0, 0, 0))
            dd = ImageDraw.Draw(lay)
            dd.ellipse([ew * 0.08, eh * 0.2, ew * 0.92, eh * 0.8], fill=mix(tint, (0, 0, 0), 0.2) + (110,))
            lay = lay.filter(ImageFilter.GaussianBlur(fw * 0.06))
            dk = Image.new("RGBA", (ew, eh), (0, 0, 0, 0))
            ImageDraw.Draw(dk).ellipse([ew * 0.2, eh * 0.34, ew * 0.8, eh * 0.66], fill=(0, 0, 0, 175))
            dk = dk.filter(ImageFilter.GaussianBlur(fw * 0.04))
            lay.alpha_composite(dk)
            self.under[uk] = ug = lay
        frame.paste(ug, (int(x + fx - ug.width / 2), int(y + fy - ug.height * 0.5)), ug)
        frame.paste(hl, (int(x - pad), int(y - pad)), hl)
        frame.paste(sprite, (int(x), int(y)), sprite)
