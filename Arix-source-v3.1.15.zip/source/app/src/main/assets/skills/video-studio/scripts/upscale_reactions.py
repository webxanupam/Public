"""upscale_reactions.py - sharpens the reaction sprites 2x with Real-ESRGAN (anime) while keeping the original colours.

  python3 upscale_reactions.py /path/RealESRGAN_x4plus_anime_6B.pth [names...]

Run after build_reaction_assets.py. Writes assets/characters/anupam/reactions/<name>.png and <name>_m.png at 2x size
(1024x1536); the renderer reads the scale from the image width, so 1x files keep working.
"""
import os
import sys
from multiprocessing import Pool

import numpy as np
from PIL import Image, ImageFilter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from esrgan_np import Net

RX = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets", "characters", "anupam", "reactions"))
_net = None


def enhance(im, net, detail=0.95):
    rgba = im.convert("RGBA")
    a = rgba.getchannel("A")
    bb = a.point(lambda v: 255 if v > 4 else 0).getbbox()
    if not bb:
        return rgba.resize((rgba.width * 2, rgba.height * 2), Image.LANCZOS)
    pad = 6
    bb = (max(0, bb[0] - pad), max(0, bb[1] - pad), min(im.width, bb[2] + pad), min(im.height, bb[3] + pad))
    crop = rgba.crop(bb)
    rgb = np.asarray(crop.convert("RGB")).astype(np.float32) / 255.0
    up = net.up(rgb)
    base = np.asarray(Image.fromarray((rgb * 255).astype(np.uint8)).resize((crop.width * 4, crop.height * 4), Image.LANCZOS)).astype(np.float32) / 255.0
    low = np.asarray(Image.fromarray((up * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(5))).astype(np.float32) / 255.0
    out = np.clip(base + (up - low) * detail, 0, 1)
    rgb4 = Image.fromarray((out * 255).astype(np.uint8)).resize((crop.width * 2, crop.height * 2), Image.LANCZOS)
    a4 = crop.getchannel("A").resize((crop.width * 4, crop.height * 4), Image.BICUBIC).filter(ImageFilter.GaussianBlur(1.2))
    a4 = a4.point(lambda v: max(0, min(255, int((v - 128) * 1.6 + 128)))).resize((crop.width * 2, crop.height * 2), Image.LANCZOS)
    res = rgb4.convert("RGBA")
    res.putalpha(a4)
    canvas = Image.new("RGBA", (im.width * 2, im.height * 2), (0, 0, 0, 0))
    canvas.paste(res, (bb[0] * 2, bb[1] * 2))
    return canvas


def job(args):
    global _net
    weights, name = args
    if _net is None:
        _net = Net(weights)
    for suffix in ("", "_m"):
        p = os.path.join(RX, name + suffix + ".png")
        im = Image.open(p)
        if im.width >= 1000 or (suffix and im.width > 200):
            continue
        out = enhance(im, _net)
        out.save(p, optimize=True)
    return name


if __name__ == "__main__":
    weights = sys.argv[1]
    names = sys.argv[2:] or sorted(n[:-4] for n in os.listdir(RX) if n.endswith(".png") and not n.endswith("_m.png"))
    with Pool(min(len(names), os.cpu_count() or 2)) as pool:
        for n in pool.imap_unordered(job, [(weights, n) for n in names]):
            print("done", n, flush=True)
