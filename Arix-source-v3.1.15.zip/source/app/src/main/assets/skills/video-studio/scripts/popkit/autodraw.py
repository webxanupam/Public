import hashlib
import re
import shlex

from . import library

STOP = set("""a an the and or but of to in on at for with from by is are was were be been being it its this that these those you your we our they
their i me my as if so do does did how what why when who which can will just not no yes than then into about over more most very all any some
each every one two have has had get gets got make makes made like also only even still there here out up down off too much many such own same
other another while where after before again once now new would could should may might must let lets us them him her his she he""".split())

FAMILIES = [
    ("tech", "code coding api server servers data python app apps software ai model models algorithm database cloud internet network web website cpu gpu bug deploy "
             "browser cache latency request token tokens neural computer program script system systems cyber hack password security encrypt डेटा सर्वर कोड ऐप इंटरनेट नेटवर्क वेबसाइट"),
    ("money", "money price prices cost costs revenue profit dollar dollars rupee rupees invest investing salary income budget saving savings cash loan tax stock market "
              "पैसा पैसे कीमत निवेश कमाई बचत बाज़ार"),
    ("world", "world global country countries city cities map travel earth planet nation continent everywhere दुनिया देश शहर विश्व"),
    ("doc", "file files document documents pdf report email message letter note notes book article essay form फाइल दस्तावेज़ रिपोर्ट"),
    ("growth", "grow grows growth increase increases rising rise rises boost faster improve improved higher more better scale gain gains बढ़ता बढ़ती बढ़ने तेज़ तेज"),
    ("decline", "drop drops fall falls decline decreases less lower slower slow lose loss losing crash crashes fail breaks कम घटता घटती धीमा धीमी नुकसान"),
]
FAM = {}
for _n, _w in FAMILIES:
    for _x in _w.split():
        FAM.setdefault(_x, _n)

POS = set("fast faster fastest great best better win success easy boost improve perfect amazing love solved growth secret trick free safe तेज़ तेज बढ़िया शानदार बेहतर आसान".split())
NEG = set("slow crawls crash error fail failed broken lag problem worst danger risk scam mistake wrong loss lose धीमा खराब फेल समस्या खतरा गलती नुकसान".split())
PIVOT = set("vs versus than instead unlike while whereas बनाम".split())
STEP = set("first second third next then finally after before step steps".split())
TINTS = ["accent", "accent2", "accent3", "accent4"]
CAMS = ["push", "drift_r", "pull", "drift_l", "punch", "tilt"]
MOODS = ["confident", "happy", "calm", "excited"]


def _norm(w):
    return re.sub(r"[^\w]", "", str(w), flags=re.UNICODE).lower()


def _q(s, bar=False):
    s = re.sub(r"[\"'=" + ("" if bar else "|") + "]", "", str(s)).strip()
    return shlex.quote(s)


def _short(s, n):
    s = re.sub(r"\s+", " ", str(s)).strip(" .,!?;:-")
    if len(s) <= n:
        return s
    cut = s[:n].rsplit(" ", 1)[0]
    return cut if len(cut) >= max(4, n // 2) else s[:n]


def _trim(s):
    ws = s.split()
    while len(ws) > 1 and _norm(ws[0]) in ("the", "a", "an", "and", "or", "then", "so", "की", "का", "और"):
        ws = ws[1:]
    while len(ws) > 1 and (_norm(ws[-1]) in STOP):
        ws = ws[:-1]
    return " ".join(ws)


def _is_stop(w):
    n = _norm(w)
    return (not n) or n in STOP or len(n) < 3


def _key_tokens(tokens, limit=6):
    cand = []
    for i, t in enumerate(tokens):
        n = _norm(t)
        if _is_stop(t) or n.isdigit():
            continue
        score = len(n) + (3 if n in FAM else 0) + (2 if n in POS or n in NEG else 0)
        cand.append((score, i))
    seen, out = set(), []
    for sc, i in sorted(cand, key=lambda c: -c[0]):
        n = _norm(tokens[i])
        if n in seen:
            continue
        seen.add(n)
        out.append(i)
        if len(out) >= limit:
            break
    return sorted(out)


def _numbers(tokens):
    out = []
    for i, t in enumerate(tokens):
        m = re.fullmatch(r"[^\d]*(\d[\d,]*\.?\d*)\s*(%|x|k|m|b|s|ms|gb|mb|tb)?[^\w%]*", t, flags=re.I)
        if m:
            val = m.group(1).replace(",", "")
            unit = (m.group(2) or "")
            nxt = _norm(tokens[i + 1]) if i + 1 < len(tokens) else ""
            if not unit and nxt in ("percent", "%"):
                unit = "%"
            if not unit and nxt in ("million", "billion", "thousand", "lakh", "crore"):
                unit = {"million": "M", "billion": "B", "thousand": "K", "lakh": "L", "crore": "Cr"}[nxt]
            out.append((i, val + unit if unit != "%" else val + "%", float(val) if re.match(r"^\d+\.?\d*$", val) else 0.0, unit == "%"))
    return out


def _on(tokens, i):
    t = tokens[i]
    n = _norm(t)
    return str(i) if (not n or n.isdigit()) else _q(t)


def analyse(text):
    tokens = text.split()
    keys = _key_tokens(tokens)
    nums = _numbers(tokens)
    low = [_norm(t) for t in tokens]
    fam = {}
    for n in low:
        f = FAM.get(n)
        if f:
            fam[f] = fam.get(f, 0) + 1
    pos = sum(1 for n in low if n in POS)
    neg = sum(1 for n in low if n in NEG)
    items = []
    if sum(1 for t in tokens if t.endswith(",")) >= 2 or (any(t.endswith(",") for t in tokens) and any(_norm(t) in ("and", "or", "और") for t in tokens)):
        cur = []
        groups = []
        for i, t in enumerate(tokens):
            if _norm(t) in ("and", "or", "और"):
                if cur and not tokens[i - 1].endswith(","):
                    groups.append(cur)
                    cur = []
                continue
            cur.append(i)
            if t.endswith(","):
                groups.append(cur)
                cur = []
        if cur:
            groups.append(cur)
        for k, g in enumerate(groups):
            g = [j for j in g if _norm(tokens[j])]
            if k == 0 and len(g) > 2:
                g = g[-2:]
            ks = [j for j in g if not _is_stop(tokens[j])]
            if ks and len(g) <= 5:
                items.append((_short(_trim(" ".join(tokens[j] for j in g)), 26).lower(), ks[0]))
            else:
                items = []
                break
    pivot = next((i for i, n in enumerate(low) if n in PIVOT), None)
    if pivot is None:
        pivot = next((i for i, n in enumerate(low) if (n == "not" and i > 1) or (n == "but" and i > 2)), None)
    return dict(tokens=tokens, keys=keys, nums=nums, fam=fam, pos=pos, neg=neg, items=items[:4], pivot=pivot,
                question=text.strip().endswith("?"), step=any(n in STEP for n in low[:3]))


def _kw(f, n=0, default="idea", cap=14):
    ks = f["keys"]
    if n < len(ks):
        return _short(f["tokens"][ks[n]], cap).lower()
    return default


def _ki(f, n=0):
    ks = f["keys"]
    return ks[n] if n < len(ks) else 0


def _beam(W, H, hero):
    return ["beam %d %d %d %d" % (W / 2, H / 2, W * 0.5, H)] if hero else []


def _t_number(f, W, H, tint):
    tk = f["tokens"]
    pcts = [n for n in f["nums"] if n[3]]
    others = [n for n in f["nums"] if not n[3]]
    out = []
    if pcts and others:
        i, txt, val, _ = pcts[0]
        out.append("ring %d %d %d %.2f text=%s on=%s" % (W * 0.74, H * 0.42, H * 0.28, min(0.99, max(0.03, val / 100.0)), _q(txt), _on(tk, i)))
        j, t2, _, _ = others[0]
        out.append("num %d %d %s %d label=%s w=%d on=%s" % (W * 0.28, H * 0.4, _q(t2), H * 0.3, _q(_kw(f, 0, "total")), W * 0.44, _on(tk, j)))
    elif pcts:
        i, txt, val, _ = pcts[0]
        out.append("ring %d %d %d %.2f text=%s on=%s" % (W / 2, H * 0.44, H * 0.33, min(0.99, max(0.03, val / 100.0)), _q(txt), _on(tk, i)))
    else:
        i, txt, val, _ = others[0]
        out.append("num %d %d %s %d label=%s w=%d on=%s" % (W / 2, H * 0.4, _q(txt), H * 0.46, _q(_kw(f, 0, "total")), W * 0.9, _on(tk, i)))
    xs = [W * 0.28, W * 0.72]
    for n in range(min(2, len(f["keys"]))):
        out.append("chip %d %d %s size=19 hot=%d on=%s in=drop delay=%.1f" % (xs[n], H * 0.9, _q(_kw(f, n)), 1 - n, _on(tk, _ki(f, n)), 0.1 * n))
    return out, "THE NUMBERS"


def _t_list(f, W, H, tint):
    items = f["items"]
    n = len(items)
    rh = 46
    gap = min(24, max(10, (H - 20 - n * rh) / max(1, n)))
    y0 = (H - (n * rh + (n - 1) * gap)) / 2 + rh / 2
    out = ["check %d %d w=%d text=%s on=%s in=slide delay=%.2f" % (W / 2, y0 + i * (rh + gap), W * 0.86, _q(t), _on(f["tokens"], j), 0.05 * i) for i, (t, j) in enumerate(items)]
    return out, "KEY POINTS"


def _t_compare(f, W, H, tint):
    tk = f["tokens"]
    p = f["pivot"]
    left = [i for i in f["keys"] if i < p][:1] or [_ki(f, 0)]
    right = [i for i in f["keys"] if i > p][:1] or [_ki(f, 1)]
    a_good = not (f["neg"] and any(_norm(tk[i]) in NEG for i in f["keys"] if i < p))
    ra, rb = (0.92, 0.24) if a_good else (0.24, 0.92)
    nums = f["nums"]
    ta = nums[0][1] if len(nums) > 0 else ("OK" if a_good else "NO")
    tb = nums[1][1] if len(nums) > 1 else ("NO" if a_good else "OK")
    r = min(H * 0.27, W * 0.17)
    out = ["ring %d %d %d %.2f text=%s tint=%s on=%s" % (W * 0.22, H * 0.42, r, ra, _q(ta), "mint" if a_good else "red", _on(tk, left[0])),
           "ring %d %d %d %.2f text=%s tint=%s on=%s" % (W * 0.78, H * 0.42, r, rb, _q(tb), "red" if a_good else "mint", _on(tk, right[0])),
           "badge %d %d VS on=%s in=pop" % (W / 2, H * 0.42, _on(tk, p)),
           "chip %d %d %s size=19 hot=%d on=%s in=drop" % (W * 0.22, H * 0.88, _q(_short(tk[left[0]], 14).lower()), 1 if a_good else 0, _on(tk, left[0])),
           "chip %d %d %s size=19 hot=%d on=%s in=drop delay=0.15" % (W * 0.78, H * 0.88, _q(_short(tk[right[0]], 14).lower()), 0 if a_good else 1, _on(tk, right[0]))]
    return out, "COMPARE"


def _clauses(text):
    parts = re.split(r"[.!?;]\s*|,?\s*\b(?:then|and then|next|finally)\b,?\s*", text)
    out = []
    for p in parts:
        p = re.sub(r"^(first|second|third|step \d+|after that|पहले)\b[,:]?\s*", "", (p or "").strip(), flags=re.I)
        if len(p.split()) >= 2:
            out.append(p)
    return out


def _t_steps(f, W, H, tint):
    tk = f["tokens"]
    cl = _clauses(" ".join(tk))[:3]
    if len(cl) < 2:
        cl = [" ".join(tk[i] for i in f["keys"][n:n + 2]) for n in range(0, min(len(f["keys"]), 6), 2)][:3]
    cl = [c for c in cl if c]
    n = len(cl)
    rh = 62 if n < 4 else 52
    gap = 16
    y0 = (H - (n * rh + (n - 1) * gap)) / 2 + rh / 2
    out = []
    pos = 0
    for i, c in enumerate(cl):
        lead = next((w for w in c.split() if not _is_stop(w)), c.split()[0])
        ws = [j for j, t in enumerate(tk) if _norm(t) == _norm(lead)]
        j = ws[0] if ws else min(len(tk) - 1, pos)
        pos = j
        y = y0 + i * (rh + gap)
        out.append("card %d %d %d %d title=%s on=%s in=slide delay=%.2f" % (W / 2 + 22, y, W * 0.78, rh, _q(_trim(_short(c, 24)).lower()), _on(tk, j), 0.05 * i))
        out.append("badge %d %d %d on=%s in=pop" % (W * 0.075 + 8, y, i + 1, _on(tk, j)))
        if i:
            out.append("l %d %d %d %d s=accent lw=2 on=%s in=draw" % (W * 0.075 + 8, y - gap - rh / 2 + 17, W * 0.075 + 8, y - 17, _on(tk, j)))
    return out, "STEP BY STEP"


def _t_trend(f, W, H, tint):
    up = f["fam"].get("decline", 0) <= f["fam"].get("growth", 0) and f["neg"] <= f["pos"]
    vals = "2,3,2.6,4,5.2,4.8,7,9" if up else "9,7.6,8,5.5,5,3.4,3.8,1.6"
    k = _ki(f, 0)
    out = ["spark %d %d %d %d vals=%s tint=%s on=%s" % (W / 2, H * 0.52, W * 0.8, H * 0.5, vals, "mint" if up else "red", _on(f["tokens"], k)),
           "badge %d %d %s on=%s in=drop" % (W * 0.28, H * 0.1, _q(_kw(f, 0, "trend").upper()), _on(f["tokens"], k))]
    if f["nums"]:
        i, txt, _, _ = f["nums"][0]
        out.append("chip %d %d %s size=19 hot=1 on=%s in=pop" % (W * 0.78, H * 0.1, _q(("+" if up else "-") + txt), _on(f["tokens"], i)))
    elif len(f["keys"]) > 1:
        out.append("chip %d %d %s size=19 hot=1 on=%s in=pop" % (W * 0.78, H * 0.1, _q(_kw(f, 1)), _on(f["tokens"], _ki(f, 1))))
    return out, "GROWTH" if up else "THE DROP"


def _t_bars(f, W, H, tint):
    nums = f["nums"][:4]
    vals = ",".join("%g" % max(0.5, v) for _, _, v, _ in nums)
    labels = "|".join(_short(t, 6) for _, t, _, _ in nums)
    i = nums[-1][0]
    return ["bars %d %d %d %d vals=%s labels=%s on=%s" % (W / 2, H * 0.46, W * 0.76, H * 0.56, vals, _q(labels, True), _on(f["tokens"], i))], "BY THE NUMBERS"


def _t_tech(f, W, H, tint):
    tk = f["tokens"]
    k0, k1, k2 = _kw(f, 0, "request"), _kw(f, 1, "server"), _kw(f, 2, "response")
    cl = _clauses(" ".join(tk)) or [" ".join(tk)]
    lines = "> %s|%s: ok|%s: ready" % (_short(re.sub(r"[^\w\s]", "", cl[0].lower(), flags=re.U), 28), k1, k2)
    out = ["term %d %d %d %d title=%s lines=%s step=0.7 on=%s" % (W / 2, H * 0.36, W * 0.84, H * 0.56, _q(k1 + ".log"), _q(lines, True), _on(tk, _ki(f, 0)))]
    out.append("chip %d %d %s size=19 hot=1 on=%s in=drop" % (W * 0.28, H * 0.86, _q(k0), _on(tk, _ki(f, 0))))
    out.append("chip %d %d %s size=19 on=%s in=drop delay=0.15" % (W * 0.72, H * 0.86, _q(k2), _on(tk, _ki(f, 2) if len(f["keys"]) > 2 else _ki(f, 1))))
    return out, "UNDER THE HOOD"


def _t_search(f, W, H, tint):
    tk = f["tokens"]
    qs = [t for t in tk if not (_is_stop(t) and _norm(t) in STOP and len(_norm(t)) < 5 and tk.index(t) < 3)]
    q = " ".join(qs).lower() or "search"
    out = ["search %d %d %d text=%s on=%s" % (W / 2, H * 0.2, W * 0.84, _q(_short(re.sub(r"[?!.,]", "", q), 30)), _on(tk, _ki(f, 0)))]
    for n, (x, y) in enumerate([(W * 0.26, H * 0.55), (W * 0.74, H * 0.55), (W * 0.5, H * 0.78)]):
        if n < len(f["keys"]):
            out.append("chip %d %d %s size=19 hot=%d on=%s in=drop delay=%.2f" % (x, y, _q(_kw(f, n)), 1 if n == 0 else 0, _on(tk, _ki(f, n)), 0.12 * n))
    return out, "THE QUESTION"


def _t_globe(f, W, H, tint):
    tk = f["tokens"]
    cx, cy, r = W / 2, H * 0.5, min(H * 0.3, W * 0.2)
    spots = [(W * 0.16, H * 0.2), (W * 0.84, H * 0.22), (W * 0.15, H * 0.8), (W * 0.85, H * 0.78)]
    out = ["globe %d %d %d on=%s" % (cx, cy, r, _on(tk, _ki(f, 0)))]
    for n, (x, y) in enumerate(spots):
        if n < len(f["keys"]):
            out.append("chip %d %d %s size=19 hot=1 on=%s in=drop delay=%.2f" % (x, y, _q(_kw(f, n)), _on(tk, _ki(f, n)), 0.12 * n))
            out.append("l %d %d %d %d s=accent lw=2 on=%s in=draw" % (cx, cy, x, y, _on(tk, _ki(f, n))))
    return out, "WORLDWIDE"


def _t_file(f, W, H, tint):
    tk = f["tokens"]
    out = []
    for n in range(min(3, max(1, len(f["keys"])))):
        out.append("file %d %d w=%d name=%s sub=%s on=%s in=slide delay=%.2f" % (W / 2, H * (0.2 + 0.3 * n), W * 0.76, _q(_kw(f, n, "notes", 18) + (".pdf" if n == 0 else ".txt")),
                                                                              _q("ready" if n == 0 else "attached"), _on(tk, _ki(f, n)), 0.1 * n))
    return out, "THE DETAILS"


def _t_hub(f, W, H, tint):
    tk = f["tokens"]
    cx, cy = W / 2, H * 0.5
    out = ["card %d %d %d %d title=%s sub=%s on=%s" % (cx, cy, min(W * 0.5, 300), 84, _q(_kw(f, 0, "idea", 16)), _q(_kw(f, 1, "key idea", 18)), _on(tk, _ki(f, 0)))]
    spots = [(W * 0.17, H * 0.15), (W * 0.83, H * 0.15), (W * 0.17, H * 0.85), (W * 0.83, H * 0.85)]
    for n, (x, y) in enumerate(spots):
        if n + 2 < len(f["keys"]) + 1 and n + 1 < len(f["keys"]):
            out.append("chip %d %d %s size=19 hot=%d on=%s in=drop delay=%.2f" % (x, y, _q(_kw(f, n + 1)), 1 if n == 0 else 0, _on(tk, _ki(f, n + 1)), 0.1 * n))
            out.append("l %d %d %d %d s=accent lw=2 on=%s in=draw" % (cx, cy, x, y, _on(tk, _ki(f, n + 1))))
    return out, "KEY IDEA"


def _pick(f, used, idx):
    opts = []
    if f["pivot"] is not None and len(f["keys"]) >= 2:
        opts.append(("compare", 9))
    if len(f["items"]) >= 3:
        opts.append(("list", 9))
    if len(f["nums"]) >= 2 and len({n[3] for n in f["nums"]}) == 1:
        opts.append(("bars", 8))
    if f["nums"]:
        opts.append(("number", 8))
    if f["step"] and len(f["keys"]) >= 2:
        opts.append(("steps", 8))
    if f["question"]:
        opts.append(("search", 7))
    fam = f["fam"]
    if fam.get("growth") or fam.get("decline"):
        opts.append(("trend", 6))
    if fam.get("tech"):
        opts.append(("tech", 6))
    if fam.get("world"):
        opts.append(("globe", 6))
    if fam.get("doc"):
        opts.append(("file", 5))
    if fam.get("money"):
        opts.append(("trend", 5))
    opts += [("hub", 2), ("steps", 1), ("globe", 1)]
    seen, ranked = set(), []
    for n, p in sorted(opts, key=lambda o: -o[1]):
        if n in seen:
            continue
        seen.add(n)
        ranked.append(n)
    need = {"hub": 2, "steps": 1, "globe": 1, "search": 1, "tech": 1, "trend": 1, "file": 1, "number": 0}
    ranked = [n for n in ranked if len(f["keys"]) >= need.get(n, 0) or n in ("number", "list", "compare", "bars")]
    for n in ranked:
        if n not in used[-2:]:
            return n
    return ranked[0] if ranked else "hub"


TEMPLATES = {"number": _t_number, "list": _t_list, "compare": _t_compare, "steps": _t_steps, "trend": _t_trend, "bars": _t_bars,
             "tech": _t_tech, "search": _t_search, "globe": _t_globe, "file": _t_file, "hub": _t_hub}


def _dims(spec):
    style = str(spec.get("style") or "cinema").lower()
    asp = spec.get("aspect", "9:16")
    if style == "doodle":
        return 400, 400
    return {"9:16": (640, 380), "1:1": (420, 330), "16:9": (760, 310)}.get(asp, (640, 380))


def draw_scene(text, spec, idx, used):
    f = analyse(text)
    if not f["keys"]:
        f["keys"] = [0] if f["tokens"] else []
    if not f["tokens"]:
        return None
    W, H = _dims(spec)
    lib = None if spec.get("library") is False else library.build(f["tokens"], W, H, used)
    if lib:
        kind, shapes, tag = lib
        hero = False
    else:
        kind = _pick(f, used, idx)
        shapes, tag = TEMPLATES[kind](f, W, H, "accent")
        hero = kind in ("number", "compare", "search")
    pre = _beam(W, H, hero and idx % 3 == 0)
    if kind in ("number", "tech", "hub") and idx % 3 == 1:
        pre.append("frame %d %d %d %d" % (W / 2, H / 2, W * 0.92, H * 0.94))
    h = int(hashlib.sha1(text.encode("utf-8")).hexdigest()[:6], 16)
    top = _kw(f, 0, "", 10).upper()
    mood = "thinking" if f["question"] else ("excited" if f["pos"] > f["neg"] and f["pos"] else ("worried" if f["neg"] else MOODS[(idx + h) % len(MOODS)]))
    sfx = []
    if f["nums"]:
        sfx.append({"on": _on_word(f["tokens"], f["nums"][0][0]), "do": "ding"})
    elif f["neg"] > f["pos"]:
        sfx.append({"on": _on_word(f["tokens"], next(i for i, t in enumerate(f["tokens"]) if _norm(t) in NEG)), "do": "buzz"})
    elif f["pos"]:
        sfx.append({"on": _on_word(f["tokens"], next(i for i, t in enumerate(f["tokens"]) if _norm(t) in POS)), "do": "ding"})
    elif f["keys"]:
        sfx.append({"on": _on_word(f["tokens"], f["keys"][0]), "do": "pop"})
    return dict(draw=pre + shapes, tag=tag, ghost=top, mood=mood, cam=CAMS[(idx * 2 + h) % len(CAMS)], tint=TINTS[(idx + h % 3) % 4], sfx=sfx, kind=kind)


def _on_word(tokens, i):
    n = _norm(tokens[i])
    return int(i) if (not n or n.isdigit()) else tokens[i]


def autodraw(spec):
    if spec.get("autodraw") is False:
        return spec
    spec = dict(spec)
    scenes = [dict(s) for s in (spec.get("scenes") or [])]
    used = []
    for i, sc in enumerate(scenes):
        if sc.get("outro") or not str(sc.get("narration", "")).strip():
            continue
        vis = sc.get("visual") or sc.get("elements") or []
        vis = [vis] if isinstance(vis, dict) else list(vis)
        has = sc.get("draw") is not None or any(isinstance(e, dict) and str(e.get("type", "")).lower() in ("draw", "image", "photo") for e in vis)
        if has:
            continue
        got = draw_scene(str(sc["narration"]), spec, i, used)
        if not got:
            continue
        used.append(got.pop("kind"))
        sc["draw"] = got.pop("draw")
        sc["auto_drawn"] = True
        sc["auto_kind"] = used[-1]
        for k, v in got.items():
            if v and not sc.get(k):
                sc[k] = v
    spec["scenes"] = scenes
    return spec
