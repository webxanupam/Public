"""lipsync.py - phoneme/viseme driven lip-sync for English.

Pipeline
  1. text -> phonemes (rule based, no network, no model): letters and digraphs.
  2. phonemes -> 11 visemes: A E I O U FV L MBP SZ CHJ REST (the groups on the character sheet).
  3. each word already has start/end times (aligned to the real TTS audio by timing.py); the phonemes are laid over
     the word's span with vowel-long / consonant-short durations, so the mouth hits the right shape at the right time.
  4. at render time the shape is a smooth crossfade between neighbouring visemes, scaled by the real voice envelope
     (amplitude only trims how wide the mouth opens - it never picks the shape) and returns to REST in silence.
If no word timings exist at all, `fallback_state` drives the mouth from the envelope alone.
"""
import math
import re

VISEMES = ["A", "E", "I", "O", "U", "FV", "L", "MBP", "SZ", "CHJ", "REST"]
OPEN = {"A": 1.0, "E": 0.85, "I": 0.75, "O": 0.9, "U": 0.7, "FV": 0.55, "L": 0.6, "MBP": 0.0, "SZ": 0.5, "CHJ": 0.85,
        "REST": 0.0}
VOWEL_SET = {"A", "E", "I", "O", "U"}

_DIGRAPHS = [
    ("tch", "CHJ"), ("sch", "SZ"), ("ph", "FV"), ("sh", "CHJ"), ("ch", "CHJ"), ("th", "L"), ("ck", None),
    ("ng", None), ("wh", "U"), ("kn", None), ("wr", "U"), ("qu", "U"), ("gh", None),
    ("ee", "I"), ("ea", "I"), ("ie", "I"), ("ei", "E"), ("ai", "E"), ("ay", "E"), ("oo", "U"), ("ou", "O"),
    ("ow", "O"), ("oa", "O"), ("oi", "O"), ("oy", "O"), ("au", "A"), ("aw", "A"), ("ew", "U"), ("ue", "U"),
]
_LET = {"a": "A", "e": "E", "i": "I", "o": "O", "u": "U", "y": "I",
        "m": "MBP", "b": "MBP", "p": "MBP", "f": "FV", "v": "FV", "l": "L", "t": "L", "d": "L", "n": "L",
        "s": "SZ", "z": "SZ", "x": "SZ", "j": "CHJ", "w": "U", "r": "U", "q": None, "k": None, "g": None,
        "h": None, "c": None}
_LONG = {"I": 1.15, "A": 1.2, "O": 1.15, "U": 1.1, "E": 1.0}

def _english(word):
    w = re.sub(r"[^a-z]", "", word.lower())
    out, i = [], 0
    if w.endswith("e") and len(w) > 3 and w[-2] not in "aeiouy" and not w.endswith("le"):
        w = w[:-1]
    while i < len(w):
        two, three = w[i:i + 2], w[i:i + 3]
        if three == "tch":
            out.append(("CHJ", 0.7)); i += 3; continue
        hit = next((v for d, v in _DIGRAPHS if d == two), "?")
        if hit != "?":
            if hit:
                out.append((hit, _LONG.get(hit, 0.6)))
            i += 2
            continue
        ch = w[i]
        v = _LET.get(ch)
        if ch == "c":
            v = "SZ" if (i + 1 < len(w) and w[i + 1] in "eiy") else None
        elif ch == "g":
            v = "CHJ" if (i + 1 < len(w) and w[i + 1] in "ei" and i + 2 < len(w)) else None
        elif ch == "y" and i > 0 and i + 1 < len(w) and w[i + 1] in "aeiou":
            v = "I"
        elif ch == "x":
            v = "SZ"
        if v:
            out.append((v, _LONG.get(v, 0.55) if v in VOWEL_SET else 0.55))
        i += 1
    return out

def phonemes(word):
    """word -> [(viseme, weight)] (weight = relative duration). Empty if nothing speakable."""
    if not word:
        return []
    res = _english(re.sub(r"\d", "", word))
    if not res and re.search(r"\d", word):
        res = [("A", 1.0), ("MBP", 0.4), ("E", 1.0)]

    clean = []
    for v, w in res:
        if clean and clean[-1][0] == v and v not in VOWEL_SET:
            clean[-1] = (v, clean[-1][1] + w * 0.4)
        else:
            clean.append((v, w))
    return clean

def _smooth(x):
    x = 0.0 if x < 0 else 1.0 if x > 1 else x
    return x * x * (3 - 2 * x)

class LipSync:
    """Per-scene viseme timeline from word timings [(text, start, end)] (scene-local seconds)."""

    def __init__(self, words):
        self.keys = []
        prev_end = None
        for (text, s, e) in words or []:
            ph = phonemes(text)
            dur = max(0.05, e - s)
            if not ph:
                ph = [("E", 1.0)]

            tot = sum(w for _, w in ph)
            t = s
            for v, w in ph:
                d = dur * w / tot
                self.keys.append((t + d / 2, v, d / 2))
                t += d
            if text.rstrip()[-1:] in ".!?,;:" and e - s > 0.2:
                self.keys.append((e + 0.08, "REST", 0.1))
            prev_end = e
        self.keys.sort()
        self.t_first = self.keys[0][0] if self.keys else 0.0
        self.t_last = self.keys[-1][0] if self.keys else 0.0

    def state(self, lt, env, speaking=True):
        """-> (viseme_a, viseme_b, w, f): crossfade a->b by w, then REST->that by f (mouth-open amount)."""
        if not self.keys or not speaking:
            return ("REST", "REST", 0.0, 0.0)
        ks = self.keys

        lo, hi = 0, len(ks) - 1
        if lt <= ks[0][0]:
            a, b, u = "REST", ks[0][1], _smooth((lt - (ks[0][0] - 0.07)) / 0.07)
        elif lt >= ks[-1][0]:
            a, b, u = ks[-1][1], "REST", _smooth((lt - ks[-1][0]) / 0.09)
        else:
            while hi - lo > 1:
                m = (lo + hi) // 2
                if ks[m][0] <= lt:
                    lo = m
                else:
                    hi = m
            t0, v0, _ = ks[lo]
            t1, v1, _ = ks[hi]
            gap = t1 - t0
            a, b = v0, v1
            if gap > 0.30:
                mid_a = t0 + 0.10
                mid_b = t1 - 0.08
                if lt < mid_a:
                    b, u = "REST", _smooth((lt - t0) / 0.10)
                elif lt > mid_b:
                    a, u = "REST", _smooth((lt - mid_b) / 0.08)
                else:
                    a = b = "REST"; u = 0.0
            else:
                hold = 0.28
                u = _smooth(((lt - t0) / gap - hold) / (1.0 - hold))
        e = 0.0 if env is None else env
        if e < 0.05:
            return ("REST", "REST", 0.0, 0.0)
        f = min(1.0, 0.42 + 0.95 * min(1.0, e / 0.7))
        if a == "MBP" and b == "MBP":
            f = 1.0
        return (a, b, u, f)

def fallback_state(t, env, speaking):
    """No word timings: derive a plausible open/close from the envelope only."""
    if not speaking or env is None or env < 0.07:
        return ("REST", "REST", 0.0, 0.0)
    cyc = int(t * 7.5) % 4
    a = ("A", "E", "O", "I")[cyc]
    b = ("E", "O", "I", "A")[cyc]
    return (a, b, _smooth((t * 7.5) % 1.0), min(1.0, 0.4 + env))
