import re

RULES = [
    ("caution", 9, "warning careful beware caution danger risky unsafe harmful scam सावधान ख़तरा खतरा बचें बचो"),
    ("facepalm", 8, "mistake mistakes oops blunder facepalm embarrassing गलती गलतियाँ ऊप्स"),
    ("fail", 8, "slow crawls crawl crash crashes error fail failed failure broken lag laggy outage terrible worst painful धीमा धीमी खराब फेल नुकसान"),
    ("success", 7, "fast faster fastest instantly great best better win success successful easy boost improve improved "
                   "perfect awesome amazing love solved rankings growth congrats तेज़ तेज बढ़िया सफल शानदार बेहतर जीत कमाल आसान"),
    ("idea", 7, "secret secrets trick tricks hack hacks imagine discover solution aha introducing रहस्य तरीका आइडिया समाधान सीक्रेट ट्रिक उपाय"),
    ("wave", 9, "hi hello hey welcome bye goodbye namaste नमस्ते स्वागत अलविदा"),
    ("point", 6, "look click tap below subscribe follow link देखो क्लिक फॉलो सब्सक्राइब"),
    ("think", 6, "think maybe perhaps consider hmm wonder सोचो शायद सोचिए"),
    ("presenting", 5, "meet today's features steps first second third next overview agenda percent half million billion thousand चलिए पहला दूसरा"),
    ("cross", 4, "but however although लेकिन परंतु मगर"),
]
QUESTION_WORDS = set("why how what which who where when क्यों कैसे क्या कौन कहाँ कब".split())
_WORD = {}
for pose, pr, text in RULES:
    for w in text.split():
        _WORD[re.sub(r"[^\w]", "", w.lower().replace("'", ""))] = (pose, pr)
FILLER = ["front", "hips", "presenting"]


def _norm(w):
    return re.sub(r"[^\w]", "", str(w).lower().replace("'", "").replace("’", ""))


def _sentences(words):
    out, cur = [], []
    for i, w in enumerate(words):
        cur.append(i)
        t = str(w[0]).strip()
        if t[-1:] in (".", "!", "?") or i == len(words) - 1:
            out.append(cur)
            cur = []
    return out


def _sentence_pose(words, idxs):
    first = words[idxs[0]]
    last = str(words[idxs[-1]][0]).strip()[-1:]
    best = None
    for i in idxs:
        tx = str(words[i][0])
        hit = _WORD.get(_norm(tx))
        if hit is None and re.search(r"\d", tx):
            hit = ("presenting", 5)
        if hit and (best is None or hit[1] > best[1]):
            best = (hit[0], hit[1], words[i][1])
    if last == "?":
        pose = "confused" if _norm(first[0]) in QUESTION_WORDS else "think"
        return pose, first[1]
    if best:
        return best[0], max(first[1], best[2] - 0.25)
    return None, first[1]


_WORD_POSES = {p for p, _, _ in RULES} | {"confused"}


def plan(words, base="front", min_gap=1.8):
    if not words:
        return [(0.0, base)]
    seq = [(0.0, base)]
    neutral = ["front", "presenting"]
    ni = 0
    for si, idxs in enumerate(_sentences(words)):
        pose, t = _sentence_pose(words, idxs)
        end = words[idxs[-1]][2]
        if pose is None:
            ni += 1
            pose = neutral[ni % 2]
            t = words[idxs[0]][1]
        t = max(0.0, t - 0.04)
        if pose != seq[-1][1] and t - seq[-1][0] >= (0.6 if len(seq) == 1 else min_gap):
            seq.append((t, pose))
        elif pose != seq[-1][1] and si == 0 and pose in _WORD_POSES:
            seq[-1] = (0.0, pose)
        if end - seq[-1][0] > 3.6 and seq[-1][1] not in neutral:
            ni += 1
            seq.append((seq[-1][0] + 2.4, neutral[ni % 2]))
    pruned = [seq[0]]
    for t, p in seq[1:]:
        if p != pruned[-1][1]:
            pruned.append((t, p))
    return pruned
