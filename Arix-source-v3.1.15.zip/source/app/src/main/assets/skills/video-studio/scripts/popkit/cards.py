"""cards.py - the few generic building blocks around the live drawing: base element, headline text, user photos, label chip.

Every element is an `El`:
    layout(width)        -> sets self.w / self.h (logical units)
    paint(c, ox, oy, lt) -> draws at (ox, oy) on Canvas `c`; lt = seconds since it appeared
    key(lt)              -> hashable animation state (sprite cache key)
    anim_end             -> seconds after which the look no longer changes
Pictures are authored per scene as `draw` elements (see draw.py); there are no ready-made designs.
"""
import os
import re

from PIL import Image

from .gfx import (THEME, BGTEXT, GREY_D, INK, ORANGE, PURPLE, WHITE, clamp, color, ease_out_back, fit_lines, measure, pill,
                  pill_size)

KEY_FPS = 30

def _q(lt, end):
    return int(round(min(max(lt, 0.0), end) * KEY_FPS))

def tfit(c, x, y, text, maxw, size, fill=INK, kind="sans", anchor="mm", min_size=10, lines=1, lh=1.12):
    """Draw text that can never leave its box: shrinks, wraps (<= `lines`), then ellipsises."""
    ls, sz = fit_lines(text, maxw, size, min_size=min_size, kind=kind, max_lines=lines)
    y0 = y - (len(ls) - 1) * sz * lh / 2.0
    for i, ln in enumerate(ls):
        c.text(x, y0 + i * sz * lh, ln, sz, fill=fill, kind=kind, anchor=anchor)
    return sz

class El:
    type = "el"
    anim_end = 0.0
    margin = 10

    def __init__(self, spec=None):
        self.spec = spec or {}
        self.w = 0.0
        self.h = 0.0
        self.at = self.spec.get("at")
        self.on = self.spec.get("on")
        self.rot = float(self.spec.get("rot", 0) or 0)
        self.hold = bool(self.spec.get("hold", False))
        self.max_w = self.spec.get("max_w")
        self.max_h = None
        self.sync = None

    def layout(self, width):
        raise NotImplementedError

    def key(self, lt):
        return _q(lt, self.anim_end)

    def paint(self, c, ox, oy, lt):
        raise NotImplementedError

    def lint(self):
        return []

class Chip(El):
    type = "chip"

    def __init__(self, spec):
        super().__init__(spec)
        self.text = str(spec.get("text", ""))
        self.fill = color(spec.get("color"), ORANGE)
        self.size = float(spec.get("size", 26))

    def layout(self, width):
        size = self.size
        avail = (self.max_w or width) - 8
        while size > 12 and pill_size(self.text, size)[0] > avail:
            size -= 1
        self.fsize = size
        self.w, self.h = pill_size(self.text, size)
        self.w += 4
        self.h += 4

    def paint(self, c, ox, oy, lt):
        pill(c, ox, oy, self.text, fill=self.fill, size=self.fsize)

class Headline(El):
    type = "text"

    def __init__(self, spec):
        super().__init__(spec)
        self.text = str(spec.get("text", ""))
        hl = spec.get("hl") or spec.get("highlight") or []
        self.hl = [hl] if isinstance(hl, str) else list(hl)
        self.card = bool(spec.get("card", True))
        self.size = float(spec.get("size", 40))
        self.sub = str(spec.get("pill", ""))
        self.sub_col = color(spec.get("pill_color"), ORANGE)
        self.col = color(spec.get("hl_color"), PURPLE)
        self.align = spec.get("align", "center")
        self.anim_end = 0.7

    def _wid(self, ws, size):
        return measure(" ".join(ws), "sans", size)[0] + 14 * sum(1 for x in ws if self._is_hl(x))

    def _lines(self, size, maxw):
        words = self.text.split(" ")
        lines, cur = [], []
        for wd in words:
            trial = cur + [wd]
            if cur and self._wid(trial, size) > maxw:
                lines.append(cur)
                cur = [wd]
            else:
                cur.append(wd)
        if cur:
            lines.append(cur)
        return lines

    def layout(self, width):
        self.w = min(width - 12, self.max_w or width - 12)
        pad = 24 if self.card else 4
        size = self.size
        while True:
            lines = self._lines(size, self.w - 2 * pad - 14)
            widest = max(self._wid(l, size) for l in lines)
            if size <= 16 or (widest <= self.w - 2 * pad and len(lines) <= 4):
                break
            size -= 2
        self.fs = size
        self.ls = self._lines(size, self.w - 2 * pad - 14)
        self.lh = size * 1.42
        self.pad = pad
        body = len(self.ls) * self.lh + (2 * pad if self.card else 0)
        self.sub_h = 52 if self.sub else 0
        self.h = body + self.sub_h
        if self.card:
            widest = max(self._wid(l, size) for l in self.ls)
            self.w = min(self.w, widest + 2 * pad + 18)

    def _is_hl(self, word):
        wd = re.sub(r"[^\w]", "", word).lower()
        return any(re.sub(r"[^\w]", "", h).lower() == wd for h in self.hl if h)

    def paint(self, c, ox, oy, lt):
        body = self.h - self.sub_h
        if self.card:
            c.box(ox, oy, self.w, body, r=16, lw=3.5, shadow=(6, 6))
        y = oy + (self.pad if self.card else 0)
        for ln in self.ls:
            widths = [measure(wd, "sans", self.fs)[0] + (14 if self._is_hl(wd) else 0) for wd in ln]
            space = measure(" ", "sans", self.fs)[0]
            total = sum(widths) + space * (len(ln) - 1)
            x = ox + (self.w - total) / 2 if self.align == "center" else ox + self.pad
            for wd, ww in zip(ln, widths):
                if self._is_hl(wd):
                    pop = ease_out_back((lt - 0.25) / 0.3)
                    c.rrect(x, y + 2, ww, self.fs * 1.22 * clamp(pop, 0, 1.0), 10, fill=self.col)
                    c.text(x + 7, y + self.fs * 0.62, wd, self.fs, fill=WHITE, anchor="lm")
                else:
                    c.text(x, y + self.fs * 0.62, wd, self.fs, fill=INK if self.card else BGTEXT, anchor="lm")
                x += ww + space
            y += self.lh
        if self.sub:
            pw, ph = pill_size(self.sub, 24)
            pill(c, ox + (self.w - pw) / 2, oy + body + 8, self.sub, fill=self.sub_col, size=24)

class Photo(El):
    type = "image"
    _cache = {}

    def __init__(self, spec):
        super().__init__(spec)
        self.path = spec.get("path") or spec.get("src") or ""
        self.base_dir = spec.get("_base", "")
        self.caption = str(spec.get("caption", ""))
        self.aspect = float(spec.get("aspect", 0.72))
        self.anim_end = 0.0

    def _img(self):
        p = self.path if os.path.isabs(self.path) else os.path.join(self.base_dir, self.path)
        im = Photo._cache.get(p)
        if im is None:
            try:
                im = Image.open(p).convert("RGB")
                im.thumbnail((1600, 1600))
            except Exception:
                im = Image.new("RGB", (400, 300), (210, 214, 224))
            Photo._cache[p] = im
        return im

    def layout(self, width):
        self.w = min(width - 12, self.max_w or width - 12)
        if self.max_h:
            self.w = min(self.w, max(120.0, (self.max_h - (30 if self.caption else 0)) / self.aspect))
        self.h = self.w * self.aspect + (30 if self.caption else 0)

    def paint(self, c, ox, oy, lt):
        c.box(ox, oy, self.w, self.h, r=16, lw=3.5, shadow=(6, 6))
        ih = self.h - (30 if self.caption else 0)
        im = self._img()
        tw, th = int((self.w - 14) * c.k), int((ih - 14) * c.k)
        s = max(tw / im.width, th / im.height)
        im2 = im.resize((max(1, int(im.width * s)), max(1, int(im.height * s))), Image.LANCZOS)
        l, t = (im2.width - tw) // 2, (im2.height - th) // 2
        im2 = im2.crop((l, t, l + tw, t + th)).convert("RGBA")
        from PIL import ImageDraw
        mask = Image.new("L", im2.size, 0)
        ImageDraw.Draw(mask).rounded_rectangle([0, 0, im2.width - 1, im2.height - 1], radius=10 * c.k, fill=255)
        c.im.paste(im2, (int((ox + 7) * c.k), int((oy + 7) * c.k)), mask)
        if self.caption:
            c.text(ox + self.w / 2, oy + self.h - 15, self.caption[:50], 15, fill=GREY_D, kind="sansm", anchor="mm")

class Follow(El):
    type = "follow"

    def __init__(self, spec):
        super().__init__(spec)
        self.handle = str(spec.get("handle", "@channel"))
        self.toggle = float(spec.get("toggle_at", 1.4))
        self.anim_end = self.toggle + 0.5

    def layout(self, width):
        self.w = min(width - 12, self.max_w or width - 12, 420)
        self.h = 62

    def key(self, lt):
        return (_q(lt, self.anim_end), lt > self.toggle)

    def paint(self, c, ox, oy, lt):
        c.box(ox, oy, self.w, self.h, r=14, lw=3, shadow=(5, 5))
        tfit(c, ox + 18, oy + self.h / 2 + 1, self.handle, self.w - 18 - 150, 21, anchor="lm", min_size=11)
        on = lt > self.toggle
        label = "Following ✓".replace("✓", "").strip() if on else "Follow"
        bw = measure(label, "sans", 17)[0] + (44 if on else 30)
        bx, by = ox + self.w - bw - 12, oy + 12
        if on:
            c.rrect(bx, by, bw, self.h - 24, 8, fill=WHITE, outline=INK, lw=2.6)
            c.text(bx + 14, by + (self.h - 24) / 2 + 1, label, 17, fill=INK, anchor="lm")
            icons.draw(c, "check", bx + bw - 17, by + (self.h - 24) / 2, 7, fg=INK, lw=2.8)
        else:
            c.rrect(bx, by, bw, self.h - 24, 8, fill=PURPLE)
            c.text(bx + bw / 2, by + (self.h - 24) / 2 + 1, label, 17, fill=WHITE, anchor="mm")

class MiniGrid(El):
    type = "minigrid"

    def __init__(self, spec):
        super().__init__(spec)
        self.n = int(spec.get("count", 10))
        self.cols = int(spec.get("cols", 5))
        self.titles = [str(t) for t in (spec.get("titles") or [])]
        self.anim_end = 0.07 * self.n + 0.5

    def layout(self, width):
        self.w = min(width - 12, self.max_w or width - 12)
        gap = 12
        self.cols = int(self.spec.get("cols", 5))
        self.rows = int(math.ceil(self.n / self.cols))
        self.cw = (self.w - gap * (self.cols - 1)) / self.cols
        self.ch = self.cw * 1.55
        self.gap = gap
        self.h = self.rows * self.ch + (self.rows - 1) * gap + 6
        if self.max_h and self.h > self.max_h:
            k = (self.max_h - 6 - (self.rows - 1) * gap) / (self.rows * self.ch)
            self.ch *= max(0.3, k)
            self.cw = self.ch / 1.55
            self.w = self.cw * self.cols + gap * (self.cols - 1)
            self.h = self.rows * self.ch + (self.rows - 1) * gap + 6

    def paint(self, c, ox, oy, lt):
        for i in range(self.n):
            r, col = divmod(i, self.cols)
            t_in = (lt - i * 0.07) / 0.28
            if t_in <= 0:
                continue
            sc = ease_out_back(t_in)
            x = ox + col * (self.cw + self.gap)
            y = oy + r * (self.ch + self.gap)
            cx, cy = x + self.cw / 2, y + self.ch / 2
            ww, hh = self.cw * sc, self.ch * sc
            c.box(cx - ww / 2, cy - hh / 2, ww, hh, r=9 * sc, lw=2.4, shadow=(3, 3))
            if sc < 0.8:
                continue
            c.rrect(cx - ww / 2 + 6, cy - hh / 2 + 7, ww - 12, 7, 3, fill=CYCLE[i % len(CYCLE)])
            for k in range(3):
                c.rrect(cx - ww / 2 + 6, cy - hh / 2 + 20 + k * 9, (ww - 12) * (0.9 - 0.2 * k), 4, 2, fill=(206, 210, 222))
            c.ellipse(cx - ww / 2 + 14, cy + hh / 2 - 15, 8, fill=(201, 138, 85), outline=INK, lw=1.8)
            c.rrect(cx - ww / 2 + 7, cy + hh / 2 - 9, 15, 6, 3, fill=TEAL)

class Row(El):
    type = "row"

    def __init__(self, spec, children):
        super().__init__(spec)
        self.kids = children
        self.gap = 14
        self.weights = spec.get("weights")

    def layout(self, width):
        self.w = min(width - 12, self.max_w or width - 12)
        n = len(self.kids)
        wts = self.weights or [1] * n
        tot = float(sum(wts))
        avail = self.w - self.gap * (n - 1)
        self.cell = []
        for k, wt in zip(self.kids, wts):
            cw = avail * wt / tot
            k.layout(cw + 12)
            self.cell.append(cw)
        self.h = max(k.h for k in self.kids)

    @property
    def anim_end(self):
        return max(k.anim_end for k in self.kids) + 0.4 * len(self.kids)

    @anim_end.setter
    def anim_end(self, v):
        pass

    def key(self, lt):
        return tuple(k.key(max(0.0, lt - 0.18 * i)) for i, k in enumerate(self.kids))

    def paint(self, c, ox, oy, lt):
        x = ox
        for i, (k, cw) in enumerate(zip(self.kids, self.cell)):
            t = lt - 0.18 * i
            if t > 0:
                sc = ease_out_back(t / 0.3)
                if sc < 0.999:
                    pass
                k.paint(c, x + (cw - k.w) / 2, oy + (self.h - k.h) / 2, t)
            x += cw + self.gap

def _headline(s):
    from .draw import Draw
    lines = s.get("lines") or str(s.get("text", "")).split("|")
    lines = [str(x) for x in ([lines] if isinstance(lines, str) else lines) if str(x).strip()]
    size = float(s.get("size", 46))
    lh = size * 1.12
    W = 400.0
    shapes = []
    under = s.get("under")
    for i, ln in enumerate(lines):
        y = lh * i + lh / 2 + 4
        shapes.append({"t": "text", "x": W / 2, "y": y, "text": ln.upper() if s.get("caps", True) else ln, "size": size, "kind": "sans" if THEME.get("cine") else "hand",
                       "w": W - 16, "lines": 1, "fill": "bgtext" if i == 0 else "accent", "in": "rise", "delay": 0.22 * i, "dur": 0.4})
        if under == i:
            wd = min(W - 40, 0.46 * size * len(ln))
            yy = y + size * 0.52
            shapes.append({"t": "path", "d": "M %g %g Q %g %g %g %g T %g %g" % (W / 2 - wd / 2, yy, W / 2 - wd / 4, yy - 5, W / 2, yy, W / 2 + wd / 2, yy - 1),
                           "stroke": "soft" if THEME.get("cine") else "accent2", "lw": 5, "in": "draw", "delay": 0.22 * i + 0.4, "dur": 0.5})
    return Draw({"type": "draw", "size": [W, lh * len(lines) + 14], "shapes": shapes, "max_w": s.get("max_w"), "_base": s.get("_base", "")})

def build(spec, base_dir=""):
    """JSON dict -> El."""
    if not isinstance(spec, dict):
        raise ValueError("a visual element must be an object like {\"type\": \"draw\", ...}")
    t = str(spec.get("type", "")).lower()
    s = dict(spec)
    s["_base"] = base_dir
    if t == "draw":
        from .draw import Draw
        return Draw(s)
    if t in ("chip", "label"):
        return Chip(s)
    if t == "headline":
        return _headline(s)
    if t == "text":
        return Headline(s)
    if t in ("image", "photo"):
        return Photo(s)
    if t in ("subscribe", "outro"):
        from .outro import Subscribe
        return Subscribe(s)
    raise ValueError("unknown element type '%s': draw the picture yourself with {\"type\": \"draw\", \"shapes\": [...]}" % t)
