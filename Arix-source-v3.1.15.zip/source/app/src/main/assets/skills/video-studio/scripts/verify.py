#!/usr/bin/env python3
"""verify.py - quality gate for a Video Studio v4 render.

  python3 verify.py video.mp4 [--report video.report.json] [--sheet sheet.png] [--expect-audio]

Checks (exit 1 on any problem; JSON on stdout):
  * container: h264 video + audio, A/V durations within 0.15 s, no black/frozen start
  * layout lint from the renderer report is empty (no overflow / cut-off / off-canvas)
  * SYNC, measured independently on the FINAL file: the audio is re-extracted from the mp4 and every
    caption word's time span must carry voice energy (>= 92 % of words)
  * the presenter is on screen: pixel check of the presenter zone in a frame of every normal scene
  * research present in the report
Writes a contact sheet when --sheet is given - LOOK at it.
"""
import argparse, json, os, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

def probe(path):
    out = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "stream=codec_type,codec_name,width,height,duration",
                          "-of", "json", path], capture_output=True, text=True).stdout
    return json.loads(out or "{}").get("streams", [])

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("video")
    ap.add_argument("--report")
    ap.add_argument("--sheet")
    ap.add_argument("--expect-audio", action="store_true")
    a = ap.parse_args()
    problems, info = [], {}
    if not os.path.isfile(a.video):
        print(json.dumps({"ok": False, "problems": ["file not found"]}))
        return 1
    st = probe(a.video)
    v = next((s for s in st if s["codec_type"] == "video"), None)
    au = next((s for s in st if s["codec_type"] == "audio"), None)
    if not v:
        problems.append("no video stream")
    else:
        info["size"] = [v.get("width"), v.get("height")]
        info["video_duration"] = float(v.get("duration") or 0)
    if au:
        info["audio_duration"] = float(au.get("duration") or 0)
        if v and abs(info["audio_duration"] - info["video_duration"]) > 0.15:
            problems.append(f"audio/video length differ by {abs(info['audio_duration'] - info['video_duration']):.2f}s")
    elif a.expect_audio:
        problems.append("no audio stream")

    rp = a.report or os.path.splitext(a.video)[0] + ".report.json"
    rep = json.load(open(rp, encoding="utf-8")) if os.path.isfile(rp) else None
    if rep is None:
        problems.append("renderer report missing (%s) - cannot check layout/sync" % rp)
    else:
        if rep.get("lint"):
            for l in rep["lint"][:8]:
                problems.append(f"layout: scene {l.get('scene')}: {l.get('problem')} ({l.get('element')})")
        if not rep.get("research", True):
            problems.append("no research block in the spec")

    if rep and au:
        try:
            import numpy as np
            from popkit import timing
            with tempfile.TemporaryDirectory() as td:
                wav = os.path.join(td, "a.wav")
                subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", a.video, "-vn", "-ac", "1", "-ar", "24000", wav], check=True)
                env = timing.envelope(timing.read_wav(wav))
            n = ok = 0
            bad = []
            for sc in rep["scenes"]:
                if not sc.get("voice_engine"):
                    continue
                for w, s, e in sc["words"]:
                    i0 = int((sc["start"] + s) * 100)
                    i1 = max(int((sc["start"] + e) * 100), i0 + 1)
                    seg = env[i0:i1]
                    n += 1
                    if len(seg) and float(seg.mean()) >= 0.14:
                        ok += 1
                    else:
                        bad.append([round(sc["start"] + s, 2), w])
            if n:
                info["sync_voiced_ratio"] = round(ok / n, 3)
                if ok / n < 0.92:
                    problems.append(f"caption/voice sync: only {ok}/{n} caption words fall on voice ({bad[:6]})")
        except Exception as ex:
            info["sync_check"] = f"skipped ({ex})"

    try:
        from PIL import Image
        from popkit.render import LAYOUTS, Renderer
        asp = "9:16"
        if v and v.get("width") and v.get("height"):
            r = v["width"] / v["height"]
            asp = "16:9" if r > 1.3 else "1:1" if r > 0.9 else "9:16"
        L = LAYOUTS[asp]
        frames = []
        with tempfile.TemporaryDirectory() as td:
            scenes = (rep or {}).get("scenes") or []
            times = [(sc["start"] + min(sc["duration"] * 0.6, sc["duration"] - 0.2), sc) for sc in scenes] or [(1.0, None)]
            seen = 0
            for k, (t, sc) in enumerate(times):
                fp = os.path.join(td, f"f{k}.png")
                subprocess.run(["ffmpeg", "-v", "error", "-y", "-ss", f"{t:.2f}", "-i", a.video, "-frames:v", "1", fp], check=True)
                im = Image.open(fp).convert("RGB")
                frames.append(im.copy())
                if sc:
                    s = im.width / L["W"]
                    lay = Renderer._cine_layout(L)
                    cfg = lay["hero"] if sc.get("layout") == "hero" else lay["main"]
                    k, cx, feet = cfg["k"], cfg["cx"], cfg["feet"]
                    box = (int((cx - 51 * k) * s), int((feet - 480 * k) * s), int((cx + 51 * k) * s), int((feet - 415 * k) * s))
                    crop = im.crop(box)
                    px = crop.load()
                    bright = sum(1 for x in range(0, crop.width, 2) for y in range(0, crop.height, 2)
                                 if sum(px[x, y]) / 3.0 > 170)
                    tot = ((crop.width + 1) // 2) * ((crop.height + 1) // 2)
                    seen += 1
                    if bright / max(1, tot) < 0.12:
                        problems.append(f"presenter not visible in scene {sc['index']}")
            info["presenter_checked_scenes"] = seen
        if a.sheet and frames:
            cols = min(6, len(frames))
            rows = (len(frames) + cols - 1) // cols
            tw = 270
            th = int(tw * frames[0].height / frames[0].width)
            sheet = Image.new("RGB", (cols * tw, rows * th), (255, 255, 255))
            for i, f in enumerate(frames):
                sheet.paste(f.resize((tw, th)), ((i % cols) * tw, (i // cols) * th))
            sheet.save(a.sheet)
            info["sheet"] = a.sheet
    except Exception as ex:
        info["frame_check"] = f"skipped ({ex})"

    print(json.dumps({"ok": not problems, "problems": problems, **info}, ensure_ascii=False))
    return 0 if not problems else 1

if __name__ == "__main__":
    sys.exit(main())
