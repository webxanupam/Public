import math

from . import reactions as _rx

def _w(s):
    return "".join(ch for ch in str(s).lower() if ch.isalnum())

def _pulse(x):
    if x < 0:
        return 0.0
    if x < 0.08:
        return x / 0.08
    return math.exp(-(x - 0.08) / 0.2)

def _lerp(a, b, w):
    return a + (b - a) * w

MOODS = {
    "happy": dict(smile=1.6, brow_y=-0.8, eyes=1.0, act="explain"),
    "neutral": dict(smile=-1.2, brow_y=0.0, eyes=1.0, act="idle"),
    "excited": dict(smile=3.2, brow_y=-2.6, eyes=1.08, act="cheer"),
    "surprised": dict(smile=0.0, brow_y=-4.2, eyes=1.2, act="surprise"),
    "sad": dict(smile=-3.2, brow_y=0.5, brow_tilt=-10, eyes=0.92, act="sad"),
    "angry": dict(smile=-2.5, brow_y=1.2, brow_tilt=15, eyes=0.86, act="angry"),
    "confused": dict(smile=-0.8, brow_y=-1.0, eyes=1.0, act="confused"),
    "thinking": dict(smile=-0.5, brow_y=-1.6, eyes=1.0, act="think", look=(-0.9, -0.9)),
    "laugh": dict(smile=3.0, brow_y=-1.5, eyes=1.0, shape="happy", act="laugh"),
    "confident": dict(smile=2.2, brow_y=-0.6, brow_tilt=4, eyes=0.94, act="present"),
    "calm": dict(smile=0.8, brow_y=0.0, eyes=0.98, act="present"),
}
ALIAS = {"curious": "thinking", "joy": "excited", "wow": "surprised", "shock": "surprised", "smug": "confident",
         "proud": "confident", "worried": "sad", "serious": "neutral", "fun": "laugh", "funny": "laugh", "happy!": "happy"}

IDLE = (3.0, 0.0, 0.0, 0)
HANDS_BY = {"wave": ("relaxed", "open"), "wave2": ("open", "open"), "cheer": ("fist", "fist"),
            "point": ("relaxed", "point"), "point2": ("point", "relaxed"), "angry": ("fist", "fist")}

POSE_BY = {"wave": "wave", "wave2": "wave", "laugh": "wave", "point": "point", "point2": "point", "think": "think",
           "present": "presenting", "presenting": "presenting", "cheer": "success", "clap": "success", "success": "success",
           "surprise": "idea", "idea": "idea", "shrug": "confused", "confused": "confused", "sad": "fail", "fail": "fail",
           "facepalm": "facepalm", "angry": "caution", "caution": "caution", "lean": "cross", "cross": "cross", "hips": "hips",
           "open": "open", "explain": "front"}

def _gesture(name, t, u):
    s = math.sin
    pi2 = 2 * math.pi
    hl_, hr2_ = HANDS_BY.get(name, ("relaxed", "relaxed"))
    d = dict(PA=POSE_BY.get(name, "front"), L=IDLE, R=IDLE, HL=hl_, HR=hr2_, hr=0.0, hdy=0.0, hdx=0.0, rot=0.0, sy=1.0, dy=0.0, eyes=None, shape=None, look=None, brow_y=0.0, smile=0.0, mouth=None)
    if name == "wave":
        d.update(R=(112 + 5 * s(pi2 * 1.2 * t), 38 + 14 * s(pi2 * 2.6 * t), 30 * s(pi2 * 2.6 * t + 1.2), 0), hr=3.5, shape="happy" if s(t * 1.1) > 0.35 else None, smile=1.5)
    elif name == "wave2":
        d.update(R=(112 + 5 * s(pi2 * 1.2 * t), 38 + 14 * s(pi2 * 2.6 * t), 30 * s(pi2 * 2.6 * t + 1.2), 0),
                 L=(112 + 5 * s(pi2 * 1.2 * t + 1), 38 + 14 * s(pi2 * 2.6 * t + 1), 30 * s(pi2 * 2.6 * t + 2.2), 0), hr=2, smile=2)
    elif name == "present":
        d.update(L=(36 + 3 * s(pi2 * 0.5 * t), 26, 10, 0), R=(36 + 3 * s(pi2 * 0.5 * t + 1), 26, 10, 0), hr=2.0 * s(pi2 * 0.25 * t))
    elif name == "explain":
        a = s(pi2 * 0.7 * t)
        b = s(pi2 * 0.7 * t + 2.4)
        d.update(L=(14 + 12 * max(0, b), 18 * max(0, b), 8 * b, 0), R=(24 + 18 * max(0, a), 30 * max(0, a), 10 * a, 0), hr=1.6 * s(pi2 * 0.35 * t), hdx=1.2 * s(pi2 * 0.35 * t))
    elif name == "cheer":
        q = abs(s(pi2 * 1.8 * t))
        d.update(L=(138 + 6 * s(pi2 * 3.6 * t), 14 + 10 * s(pi2 * 3.6 * t), 18 * s(pi2 * 3.6 * t + 1), 0),
                 R=(138 + 6 * s(pi2 * 3.6 * t + 1), 14 + 10 * s(pi2 * 3.6 * t + 1), 18 * s(pi2 * 3.6 * t), 0), dy=-9 * q, sy=1 + 0.014 * (1 - q), shape="happy" if q < 0.5 else None, smile=3, hr=3 * s(pi2 * 0.9 * t))
    elif name == "think":
        d.update(R=(30, -112, -6, 1), hr=-4, look=(-0.9, -1.0), brow_y=-1.5, hdy=0.6 * s(pi2 * 0.3 * t))
    elif name == "point":
        d.update(R=(132 + 3 * s(pi2 * 1.4 * t), -6, 0, 0), L=(5, 0, 0, 0), hr=4, smile=1.2, look=(0.8, -0.7))
    elif name == "point2":
        d.update(L=(132 + 3 * s(pi2 * 1.4 * t), -6, 0, 0), R=(5, 0, 0, 0), hr=-4, smile=1.2, look=(-0.8, -0.7))
    elif name == "shrug":
        k = 0.5 - 0.5 * math.cos(pi2 * 0.9 * t)
        d.update(L=(38, -48, 12, 0), R=(38, -48, 12, 0), hr=6 * s(pi2 * 0.45 * t), hdy=-2.0 * k, sy=1 - 0.006 * k, brow_y=-2, brow_tilt=-6, smile=-1)
    elif name == "surprise":
        k = 1 - math.exp(-u * 8)
        d.update(L=(52 * k + 3, -30 * k, 14 * k, 0), R=(52 * k + 3, -30 * k, 14 * k, 0), hdy=-3 * k, sy=1 + 0.016 * k, dy=-4 * k * (1 if u < 0.4 else 0), eyes=1.2, brow_y=-4, mouth="O")
    elif name == "laugh":
        sh = s(pi2 * 5.2 * t)
        d.update(L=(18, 30, 0, 0), R=(18, 30, 0, 0), hr=-6 + 1.5 * sh, hdy=1.6 * sh, dy=-2.2 * abs(sh), sy=1 + 0.01 * sh, shape="happy", smile=3.5, mouth="A")
    elif name == "sad":
        d.update(L=(3, 0, 0, 0), R=(3, 0, 0, 0), hr=-5, hdy=4.0, sy=0.985, rot=-0.6, brow_tilt=-10, smile=-3)
    elif name == "angry":
        sh = s(pi2 * 7 * t)
        d.update(L=(14, -96, 0, 1), R=(14, -96, 0, 1), hr=0.8 * sh, hdy=3.0, rot=0.3 * sh, brow_tilt=15, brow_y=1, eyes=0.86, smile=-2.5)
    elif name == "clap":
        k = 0.5 + 0.5 * s(pi2 * 3.2 * t)
        d.update(L=(14 + 12 * k, -104, 0, 1), R=(14 + 12 * k, -104, 0, 1), hr=2.0 * s(pi2 * 1.6 * t), dy=-1.4 * k, shape="happy", smile=3)
    elif name == "nod":
        d.update(hdy=3.0 * abs(s(pi2 * 1.3 * t)), hr=0)
    elif name == "shake":
        d.update(hr=7 * s(pi2 * 2.8 * t), hdx=2 * s(pi2 * 2.8 * t))
    elif name == "bow":
        k = math.sin(math.pi * min(1.0, u))
        d.update(hdy=7 * k, hr=0, rot=1.4 * k, sy=1 - 0.012 * k)
    elif name == "lean":
        d.update(rot=2.4, hr=-3, L=(8, 0, 0, 0), R=(18, 20, 0, 0))
    return d

class Motion:
    def __init__(self, sc, default_mood="happy"):
        self.sc = sc
        mood = str(sc.spec.get("mood") or default_mood or "happy").lower()
        mood = ALIAS.get(mood, mood)
        self.mood = MOODS.get(mood, MOODS["happy"])
        act = sc.spec.get("act")
        if act is None and sc.spec.get("outro"):
            act = "wave"
        self.act = str(act or self.mood["act"]).lower()
        self.words = sc.words
        self.beats = []
        for i, (tx, s, e) in enumerate(sc.words):
            strong = len(_w(tx)) >= 7 or tx[-1:] in "!?:" or (tx[-1:] in ".," and e - s > 0.3)
            self.beats.append((s, 1.0 if strong else 0.45, i))
        self.seq = None
        if sc.spec.get("act") is None and not sc.spec.get("acts") and not sc.spec.get("outro") and sc.spec.get("auto_react", True) and sc.words:
            self.seq = _rx.plan(sc.words, POSE_BY.get(self.act, "front"))
        self.timed = []
        for a in (sc.spec.get("acts") or []):
            if not isinstance(a, dict):
                continue
            t0 = self._when(a)
            dur = float(a.get("dur", 1.2))
            self.timed.append((t0, dur, str(a.get("do") or a.get("act") or "nod").lower()))

    def _when(self, a):
        if a.get("at") is not None:
            return max(0.0, float(a["at"]))
        on = a.get("on")
        ws = self.words
        if on is None or not ws:
            return 0.0
        if isinstance(on, int):
            return ws[max(0, min(len(ws) - 1, on))][1]
        want = _w(on)
        for (tx, s, e) in ws:
            if _w(tx) == want:
                return s
        return 0.0

    def _blend(self, lt, t):
        base = _gesture(self.act, t, lt / max(0.3, self.sc.dur))
        base["PB"] = None
        base["PW"] = 0.0
        if self.seq:
            i = 0
            for n, (t0, nm) in enumerate(self.seq):
                if t0 <= lt:
                    i = n
            base["PA"] = self.seq[i][1]
            x = lt - self.seq[i][0]
            if i > 0 and x < 0.14 and self.seq[i - 1][1] != self.seq[i][1]:
                base["PA"], base["PB"], base["PW"] = self.seq[i - 1][1], self.seq[i][1], x / 0.14
        for (t0, dur, name) in self.timed:
            x = lt - t0
            if -0.001 <= x <= dur:
                w = min(1.0, x / 0.09, (dur - x) / 0.1)
                w = max(0.0, w)
                w = w * w * (3 - 2 * w)
                g = _gesture(name, t, x / max(0.1, dur))
                if g["PA"] != base["PA"] and w > 0.0:
                    base["PB"], base["PW"] = g["PA"], w
                for k in ("hr", "hdy", "hdx", "rot", "dy", "brow_y", "smile"):
                    base[k] = _lerp(base[k], g[k], w)
                base["sy"] = _lerp(base["sy"], g["sy"], w)
                for side in ("L", "R"):
                    if g[side] != IDLE:
                        base[side] = tuple(_lerp(base[side][i], g[side][i], w) for i in range(3)) + (g[side][3] if w > 0.4 else base[side][3],)
                for k in ("eyes", "shape", "look", "mouth"):
                    if g[k] is not None and w > 0.3:
                        base[k] = g[k]
                if w > 0.4:
                    for k in ("HL", "HR"):
                        if g[k] != "relaxed":
                            base[k] = g[k]
        return base

    def _adapt(self, name):
        if name is None:
            return None
        if name == "presenting":
            return "open"
        if name == "point" and getattr(self, "layout", "side") == "above" and not getattr(self, "cta", False):
            return "open"
        return name

    def pose(self, lt, t, mouth, blink, env):
        m = self.mood
        g = self._blend(lt, t)
        ramp = min(1.0, lt / 0.35)
        idle_sway = math.sin(t * 2 * math.pi / 4.1)
        breath = math.sin(t * 2 * math.pi / 3.3)
        pul = 0.0
        strong = 0.0
        for (s, st, i) in self.beats:
            p = _pulse(lt - s) * st
            if p > pul:
                pul = p
                strong = st
        side = 0
        for (s, st, i) in self.beats:
            if lt >= s:
                side = i
        beat_arm = 0.0
        if self.act in ("explain", "present", "idle", "calm") and pul > 0.05:
            beat_arm = pul * (1.0 if strong > 0.9 else 0.5)
        armL, armR = list(g["L"]), list(g["R"])
        if beat_arm:
            if side % 2 == 0:
                armR[0] += 16 * beat_arm
                armR[1] += 26 * beat_arm
                armR[2] += 8 * beat_arm
            else:
                armL[0] += 16 * beat_arm
                armL[1] += 26 * beat_arm
                armL[2] += 8 * beat_arm
        armL[0] += 1.5 * breath
        armR[0] += 1.5 * math.sin(t * 2 * math.pi / 3.3 + 1)
        look = g["look"] or m.get("look") or (0.5 * math.sin(t * 0.7), 0.3 * math.sin(t * 0.9 + 1))
        shape = g["shape"] or m.get("shape") or "round"
        eyes = g["eyes"] if g["eyes"] is not None else m["eyes"]
        brow_y = m["brow_y"] + g["brow_y"] - 1.6 * pul * (1 if strong > 0.9 else 0.4)
        tilt = m.get("brow_tilt", 0.0)
        smile = m["smile"] + g["smile"]
        if mouth == ("REST", "REST", 0.0, 0.0) or not isinstance(mouth, tuple) or mouth[3] < 0.05:
            if g["mouth"] in VIS_OK:
                mouth = (g["mouth"], g["mouth"], 0.0, 0.75)
        pa, pb, pw = g["PA"], g["PB"], g["PW"]
        if pb is None and not self.seq and pa == "front" and self.act in ("explain", "idle", "calm", "neutral", "happy"):
            wo = 0.0
            for (s, st, i) in self.beats:
                if st < 0.9:
                    continue
                x = lt - s
                if x < -0.05 or x > 1.5:
                    continue
                up = min(1.0, max(0.0, (x + 0.05) / 0.1))
                dn = min(1.0, max(0.0, (1.5 - x) / 0.12))
                wo = max(wo, min(up, dn))
            if wo > 0.01:
                pb, pw = "presenting", wo
        pa, pb = self._adapt(pa), self._adapt(pb)
        if pb == pa:
            pb = None
        pose = {
            "pa": pa,
            "pb": pb,
            "pw": pw,
            "mouth": mouth,
            "blink": blink,
            "look": look,
            "eyes": eyes,
            "shape": shape,
            "brow_y": brow_y,
            "brow_tilt": tilt,
            "smile": smile,
            "head_rot": g["hr"] + 0.9 * idle_sway + 1.2 * pul * (1 if side % 2 else -1) * 0.5,
            "head_dx": g["hdx"],
            "head_dy": g["hdy"] + 0.8 * breath + 2.4 * pul * (1.0 if strong > 0.9 else 0.45),
            "handL": g["HL"],
            "handR": g["HR"],
            "armL": (armL[0], armL[1], armL[2], armL[3]),
            "armR": (armR[0], armR[1], armR[2], armR[3]),
            "rot": g["rot"] + 0.35 * idle_sway,
            "sy": g["sy"] * (1 + 0.005 * breath),
            "dy": g["dy"] - 1.6 * pul * (1.0 if strong > 0.9 else 0.3),
        }
        for kx in ("armL", "armR"):
            sh, el, wr, fr = pose[kx]
            pose[kx] = (sh * ramp + IDLE[0] * (1 - ramp), el * ramp, wr * ramp, fr if ramp > 0.5 else 0)
        return pose

VIS_OK = ("A", "E", "I", "O", "U")
