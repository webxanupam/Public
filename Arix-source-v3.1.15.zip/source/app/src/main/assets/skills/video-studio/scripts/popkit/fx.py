import math

from PIL import Image, ImageFilter

try:
    import numpy as np
except Exception:
    np = None


def project(u, v, pivot, ax, ay, dist=700.0):
    X, Y = u - pivot[0], v - pivot[1]
    a, b = math.radians(ax), math.radians(ay)
    Y2 = Y * math.cos(a)
    Z = Y * math.sin(a)
    X2 = X * math.cos(b) + Z * math.sin(b)
    Z2 = -X * math.sin(b) + Z * math.cos(b)
    s = dist / max(120.0, dist + Z2)
    return pivot[0] + X2 * s, pivot[1] + Y2 * s


def persp_coeffs(dst, src):
    if np is None:
        return None
    A = []
    B = []
    for (x, y), (u, v) in zip(dst, src):
        A.append([x, y, 1, 0, 0, 0, -u * x, -u * y])
        A.append([0, 0, 0, x, y, 1, -v * x, -v * y])
        B += [u, v]
    try:
        return [float(c) for c in np.linalg.solve(np.array(A, dtype=float), np.array(B, dtype=float))]
    except Exception:
        return None


def halo(layer_im, rgb, radius_px, strength):
    q = 4 if radius_px >= 6 else 2
    a = layer_im.getchannel("A")
    r = max(1.0, radius_px)
    pad = int(r * 2.6)
    pad -= pad % q
    sw, sh = max(1, (a.width + 2 * pad) // q), max(1, (a.height + 2 * pad) // q)
    small = Image.new("L", (sw, sh), 0)
    small.paste(a.resize((max(1, a.width // q), max(1, a.height // q)), Image.BILINEAR), (pad // q, pad // q))
    small = small.filter(ImageFilter.GaussianBlur(max(0.6, r / q)))
    k = max(0.0, min(2.0, strength))
    small = small.point(lambda v, k=k: min(255, int(v * k * 1.6)))
    big = small.resize((a.width + 2 * pad, a.height + 2 * pad), Image.BILINEAR)
    out = Image.new("RGBA", big.size, tuple(rgb) + (0,))
    out.putalpha(big)
    return out, pad


def blit(dst, src, x, y):
    x, y = int(x), int(y)
    sx, sy = 0, 0
    if x < 0:
        sx, x = -x, 0
    if y < 0:
        sy, y = -y, 0
    w = min(src.width - sx, dst.width - x)
    h = min(src.height - sy, dst.height - y)
    if w <= 0 or h <= 0:
        return
    if sx or sy or w != src.width or h != src.height:
        src = src.crop((sx, sy, sx + w, sy + h))
    dst.alpha_composite(src, (x, y))
