import shlex

_TYPES = {"r": "rect", "c": "circle", "e": "ellipse", "l": "line", "p": "poly", "a": "arc", "d": "path", "t": "text", "k": "stick"}
_ALIAS = {"f": "fill", "s": "stroke", "w": "lw", "o": "opacity", "dl": "delay", "du": "dur", "sh": "shadow", "lp": "loop"}
_ARGS = {"beam": ("x", "y", "w", "h"), "frame": ("x", "y", "w", "h"), "card": ("x", "y", "w", "h"), "term": ("x", "y", "w", "h"), "check": ("x", "y", "w"), "num": ("x", "y", "text", "size"),
         "chip": ("x", "y", "text"), "search": ("x", "y", "w"), "file": ("x", "y", "w"), "bars": ("x", "y", "w", "h"),
         "ring": ("x", "y", "r", "pct"), "spark": ("x", "y", "w", "h"), "globe": ("x", "y", "r"), "badge": ("x", "y", "text"),
         "rect": ("x", "y", "w", "h", "r"), "circle": ("cx", "cy", "r"), "ellipse": ("cx", "cy", "rx", "ry"),
         "arc": ("cx", "cy", "r", "a0", "a1"), "text": ("x", "y", "text", "size"),
         "stick": ("who", "x", "y", "h", "pose", "mood")}


def _val(v):
    low = v.lower()
    if low in ("true", "false"):
        return low == "true"
    try:
        return float(v) if ("." in v or "e" in low) else int(v)
    except ValueError:
        pass
    if "," in v:
        parts = v.split(",")
        try:
            return [float(p) for p in parts]
        except ValueError:
            return v
    return v


def parse_shape(s):
    try:
        toks = shlex.split(s)
    except ValueError:
        toks = s.split()
    if not toks:
        return {}
    head = toks[0]
    kind = _TYPES.get(head, head)
    out = {"t": kind}
    pos, keys = [], []
    for tk in toks[1:]:
        if "=" in tk and not tk.startswith("=") and tk.split("=", 1)[0].replace("_", "").isalnum() and not tk[0].isdigit() and tk[0] not in "-+.":
            keys.append(tk)
        else:
            pos.append(tk)
    if kind in ("line", "poly"):
        nums = [float(x) for x in pos]
        out["pts"] = [[nums[i], nums[i + 1]] for i in range(0, len(nums) - 1, 2)]
    elif kind == "path":
        out["d"] = " ".join(pos)
    else:
        names = _ARGS.get(kind, ())
        for n, v in zip(names, pos):
            out[n] = v if n in ("text", "who", "pose", "mood") else _val(v)
    for tk in keys:
        k, v = tk.split("=", 1)
        if not (kind == "text" and k == "w"):
            k = _ALIAS.get(k, k)
        if k == "mv":
            a = _val(v)
            a = a if isinstance(a, list) else [a]
            out["move"] = {"by": [a[0], a[1] if len(a) > 1 else 0], "at": a[2] if len(a) > 2 else 0, "dur": a[3] if len(a) > 3 else 0.8}
            if len(a) > 4:
                out["move"]["arc"] = a[4]
        else:
            out[k] = _val(v)
    return out
