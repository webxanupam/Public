"""esrgan_np.py - pure NumPy Real-ESRGAN (RRDBNet) runner used at build time only.

Weights (not shipped, 17 MB): https://github.com/xinntao/Real-ESRGAN/releases/download/v0.2.2.4/RealESRGAN_x4plus_anime_6B.pth
"""
import collections
import io
import pickle
import zipfile

import numpy as np


class _Storage:
    def __init__(self, arr):
        self.arr = arr


def load_pth(path):
    z = zipfile.ZipFile(path)
    base = z.namelist()[0].split("/")[0]

    class U(pickle.Unpickler):
        def find_class(self, mod, name):
            if name == "_rebuild_tensor_v2":
                def rebuild(storage, off, size, stride, *a):
                    return np.lib.stride_tricks.as_strided(storage.arr[off:], shape=size, strides=[s * storage.arr.itemsize for s in stride]).copy()
                return rebuild
            if name == "OrderedDict":
                return collections.OrderedDict
            if name in ("FloatStorage", "HalfStorage"):
                return name
            if name == "_rebuild_parameter":
                return lambda data, *a: data
            return super().find_class(mod, name)

        def persistent_load(self, pid):
            typ, st, key, loc, n = pid
            data = z.read("%s/data/%s" % (base, key))
            return _Storage(np.frombuffer(data, dtype=np.float32 if "Float" in str(st) else np.float16))

    return U(io.BytesIO(z.read("%s/data.pkl" % base))).load()


def conv(x, w, b):
    H, W, C = x.shape
    O = w.shape[0]
    xp = np.pad(x, ((1, 1), (1, 1), (0, 0)), mode="edge")
    win = np.lib.stride_tricks.sliding_window_view(xp, (3, 3), axis=(0, 1))
    cols = win.transpose(0, 1, 3, 4, 2).reshape(H * W, 9 * C)
    return (cols @ w.transpose(0, 2, 3, 1).reshape(O, 9 * C).T + b).reshape(H, W, O).astype(np.float32)


def lrelu(x):
    return np.where(x > 0, x, 0.2 * x)


class Net:
    def __init__(self, path, nb=6):
        sd = load_pth(path)
        self.p = sd.get("params_ema") or sd.get("params") or sd
        self.nb = nb

    def c(self, x, name):
        return conv(x, self.p[name + ".weight"], self.p[name + ".bias"])

    def rdb(self, x, pre):
        x1 = lrelu(self.c(x, pre + ".conv1"))
        x2 = lrelu(self.c(np.concatenate([x, x1], 2), pre + ".conv2"))
        x3 = lrelu(self.c(np.concatenate([x, x1, x2], 2), pre + ".conv3"))
        x4 = lrelu(self.c(np.concatenate([x, x1, x2, x3], 2), pre + ".conv4"))
        return self.c(np.concatenate([x, x1, x2, x3, x4], 2), pre + ".conv5") * 0.2 + x

    def forward(self, x):
        fea = self.c(x.astype(np.float32), "conv_first")
        t = fea
        for i in range(self.nb):
            pre = "body.%d" % i
            t = self.rdb(self.rdb(self.rdb(t, pre + ".rdb1"), pre + ".rdb2"), pre + ".rdb3") * 0.2 + t
        fea = fea + self.c(t, "conv_body")
        fea = lrelu(self.c(fea.repeat(2, 0).repeat(2, 1), "conv_up1"))
        fea = lrelu(self.c(fea.repeat(2, 0).repeat(2, 1), "conv_up2"))
        return self.c(lrelu(self.c(fea, "conv_hr")), "conv_last")

    def up(self, rgb, tile=80, pad=10):
        h, w, _ = rgb.shape
        out = np.zeros((h * 4, w * 4, 3), np.float32)
        for y in range(0, h, tile):
            for x in range(0, w, tile):
                y0, x0 = max(0, y - pad), max(0, x - pad)
                y1, x1 = min(h, y + tile + pad), min(w, x + tile + pad)
                r = self.forward(rgb[y0:y1, x0:x1])
                oy, ox = (y - y0) * 4, (x - x0) * 4
                th, tw = min(tile, h - y) * 4, min(tile, w - x) * 4
                out[y * 4:y * 4 + th, x * 4:x * 4 + tw] = r[oy:oy + th, ox:ox + tw]
        return np.clip(out, 0, 1)
