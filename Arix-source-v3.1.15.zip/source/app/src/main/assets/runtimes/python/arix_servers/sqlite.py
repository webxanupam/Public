#!/usr/bin/env python3
"""Arix bundled MCP server: SQLite (pure Python stdlib `sqlite3`, no dependencies, no network).

Usage: sqlite.py [DB_PATH]   (default ./arix.db, created on first use)
Tools: query (read-only SELECT/PRAGMA/EXPLAIN), execute (INSERT/UPDATE/DELETE/DDL), list_tables, describe_table.
"""
import json
import os
import sqlite3
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _stdio import serve

DB = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else "arix.db")
MAX_ROWS = 500
READ_PREFIXES = ("select", "with", "pragma", "explain")

def conn():
    os.makedirs(os.path.dirname(DB), exist_ok=True)
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def text(obj, error=False):
    s = obj if isinstance(obj, str) else json.dumps(obj, indent=2, ensure_ascii=False, default=str)
    r = {"content": [{"type": "text", "text": s}]}
    if error:
        r["isError"] = True
    return r

def query(a):
    sql = (a.get("sql") or "").strip()
    if not sql.lower().startswith(READ_PREFIXES):
        return text("query only runs SELECT / WITH / PRAGMA / EXPLAIN statements. Use `execute` for changes.", True)
    try:
        with conn() as c:
            cur = c.execute(sql, a.get("params") or [])
            rows = cur.fetchmany(MAX_ROWS + 1)
            out = [dict(r) for r in rows[:MAX_ROWS]]
            return text({"columns": [d[0] for d in (cur.description or [])], "rows": out,
                         "truncated": len(rows) > MAX_ROWS})
    except sqlite3.Error as exc:
        return text("SQL error: %s" % exc, True)

def execute(a):
    sql = (a.get("sql") or "").strip()
    if not sql:
        return text("sql is required", True)
    try:
        with conn() as c:
            cur = c.execute(sql, a.get("params") or [])
            c.commit()
            return text({"ok": True, "rows_affected": cur.rowcount, "last_insert_rowid": cur.lastrowid})
    except sqlite3.Error as exc:
        return text("SQL error: %s" % exc, True)

def list_tables(_a=None):
    try:
        with conn() as c:
            names = [r[0] for r in c.execute(
                "SELECT name FROM sqlite_master WHERE type IN ('table','view') AND name NOT LIKE 'sqlite_%' ORDER BY name")]
            res = []
            for n in names:
                q = '"%s"' % n.replace('"', '""')
                res.append({"name": n, "rows": c.execute("SELECT COUNT(*) FROM %s" % q).fetchone()[0]})
            return text({"database": DB, "tables": res})
    except sqlite3.Error as exc:
        return text("SQL error: %s" % exc, True)

def describe_table(a):
    name = a.get("table") or ""
    try:
        with conn() as c:
            cols = [dict(r) for r in c.execute('PRAGMA table_info("%s")' % name.replace('"', '""'))]
            if not cols:
                return text("No such table: %s" % name, True)
            return text({"table": name, "columns": cols})
    except sqlite3.Error as exc:
        return text("SQL error: %s" % exc, True)

S = {"type": "string"}
PARAMS = {"type": "array", "items": {}, "description": "Optional positional ? parameters"}
TOOLS = [
    {"name": "query", "description": "Run a read-only SQL query (SELECT/WITH/PRAGMA/EXPLAIN); returns up to %d rows." % MAX_ROWS,
     "inputSchema": {"type": "object", "properties": {"sql": S, "params": PARAMS}, "required": ["sql"]}},
    {"name": "execute", "description": "Run INSERT/UPDATE/DELETE or DDL (CREATE/ALTER/DROP) and commit.",
     "inputSchema": {"type": "object", "properties": {"sql": S, "params": PARAMS}, "required": ["sql"]}},
    {"name": "list_tables", "description": "List tables and views with their row counts.",
     "inputSchema": {"type": "object", "properties": {}}},
    {"name": "describe_table", "description": "Show the columns of a table.",
     "inputSchema": {"type": "object", "properties": {"table": S}, "required": ["table"]}},
]
HANDLERS = {"query": query, "execute": execute, "list_tables": list_tables, "describe_table": describe_table}

if __name__ == "__main__":
    serve("arix-sqlite", "1.0.0", TOOLS, HANDLERS, "SQLite database at " + DB)
