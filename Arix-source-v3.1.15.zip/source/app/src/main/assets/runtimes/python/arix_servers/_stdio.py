"""Minimal MCP stdio server loop (JSON-RPC 2.0, newline-delimited). Standard library only."""
import json
import sys

PROTOCOL = "2025-06-18"

def serve(server_name, version, tools, handlers, instructions=""):
    """Blocking loop: reads requests on stdin, answers on stdout (stderr is for logs)."""
    out = sys.stdout

    def send(obj):
        out.write(json.dumps(obj, ensure_ascii=False) + "\n")
        out.flush()

    def result(rid, res):
        send({"jsonrpc": "2.0", "id": rid, "result": res})

    def error(rid, code, message):
        send({"jsonrpc": "2.0", "id": rid, "error": {"code": code, "message": message}})

    sys.stderr.write(f"{server_name} ready\n")
    sys.stderr.flush()
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except ValueError:
            continue
        if not isinstance(msg, dict) or msg.get("jsonrpc") != "2.0" or not isinstance(msg.get("method"), str):
            continue
        rid = msg.get("id")
        method = msg["method"]
        params = msg.get("params") or {}
        if method == "initialize":
            result(rid, {
                "protocolVersion": params.get("protocolVersion") or PROTOCOL,
                "capabilities": {"tools": {"listChanged": False}},
                "serverInfo": {"name": server_name, "version": version},
                "instructions": instructions,
            })
        elif method in ("notifications/initialized", "notifications/cancelled"):
            continue
        elif method == "ping":
            result(rid, {})
        elif method == "tools/list":
            result(rid, {"tools": tools})
        elif method == "tools/call":
            handler = handlers.get(params.get("name"))
            if handler is None:
                result(rid, {"content": [{"type": "text", "text": "Unknown tool: %s" % params.get("name")}], "isError": True})
                continue
            try:
                result(rid, handler(params.get("arguments") or {}))
            except Exception as exc:
                result(rid, {"content": [{"type": "text", "text": "Error: %s" % exc}], "isError": True})
        elif method == "resources/list":
            result(rid, {"resources": []})
        elif method == "prompts/list":
            result(rid, {"prompts": []})
        elif rid is not None:
            error(rid, -32601, "Method not found: " + method)
