#!/usr/bin/env python3
"""arix_mcp.py - the ONE global package store + launcher for MCP servers, extensions and tools.

Why: before, every MCP connection installed its own copy of a package (npx cache in ~/.npm/_npx, bundled
index.js in ~/.arix/mcp-servers, per-server node_modules), the entry file and the installed packages
lived in different places and the start command/args did not match. Now:

  ~/.arix/store/
      registry.json     who (owner = connection id) uses which package
      npm/              ONE shared node_modules for every Node package (package.json = union of owners)
      pip/site/         ONE shared site-packages (pip --target) for every Python package
      cache/            npm/pip download cache (emptied after installs; set ARIX_KEEP_CACHE=1 to keep)

Commands (all print one JSON object on the last stdout line, except `run`, which execs the server):
  run     --owner ID [--] COMMAND ARGS...   resolve + install missing packages once, then exec the server
  ensure  --owner ID [--npm SPEC]... [--pip SPEC]...
  release --owner ID                        owner no longer uses anything -> prune packages nobody uses
  gc                                        prune everything no owner uses (orphans, partial installs)
  list                                      what is installed and who uses it
  migrate [--remove PATH]...                delete legacy per-server dirs (npx cache, old mcp-servers)

`run` understands: npx/pnpm dlx/bunx/npm exec, node <file>, uvx/pipx run, python/python3 and any other command
(passed through, with the shared store on NODE_PATH / PYTHONPATH). Pure standard library.
"""
import argparse
import contextlib
import json
import os
import re
import shutil
import subprocess
import sys
import time

try:
    import fcntl
except ImportError:
    fcntl = None

HOME = os.environ.get("ARIX_HOME") or os.path.join(os.environ.get("HOME") or os.path.expanduser("~"), ".arix")
STORE = os.environ.get("ARIX_STORE") or os.path.join(HOME, "store")
NPM_DIR = os.path.join(STORE, "npm")
NODE_MODULES = os.path.join(NPM_DIR, "node_modules")
PIP_SITE = os.path.join(STORE, "pip", "site")
CACHE = os.path.join(STORE, "cache")
REG_FILE = os.path.join(STORE, "registry.json")
LOCK_FILE = os.path.join(STORE, ".lock")

def out(obj, code=0):
    sys.stdout.write(json.dumps(obj, ensure_ascii=False) + "\n")
    sys.stdout.flush()
    sys.exit(code)

def log(msg):
    sys.stderr.write("[arix-mcp] %s\n" % msg)
    sys.stderr.flush()

@contextlib.contextmanager
def locked():
    os.makedirs(STORE, exist_ok=True)
    fh = open(LOCK_FILE, "a+")
    try:
        if fcntl:
            fcntl.flock(fh, fcntl.LOCK_EX)
        yield
    finally:
        try:
            if fcntl:
                fcntl.flock(fh, fcntl.LOCK_UN)
        finally:
            fh.close()

def load_reg():
    try:
        with open(REG_FILE, encoding="utf-8") as f:
            r = json.load(f)
    except Exception:
        r = {}
    for k in ("npm", "pip"):
        if not isinstance(r.get(k), dict):
            r[k] = {}
    return r

def save_reg(r):
    os.makedirs(STORE, exist_ok=True)
    tmp = REG_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(r, f, indent=2, sort_keys=True)
    os.replace(tmp, REG_FILE)

def claim(reg, owner, npm_specs, pip_specs):
    """Owner's package set is REPLACED by exactly these (a changed command never leaks old packages)."""
    for kind in ("npm", "pip"):
        for name, ent in list(reg[kind].items()):
            if owner in ent["owners"]:
                ent["owners"].remove(owner)
    for kind, specs in (("npm", npm_specs), ("pip", pip_specs)):
        for spec in specs:
            name, ver = split_spec(spec, kind)
            ent = reg[kind].setdefault(name, {"spec": ver, "owners": [], "installed": False})
            if ent.get("spec") != ver:
                ent["spec"] = ver
                ent["installed"] = False
            if owner not in ent["owners"]:
                ent["owners"].append(owner)

def split_spec(spec, kind):
    """'@scope/pkg@1.2' -> ('@scope/pkg', '1.2'); 'pkg' -> ('pkg', 'latest'); pip 'a==1' -> ('a', '==1')."""
    spec = spec.strip()
    if kind == "pip":
        m = re.match(r"^([A-Za-z0-9._-]+)(\[[^\]]*\])?\s*(.*)$", spec)
        if not m:
            return spec, ""
        return m.group(1), (m.group(3) or "")
    if spec.startswith("@"):
        i = spec.find("@", 1)
    else:
        i = spec.find("@")
    if i > 0:
        return spec[:i], (spec[i + 1:] or "latest")
    return spec, "latest"

def norm_pip(n):
    return re.sub(r"[-_.]+", "-", n).lower()

def find_tool(name):
    p = shutil.which(name)
    if p:
        return p
    for d in (os.environ.get("PREFIX", "") + "/bin", "/usr/local/bin", "/usr/bin", "/data/data/com.termux/files/usr/bin"):
        c = os.path.join(d, name)
        if os.path.isfile(c) and os.access(c, os.X_OK):
            return c
    return None

def store_env():
    env = dict(os.environ)
    env["npm_config_cache"] = os.path.join(CACHE, "npm")
    env["PIP_CACHE_DIR"] = os.path.join(CACHE, "pip")
    env["NODE_PATH"] = os.pathsep.join([p for p in (NODE_MODULES, env.get("NODE_PATH", "")) if p])
    env["PYTHONPATH"] = os.pathsep.join([p for p in (PIP_SITE, env.get("PYTHONPATH", "")) if p])
    env["ARIX_STORE"] = STORE
    return env

def run_quiet(cmd, cwd=None, env=None, timeout=900):
    log("$ " + " ".join(cmd))
    p = subprocess.run(cmd, cwd=cwd, env=env or store_env(), stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                       text=True, timeout=timeout)
    if p.returncode != 0:
        raise RuntimeError("%s failed (exit %d): %s" % (cmd[0], p.returncode, (p.stdout or "").strip()[-1500:]))
    return p.stdout

def clear_cache():
    if os.environ.get("ARIX_KEEP_CACHE") != "1":
        shutil.rmtree(CACHE, ignore_errors=True)

def pkg_dir(name):
    return os.path.join(NODE_MODULES, *name.split("/"))

def npm_installed(name):
    return os.path.isfile(os.path.join(pkg_dir(name), "package.json"))

def write_npm_manifest(reg):
    os.makedirs(NPM_DIR, exist_ok=True)
    deps = {n: e.get("spec") or "latest" for n, e in sorted(reg["npm"].items()) if e["owners"]}
    with open(os.path.join(NPM_DIR, "package.json"), "w", encoding="utf-8") as f:
        json.dump({"name": "arix-global-store", "private": True, "version": "1.0.0", "dependencies": deps}, f, indent=2)

def install_npm(reg):
    need = [n for n, e in reg["npm"].items() if e["owners"] and (not e.get("installed") or not npm_installed(n))]
    if not need:
        return
    npm = find_tool("npm")
    if not npm:
        raise RuntimeError("npm is not available - Node.js runtime is required for this server (install nodejs)")
    write_npm_manifest(reg)
    run_quiet([npm, "install", "--prefix", NPM_DIR, "--omit=dev", "--no-audit", "--no-fund", "--no-package-lock",
               "--loglevel=error"], cwd=NPM_DIR)
    for n in need:
        if not npm_installed(n):
            raise RuntimeError("npm reported success but %s is not in the store" % n)
        reg["npm"][n]["installed"] = True

def npm_entry(name, bin_hint=None):
    """Absolute path of the JS file that starts package `name` (from its package.json)."""
    pj = os.path.join(pkg_dir(name), "package.json")
    with open(pj, encoding="utf-8") as f:
        meta = json.load(f)
    b = meta.get("bin")
    base = name.split("/")[-1]
    rel = None
    if isinstance(b, str):
        rel = b
    elif isinstance(b, dict) and b:
        rel = b.get(bin_hint) or b.get(base) or next(iter(b.values()))
    if not rel:
        rel = meta.get("main") or "index.js"
    return os.path.normpath(os.path.join(pkg_dir(name), rel))

def npm_bin_entry(binname):
    """Find the package that provides executable `binname` (npx <bin> form, bin != package name)."""
    if not os.path.isdir(NODE_MODULES):
        return None
    for top in sorted(os.listdir(NODE_MODULES)):
        cands = [top] if not top.startswith("@") else [top + "/" + s for s in sorted(os.listdir(os.path.join(NODE_MODULES, top)))]
        for c in cands:
            try:
                with open(os.path.join(pkg_dir(c), "package.json"), encoding="utf-8") as f:
                    b = json.load(f).get("bin")
            except Exception:
                continue
            if isinstance(b, dict) and binname in b:
                return c, binname
    return None

def read_json(path):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def lookup_dep(dep, from_dir):
    """Directory node would load `dep` from, searching node_modules upward from from_dir (stops at the store)."""
    cur = os.path.realpath(from_dir)
    stop = os.path.realpath(NPM_DIR)
    while True:
        cand = os.path.join(cur, "node_modules", *dep.split("/"))
        if os.path.isfile(os.path.join(cand, "package.json")):
            return cand
        if cur == stop or len(cur) <= len(stop):
            return None
        cur = os.path.dirname(cur)

def prune_npm(reg):
    """Delete every top-level dir of the shared node_modules that no owned package (transitively) needs."""
    removed = []
    if not os.path.isdir(NODE_MODULES):
        return removed
    keep = set()
    real_nm = os.path.realpath(NODE_MODULES)
    queue = [pkg_dir(n) for n, e in reg["npm"].items() if e["owners"] and npm_installed(n)]
    seen = set()
    while queue:
        d = os.path.realpath(queue.pop())
        if d in seen:
            continue
        seen.add(d)
        rel = os.path.relpath(d, real_nm)
        if not rel.startswith(".."):
            parts = rel.split(os.sep)
            keep.add("/".join(parts[:2]) if parts[0].startswith("@") else parts[0])
        meta = read_json(os.path.join(d, "package.json"))
        deps = {}
        for k in ("dependencies", "optionalDependencies", "peerDependencies"):
            deps.update(meta.get(k) or {})
        for dep in deps:
            found = lookup_dep(dep, d)
            if found:
                queue.append(found)
    for top in sorted(os.listdir(NODE_MODULES)):
        full = os.path.join(NODE_MODULES, top)
        if top.startswith("."):
            if top == ".bin":
                shutil.rmtree(full, ignore_errors=True)
            continue
        if top.startswith("@"):
            for sub in sorted(os.listdir(full)):
                nm = top + "/" + sub
                if nm not in keep:
                    shutil.rmtree(os.path.join(full, sub), ignore_errors=True)
                    removed.append(nm)
            if not os.listdir(full):
                os.rmdir(full)
        elif top not in keep:
            shutil.rmtree(full, ignore_errors=True)
            removed.append(top)
    write_npm_manifest(reg)
    if not any(e["owners"] for e in reg["npm"].values()):
        shutil.rmtree(NPM_DIR, ignore_errors=True)
    return removed

def dist_infos():
    res = {}
    if not os.path.isdir(PIP_SITE):
        return res
    for e in os.listdir(PIP_SITE):
        if e.endswith(".dist-info"):
            m = re.match(r"^(.+?)-\d", e)
            if m:
                res[norm_pip(m.group(1))] = os.path.join(PIP_SITE, e)
    return res

def pip_installed(name):
    return norm_pip(name) in dist_infos()

def install_pip(reg):
    need = [n for n, e in reg["pip"].items() if e["owners"] and (not e.get("installed") or not pip_installed(n))]
    if not need:
        return
    py = sys.executable or find_tool("python3")
    os.makedirs(PIP_SITE, exist_ok=True)
    reqs = [n + (reg["pip"][n].get("spec") or "") for n in need]
    run_quiet([py, "-m", "pip", "install", "--target", PIP_SITE, "--upgrade", "--no-input",
               "--disable-pip-version-check", "--no-warn-script-location"] + reqs)
    for n in need:
        if not pip_installed(n):
            raise RuntimeError("pip reported success but %s is not in the store" % n)
        reg["pip"][n]["installed"] = True

def requires_of(info_dir):
    names = []
    try:
        with open(os.path.join(info_dir, "METADATA"), encoding="utf-8", errors="replace") as f:
            for line in f:
                if line.startswith("Requires-Dist:"):
                    body = line.split(":", 1)[1].strip()
                    if "extra ==" in body or "extra==" in body:
                        continue
                    m = re.match(r"([A-Za-z0-9._-]+)", body)
                    if m:
                        names.append(norm_pip(m.group(1)))
                elif not line.strip():
                    break
    except OSError:
        pass
    return names

def prune_pip(reg):
    removed = []
    dists = dist_infos()
    if not dists:
        return removed
    keep, queue = set(), [norm_pip(n) for n, e in reg["pip"].items() if e["owners"]]
    while queue:
        n = queue.pop()
        if n in keep or n not in dists:
            continue
        keep.add(n)
        queue.extend(requires_of(dists[n]))
    for n, info in dists.items():
        if n in keep:
            continue
        files = set()
        try:
            with open(os.path.join(info, "RECORD"), encoding="utf-8") as f:
                for line in f:
                    p = line.rsplit(",", 2)[0].strip().strip('"')
                    if p:
                        files.add(p)
        except OSError:
            pass
        tops = set()
        for p in files:
            full = os.path.normpath(os.path.join(PIP_SITE, p))
            if not full.startswith(os.path.realpath(PIP_SITE) + os.sep) and not full.startswith(PIP_SITE + os.sep):
                continue
            tops.add(p.split("/")[0])
            with contextlib.suppress(OSError):
                os.remove(full)
        for t in tops:
            tp = os.path.join(PIP_SITE, t)
            if os.path.isdir(tp):
                shutil.rmtree(tp, ignore_errors=True)
        shutil.rmtree(info, ignore_errors=True)
        removed.append(n)
    if not any(e["owners"] for e in reg["pip"].values()):
        shutil.rmtree(os.path.join(STORE, "pip"), ignore_errors=True)
    return removed

def pip_entry(name):
    """('module:function') of the first console script of an installed pip package."""
    info = dist_infos().get(norm_pip(name))
    if not info:
        return None
    try:
        with open(os.path.join(info, "entry_points.txt"), encoding="utf-8") as f:
            sect = ""
            for line in f:
                line = line.strip()
                if line.startswith("["):
                    sect = line
                elif sect == "[console_scripts]" and "=" in line:
                    return line.split("=", 1)[1].split("[")[0].strip()
    except OSError:
        pass
    return None

def prune_all(reg):
    for kind in ("npm", "pip"):
        for n in [n for n, e in reg[kind].items() if not e["owners"]]:
            del reg[kind][n]
    r = {"npm": prune_npm(reg), "pip": prune_pip(reg)}
    clear_cache()
    return r

def ensure_set(owner, npm_specs, pip_specs):
    with locked():
        reg = load_reg()
        claim(reg, owner, npm_specs, pip_specs)
        try:
            install_npm(reg)
            install_pip(reg)
        finally:
            removed = prune_all(reg)
            save_reg(reg)
    return removed

NPX_NAMES = {"npx", "npx.cmd", "bunx", "pnpx"}

def parse_npx(args):
    """-> (packages[], first_exec_target, rest_args). Handles -y/--yes, -p/--package, --no-install, --."""
    pkgs, i = [], 0
    while i < len(args):
        a = args[i]
        if a in ("-y", "--yes", "-q", "--quiet", "--no-install", "--prefer-online", "--prefer-offline", "--ignore-existing"):
            i += 1
        elif a in ("-p", "--package"):
            if i + 1 < len(args):
                pkgs.append(args[i + 1])
            i += 2
        elif a.startswith("--package="):
            pkgs.append(a.split("=", 1)[1])
            i += 1
        elif a == "--":
            i += 1
            break
        elif a.startswith("-") and not pkgs and a not in ("-c",):
            i += 1
        else:
            break
    if i >= len(args):
        return pkgs, None, []
    target, rest = args[i], args[i + 1:]
    return pkgs, target, rest

BUNDLED = {
    "@modelcontextprotocol/server-sequential-thinking": "sequential_thinking.py",
    "@modelcontextprotocol/server-memory": "memory.py",
}

def bundled_argv(pkg_spec, rest):
    f = BUNDLED.get(split_spec(pkg_spec, "npm")[0])
    if not f:
        return None
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "arix_servers", f)
    return [sys.executable or "python3", path] + list(rest)

def build_plan(cmd):
    """-> dict(npm=[specs], pip=[specs], argv=[...]|None, finish=callable(reg)->argv)."""
    exe = os.path.basename(cmd[0])
    args = cmd[1:]
    plan = {"npm": [], "pip": [], "post": None}
    if exe in NPX_NAMES or (exe in ("npm", "pnpm") and args[:1] in (["exec"], ["dlx"])) or (exe == "pnpm" and args[:1] == ["dlx"]):
        if exe in ("npm", "pnpm"):
            args = args[1:]
        pkgs, target, rest = parse_npx(args)
        if target is None and not pkgs:
            raise RuntimeError("npx command without a package")
        spec = pkgs[0] if pkgs else target
        b = bundled_argv(spec, rest)
        if b:
            plan["bundled"] = b
            return plan
        plan["npm"] = list(pkgs) if pkgs else [target]
        tname = split_spec(spec, "npm")[0]

        def post_npx():
            if npm_installed(tname):
                entry = npm_entry(tname, target if pkgs else None)
            else:
                found = npm_bin_entry(target or "")
                if not found:
                    raise RuntimeError("cannot find executable for %s" % spec)
                entry = npm_entry(found[0], found[1])
            return [find_tool("node") or "node", entry] + (rest if not pkgs else rest)
        plan["post"] = post_npx
        if pkgs and target and split_spec(target, "npm")[0] not in [split_spec(p, "npm")[0] for p in pkgs]:
            pass
        return plan
    if exe in ("uvx", "pipx") or (exe == "pipx" and args[:1] == ["run"]) or (exe == "uv" and args[:1] == ["tool"]):
        a = list(args)
        if exe == "pipx" and a[:1] == ["run"]:
            a = a[1:]
        if exe == "uv":
            a = a[2:] if a[:2] == ["tool", "run"] else a[1:]
        a = [x for x in a if x not in ("-y", "--yes", "-q")]
        frm = None
        if "--from" in a:
            k = a.index("--from")
            frm = a[k + 1]
            del a[k:k + 2]
        target = a[0] if a else None
        if not target:
            raise RuntimeError("uvx command without a package")
        spec = frm or target
        spec = re.sub(r"@(\d)", r"==\1", spec) if "==" not in spec else spec
        plan["pip"] = [spec]
        pname = split_spec(spec, "pip")[0]

        def post_uvx():
            ep = pip_entry(pname)
            if not ep:
                return [sys.executable, "-m", pname.replace("-", "_")] + a[1:]
            mod, _, fn = ep.partition(":")
            code = "import sys,%s as m;sys.argv[0]=%r;sys.exit(m.%s())" % (mod.split(".")[0], target, fn) if "." not in mod \
                else "import sys,importlib;m=importlib.import_module(%r);sys.argv[0]=%r;sys.exit(m.%s())" % (mod, target, fn)
            return [sys.executable, "-c", code] + a[1:]
        plan["post"] = post_uvx
        return plan
    return plan

def cmd_run(ns):
    cmd = ns.argv[1:] if ns.argv and ns.argv[0] == "--" else ns.argv
    if not cmd:
        out({"ok": False, "error": "no command"}, 2)
    try:
        plan = build_plan(cmd)
        if plan.get("bundled"):
            ensure_set(ns.owner, [], [])
            argv = plan["bundled"]
        elif plan["npm"] or plan["pip"]:
            ensure_set(ns.owner, plan["npm"], plan["pip"])
            argv = plan["post"]()
        else:
            argv = cmd
    except Exception as exc:
        log("cannot prepare '%s': %s" % (" ".join(cmd), exc))
        sys.stderr.write("arix-mcp: %s\n" % exc)
        sys.exit(3)
    if argv[0] in ("python", "python3") and sys.executable:
        argv = [sys.executable] + argv[1:]
    exe = shutil.which(argv[0], path=store_env().get("PATH")) or argv[0]
    try:
        os.execvpe(exe, argv, store_env())
    except OSError as exc:
        sys.stderr.write("arix-mcp: cannot start %s: %s\n" % (argv[0], exc))
        sys.exit(127)

def cmd_ensure(ns):
    try:
        removed = ensure_set(ns.owner, ns.npm or [], ns.pip or [])
    except Exception as exc:
        out({"ok": False, "error": str(exc)}, 3)
    out({"ok": True, "owner": ns.owner, "pruned": removed})

def cmd_release(ns):
    with locked():
        reg = load_reg()
        claim(reg, ns.owner, [], [])
        removed = prune_all(reg)
        save_reg(reg)
    out({"ok": True, "owner": ns.owner, "pruned": removed})

def cmd_gc(_ns):
    with locked():
        reg = load_reg()

        for n, e in list(reg["npm"].items()):
            if e["owners"] and not npm_installed(n):
                e["installed"] = False
        removed = prune_all(reg)
        save_reg(reg)
    out({"ok": True, "pruned": removed})

def dir_size(path):
    total = 0
    for root, _d, files in os.walk(path):
        for f in files:
            with contextlib.suppress(OSError):
                total += os.lstat(os.path.join(root, f)).st_size
    return total

def cmd_list(_ns):
    with locked():
        reg = load_reg()
    out({"ok": True, "store": STORE, "npm": reg["npm"], "pip": reg["pip"],
         "bytes": dir_size(STORE) if os.path.isdir(STORE) else 0})

def cmd_migrate(ns):
    gone = []
    for p in ns.remove or []:
        p = os.path.abspath(p)

        if p in (os.path.abspath(HOME), os.path.abspath(STORE), os.path.expanduser("~"), "/"):
            continue
        if os.path.isdir(p):
            shutil.rmtree(p, ignore_errors=True)
            gone.append(p)
    out({"ok": True, "removed": gone})

def main():
    ap = argparse.ArgumentParser(prog="arix_mcp")
    sub = ap.add_subparsers(dest="action", required=True)
    r = sub.add_parser("run")
    r.add_argument("--owner", required=True)
    r.add_argument("argv", nargs=argparse.REMAINDER)
    e = sub.add_parser("ensure")
    e.add_argument("--owner", required=True)
    e.add_argument("--npm", action="append")
    e.add_argument("--pip", action="append")
    rl = sub.add_parser("release")
    rl.add_argument("--owner", required=True)
    sub.add_parser("gc")
    sub.add_parser("list")
    m = sub.add_parser("migrate")
    m.add_argument("--remove", action="append")
    ns = ap.parse_args()
    {"run": cmd_run, "ensure": cmd_ensure, "release": cmd_release, "gc": cmd_gc, "list": cmd_list,
     "migrate": cmd_migrate}[ns.action](ns)

if __name__ == "__main__":
    main()
