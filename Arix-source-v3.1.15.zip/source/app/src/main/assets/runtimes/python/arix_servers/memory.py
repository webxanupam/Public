#!/usr/bin/env python3
"""Arix bundled MCP server: Knowledge Graph Memory (pure Python, no dependencies, no network).

Same tool contracts as the official `@modelcontextprotocol/server-memory`: a persistent
graph of entities, relations and observations stored as JSON. File: --memory-path <file>,
$ARIX_MEMORY_FILE, or ~/.arix/memory-graph.json.
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _stdio import serve

def memory_file(argv):
    if "--memory-path" in argv:
        i = argv.index("--memory-path")
        if i + 1 < len(argv):
            return os.path.abspath(argv[i + 1])
    if os.environ.get("ARIX_MEMORY_FILE"):
        return os.path.abspath(os.environ["ARIX_MEMORY_FILE"])
    return os.path.join(os.environ.get("HOME") or os.getcwd(), ".arix", "memory-graph.json")

FILE = memory_file(sys.argv[1:])
graph = {"entities": [], "relations": []}

def load():
    global graph
    try:
        with open(FILE, encoding="utf-8") as f:
            parsed = json.load(f)
        graph = {"entities": parsed.get("entities") if isinstance(parsed.get("entities"), list) else [],
                 "relations": parsed.get("relations") if isinstance(parsed.get("relations"), list) else []}
    except Exception:
        graph = {"entities": [], "relations": []}

def save():
    try:
        os.makedirs(os.path.dirname(FILE), exist_ok=True)
        tmp = FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(graph, f, indent=2, ensure_ascii=False)
        os.replace(tmp, FILE)
    except OSError as exc:
        sys.stderr.write("memory: could not persist graph: %s\n" % exc)

def text(s):
    return {"content": [{"type": "text", "text": s}]}

def find(name):
    return next((e for e in graph["entities"] if e["name"] == name), None)

def create_entities(a):
    created = []
    for e in a.get("entities") or []:
        if not isinstance(e, dict) or not isinstance(e.get("name"), str) or not e["name"].strip():
            continue
        if find(e["name"]):
            continue
        graph["entities"].append({
            "name": e["name"],
            "entityType": e["entityType"] if isinstance(e.get("entityType"), str) else "unknown",
            "observations": [o for o in (e.get("observations") or []) if isinstance(o, str)],
        })
        created.append(e["name"])
    if created:
        save()
    return text("Entities created: " + (", ".join(created) or "none"))

def create_relations(a):
    created = []
    for r in a.get("relations") or []:
        if not isinstance(r, dict) or not all(isinstance(r.get(k), str) for k in ("from", "to", "relationType")):
            continue
        if any(x["from"] == r["from"] and x["to"] == r["to"] and x["relationType"] == r["relationType"]
               for x in graph["relations"]):
            continue
        if not find(r["from"]) or not find(r["to"]):
            continue
        graph["relations"].append({"from": r["from"], "to": r["to"], "relationType": r["relationType"]})
        created.append("%s -[%s]-> %s" % (r["from"], r["relationType"], r["to"]))
    if created:
        save()
    return text("Relations created: " + ("; ".join(created) or "none"))

def add_observations(a):
    added = []
    for o in a.get("observations") or []:
        if not isinstance(o, dict) or not isinstance(o.get("entityName"), str) or not isinstance(o.get("contents"), list):
            continue
        ent = find(o["entityName"])
        if not ent:
            continue
        for c in o["contents"]:
            if isinstance(c, str) and c not in ent["observations"]:
                ent["observations"].append(c)
                added.append("%s: %s" % (o["entityName"], c))
    if added:
        save()
    return text("Observations added: " + ("; ".join(added) or "none"))

def delete_entities(a):
    names = {n for n in (a.get("entityNames") or []) if isinstance(n, str)}
    before = len(graph["entities"])
    graph["entities"] = [e for e in graph["entities"] if e["name"] not in names]
    graph["relations"] = [r for r in graph["relations"] if r["from"] not in names and r["to"] not in names]
    if len(graph["entities"]) != before:
        save()
    return text("Entities deleted: " + ", ".join(sorted(names)))

def delete_observations(a):
    removed = 0
    for d in a.get("deletions") or []:
        if not isinstance(d, dict) or not isinstance(d.get("entityName"), str) or not isinstance(d.get("observations"), list):
            continue
        ent = find(d["entityName"])
        if not ent:
            continue
        kill = set(d["observations"])
        keep = [o for o in ent["observations"] if o not in kill]
        removed += len(ent["observations"]) - len(keep)
        ent["observations"] = keep
    if removed:
        save()
    return text("Observations deleted: %d" % removed)

def delete_relations(a):
    removed = 0
    for r in a.get("relations") or []:
        if not isinstance(r, dict) or not all(isinstance(r.get(k), str) for k in ("from", "to", "relationType")):
            continue
        before = len(graph["relations"])
        graph["relations"] = [x for x in graph["relations"] if not (
            x["from"] == r["from"] and x["to"] == r["to"] and x["relationType"] == r["relationType"])]
        removed += before - len(graph["relations"])
    if removed:
        save()
    return text("Relations deleted: %d" % removed)

def read_graph(_a=None):
    return text("Knowledge Graph:\n" + json.dumps(graph, indent=2, ensure_ascii=False))

def search_nodes(a):
    q = a.get("query").lower() if isinstance(a.get("query"), str) else ""
    if not q:
        return read_graph()
    ents = [e for e in graph["entities"] if q in e["name"].lower() or q in e["entityType"].lower()
            or any(q in o.lower() for o in e["observations"])]
    names = {e["name"] for e in ents}
    rels = [r for r in graph["relations"] if r["from"] in names or r["to"] in names]
    return text(json.dumps({"entities": ents, "relations": rels}, indent=2, ensure_ascii=False))

def open_nodes(a):
    names = {n for n in (a.get("names") or []) if isinstance(n, str)}
    ents = [e for e in graph["entities"] if e["name"] in names]
    rels = [r for r in graph["relations"] if r["from"] in names or r["to"] in names]
    return text(json.dumps({"entities": ents, "relations": rels}, indent=2, ensure_ascii=False))

S = {"type": "string"}
TOOLS = [
    {"name": "create_entities", "description": "Create multiple new entities in the knowledge graph",
     "inputSchema": {"type": "object", "properties": {"entities": {"type": "array", "items": {"type": "object", "properties": {
         "name": {"type": "string", "description": "Entity name"}, "entityType": {"type": "string", "description": "Entity type"},
         "observations": {"type": "array", "items": S, "description": "Observations about the entity"}},
         "required": ["name", "entityType"]}}}, "required": ["entities"]}},
    {"name": "create_relations", "description": "Create multiple new relations between entities. Entities must exist first.",
     "inputSchema": {"type": "object", "properties": {"relations": {"type": "array", "items": {"type": "object", "properties": {
         "from": {"type": "string", "description": "Entity name (source)"}, "to": {"type": "string", "description": "Entity name (target)"},
         "relationType": {"type": "string", "description": "Relation type"}}, "required": ["from", "to", "relationType"]}}},
         "required": ["relations"]}},
    {"name": "add_observations", "description": "Add new observations to existing entities",
     "inputSchema": {"type": "object", "properties": {"observations": {"type": "array", "items": {"type": "object", "properties": {
         "entityName": {"type": "string", "description": "Entity name"},
         "contents": {"type": "array", "items": S, "description": "Observation contents"}},
         "required": ["entityName", "contents"]}}}, "required": ["observations"]}},
    {"name": "delete_entities", "description": "Delete multiple entities and their relations",
     "inputSchema": {"type": "object", "properties": {"entityNames": {"type": "array", "items": S, "description": "Entity names"}},
                     "required": ["entityNames"]}},
    {"name": "delete_observations", "description": "Delete specific observations from entities",
     "inputSchema": {"type": "object", "properties": {"deletions": {"type": "array", "items": {"type": "object", "properties": {
         "entityName": {"type": "string", "description": "Entity name"},
         "observations": {"type": "array", "items": S, "description": "Observations to delete"}},
         "required": ["entityName", "observations"]}}}, "required": ["deletions"]}},
    {"name": "delete_relations", "description": "Delete multiple relations from the graph",
     "inputSchema": {"type": "object", "properties": {"relations": {"type": "array", "items": {"type": "object", "properties": {
         "from": S, "to": S, "relationType": S}, "required": ["from", "to", "relationType"]}}}, "required": ["relations"]}},
    {"name": "read_graph", "description": "Read the entire knowledge graph", "inputSchema": {"type": "object", "properties": {}}},
    {"name": "search_nodes", "description": "Search for nodes by query (name, type, or observation content)",
     "inputSchema": {"type": "object", "properties": {"query": {"type": "string", "description": "Search query"}}, "required": ["query"]}},
    {"name": "open_nodes", "description": "Open specific nodes by name (with their relations)",
     "inputSchema": {"type": "object", "properties": {"names": {"type": "array", "items": S, "description": "Entity names"}},
                     "required": ["names"]}},
]
HANDLERS = {f.__name__: f for f in (create_entities, create_relations, add_observations, delete_entities,
                                    delete_observations, delete_relations, read_graph, search_nodes, open_nodes)}

if __name__ == "__main__":
    load()
    serve("arix-memory", "2.0.0", TOOLS, HANDLERS,
          "Knowledge Graph Memory server: persist entities, relations and observations across sessions. Graph file: " + FILE)
