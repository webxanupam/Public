#!/usr/bin/env python3
"""Arix bundled MCP server: Sequential Thinking (pure Python, no dependencies, no network).

Same tool contract as the official `@modelcontextprotocol/server-sequential-thinking`
(name `sequentialthinking`, same schema and response shape).
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _stdio import serve

thoughts = []
branches = {}

TOOL = {
    "name": "sequentialthinking",
    "description": (
        "A detailed tool for dynamic and reflective problem-solving through thoughts. "
        "This tool helps in analyzing problems, evaluating hypotheses, and reasoning "
        "through complex questions by breaking them into discrete thoughts. It supports "
        "branching, revising previous insights, and adapting the depth of analysis as "
        "understanding deepens."),
    "inputSchema": {
        "type": "object",
        "properties": {
            "thought": {"type": "string", "description": "Your current reasoning step"},
            "nextThoughtNeeded": {"type": "boolean", "description": "Whether another thought step is needed"},
            "thoughtNumber": {"type": "integer", "description": "Current thought number"},
            "totalThoughts": {"type": "integer", "description": "Estimated total thoughts needed (minimum 3)"},
            "isRevision": {"type": "boolean", "description": "Whether this revises previous thinking"},
            "revisesThought": {"type": "integer", "description": "Which thought is being reconsidered"},
            "branchFromThought": {"type": "integer", "description": "Branching point thought number"},
            "branchId": {"type": "string", "description": "Branch identifier"},
            "needsMoreThoughts": {"type": "boolean", "description": "If more thoughts are needed"},
        },
        "required": ["thought", "nextThoughtNeeded", "thoughtNumber", "totalThoughts"],
    },
}

def _err(text):
    return {"content": [{"type": "text", "text": text}], "isError": True}

def sequentialthinking(args):
    try:
        num = int(args.get("thoughtNumber"))
    except (TypeError, ValueError):
        num = 0
    try:
        total = int(args.get("totalThoughts"))
    except (TypeError, ValueError):
        total = 0
    if num < 1:
        return _err("Invalid thoughtNumber: must be >= 1")
    if total < 1:
        return _err("Invalid totalThoughts: must be >= 1")
    thought = args.get("thought")
    if not isinstance(thought, str) or not thought.strip():
        return _err("Invalid thought: must be a non-empty string")
    is_rev = args.get("isRevision") is True
    revises = args.get("revisesThought") if isinstance(args.get("revisesThought"), int) else None
    branch_id = args.get("branchId") if isinstance(args.get("branchId"), str) else None
    thoughts.append({"number": num, "thought": thought, "isRevision": is_rev, "revisesThought": revises,
                     "branchId": branch_id})
    lines = ["Thought %d/%d%s" % (num, total, " (revision of thought %s)" % revises if is_rev else "")]
    if branch_id:
        branches.setdefault(branch_id, []).append(num)
    lines += ["", thought]
    if branches:
        lines += ["", "Branches:"]
        for bid, items in branches.items():
            lines.append("  %s: %d thought%s" % (bid, len(items), "" if len(items) == 1 else "s"))
    if args.get("needsMoreThoughts") is True:
        lines += ["", "Note: analysis incomplete - approx %d more thoughts suggested." % max(3, total - num)]
    if args.get("nextThoughtNeeded") is False:
        lines += ["", "Chain of thought complete."]
    return {"content": [{"type": "text", "text": "\n".join(lines)}], "isError": False}

if __name__ == "__main__":
    serve("arix-sequential-thinking", "2.0.0", [TOOL], {"sequentialthinking": sequentialthinking},
          "Sequential thinking server: break complex problems into a chain of thoughts using the "
          "sequentialthinking tool. Branch, revise and adapt as you go.")
