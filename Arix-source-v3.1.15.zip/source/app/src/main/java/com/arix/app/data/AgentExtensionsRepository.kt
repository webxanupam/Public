package com.arix.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

private val Context.agentExtensionsDataStore by preferencesDataStore(name = "arix_agent_extensions")

class AgentExtensionsRepository(
    private val context: Context,
) {
    private val mutationMutex = Mutex()

    val extensionState: Flow<AgentExtensionsState> = context.agentExtensionsDataStore.data.map { preferences ->
        AgentExtensionsState(
            installedSkills = parseInstalledSkills(preferences[INSTALLED_SKILLS_JSON].orEmpty()),
        )
    }

    suspend fun updateInstalledSkills(skills: List<InstalledSkill>) {
        mutationMutex.withLock {
            context.agentExtensionsDataStore.edit {
                it[INSTALLED_SKILLS_JSON] = serializeInstalledSkills(skills)
            }
        }
    }

    suspend fun upsertInstalledSkill(skill: InstalledSkill) {
        mutationMutex.withLock {
            val updatedSkills = extensionState.firstValue()
                .installedSkills
                .filterNot { it.id == skill.id } + skill
            context.agentExtensionsDataStore.edit {
                it[INSTALLED_SKILLS_JSON] = serializeInstalledSkills(updatedSkills.sortedBy { it.name.lowercase() })
            }
        }
    }

    suspend fun removeInstalledSkill(skillId: String) {
        mutationMutex.withLock {
            val updatedSkills = extensionState.firstValue()
                .installedSkills
                .filterNot { it.id == skillId }
            context.agentExtensionsDataStore.edit {
                it[INSTALLED_SKILLS_JSON] = serializeInstalledSkills(updatedSkills)
            }
        }
    }

    suspend fun setSkillEnabled(
        skillId: String,
        enabled: Boolean,
    ) {
        mutateSkills { skill ->
            if (skill.id == skillId) {
                skill.copy(
                    isEnabled = enabled,
                    updatedAtMillis = System.currentTimeMillis(),
                )
            } else {
                skill
            }
        }
    }

    private suspend fun mutateSkills(transform: (InstalledSkill) -> InstalledSkill) {
        mutationMutex.withLock {
            val updatedSkills = extensionState.firstValue().installedSkills.map(transform)
            context.agentExtensionsDataStore.edit {
                it[INSTALLED_SKILLS_JSON] = serializeInstalledSkills(updatedSkills)
            }
        }
    }

    private suspend fun <T> Flow<T>.firstValue(): T = first()

    private companion object {
        val INSTALLED_SKILLS_JSON = stringPreferencesKey("installed_skills_json")
    }
}
