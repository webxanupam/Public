package com.arix.app.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import android.content.Context
import com.arix.app.ArixApplication
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.SystemClock
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.rounded.ArrowForwardIos
import androidx.compose.material.icons.rounded.AttachFile
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.CurrencyRupee
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.PopupPositionProvider
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import com.arix.app.R
import com.arix.app.companion.ArixMochiState
import com.arix.app.companion.ArixWorkStatusMochi
import com.arix.app.ui.theme.ArixMessageBubble
import com.arix.app.ui.theme.ArixError
import com.arix.app.ui.theme.ArixOnPrimaryContainer
import com.arix.app.ui.theme.ArixOnSurface
import com.arix.app.ui.theme.ArixOnSurfaceVariant
import com.arix.app.ui.theme.ArixOutlineSoft
import com.arix.app.ui.theme.ArixOutline
import com.arix.app.ui.theme.ArixPrimary
import com.arix.app.ui.theme.ArixScrim
import com.arix.app.ui.theme.ArixSecondary
import com.arix.app.ui.theme.ArixSurface
import com.arix.app.platform.LocalReduceMotion
import com.arix.app.ui.theme.ArixSurfaceHigh
import com.arix.app.ui.theme.ArixTertiary

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.IDN
import java.net.URI
import java.net.URL
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Base64
import java.util.Locale
import kotlin.math.roundToInt
import kotlin.math.max

private const val ToolInvocationCollapseThreshold = 3
private const val ToolTransitionDurationMillis = 360
private const val ToolInvocationAutoExpandDelayMillis = 1_000L
private const val ToolGroupCollapseStageDelayMillis = 180L
private const val FaviconFetchTimeoutMillis = 3_000
private const val MaxFaviconDownloadBytes = 1024 * 1024
private const val MinimumEpochMillis = 946_684_800_000L
private const val TavilyFallbackDomain = "tavily.com"
private const val DefaultFaviconUserAgent =
    "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Mobile Safari/537.36"
private val ToolTransitionEasing = CubicBezierEasing(0.22f, 0.84f, 0.18f, 1f)
private val ToolGroupIndent = 14.dp
private val TimelineGlyphWidth = 22.dp
private val TimelineIconSize = 18.dp
private val TimelineLineWidth = 2.dp
private val TimelineLineTopGap = 9.dp
private val TimelineLineBottomGap = 0.dp
private val MessageTimestampFormatter = DateTimeFormatter.ofPattern("MMMM d, h:mm a", Locale.US)

@Composable
fun ConversationMessageBubble(
    message: ChatMessage,
    actionsEnabled: Boolean,
    workspaceDirectory: String?,
    allowRootImageRead: Boolean = false,
    onOpenAttachment: (ChatAttachment) -> Unit,
    onOpenLink: (String) -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onCopy: () -> Unit,
    onRedo: () -> Unit,
    onRetry: () -> Unit,
    onSwitchBranch: (Int) -> Unit,
    sessionTotalTokens: Long? = null,
) {
    if (message.author == MessageAuthor.User) {
        UserMessageBlock(
            message = message,
            onOpenAttachment = onOpenAttachment,
            onEdit = onEdit,
            onCopy = onCopy,
            onRetry = onRetry,
            onDelete = onDelete,
            onSwitchBranch = onSwitchBranch,
        )
    } else {
        AssistantMessageBlock(
            message = message,
            actionsEnabled = actionsEnabled,
            showActions = !message.assistantActionsHidden,
            workspaceDirectory = workspaceDirectory,
            allowRootImageRead = allowRootImageRead,
            onOpenAttachment = onOpenAttachment,
            onOpenLink = onOpenLink,
            onCopy = onCopy,
            onRedo = onRedo,
            onDelete = onDelete,
            sessionTotalTokens = sessionTotalTokens,
        )
    }
}

@Composable
fun SurfaceNotice(
    title: String,
    subtitle: String,
    actionLabel: String,
    onAction: () -> Unit,
    actionEnabled: Boolean,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(12.dp, RoundedCornerShape(24.dp), ambientColor = ArixScrim, spotColor = ArixScrim)
            .clip(RoundedCornerShape(24.dp))
            .background(ArixSurface.copy(alpha = 0.96f))
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.labelLarge, color = ArixOnSurface)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = ArixOnSurfaceVariant)
        }
        ActionIconLabel(
            icon = Icons.Rounded.Close,
            label = actionLabel,
            enabled = actionEnabled,
            onClick = onAction,
        )
    }
}

@Composable
fun ComposerAttachmentTray(
    attachments: List<ChatAttachment>,
    onRemoveAttachment: (String) -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(10.dp, RoundedCornerShape(24.dp), ambientColor = ArixScrim, spotColor = ArixScrim)
            .clip(RoundedCornerShape(24.dp))
            .background(ArixSurface.copy(alpha = 0.96f))
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        attachments.forEach { attachment ->
            if (attachment.kind == AttachmentKind.Image) {
                ComposerImageAttachmentCard(attachment = attachment, onRemove = { onRemoveAttachment(attachment.id) })
            } else {
                ComposerFileAttachmentCard(attachment = attachment, onRemove = { onRemoveAttachment(attachment.id) })
            }
        }
    }
}

@Composable
private fun UserMessageBlock(
    message: ChatMessage,
    onOpenAttachment: (ChatAttachment) -> Unit,
    onEdit: () -> Unit,
    onCopy: () -> Unit,
    onRetry: () -> Unit,
    onDelete: () -> Unit,
    onSwitchBranch: (Int) -> Unit,
) {
    var menuExpanded by remember { mutableStateOf(false) }
    var selectTextExpanded by remember { mutableStateOf(false) }
    var confirmDeleteExpanded by remember { mutableStateOf(false) }
    val branchNavigation = message.branchNavigation()

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.End,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        BoxWithConstraints {
            val userBubbleMaxWidth = (maxWidth * 0.72f).coerceIn(300.dp, 520.dp)
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                UserAttachments(message.attachments, onOpenAttachment)
                if (message.text.isNotBlank()) {
                    UserTextBubble(
                        text = stripAssistantScreenContext(message.text),
                        maxWidth = userBubbleMaxWidth,
                        onLongPress = { menuExpanded = true },
                    )
                }
                if (branchNavigation != null) {
                    UserMessageBranchSwitcher(
                        navigation = branchNavigation,
                        onPrevious = { onSwitchBranch(-1) },
                        onNext = { onSwitchBranch(1) },
                    )
                }
            }

            UserMessageActionDialog(
                expanded = menuExpanded,
                onDismissRequest = { menuExpanded = false },
                timestamp = formatMessageTimestamp(message.createdAtMillis),
                onCopy = {
                    menuExpanded = false
                    onCopy()
                },
                onSelectText = {
                    menuExpanded = false
                    selectTextExpanded = true
                },
                onEdit = {
                    menuExpanded = false
                    onEdit()
                },
                onRetry = {
                    menuExpanded = false
                    onRetry()
                },
                onDelete = {
                    menuExpanded = false
                    confirmDeleteExpanded = true
                },
            )

            ConfirmDeleteMessageDialog(
                visible = confirmDeleteExpanded,
                onDismissRequest = { confirmDeleteExpanded = false },
                onConfirm = {
                    confirmDeleteExpanded = false
                    onDelete()
                },
            )

            SelectUserMessageTextDialog(
                expanded = selectTextExpanded,
                text = message.text,
                onDismissRequest = { selectTextExpanded = false },
            )
        }
    }
}

@Composable
private fun UserMessageActionDialog(
    expanded: Boolean,
    timestamp: String,
    onDismissRequest: () -> Unit,
    onCopy: () -> Unit,
    onSelectText: () -> Unit,
    onEdit: () -> Unit,
    onRetry: () -> Unit,
    onDelete: () -> Unit,
) {
    val menuVisibility = remember { MutableTransitionState(false) }
    menuVisibility.targetState = expanded
    if (!menuVisibility.currentState && !menuVisibility.targetState) return

    val density = LocalDensity.current
    val popupOffset = with(density) {
        IntOffset(x = 0, y = 30.dp.roundToPx())
    }

    Popup(
        alignment = Alignment.TopEnd,
        offset = popupOffset,
        onDismissRequest = onDismissRequest,
        properties = PopupProperties(
            focusable = true,
            dismissOnBackPress = true,
            dismissOnClickOutside = true,
        ),
    ) {
        AnimatedVisibility(
            visibleState = menuVisibility,
            enter = fadeIn() +
                scaleIn(
                    initialScale = 0.92f,
                    transformOrigin = TransformOrigin(1f, 0f),
                ) +
                slideInVertically(initialOffsetY = { -it / 10 }),
            exit = fadeOut() +
                scaleOut(
                    targetScale = 0.96f,
                    transformOrigin = TransformOrigin(1f, 0f),
                ) +
                slideOutVertically(targetOffsetY = { -it / 12 }),
        ) {
            Column(
                modifier = Modifier
                    .width(228.dp)
                    .shadow(20.dp, RoundedCornerShape(30.dp), ambientColor = ArixScrim, spotColor = ArixScrim)
                    .clip(RoundedCornerShape(30.dp))
                    .background(ArixSurface)
                    .padding(horizontal = 12.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                if (timestamp.isNotBlank()) {
                    Text(
                        text = timestamp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.bodyLarge,
                        color = ArixOnSurfaceVariant,
                        textAlign = TextAlign.Center,
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                }
                UserMessageActionRow(
                    icon = Icons.Rounded.ContentCopy,
                    label = stringResource(R.string.common_copy),
                    onClick = onCopy,
                )
                UserMessageActionRow(
                    icon = Icons.Rounded.Description,
                    label = stringResource(R.string.common_select_text),
                    onClick = onSelectText,
                )
                UserMessageActionRow(
                    icon = Icons.Rounded.Edit,
                    label = stringResource(R.string.common_edit_message),
                    onClick = onEdit,
                )
                UserMessageActionRow(
                    icon = Icons.Rounded.Refresh,
                    label = stringResource(R.string.common_retry),
                    onClick = onRetry,
                )
                UserMessageActionRow(
                    icon = Icons.Rounded.Delete,
                    label = stringResource(R.string.common_delete_turn),
                    onClick = onDelete,
                )
            }
        }
    }
}

@Composable
private fun ConfirmDeleteMessageDialog(
    visible: Boolean,
    onDismissRequest: () -> Unit,
    onConfirm: () -> Unit,
) {
    if (!visible) return
    Dialog(onDismissRequest = onDismissRequest) {
        Column(
            modifier = Modifier
                .shadow(20.dp, RoundedCornerShape(30.dp), ambientColor = ArixScrim, spotColor = ArixScrim)
                .clip(RoundedCornerShape(30.dp))
                .background(ArixSurface)
                .padding(24.dp),
        ) {
            Text(
                text = stringResource(R.string.chat_delete_message_confirm_title),
                style = MaterialTheme.typography.titleMedium,
                color = ArixOnSurface,
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = stringResource(R.string.chat_delete_message_confirm_body),
                style = MaterialTheme.typography.bodyMedium,
                color = ArixOnSurfaceVariant,
            )
            Spacer(modifier = Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.align(Alignment.End)) {
                ActionIconLabel(
                    icon = Icons.Rounded.Close,
                    label = stringResource(R.string.common_cancel),
                    enabled = true,
                    onClick = onDismissRequest,
                )
                ActionIconLabel(
                    icon = Icons.Rounded.Delete,
                    label = stringResource(R.string.common_confirm_delete),
                    enabled = true,
                    onClick = onConfirm,
                )
            }
        }
    }
}

@Composable
private fun UserMessageBranchSwitcher(
    navigation: ChatBranchNavigation,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
) {
    Row(
        modifier = Modifier.padding(end = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        BranchStepButton(
            enabled = navigation.canGoPrevious,
            icon = Icons.AutoMirrored.Rounded.KeyboardArrowLeft,
            contentDescription = "Previous response version",
            onClick = onPrevious,
        )
        Text(
            text = "${navigation.selectedIndex + 1}/${navigation.branchCount}",
            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
            color = ArixOnSurfaceVariant,
        )
        BranchStepButton(
            enabled = navigation.canGoNext,
            icon = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
            contentDescription = "Next response version",
            onClick = onNext,
        )
    }
}

@Composable
private fun BranchStepButton(
    enabled: Boolean,
    icon: ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
) {
    Box(
        modifier = Modifier
            .size(32.dp)
            .clip(CircleShape)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = if (enabled) ArixOnSurfaceVariant else ArixOnSurfaceVariant.copy(alpha = 0.32f),
            modifier = Modifier.size(30.dp),
        )
    }
}

@Composable
private fun UserMessageActionRow(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .clip(RoundedCornerShape(22.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = ArixOnSurface,
            modifier = Modifier.size(24.dp),
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge,
            color = ArixOnSurface,
        )
    }
}

@Composable
private fun SelectUserMessageTextDialog(
    expanded: Boolean,
    text: String,
    onDismissRequest: () -> Unit,
) {
    if (!expanded) return

    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .widthIn(max = 520.dp)
                .shadow(22.dp, RoundedCornerShape(28.dp), ambientColor = ArixScrim, spotColor = ArixScrim)
                .clip(RoundedCornerShape(28.dp))
                .background(ArixSurface)
                .padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(
                text = stringResource(R.string.common_select_text),
                style = MaterialTheme.typography.titleMedium,
                color = ArixOnSurface,
            )
            SelectionContainer {
                Text(
                    text = text,
                    style = MaterialTheme.typography.bodyLarge,
                    color = ArixOnSurface,
                )
            }
        }
    }
}

@Composable
private fun UserAttachments(
    attachments: List<ChatAttachment>,
    onOpenAttachment: (ChatAttachment) -> Unit,
) {
    attachments.forEach { attachment ->
        when (attachment.kind) {
            AttachmentKind.Image -> UserImageAttachmentCard(attachment = attachment, onClick = { onOpenAttachment(attachment) })
            AttachmentKind.File -> UserFileAttachmentCard(attachment = attachment, onClick = { onOpenAttachment(attachment) })
        }
    }
}

@Composable
@OptIn(ExperimentalFoundationApi::class)
private fun UserTextBubble(
    text: String,
    maxWidth: Dp,
    onLongPress: () -> Unit,
) {
    Box(
        modifier = Modifier
            .widthIn(max = maxWidth)
            .shadow(10.dp, RoundedCornerShape(24.dp), ambientColor = ArixScrim, spotColor = ArixScrim)
            .clip(RoundedCornerShape(24.dp))
            .background(ArixMessageBubble)
            .combinedClickable(
                onClick = {},
                onLongClick = onLongPress,
            )
            .padding(horizontal = 18.dp, vertical = 14.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.bodyLarge,
            color = ArixOnPrimaryContainer,
        )
    }
}

@Composable
private fun AssistantMessageBlock(
    message: ChatMessage,
    actionsEnabled: Boolean,
    showActions: Boolean,
    workspaceDirectory: String?,
    allowRootImageRead: Boolean,
    onOpenAttachment: (ChatAttachment) -> Unit,
    onOpenLink: (String) -> Unit,
    onCopy: () -> Unit,
    onRedo: () -> Unit,
    onDelete: () -> Unit,
    sessionTotalTokens: Long?,
) {
    val shouldFoldWorkBeforeFinalText = message.text.isNotBlank() &&
        (message.reasoningTrace != null ||
            message.thoughtDurationMillis != null ||
            message.toolInvocations.isNotEmpty() ||
            message.attachments.isNotEmpty())
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        val workContent: @Composable () -> Unit = {
            AssistantMessageWorkContent(
                message = message,
                workspaceDirectory = workspaceDirectory,
                allowRootImageRead = allowRootImageRead,
                onOpenAttachment = onOpenAttachment,
                onOpenLink = onOpenLink,
            )
        }
        if (shouldFoldWorkBeforeFinalText) {
            ToolResultsInlineGallery(
                message.toolInvocations + (message.reasoningTrace?.toolInvocations ?: emptyList()),
            )
            AgentWorkSummaryDisclosure(
                title = formatWorkedSummaryTitle(
                    workDurationMillisForMessages(
                        messages = listOf(message),
                        endAtMillis = message.createdAtMillis,
                    ),
                ),
                stateKey = "message-work-${message.id}",
                content = workContent,
            )
        }
        if (!shouldFoldWorkBeforeFinalText) {
        if (message.reasoningTrace != null) {
            ReasoningTraceStatus(
                trace = message.reasoningTrace,
                onOpenLink = onOpenLink,
            )
        } else {
            message.thoughtDurationMillis?.let { duration ->
                ArixThoughtStatusRow(duration)
            }
        }
        if (message.reasoningTrace == null) {
            ToolInvocationList(
                toolInvocations = message.toolInvocations,
                stateKey = "message-tools-${message.id}",
            )
        }
        AssistantAttachments(
            attachments = message.attachments,
            onOpenAttachment = onOpenAttachment,
        )
        }
        if (message.text.isNotBlank()) {
            MarkdownContent(
                markdown = message.text,
                workspaceDirectory = workspaceDirectory,
                allowRootImageRead = allowRootImageRead,
                onLinkClick = onOpenLink,
            )
        }
        if (message.statusText.isNotBlank()) {
            ReconnectingStatusCard(
                text = message.statusText,
                detail = message.statusDetail,
                modifier = Modifier.padding(top = 6.dp),
            )
        }
        if (showActions) {
            AssistantMessageActions(
                usageStatistics = message.usageStatistics,
                sessionTotalTokens = sessionTotalTokens,
                actionsEnabled = actionsEnabled,
                onCopy = onCopy,
                onRedo = onRedo,
                onDelete = onDelete,
            )
        }
    }
}

@Composable
private fun AssistantMessageWorkContent(
    message: ChatMessage,
    workspaceDirectory: String?,
    allowRootImageRead: Boolean,
    onOpenAttachment: (ChatAttachment) -> Unit,
    onOpenLink: (String) -> Unit,
) {
    if (message.reasoningTrace != null) {
        ReasoningTraceStatus(
            trace = message.reasoningTrace,
            onOpenLink = onOpenLink,
        )
    } else {
            message.thoughtDurationMillis?.let { duration ->
                ArixThoughtStatusRow(duration)
            }
    }
    if (message.reasoningTrace == null) {
        ToolInvocationList(
            toolInvocations = message.toolInvocations,
            stateKey = "message-tools-${message.id}",
            renderInlineResults = false,
        )
    }
    AssistantAttachments(
        attachments = message.attachments,
        onOpenAttachment = onOpenAttachment,
    )
}

@Composable
fun ConversationAssistantGroupBubble(
    messages: List<ChatMessage>,
    actionsEnabled: Boolean,
    workspaceDirectory: String?,
    allowRootImageRead: Boolean = false,
    onOpenAttachment: (ChatAttachment) -> Unit,
    onOpenLink: (String) -> Unit,
    onCopy: () -> Unit,
    onRedo: () -> Unit,
    onDelete: () -> Unit,
    sessionTotalTokens: Long? = null,
) {
    if (messages.isEmpty()) return
    val groupUsageStatistics = messages.lastOrNull { it.usageStatistics != null }?.usageStatistics
    val thoughtDurationMillis = messages.lastOrNull()?.thoughtDurationMillis
    val hasReasoningTrace = messages.any { it.reasoningTrace != null }
    val showActions = messages.none { it.assistantActionsHidden }
    val finalTextMessageIndex = messages.indexOfLast { message ->
        message.text.isNotBlank()
    }
    val shouldFoldWorkBeforeFinalText = finalTextMessageIndex > 0
    val workMessages = if (shouldFoldWorkBeforeFinalText) {
        messages.take(finalTextMessageIndex)
    } else {
        emptyList()
    }
    val visibleMessages = if (shouldFoldWorkBeforeFinalText) {
        messages.drop(finalTextMessageIndex)
    } else {
        messages
    }
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        if (!shouldFoldWorkBeforeFinalText && !hasReasoningTrace) thoughtDurationMillis?.let { duration ->
            ArixThoughtStatusRow(duration)
        }
        if (shouldFoldWorkBeforeFinalText) {
            ToolResultsInlineGallery(
                workMessages.flatMap { message ->
                    message.toolInvocations + (message.reasoningTrace?.toolInvocations ?: emptyList())
                },
            )
            AgentWorkSummaryDisclosure(
                title = formatWorkedSummaryTitle(
                    workDurationMillisForMessages(
                        messages = messages,
                        endAtMillis = messages[finalTextMessageIndex].createdAtMillis,
                    ),
                ),
                stateKey = "assistant-work-${messages.first().responseGroupId ?: messages.first().id}",
            ) {
                workMessages.forEach { message ->
                    AssistantGroupMessageContent(
                        message = message,
                        workspaceDirectory = workspaceDirectory,
                        allowRootImageRead = allowRootImageRead,
                        onOpenAttachment = onOpenAttachment,
                        onOpenLink = onOpenLink,
                        renderInlineResults = false,
                    )
                }
            }
        }
        messages.forEach { message ->
            if (shouldFoldWorkBeforeFinalText && message !in visibleMessages) {
                return@forEach
            }
            AssistantGroupMessageContent(
                message = message,
                workspaceDirectory = workspaceDirectory,
                allowRootImageRead = allowRootImageRead,
                onOpenAttachment = onOpenAttachment,
                onOpenLink = onOpenLink,
            )
        }
        if (showActions) {
            AssistantMessageActions(
                usageStatistics = groupUsageStatistics,
                sessionTotalTokens = sessionTotalTokens,
                actionsEnabled = actionsEnabled,
                onCopy = onCopy,
                onRedo = onRedo,
                onDelete = onDelete,
            )
        }
    }
}

@Composable
private fun AssistantGroupMessageContent(
    message: ChatMessage,
    workspaceDirectory: String?,
    allowRootImageRead: Boolean,
    onOpenAttachment: (ChatAttachment) -> Unit,
    onOpenLink: (String) -> Unit,
    renderInlineResults: Boolean = true,
) {
    if (message.reasoningTrace != null) {
        ReasoningTraceStatus(
            trace = message.reasoningTrace,
            onOpenLink = onOpenLink,
        )
    } else {
        ToolInvocationList(
            toolInvocations = message.toolInvocations,
            stateKey = "message-tools-${message.id}",
            renderInlineResults = renderInlineResults,
        )
    }
    AssistantAttachments(
        attachments = message.attachments,
        onOpenAttachment = onOpenAttachment,
    )
    if (message.text.isNotBlank()) {
        MarkdownContent(
            markdown = message.text,
            workspaceDirectory = workspaceDirectory,
            allowRootImageRead = allowRootImageRead,
            onLinkClick = onOpenLink,
        )
    }
    if (message.statusText.isNotBlank()) {
        ReconnectingStatusCard(
            text = message.statusText,
            detail = message.statusDetail,
            modifier = Modifier.padding(top = 6.dp),
        )
    }
}

@Composable
fun ToolInvocationList(
    toolInvocations: List<ChatToolInvocation>,
    stateKey: String,
    autoExpand: Boolean = false,
    renderInlineResults: Boolean = true,
) {
    if (toolInvocations.isEmpty()) return

    if (renderInlineResults) {
        ToolResultsInlineGallery(toolInvocations)
    }

    if (toolInvocations.size < ToolInvocationCollapseThreshold) {
        ToolInvocationCardsColumn(
            toolInvocations = toolInvocations,
        )
        return
    }

    val isRunning = toolInvocations.any { it.isRunning }
    var headerVisible by rememberSaveable(stateKey) { mutableStateOf(!autoExpand) }
    var expanded by rememberSaveable(stateKey) { mutableStateOf(autoExpand) }
    var lastAutoExpanded by rememberSaveable(stateKey) { mutableStateOf(autoExpand) }
    LaunchedEffect(autoExpand) {
        if (lastAutoExpanded != autoExpand) {
            if (autoExpand) {
                headerVisible = false
                expanded = true
            } else {
                headerVisible = true
                expanded = true
                delay(ToolGroupCollapseStageDelayMillis)
                expanded = false
            }
            lastAutoExpanded = autoExpand
        }
    }
    val childIndent by animateDpAsState(
        targetValue = if (headerVisible) ToolGroupIndent else 0.dp,
        animationSpec = tween(durationMillis = ToolTransitionDurationMillis, easing = ToolTransitionEasing),
        label = "tool_group_indent",
    )
    val arrowRotation by animateFloatAsState(
        targetValue = if (expanded) 90f else 0f,
        animationSpec = tween(durationMillis = ToolTransitionDurationMillis, easing = ToolTransitionEasing),
        label = "tool_group_arrow_rotation",
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 6.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        AnimatedVisibility(
            visible = headerVisible,
            enter = fadeIn(
                animationSpec = tween(
                    durationMillis = ToolTransitionDurationMillis - 100,
                    easing = ToolTransitionEasing,
                ),
            ) + expandVertically(
                animationSpec = tween(durationMillis = ToolTransitionDurationMillis, easing = ToolTransitionEasing),
                expandFrom = Alignment.Top,
            ),
            exit = fadeOut(
                animationSpec = tween(durationMillis = 180, easing = FastOutLinearInEasing),
            ) + shrinkVertically(
                animationSpec = tween(durationMillis = 220, easing = FastOutLinearInEasing),
                shrinkTowards = Alignment.Top,
            ),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .noRippleClickable { expanded = !expanded },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (isRunning) {
                    ShimmerStatusText(
                        text = stringResource(R.string.tool_invocation_group_executing, toolInvocations.size),
                        modifier = Modifier.weight(1f),
                        travelDurationMillis = 2600,
                        pauseDurationMillis = 1000,
                    )
                } else {
                    Text(
                        text = stringResource(R.string.tool_invocation_group_executed, toolInvocations.size),
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.bodyMedium,
                        color = ArixOnSurfaceVariant,
                    )
                }
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.ArrowForwardIos,
                    contentDescription = if (expanded) {
                        stringResource(R.string.tool_invocation_collapse_tools)
                    } else {
                        stringResource(R.string.tool_invocation_expand_tools)
                    },
                    tint = ArixOnSurfaceVariant,
                    modifier = Modifier
                        .size(14.dp)
                        .graphicsLayer { rotationZ = arrowRotation },
                )
            }
        }

        AnimatedVisibility(
            visible = expanded,
            enter = expandVertically(
                animationSpec = tween(durationMillis = ToolTransitionDurationMillis, easing = ToolTransitionEasing),
                expandFrom = Alignment.Top,
            ) + fadeIn(
                animationSpec = tween(
                    durationMillis = ToolTransitionDurationMillis - 90,
                    delayMillis = 40,
                    easing = ToolTransitionEasing,
                ),
            ),
            exit = shrinkVertically(
                animationSpec = tween(durationMillis = 260, easing = FastOutLinearInEasing),
                shrinkTowards = Alignment.Top,
            ) + fadeOut(
                animationSpec = tween(durationMillis = 180, easing = FastOutLinearInEasing),
            ),
        ) {
            ToolInvocationCardsColumn(
                toolInvocations = toolInvocations,
                indent = childIndent,
                topPadding = 4.dp,
            )
        }
    }
}

@Composable
fun AgentWorkSummaryDisclosure(
    title: String,
    stateKey: String,
    modifier: Modifier = Modifier,
    initiallyExpanded: Boolean = false,
    content: @Composable () -> Unit,
) {
    var expanded by rememberSaveable(stateKey) { mutableStateOf(initiallyExpanded) }
    val arrowRotation by animateFloatAsState(
        targetValue = if (expanded) 90f else 0f,
        animationSpec = tween(durationMillis = ToolTransitionDurationMillis, easing = ToolTransitionEasing),
        label = "agent_work_arrow_rotation",
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(top = 6.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .noRippleClickable { expanded = !expanded },
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                text = title,
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.bodyMedium,
                color = ArixOnSurfaceVariant,
            )
            Icon(
                imageVector = Icons.AutoMirrored.Rounded.ArrowForwardIos,
                contentDescription = if (expanded) stringResource(R.string.agent_work_collapse) else stringResource(R.string.agent_work_expand),
                tint = ArixOnSurfaceVariant,
                modifier = Modifier
                    .size(14.dp)
                    .graphicsLayer { rotationZ = arrowRotation },
            )
        }

        AnimatedVisibility(
            visible = expanded,
            enter = expandVertically(
                animationSpec = tween(durationMillis = ToolTransitionDurationMillis, easing = ToolTransitionEasing),
                expandFrom = Alignment.Top,
            ) + fadeIn(
                animationSpec = tween(
                    durationMillis = ToolTransitionDurationMillis - 90,
                    delayMillis = 40,
                    easing = ToolTransitionEasing,
                ),
            ),
            exit = shrinkVertically(
                animationSpec = tween(durationMillis = 260, easing = FastOutLinearInEasing),
                shrinkTowards = Alignment.Top,
            ) + fadeOut(
                animationSpec = tween(durationMillis = 180, easing = FastOutLinearInEasing),
            ),
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = ToolGroupIndent),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                content()
            }
        }
    }
}

@Composable
fun AgentWorkingStatusHeader(
    title: String,
    modifier: Modifier = Modifier,
    mochiState: com.arix.app.companion.ArixMochiState = com.arix.app.companion.ArixMochiState.Thinking,
    invocations: List<ChatToolInvocation> = emptyList(),
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(top = 6.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            ArixWorkStatusMochi(
                state = mochiState,
                diameter = 30.dp,
            )
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                color = ArixOnSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
        }
        ArixLiveWorkLines(invocations = invocations)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(ArixOutlineSoft.copy(alpha = 0.62f))
        )
    }
}

@Composable
private fun ArixThoughtStatusRow(durationMillis: Long) {
    Text(
        text = stringResource(
            R.string.chat_thought_for_duration,
            formatThoughtDuration(durationMillis),
        ),
        style = MaterialTheme.typography.bodySmall,
        color = ArixOnSurfaceVariant,
    )
}

@Composable
fun ToolResultsInlineGallery(toolInvocations: List<ChatToolInvocation>) {
    if (toolInvocations.isEmpty()) return
    MediaResultsInlineGallery(toolInvocations)
    WebSearchSourcesCard(toolInvocations)
}

@Composable
private fun MediaResultsInlineGallery(toolInvocations: List<ChatToolInvocation>) {
    if (toolInvocations.isEmpty()) return
    val mediaInvocations = remember(toolInvocations) {
        val seenRequests = HashSet<String>()
        toolInvocations.filter { invocation ->
            invocation.toolName.equals("media_search", ignoreCase = true) &&
                !invocation.isRunning &&
                invocation.outputJson.isNotBlank() &&
                seenRequests.add(invocation.argumentsJson.trim().lowercase())
        }
    }
    mediaInvocations.forEach { invocation ->
        ArixToolResultWidget(
            toolName = invocation.toolName,
            outputJson = invocation.outputJson,
            modifier = Modifier.padding(top = 6.dp),
        )
    }
}

@Composable
private fun WebSearchSourcesCard(toolInvocations: List<ChatToolInvocation>) {
    if (toolInvocations.isEmpty()) return
    val context = LocalContext.current
    val searchInvocations = remember(toolInvocations) {
        val seenQueries = HashSet<String>()
        toolInvocations.filter { invocation ->
            invocation.toolName.equals("web_search", ignoreCase = true) &&
                !invocation.isRunning &&
                invocation.outputJson.isNotBlank() &&
                seenQueries.add(invocation.argumentsJson.trim().lowercase())
        }
    }
    searchInvocations.forEach { invocation ->
        val results = remember(invocation.outputJson) {
            parseJsonObject(invocation.outputJson)
                ?.optJSONArray("results")
                ?.let { array ->
                    (0 until array.length()).mapNotNull { array.optJSONObject(it) }
                }
                .orEmpty()
                .filter { it.optString("url").startsWith("http") }
        }
        if (results.isEmpty()) return@forEach
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 6.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(ArixSurfaceHigh)
                .border(1.dp, ArixOutline.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Icon(
                    imageVector = Icons.Rounded.Language,
                    contentDescription = null,
                    tint = ArixPrimary,
                    modifier = Modifier.size(16.dp),
                )
                Text(
                    text = "Web results",
                    style = MaterialTheme.typography.labelLarge,
                    color = ArixOnSurface,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    text = "${results.size}",
                    style = MaterialTheme.typography.labelSmall,
                    color = ArixOnSurfaceVariant,
                )
            }
            results.take(5).forEachIndexed { index, result ->
                val url = result.optString("url")
                val host = result.optString("host").ifBlank {
                    runCatching { Uri.parse(url).host.orEmpty() }.getOrDefault("")
                }
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable {
                            ArixLinkActions.openUrl(context, url)
                        }
                        .padding(horizontal = 4.dp, vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(1.dp),
                ) {
                    Text(
                        text = "${index + 1}. ${result.optString("title").ifBlank { host }}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = ArixOnSurface,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                    if (host.isNotBlank()) {
                        Text(
                            text = host,
                            style = MaterialTheme.typography.labelSmall,
                            color = ArixPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    result.optString("snippet").takeIf { it.isNotBlank() }?.let { snippet ->
                        Text(
                            text = snippet,
                            style = MaterialTheme.typography.bodySmall,
                            color = ArixOnSurfaceVariant,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
            if (results.size > 5) {
                Text(
                    text = "+${results.size - 5} more sources in the work details",
                    style = MaterialTheme.typography.labelSmall,
                    color = ArixOnSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun ToolInvocationCardsColumn(
    toolInvocations: List<ChatToolInvocation>,
    indent: Dp = 0.dp,
    topPadding: Dp = 6.dp,
) {
    val mediaSearchSignatureSeen = remember(toolInvocations) {
        val seen = HashSet<String>()
        toolInvocations.map { toolInvocation ->
            val isGalleryTool = toolInvocation.toolName.equals("media_search", ignoreCase = true)
            val duplicate = isGalleryTool &&
                toolInvocation.argumentsJson.isNotBlank() &&
                !seen.add("${toolInvocation.toolName.lowercase()}|${toolInvocation.argumentsJson}")
            toolInvocation.id to (duplicate || isGalleryTool)
        }.toMap()
    }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = indent),
        verticalArrangement = Arrangement.spacedBy(0.dp),
    ) {
        val agentInvocations = toolInvocations.filter(::isSubAgentInvocation)
        val firstAgentIndex = toolInvocations.indexOfFirst(::isSubAgentInvocation)
        toolInvocations.forEachIndexed { index, toolInvocation ->
            if (isSubAgentInvocation(toolInvocation)) {
                if (index == firstAgentIndex) {
                    ArixAgentPanel(invocations = agentInvocations, topPadding = topPadding)
                }
            } else {
                ToolInvocationAnimatedCard(
                    toolInvocation = toolInvocation,
                    topPadding = topPadding,
                    suppressResultWidget = mediaSearchSignatureSeen[toolInvocation.id] == true,
                )
            }
        }
    }
}

@Composable
private fun ToolInvocationAnimatedCard(
    toolInvocation: ChatToolInvocation,
    topPadding: Dp,
    suppressResultWidget: Boolean = false,
) {
    var visible by rememberSaveable(toolInvocation.id) { mutableStateOf(false) }
    LaunchedEffect(toolInvocation.id) {
        visible = true
    }

    AnimatedVisibility(
        visible = visible,
        enter = expandVertically(
            animationSpec = tween(durationMillis = ToolTransitionDurationMillis, easing = ToolTransitionEasing),
            expandFrom = Alignment.Top,
        ) + fadeIn(
            animationSpec = tween(
                durationMillis = ToolTransitionDurationMillis - 90,
                delayMillis = 30,
                easing = ToolTransitionEasing,
            ),
        ),
    ) {
        ToolInvocationCard(
            toolInvocation = toolInvocation,
            topPadding = topPadding,
            suppressResultWidget = suppressResultWidget,
        )
    }
}

@Composable
fun PendingAssistantResponseBlock(
    text: String,
    workspaceDirectory: String?,
    allowRootImageRead: Boolean = false,
    onOpenLink: (String) -> Unit,
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        StreamingMarkdownContent(
            markdown = text,
            workspaceDirectory = workspaceDirectory,
            allowRootImageRead = allowRootImageRead,
            onLinkClick = onOpenLink,
            showCursor = true,
        )
    }
}

@Composable
private fun rememberStreamingMarkdownSample(source: String): String {
    var displayed by remember { mutableStateOf(source) }
    var lastEmitAtMillis by remember { mutableStateOf(0L) }
    LaunchedEffect(source) {
        if (source == displayed) return@LaunchedEffect
        val isAppend = source.startsWith(displayed)
        val sinceEmit = SystemClock.elapsedRealtime() - lastEmitAtMillis
        val deltaChars = source.length - displayed.length
        if (!isAppend || sinceEmit >= StreamingMarkdownSampleIntervalMillis ||
            deltaChars >= StreamingMarkdownSampleMinChars
        ) {
            displayed = source
            lastEmitAtMillis = SystemClock.elapsedRealtime()
        } else {
            delay(StreamingMarkdownSampleIntervalMillis)
            displayed = source
            lastEmitAtMillis = SystemClock.elapsedRealtime()
        }
    }
    return displayed
}

private const val StreamingMarkdownSampleIntervalMillis = 60L
private const val StreamingMarkdownSampleMinChars = 120

@Composable
fun StreamingMarkdownContent(
    markdown: String,
    workspaceDirectory: String?,
    allowRootImageRead: Boolean,
    onLinkClick: (String) -> Unit,
    showCursor: Boolean = false,
) {
    val markdown = rememberStreamingMarkdownSample(source = markdown)

    StreamingRevealContent(source = markdown, isStreaming = true) { visibleMarkdown ->
        MarkdownContent(
            markdown = visibleMarkdown,
            modifier = Modifier.fillMaxWidth(),
            workspaceDirectory = workspaceDirectory,
            allowRootImageRead = allowRootImageRead,
            onLinkClick = onLinkClick,
        )
    }
}

@Composable
fun ShimmerStatusText(
    text: String,
    modifier: Modifier = Modifier,
    travelDurationMillis: Int = 1800,
    pauseDurationMillis: Int = 1000,
    style: androidx.compose.ui.text.TextStyle = MaterialTheme.typography.bodyMedium,
    maxLines: Int = Int.MAX_VALUE,
) {
    if (LocalReduceMotion.current) {
        Text(text = text, modifier = modifier, style = style, color = ArixOnSurfaceVariant,
            maxLines = maxLines, overflow = TextOverflow.Ellipsis)
        return
    }
    val travelDistance = (280f + text.length * 18f).coerceIn(280f, 760f)
    val sweepHalfWidth = 180f
    val totalDurationMillis = travelDurationMillis + pauseDurationMillis
    val shimmerOffset by rememberInfiniteTransition(label = "status_shimmer").animateFloat(
        initialValue = -travelDistance,
        targetValue = travelDistance,
        animationSpec = infiniteRepeatable(
            animation = keyframes {
                durationMillis = totalDurationMillis
                travelDistance at travelDurationMillis using LinearEasing
                travelDistance at totalDurationMillis
            },
            repeatMode = RepeatMode.Restart,
        ),
        label = "status_shimmer_offset",
    )
    val shimmerBrush = Brush.linearGradient(
        colors = listOf(
            ArixOnSurfaceVariant.copy(alpha = 0.42f),
            ArixOnSurface.copy(alpha = 0.96f),
            ArixOnSurfaceVariant.copy(alpha = 0.42f),
        ),
        start = Offset(shimmerOffset - sweepHalfWidth, 0f),
        end = Offset(shimmerOffset + sweepHalfWidth, 0f),
    )

    Text(
        text = text,
        style = style.copy(brush = shimmerBrush),
        modifier = modifier,
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis,
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReasoningTraceStatus(
    trace: ReasoningTrace,
    modifier: Modifier = Modifier,
    onOpenLink: (String) -> Unit = {},
) {
    var sheetVisible by remember(trace.id) { mutableStateOf(false) }
    val latestDetail = remember(trace.latestStatusText, trace.chunks, trace.rawText) {
        trace.latestStatusText.ifBlank {
            trace.chunks.lastOrNull { !it.isPending && (it.detail.isNotBlank() || it.title.isNotBlank()) }
            ?.let { chunk -> chunk.detail.ifBlank { chunk.title } }
            .orEmpty().ifBlank { trace.rawText.trim().takeLast(180) }
        }
    }
    val completed = trace.completedAtMillis != null
    val statusText = if (completed) {
        formatReasoningTraceDoneLabel(trace)
    } else {
        latestDetail
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(top = 6.dp)
            .noRippleClickable { sheetVisible = true },
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        when {
            completed -> Text(
                text = statusText,
                style = MaterialTheme.typography.bodyMedium,
                color = ArixOnSurfaceVariant,
            )

            statusText.isNotBlank() -> ReasoningTypewriterText(
                text = statusText,
                styleColor = ArixOnSurfaceVariant,
            )

            else -> ShimmerStatusText(
                text = stringResource(R.string.chat_thinking),
            )
        }
    }

    if (sheetVisible) {
        ModalBottomSheet(
            onDismissRequest = { sheetVisible = false },
            containerColor = ArixSurface,
            contentColor = ArixOnSurface,
            dragHandle = {
                Box(
                    modifier = Modifier
                        .padding(top = 10.dp, bottom = 8.dp)
                        .width(56.dp)
                        .height(5.dp)
                        .clip(RoundedCornerShape(999.dp))
                        .background(ArixOnSurfaceVariant.copy(alpha = 0.16f))
                )
            },
        ) {
            ReasoningTraceSheetContent(
                trace = trace,
                onOpenLink = onOpenLink,
            )
        }
    }
}

@Composable
private fun ReasoningTypewriterText(
    text: String,
    styleColor: Color,
) {
    var rendered by remember(text) { mutableStateOf("") }
    LaunchedEffect(text) {
        if (text.isBlank()) {
            rendered = ""
            return@LaunchedEffect
        }
        if (!text.startsWith(rendered)) {
            rendered = ""
        }
        while (rendered.length < text.length) {
            val nextEnd = (rendered.length + 3).coerceAtMost(text.length)
            rendered = text.substring(0, nextEnd)
            delay(18)
        }
    }
    Text(
        text = rendered.ifBlank { text },
        style = MaterialTheme.typography.bodyMedium,
        color = styleColor,
    )
}

@Composable
private fun ReasoningTraceSheetContent(
    trace: ReasoningTrace,
    onOpenLink: (String) -> Unit,
) {
    ReasoningSheetPages(
        traceId = trace.id,
        rawText = trace.rawText,
        sections = trace.chunks.map { ReasoningRawSection(it.id, it.rawText) },
    ) { onOpenRawReasoning ->
        if (trace.hasTimelineContent || trace.completedAtMillis != null) {
            ReasoningTimeline(
                trace = trace,
                onOpenLink = onOpenLink,
                onOpenRawReasoning = onOpenRawReasoning,
            )
        } else {
            RawReasoningPanel(rawText = trace.rawText)
        }
    }
}

@Composable
private fun RawReasoningPanel(
    rawText: String,
) {
    val waitingForReasoning = stringResource(R.string.chat_waiting_for_reasoning)
    val displayText = remember(rawText, waitingForReasoning) {
        rawText.ifBlank { waitingForReasoning }.let { text ->
            if (text.length <= 12_000) text else text.take(12_000).trimEnd() + "\n..."
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = stringResource(R.string.chat_raw_reasoning),
            style = MaterialTheme.typography.labelMedium,
            color = ArixOnSurfaceVariant,
        )
        SelectionContainer {
            Text(
                text = displayText,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(ArixSurfaceHigh)
                    .padding(14.dp),
                style = MaterialTheme.typography.bodyMedium,
                color = ArixOnSurfaceVariant,
            )
        }
    }
}

@Composable
private fun ReasoningTimeline(
    trace: ReasoningTrace,
    onOpenLink: (String) -> Unit,
    onOpenRawReasoning: (String, String) -> Unit,
) {
    val timelineItems = remember(trace.chunks, trace.toolInvocations) {
        reasoningTimelineItems(trace)
    }
    val duplicateMediaSearchIds = remember(timelineItems) {
        val seen = HashSet<String>()
        timelineItems.mapNotNull { item ->
            (item as? ReasoningTimelineItem.Tool)?.toolInvocation?.let { toolInvocation ->
                val isGalleryTool = toolInvocation.toolName.equals("media_search", ignoreCase = true)
                if (isGalleryTool &&
                    toolInvocation.argumentsJson.isNotBlank() &&
                    !seen.add(toolInvocation.argumentsJson)
                ) {
                    toolInvocation.id
                } else {
                    null
                }
            }
        }.toSet()
    }
    val hasDoneChunk = trace.completedAtMillis != null
    val summarizingReasoningTitle = stringResource(R.string.chat_summarizing_reasoning)
    val preparingReasoningSummary = stringResource(R.string.chat_preparing_reasoning_summary)
    Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {
        ToolResultsInlineGallery(
            timelineItems.mapNotNull { (it as? ReasoningTimelineItem.Tool)?.toolInvocation }
        )
        timelineItems.forEachIndexed { index, item ->
            val isLast = !hasDoneChunk && index == timelineItems.lastIndex
            when (item) {
                is ReasoningTimelineItem.Summary -> ReasoningTimelineRow(
                    title = if (item.chunk.isPending) "" else item.chunk.title.ifBlank { summarizingReasoningTitle },
                    detail = when {
                        item.chunk.isPending -> pendingReasoningPreview(item.chunk.rawText)
                            .ifBlank { preparingReasoningSummary }
                        item.chunk.detail.isNotBlank() -> item.chunk.detail
                        else -> preparingReasoningSummary
                    },
                    isLast = isLast,
                    onOpenRawReasoning = if (!item.chunk.isPending && item.chunk.rawText.isNotBlank()) {
                        { onOpenRawReasoning(item.chunk.title, item.chunk.id) }
                    } else null,
                )

                is ReasoningTimelineItem.Tool -> ReasoningTimelineToolRow(
                    toolInvocation = item.toolInvocation,
                    isLast = isLast,
                    onOpenLink = onOpenLink,
                    suppressResultWidget = item.toolInvocation.toolName.equals("media_search", ignoreCase = true) ||
                        item.toolInvocation.id in duplicateMediaSearchIds,
                )
            }
        }
        if (hasDoneChunk) {
            ReasoningTimelineDoneRow(trace = trace)
        }
    }
}

internal sealed interface ReasoningTimelineItem {
    val sortOrder: Long
    val fallbackOrder: Int

    data class Summary(
        val chunk: ReasoningSummaryChunk,
        override val sortOrder: Long,
        override val fallbackOrder: Int,
    ) : ReasoningTimelineItem

    data class Tool(
        val toolInvocation: ChatToolInvocation,
        override val sortOrder: Long,
        override val fallbackOrder: Int,
    ) : ReasoningTimelineItem
}

internal fun reasoningTimelineItems(trace: ReasoningTrace): List<ReasoningTimelineItem> {
    val visibleChunks = trace.chunks.filter {
        it.title.isNotBlank() || it.detail.isNotBlank() || it.isPending || it.rawText.isNotBlank()
    }
    val items = buildList {
        visibleChunks.forEachIndexed { index, chunk ->
            add(
                ReasoningTimelineItem.Summary(
                    chunk = chunk,
                    sortOrder = chunk.timelineOrder
                        .takeIf { it > 0L }
                        ?: chunk.createdAtMillis.takeIf { it > 0L }
                        ?: Long.MAX_VALUE,
                    fallbackOrder = index,
                )
            )
        }
        trace.toolInvocations.forEachIndexed { index, invocation ->
            add(
                ReasoningTimelineItem.Tool(
                    toolInvocation = invocation,
                    sortOrder = invocation.timelineOrder
                        .takeIf { it > 0L }
                        ?: invocation.startedAtMillis.takeIf { it > 0L }
                        ?: Long.MAX_VALUE,
                    fallbackOrder = visibleChunks.size + index,
                )
            )
        }
    }

    return items.sortedWith(
        compareBy<ReasoningTimelineItem> { it.sortOrder }
            .thenBy { it.fallbackOrder }
    )
}

@Composable
private fun ReasoningTimelineRow(
    title: String,
    detail: String,
    isLast: Boolean,
    onOpenRawReasoning: (() -> Unit)?,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .reasoningTimelineConnector(isLast = isLast),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        TimelineGlyph(isLast = isLast)
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(bottom = if (isLast) 0.dp else 22.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            if (title.isNotBlank()) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                    color = ArixOnSurface,
                )
            }
            if (detail.isNotBlank()) {
                Text(
                    text = detail,
                    modifier = if (onOpenRawReasoning != null) Modifier.noRippleClickable(onClick = onOpenRawReasoning) else Modifier,
                    style = MaterialTheme.typography.bodyMedium,
                    color = ArixOnSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun ReasoningTimelineToolRow(
    toolInvocation: ChatToolInvocation,
    isLast: Boolean,
    onOpenLink: (String) -> Unit,
    suppressResultWidget: Boolean = false,
) {
    val arguments = remember(toolInvocation.argumentsJson) { parseJsonObject(toolInvocation.argumentsJson) }
    val output = remember(toolInvocation.outputJson) { parseJsonObject(toolInvocation.outputJson) }
    val webSourceMetadata = remember(toolInvocation.toolName, toolInvocation.argumentsJson, toolInvocation.outputJson) {
        webSourceMetadata(toolInvocation.toolName, arguments, output)
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .reasoningTimelineConnector(isLast = isLast),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        TimelineGlyph(
            icon = reasoningToolIcon(toolInvocation.toolName),
            isLast = isLast,
        )
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(bottom = if (isLast) 0.dp else 18.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            ToolInvocationCard(
                toolInvocation = toolInvocation,
                topPadding = 0.dp,
                suppressResultWidget = suppressResultWidget,
            )
            webSourceMetadata?.let { metadata ->
                WebSourcePill(
                    metadata = metadata,
                    onOpenLink = onOpenLink,
                )
            }
        }
    }
}

@Composable
private fun ReasoningTimelineDoneRow(
    trace: ReasoningTrace,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .reasoningTimelineConnector(isLast = true),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        TimelineGlyph(
            icon = Icons.Rounded.CheckCircle,
            isLast = true,
        )
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Text(
                text = formatReasoningTraceDoneChunkTitle(trace),
                style = MaterialTheme.typography.bodyMedium,
                color = ArixOnSurface,
            )
            Text(
                text = stringResource(R.string.common_done),
                style = MaterialTheme.typography.bodyMedium,
                color = ArixOnSurfaceVariant,
            )
        }
    }
}

private fun Modifier.reasoningTimelineConnector(isLast: Boolean): Modifier = drawBehind {
    if (isLast) return@drawBehind
    val lineTop = TimelineIconSize.toPx() + TimelineLineTopGap.toPx()
    val lineBottom = size.height - TimelineLineBottomGap.toPx()
    if (lineBottom <= lineTop) return@drawBehind
    val centerX = TimelineGlyphWidth.toPx() / 2f
    val halfStroke = (TimelineLineWidth.toPx() / 2f).coerceAtLeast(0.5f)
    drawRoundRect(
        color = ArixOnSurfaceVariant.copy(alpha = 0.12f),
        topLeft = Offset(centerX - halfStroke, lineTop),
        size = Size(halfStroke * 2f, lineBottom - lineTop),
        cornerRadius = CornerRadius(halfStroke),
    )
}

@Composable
private fun TimelineGlyph(
    icon: ImageVector? = null,
    isLast: Boolean,
) {
    Box(
        modifier = Modifier
            .width(TimelineGlyphWidth),
        contentAlignment = Alignment.TopCenter,
    ) {
        if (icon != null) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = ArixOnSurfaceVariant,
                modifier = Modifier.size(TimelineIconSize),
            )
        } else {
            Box(
                modifier = Modifier
                    .padding(top = 5.dp)
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(ArixOnSurfaceVariant)
            )
        }
    }
}

private fun reasoningToolIcon(toolName: String): ImageVector = when (toolName.lowercase()) {
    "bash" -> Icons.Rounded.Terminal
    "fetch_web_url", "tavily_search", "browser" -> Icons.Rounded.Language
    "media_search" -> Icons.Rounded.Headphones
    "upi_pay" -> Icons.Rounded.CurrencyRupee
    else -> Icons.Rounded.Build
}

@Composable
private fun WebSourcePill(
    metadata: WebSourceMetadata,
    onOpenLink: (String) -> Unit,
) {
    val favicon = rememberRemoteBitmap(metadata.faviconUrl)
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(ArixSurfaceHigh.copy(alpha = 0.72f))
            .noRippleClickable { onOpenLink(metadata.url) }
            .padding(start = 10.dp, top = 7.dp, end = 12.dp, bottom = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp),
    ) {
        if (favicon != null) {
            Image(
                bitmap = favicon,
                contentDescription = null,
                modifier = Modifier
                    .size(16.dp)
                    .clip(CircleShape),
                contentScale = ContentScale.Fit,
            )
        } else {
            Icon(
                imageVector = Icons.Rounded.Language,
                contentDescription = null,
                tint = ArixOnSurfaceVariant,
                modifier = Modifier.size(16.dp),
            )
        }
        Text(
            text = metadata.domain,
            style = MaterialTheme.typography.bodyMedium,
            color = ArixOnSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun rememberRemoteBitmap(
    url: String?,
): ImageBitmap? {
    val bitmap by produceState<ImageBitmap?>(initialValue = null, url) {
        value = withContext(Dispatchers.IO) {
            val sourceUrl = url?.takeIf { it.isNotBlank() } ?: return@withContext null
            runCatching {
                val connection = (URL(sourceUrl).openConnection() as HttpURLConnection).apply {
                    connectTimeout = FaviconFetchTimeoutMillis
                    readTimeout = FaviconFetchTimeoutMillis
                    instanceFollowRedirects = true
                    setRequestProperty("User-Agent", DefaultFaviconUserAgent)
                    setRequestProperty("Accept", "image/avif,image/webp,image/png,image/svg+xml,image/*;q=0.8,*/*;q=0.5")
                }
                try {
                    connection.inputStream.use { stream ->
                        val bounded = ByteArrayOutputStream()
                        val buffer = ByteArray(8 * 1024)
                        while (true) {
                            val read = stream.read(buffer)
                            if (read <= 0) break
                            bounded.write(buffer, 0, read)
                            if (bounded.size() > MaxFaviconDownloadBytes) {
                                return@runCatching null
                            }
                        }
                        val bytes = bounded.toByteArray()
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
                    }
                } finally {
                    connection.disconnect()
                }
            }.getOrNull()
        }
    }
    return bitmap
}

private fun webSourceMetadata(
    toolName: String,
    arguments: JSONObject?,
    output: JSONObject?,
): WebSourceMetadata? = when (toolName.lowercase()) {
    "fetch_web_url" -> {
        val sourceUrl = output?.optString("final_url").orEmpty()
            .ifBlank { output?.optString("request_url").orEmpty() }
            .ifBlank { arguments?.optString("url").orEmpty() }
        webSourceMetadataFromUrl(sourceUrl)
    }
    "tavily_search" -> tavilySourceMetadata(arguments, output)
    else -> null
}

private fun tavilySourceMetadata(
    arguments: JSONObject?,
    output: JSONObject?,
): WebSourceMetadata {
    val result = output?.optJSONArray("results")?.let { results ->
        (0 until results.length())
            .asSequence()
            .mapNotNull(results::optJSONObject)
            .firstOrNull { it.optString("url").isNotBlank() || it.optString("favicon").isNotBlank() }
    }
    val resultUrl = result?.optString("url").orEmpty()
    val argumentDomain = firstSearchArgumentDomain(arguments)
    val domain = normalizedDomain(resultUrl)
        .ifBlank { argumentDomain }
        .ifBlank { TavilyFallbackDomain }
    val url = normalizedHttpUrl(resultUrl)
        .ifBlank { normalizedHttpUrl(domain) }
        .ifBlank { "https://$TavilyFallbackDomain" }
    val faviconUrl = result?.optString("favicon").orEmpty()
        .takeIf { (it.startsWith("http://") || it.startsWith("https://")) && !it.endsWith(".svg", ignoreCase = true) }
        ?: faviconUrlForDomain(domain)
    return WebSourceMetadata(
        domain = domain,
        url = url,
        faviconUrl = faviconUrl,
    )
}

private fun webSourceMetadataFromUrl(url: String): WebSourceMetadata? {
    val domain = normalizedDomain(url)
    if (domain.isBlank()) return null
    return WebSourceMetadata(
        domain = domain,
        url = normalizedHttpUrl(url).ifBlank { "https://$domain" },
        faviconUrl = faviconUrlForDomain(domain),
    )
}

private fun firstSearchArgumentDomain(arguments: JSONObject?): String {
    val includeDomains = arguments?.optJSONArray("include_domains")
        ?: arguments?.optJSONArray("includeDomains")
    if (includeDomains != null) {
        for (index in 0 until includeDomains.length()) {
            val domain = normalizedDomain(includeDomains.optString(index))
            if (domain.isNotBlank()) return domain
        }
    }

    val query = arguments?.optString("query").orEmpty()
    val domainPattern = Regex("""(?:site:)?([A-Za-z0-9][A-Za-z0-9.-]*\.[A-Za-z]{2,})(?:/[^\s]*)?""")
    return domainPattern.find(query)
        ?.groupValues
        ?.getOrNull(1)
        ?.let(::normalizedDomain)
        .orEmpty()
}

private fun normalizedDomain(urlOrDomain: String): String {
    val trimmed = urlOrDomain.trim()
    if (trimmed.isBlank()) return ""
    val candidate = if (trimmed.contains("://")) trimmed else "https://$trimmed"
    val host = runCatching { URI(candidate).host }
        .getOrNull()
        .orEmpty()
        .ifBlank { trimmed.substringBefore('/').substringBefore('?').substringBefore('#') }
        .trim('.')
    if (host.isBlank()) return ""
    return runCatching { IDN.toUnicode(host) }
        .getOrDefault(host)
        .removePrefix("www.")
        .lowercase(Locale.US)
}

private fun normalizedHttpUrl(urlOrDomain: String): String {
    val trimmed = urlOrDomain.trim()
    if (trimmed.isBlank()) return ""
    val candidate = if (trimmed.contains("://")) trimmed else "https://$trimmed"
    val uri = runCatching { URI(candidate) }.getOrNull() ?: return ""
    val scheme = uri.scheme?.lowercase(Locale.US).orEmpty()
    if (scheme != "http" && scheme != "https") return ""
    val host = uri.host.orEmpty()
    if (host.isBlank()) return ""
    return uri.toString()
}

private fun faviconUrlForDomain(domain: String): String =
    "https://www.google.com/s2/favicons?domain=${Uri.encode(domain)}&sz=64"

@Composable
fun ReconnectingStatusCard(
    text: String,
    detail: String,
    isRunning: Boolean = false,
    modifier: Modifier = Modifier,
) {
    var expanded by rememberSaveable(text, detail) { mutableStateOf(false) }
    LaunchedEffect(detail) {
        if (detail.isBlank()) {
            expanded = false
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .then(
                if (isRunning) Modifier else Modifier.animateContentSize(
                    animationSpec = tween(durationMillis = ToolTransitionDurationMillis, easing = ToolTransitionEasing),
                ),
            )
            .noRippleClickable(enabled = !isRunning && detail.isNotBlank()) { expanded = !expanded },
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        if (isRunning) {
            ShimmerStatusText(text = text)
            if (detail.isNotBlank() && detail != text) {
                Text(
                    text = detail,
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                )
            }
        } else {
            Text(
                text = text,
                style = MaterialTheme.typography.bodyMedium,
                color = ArixOnSurfaceVariant,
            )

            AnimatedVisibility(
                visible = expanded && detail.isNotBlank(),
                enter = expandVertically(
                    animationSpec = tween(durationMillis = ToolTransitionDurationMillis, easing = ToolTransitionEasing),
                    expandFrom = Alignment.Top,
                ) + fadeIn(
                    animationSpec = tween(
                        durationMillis = ToolTransitionDurationMillis - 90,
                        delayMillis = 40,
                        easing = ToolTransitionEasing,
                    ),
                ),
                exit = shrinkVertically(
                    animationSpec = tween(durationMillis = 240, easing = FastOutLinearInEasing),
                    shrinkTowards = Alignment.Top,
                ) + fadeOut(
                    animationSpec = tween(durationMillis = 160, easing = FastOutLinearInEasing),
                ),
            ) {
                SyntaxHighlightedCodeBlock(
                    label = stringResource(R.string.common_error),
                    content = remember(detail) { highlightToolResult(detail) },
                )
            }
        }
    }
}

@Composable
fun ToolInvocationCard(
    toolInvocation: ChatToolInvocation,
    topPadding: Dp = 6.dp,
    suppressResultWidget: Boolean = false,
) {
    val context = LocalContext.current
    val arguments = remember(toolInvocation.argumentsJson) { parseJsonObject(toolInvocation.argumentsJson) }
    val output = remember(toolInvocation.outputJson) { parseJsonObject(toolInvocation.outputJson) }
    val title = remember(context, toolInvocation.toolName, toolInvocation.isRunning, toolInvocation.argumentsJson) {
        formatToolInvocationTitleLabel(context, toolInvocation, arguments = arguments)
    }
    val noOutputLabel = stringResource(R.string.chat_no_output)
    val contentTruncatedLabel = stringResource(R.string.chat_content_truncated)
    val exitCodeLabel = remember(context) {
        { exitCode: Int -> context.getString(R.string.tool_invocation_exit_code, exitCode) }
    }
    val detail = remember(
        toolInvocation.toolName,
        toolInvocation.isRunning,
        toolInvocation.argumentsJson,
        toolInvocation.outputJson,
        noOutputLabel,
        contentTruncatedLabel,
        exitCodeLabel,
    ) {
        formatToolInvocationDetail(
            toolInvocation = toolInvocation,
            arguments = arguments,
            output = output,
            noOutputLabel = noOutputLabel,
            contentTruncatedLabel = contentTruncatedLabel,
            exitCodeLabel = exitCodeLabel,
        )
    }
    var expanded by rememberSaveable(toolInvocation.id) { mutableStateOf(false) }
    val toolWidgetPayload = remember(toolInvocation.toolName, toolInvocation.outputJson, toolInvocation.isRunning, suppressResultWidget) {
        if (!toolInvocation.isRunning && toolInvocation.outputJson.isNotBlank() && !suppressResultWidget) {
            parseArixToolWidgetPayload(toolInvocation.outputJson)
        } else {
            null
        }
    }
    LaunchedEffect(
        toolInvocation.id,
        toolInvocation.isRunning,
        toolInvocation.startedAtUptimeMillis,
        toolInvocation.completedAtUptimeMillis,
    ) {
        if (!toolInvocation.isRunning) {
            expanded = false
            return@LaunchedEffect
        }

        val startedAt = toolInvocation.startedAtUptimeMillis
            .takeIf { it > 0L }
            ?: SystemClock.uptimeMillis()
        val remainingDelayMillis = ToolInvocationAutoExpandDelayMillis -
            (SystemClock.uptimeMillis() - startedAt)
        if (remainingDelayMillis > 0L) {
            delay(remainingDelayMillis)
        }
        expanded = true
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (toolInvocation.isRunning) Modifier else Modifier.animateContentSize(
                    animationSpec = tween(durationMillis = ToolTransitionDurationMillis, easing = ToolTransitionEasing),
                ),
            )
            .noRippleClickable { expanded = !expanded }
            .padding(top = topPadding),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        if (toolInvocation.isRunning) {
            ShimmerStatusText(
                text = title,
                travelDurationMillis = 3200,
                pauseDurationMillis = 1000,
            )
        } else {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                color = ArixOnSurfaceVariant,
            )
        }
        if (toolWidgetPayload != null && !toolInvocation.isRunning) {
            ArixToolResultWidget(
                toolName = toolInvocation.toolName,
                outputJson = toolInvocation.outputJson,
            )
            return@Column
        }
        AnimatedVisibility(
            visible = expanded && detail.command.isNotBlank(),
            enter = expandVertically(
                animationSpec = tween(durationMillis = ToolTransitionDurationMillis, easing = ToolTransitionEasing),
                expandFrom = Alignment.Top,
            ) + fadeIn(
                animationSpec = tween(
                    durationMillis = ToolTransitionDurationMillis - 90,
                    delayMillis = 40,
                    easing = ToolTransitionEasing,
                ),
            ),
            exit = shrinkVertically(
                animationSpec = tween(durationMillis = 240, easing = FastOutLinearInEasing),
                shrinkTowards = Alignment.Top,
            ) + fadeOut(
                animationSpec = tween(durationMillis = 160, easing = FastOutLinearInEasing),
            ),
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SyntaxHighlightedCodeBlock(
                    label = stringResource(R.string.tool_invocation_command),
                    content = remember(detail.command) { highlightBashCommand(detail.command) },
                )
                detail.result?.let { result ->
                    SyntaxHighlightedCodeBlock(
                        label = stringResource(R.string.tool_invocation_result),
                        content = remember(result) { highlightToolResult(result) },
                    )
                }
            }
        }
    }
}

private fun Modifier.noRippleClickable(
    enabled: Boolean = true,
    onClick: () -> Unit,
): Modifier = composed {
    clickable(
        enabled = enabled,
        indication = null,
        interactionSource = remember { MutableInteractionSource() },
        onClick = onClick,
    )
}

@Composable
internal fun SyntaxHighlightedCodeBlock(
    label: String,
    content: AnnotatedString,
    modifier: Modifier = Modifier,
    maxHeight: Dp = 220.dp,
    scrollState: ScrollState = rememberScrollState(),
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = ArixOnSurfaceVariant,
        )
        SelectionContainer {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(ArixSurfaceHigh)
                    .padding(horizontal = 12.dp, vertical = 10.dp)
                    .heightIn(max = maxHeight)
                    .verticalScroll(scrollState),
            ) {
                Text(
                    text = content,
                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                    color = ArixOnSurface,
                )
            }
        }
    }
}

@Composable
private fun AssistantAttachments(
    attachments: List<ChatAttachment>,
    onOpenAttachment: (ChatAttachment) -> Unit,
) {
    attachments.forEach { attachment ->
        when (attachment.kind) {
            AttachmentKind.Image -> UserImageAttachmentCard(attachment = attachment, onClick = { onOpenAttachment(attachment) })
            AttachmentKind.File -> UserFileAttachmentCard(attachment = attachment, onClick = { onOpenAttachment(attachment) })
        }
    }
}

@Composable
fun AttachmentPreviewDialog(
    attachment: ChatAttachment,
    onDismiss: () -> Unit,
    onSave: () -> Unit,
) {
    if (attachment.kind == AttachmentKind.Image) {
        AttachmentImageViewer(attachment = attachment, onDismiss = onDismiss)
        return
    }
    val attachmentKindLabel = attachmentTypeLabel(attachment.kind)
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 24.dp)
                .shadow(24.dp, RoundedCornerShape(30.dp), ambientColor = ArixScrim, spotColor = ArixScrim)
                .clip(RoundedCornerShape(30.dp))
            .background(ArixSurface.copy(alpha = 0.98f))
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(ArixSurfaceHigh),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = if (attachment.kind == AttachmentKind.Image) Icons.Rounded.Image else Icons.Rounded.Description,
                        contentDescription = null,
                        tint = ArixOnSurface,
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = attachment.name,
                        style = MaterialTheme.typography.titleMedium,
                        color = ArixOnSurface,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = formatAttachmentMetaLabel(attachmentKindLabel, attachment),
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                    )
                }
                IconOnlyAction(
                    icon = Icons.Rounded.Close,
                    contentDescription = stringResource(R.string.attachment_close_preview),
                    onClick = onDismiss,
                )
            }

            when (attachment.kind) {
                AttachmentKind.Image -> AttachmentImagePreview(attachment)
                AttachmentKind.File -> AttachmentFilePreview(attachment)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionIconLabel(
                    icon = Icons.Rounded.Download,
                    label = stringResource(R.string.common_save),
                    enabled = true,
                    onClick = onSave,
                )
            }
        }
    }
}

@Composable
private fun AttachmentImageViewer(
    attachment: ChatAttachment,
    onDismiss: () -> Unit,
) {
    val context = LocalContext.current
    val bitmap = rememberAttachmentBitmap(attachment, maxSize = 2200)
    val bytes by androidx.compose.runtime.produceState<ByteArray?>(
        initialValue = null,
        key1 = attachment.id,
    ) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                attachment.inlineBase64.takeIf { it.isNotBlank() }?.let { encoded ->
                    android.util.Base64.decode(encoded, android.util.Base64.DEFAULT)
                } ?: run {
                    val attachmentUri = android.net.Uri.parse(attachment.uri)
                    context.contentResolver.openInputStream(attachmentUri)?.use { input ->
                        input.readBytes()
                    }
                }
            }.getOrNull()
        }
    }
    ArixMediaViewerDialog(
        onDismiss = onDismiss,
        bitmap = bitmap,
        imageBytes = bytes,
        imageMimeType = attachment.mimeType,
        title = attachment.name,
        detail = listOfNotNull(
            attachmentTypeLabel(attachment.kind),
            attachment.sizeBytes?.takeIf { it > 0L }?.let { size ->
                ArixMediaActions.formatFileSize(size)
            },
        ).joinToString(" · "),
        fileName = attachment.name.ifBlank { "arix-attachment.jpg" },
    )
}

@Composable
private fun AttachmentImagePreview(
    attachment: ChatAttachment,
) {
    val bitmap = rememberAttachmentBitmap(attachment, maxSize = 2200)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 220.dp, max = 560.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(ArixSurfaceHigh),
        contentAlignment = Alignment.Center,
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap,
                contentDescription = attachment.name,
                modifier = Modifier.fillMaxWidth(),
                contentScale = ContentScale.Fit,
            )
        } else {
            Icon(
                imageVector = Icons.Rounded.Image,
                contentDescription = null,
                tint = ArixOnSurfaceVariant,
                modifier = Modifier.size(40.dp),
            )
        }
    }
}

@Composable
private fun AttachmentFilePreview(
    attachment: ChatAttachment,
) {
    val preview = rememberAttachmentTextPreview(attachment)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(ArixSurfaceHigh)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        if (preview == null) {
            Text(
                text = stringResource(R.string.attachment_file_preview_unavailable),
                style = MaterialTheme.typography.bodyMedium,
                color = ArixOnSurfaceVariant,
            )
        } else {
            SelectionContainer {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 160.dp, max = 360.dp)
                        .verticalScroll(rememberScrollState()),
                ) {
                    Text(
                        text = preview.text,
                        style = MaterialTheme.typography.bodyMedium,
                        color = ArixOnSurface,
                    )
                }
            }
            if (preview.isTruncated) {
                Text(
                    text = stringResource(R.string.attachment_preview_truncated),
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun UserImageAttachmentCard(
    attachment: ChatAttachment,
    onClick: () -> Unit,
) {
    val bitmap = rememberAttachmentBitmap(attachment, maxSize = 1400)
    Box(
        modifier = Modifier
            .widthIn(max = 300.dp)
            .shadow(10.dp, RoundedCornerShape(24.dp), ambientColor = ArixScrim, spotColor = ArixScrim)
            .clip(RoundedCornerShape(24.dp))
            .background(ArixSurface)
            .clickable(onClick = onClick)
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap,
                contentDescription = attachment.name,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp),
                contentScale = ContentScale.Crop,
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp)
                    .background(ArixSurfaceHigh),
            ) {
                Icon(
                    imageVector = Icons.Rounded.Image,
                    contentDescription = null,
                    tint = ArixOnSurfaceVariant,
                    modifier = Modifier.align(Alignment.Center),
                )
            }
        }
    }
}

@Composable
private fun UserFileAttachmentCard(
    attachment: ChatAttachment,
    onClick: () -> Unit,
) {
    val attachmentKindLabel = attachmentTypeLabel(attachment.kind)
    Row(
        modifier = Modifier
            .widthIn(max = 300.dp)
            .shadow(10.dp, RoundedCornerShape(22.dp), ambientColor = ArixScrim, spotColor = ArixScrim)
            .clip(RoundedCornerShape(22.dp))
            .background(ArixSurface)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(ArixSurfaceHigh),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Rounded.Description, contentDescription = null, tint = ArixOnSurface)
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = attachment.name,
                style = MaterialTheme.typography.labelLarge,
                color = ArixOnSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = formatAttachmentMetaLabel(attachmentKindLabel, attachment),
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Icon(
            imageVector = Icons.AutoMirrored.Rounded.ArrowForwardIos,
            contentDescription = null,
            tint = ArixOnSurfaceVariant,
            modifier = Modifier.size(14.dp),
        )
    }
}

@Composable
private fun ComposerImageAttachmentCard(
    attachment: ChatAttachment,
    onRemove: () -> Unit,
) {
    val attachmentKindLabel = attachmentTypeLabel(attachment.kind)
    val copyingToWorkspaceLabel = stringResource(R.string.attachment_copying_to_workspace)
    val workspaceCopyFailedLabel = stringResource(R.string.attachment_workspace_copy_failed)
    val bitmap = rememberAttachmentBitmap(attachment, maxSize = 600)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(ArixSurfaceHigh)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(
            modifier = Modifier
                .size(62.dp)
                .clip(RoundedCornerShape(16.dp))
            .background(ArixSurface),
            contentAlignment = Alignment.Center,
        ) {
            if (bitmap != null) {
                Image(
                    bitmap = bitmap,
                    contentDescription = attachment.name,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                )
            } else {
                Icon(Icons.Rounded.Image, contentDescription = null, tint = ArixOnSurfaceVariant)
            }
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = attachment.name,
                style = MaterialTheme.typography.labelLarge,
                color = ArixOnSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = formatComposerAttachmentMetaLabel(
                    attachmentKindLabel = attachmentKindLabel,
                    copyingToWorkspaceLabel = copyingToWorkspaceLabel,
                    workspaceCopyFailedLabel = workspaceCopyFailedLabel,
                    attachment = attachment,
                ),
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
            )
        }
        IconOnlyAction(
            icon = Icons.Rounded.Close,
            contentDescription = stringResource(R.string.attachment_remove),
            onClick = onRemove,
        )
    }
}

@Composable
private fun ComposerFileAttachmentCard(
    attachment: ChatAttachment,
    onRemove: () -> Unit,
) {
    val attachmentKindLabel = attachmentTypeLabel(attachment.kind)
    val copyingToWorkspaceLabel = stringResource(R.string.attachment_copying_to_workspace)
    val workspaceCopyFailedLabel = stringResource(R.string.attachment_workspace_copy_failed)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(ArixSurfaceHigh)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
            .background(ArixSurface),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Rounded.AttachFile, contentDescription = null, tint = ArixOnSurface)
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = attachment.name,
                style = MaterialTheme.typography.labelLarge,
                color = ArixOnSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = formatComposerAttachmentMetaLabel(
                    attachmentKindLabel = attachmentKindLabel,
                    copyingToWorkspaceLabel = copyingToWorkspaceLabel,
                    workspaceCopyFailedLabel = workspaceCopyFailedLabel,
                    attachment = attachment,
                ),
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
            )
        }
        IconOnlyAction(
            icon = Icons.Rounded.Close,
            contentDescription = stringResource(R.string.attachment_remove),
            onClick = onRemove,
        )
    }
}

@Composable
private fun ActionIconLabel(
    icon: ImageVector,
    label: String,
    enabled: Boolean,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(if (enabled) ArixSurfaceHigh else ArixSurfaceHigh.copy(alpha = 0.45f))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Icon(icon, contentDescription = null, tint = if (enabled) ArixOnSurface else ArixOnSurface.copy(alpha = 0.45f), modifier = Modifier.size(14.dp))
        Text(label, style = MaterialTheme.typography.labelMedium, color = if (enabled) ArixOnSurface else ArixOnSurface.copy(alpha = 0.45f))
    }
}

@Composable
private fun IconOnlyAction(
    icon: ImageVector,
    contentDescription: String,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    Box(
        modifier = Modifier
            .size(28.dp)
            .clip(CircleShape)
            .background(
                if (enabled) ArixSurface.copy(alpha = 0.72f) else ArixSurface.copy(alpha = 0.35f)
            )
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = if (enabled) ArixOnSurfaceVariant else ArixOnSurfaceVariant.copy(alpha = 0.4f),
            modifier = Modifier.size(16.dp),
        )
    }
}

@Composable
private fun AssistantMessageAction(
    icon: ImageVector,
    contentDescription: String,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    Box(
        modifier = Modifier
            .size(24.dp)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = if (enabled) ArixOnSurfaceVariant else ArixOnSurfaceVariant.copy(alpha = 0.36f),
            modifier = Modifier.size(14.dp),
        )
    }
}

@Composable
private fun AssistantMessageActions(
    usageStatistics: ChatUsageStatistics?,
    sessionTotalTokens: Long?,
    actionsEnabled: Boolean,
    onCopy: () -> Unit,
    onRedo: () -> Unit,
    onDelete: () -> Unit,
) {
    var showStatistics by rememberSaveable { mutableStateOf(false) }
    var keepStatisticsPopup by remember { mutableStateOf(false) }
    val statisticsPopupAlpha by animateFloatAsState(
        targetValue = if (showStatistics) 1f else 0f,
        animationSpec = if (showStatistics) {
            tween(durationMillis = 140, easing = ToolTransitionEasing)
        } else {
            tween(durationMillis = 90, easing = FastOutLinearInEasing)
        },
        finishedListener = { alpha ->
            if (alpha == 0f) keepStatisticsPopup = false
        },
        label = "statistics_popup_alpha",
    )
    val statisticsPopupScale by animateFloatAsState(
        targetValue = if (showStatistics) 1f else 0.98f,
        animationSpec = if (showStatistics) {
            tween(durationMillis = 160, easing = ToolTransitionEasing)
        } else {
            tween(durationMillis = 90, easing = FastOutLinearInEasing)
        },
        label = "statistics_popup_scale",
    )
    Box {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AssistantMessageAction(
                icon = LucideIcons.Copy,
                contentDescription = stringResource(R.string.common_copy_reply),
                onClick = onCopy,
            )
            AssistantMessageAction(
                icon = LucideIcons.RotateCcw,
                contentDescription = stringResource(R.string.common_redo_reply),
                enabled = actionsEnabled,
                onClick = onRedo,
            )
            AssistantMessageAction(
                icon = LucideIcons.Trash2,
                contentDescription = stringResource(R.string.common_delete_reply),
                enabled = actionsEnabled,
                onClick = onDelete,
            )
            AssistantMessageAction(
                icon = LucideIcons.ChartNoAxesColumn,
                contentDescription = stringResource(R.string.statistics_title),
                onClick = {
                    keepStatisticsPopup = true
                    showStatistics = true
                },
            )
        }
        if (keepStatisticsPopup || showStatistics) {
            Popup(
                popupPositionProvider = remember { StatisticsPopupPositionProvider() },
                onDismissRequest = { showStatistics = false },
                properties = PopupProperties(focusable = true),
            ) {
                MessageStatisticsPopup(
                    usageStatistics = usageStatistics,
                    sessionTotalTokens = sessionTotalTokens,
                    modifier = Modifier.graphicsLayer {
                        alpha = statisticsPopupAlpha
                        scaleX = statisticsPopupScale
                        scaleY = statisticsPopupScale
                        transformOrigin = TransformOrigin(0.18f, 1f)
                    },
                )
            }
        }
    }
}

@Composable
private fun MessageStatisticsPopup(
    usageStatistics: ChatUsageStatistics?,
    sessionTotalTokens: Long?,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .widthIn(min = 236.dp, max = 300.dp)
            .shadow(18.dp, RoundedCornerShape(22.dp), ambientColor = ArixScrim, spotColor = ArixScrim)
            .clip(RoundedCornerShape(22.dp))
            .background(ArixSurface.copy(alpha = 0.98f))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(ArixPrimary.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = LucideIcons.ChartNoAxesColumn,
                    contentDescription = null,
                    tint = ArixPrimary,
                    modifier = Modifier.size(16.dp),
                )
            }
            Text(
                text = stringResource(R.string.statistics_title),
                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                color = ArixOnSurface,
            )
        }
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            MessageStatisticRow(
                label = stringResource(R.string.statistics_session_tokens),
                value = sessionTotalTokens?.let(::formatTokenCount)
                    ?: stringResource(R.string.statistics_unavailable),
            )
            MessageStatisticRow(
                label = stringResource(R.string.statistics_turn_tokens),
                value = usageStatistics?.totalTokens?.let(::formatTokenCount)
                    ?: stringResource(R.string.statistics_unavailable),
            )
            MessageStatisticRow(
                label = stringResource(R.string.statistics_reasoning_tokens),
                value = usageStatistics?.reasoningTokens?.let(::formatTokenCount)
                    ?: stringResource(R.string.statistics_unavailable),
            )
            MessageStatisticRow(
                label = stringResource(R.string.statistics_cached_input),
                value = usageStatistics?.cachedInputTokens?.let(::formatTokenCount)
                    ?: stringResource(R.string.statistics_unavailable),
            )
            MessageStatisticRow(
                label = stringResource(R.string.statistics_cache_write),
                value = usageStatistics?.cacheWriteTokens?.let(::formatTokenCount)
                    ?: stringResource(R.string.statistics_unavailable),
            )
            MessageStatisticRow(
                label = stringResource(R.string.statistics_output_rate),
                value = usageStatistics?.outputTokensPerSecond?.let(::formatTokenRate)
                    ?: stringResource(R.string.statistics_unavailable),
            )
            MessageStatisticRow(
                label = stringResource(R.string.statistics_first_token_latency),
                value = usageStatistics?.firstTokenLatencyMillis?.let(::formatLatency)
                    ?: stringResource(R.string.statistics_unavailable),
            )
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(ArixSurfaceHigh)
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            CompactStatisticValue(
                label = stringResource(R.string.statistics_input),
                value = usageStatistics?.inputTokens?.let(::formatTokenCount)
                    ?: stringResource(R.string.statistics_dash),
            )
            CompactStatisticValue(
                label = stringResource(R.string.statistics_output),
                value = usageStatistics?.outputTokens?.let(::formatTokenCount)
                    ?: stringResource(R.string.statistics_dash),
            )
            CompactStatisticValue(
                label = stringResource(R.string.statistics_source),
                value = usageStatistics?.tokenUsageSource?.ifBlank { null }
                    ?: stringResource(R.string.statistics_dash),
            )
        }
    }
}

@Composable
private fun MessageStatisticRow(
    label: String,
    value: String,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
            color = ArixOnSurface,
            textAlign = TextAlign.End,
        )
    }
}

@Composable
private fun CompactStatisticValue(
    label: String,
    value: String,
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        Text(
            text = value,
            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
            color = ArixOnSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = ArixOnSurfaceVariant,
            maxLines = 1,
        )
    }
}

private class StatisticsPopupPositionProvider : PopupPositionProvider {
    override fun calculatePosition(
        anchorBounds: androidx.compose.ui.unit.IntRect,
        windowSize: IntSize,
        layoutDirection: androidx.compose.ui.unit.LayoutDirection,
        popupContentSize: IntSize,
    ): IntOffset {
        val margin = 28
        val preferredX = anchorBounds.right + 18
        val fallbackX = anchorBounds.left - popupContentSize.width + 18
        val x = if (preferredX + popupContentSize.width <= windowSize.width - margin) {
            preferredX
        } else {
            fallbackX.coerceAtLeast(margin)
        }
        val y = (anchorBounds.top - 10).coerceIn(
            margin,
            max(margin, windowSize.height - popupContentSize.height - margin),
        )
        return IntOffset(x, y)
    }
}

private fun formatTokenCount(tokens: Long): String = when {
    tokens >= 1_000_000L -> String.format(Locale.US, "%.1fM", tokens / 1_000_000.0)
    tokens >= 1_000L -> String.format(Locale.US, "%.1fK", tokens / 1_000.0)
    else -> tokens.toString()
}

private fun formatTokenRate(tokensPerSecond: Double): String =
    String.format(Locale.US, "%.1f tok/s", tokensPerSecond)

private fun formatLatency(millis: Long): String =
    if (millis >= 1_000L) {
        String.format(Locale.US, "%.2fs", millis / 1000.0)
    } else {
        "${millis}ms"
    }

private fun formatMessageTimestamp(createdAtMillis: Long): String {
    if (createdAtMillis <= 0L) return ""
    return runCatching {
        Instant.ofEpochMilli(createdAtMillis)
            .atZone(ZoneId.systemDefault())
            .format(MessageTimestampFormatter)
    }.getOrDefault("")
}

@Composable
private fun rememberAttachmentBitmap(
    attachment: ChatAttachment,
    maxSize: Int,
): ImageBitmap? {
    val context = LocalContext.current
    val bitmap by produceState<ImageBitmap?>(initialValue = null, attachment, maxSize) {
        value = withContext(Dispatchers.IO) {
            decodeInlineAttachmentBitmap(attachment, maxSize)
                ?: decodeUriAttachmentBitmap(
                    resolver = context.contentResolver,
                    uriString = attachment.uri,
                    maxSize = maxSize,
                )
        }
    }
    return bitmap
}

private fun decodeInlineAttachmentBitmap(
    attachment: ChatAttachment,
    maxSize: Int,
): ImageBitmap? = runCatching {
    if (attachment.inlineBase64.isBlank()) return@runCatching null
    val bytes = Base64.getDecoder().decode(attachment.inlineBase64)
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return@runCatching null

    val sampleSize = calculateSampleSize(bounds.outWidth, bounds.outHeight, maxSize)
    val options = BitmapFactory.Options().apply { inSampleSize = sampleSize }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)?.asImageBitmap()
}.getOrNull()

private fun decodeUriAttachmentBitmap(
    resolver: android.content.ContentResolver,
    uriString: String,
    maxSize: Int,
): ImageBitmap? = decodeUriAttachmentBitmap(
    uriString = uriString,
    maxSize = maxSize,
    openInputStream = { uri -> resolver.openInputStream(uri) },
)

internal fun decodeUriAttachmentBitmap(
    uriString: String,
    maxSize: Int,
    openInputStream: (Uri) -> java.io.InputStream?,
): ImageBitmap? = runCatching {
    val uri = Uri.parse(uriString)
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
        return@runCatching null
    }

    val sampleSize = calculateSampleSize(bounds.outWidth, bounds.outHeight, maxSize)
    val options = BitmapFactory.Options().apply { inSampleSize = sampleSize }
    openInputStream(uri)?.use { stream ->
        BitmapFactory.decodeStream(stream, null, options)?.asImageBitmap()
    }
}.getOrNull()

@Composable
private fun rememberAttachmentTextPreview(
    attachment: ChatAttachment,
): AttachmentTextPreview? {
    val context = LocalContext.current
    val preview by produceState<AttachmentTextPreview?>(initialValue = null, attachment) {
        value = withContext(Dispatchers.IO) {
            if (!isLikelyTextAttachment(attachment)) {
                return@withContext null
            }

            val bytes = readAttachmentBytes(
                resolver = context.contentResolver,
                uriString = attachment.uri,
                byteLimit = 64 * 1024 + 1,
            ) ?: return@withContext null

            val decoded = decodeTextAttachment(bytes) ?: return@withContext null
            val isTruncated = bytes.size > 64 * 1024 || decoded.length > 12_000
            AttachmentTextPreview(
                text = decoded.take(12_000),
                isTruncated = isTruncated,
            )
        }
    }
    return preview
}

private fun readAttachmentBytes(
    resolver: android.content.ContentResolver,
    uriString: String,
    byteLimit: Int,
): ByteArray? = runCatching {
    resolver.openInputStream(Uri.parse(uriString))?.use { inputStream ->
        val output = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
        var totalRead = 0

        while (true) {
            val read = inputStream.read(buffer)
            if (read <= 0) break

            val remaining = byteLimit - totalRead
            if (remaining <= 0) break

            val writeCount = minOf(read, remaining)
            output.write(buffer, 0, writeCount)
            totalRead += writeCount

            if (totalRead >= byteLimit) break
        }

        output.toByteArray()
    }
}.getOrNull()

private fun decodeTextAttachment(
    bytes: ByteArray,
): String? {
    if (bytes.take(512).any { it == 0.toByte() }) return null

    val decoded = bytes.toString(Charsets.UTF_8)
    val replacementCount = decoded.count { it == '\uFFFD' }
    return if (replacementCount > 12) null else decoded
}

private fun isLikelyTextAttachment(
    attachment: ChatAttachment,
): Boolean {
    val mimeType = attachment.mimeType.lowercase()
    if (
        mimeType.startsWith("text/") ||
        mimeType.contains("json") ||
        mimeType.contains("xml") ||
        mimeType.contains("yaml") ||
        mimeType.contains("csv") ||
        mimeType.contains("javascript")
    ) {
        return true
    }

    val extension = attachment.name.substringAfterLast('.', "").lowercase()
    return extension in setOf(
        "txt",
        "md",
        "json",
        "xml",
        "yaml",
        "yml",
        "csv",
        "log",
        "kt",
        "java",
        "kts",
        "js",
        "ts",
        "tsx",
        "jsx",
        "py",
        "rb",
        "go",
        "rs",
        "c",
        "cc",
        "cpp",
        "h",
        "hpp",
        "html",
        "css",
        "sql",
        "sh",
        "gradle",
        "properties",
    )
}

private fun calculateSampleSize(
    width: Int,
    height: Int,
    maxSize: Int,
): Int {
    var sampleSize = 1
    var currentWidth = width
    var currentHeight = height

    while (currentWidth > maxSize || currentHeight > maxSize) {
        currentWidth /= 2
        currentHeight /= 2
        sampleSize *= 2
    }
    return sampleSize.coerceAtLeast(1)
}

private fun formatThoughtDuration(durationMillis: Long): String {
    val totalSeconds = (durationMillis / 1000f).roundToInt().coerceAtLeast(1)
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return buildList {
        if (hours > 0) add("${hours}h")
        if (minutes > 0 || hours > 0) add("${minutes}min")
        add("${seconds}s")
    }.joinToString(" ")
}

@Composable
fun formatWorkedSummaryTitle(durationMillis: Long): String =
    stringResource(R.string.chat_working_for_duration, formatThoughtDuration(durationMillis))

fun workDurationMillisForMessages(
    messages: List<ChatMessage>,
    endAtMillis: Long? = null,
): Long {
    messages.asReversed().forEach { message ->
        val usage = message.usageStatistics ?: return@forEach
        if (
            usage.startedAtMillis >= MinimumEpochMillis &&
            usage.completedAtMillis >= usage.startedAtMillis
        ) {
            return (usage.completedAtMillis - usage.startedAtMillis).coerceAtLeast(1_000L)
        }
    }
    messages.lastOrNull()?.thoughtDurationMillis?.let { duration ->
        return duration.coerceAtLeast(1_000L)
    }

    val timestamps = mutableListOf<Long>()
    messages.forEach { message ->
        if (message.createdAtMillis > 0L) {
            timestamps += message.createdAtMillis
        }
        message.reasoningTrace?.let { trace ->
            if (trace.startedAtMillis > 0L) timestamps += trace.startedAtMillis
            trace.completedAtMillis?.takeIf { it > 0L }?.let { timestamps += it }
            trace.chunks.forEach { chunk ->
                if (chunk.createdAtMillis > 0L) timestamps += chunk.createdAtMillis
            }
        }
        message.toolInvocations.forEach { invocation ->
            if (invocation.startedAtMillis > 0L) timestamps += invocation.startedAtMillis
            invocation.completedAtMillis?.takeIf { it > 0L }?.let { timestamps += it }
        }
    }
    endAtMillis?.takeIf { it > 0L }?.let { timestamps += it }

    val wallClockTimestamps = timestamps.filter { it >= MinimumEpochMillis }
    if (wallClockTimestamps.size < 2) {
        return 1_000L
    }
    return (wallClockTimestamps.maxOrNull()!! - wallClockTimestamps.minOrNull()!!)
        .coerceAtLeast(1_000L)
}

@Composable
private fun formatReasoningTraceDoneLabel(trace: ReasoningTrace): String {
    val startedAt = trace.startedAtMillis.takeIf { it > 0L }
    val endedAt = trace.completedAtMillis ?: System.currentTimeMillis()
    val duration = startedAt?.let { formatThoughtDuration((endedAt - it).coerceAtLeast(1L)) } ?: "0s"
    val toolCount = trace.toolInvocations.size
    return if (toolCount > 0) {
        stringResource(R.string.chat_thought_for_duration_and_tools, duration, toolCount)
    } else {
        stringResource(R.string.chat_thought_for_duration, duration)
    }
}

@Composable
private fun formatReasoningTraceDoneChunkTitle(trace: ReasoningTrace): String {
    val startedAt = trace.startedAtMillis.takeIf { it > 0L }
    val endedAt = trace.completedAtMillis ?: System.currentTimeMillis()
    val duration = startedAt?.let { formatThoughtDuration((endedAt - it).coerceAtLeast(1L)) } ?: "0s"
    return stringResource(R.string.chat_thought_for_duration, duration)
}

@Composable
private fun attachmentTypeLabel(kind: AttachmentKind): String = stringResource(
    if (kind == AttachmentKind.Image) R.string.attachment_type_photo else R.string.attachment_type_file,
)

private fun formatAttachmentMetaLabel(attachmentKindLabel: String, attachment: ChatAttachment): String {
    val sizeLabel = attachment.sizeBytes?.let(::formatAttachmentSize)
    return listOfNotNull(attachmentKindLabel, sizeLabel).joinToString(" | ")
}

private fun formatComposerAttachmentMetaLabel(
    attachmentKindLabel: String,
    copyingToWorkspaceLabel: String,
    workspaceCopyFailedLabel: String,
    attachment: ChatAttachment,
): String {
    val statusLabel = when (attachment.workspaceState) {
        AttachmentWorkspaceState.Pending -> copyingToWorkspaceLabel
        AttachmentWorkspaceState.Failed -> workspaceCopyFailedLabel
        AttachmentWorkspaceState.Ready -> null
    }
    return listOfNotNull(
        formatAttachmentMetaLabel(attachmentKindLabel, attachment).ifBlank { null },
        if (attachment.workspaceState == AttachmentWorkspaceState.Pending) {
            formatWorkspaceCopyProgress(copyingToWorkspaceLabel, attachment)
        } else {
            statusLabel
        },
    ).joinToString(" | ")
}

private fun formatWorkspaceCopyProgress(copyingToWorkspaceLabel: String, attachment: ChatAttachment): String {
    val copiedLabel = attachment.workspaceBytesCopied
        .takeIf { it > 0L }
        ?.let(::formatAttachmentSize)
    val totalLabel = attachment.sizeBytes?.takeIf { it > 0L }?.let(::formatAttachmentSize)
    val speedLabel = attachment.workspaceBytesPerSecond
        .takeIf { it > 0L }
        ?.let { "${formatAttachmentSize(it)}/s" }
    val progressLabel = when {
        copiedLabel != null && totalLabel != null -> "$copiedLabel / $totalLabel"
        copiedLabel != null -> copiedLabel
        else -> null
    }
    return listOfNotNull(copyingToWorkspaceLabel, progressLabel, speedLabel).joinToString(" · ")
}

private fun formatToolInvocationTitleLabel(
    context: Context,
    toolInvocation: ChatToolInvocation,
    arguments: JSONObject? = parseJsonObject(toolInvocation.argumentsJson),
): String {
    val isRunning = toolInvocation.isRunning
    return when (toolInvocation.toolName.lowercase()) {
        "bash" -> context.getString(if (isRunning) R.string.tool_title_bash_running else R.string.tool_title_bash_done)
        "read" -> context.getString(if (isRunning) R.string.tool_title_read_running else R.string.tool_title_read_done)
        "edit" -> context.getString(if (isRunning) R.string.tool_title_edit_running else R.string.tool_title_edit_done)
        "write" -> context.getString(if (isRunning) R.string.tool_title_write_running else R.string.tool_title_write_done)
        "grep" -> context.getString(if (isRunning) R.string.tool_title_grep_running else R.string.tool_title_grep_done)
        "find" -> context.getString(if (isRunning) R.string.tool_title_find_running else R.string.tool_title_find_done)
        "ls" -> context.getString(if (isRunning) R.string.tool_title_ls_running else R.string.tool_title_ls_done)
        "media_search" -> context.getString(if (isRunning) R.string.media_tool_title_running else R.string.media_tool_title_done)
        "browser" -> context.getString(if (isRunning) R.string.tool_title_browser_running else R.string.tool_title_browser_done)
        "upi_pay" -> context.getString(if (isRunning) R.string.tool_title_upi_running else R.string.tool_title_upi_done)
        "arix_ensure_package" -> context.getString(
            if (isRunning) R.string.tool_title_ensure_package_running else R.string.tool_title_ensure_package_done
        )
        "read_screen" -> context.getString(if (isRunning) R.string.tool_title_read_screen_running else R.string.tool_title_read_screen_done)
        "ui_action" -> context.getString(if (isRunning) R.string.tool_title_ui_action_running else R.string.tool_title_ui_action_done)
        "device_status" -> context.getString(if (isRunning) R.string.tool_title_device_status_running else R.string.tool_title_device_status_done)
        "open_app" -> context.getString(if (isRunning) R.string.tool_title_open_app_running else R.string.tool_title_open_app_done)
        "open_settings" -> context.getString(if (isRunning) R.string.tool_title_open_settings_running else R.string.tool_title_open_settings_done)
        "open_url" -> context.getString(if (isRunning) R.string.tool_title_open_url_running else R.string.tool_title_open_url_done)
        "agent_mode" -> formatAgentDisplayTitle(context = context, isRunning = isRunning, arguments = arguments)
        "arix_config_get",
        "arix_config_set",
        "arix_skill_manage",
        "arix_agent_mode_manage",
        "arix_developer_manage" -> formatArixToolTitle(
            context = context,
            toolName = toolInvocation.toolName,
            isRunning = isRunning,
            arguments = arguments,
        )
        else -> if (isRunning) {
            context.getString(R.string.tool_title_using_tool, toolInvocation.toolName)
        } else {
            context.getString(R.string.tool_title_used_tool, toolInvocation.toolName)
        }
    }
}

private fun summarizeToolInvocationCommandLabel(
    toolName: String,
    arguments: JSONObject?,
): String {
    if (arguments == null) return toolName
    return when (toolName.lowercase()) {
        "bash" -> arguments.optString("command").trim()
        "read" -> buildString {
            append("read ")
            append(arguments.optString("path").trim())
            val offset = arguments.takeIf { it.has("offset") }?.optInt("offset") ?: 0
            val limit = arguments.takeIf { it.has("limit") }?.optInt("limit")
            if (offset > 0 || limit != null) {
                append(" (offset=")
                append(offset)
                if (limit != null) {
                    append(", limit=")
                    append(limit)
                }
                append(')')
            }
        }
        "edit" -> {
            val path = arguments.optString("path").trim()
            val editCount = arguments.optJSONArray("edits")?.length()
                ?: if (arguments.has("oldText") || arguments.has("newText")) 1 else 0
            "edit $path${if (editCount > 0) " ($editCount edit${if (editCount == 1) "" else "s"})" else ""}"
        }
        "write" -> "write ${arguments.optString("path").trim()}"
        "grep" -> "grep ${arguments.optString("pattern").trim()} in ${arguments.optString("path").trim()}"
        "find" -> "find ${arguments.optString("pattern").trim()} in ${arguments.optString("path").trim()}"
        "ls" -> "ls ${arguments.optString("path").trim()}"
        "mcp" -> summarizeMcpProxyCommand(arguments)
        "analyze_image" -> buildString {
            append("analyze_image ")
            append(arguments.optString("path").trim())
            val prompt = arguments.optString("prompt").trim()
            if (prompt.isNotBlank()) {
                append(" (")
                append(prompt.take(48))
                if (prompt.length > 48) {
                    append("...")
                }
                append(')')
            }
        }
        "agent_mode" -> summarizeAgentDisplayCommand(arguments)
        "read_screen" -> "read_screen"
        "ui_action" -> buildString {
            append("ui_action ")
            append(arguments.optString("action").trim())
            val target = arguments.optString("target_text").trim().ifBlank {
                arguments.optString("target_resource_id").trim()
            }
            if (target.isNotBlank()) append(" \"${target.take(32)}\"")
        }.trim()
        "device_status" -> "device_status ${arguments.optString("action").trim()}".trim()
        "open_app" -> "open ${arguments.optString("app").trim()}"
        "open_settings" -> "open settings ${arguments.optString("page").trim()}".trim()
        "open_url" -> "open ${arguments.optString("url").trim()}"
        "media_search" -> buildString {
            val url = arguments.optString("url").trim()
            val site = arguments.optString("site").trim()
            val query = arguments.optString("query").trim()
            when {
                url.isNotBlank() -> append(url.take(72))
                site.isNotBlank() -> {
                    append("media from ")
                    append(site.take(48))
                    if (query.isNotBlank()) {
                        append(" — ")
                        append(query.take(32))
                    }
                }
                else -> append(query.take(60))
            }
        }.trim()
        "browser" -> buildString {
            append("browser")
            val action = arguments.optString("action").trim()
            if (action.isNotBlank()) {
                append(' ')
                append(action)
            }
            val url = arguments.optString("url").trim()
            if (url.isNotBlank()) {
                append(' ')
                append(url.take(72))
                if (url.length > 72) append("…")
            }
            val selector = arguments.optString("selector").trim()
            if (selector.isNotBlank()) {
                append(" sel=")
                append(selector.take(40))
                if (selector.length > 40) append("…")
            }
        }.trim()
        "upi_pay" -> buildString {
            val payee = arguments.optString("payee").trim()
            val amount = arguments.optDouble("amount", 0.0)
            if (amount > 0) append("₹${amount.toLong()} ")
            if (payee.isNotBlank()) append("to $payee")
        }.trim().ifBlank { "upi_pay" }
        "tavily_search" -> "search ${arguments.optString("query").trim()}"
        "fetch_web_url" -> "fetch ${arguments.optString("url").trim()}"
        "arix_config_get",
        "arix_config_set",
        "arix_skill_manage",
        "arix_mcp_manage",
        "arix_agent_mode_manage",
        "arix_developer_manage" -> summarizeArixToolCommand(toolName, arguments)
        else -> toolName
    }.trim()
}

private fun formatToolInvocationDetail(
    toolInvocation: ChatToolInvocation,
    arguments: JSONObject? = parseJsonObject(toolInvocation.argumentsJson),
    output: JSONObject? = parseJsonObject(toolInvocation.outputJson),
    noOutputLabel: String,
    contentTruncatedLabel: String,
    exitCodeLabel: (Int) -> String,
): ToolInvocationDetail {
    val command = output?.optString("command")
        .orEmpty()
        .trim()
        .ifBlank { summarizeToolInvocationCommandLabel(toolInvocation.toolName, arguments) }
        .ifBlank { toolInvocation.toolName }

    if (toolInvocation.isRunning && output == null) {
        return ToolInvocationDetail(
            command = command,
            result = null,
        )
    }

    val result = when {
        output == null -> toolInvocation.outputJson.trim().ifBlank { noOutputLabel }
        toolInvocation.toolName.startsWith("arix_", ignoreCase = true) -> {
            toolInvocation.outputJson.trim().ifBlank { noOutputLabel }
        }
        toolInvocation.toolName.equals("fetch_web_url", ignoreCase = true) -> {
            formatFetchWebUrlResult(output, noOutputLabel, contentTruncatedLabel)
        }
        output.optString("stdout").trim().isNotBlank() &&
            output.optString("stderr").trim().isNotBlank() -> {
            buildString {
                appendLine(output.optString("stdout").trim())
                appendLine()
                append("stderr: ")
                append(output.optString("stderr").trim())
            }
        }
        output.optString("stdout").trim().isNotBlank() -> output.optString("stdout").trim()
        output.optString("stderr").trim().isNotBlank() -> output.optString("stderr").trim()
        output.optString("errmsg").trim().isNotBlank() -> output.optString("errmsg").trim()
        output.optString("hint").trim().isNotBlank() -> output.optString("hint").trim()
        output.has("exit_code") && output.optInt("exit_code") != 0 -> exitCodeLabel(output.optInt("exit_code"))
        else -> noOutputLabel
    }

    val cappedResult = if (result.length > MaxToolResultDetailChars) {
        buildString {
            append(result.take(MaxToolResultDetailChars))
            append('\n')
            append('\n')
            append(contentTruncatedLabel)
        }
    } else {
        result
    }

    return ToolInvocationDetail(
        command = command,
        result = cappedResult,
    )
}

private fun formatFetchWebUrlResult(
    output: JSONObject,
    noOutputLabel: String,
    contentTruncatedLabel: String,
): String {
    val markdown = output.optString("markdown").trim()
    if (markdown.isNotBlank()) {
        return buildString {
            append(markdown)

            if (output.optBoolean("truncated")) {
                appendLine()
                appendLine()
                append(contentTruncatedLabel)
            }
        }.trim()
    }

    return output.optString("stdout").trim().ifBlank { noOutputLabel }
}

private const val MaxToolResultDetailChars = 6_000

private fun formatArgumentDrivenTitle(
    isRunning: Boolean,
    progressiveVerb: String,
    completedVerb: String,
    subject: String,
    fallback: String,
): String {
    val normalizedSubject = subject.trim()
    val action = if (isRunning) progressiveVerb else completedVerb
    if (normalizedSubject.isBlank()) {
        return "$action $fallback"
    }

    return "$action ${normalizedSubject.take(72)}${if (normalizedSubject.length > 72) "..." else ""}"
}

private fun formatAgentDisplayTitle(
    context: Context,
    isRunning: Boolean,
    arguments: JSONObject?,
): String {
    val action = arguments?.optString("action").orEmpty().lowercase()
    return when (action) {
        "list_apps", "apps", "installed_apps" -> formatArgumentDrivenTitle(
            isRunning = isRunning,
            progressiveVerb = context.getString(R.string.tool_title_reading),
            completedVerb = context.getString(R.string.tool_title_read),
            subject = arguments?.optString("query").orEmpty(),
            fallback = context.getString(R.string.tool_title_installed_apps_fallback),
        )
        "start" -> context.getString(if (isRunning) R.string.tool_title_starting_agent_mode_display else R.string.tool_title_started_agent_mode_display)
        "status" -> context.getString(if (isRunning) R.string.tool_title_checking_agent_mode_display else R.string.tool_title_checked_agent_mode_display)
        "launch" -> formatArgumentDrivenTitle(
            isRunning = isRunning,
            progressiveVerb = context.getString(R.string.tool_title_launching),
            completedVerb = context.getString(R.string.tool_title_launched),
            subject = arguments?.optString("target").orEmpty(),
            fallback = context.getString(R.string.tool_title_agent_mode_app_fallback),
        )
        "tap" -> context.getString(if (isRunning) R.string.tool_title_tapping_agent_mode_display else R.string.tool_title_tapped_agent_mode_display)
        "swipe" -> context.getString(if (isRunning) R.string.tool_title_swiping_agent_mode_display else R.string.tool_title_swiped_agent_mode_display)
        "key" -> formatArgumentDrivenTitle(
            isRunning = isRunning,
            progressiveVerb = context.getString(R.string.tool_title_pressing),
            completedVerb = context.getString(R.string.tool_title_pressed),
            subject = arguments?.optString("key").orEmpty(),
            fallback = context.getString(R.string.tool_title_agent_mode_key_fallback),
        )
        "text" -> context.getString(if (isRunning) R.string.tool_title_typing_agent_mode else R.string.tool_title_typed_agent_mode)
        "screenshot", "read_screen", "read", "screen" -> context.getString(if (isRunning) R.string.tool_title_capturing_agent_mode_display else R.string.tool_title_captured_agent_mode_display)
        "stop" -> context.getString(if (isRunning) R.string.tool_title_stopping_agent_mode_display else R.string.tool_title_stopped_agent_mode_display)
        else -> context.getString(if (isRunning) R.string.tool_title_using_agent_mode_display else R.string.tool_title_used_agent_mode_display)
    }
}

private fun formatArixToolTitle(
    context: Context,
    toolName: String,
    isRunning: Boolean,
    arguments: JSONObject?,
): String {
    val action = arguments?.optString("action").orEmpty().trim()
    return when (toolName.lowercase()) {
        "arix_config_get" -> formatArgumentDrivenTitle(
            isRunning = isRunning,
            progressiveVerb = context.getString(R.string.tool_title_reading),
            completedVerb = context.getString(R.string.tool_title_read),
            subject = summarizeArixCategories(arguments),
            fallback = context.getString(R.string.tool_title_arix_settings_fallback),
        )
        "arix_config_set" -> formatArgumentDrivenTitle(
            isRunning = isRunning,
            progressiveVerb = context.getString(R.string.tool_title_updating),
            completedVerb = context.getString(R.string.tool_title_updated),
            subject = arguments?.optString("category").orEmpty(),
            fallback = context.getString(R.string.tool_title_arix_settings_fallback),
        )
        "arix_skill_manage" -> when (action.lowercase()) {
            "install_remote" -> formatArgumentDrivenTitle(isRunning, context.getString(R.string.tool_title_installing), context.getString(R.string.tool_title_installed), arguments?.optString("url").orEmpty(), context.getString(R.string.tool_title_agent_skill_fallback))
            "remove" -> formatArgumentDrivenTitle(isRunning, context.getString(R.string.tool_title_removing), context.getString(R.string.tool_title_removed), optArixString(arguments, "skill_id", "skillId"), context.getString(R.string.tool_title_agent_skill_fallback))
            "set_enabled" -> formatArgumentDrivenTitle(isRunning, context.getString(R.string.tool_title_updating), context.getString(R.string.tool_title_updated), optArixString(arguments, "skill_id", "skillId"), context.getString(R.string.tool_title_agent_skill_fallback))
            else -> context.getString(if (isRunning) R.string.tool_title_reading_agent_skills else R.string.tool_title_read_agent_skills)
        }
        "arix_mcp_manage" -> when (action.lowercase()) {
            "upsert_streamable_http", "upsert_stdio" -> formatArgumentDrivenTitle(isRunning, context.getString(R.string.tool_title_saving), context.getString(R.string.tool_title_saved), optArixString(arguments, "display_name", "displayName"), context.getString(R.string.tool_title_mcp_server_fallback))
            "remove" -> formatArgumentDrivenTitle(isRunning, context.getString(R.string.tool_title_removing), context.getString(R.string.tool_title_removed), optArixString(arguments, "server_id", "serverId"), context.getString(R.string.tool_title_mcp_server_fallback))
            "set_enabled" -> formatArgumentDrivenTitle(isRunning, context.getString(R.string.tool_title_updating), context.getString(R.string.tool_title_updated), optArixString(arguments, "server_id", "serverId"), context.getString(R.string.tool_title_mcp_server_fallback))
            else -> context.getString(if (isRunning) R.string.tool_title_reading_mcp_servers else R.string.tool_title_read_mcp_servers)
        }
        "arix_agent_mode_manage" -> when (action.lowercase()) {
            "set_authorization" -> context.getString(if (isRunning) R.string.tool_title_updating_agent_mode_authorization else R.string.tool_title_updated_agent_mode_authorization)
            "stop_session" -> context.getString(if (isRunning) R.string.tool_title_stopping_agent_mode_display else R.string.tool_title_stopped_agent_mode_display)
            else -> context.getString(if (isRunning) R.string.tool_title_checking_agent_mode_authorization else R.string.tool_title_checked_agent_mode_authorization)
        }
        "arix_developer_manage" -> context.getString(if (isRunning) R.string.tool_title_reading_arix_diagnostics else R.string.tool_title_read_arix_diagnostics)
        else -> context.getString(if (isRunning) R.string.tool_title_managing_arix else R.string.tool_title_managed_arix)
    }
}

private fun summarizeArixToolCommand(
    toolName: String,
    arguments: JSONObject,
): String {
    val action = arguments.optString("action").trim()
    return when (toolName.lowercase()) {
        "arix_config_get" -> "arix_config_get categories=${summarizeArixCategories(arguments).ifBlank { "all" }}"
        "arix_config_set" -> "arix_config_set category=${arguments.optString("category").trim()} ${summarizeArixSettingsPatch(arguments.optJSONObject("settings"))}".trim()
        "arix_skill_manage" -> buildString {
            append("arix_skill_manage action=")
            append(action.ifBlank { "list" })
            appendArixKeyValue(arguments, "skill_id", "skillId")
            appendArixKeyValue(arguments, "url")
            if (arguments.has("enabled")) append(" enabled=").append(arguments.optBoolean("enabled"))
        }.trim()
        "arix_mcp_manage" -> buildString {
            append("arix_mcp_manage action=")
            append(action.ifBlank { "list" })
            appendArixKeyValue(arguments, "server_id", "serverId")
            appendArixKeyValue(arguments, "display_name", "displayName")
            appendArixKeyValue(arguments, "url")
            appendArixKeyValue(arguments, "command")
            if (arguments.has("enabled")) append(" enabled=").append(arguments.optBoolean("enabled"))
        }.trim()
        "arix_agent_mode_manage" -> buildString {
            append("arix_agent_mode_manage action=")
            append(action.ifBlank { "inspect_authorization" })
            if (arguments.has("enabled")) append(" enabled=").append(arguments.optBoolean("enabled"))
            appendArixKeyValue(arguments, "method")
        }.trim()
        "arix_developer_manage" -> buildString {
            append("arix_developer_manage action=")
            append(action.ifBlank { "read_diagnostics" })
            appendArixKeyValue(arguments, "include")
            appendArixKeyValue(arguments, "max_chars", "maxChars")
        }.trim()
        else -> toolName
    }
}

private fun summarizeArixCategories(arguments: JSONObject?): String {
    val categories = arguments?.optJSONArray("categories") ?: return ""
    return buildList {
        for (index in 0 until categories.length()) {
            val value = categories.optString(index).trim()
            if (value.isNotBlank()) add(value)
        }
    }.joinToString(",")
}

private fun summarizeArixSettingsPatch(settings: JSONObject?): String {
    if (settings == null) return ""
    val keys = buildList {
        settings.keys().forEach { add(it) }
    }
    return if (keys.isEmpty()) "" else "fields=${keys.joinToString(",")}"
}

private fun optArixString(
    arguments: JSONObject?,
    primary: String,
    secondary: String,
): String = arguments?.optString(primary).orEmpty().ifBlank {
    arguments?.optString(secondary).orEmpty()
}

private fun StringBuilder.appendArixKeyValue(
    arguments: JSONObject,
    primary: String,
    secondary: String = "",
) {
    val value = arguments.optString(primary).ifBlank {
        if (secondary.isBlank()) "" else arguments.optString(secondary)
    }.trim()
    if (value.isNotBlank()) {
        append(' ')
        append(primary)
        append('=')
        append(value.take(96))
        if (value.length > 96) append("...")
    }
}

private fun summarizeAgentDisplayCommand(arguments: JSONObject?): String {
    if (arguments == null) return "agent_mode"
    val action = arguments.optString("action").trim().ifBlank { "unknown" }
    return when (action.lowercase()) {
        "list_apps", "apps", "installed_apps" -> {
            val query = arguments.optString("query").trim()
            "agent_mode list_apps${if (query.isBlank()) "" else " $query"}"
        }
        "launch" -> "agent_mode launch ${arguments.optString("target").trim()}"
        "tap" -> "agent_mode tap x=${arguments.optString("x").trim()} y=${arguments.optString("y").trim()}"
        "swipe" -> "agent_mode swipe ${arguments.optString("x1").trim()},${arguments.optString("y1").trim()} -> ${arguments.optString("x2").trim()},${arguments.optString("y2").trim()} ${arguments.optString("duration_ms").ifBlank { arguments.optString("durationMs") }.trim()}ms"
        "key" -> "agent_mode key ${arguments.optString("key").trim()}"
        "text" -> {
            val text = arguments.optString("text").trim()
            "agent_mode text ${text.take(48)}${if (text.length > 48) "..." else ""}"
        }
        "start", "status", "read_screen", "read", "screen", "stop" -> "agent_mode $action"
        else -> "agent_mode $action"
    }.trim()
}

private fun parseJsonObject(rawValue: String): JSONObject? {
    if (rawValue.isBlank()) return null
    return runCatching { JSONObject(rawValue) }.getOrNull()
}

internal fun highlightBashCommand(command: String): AnnotatedString = buildAnnotatedString {
    appendStyled("$ ", SpanStyle(color = ArixSecondary, fontWeight = FontWeight.SemiBold))

    val tokenPattern = Regex("""\s+|&&|\|\||[|;><()]|"(?:\\.|[^"])*"|'(?:\\.|[^'])*'|\$[A-Za-z_][A-Za-z0-9_]*|--?[A-Za-z0-9][\w-]*|[^\s|;><()]+""")
    var expectsCommand = true

    tokenPattern.findAll(command).forEach { match ->
        val token = match.value
        val style = when {
            token.isBlank() -> null
            token in setOf("|", "||", "&&", ";", ">", "<", "(", ")") -> {
                expectsCommand = true
                SpanStyle(color = ArixOnSurfaceVariant)
            }
            token.startsWith("\"") || token.startsWith("'") -> SpanStyle(color = ArixTertiary)
            token.startsWith("$") -> SpanStyle(color = ArixPrimary)
            token.startsWith("-") -> SpanStyle(color = ArixSecondary)
            token.startsWith("/") || token.startsWith("~/") || token.startsWith("./") || token.startsWith("../") -> SpanStyle(color = ArixSecondary)
            expectsCommand -> {
                expectsCommand = false
                SpanStyle(color = ArixPrimary, fontWeight = FontWeight.SemiBold)
            }
            token.all(Char::isDigit) -> SpanStyle(color = ArixTertiary)
            else -> SpanStyle(color = ArixOnSurface)
        }
        appendStyled(token, style)
    }
}

internal fun highlightToolResult(result: String): AnnotatedString = buildAnnotatedString {
    val tokenPattern = Regex("""\s+|~?/[\w./-]+|\b\d+\b|[A-Za-z_][A-Za-z0-9_]*:|[^\s]+""")

    tokenPattern.findAll(result).forEach { match ->
        val token = match.value
        val lowerToken = token.lowercase()
        val style = when {
            token.isBlank() -> null
            lowerToken.contains("error") ||
                lowerToken.contains("failed") ||
                lowerToken.contains("denied") -> SpanStyle(color = ArixError, fontWeight = FontWeight.Medium)
            lowerToken.startsWith("http://") ||
                lowerToken.startsWith("https://") ||
                token.startsWith("/") ||
                token.startsWith("~/") ||
                token.contains("/") -> SpanStyle(color = ArixSecondary)
            token.all(Char::isDigit) -> SpanStyle(color = ArixTertiary)
            token.endsWith(":") -> SpanStyle(color = ArixOnSurfaceVariant, fontWeight = FontWeight.Medium)
            else -> SpanStyle(color = ArixOnSurface)
        }
        appendStyled(token, style)
    }
}

private fun summarizeMcpProxyCommand(arguments: JSONObject?): String {
    if (arguments == null) return "mcp"
    val tool = arguments.optString("tool").trim()
    if (tool.isNotBlank()) return "mcp call $tool"
    val action = arguments.optString("action").trim()
    val server = arguments.optString("server").trim()
    if (action.isNotBlank()) {
        return if (server.isNotBlank()) "mcp $action $server" else "mcp $action"
    }
    val query = arguments.optString("search").trim()
    if (query.isNotBlank()) return "mcp search $query"
    val describe = arguments.optString("describe").trim()
    if (describe.isNotBlank()) return "mcp describe $describe"
    if (server.isNotBlank()) return "mcp list $server"
    return "mcp"
}

private fun AnnotatedString.Builder.appendStyled(
    text: String,
    style: SpanStyle?,
) {
    if (style == null) {
        append(text)
        return
    }

    pushStyle(style)
    append(text)
    pop()
}

private fun formatAttachmentSize(bytes: Long): String = when {
    bytes >= 1024 * 1024 -> String.format("%.1f MB", bytes / (1024f * 1024f))
    bytes >= 1024 -> String.format("%.1f KB", bytes / 1024f)
    else -> "$bytes B"
}

private data class AttachmentTextPreview(
    val text: String,
    val isTruncated: Boolean,
)

private data class ToolInvocationDetail(
    val command: String,
    val result: String?,
)

private data class WebSourceMetadata(
    val domain: String,
    val url: String,
    val faviconUrl: String?,
)
