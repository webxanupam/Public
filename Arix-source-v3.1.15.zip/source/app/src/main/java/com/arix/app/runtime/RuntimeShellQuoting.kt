package com.arix.app.runtime

internal object RuntimeShellQuoting {

    private val NeedsQuoting = Regex("[\\s'\"\\\\$`&;|<>()!*?]")

    fun shellQuote(value: String): String =
        if (value.contains(NeedsQuoting)) "'${value.replace("'", "'\\''")}'" else value
}
