package com.arix.app.data.acp

import com.arix.app.data.pi.PiKernelBridge
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class ArixAcpClient(
    private val bridge: PiKernelBridge,
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default),
) {

    data class AcpPermissionPrompt(
        val requestId: Any,
        val sessionId: String,
        val toolTitle: String,
        val toolCallId: String,
        val options: List<JSONObject>,
    )

    private val _connectionState = MutableStateFlow("disconnected")
    val connectionState: StateFlow<String> = _connectionState.asStateFlow()

    private val _agentInfo = MutableStateFlow<JSONObject?>(null)
    val agentInfo: StateFlow<JSONObject?> = _agentInfo.asStateFlow()

    private val _updates = MutableStateFlow<List<JSONObject>>(emptyList())
    val updates: StateFlow<List<JSONObject>> = _updates.asStateFlow()

    private val _pendingPermission = MutableStateFlow<AcpPermissionPrompt?>(null)
    val pendingPermission: StateFlow<AcpPermissionPrompt?> = _pendingPermission.asStateFlow()

    private var collecting = false

    fun start() {
        if (collecting) return
        collecting = true
        scope.launch {
            bridge.acpEvents.collect { frame ->
                handleInboundFrame(frame)
            }
        }
    }

    private fun handleInboundFrame(frame: JSONObject) {
        val method = frame.optString("method")
        when (method) {
            "session/update" -> {
                val update = frame.optJSONObject("params") ?: return
                _updates.value = (_updates.value + update).takeLast(500)
            }
            "session/request_permission" -> {
                val params = frame.optJSONObject("params") ?: return
                val options = mutableListOf<JSONObject>()
                val optionsJson = params.optJSONArray("options") ?: JSONArray()
                for (index in 0 until optionsJson.length()) {
                    optionsJson.optJSONObject(index)?.let(options::add)
                }
                val toolCall = params.optJSONObject("toolCall") ?: JSONObject()
                _pendingPermission.value = AcpPermissionPrompt(
                    requestId = frame.opt("id") ?: JSONObject.NULL,
                    sessionId = params.optString("sessionId"),
                    toolTitle = toolCall.optString("title"),
                    toolCallId = toolCall.optString("toolCallId"),
                    options = options,
                )
            }
            else -> Unit
        }
    }

    suspend fun initialize(): JSONObject {
        val result = bridge.acpRequest(
            method = "initialize",
            params = JSONObject()
                .put("protocolVersion", 1)
                .put(
                    "clientInfo",
                    JSONObject().put("name", "Arix").put("version", "2.9.16"),
                )
                .put(
                    "clientCapabilities",
                    JSONObject()
                        .put("terminal", true)
                        .put(
                            "fs",
                            JSONObject().put("readTextFile", true).put("writeTextFile", true),
                        ),
                ),
            timeoutMillis = 90_000,
        )
        _agentInfo.value = result.optJSONObject("result")?.optJSONObject("agentInfo")
        _connectionState.value = "connected"
        start()
        return result
    }

    suspend fun newSession(cwd: String): JSONObject = bridge.acpRequest(
        method = "session/new",
        params = JSONObject().put("cwd", cwd),
    )

    suspend fun restoreSession(sessionId: String): JSONObject = bridge.acpRequest(
        method = "session/load",
        params = JSONObject().put("sessionId", sessionId),
    )

    suspend fun forkSession(sessionId: String): JSONObject = bridge.acpRequest(
        method = "session/fork",
        params = JSONObject().put("sessionId", sessionId),
    )

    suspend fun listSessions(): JSONObject = bridge.acpRequest(
        method = "session/list",
    )

    suspend fun closeSession(sessionId: String): JSONObject = bridge.acpRequest(
        method = "session/close",
        params = JSONObject().put("sessionId", sessionId),
    )

    suspend fun deleteSession(sessionId: String): JSONObject = bridge.acpRequest(
        method = "session/delete",
        params = JSONObject().put("sessionId", sessionId),
    )

    suspend fun prompt(sessionId: String, text: String): JSONObject = bridge.acpRequest(
        method = "session/prompt",
        params = JSONObject()
            .put("sessionId", sessionId)
            .put("prompt", JSONArray().put(JSONObject().put("type", "text").put("text", text))),
        timeoutMillis = 10 * 60_000,
    )

    suspend fun setMode(sessionId: String, mode: String): JSONObject = bridge.acpRequest(
        method = "session/set_mode",
        params = JSONObject()
            .put("sessionId", sessionId)
            .put("mode", mode),
    )

    suspend fun setPermission(sessionId: String, tool: String, allowed: Boolean): JSONObject =
        bridge.acpRequest(
            method = "session/set_permission",
            params = JSONObject()
                .put("sessionId", sessionId)
                .put("tool", tool)
                .put("allowed", allowed),
        )

    suspend fun answerPermission(prompt: AcpPermissionPrompt, optionId: String) {
        runCatching {
            bridge.acpRespond(
                requestId = prompt.requestId,
                result = JSONObject()
                    .put(
                        "outcome",
                        JSONObject()
                            .put("outcome", "selected")
                            .put("optionId", optionId),
                    ),
            )
        }
        _pendingPermission.value = null
    }

    suspend fun readTextFile(path: String, line: Int? = null, limit: Int? = null): JSONObject =
        bridge.acpRequest(
            method = "fs/read_text_file",
            params = JSONObject().apply {
                put("path", path)
                line?.let { put("line", it) }
                limit?.let { put("limit", it) }
            },
        )

    suspend fun writeTextFile(path: String, content: String): JSONObject = bridge.acpRequest(
        method = "fs/write_text_file",
        params = JSONObject()
            .put("path", path)
            .put("content", content),
    )

    suspend fun createTerminal(
        command: String,
        args: List<String> = emptyList(),
        cwd: String? = null,
    ): JSONObject = bridge.acpRequest(
        method = "terminal/create",
        params = JSONObject().apply {
            put("command", command)
            put("args", JSONArray(args))
            cwd?.let { put("cwd", it) }
        },
    )

    suspend fun terminalOutput(terminalId: String): JSONObject = bridge.acpRequest(
        method = "terminal/output",
        params = JSONObject().put("terminalId", terminalId),
    )

    suspend fun terminalWaitForExit(terminalId: String, timeoutMillis: Long = 30_000): JSONObject =
        bridge.acpRequest(
            method = "terminal/wait_for_exit",
            params = JSONObject()
                .put("terminalId", terminalId)
                .put("timeout_ms", timeoutMillis),
            timeoutMillis = timeoutMillis + 10_000,
        )

    suspend fun terminalKill(terminalId: String): JSONObject = bridge.acpRequest(
        method = "terminal/kill",
        params = JSONObject().put("terminalId", terminalId),
    )

    suspend fun terminalRelease(terminalId: String): JSONObject = bridge.acpRequest(
        method = "terminal/release",
        params = JSONObject().put("terminalId", terminalId),
    )
}
