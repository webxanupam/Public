package com.arix.app.mcp

import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom
import java.util.Base64

data class ArixMcpOAuthConfig(
    val clientId: String = "",
    val clientSecret: String = "",
    val authorizationEndpoint: String = "",
    val tokenEndpoint: String = "",
    val registrationEndpoint: String = "",
    val redirectUri: String = ArixMcpOAuth.CustomSchemeRedirect,
    val scope: String = "",
    val resource: String = "",
    val accessToken: String = "",
    val refreshToken: String = "",
    val tokenType: String = "Bearer",
    val expiresAt: Long = 0L,
    val authorizationServer: String = "",
    val tokenEndpointAuthMethods: List<String> = emptyList(),
) {
    val acceptsPublicClients: Boolean
        get() = "none" in tokenEndpointAuthMethods

    fun toJson(): JSONObject = JSONObject().apply {
        put("client_id", clientId)
        put("client_secret", clientSecret)
        put("authorization_endpoint", authorizationEndpoint)
        put("token_endpoint", tokenEndpoint)
        put("registration_endpoint", registrationEndpoint)
        put("redirect_uri", redirectUri)
        put("scope", scope)
        put("resource", resource)
        put("access_token", accessToken)
        put("refresh_token", refreshToken)
        put("token_type", tokenType)
        put("expires_at", expiresAt)
        put("authorization_server", authorizationServer)
        put("token_endpoint_auth_methods", JSONArray(tokenEndpointAuthMethods))
    }

    val hasTokens: Boolean get() = accessToken.isNotBlank()

    companion object {
        fun fromJson(json: JSONObject): ArixMcpOAuthConfig = ArixMcpOAuthConfig(
            clientId = json.optString("client_id"),
            clientSecret = json.optString("client_secret"),
            authorizationEndpoint = json.optString("authorization_endpoint"),
            tokenEndpoint = json.optString("token_endpoint"),
            registrationEndpoint = json.optString("registration_endpoint"),
            redirectUri = json.optString("redirect_uri")
                .takeIf { it.isNotBlank() } ?: ArixMcpOAuth.CustomSchemeRedirect,
            scope = json.optString("scope"),
            resource = json.optString("resource"),
            accessToken = json.optString("access_token"),
            refreshToken = json.optString("refresh_token"),
            tokenType = json.optString("token_type").takeIf { it.isNotBlank() } ?: "Bearer",
            expiresAt = json.optLong("expires_at", 0L),
            authorizationServer = json.optString("authorization_server"),
            tokenEndpointAuthMethods = json.optJSONArray("token_endpoint_auth_methods")
                ?.let { methods ->
                    buildList {
                        for (index in 0 until methods.length()) {
                            methods.optString(index).takeIf { it.isNotBlank() }?.let(::add)
                        }
                    }
                }.orEmpty(),
        )
    }
}

object ArixMcpOAuth {
    const val CustomSchemeRedirect = "arix-mcp://oauth/callback"

    const val LoopbackRedirect = "http://127.0.0.1:33418/callback"

    const val LoopbackLocalhostRedirect = "http://localhost:33418/callback"

    fun isLoopbackRedirect(uri: String): Boolean =
        uri.startsWith("http://127.0.0.1:33418/", ignoreCase = true) ||
            uri.startsWith("http://localhost:33418/", ignoreCase = true)

    val externalRedirect = kotlinx.coroutines.flow.MutableStateFlow<String?>(null)

    fun makePkce(): Pair<String, String> {
        val random = SecureRandom()
        val bytes = ByteArray(32)
        random.nextBytes(bytes)
        val verifier = Base64.getUrlEncoder().withoutPadding().encodeToString(bytes)
        val digest = java.security.MessageDigest.getInstance("SHA-256")
            .digest(verifier.toByteArray(Charsets.US_ASCII))
        val challenge = Base64.getUrlEncoder().withoutPadding().encodeToString(digest)
        return verifier to challenge
    }

    fun makeState(): String {
        val random = SecureRandom()
        val bytes = ByteArray(16)
        random.nextBytes(bytes)
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes)
    }
}
