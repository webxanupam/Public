package com.arix.app.data

object ArixLegacyContextBlockSanitizer {

    private val LegacyMarker = "[Assistant context — captured at summon"
    private val CurrentMarker = "[Background summon context"

    fun strip(text: String): String {
        var working = text.trimStart()
        for (marker in listOf(LegacyMarker, CurrentMarker)) {
            if (working.startsWith(marker)) {
                val firstBreak = working.indexOf("\n\n")
                working = when {
                    firstBreak >= 0 -> working.substring(firstBreak + 2)
                    marker == CurrentMarker -> {
                        val rulesIdx = working.indexOf("\nRules:")
                        if (rulesIdx >= 0) {
                            val rulesEnd = working.indexOf('\n', rulesIdx + 1)
                            if (rulesEnd >= 0 && rulesEnd + 1 < working.length) {
                                working.substring(rulesEnd + 1)
                            } else {
                                ""
                            }
                        } else {
                            working
                        }
                    }
                    else -> ""
                }
                break
            }
        }
        return working.trim()
    }
}
