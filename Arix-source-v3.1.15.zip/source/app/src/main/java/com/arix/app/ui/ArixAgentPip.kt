package com.arix.app.ui

import android.content.Context
import android.graphics.Bitmap
import android.hardware.display.DisplayManager
import android.util.DisplayMetrics
import android.view.Display
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Smartphone
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.arix.app.agent.ArixPipMode
import com.arix.app.agent.ArixPipUi
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.math.hypot
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * The floating small live view over the conversation — ported 1:1 from Mika's
 * AgentPip (Apache-2.0, wangzan101/Mika): shows ONLY the agent background
 * screen's live picture; watch-only, no buttons on the picture (everything the
 * user must do lives in the conversation cards). State speaks through the
 * border glow: thin green while working, breathing orange halo when it needs
 * you. Rests at the bottom-right above the composer by default; drag is 1:1,
 * release flings to the nearest corner with a critically-damped spring; tap
 * expands, tap × or outside collapses; when it needs you a tap hands over to
 * [onAttention]. Expanded shows a close button top-left ("close the live view"
 * — leaves a small button bottom-right until the task ends, breathing orange
 * when it needs you) and a plain × top-right (collapse only).
 */

/** Small-view width: collapsed / expanded. Height follows the frame's aspect. */
private val CollapsedWidth = 96.dp
private val ExpandedWidth = 220.dp
private val Ease = CubicBezierEasing(0.2f, 0.8f, 0.2f, 1f)

/** Mika's exact accent values for the live view (identical look). */
private val PipGreen = Color(0xFF1F9D55)
private val PipGreenDark = Color(0xFF3CCF7A)
private val PipWarnText = Color(0xFFB86E00)
private val PipWarnTextDark = Color(0xFFFFB340)
private val PipWarnSolid = Color(0xFFFF9F0A)

/** Main-screen aspect (real pixels incl. system bars) used before any frame arrives. */
private fun mainScreenAspect(context: Context): Float {
    val m = DisplayMetrics()
    context.getSystemService(DisplayManager::class.java)
        ?.getDisplay(Display.DEFAULT_DISPLAY)?.getRealMetrics(m)
    return if (m.widthPixels > 0 && m.heightPixels > 0) m.heightPixels.toFloat() / m.widthPixels else DEFAULT_ASPECT
}

private const val DEFAULT_ASPECT = 2.2f

@Composable
fun ArixAgentPip(
    pip: ArixPipUi,
    frame: Bitmap?,
    webContent: Boolean,
    reduceMotion: Boolean,
    topInset: Float,
    bottomInset: Float,
    onExpand: () -> Unit,
    onCollapse: () -> Unit,
    onAttention: () -> Unit,
    onClose: () -> Unit = {},
    onReopen: () -> Unit = {},
) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val fade = if (reduceMotion) tween<Float>(150) else tween(300)
        // Closed: only the small button stays (not during the done moments).
        AnimatedVisibility(
            pip.visible && pip.closed && pip.mode != ArixPipMode.Done,
            Modifier.align(Alignment.BottomEnd),
            enter = fadeIn(fade),
            exit = fadeOut(fade),
        ) {
            val bottom = with(LocalDensity.current) { bottomInset.toDp() }
            ClosedPip(
                pip.mode == ArixPipMode.NeedsYou, reduceMotion,
                Modifier.padding(end = 12.dp, bottom = bottom + 12.dp), onReopen, onAttention,
            )
        }
        AnimatedVisibility(
            pip.visible && !pip.closed && pip.expanded,
            enter = fadeIn(fade),
            exit = fadeOut(fade),
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.12f))
                    .pointerInput(Unit) { detectTapGestures { onCollapse() } },
            )
        }
        AnimatedVisibility(
            pip.visible && !pip.closed,
            enter = fadeIn(fade),
            exit = fadeOut(if (reduceMotion) tween(150) else tween(500)),
        ) {
            PipWindow(
                pip, frame, webContent, reduceMotion,
                areaWidth = constraints.maxWidth.toFloat(),
                areaHeight = constraints.maxHeight.toFloat(),
                topInset = topInset, bottomInset = bottomInset,
                onExpand = onExpand, onCollapse = onCollapse, onAttention = onAttention,
                onClose = onClose,
            )
        }
    }
}

/** The little button left after closing: "Show live view", orange breathing "Needs you" when it wants you. */
@Composable
private fun ClosedPip(needsYou: Boolean, reduceMotion: Boolean, modifier: Modifier, onReopen: () -> Unit, onAttention: () -> Unit) {
    val c = MaterialTheme.colorScheme
    val isDark = androidx.compose.foundation.isSystemInDarkTheme()
    val warnText = if (isDark) PipWarnTextDark else PipWarnText
    val shape = RoundedCornerShape(50)
    val breath = if (needsYou && !reduceMotion) {
        rememberInfiniteTransition(label = "closedBreathe").animateFloat(
            1f, 0.45f, infiniteRepeatable(tween(1000), RepeatMode.Reverse), label = "closedBreathe",
        ).value
    } else 1f
    val label = if (needsYou) "Needs you" else "Show live view"
    Row(
        modifier
            .shadow(6.dp, shape)
            .background(c.surface.copy(alpha = 0.94f), shape)
            .border(
                if (needsYou) 2.dp else 0.5.dp,
                if (needsYou) PipWarnSolid.copy(alpha = breath) else c.outline.copy(alpha = 0.4f),
                shape,
            )
            .clip(shape)
            .clickable(onClickLabel = label, role = Role.Button) { if (needsYou) onAttention() else onReopen() }
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .testTag("pip-closed"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        if (needsYou) {
            Box(Modifier.size(7.dp).alpha(breath).background(PipWarnSolid, CircleShape))
        } else {
            Icon(Icons.Rounded.Smartphone, null, Modifier.size(14.dp), tint = c.onSurfaceVariant)
        }
        Text(label, style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp), color = if (needsYou) warnText else c.onSurfaceVariant)
    }
}

/** Corner-snap physics for the small live view (ported 1:1 from Mika's PipPhysics). */
private object PipPhysics {
    enum class Corner { TopStart, TopEnd, BottomStart, BottomEnd }

    data class Bounds(
        val width: Float,
        val height: Float,
        val pipWidth: Float,
        val pipHeight: Float,
        val margin: Float,
        val top: Float,
        val bottom: Float,
    ) {
        fun position(c: Corner): Pair<Float, Float> {
            val left = margin
            val right = maxOf(left, width - pipWidth - margin)
            val upper = top + margin
            val lower = maxOf(upper, height - pipHeight - bottom - margin)
            return when (c) {
                Corner.TopStart -> left to upper
                Corner.TopEnd -> right to upper
                Corner.BottomStart -> left to lower
                Corner.BottomEnd -> right to lower
            }
        }
    }

    private const val DECELERATION = 0.998f

    fun project(velocity: Float): Float = (velocity / 1000f) * DECELERATION / (1f - DECELERATION)

    fun snapCorner(x: Float, y: Float, vx: Float, vy: Float, bounds: Bounds): Corner {
        val px = x + project(vx)
        val py = y + project(vy)
        return Corner.entries.minBy { c ->
            val (cx, cy) = bounds.position(c)
            hypot(cx - px, cy - py)
        }
    }

    data class Motion(val position: Float, val velocity: Float)

    class Spring(response: Float = 0.4f, dampingRatio: Float = 1f) {
        private val stiffness = (2 * Math.PI / response).pow(2).toFloat()
        private val damping = (4 * Math.PI * dampingRatio / response).toFloat()

        fun step(m: Motion, target: Float, dt: Float): Motion {
            val t = dt.coerceIn(0f, MAX_DT)
            val v = m.velocity + (-stiffness * (m.position - target) - damping * m.velocity) * t
            return Motion(m.position + v * t, v)
        }

        fun settled(m: Motion, target: Float) =
            kotlin.math.abs(m.position - target) < REST_DISTANCE && kotlin.math.abs(m.velocity) < REST_VELOCITY
    }

    private const val MAX_DT = 0.032f
    private const val REST_DISTANCE = 0.5f
    private const val REST_VELOCITY = 5f
}

@Composable
private fun PipWindow(
    pip: ArixPipUi,
    frame: Bitmap?,
    webContent: Boolean,
    reduceMotion: Boolean,
    areaWidth: Float,
    areaHeight: Float,
    topInset: Float,
    bottomInset: Float,
    onExpand: () -> Unit,
    onCollapse: () -> Unit,
    onAttention: () -> Unit,
    onClose: () -> Unit,
) {
    val density = LocalDensity.current
    val sizeSpec = if (reduceMotion) snap() else tween<androidx.compose.ui.unit.Dp>(350, easing = Ease)
    val c = MaterialTheme.colorScheme
    val isDark = androidx.compose.foundation.isSystemInDarkTheme()
    val runningGlow = if (isDark) PipGreenDark else PipGreen
    val warnText = if (isDark) PipWarnTextDark else PipWarnText
    val context = LocalContext.current
    val screenAspect = remember { mainScreenAspect(context) }
    val landscapeWeb = frame != null && webContent && frame.width > frame.height
    val aspect = frame?.let { it.height.toFloat() / it.width } ?: screenAspect
    val target = run {
        val margin = with(density) { 24.dp.toPx() }
        val availableWidth = with(density) { (areaWidth - margin).coerceAtLeast(1f).toDp() }
        val availableHeight = with(density) { (areaHeight - topInset - bottomInset - margin).coerceAtLeast(1f).toDp() }
        val base = when {
            landscapeWeb -> if (pip.expanded) 320.dp else 220.dp
            else -> if (pip.expanded) ExpandedWidth else CollapsedWidth
        }
        val width = minOf(base, availableWidth, availableHeight / aspect)
        width to width * aspect
    }
    val w by animateDpAsState(target.first, sizeSpec, label = "pipW")
    val h by animateDpAsState(target.second, sizeSpec, label = "pipH")
    val wPx = with(density) { w.toPx() }
    val hPx = with(density) { h.toPx() }
    val bounds = PipPhysics.Bounds(areaWidth, areaHeight, wPx, hPx, with(density) { 12.dp.toPx() }, topInset, bottomInset)
    val currentBounds by rememberUpdatedState(bounds)
    val motionOff by rememberUpdatedState(reduceMotion)
    val expanded by rememberUpdatedState(pip.expanded)
    val expand by rememberUpdatedState(onExpand)
    val needsYou by rememberUpdatedState(pip.mode == ArixPipMode.NeedsYou)
    val attend by rememberUpdatedState(onAttention)

    var corner by rememberSaveable { mutableStateOf(PipPhysics.Corner.BottomEnd) }
    var free by remember { mutableStateOf<Offset?>(null) }
    val scope = rememberCoroutineScope()
    var settle by remember { mutableStateOf<Job?>(null) }

    fun springTo(cornerTo: PipPhysics.Corner, start: Offset, vx: Float, vy: Float) {
        settle?.cancel()
        corner = cornerTo
        if (motionOff) {
            free = null
            return
        }
        settle = scope.launch {
            val spring = PipPhysics.Spring()
            var mx = PipPhysics.Motion(start.x, vx)
            var my = PipPhysics.Motion(start.y, vy)
            var last = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                val dt = (now - last) / 1e9f
                last = now
                val (tx, ty) = currentBounds.position(corner)
                mx = spring.step(mx, tx, dt)
                my = spring.step(my, ty, dt)
                free = Offset(mx.position, my.position)
                if (spring.settled(mx, tx) && spring.settled(my, ty)) break
            }
            free = null
        }
    }

    fun release(vx: Float, vy: Float) {
        val start = free ?: return
        springTo(PipPhysics.snapCorner(start.x, start.y, vx, vy, currentBounds), start, vx, vy)
    }

    // On done, move out of the bottom corners so the result card below is not covered.
    LaunchedEffect(pip.mode) {
        if (pip.mode != ArixPipMode.Done) return@LaunchedEffect
        val up = when (corner) {
            PipPhysics.Corner.BottomStart -> PipPhysics.Corner.TopStart
            PipPhysics.Corner.BottomEnd -> PipPhysics.Corner.TopEnd
            else -> return@LaunchedEffect
        }
        springTo(up, free ?: currentBounds.position(corner).let { (x, y) -> Offset(x, y) }, 0f, 0f)
    }

    val pos = free ?: bounds.position(corner).let { (x, y) -> Offset(x, y) }
    val outer = RoundedCornerShape(if (pip.expanded) 26.dp else 16.dp)
    val inner = RoundedCornerShape(if (pip.expanded) 22.dp else 13.dp)
    val breath = if (pip.mode == ArixPipMode.NeedsYou && !reduceMotion) {
        rememberInfiniteTransition(label = "breathe").animateFloat(
            1f, 0.55f, infiniteRepeatable(tween(1000), RepeatMode.Reverse), label = "breathe",
        ).value
    } else 1f

    Box(Modifier.offset { IntOffset(pos.x.roundToInt(), pos.y.roundToInt()) }) {
        if (pip.mode == ArixPipMode.NeedsYou) {
            // Orange halo: bigger than the window, blurred at the edge.
            Box(
                Modifier
                    .offset((-5).dp, (-5).dp)
                    .size(w + 10.dp, h + 10.dp)
                    .alpha(breath)
                    .blur(10.dp)
                    .background(PipWarnSolid.copy(alpha = 0.55f), outer),
            )
        }
        Box(
            Modifier
                .size(w, h)
                .alpha(if (pip.mode == ArixPipMode.Done) 0.85f else 1f)
                .shadow(8.dp, outer)
                .background(c.surface.copy(alpha = 0.96f), outer)
                .border(0.5.dp, c.outline.copy(alpha = 0.35f), outer)
                .pointerInput(Unit) {
                    val tracker = VelocityTracker()
                    // Count displacement manually instead of detectDragGestures: past
                    // the touch slop the pre-slop distance is replayed, so the window
                    // keeps the exact grab point — truly 1:1 with the finger.
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val origin = free ?: currentBounds.position(corner).let { (x, y) -> Offset(x, y) }
                        var total = Offset.Zero
                        var dragging = false
                        tracker.resetTracking()
                        tracker.addPosition(down.uptimeMillis, origin + down.position)
                        while (true) {
                            val change = awaitPointerEvent().changes.firstOrNull { it.id == down.id } ?: break
                            if (!change.pressed) break
                            total += change.positionChange()
                            if (!dragging && total.getDistance() > viewConfiguration.touchSlop) {
                                dragging = true
                                settle?.cancel()
                            }
                            if (dragging) {
                                change.consume()
                                free = origin + total
                                tracker.addPosition(change.uptimeMillis, origin + down.position + total)
                            }
                        }
                        if (dragging) tracker.calculateVelocity().let { v -> release(v.x, v.y) }
                    }
                }
                .pointerInput(Unit) { detectTapGestures { if (needsYou) attend() else if (!expanded) expand() } }
                .padding(if (pip.expanded) 4.dp else 3.dp),
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .clip(inner)
                    .background(c.surface),
            ) {
                if (frame != null) {
                    val image = remember(frame) { frame.asImageBitmap() }
                    Image(
                        image, "Agent screen",
                        Modifier.fillMaxSize(),
                        alignment = Alignment.TopCenter,
                        contentScale = if (webContent) ContentScale.Fit else ContentScale.Crop,
                    )
                }
            }
            if (pip.expanded) {
                // Top-left: close this task's live view (small button stays). Top-right × collapses only.
                Box(
                    Modifier
                        .align(Alignment.TopStart)
                        .padding(6.dp)
                        .size(26.dp)
                        .shadow(4.dp, CircleShape)
                        .background(c.surface, CircleShape)
                        .clip(CircleShape)
                        .clickable(onClickLabel = "Close the live view", onClick = onClose)
                        .testTag("pip-close"),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.VisibilityOff, "Close the live view", Modifier.size(13.dp), tint = c.onSurface) }
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp)
                        .size(26.dp)
                        .shadow(4.dp, CircleShape)
                        .background(c.surface, CircleShape)
                        .clip(CircleShape)
                        .clickable(onClickLabel = "Collapse", onClick = onCollapse),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.Close, "Collapse", Modifier.size(12.dp), tint = c.onSurface) }
            }
        }
        // The border glow rides the outer edge of the glass frame.
        val glow = when (pip.mode) {
            ArixPipMode.Running -> runningGlow to 2.dp
            ArixPipMode.NeedsYou -> PipWarnSolid.copy(alpha = breath) to 2.dp
            ArixPipMode.Done -> null
        }
        if (glow != null) Box(Modifier.size(w, h).border(glow.second, glow.first, outer))
    }
}
