package com.arix.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.arix.app.ui.theme.ArixError
import com.arix.app.ui.theme.ArixOnPrimary
import com.arix.app.ui.theme.ArixOnSurface
import com.arix.app.ui.theme.ArixOnSurfaceVariant
import com.arix.app.ui.theme.ArixOutline
import com.arix.app.ui.theme.ArixPrimary
import com.arix.app.ui.theme.ArixSurface
import com.arix.app.ui.theme.ArixSurfaceHigher
import com.arix.app.ui.theme.ArixSurfaceVariant
import com.arix.app.ui.theme.ArixTertiary

@Composable
fun TerminalQuickCommandsSheet(
    commands: List<TerminalQuickCommand>,
    onLaunchCommand: (TerminalQuickCommand) -> Unit,
    onAddCommand: (String) -> Boolean,
    onDeleteCommand: (TerminalQuickCommand) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var input by rememberSaveable { mutableStateOf("") }
    var justAddedPulse by remember { mutableStateOf(false) }
    val focusRequester = remember { FocusRequester() }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .imePadding()
            .animateContentSize(),
        shape = RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp),
        color = ArixSurface,
        tonalElevation = 2.dp,
        shadowElevation = 16.dp,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 10.dp),
        ) {
            Box(
                modifier = Modifier
                    .width(44.dp)
                    .height(5.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(ArixOutline.copy(alpha = 0.55f))
                    .align(Alignment.CenterHorizontally),
            )
            Spacer(Modifier.height(14.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    ArixPrimary.copy(alpha = 0.30f),
                                    ArixTertiary.copy(alpha = 0.22f),
                                ),
                            ),
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Bolt,
                        contentDescription = null,
                        tint = ArixPrimary,
                        modifier = Modifier.size(22.dp),
                    )
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(
                        text = "Quick commands",
                        style = MaterialTheme.typography.titleMedium,
                        color = ArixOnSurface,
                    )
                    Text(
                        text = "Tap to launch · insert once · swipe-free",
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            Spacer(Modifier.height(16.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier
                        .weight(1f)
                        .focusRequester(focusRequester),
                    placeholder = {
                        Text(
                            text = "Insert a command to save…",
                            fontFamily = FontFamily.Monospace,
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    },
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyMedium.copy(
                        fontFamily = FontFamily.Monospace,
                    ),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            if (onAddCommand(input)) {
                                input = ""
                                justAddedPulse = true
                            }
                        },
                    ),
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ArixPrimary.copy(alpha = 0.8f),
                        unfocusedBorderColor = ArixOutline.copy(alpha = 0.6f),
                        focusedContainerColor = ArixSurfaceHigher.copy(alpha = 0.6f),
                        unfocusedContainerColor = ArixSurfaceHigher.copy(alpha = 0.4f),
                        cursorColor = ArixPrimary,
                        focusedTextColor = ArixOnSurface,
                        unfocusedTextColor = ArixOnSurface,
                    ),
                )
                Spacer(Modifier.width(10.dp))
                QuickCommandAddButton(
                    enabled = input.isNotBlank(),
                    onClick = {
                        if (onAddCommand(input)) {
                            input = ""
                            justAddedPulse = true
                        }
                    },
                )
            }
            Spacer(Modifier.height(14.dp))

            if (commands.isEmpty()) {
                QuickCommandsEmptyHint()
            } else {
                Text(
                    text = "Saved commands · ${commands.size}",
                    style = MaterialTheme.typography.labelMedium,
                    color = ArixOnSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
                )
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(240.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(
                        start = 20.dp,
                        end = 20.dp,
                        bottom = 18.dp,
                    ),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(commands, key = { it.id }) { command ->
                        QuickCommandRow(
                            command = command,
                            onLaunch = { onLaunchCommand(command) },
                            onDelete = { onDeleteCommand(command) },
                        )
                    }
                }
            }

            AnimatedVisibility(
                visible = justAddedPulse,
                enter = fadeIn(),
                exit = fadeOut() + shrinkVertically(),
            ) {
                Text(
                    text = "Saved to your list",
                    style = MaterialTheme.typography.labelMedium,
                    color = ArixPrimary,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
                )
                LaunchedEffect(justAddedPulse) {
                    if (justAddedPulse) {
                        kotlinx.coroutines.delay(1400)
                        justAddedPulse = false
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
        }
    }
}

@Composable
private fun QuickCommandAddButton(
    enabled: Boolean,
    onClick: () -> Unit,
) {
    val alpha by animateFloatAsState(
        targetValue = if (enabled) 1f else 0.45f,
        animationSpec = tween(160),
        label = "quick_command_add_alpha",
    )
    Box(
        modifier = Modifier
            .size(52.dp)
            .graphicsLayer { this.alpha = alpha }
            .clip(CircleShape)
            .background(
                Brush.linearGradient(
                    listOf(
                        ArixPrimary,
                        ArixTertiary.copy(alpha = 0.85f),
                    ),
                ),
            )
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = Icons.Rounded.Add,
            contentDescription = "Save command",
            tint = ArixOnPrimary,
            modifier = Modifier.size(24.dp),
        )
    }
}

@Composable
private fun QuickCommandRow(
    command: TerminalQuickCommand,
    onLaunch: () -> Unit,
    onDelete: () -> Unit,
) {
    var pendingDelete by remember(command.id) { mutableStateOf(false) }
    if (pendingDelete) {
        LaunchedEffect(command.id) {
            kotlinx.coroutines.delay(2600)
            pendingDelete = false
        }
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(
                Brush.horizontalGradient(
                    listOf(
                        ArixSurfaceHigher.copy(alpha = 0.95f),
                        ArixSurfaceVariant.copy(alpha = 0.55f),
                    ),
                ),
            )
            .clickable(onClick = onLaunch)
            .padding(start = 12.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector = Icons.Rounded.Terminal,
            contentDescription = null,
            tint = ArixPrimary.copy(alpha = 0.85f),
            modifier = Modifier.size(18.dp),
        )
        Spacer(Modifier.width(10.dp))
        Text(
            text = command.command,
            fontFamily = FontFamily.Monospace,
            fontSize = 13.5.sp,
            lineHeight = 19.sp,
            color = ArixOnSurface,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
        Spacer(Modifier.width(6.dp))
        Icon(
            imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
            contentDescription = null,
            tint = ArixOnSurfaceVariant.copy(alpha = 0.7f),
            modifier = Modifier.size(18.dp),
        )
        Spacer(Modifier.width(2.dp))
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .clickable {
                    if (pendingDelete) {
                        onDelete()
                    } else {
                        pendingDelete = true
                    }
                },
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = Icons.Rounded.Delete,
                contentDescription = if (pendingDelete) "Confirm delete" else "Delete command",
                tint = if (pendingDelete) ArixError else ArixOnSurfaceVariant.copy(alpha = 0.75f),
                modifier = Modifier.size(19.dp),
            )
        }
    }
}

@Composable
private fun QuickCommandsEmptyHint() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(
            imageVector = Icons.Rounded.Terminal,
            contentDescription = null,
            tint = ArixOnSurfaceVariant.copy(alpha = 0.6f),
            modifier = Modifier.size(34.dp),
        )
        Spacer(Modifier.height(10.dp))
        Text(
            text = "No saved commands yet",
            style = MaterialTheme.typography.titleSmall,
            color = ArixOnSurface,
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = "Type a command once above — it is stored here.\n" +
                "Next time, just tap it to launch instantly.",
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
    }
}
