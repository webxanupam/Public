package com.arix.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import java.util.UUID
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.arixPersonasDataStore by preferencesDataStore(name = "arix_personas")

class ArixPersonaRepository(
    private val context: Context,
) {

    enum class MemoryScope(val storageValue: String) {
        Global("global"),
        Project("project"),
        ;
        companion object {
            fun fromStorage(value: String?): MemoryScope =
                entries.firstOrNull { it.storageValue == value } ?: Global
        }
    }

    data class ArixPersona(
        val id: String = UUID.randomUUID().toString().substring(0, 12),
        val name: String,
        val description: String = "",
        val instructions: String = "",
        val allowedTools: List<String> = emptyList(),
        val skillNames: List<String> = emptyList(),
        val memoryScope: MemoryScope = MemoryScope.Global,
        val preferredModelKey: String = "",
        val allowBrowser: Boolean = true,
        val allowFiles: Boolean = true,
        val allowNetwork: Boolean = true,
        val isBuiltIn: Boolean = false,
        val createdAtMillis: Long = System.currentTimeMillis(),
        val updatedAtMillis: Long = createdAtMillis,
    )

    val personas: Flow<List<ArixPersona>> = context.arixPersonasDataStore.data.map { preferences ->
        parsePersonas(preferences[PersonasJsonKey] ?: "[]").ifEmpty { defaultPersonas() }
    }

    suspend fun snapshot(): List<ArixPersona> = personas.first()

    suspend fun find(personaId: String): ArixPersona? = snapshot().firstOrNull { it.id == personaId }

    suspend fun upsert(persona: ArixPersona): ArixPersona {
        context.arixPersonasDataStore.edit { preferences ->
            val current = parsePersonas(preferences[PersonasJsonKey] ?: "[]").toMutableList()
            val saved = persona.copy(updatedAtMillis = System.currentTimeMillis())
            val index = current.indexOfFirst { it.id == persona.id }
            if (index >= 0) current[index] = saved else current.add(saved)
            preferences[PersonasJsonKey] = serializePersonas(current)
        }
        return persona
    }

    suspend fun delete(personaId: String): Boolean {
        var deleted = false
        context.arixPersonasDataStore.edit { preferences ->
            val current = parsePersonas(preferences[PersonasJsonKey] ?: "[]")
            val remaining = current.filterNot { it.id == personaId }
            deleted = remaining.size != current.size
            preferences[PersonasJsonKey] = serializePersonas(remaining)
        }
        return deleted
    }

    fun effectiveToolFilter(persona: ArixPersona): Set<String>? {
        if (persona.allowedTools.isEmpty()) return null
        return persona.allowedTools
            .filter { tool ->
                when {
                    !persona.allowBrowser && tool == "browser" -> false
                    !persona.allowNetwork && tool in setOf("web_search", "fetch_url") -> false
                    else -> true
                }
            }
            .toSet()
    }

    fun promptBlock(persona: ArixPersona): String {
        val description = persona.description.trim()
        val instructions = persona.instructions.trim()
        if (description.isEmpty() && instructions.isEmpty()) return ""
        return buildString {
            append("<agent_persona name=\"")
            append(persona.name.replace('\"', '\''))
            append("\">\n")
            if (description.isNotEmpty()) {
                append(description)
                append('\n')
            }
            if (instructions.isNotEmpty()) {
                append(instructions)
                append('\n')
            }
            append("</agent_persona>")
        }
    }

    private fun defaultPersonas(): List<ArixPersona> = listOf(
        ArixPersona(
            id = "persona-research",
            name = "Research Agent",
            description = "Deep multi-source research with citations.",
            instructions = "Investigate thoroughly across at least three independent sources. " +
                "Rank source credibility, cross-check claims, and always cite URLs. Prefer " +
                "web_search + fetch_url over interactive browsing when reading suffices.",
            allowedTools = listOf(
                "web_search", "fetch_url", "browser", "arix_memory", "arix_tasks",
                "arix_swarm", "read", "bash",
            ),
            isBuiltIn = true,
        ),
        ArixPersona(
            id = "persona-coding",
            name = "Coding Agent",
            description = "Software development in the Termux workspace.",
            instructions = "Write, run and test code in the workspace. Use bash for execution, " +
                "read/write/edit for files, and verify every change compiles or runs before " +
                "claiming success.",
            allowedTools = listOf(
                "bash", "read", "write", "edit", "grep", "find", "ls",
                "arix_memory", "arix_tasks", "web_search", "fetch_url",
            ),
            isBuiltIn = true,
        ),
        ArixPersona(
            id = "persona-writing",
            name = "Writing Agent",
            description = "Long-form writing, editing and documents.",
            instructions = "Produce well-structured prose with clear hierarchy. Draft, then " +
                "tighten. Save deliverables as Markdown files in the workspace when the user " +
                "asks for a document.",
            allowedTools = listOf("read", "write", "edit", "arix_memory", "arix_tasks", "web_search", "fetch_url"),
            isBuiltIn = true,
        ),
        ArixPersona(
            id = "persona-automation",
            name = "Automation Agent",
            description = "Builds and maintains scheduled automations.",
            instructions = "Design reliable automations: idempotent triggers, bounded retries, " +
                "verification of each step. Prefer arix_scheduled_task_manage for persistence " +
                "and arix_swarm for parallel multi-step runs.",
            allowedTools = listOf(
                "arix_scheduled_task_manage", "arix_swarm", "arix_memory", "arix_tasks",
                "web_search", "fetch_url", "read", "write", "bash",
            ),
            isBuiltIn = true,
        ),
    )

    private fun ArixPersona.toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("description", description)
        put("instructions", instructions)
        put("allowedTools", JSONArray(allowedTools))
        put("skillNames", JSONArray(skillNames))
        put("memoryScope", memoryScope.storageValue)
        put("preferredModelKey", preferredModelKey)
        put("allowBrowser", allowBrowser)
        put("allowFiles", allowFiles)
        put("allowNetwork", allowNetwork)
        put("isBuiltIn", isBuiltIn)
        put("createdAtMillis", createdAtMillis)
        put("updatedAtMillis", updatedAtMillis)
    }

    private fun serializePersonas(personas: List<ArixPersona>): String = JSONArray()
        .apply { personas.forEach { put(it.toJson()) } }
        .toString()

    private fun parsePersonas(rawValue: String): List<ArixPersona> {
        if (rawValue.isBlank()) return emptyList()
        return runCatching {
            val array = JSONArray(rawValue)
            buildList {
                for (index in 0 until array.length()) {
                    val json = array.optJSONObject(index) ?: continue
                    val id = json.optString("id").trim()
                    val name = json.optString("name").trim()
                    if (id.isEmpty() || name.isEmpty()) continue
                    add(
                        ArixPersona(
                            id = id,
                            name = name,
                            description = json.optString("description"),
                            instructions = json.optString("instructions"),
                            allowedTools = json.optJSONArray("allowedTools")?.let { tools ->
                                buildList {
                                    for (i in 0 until tools.length()) add(tools.optString(i))
                                }
                            }.orEmpty(),
                            skillNames = json.optJSONArray("skillNames")?.let { skills ->
                                buildList {
                                    for (i in 0 until skills.length()) add(skills.optString(i))
                                }
                            }.orEmpty(),
                            memoryScope = MemoryScope.fromStorage(json.optString("memoryScope")),
                            preferredModelKey = json.optString("preferredModelKey"),
                            allowBrowser = json.optBoolean("allowBrowser", true),
                            allowFiles = json.optBoolean("allowFiles", true),
                            allowNetwork = json.optBoolean("allowNetwork", true),
                            isBuiltIn = json.optBoolean("isBuiltIn", false),
                            createdAtMillis = json.optLong("createdAtMillis"),
                            updatedAtMillis = json.optLong("updatedAtMillis"),
                        ),
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    private companion object {
        val PersonasJsonKey = stringPreferencesKey("personas_json")
    }
}
