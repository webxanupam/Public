package com.arix.app.ui

internal fun parseNonBlankLines(rawValue: String): List<String> =
    rawValue.lineSequence()
        .map(String::trim)
        .filter(String::isNotBlank)
        .toList()
