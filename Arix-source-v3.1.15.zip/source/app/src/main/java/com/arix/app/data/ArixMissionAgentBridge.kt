package com.arix.app.data

import com.arix.app.data.pi.PiAgentRunner
import com.arix.app.data.pi.PiCompletionClient
import com.arix.app.mission.ArixMissionEngine
import com.arix.app.mission.ArixMission
import com.arix.app.mission.MissionTask
import com.arix.app.runtime.RuntimeRouter
import kotlinx.coroutines.flow.first
import org.json.JSONObject

class ArixMissionAgentBridge(
    private val settingsRepository: SettingsRepository,
    private val runtimeRouter: RuntimeRouter,
    private val runner: PiAgentRunner,
    private val toolExecutor: ArixToolExecutor,
    private val completionClient: PiCompletionClient,
    private val diagnosticLogger: ArixDiagnosticLogger = ArixDiagnosticLogger.NoOp,
) : ArixMissionEngine.MissionTaskExecutor {

    override suspend fun execute(task: MissionTask, resolvedTool: String, mission: ArixMission): String {
        val startedAt = System.currentTimeMillis()
        val result = runCatching {
            if (task.instruction.trim().startsWith("{") && resolvedTool != "agent_turn") {
                executeHostToolDirect(task, resolvedTool, mission)
            } else {
                executeAgentTurn(task, resolvedTool, mission)
            }
        }.getOrElse { throwable ->
            diagnosticLogger.exception(
                category = "mission",
                event = "step_execution_failed",
                throwable = throwable,
                details = mapOf("task_id" to task.taskId, "tool" to resolvedTool),
            )
            JSONObject()
                .put("ok", false)
                .put("error_code", "EXECUTION_FAILED")
                .put("message", throwable.message ?: "Step execution failed.")
                .toString()
        }
        diagnosticLogger.event(
            category = "mission",
            event = "step_executed",
            details = mapOf(
                "task_id" to task.taskId,
                "tool" to resolvedTool,
                "latency_ms" to (System.currentTimeMillis() - startedAt),
                "ok" to runCatching { JSONObject(result).optBoolean("ok", false) }.getOrDefault(false),
            ),
        )
        return result
    }

    private suspend fun executeAgentTurn(task: MissionTask, resolvedTool: String, mission: ArixMission): String {
        val settings = settingsRepository.settings.first()
        val providerConfigs = settingsRepository.providerConfigs.first()
        val resolved = resolveModelSettings(
            baseSettings = settings,
            providerConfigs = providerConfigs,
            preferredModelKey = settings.defaultChatModelKey,
            fallbackModelKey = settings.defaultChatModelKey,
        )
        val workspaceDirectory = runtimeRouter.runtimeWorkspaceDirectory(settings = resolved)
        val prompt = buildString {
            append("MISSION STEP: ")
            append(task.description)
            append("\n\n")
            append(task.instruction.trim())
            append("\n\nMISSION OBJECTIVE (context): ")
            append(mission.objective)
            append(
                "\n\nExecute this ONE step with the tools available" +
                    (if (resolvedTool != "agent_turn") " (prefer the $resolvedTool tool)" else "") +
                    ". Work autonomously and VERIFY your own work before finishing.\n" +
                    "FINAL REPLY FORMAT — reply with ONLY a JSON object:\n" +
                    "{\"ok\": true|false, \"result\": {\"summary\": \"concise factual result\"" +
                    ", \"path\": \"artifact path when a file was created/modified\"}, " +
                    "\"message\": \"error description when ok=false\"}",
            )
        }
        val messages = listOf(LlmMessage(role = "user", contentParts = listOf(LlmTextPart(prompt))))
        val result = runner.runTurn(
            settings = resolved,
            messages = messages,
            workspaceDirectory = workspaceDirectory,
            sessionId = "${mission.missionId}-${task.taskId}",
            sessionFile = "",
            allowSwarmTool = false,
        )
        val text = result.getOrNull()?.assistantText?.trim().orEmpty()
        if (result.isFailure || text.isBlank()) {
            return JSONObject()
                .put("ok", false)
                .put("error_code", "EXECUTION_FAILED")
                .put(
                    "message",
                    result.exceptionOrNull()?.message?.take(300)
                        ?: "The agent turn produced no output.",
                )
                .toString()
        }
        val parsed = runCatching {
            val cleaned = text.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            JSONObject(cleaned)
        }.getOrNull()
        return if (parsed != null && parsed.has("ok")) {
            parsed.toString()
        } else {
            JSONObject()
                .put("ok", true)
                .put("result", JSONObject().put("summary", text.take(4_000)))
                .toString()
        }
    }

    private suspend fun executeHostToolDirect(task: MissionTask, resolvedTool: String, mission: ArixMission): String {
        if (!ArixToolExecutor.supports(resolvedTool)) {
            return JSONObject()
                .put("ok", false)
                .put("error_code", "TOOL_UNAVAILABLE")
                .put("message", "Tool '$resolvedTool' is not a host tool.")
                .toString()
        }
        val settings = settingsRepository.settings.first()
        val workspaceDirectory = runtimeRouter.runtimeWorkspaceDirectory(settings = settings)
        return toolExecutor.execute(
            settings = settings,
            workspaceDirectory = workspaceDirectory,
            toolName = resolvedTool,
            argumentsJson = task.instruction.trim(),
            sessionId = "${mission.missionId}-${task.taskId}",
        ).rawOutput
    }

    companion object {
        internal const val Tag = "ArixMissionAgentBridge"
    }

    class Completer(
        private val completionClient: PiCompletionClient,
        private val settingsRepository: SettingsRepository,
    ) : ArixMissionEngine.MissionModelCompleter {
        override suspend fun complete(prompt: String): String? {
            val settings = settingsRepository.settings.first()
            val result = runCatching {
                completionClient.completeOnce(
                    settings = settings,
                    systemPrompt = "You are the Arix mission engine. Follow the requested output format exactly.",
                    messages = listOf(LlmMessage(role = "user", contentParts = listOf(LlmTextPart(prompt)))),
                    disableReasoning = true,
                )
            }.getOrNull() ?: return null
            return result.getOrNull()?.assistantText?.trim()?.takeIf { it.isNotBlank() }
        }
    }
}
