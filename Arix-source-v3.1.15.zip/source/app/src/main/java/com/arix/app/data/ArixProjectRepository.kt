package com.arix.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import java.util.UUID
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.arixProjectsDataStore by preferencesDataStore(name = "arix_projects")

class ArixProjectRepository(
    private val context: Context,
) {

    data class ArixProject(
        val id: String = UUID.randomUUID().toString().substring(0, 12),
        val name: String,
        val description: String = "",
        val colorSeed: Int = 0,
        val createdAtMillis: Long = System.currentTimeMillis(),
        val updatedAtMillis: Long = createdAtMillis,
        val linkedSessionIds: List<String> = emptyList(),
        val personaIds: List<String> = emptyList(),
        val isArchived: Boolean = false,
        val cachedMemoryCount: Int = 0,
        val cachedMissionCount: Int = 0,
        val cachedAutomationCount: Int = 0,
    )

    val projects: Flow<List<ArixProject>> = context.arixProjectsDataStore.data.map { preferences ->
        parseProjects(preferences[ProjectsJsonKey] ?: "[]")
    }

    suspend fun snapshot(): List<ArixProject> = projects.first()

    suspend fun create(name: String, description: String = ""): ArixProject {
        val trimmed = name.trim()
        require(trimmed.isNotEmpty()) { "Project name must not be empty." }
        val existing = snapshot()
        require(existing.none { it.name.equals(trimmed, ignoreCase = true) }) {
            "A project named '$trimmed' already exists."
        }
        val project = ArixProject(
            name = trimmed,
            description = description.trim(),
            colorSeed = trimmed.hashCode(),
        )
        upsert(project)
        return project
    }

    suspend fun upsert(project: ArixProject) {
        context.arixProjectsDataStore.edit { preferences ->
            val current = parseProjects(preferences[ProjectsJsonKey] ?: "[]").toMutableList()
            val index = current.indexOfFirst { it.id == project.id }
            val saved = project.copy(updatedAtMillis = System.currentTimeMillis())
            if (index >= 0) current[index] = saved else current.add(saved)
            preferences[ProjectsJsonKey] = serializeProjects(current)
        }
    }

    suspend fun update(
        projectId: String,
        transform: (ArixProject) -> ArixProject,
    ): ArixProject? {
        var updatedProject: ArixProject? = null
        context.arixProjectsDataStore.edit { preferences ->
            val current = parseProjects(preferences[ProjectsJsonKey] ?: "[]")
            val updated = current.map { project ->
                if (project.id == projectId) {
                    transform(project).also { updatedProject = it }
                } else {
                    project
                }
            }
            preferences[ProjectsJsonKey] = serializeProjects(updated)
        }
        return updatedProject
    }

    suspend fun delete(projectId: String): Boolean {
        var deleted = false
        context.arixProjectsDataStore.edit { preferences ->
            val current = parseProjects(preferences[ProjectsJsonKey] ?: "[]")
            val remaining = current.filterNot { it.id == projectId }
            deleted = remaining.size != current.size
            preferences[ProjectsJsonKey] = serializeProjects(remaining)
        }
        return deleted
    }

    suspend fun find(projectId: String): ArixProject? =
        snapshot().firstOrNull { it.id == projectId }

    suspend fun findByName(name: String): ArixProject? =
        snapshot().firstOrNull { it.name.equals(name.trim(), ignoreCase = true) }

    private fun ArixProject.toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("description", description)
        put("colorSeed", colorSeed)
        put("createdAtMillis", createdAtMillis)
        put("updatedAtMillis", updatedAtMillis)
        put("linkedSessionIds", JSONArray(linkedSessionIds))
        put("personaIds", JSONArray(personaIds))
        put("isArchived", isArchived)
        put("cachedMemoryCount", cachedMemoryCount)
        put("cachedMissionCount", cachedMissionCount)
        put("cachedAutomationCount", cachedAutomationCount)
    }

    private fun serializeProjects(projects: List<ArixProject>): String = JSONArray()
        .apply { projects.forEach { put(it.toJson()) } }
        .toString()

    private fun parseProjects(rawValue: String): List<ArixProject> {
        if (rawValue.isBlank()) return emptyList()
        return runCatching {
            val array = JSONArray(rawValue)
            buildList {
                for (index in 0 until array.length()) {
                    val json = array.optJSONObject(index) ?: continue
                    val id = json.optString("id").trim()
                    val name = json.optString("name").trim()
                    if (id.isEmpty() || name.isEmpty()) continue
                    add(
                        ArixProject(
                            id = id,
                            name = name,
                            description = json.optString("description"),
                            colorSeed = json.optInt("colorSeed"),
                            createdAtMillis = json.optLong("createdAtMillis"),
                            updatedAtMillis = json.optLong("updatedAtMillis"),
                            linkedSessionIds = json.optJSONArray("linkedSessionIds")?.let { ids ->
                                buildList {
                                    for (i in 0 until ids.length()) add(ids.optString(i))
                                }
                            }.orEmpty(),
                            personaIds = json.optJSONArray("personaIds")?.let { ids ->
                                buildList {
                                    for (i in 0 until ids.length()) add(ids.optString(i))
                                }
                            }.orEmpty(),
                            isArchived = json.optBoolean("isArchived", false),
                            cachedMemoryCount = json.optInt("cachedMemoryCount"),
                            cachedMissionCount = json.optInt("cachedMissionCount"),
                            cachedAutomationCount = json.optInt("cachedAutomationCount"),
                        ),
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    private companion object {
        val ProjectsJsonKey = stringPreferencesKey("projects_json")
    }
}
