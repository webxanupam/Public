package com.arix.app.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.arix.app.R
import com.arix.app.mcp.ArixConnector
import com.arix.app.mcp.ArixConnectorAuthKind
import com.arix.app.mcp.ArixConnectorInstaller
import com.arix.app.mcp.ArixConnectorLibrary
import com.arix.app.mcp.ArixMcpJsonImporter
import com.arix.app.mcp.ArixMcpLoopbackServer
import com.arix.app.mcp.ArixMcpOAuth
import com.arix.app.mcp.ArixMcpOAuthClient
import com.arix.app.mcp.ArixMcpOAuthConfig
import com.arix.app.mcp.ArixMcpServerConfig
import com.arix.app.mcp.ArixMcpServerStatus
import com.arix.app.mcp.ArixMcpManager
import com.arix.app.mcp.ArixMcpRepository
import com.arix.app.ui.theme.ArixError
import com.arix.app.ui.theme.ArixOnSurface
import com.arix.app.ui.theme.ArixOnSurfaceVariant
import com.arix.app.ui.theme.ArixSettingsBackground
import com.arix.app.ui.theme.ArixSurface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ArixMcpServersPage(
    repository: ArixMcpRepository,
    manager: ArixMcpManager,
    onBrowseConnectors: () -> Unit,
    onBack: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val servers by repository.servers.collectAsState(initial = emptyList())
    val statuses by manager.statuses.collectAsState()
    val reloading by manager.reloading.collectAsState()
    var editing by remember { mutableStateOf<ArixMcpServerConfig?>(null) }
    var adding by remember { mutableStateOf(false) }
    var importing by remember { mutableStateOf(false) }

    SubPageScaffold(
        title = stringResource(R.string.settings_mcp_servers),
        onBack = onBack,
        trailingIcon = Icons.Rounded.Refresh,
        trailingLoading = reloading,
        trailingContentDescription = stringResource(R.string.settings_reconnect),
        onTrailingAction = { scope.launch { manager.reload() } },
        secondaryTrailingIcon = Icons.Rounded.Add,
        secondaryTrailingContentDescription = stringResource(R.string.mcp_add_server),
        onSecondaryTrailingAction = { adding = true },
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            SettingsCardGroup {
                SettingsNavRow(
                    icon = Icons.Rounded.Public,
                    title = stringResource(R.string.mcp_browse_connectors),
                    subtitle = stringResource(R.string.mcp_browse_connectors_hint),
                    onClick = onBrowseConnectors,
                )
                CardDivider()
                SettingsNavRow(
                    icon = Icons.Rounded.Download,
                    title = stringResource(R.string.mcp_import_json),
                    subtitle = stringResource(R.string.mcp_import_json_hint),
                    onClick = { importing = true },
                )
            }

            if (servers.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(ArixSurface),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Terminal,
                            contentDescription = null,
                            tint = ArixOnSurfaceVariant,
                            modifier = Modifier.size(28.dp),
                        )
                    }
                    Text(
                        text = stringResource(R.string.mcp_empty),
                        style = MaterialTheme.typography.titleMedium,
                        color = ArixOnSurface,
                    )
                    Text(
                        text = stringResource(R.string.mcp_empty_hint),
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                    )
                }
            } else {
                SettingsCardGroup {
                    servers.forEachIndexed { index, server ->
                        if (index > 0) CardDivider()
                        ArixMcpServerRow(
                            server = server,
                            status = statuses.firstOrNull { it.name == server.name },
                            onClick = { editing = server },
                        )
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }

    if (adding || editing != null) {
        ArixMcpEditorDialog(
            existing = editing,
            repository = repository,
            manager = manager,
            onDismiss = {
                adding = false
                editing = null
            },
        )
    }
    if (importing) {
        ArixMcpImportDialog(
            repository = repository,
            manager = manager,
            onDismiss = { importing = false },
        )
    }
}

@Composable
private fun ArixMcpServerRow(
    server: ArixMcpServerConfig,
    status: ArixMcpServerStatus?,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(ArixSurface),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = if (server.isStdio) Icons.Rounded.Terminal else Icons.Rounded.Public,
                contentDescription = null,
                tint = ArixOnSurfaceVariant,
                modifier = Modifier.size(20.dp),
            )
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = server.name,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.SemiBold,
                color = ArixOnSurface,
            )
            val subtitle = when {
                server.isStdio -> server.command.orEmpty()
                status?.state == ArixMcpServerStatus.State.CONNECTED ->
                    stringResource(R.string.mcp_tools_count, status.toolCount)
                status?.state == ArixMcpServerStatus.State.FAILED &&
                    !status.error.isNullOrBlank() -> status.error
                else -> server.url.orEmpty()
            }
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
                maxLines = 1,
            )
        }
        ArixMcpStatusPill(status = status, enabled = server.enabled)
    }
}

@Composable
internal fun ArixMcpStatusPill(status: ArixMcpServerStatus?, enabled: Boolean) {
    val (label, color) = when {
        !enabled -> stringResource(R.string.mcp_status_disabled) to ArixOnSurfaceVariant
        status == null || status.state == ArixMcpServerStatus.State.CONNECTING ->
            stringResource(R.string.mcp_status_connecting) to MaterialTheme.colorScheme.primary
        status.state == ArixMcpServerStatus.State.CONNECTED ->
            stringResource(R.string.mcp_status_connected) to Color(0xFF3FB27F)
        status.state == ArixMcpServerStatus.State.FAILED ->
            stringResource(R.string.mcp_status_failed) to ArixError
        else -> stringResource(R.string.mcp_status_not_connected) to ArixOnSurfaceVariant
    }
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(color.copy(alpha = 0.14f))
            .border(0.5.dp, color.copy(alpha = 0.5f), RoundedCornerShape(999.dp))
            .padding(horizontal = 10.dp, vertical = 3.dp),
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = color,
        )
    }
}

@Composable
private fun ArixMcpEditorDialog(
    existing: ArixMcpServerConfig?,
    repository: ArixMcpRepository,
    manager: ArixMcpManager,
    onDismiss: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(existing?.name.orEmpty()) }
    var url by remember { mutableStateOf(existing?.url.orEmpty()) }
    var command by remember { mutableStateOf(existing?.command.orEmpty()) }
    var argsText by remember { mutableStateOf(existing?.args?.joinToString(" ") ?: "") }
    var envText by remember {
        mutableStateOf(existing?.env?.entries?.joinToString("\n") { "${it.key}=${it.value}" } ?: "")
    }
    var oauthClientId by remember {
        mutableStateOf(existing?.oauth?.clientId.orEmpty())
    }
    var oauthClientSecret by remember {
        mutableStateOf(existing?.oauth?.clientSecret.orEmpty())
    }
    var revealSecret by remember { mutableStateOf(false) }
    var enabled by remember { mutableStateOf(existing?.enabled ?: true) }
    val stdio = command.isNotBlank()
    val nameValid = ArixMcpServerConfig.isValidName(name)
    val canSave = nameValid && (stdio || url.isNotBlank())

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(
                enabled = canSave,
                onClick = {
                    val config = ArixMcpServerConfig(
                        name = name.trim(),
                        url = url.trim().takeIf { it.isNotEmpty() },
                        command = command.trim().takeIf { it.isNotEmpty() },
                        args = argsText.split(" ").map(String::trim).filter(String::isNotEmpty),
                        env = envText.lines()
                            .mapNotNull { line ->
                                val index = line.indexOf('=')
                                if (index <= 0) return@mapNotNull null
                                line.substring(0, index).trim() to line.substring(index + 1)
                            }
                            .toMap(),
                        enabled = enabled,
                        headers = existing?.headers ?: emptyMap(),
                        disabledTools = existing?.disabledTools ?: emptySet(),
                        oauth = (existing?.oauth ?: ArixMcpOAuthConfig()).let { stored ->
                            if (oauthClientId.isBlank() && oauthClientSecret.isBlank() && stored.clientId.isBlank()) {
                                stored
                            } else {
                                stored.copy(
                                    clientId = oauthClientId.trim(),
                                    clientSecret = oauthClientSecret.trim(),
                                )
                            }
                        },
                    )
                    scope.launch {
                        if (existing != null && existing.name != config.name) {
                            manager.removeServer(existing.name)
                        }
                        repository.upsertServer(config)
                        manager.reloadServer(config.name)
                        onDismiss()
                    }
                },
            ) {
                Text(stringResource(R.string.common_save))
            }
        },
        dismissButton = {
            if (existing != null) {
                TextButton(
                    onClick = {
                        scope.launch {
                            manager.removeServer(existing.name)
                            onDismiss()
                        }
                    },
                ) {
                    Text(
                        stringResource(R.string.mcp_delete_server),
                        color = ArixError,
                    )
                }
            } else {
                TextButton(onClick = onDismiss) {
                    Text(stringResource(R.string.common_cancel))
                }
            }
        },
        title = {
            Text(
                text = stringResource(
                    if (existing == null) R.string.mcp_add_server else R.string.mcp_edit_server,
                ),
            )
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.verticalScroll(rememberScrollState()),
            ) {
                ArixMcpDialogField(
                    label = stringResource(R.string.mcp_field_name),
                    value = name,
                    onValueChange = { name = it },
                )
                if (!nameValid && name.isNotBlank()) {
                    Text(
                        text = stringResource(R.string.mcp_name_invalid),
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixError,
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = stringResource(R.string.mcp_field_enabled),
                        style = MaterialTheme.typography.bodyMedium,
                        color = ArixOnSurface,
                        modifier = Modifier.weight(1f),
                    )
                    Switch(checked = enabled, onCheckedChange = { enabled = it })
                }
                ArixMcpDialogField(
                    label = stringResource(R.string.mcp_field_url),
                    value = url,
                    onValueChange = { url = it },
                    enabled = !stdio,
                    placeholder = "https://example.com/mcp",
                )
                Text(
                    text = stringResource(R.string.mcp_transport_hint),
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                )
                ArixMcpDialogField(
                    label = stringResource(R.string.mcp_field_command),
                    value = command,
                    onValueChange = { command = it },
                    placeholder = "npx",
                )
                ArixMcpDialogField(
                    label = stringResource(R.string.mcp_field_args),
                    value = argsText,
                    onValueChange = { argsText = it },
                    placeholder = "-y @modelcontextprotocol/server-filesystem",
                    enabled = stdio,
                )
                ArixMcpDialogField(
                    label = stringResource(R.string.mcp_field_env),
                    value = envText,
                    onValueChange = { envText = it },
                    placeholder = "API_KEY=value",
                    enabled = stdio,
                    minLines = 2,
                )
                if (!stdio) {
                    CardDivider()
                    Text(
                        text = stringResource(R.string.mcp_oauth_section_hint),
                        style = MaterialTheme.typography.labelMedium,
                        color = ArixOnSurfaceVariant,
                    )
                    ArixMcpDialogField(
                        label = stringResource(R.string.mcp_oauth_client_id),
                        value = oauthClientId,
                        onValueChange = { oauthClientId = it },
                        placeholder = "optional — for servers without auto-registration",
                    )
                    OutlinedTextField(
                        value = oauthClientSecret,
                        onValueChange = { oauthClientSecret = it },
                        label = { Text(stringResource(R.string.mcp_oauth_client_secret)) },
                        placeholder = { Text("optional") },
                        singleLine = true,
                        visualTransformation = if (revealSecret) VisualTransformation.None
                        else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(autoCorrect = false),
                        trailingIcon = {
                            IconButton(onClick = { revealSecret = !revealSecret }) {
                                Icon(
                                    imageVector = if (revealSecret) Icons.Rounded.Close else Icons.Rounded.Key,
                                    contentDescription = null,
                                    tint = ArixOnSurfaceVariant,
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Text(
                        text = "GitHub / Discord / Render style servers: create an OAuth app " +
                            "in the developer console with one of Arix's callback URLs — " +
                            ArixMcpOAuth.CustomSchemeRedirect + " (GitHub-style app link) or " +
                            ArixMcpOAuth.LoopbackRedirect + " (local server) — and paste the " +
                            "client id here.",
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                    )
                }
            }
        },
    )
}

@Composable
private fun ArixMcpDialogField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    placeholder: String = "",
    minLines: Int = 1,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        placeholder = if (placeholder.isBlank()) null else {
            { Text(placeholder, style = MaterialTheme.typography.bodySmall) }
        },
        enabled = enabled,
        singleLine = minLines <= 1,
        minLines = minLines,
        textStyle = MaterialTheme.typography.bodyMedium,
        modifier = modifier.fillMaxWidth(),
    )
}

@Composable
private fun ArixMcpImportDialog(
    repository: ArixMcpRepository,
    manager: ArixMcpManager,
    onDismiss: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val parseOutcome = remember(text) { ArixMcpJsonImporter.parse(text) }
    val previewText = when (val outcome = parseOutcome) {
        is ArixMcpJsonImporter.Outcome.Imported ->
            stringResource(R.string.mcp_import_preview, outcome.imported.size)
        is ArixMcpJsonImporter.Outcome.Error -> when (outcome.reason) {
            ArixMcpJsonImporter.Reason.NOT_JSON -> stringResource(R.string.mcp_import_error_not_json)
            ArixMcpJsonImporter.Reason.MISSING_SERVERS ->
                stringResource(R.string.mcp_import_error_missing_servers)
            ArixMcpJsonImporter.Reason.EMPTY_SERVERS ->
                stringResource(R.string.mcp_import_error_empty_servers)
            ArixMcpJsonImporter.Reason.INVALID_ENTRIES ->
                stringResource(R.string.mcp_import_error_invalid_entries)
        }
    }
    val isImportable = parseOutcome is ArixMcpJsonImporter.Outcome.Imported

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(
                enabled = text.isNotBlank() && !busy,
                onClick = {
                    busy = true
                    scope.launch {
                        val current = repository.servers.first()
                        val (_, merged) = ArixMcpJsonImporter.merge(current, text)
                        repository.replaceServers(merged)
                        manager.reload()
                        busy = false
                        onDismiss()
                    }
                },
            ) {
                Text(stringResource(R.string.mcp_import_action))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.common_cancel))
            }
        },
        title = { Text(stringResource(R.string.mcp_import_title)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp),
                    placeholder = {
                        Text(
                            text = "{ \"mcpServers\": { \"fetch\": { \"url\": \"https://…\" } } }",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    },
                    textStyle = MaterialTheme.typography.bodySmall,
                )
                if (text.isNotBlank()) {
                    Text(
                        text = previewText,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (isImportable) Color(0xFF3FB27F) else ArixError,
                    )
                }
            }
        },
    )
}

@Composable
fun ArixConnectorsPage(
    repository: ArixMcpRepository,
    installer: ArixConnectorInstaller,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var catalog by remember { mutableStateOf(emptyList<ArixConnector>()) }
    LaunchedEffect(context) {
        catalog = withContext(Dispatchers.Default) { ArixConnectorLibrary.load(context) }
    }
    val installed by repository.servers.collectAsState(initial = emptyList())
    var search by remember { mutableStateOf("") }
    var keyDialogFor by remember { mutableStateOf<ArixConnector?>(null) }
    var clientDialogFor by remember { mutableStateOf<ArixConnector?>(null) }
    var manageDialogFor by remember { mutableStateOf<ArixConnector?>(null) }
    var oauthFlowFor by remember { mutableStateOf<ArixConnector?>(null) }
    var oauthPreset by remember {
        mutableStateOf(Triple("", "", ""))
    }

    val filtered = if (search.isBlank()) {
        catalog
    } else {
        val query = search.trim()
        catalog.filter {
            it.name.contains(query, ignoreCase = true) ||
                it.aboutEn.contains(query, ignoreCase = true) ||
                it.aboutZh.contains(query, ignoreCase = true)
        }
    }

    SubPageScaffold(
        title = stringResource(R.string.settings_connectors),
        onBack = onBack,
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                singleLine = true,
                placeholder = { Text(stringResource(R.string.connector_search_hint)) },
                textStyle = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.fillMaxWidth(),
            )
            if (filtered.isEmpty()) {
                Text(
                    text = stringResource(R.string.connector_empty),
                    style = MaterialTheme.typography.bodyMedium,
                    color = ArixOnSurfaceVariant,
                    modifier = Modifier.padding(vertical = 24.dp),
                )
            }
            ArixConnectorLibrary.categoryOrder.forEach { category ->
                val connectors = filtered.filter { it.category == category }
                if (connectors.isEmpty()) return@forEach
                Text(
                    text = connectorCategoryLabel(category),
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.SemiBold,
                    color = ArixOnSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                )
                SettingsCardGroup {
                    connectors.forEachIndexed { index, connector ->
                        if (index > 0) CardDivider()
                        ArixConnectorRow(
                            connector = connector,
                            installedServer = installed.firstOrNull { it.name == connector.id },
                            onClick = {
                                val server = installed.firstOrNull { it.name == connector.id }
                                when {
                                    server != null -> manageDialogFor = connector
                                    connector.authKind == ArixConnectorAuthKind.NONE ->
                                        scope.launch { installer.installOpen(connector) }
                                    connector.authKind == ArixConnectorAuthKind.KEY_HEADER ||
                                        connector.authKind == ArixConnectorAuthKind.KEY_QUERY ||
                                        connector.authKind == ArixConnectorAuthKind.KEY_ENV ->
                                        keyDialogFor = connector
                                    connector.authKind == ArixConnectorAuthKind.OAUTH_CLIENT_ID ->
                                        clientDialogFor = connector
                                    else -> {
                                        scope.launch {
                                            installer.prepareOAuth(connector)
                                            oauthPreset = Triple("", "", "")
                                            oauthFlowFor = connector
                                        }
                                    }
                                }
                            },
                        )
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }

    keyDialogFor?.let { connector ->
        ArixConnectorKeyDialog(
            connector = connector,
            onDismiss = { keyDialogFor = null },
            onConfirm = { key ->
                scope.launch {
                    installer.installWithKey(connector, key)
                    keyDialogFor = null
                }
            },
        )
    }
    clientDialogFor?.let { connector ->
        ArixConnectorClientDialog(
            connector = connector,
            onDismiss = { clientDialogFor = null },
            onAuthorize = { clientId, clientSecret, redirect ->
                clientDialogFor = null
                scope.launch {
                    installer.prepareOAuth(connector)
                    oauthPreset = Triple(clientId, clientSecret, redirect)
                    oauthFlowFor = connector
                }
            },
        )
    }
    manageDialogFor?.let { connector ->
        val server = installed.firstOrNull { it.name == connector.id }
        if (server != null) {
            ArixConnectorManageDialog(
                connector = connector,
                enabled = server.enabled,
                onEnabledChange = { enabled ->
                    scope.launch { repository.setEnabled(connector.id, enabled) }
                },
                onRemove = {
                    scope.launch {
                        installer.remove(connector)
                        manageDialogFor = null
                    }
                },
                onDismiss = { manageDialogFor = null },
            )
        } else {
            manageDialogFor = null
        }
    }
    oauthFlowFor?.let { connector ->
        ArixMcpOAuthOverlay(
            connector = connector,
            repository = repository,
            presetClientId = oauthPreset.first,
            presetClientSecret = oauthPreset.second,
            presetRedirect = oauthPreset.third,
            onDone = {
                oauthFlowFor = null
            },
        )
    }
}

@Composable
private fun ArixConnectorRow(
    connector: ArixConnector,
    installedServer: ArixMcpServerConfig?,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        val brandColor = runCatching { Color(android.graphics.Color.parseColor(connector.color)) }
            .getOrDefault(Color(0xFF5B5BD6))
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(brandColor),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = connector.initial,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = if (brandColor.luminanceFast() > 0.55f) Color.Black else Color.White,
            )
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = connector.name,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.SemiBold,
                color = ArixOnSurface,
            )
            Text(
                text = connector.aboutEn.ifBlank { connector.aboutZh },
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
                maxLines = 2,
            )
        }
        when {
            installedServer == null -> ArixMcpStatusPill(status = null, enabled = true)
            !installedServer.enabled -> ArixMcpStatusPill(status = null, enabled = false)
            installedServer.oauth?.hasTokens == true -> ArixMcpStatusPill(
                status = ArixMcpServerStatus(
                    name = connector.id,
                    state = ArixMcpServerStatus.State.CONNECTED,
                ),
                enabled = true,
            )
            else -> ArixMcpStatusPill(
                status = ArixMcpServerStatus(
                    name = connector.id,
                    state = ArixMcpServerStatus.State.CONNECTING,
                ),
                enabled = true,
            )
        }
    }
}

private fun Color.luminanceFast(): Float =
    (0.299f * red + 0.587f * green + 0.114f * blue)

@Composable
private fun ArixConnectorKeyDialog(
    connector: ArixConnector,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit,
) {
    var key by remember { mutableStateOf("") }
    var visible by remember { mutableStateOf(false) }
    val hint = when (connector.authKind) {
        ArixConnectorAuthKind.KEY_QUERY ->
            stringResource(R.string.connector_key_query_hint, connector.auth.query ?: "key")
        ArixConnectorAuthKind.KEY_ENV ->
            stringResource(
                R.string.connector_key_env_hint,
                connector.auth.envKey ?: (connector.id.uppercase() + "_API_KEY"),
            )
        else ->
            stringResource(
                R.string.connector_key_header_hint,
                connector.auth.header ?: "Authorization",
            )
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(
                enabled = key.isNotBlank(),
                onClick = { onConfirm(key) },
            ) {
                Text(stringResource(R.string.connector_key_submit))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.common_cancel))
            }
        },
        title = { Text(stringResource(R.string.connector_key_title, connector.name)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                connector.auth.where?.let { where ->
                    Text(
                        text = stringResource(R.string.connector_key_where, where),
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                    )
                }
                Text(
                    text = hint,
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                )
                OutlinedTextField(
                    value = key,
                    onValueChange = { key = it },
                    singleLine = true,
                    visualTransformation = if (visible) {
                        VisualTransformation.None
                    } else {
                        PasswordVisualTransformation()
                    },
                    trailingIcon = {
                        IconButton(onClick = { visible = !visible }) {
                            Icon(
                                imageVector = if (visible) Icons.Rounded.Close else Icons.Rounded.Key,
                                contentDescription = null,
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
    )
}

@Composable
private fun ArixConnectorClientDialog(
    connector: ArixConnector,
    onDismiss: () -> Unit,
    onAuthorize: (clientId: String, clientSecret: String, redirect: String) -> Unit,
) {
    ArixMcpCredentialsForm(
        connector = connector,
        onDismiss = onDismiss,
        onConfirm = onAuthorize,
    )
}

@Composable
private fun ArixConnectorManageDialog(
    connector: ArixConnector,
    enabled: Boolean,
    onEnabledChange: (Boolean) -> Unit,
    onRemove: () -> Unit,
    onDismiss: () -> Unit,
) {
    val context = LocalContext.current
    var confirming by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.common_cancel))
            }
        },
        title = { Text(connector.name) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = stringResource(R.string.connector_enabled_label),
                        style = MaterialTheme.typography.bodyMedium,
                        color = ArixOnSurface,
                        modifier = Modifier.weight(1f),
                    )
                    Switch(checked = enabled, onCheckedChange = onEnabledChange)
                }
                connector.docs?.let { docs ->
                    TextButton(
                        onClick = {
                            ArixLinkActions.openUrl(context, docs)
                        },
                    ) {
                        Text(stringResource(R.string.connector_docs))
                    }
                }
                if (!confirming) {
                    TextButton(onClick = { confirming = true }) {
                        Text(
                            stringResource(R.string.connector_remove),
                            color = ArixError,
                        )
                    }
                } else {
                    Text(
                        text = stringResource(R.string.connector_remove_body),
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { confirming = false }) {
                            Text(stringResource(R.string.common_cancel))
                        }
                        TextButton(onClick = onRemove) {
                            Text(
                                stringResource(R.string.connector_remove_confirm),
                                color = ArixError,
                            )
                        }
                    }
                }
            }
        },
    )
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun ArixMcpOAuthOverlay(
    connector: ArixConnector,
    repository: ArixMcpRepository,
    presetClientId: String,
    presetClientSecret: String,
    presetRedirect: String,
    onDone: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var status by remember { mutableStateOf("") }
    var authorizationUrl by remember { mutableStateOf<String?>(null) }
    var ongoing by remember { mutableStateOf<ArixMcpOAuthClient.Ongoing?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var manualCredentials by remember {
        mutableStateOf<Triple<String, String, String>?>(null)
    }
    var showManualDialog by remember { mutableStateOf(false) }
    var retryKey by remember { mutableStateOf(0) }
    var webErrorForUrl by remember { mutableStateOf<String?>(null) }
    var exchangeDone by remember { mutableStateOf(false) }

    val effectiveClientId = manualCredentials?.first ?: presetClientId
    val effectiveClientSecret = manualCredentials?.second ?: presetClientSecret
    val effectiveRedirectChoice = manualCredentials?.third?.takeIf { it.isNotBlank() }
        ?: presetRedirect.takeIf { it.isNotBlank() }

    DisposableEffect(Unit) {
        ArixMcpLoopbackServer.start()
        onDispose {
            ArixMcpLoopbackServer.stop()
            if (ArixMcpOAuth.externalRedirect.value != null) {
                ArixMcpOAuth.externalRedirect.value = null
            }
        }
    }

    LaunchedEffect(connector.id, retryKey) {
        error = null
        webErrorForUrl = null
        exchangeDone = false
        status = context.getString(R.string.mcp_oauth_step_connecting, connector.name)
        authorizationUrl = null
        runCatching {
            val client = ArixMcpOAuthClient(connector.id)
            val stored = repository.servers.first()
                .firstOrNull { it.name == connector.id }?.oauth
            val useStoredClient = effectiveClientId.isBlank()
            val storedRedirect = stored?.redirectUri.orEmpty()
            val redirectForFlow = when {
                effectiveRedirectChoice == ArixMcpOAuth.CustomSchemeRedirect ->
                    ArixMcpOAuth.CustomSchemeRedirect
                effectiveRedirectChoice == ArixMcpOAuth.LoopbackRedirect ->
                    ArixMcpOAuth.LoopbackRedirect
                stored != null && stored.hasTokens && storedRedirect.isNotBlank() ->
                    storedRedirect
                else -> connector.preferredRedirect
            }
            val config = ArixMcpOAuthConfig(
                clientId = effectiveClientId.ifBlank { stored?.clientId.orEmpty() },
                clientSecret = effectiveClientSecret.ifBlank {
                    if (useStoredClient) stored?.clientSecret.orEmpty() else ""
                },
                authorizationEndpoint = stored?.authorizationEndpoint.orEmpty(),
                tokenEndpoint = stored?.tokenEndpoint.orEmpty(),
                registrationEndpoint = stored?.registrationEndpoint.orEmpty(),
                scope = "",
                redirectUri = redirectForFlow,
            )
            val flow = client.beginAuthorization(
                mcpUrl = connector.url,
                config = config,
                onUpdate = { updated ->
                    runCatching {
                        val current = repository.servers.first()
                            .firstOrNull { it.name == connector.id }
                        if (current?.oauth?.hasTokens != true) {
                            repository.upsertServer(
                                (
                                    current ?: ArixMcpServerConfig(
                                        name = connector.id,
                                        url = connector.url,
                                    )
                                    ).copy(
                                    url = connector.url,
                                    oauth = updated,
                                ),
                            )
                        }
                    }
                },
            )
            ongoing = flow
            authorizationUrl = flow.authorizationUrl
            status = context.getString(R.string.mcp_oauth_step_authorize, connector.name)
        }.onFailure { failure ->
            error = failure.message ?: "OAuth discovery failed"
        }
    }

    LaunchedEffect(connector.id) {
        ArixMcpOAuth.externalRedirect.collect { redirect ->
            val target = redirect ?: return@collect
            val flow = ongoing ?: return@collect
            val isCustomScheme = target.startsWith("arix-mcp://", ignoreCase = true)
            val isLoopback = ArixMcpOAuth.isLoopbackRedirect(target)
            if (!isCustomScheme && !isLoopback) return@collect
            if (isLoopback && !ArixMcpOAuth.isLoopbackRedirect(flow.config.redirectUri)) {
                return@collect
            }
            if (exchangeDone) return@collect
            exchangeDone = true
            status = context.getString(R.string.mcp_oauth_step_completing)
            runCatching {
                val client = ArixMcpOAuthClient(connector.id)
                client.completeAuthorization(redirectUri = target, ongoing = flow)
            }.fold(
                onSuccess = { authorized ->
                    val current = repository.servers.first()
                        .firstOrNull { it.name == connector.id }
                    repository.upsertServer(
                        (
                            current ?: ArixMcpServerConfig(
                                name = connector.id,
                                url = connector.url,
                            )
                            ).copy(url = connector.url, oauth = authorized),
                    )
                    ArixMcpOAuth.externalRedirect.value = null
                    onDone()
                },
                onFailure = { failure ->
                    error = failure.message ?: "Sign-in failed"
                    ArixMcpOAuth.externalRedirect.value = null
                },
            )
        }
    }

    val brand = remember(connector.color) { connectorBrandColor(connector.color) }
    val brandGradient = remember(brand) {
        Brush.linearGradient(listOf(brand, brand.copy(alpha = 0.55f)))
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ArixSettingsBackground)
            .statusBarsPadding()
            .navigationBarsPadding(),
    ) {
        Surface(
            color = ArixSurface,
            shadowElevation = 0.dp,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 6.dp, end = 10.dp, top = 6.dp, bottom = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onDone) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = stringResource(R.string.common_back),
                        tint = ArixOnSurface,
                    )
                }
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(brandGradient),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = connector.initial,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                    )
                }
                Spacer(Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = connector.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = ArixOnSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    val liveError = error ?: webErrorForUrl
                    Text(
                        text = liveError ?: status,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (liveError != null) ArixError else ArixOnSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                val url = authorizationUrl
                if (url != null && error == null) {
                    IconButton(
                        onClick = {
                            ArixLinkActions.openUrl(context, url)
                        },
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Public,
                            contentDescription = stringResource(R.string.mcp_oauth_action_browser),
                            tint = ArixOnSurfaceVariant,
                        )
                    }
                }
            }
        }

        val loadedUrl = authorizationUrl
        val liveError = error ?: webErrorForUrl
        if (loadedUrl != null && liveError == null) {
            AndroidView(
                factory = { viewContext ->
                    WebView(viewContext).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.textZoom = 100
                        settings.useWideViewPort = true
                        settings.loadWithOverviewMode = true
                        settings.setSupportZoom(true)
                        settings.builtInZoomControls = true
                        settings.displayZoomControls = false
                        settings.userAgentString =
                            "Mozilla/5.0 (Linux; Android 13; Pixel 7) " +
                                "AppleWebKit/537.36 (KHTML, like Gecko) " +
                                "Chrome/126.0.0.0 Mobile Safari/537.36"
                        runCatching {
                            android.webkit.CookieManager.getInstance()
                                .setAcceptCookie(true)
                            android.webkit.CookieManager.getInstance()
                                .setAcceptThirdPartyCookies(this, true)
                        }
                        webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(
                                view: WebView?,
                                request: android.webkit.WebResourceRequest?,
                            ): Boolean {
                                val target = request?.url?.toString().orEmpty()
                                val isCustomScheme = target.startsWith(
                                    ArixMcpOAuth.CustomSchemeRedirect,
                                    ignoreCase = true,
                                ) || target.startsWith(
                                    ArixMcpOAuth.CustomSchemeRedirect.uppercase(),
                                    ignoreCase = true,
                                )
                                val isLoopback = ArixMcpOAuth.isLoopbackRedirect(target) && (
                                    target.startsWith(
                                        ArixMcpOAuth.LoopbackRedirect.substringBeforeLast('/'),
                                        ignoreCase = true,
                                    ) || target.startsWith(
                                        ArixMcpOAuth.LoopbackLocalhostRedirect.substringBeforeLast('/'),
                                        ignoreCase = true,
                                    )
                                    )
                                val isRedirect = isCustomScheme || isLoopback
                                if (isRedirect) {
                                    val flow = ongoing
                                    if (flow != null && !exchangeDone) {
                                        exchangeDone = true
                                        status = context.getString(R.string.mcp_oauth_step_completing)
                                        scope.launch {
                                            runCatching {
                                                val client = ArixMcpOAuthClient(connector.id)
                                                val authorized = client.completeAuthorization(
                                                    redirectUri = target,
                                                    ongoing = flow,
                                                )
                                                val current = repository.servers.first()
                                                    .firstOrNull { it.name == connector.id }
                                                repository.upsertServer(
                                                    (
                                                        current ?: ArixMcpServerConfig(
                                                            name = connector.id,
                                                            url = connector.url,
                                                        )
                                                        ).copy(
                                                        url = connector.url,
                                                        oauth = authorized,
                                                    ),
                                                )
                                            }.onSuccess {
                                                onDone()
                                            }.onFailure { failure ->
                                                error = failure.message ?: "Sign-in failed"
                                            }
                                        }
                                    }
                                    return true
                                }
                                return false
                            }

                            override fun onReceivedError(
                                view: WebView?,
                                request: android.webkit.WebResourceRequest?,
                                error: android.webkit.WebResourceError?,
                            ) {
                                val failing = request?.url?.toString().orEmpty()
                                if (request?.isForMainFrame == true) {
                                    webErrorForUrl = context.getString(R.string.mcp_oauth_page_failed) +
                                        (failing.take(80).takeIf { it.isNotBlank() }
                                            ?.let { " ($it)" } ?: "") +
                                        (error?.description?.toString()
                                            ?.take(80)?.let { " — $it" } ?: "")
                                }
                            }
                        }
                        loadUrl(loadedUrl)
                    }
                },
                onRelease = { webView ->
                    runCatching { webView.stopLoading() }
                    runCatching { webView.destroy() }
                },
                modifier = Modifier
                    .fillMaxSize()
                    .background(ArixSettingsBackground),
            )
        } else if (liveError != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center,
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    listOf(
                                        ArixError.copy(alpha = 0.22f),
                                        ArixError.copy(alpha = 0.06f),
                                    ),
                                ),
                            ),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Key,
                            contentDescription = null,
                            tint = ArixError,
                            modifier = Modifier.size(30.dp),
                        )
                    }
                    Text(
                        text = stringResource(R.string.mcp_oauth_failed_title),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = ArixOnSurface,
                    )
                    Surface(
                        color = ArixSurface,
                        shape = RoundedCornerShape(14.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            ArixError.copy(alpha = 0.28f),
                        ),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(
                            text = liveError,
                            style = MaterialTheme.typography.bodyMedium,
                            color = ArixOnSurfaceVariant,
                            modifier = Modifier
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                        )
                    }
                    Text(
                        text = stringResource(R.string.mcp_oauth_failed_hint),
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant.copy(alpha = 0.8f),
                        textAlign = TextAlign.Center,
                    )
                    Spacer(Modifier.height(4.dp))
                    Surface(
                        color = brand.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        TextButton(
                            onClick = { retryKey += 1 },
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Icon(Icons.Rounded.Refresh, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = stringResource(R.string.mcp_oauth_action_retry),
                                fontWeight = FontWeight.SemiBold,
                            )
                        }
                    }
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        TextButton(
                            onClick = { showManualDialog = true },
                        ) {
                            Text(stringResource(R.string.mcp_oauth_action_own_app))
                        }
                        TextButton(
                            onClick = {
                                val url = loadedUrl ?: return@TextButton
                                ArixLinkActions.openUrl(context, url)
                            },
                        ) {
                            Icon(Icons.Rounded.Public, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.mcp_oauth_action_browser))
                        }
                    }
                }
            }
        } else {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center,
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    val pulse = rememberInfiniteTransition(label = "arix_oauth_pulse")
                    val pulseAlpha by pulse.animateFloat(
                        initialValue = 0.35f,
                        targetValue = 1f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(900),
                            repeatMode = RepeatMode.Reverse,
                        ),
                        label = "arix_oauth_pulse_alpha",
                    )
                    Box(
                        modifier = Modifier.size(72.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape)
                                .background(brand.copy(alpha = 0.2f * pulseAlpha)),
                        )
                        Box(
                            modifier = Modifier
                                .size(52.dp)
                                .clip(CircleShape)
                                .background(brandGradient),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                text = connector.initial,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                            )
                        }
                    }
                    Text(
                        text = status,
                        style = MaterialTheme.typography.bodyMedium,
                        color = ArixOnSurfaceVariant,
                        textAlign = TextAlign.Center,
                    )
                    Surface(
                        color = ArixSurface,
                        shape = RoundedCornerShape(999.dp),
                    ) {
                        Text(
                            text = stringResource(R.string.mcp_oauth_secure),
                            style = MaterialTheme.typography.labelSmall,
                            color = ArixOnSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        )
                    }
                }
            }
        }
    }

    if (showManualDialog) {
        ArixMcpManualCredentialsDialog(
            connector = connector,
            onDismiss = { showManualDialog = false },
            onConfirm = { clientId, clientSecret, redirect ->
                showManualDialog = false
                manualCredentials = Triple(clientId, clientSecret, redirect)
                retryKey += 1
            },
        )
    }
}

private fun connectorBrandColor(hex: String): Color = runCatching {
    Color(android.graphics.Color.parseColor(hex))
}.getOrDefault(Color(0xFF5B5BD6))

@Composable
private fun ArixMcpManualCredentialsDialog(
    connector: ArixConnector,
    onDismiss: () -> Unit,
    onConfirm: (clientId: String, clientSecret: String, redirect: String) -> Unit,
) {
    ArixMcpCredentialsForm(
        connector = connector,
        onDismiss = onDismiss,
        onConfirm = onConfirm,
    )
}

@Composable
private fun ArixMcpCredentialsForm(
    connector: ArixConnector,
    onDismiss: () -> Unit,
    onConfirm: (clientId: String, clientSecret: String, redirect: String) -> Unit,
) {
    val context = LocalContext.current
    var clientId by remember { mutableStateOf("") }
    var clientSecret by remember { mutableStateOf("") }
    var secretVisible by remember { mutableStateOf(false) }
    var redirectChoice by remember(connector.id) {
        mutableStateOf(connector.preferredRedirect)
    }
    var copiedUrl by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(copiedUrl) {
        if (copiedUrl != null) {
            kotlinx.coroutines.delay(1600)
            copiedUrl = null
        }
    }
    val secretRequired = connector.auth.secretRequired
    val brand = remember(connector.color) { connectorBrandColor(connector.color) }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(
                enabled = clientId.isNotBlank() &&
                    (!secretRequired || clientSecret.isNotBlank()),
                onClick = {
                    onConfirm(clientId.trim(), clientSecret.trim(), redirectChoice)
                },
            ) {
                Text(stringResource(R.string.mcp_oauth_continue))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.common_cancel))
            }
        },
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(brand, brand.copy(alpha = 0.55f)),
                            ),
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = connector.initial,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                    )
                }
                Spacer(Modifier.width(10.dp))
                Text(stringResource(R.string.mcp_oauth_own_app_title))
            }
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.verticalScroll(rememberScrollState()),
            ) {
                Text(
                    text = stringResource(R.string.mcp_oauth_own_app_body, connector.name),
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                )
                Text(
                    text = stringResource(R.string.mcp_oauth_redirect_label),
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = ArixOnSurface,
                )
                ArixRedirectPickerRow(
                    url = ArixMcpOAuth.CustomSchemeRedirect,
                    hint = stringResource(R.string.mcp_oauth_redirect_scheme_hint),
                    selected = redirectChoice == ArixMcpOAuth.CustomSchemeRedirect,
                    copied = copiedUrl == ArixMcpOAuth.CustomSchemeRedirect,
                    onSelect = { redirectChoice = ArixMcpOAuth.CustomSchemeRedirect },
                    onCopy = {
                        runCatching {
                            context.getSystemService(
                                android.content.ClipboardManager::class.java,
                            )?.setPrimaryClip(
                                android.content.ClipData.newPlainText(
                                    "Arix redirect URI",
                                    ArixMcpOAuth.CustomSchemeRedirect,
                                ),
                            )
                        }
                        copiedUrl = ArixMcpOAuth.CustomSchemeRedirect
                    },
                )
                ArixRedirectPickerRow(
                    url = ArixMcpOAuth.LoopbackRedirect,
                    hint = stringResource(R.string.mcp_oauth_redirect_loopback_hint),
                    selected = redirectChoice == ArixMcpOAuth.LoopbackRedirect,
                    copied = copiedUrl == ArixMcpOAuth.LoopbackRedirect,
                    onSelect = { redirectChoice = ArixMcpOAuth.LoopbackRedirect },
                    onCopy = {
                        runCatching {
                            context.getSystemService(
                                android.content.ClipboardManager::class.java,
                            )?.setPrimaryClip(
                                android.content.ClipData.newPlainText(
                                    "Arix redirect URI",
                                    ArixMcpOAuth.LoopbackRedirect,
                                ),
                            )
                        }
                        copiedUrl = ArixMcpOAuth.LoopbackRedirect
                    },
                )
                OutlinedTextField(
                    value = clientId,
                    onValueChange = { clientId = it.trim() },
                    singleLine = true,
                    label = { Text(stringResource(R.string.mcp_oauth_client_id)) },
                )
                OutlinedTextField(
                    value = clientSecret,
                    onValueChange = { clientSecret = it.trim() },
                    singleLine = true,
                    label = {
                        Text(
                            text = stringResource(
                                if (secretRequired) {
                                    R.string.connector_client_secret_required
                                } else {
                                    R.string.connector_client_secret_optional
                                },
                            ),
                        )
                    },
                    visualTransformation = if (secretVisible) {
                        VisualTransformation.None
                    } else {
                        PasswordVisualTransformation()
                    },
                    trailingIcon = {
                        IconButton(onClick = { secretVisible = !secretVisible }) {
                            Icon(
                                imageVector = if (secretVisible) {
                                    Icons.Rounded.Close
                                } else {
                                    Icons.Rounded.Key
                                },
                                contentDescription = null,
                                tint = ArixOnSurfaceVariant,
                            )
                        }
                    },
                )
                if (secretRequired) {
                    Text(
                        text = stringResource(R.string.connector_client_secret_why),
                        style = MaterialTheme.typography.labelSmall,
                        color = ArixError.copy(alpha = 0.9f),
                    )
                }
                connector.auth.developer?.let { developer ->
                    TextButton(
                        onClick = {
                            ArixLinkActions.openUrl(context, developer)
                        },
                    ) { Text(stringResource(R.string.mcp_oauth_open_console)) }
                }
            }
        },
    )
}

@Composable
private fun ArixRedirectPickerRow(
    url: String,
    hint: String,
    selected: Boolean,
    copied: Boolean,
    onSelect: () -> Unit,
    onCopy: () -> Unit,
) {
    Surface(
        color = if (selected) {
            androidx.compose.ui.graphics.Color(0xFF5B5BD6).copy(alpha = 0.10f)
        } else {
            ArixSettingsBackground
        },
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (selected) {
                androidx.compose.ui.graphics.Color(0xFF5B5BD6).copy(alpha = 0.55f)
            } else {
                ArixOnSurfaceVariant.copy(alpha = 0.3f)
            },
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onSelect),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(start = 4.dp, end = 6.dp, top = 4.dp, bottom = 4.dp),
        ) {
            RadioButton(
                selected = selected,
                onClick = onSelect,
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = url,
                    style = MaterialTheme.typography.bodySmall,
                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                    color = ArixOnSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = hint,
                    style = MaterialTheme.typography.labelSmall,
                    color = ArixOnSurfaceVariant,
                )
            }
            TextButton(onClick = onCopy) {
                Text(
                    text = stringResource(
                        if (copied) R.string.mcp_oauth_copied else R.string.mcp_oauth_copy,
                    ),
                )
            }
        }
    }
}

private fun connectorCategoryLabel(category: String): String = when (category) {
    "agent" -> "Agentic"
    "tools" -> "Tools"
    "ai" -> "AI Creative"
    "work" -> "Work"
    "talk" -> "Communication"
    "files" -> "Files"
    "dev" -> "Developer"
    "data" -> "Data"
    "design" -> "Design"
    "money" -> "Payments"
    else -> category.replaceFirstChar { it.uppercase() }
}
