package com.arix.app.data

import android.content.Context
import android.content.SharedPreferences

class ScheduledTaskRequestCodeAllocator(
    private val persistence: Persistence,
) {
    private val lock = Any()
    private val allocations = HashMap(persistence.loadAllocations())
    private var nextCode = persistence.loadNextCode()

    fun requestCodeFor(taskId: String): Int = synchronized(lock) {
        val existing = allocations[taskId]
        if (existing != null) {
            existing
        } else {
            val code = allocateNextCode()
            allocations[taskId] = code
            persistLocked()
            code
        }
    }

    fun peekRequestCode(taskId: String): Int? = synchronized(lock) {
        allocations[taskId]
    }

    fun forget(taskId: String) {
        synchronized(lock) {
            if (allocations.remove(taskId) != null) {
                persistLocked()
            }
        }
    }

    fun allocationCount(): Int = synchronized(lock) { allocations.size }

    private fun allocateNextCode(): Int {
        val code = nextCode
        if (code >= 0) {
            error("Scheduled-task request code space exhausted")
        }
        nextCode += 1
        return code
    }

    private fun persistLocked() {
        persistence.save(allocations, nextCode)
    }

    interface Persistence {
        fun loadAllocations(): Map<String, Int>
        fun loadNextCode(): Int
        fun save(allocations: Map<String, Int>, nextCode: Int)
    }

    class SharedPreferencesPersistence(
        private val preferences: SharedPreferences,
    ) : Persistence {
        override fun loadAllocations(): Map<String, Int> {
            val result = mutableMapOf<String, Int>()
            for (entry in preferences.all.entries) {
                val key = entry.key
                val value = entry.value
                if (key.startsWith(KeyPrefixAllocation) && value is Int) {
                    result[key.substring(KeyPrefixAllocation.length)] = value
                }
            }
            return result
        }

        override fun loadNextCode(): Int {
            val stored = preferences.getInt(KeyNextCode, Int.MIN_VALUE)
            return if (stored in FirstCode until 0) stored else FirstCode
        }

        override fun save(allocations: Map<String, Int>, nextCode: Int) {
            preferences.edit().clear().apply {
                allocations.forEach { (taskId, code) -> putInt(KeyPrefixAllocation + taskId, code) }
                putInt(KeyNextCode, nextCode)
            }.apply()
        }

        private companion object {
            const val KeyPrefixAllocation = "alloc_"
            const val KeyNextCode = "next_code"
        }
    }

    companion object {
        const val FirstCode = Int.MIN_VALUE + 1

        fun from(context: Context): ScheduledTaskRequestCodeAllocator =
            ScheduledTaskRequestCodeAllocator(
                SharedPreferencesPersistence(
                    context.getSharedPreferences("arix_scheduled_task_request_codes", Context.MODE_PRIVATE),
                ),
            )
    }
}
