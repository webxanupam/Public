package com.arix.app.agent.setup

import com.arix.app.agent.shell.BuiltinShellFailure
import com.arix.app.agent.shell.BuiltinShellFix
import com.arix.app.agent.shell.BuiltinShellStatus
import com.arix.app.agent.shell.HelperRestart

/**
 * All user-facing copy for phone control (Mika port, Arix-native English).
 * Same wording rules as Mika: plain language, only words that already exist in
 * the phone's settings (Developer options, USB debugging, wireless debugging,
 * pairing code) — no adb/port/shell jargon (except the connect-port hint).
 */
object PhoneSetupCopy {

    data class FailureCopy(val title: String, val body: String)

    fun failure(f: BuiltinShellFailure): FailureCopy = when (f) {
        BuiltinShellFailure.WrongCode -> FailureCopy(
            "That pairing code didn't work",
            "The code was wrong or expired. Open the pairing window again for a new code, then submit it here.",
        )
        BuiltinShellFailure.PairingWindowClosed -> FailureCopy(
            "The pairing window closed",
            "The \"Pair device with pairing code\" window was closed before the code was submitted. Open it again and submit quickly.",
        )
        BuiltinShellFailure.NoWifi -> FailureCopy(
            "No Wi-Fi",
            "Wireless debugging needs Wi-Fi. Connect to a Wi-Fi network first, then retry.",
        )
        BuiltinShellFailure.WifiNotAllowed -> FailureCopy(
            "This Wi-Fi isn't allowed for wireless debugging",
            "Android has not been allowed to use wireless debugging on this Wi-Fi. Turn wireless debugging on by hand once (Developer options › Wireless debugging) and allow this network.",
        )
        BuiltinShellFailure.ConnectFailed -> FailureCopy(
            "Couldn't connect",
            "The connection to this phone's own wireless debugging failed. Retry; if it keeps failing, open the Wireless debugging page and fill its port in the field below.",
        )
        BuiltinShellFailure.AuthorizationRevoked -> FailureCopy(
            "Pairing was revoked",
            "The stored authorization is no longer accepted (unused for too long, or removed in the system). Pair again.",
        )
        BuiltinShellFailure.KeyUnreadable -> FailureCopy(
            "The pairing key can't be read",
            "The device only accepts that one key, so pair again to make a new one.",
        )
        BuiltinShellFailure.HelperStartFailed -> FailureCopy(
            "The helper didn't start",
            "Pairing worked but the background helper could not start. Retry; if it keeps failing, restart the phone and try once more.",
        )
        BuiltinShellFailure.UsbHelperStopped -> FailureCopy(
            "Run the computer start command again",
            "The helper was started from a computer over USB and has stopped (usually after a phone restart), and wireless debugging was never paired, so Arix can't start it by itself. Run the start command from the computer again.",
        )
        BuiltinShellFailure.Unknown -> FailureCopy(
            "Something went wrong",
            "Pairing or the connection failed for an unknown reason. Retry; if it keeps failing, restart the phone.",
        )
    }

    fun fixLabel(fix: BuiltinShellFix): String = when (fix) {
        BuiltinShellFix.Retry -> "Retry"
        BuiltinShellFix.RePair -> "Pair again"
        BuiltinShellFix.OpenWifi -> "Open Wi-Fi settings"
        BuiltinShellFix.OpenWirelessDebugging -> "Open wireless debugging"
        BuiltinShellFix.RunUsbCommand -> USB_COPY
    }

    /** Status values shown in Settings. */
    fun statusValue(s: BuiltinShellStatus): Pair<String, Boolean> = when (s) {
        BuiltinShellStatus.Running -> "Ready" to true
        BuiltinShellStatus.NotPaired -> "Not set up" to false
        BuiltinShellStatus.WirelessDebuggingOff -> "Wireless debugging off" to false
        BuiltinShellStatus.Connecting -> "Connecting…" to false
        is BuiltinShellStatus.Failed -> "Error" to false
    }

    fun canReconnect(s: BuiltinShellStatus): Boolean =
        s is BuiltinShellStatus.Failed && s.fix == BuiltinShellFix.Retry

    fun usageNote(restart: HelperRestart): String =
        if (restart == HelperRestart.UsbCommand) {
            "The helper was started from a computer. After a phone restart, run that start command again."
        } else {
            "After a phone restart, Arix turns wireless debugging back on by itself when allowed — everything else reconnects automatically."
        }

    val TITLE: String = "Phone control"
    val INTRO: String =
        "Lets Arix operate your apps on a separate background screen while you keep using your phone. " +
            "Works with any app — it reads the screen and taps buttons the way you would. Set it up once:"
    val LATER: String = "Later"

    val CODE_LABEL: String = "Pairing code"
    val PORT_LABEL: String = "Pairing port (optional)"
    val PORT_HINT: String = "From the Wireless debugging page — usually filled in automatically."
    val SUBMIT: String = "Pair"
    val CODE_INVALID: String = "The code is 6 digits."
    val WORKING: String = "Pairing…"
    val SCANNING_PORTS: String = "Looking for the pairing port…"

    val RECONNECT: String = "Reconnect"
    val REPAIR: String = "Pair again"
    val UNPAIR: String = "Unpair"
    val UNPAIR_TITLE: String = "Remove phone control?"
    val UNPAIR_BODY: String =
        "Arix forgets the pairing key and the helper stops. Phone control needs pairing again to work. " +
            "The system's authorization record is also removed in Developer options › Wireless debugging › Pair devices."
    val UNPAIR_CONFIRM: String = "Unpair"

    val SUCCESS_LINE: String = "Phone control is ready."
    fun successNote(restart: HelperRestart): String = usageNote(restart)

    // ---------- Notifications ----------

    val CHANNEL_NAME: String = "Pairing"
    val NOTIFY_ENTER_TITLE: String = "Enter the pairing code"
    val NOTIFY_ENTER_TEXT: String = "Arix found the pairing window — reply with the 6-digit code."
    val NOTIFY_WINDOW_FOUND: String = "pairing window found"
    val NOTIFY_CODE_INVALID: String = "The code is 6 digits — reply again."
    val NOTIFY_ACTION: String = "Fill in code"
    val NOTIFY_INPUT_LABEL: String = "Pairing code"
    val NOTIFY_WORKING: String = "Pairing…"
    val NOTIFY_DONE_TITLE: String = "Phone control ready"
    val NOTIFY_DONE_TEXT: String = "Arix can now operate apps on its background screen."
    val NOTIFY_PROBLEM_TEXT: String = "Open Arix to see what to do."

    fun notifyRetry(f: BuiltinShellFailure): String = when (f) {
        BuiltinShellFailure.WrongCode -> "That code didn't work — open the pairing window for a new one and reply with it."
        BuiltinShellFailure.PairingWindowClosed -> "The pairing window closed — open it again and reply with the new code."
        else -> failure(f).title
    }

    // ---------- USB start (computer) ----------

    val USB_ASK: String = "No usable wireless debugging? Start it from a computer instead"
    val USB_TITLE: String = "Start from a computer over USB"
    val USB_BODY: String =
        "On a computer with ADB (Android Studio or platform-tools), connect the phone with a USB cable " +
            "and run this command once. USB debugging must be on. The helper keeps running after you unplug."
    val USB_COPY: String = "Copy command"
    val USB_COPIED: String = "Copied"
}
