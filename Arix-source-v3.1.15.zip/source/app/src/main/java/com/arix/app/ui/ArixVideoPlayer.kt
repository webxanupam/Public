package com.arix.app.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.arix.app.media.ArixMediaItem
import com.arix.app.media.ArixMediaKind
import com.arix.app.media.ArixPlaybackController

@OptIn(UnstableApi::class)
@Composable
internal fun ArixVideoPlayer(
    streamUrl: String,
    referer: String = "",
    posterUrl: String = "",
) {
    val context = LocalContext.current
    val playbackState by ArixPlaybackController.state.collectAsState()
    var fullscreen by remember(streamUrl) { mutableStateOf(false) }

    val item = remember(streamUrl, referer, posterUrl) {
        ArixMediaItem(
            id = "inline:$streamUrl",
            title = streamUrl.substringBefore('?').substringAfterLast('/')
                .ifBlank { "Stream" },
            kind = ArixMediaKind.Video,
            streamUrl = streamUrl,
            posterUrl = posterUrl,
            sourceUrl = referer,
            sourceName = "Stream",
        )
    }

    LaunchedEffect(streamUrl) {
        ArixPlaybackController.initialize(context.applicationContext)
        val current = ArixPlaybackController.state.value
        if (current.nowPlaying?.streamUrl != streamUrl || !current.hasMedia) {
            ArixPlaybackController.playNow(item)
        }
    }

    val activity = remember(context) { context.findArixActivity() }
    DisposableEffect(fullscreen, activity) {
        val window = activity?.window
        if (fullscreen && window != null) {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            val controller = WindowCompat.getInsetsController(window, window.decorView)
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
            onDispose {
                activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                controller.show(WindowInsetsCompat.Type.systemBars())
            }
        } else {
            onDispose { }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(
                if (playbackState.nowPlaying?.streamUrl == streamUrl) {
                    playbackState.videoAspectRatio
                } else {
                    16f / 9f
                },
            ),
    ) {
        AndroidView(
            factory = { viewContext ->
                PlayerView(viewContext).apply {
                    useController = true
                    setShowSubtitleButton(true)
                    setShutterBackgroundColor(android.graphics.Color.BLACK)
                    keepScreenOn = true
                    layoutParams = android.view.ViewGroup.LayoutParams(
                        android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                        android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                    )
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    setFullscreenButtonClickListener { enter -> fullscreen = enter }
                }
            },
            update = { view ->
                view.player = ArixPlaybackController.player
                view.keepScreenOn = playbackState.isPlaying &&
                    playbackState.nowPlaying?.streamUrl == streamUrl
            },
            onRelease = { view -> view.player = null },
            modifier = Modifier.fillMaxSize(),
        )
        val playerError = playbackState.errorMessage
        if (playerError != null && playbackState.nowPlaying?.streamUrl == streamUrl) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
            ) {
                Text(
                    text = playerError,
                    color = Color(0xFFE5757A),
                    textAlign = TextAlign.Center,
                    style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "The stream could not be played. Try another source or link.",
                    color = Color(0xFF9AA0A6),
                    textAlign = TextAlign.Center,
                    style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                )
            }
        }
    }

    if (fullscreen) {
        Dialog(
            onDismissRequest = { fullscreen = false },
            properties = DialogProperties(
                usePlatformDefaultWidth = false,
                decorFitsSystemWindows = false,
                dismissOnBackPress = true,
            ),
        ) {
            val dialogView = LocalView.current
            LaunchedEffect(dialogView) {
                val window = (dialogView.parent as? DialogWindowProvider)?.window
                window?.let { w ->
                    WindowCompat.setDecorFitsSystemWindows(w, false)
                    val controller = WindowCompat.getInsetsController(w, w.decorView)
                    controller.systemBarsBehavior =
                        WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    controller.hide(WindowInsetsCompat.Type.systemBars())
                }
            }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black),
            ) {
                AndroidView(
                    factory = { viewContext ->
                        PlayerView(viewContext).apply {
                            useController = true
                            setShowSubtitleButton(true)
                            setShutterBackgroundColor(android.graphics.Color.BLACK)
                            keepScreenOn = true
                            layoutParams = android.view.ViewGroup.LayoutParams(
                                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                            )
                            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                            setPlayer(ArixPlaybackController.player)
                            setFullscreenButtonClickListener { enter -> fullscreen = enter }
                        }
                    },
                    update = { view ->
                        view.player = ArixPlaybackController.player
                        view.keepScreenOn = true
                    },
                    onRelease = { view -> view.player = null },
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }
    }
}

internal tailrec fun Context.findArixActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findArixActivity()
    else -> null
}
