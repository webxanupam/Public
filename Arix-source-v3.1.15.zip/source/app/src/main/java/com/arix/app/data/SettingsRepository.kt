package com.arix.app.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

private val Context.dataStore by preferencesDataStore(name = "arix_settings")

class SettingsRepository(
    private val context: Context,
) {
    suspend fun loadModelCatalogCache(): Map<String, ModelCatalogInfo> = context.dataStore.data.first()
        .let { preferences -> parseModelCatalogCache(preferences[MODEL_CATALOG_CACHE_JSON].orEmpty()) }

    suspend fun saveModelCatalogCache(cache: Map<String, ModelCatalogInfo>) {
        context.dataStore.edit { preferences ->
            val merged = parseModelCatalogCache(preferences[MODEL_CATALOG_CACHE_JSON].orEmpty()) + cache
            preferences[MODEL_CATALOG_CACHE_JSON] = serializeModelCatalogCache(merged)
        }
    }

    suspend fun loadThinkingCatalogCache(): Map<String, List<String>> = context.dataStore.data.first()
        .let { preferences -> parseThinkingCatalogCache(preferences[THINKING_CATALOG_CACHE_JSON].orEmpty()).levels }

    suspend fun loadThinkingLevelMapsCache(): Map<String, Map<String, String>> = context.dataStore.data.first()
        .let { preferences -> parseThinkingCatalogCache(preferences[THINKING_CATALOG_CACHE_JSON].orEmpty()).clamps }

    suspend fun loadReasoningModelsCache(): Set<String> = context.dataStore.data.first()
        .let { preferences -> parseThinkingCatalogCache(preferences[THINKING_CATALOG_CACHE_JSON].orEmpty()).reasoningModels }

    suspend fun loadModelLimitsCache(): Map<String, ModelsDevModelLimits> = context.dataStore.data.first()
        .let { preferences -> parseThinkingCatalogCache(preferences[THINKING_CATALOG_CACHE_JSON].orEmpty()).limits }

    suspend fun saveThinkingCatalogCache(
        cache: Map<String, List<String>>,
        levelMaps: Map<String, Map<String, String>> = emptyMap(),
        reasoningModels: Set<String> = emptySet(),
        limits: Map<String, ModelsDevModelLimits> = emptyMap(),
    ) {
        if (cache.isEmpty() && levelMaps.isEmpty() && reasoningModels.isEmpty() && limits.isEmpty()) return
        context.dataStore.edit { preferences ->
            val existing = parseThinkingCatalogCache(preferences[THINKING_CATALOG_CACHE_JSON].orEmpty())
            val mergedLevels = existing.levels + cache
            val mergedLevelMaps = (existing.clamps - cache.keys) + levelMaps
            val mergedReasoningModels = (existing.reasoningModels - cache.keys) + reasoningModels
            val mergedLimits = if (limits.isEmpty()) {
                existing.limits
            } else {
                (existing.limits - limits.keys) + limits
            }
            preferences[THINKING_CATALOG_CACHE_JSON] = serializeThinkingCatalogCache(
                mergedLevels,
                mergedLevelMaps,
                mergedReasoningModels,
                mergedLimits,
            )
        }
    }
    suspend fun initializeLanguageIfNeeded() {
        val preferences = context.dataStore.data.first()
        if (preferences[LANGUAGE] == null) {
            context.dataStore.edit { it[LANGUAGE] = defaultAppLanguage().storageValue }
        }
    }

    suspend fun initializeWebSearchEngineMigrationIfNeeded() {
        val preferences = context.dataStore.data.first()
        if (preferences[WEB_SEARCH_ENGINE_MIGRATED] != true) {
            val stored = preferences[WEB_SEARCH_ENGINE]
            val migrated = when {
                stored.isNullOrBlank() -> DefaultWebSearchEngine
                stored.trim().lowercase() == "duckduckgo" -> "google"
                else -> stored
            }
            context.dataStore.edit {
                it[WEB_SEARCH_ENGINE] = migrated
                it[WEB_SEARCH_ENGINE_MIGRATED] = true
            }
        }
        if (preferences[WEB_SEARCH_ENGINE_REVERTED_V311] != true) {
            val stored = context.dataStore.data.first()[WEB_SEARCH_ENGINE]
            val reverted = when {
                stored.isNullOrBlank() -> DefaultWebSearchEngine
                stored.trim().lowercase() == "google" -> "duckduckgo"
                else -> stored
            }
            context.dataStore.edit {
                it[WEB_SEARCH_ENGINE] = reverted
                it[WEB_SEARCH_ENGINE_REVERTED_V311] = true
            }
        }
    }

    private fun resolveWebSearchEngineWithMigration(
        preferences: androidx.datastore.preferences.core.Preferences,
    ): String {
        if (preferences[WEB_SEARCH_ENGINE_MIGRATED] == true) {
            return normalizeWebSearchEngine(preferences[WEB_SEARCH_ENGINE])
        }
        val stored = preferences[WEB_SEARCH_ENGINE]
        return when {
            stored.isNullOrBlank() -> DefaultWebSearchEngine
            stored.trim().lowercase() == "duckduckgo" -> "google"
            else -> normalizeWebSearchEngine(stored)
        }.let { migrated ->
            if (preferences[WEB_SEARCH_ENGINE_REVERTED_V311] == true) {
                normalizeWebSearchEngine(migrated)
            } else {
                if (migrated.trim().lowercase() == "google") "duckduckgo" else migrated
            }
        }
    }

    val settings: Flow<AppSettings> = context.dataStore.data.map { preferences ->
        val defaults = AppSettings()
        val storedWorkspaceMode = AgentWorkspaceMode.fromStorage(preferences[AGENT_WORKSPACE_MODE])
        val storedBaseUrl = preferences[BASE_URL] ?: defaults.baseUrl
        AppSettings(
            piProviderId = preferences[PI_PROVIDER_ID]
                ?.takeIf(String::isNotBlank)
                ?: inferLegacyPiProviderId(preferences[PROVIDER], storedBaseUrl),
            providerConfigId = preferences[PROVIDER_CONFIG_ID].orEmpty(),
            providerAuthMethod = ProviderAuthMethod.fromStorage(preferences[PROVIDER_AUTH_METHOD]),
            apiKey = preferences[API_KEY].orEmpty(),
            apiKeys = parseStringArray(preferences[API_KEYS].orEmpty()),
            multiKeyEnabled = preferences[MULTI_KEY_ENABLED] ?: true,
            keyRotationStrategy = preferences[KEY_ROTATION_STRATEGY]
                ?.takeIf(String::isNotBlank)
                ?: com.arix.app.data.KeyRotationStrategySequential,
            keyCooldownMinutes = (preferences[KEY_COOLDOWN_MINUTES] ?: 5)
                .coerceIn(0, 120),
            keySwitchStatusCodes = parseStringArray(preferences[KEY_SWITCH_STATUS_CODES].orEmpty())
                .mapNotNull { it.trim().toIntOrNull() }
                .filter { it in 100..599 }
                .distinct(),
            oauthCredentialJson = preferences[OAUTH_CREDENTIAL_JSON].orEmpty(),
            providerEnvironmentVariables = parseProviderEnvironmentVariables(
                preferences[PROVIDER_ENVIRONMENT_VARIABLES]
                    ?.let { raw -> runCatching { JSONArray(raw) }.getOrNull() },
            ),
            baseUrl = storedBaseUrl,
            modelId = preferences[MODEL_ID] ?: defaults.modelId,
            userAgent = normalizeLlmUserAgent(preferences[USER_AGENT]),
            customHeaders = parseCustomHeaders(preferences[CUSTOM_HEADERS].orEmpty()),
            serviceTier = preferences[SERVICE_TIER].orEmpty(),
            compatibilityMode = preferences[COMPATIBILITY_MODE] ?: false,
            developerRoleUnsupported = preferences[DEVELOPER_ROLE_UNSUPPORTED] ?: false,
            reasoningEffort = normalizeReasoningEffort(preferences[REASONING_EFFORT]),
            systemPrompt = preferences[SYSTEM_PROMPT] ?: defaults.systemPrompt,
            tavilyApiKey = preferences[TAVILY_API_KEY].orEmpty(),
            tavilyBaseUrl = normalizeTavilyBaseUrl(
                preferences[TAVILY_BASE_URL] ?: defaults.tavilyBaseUrl,
            ),
            webSearchEngine = resolveWebSearchEngineWithMigration(preferences),
            saveResearchToMemory = preferences[SAVE_RESEARCH_TO_MEMORY] ?: false,
            unrestrictedMode = preferences[UNRESTRICTED_MODE] ?: false,
            llmInactivityReconnectTimeoutSeconds = normalizeLlmInactivityReconnectTimeoutSeconds(
                preferences[LLM_INACTIVITY_RECONNECT_TIMEOUT_SECONDS]
            ),
            keepTasksRunningInBackground = preferences[KEEP_TASKS_RUNNING_IN_BACKGROUND] ?: true,
            notifyOnTaskCompletion = preferences[NOTIFY_ON_TASK_COMPLETION] ?: true,
            agentWorkspaceMode = if (preferences[WORKSPACE_MODE_INITIALIZED] == true) {
                storedWorkspaceMode
            } else {
                defaults.agentWorkspaceMode
            },
            autoCleanOldCommandHistory =
                preferences[AUTO_CLEAN_OLD_COMMAND_HISTORY] ?: true,
            oldCommandHistoryRetentionHours = normalizeOldCommandHistoryRetentionHours(
                preferences[OLD_COMMAND_HISTORY_RETENTION_HOURS],
            ),
            enabledRuntimeIds = resolveEnabledRuntimeIds(
                rawValue = preferences[ENABLED_RUNTIME_IDS],
                termuxSetupCompleted = preferences[ALPINE_SETUP_COMPLETED] ?: false,
            ),
            defaultRuntimeId = resolveDefaultRuntimeId(
                rawValue = preferences[DEFAULT_RUNTIME_ID],
                enabledRuntimeIds = resolveEnabledRuntimeIds(
                    rawValue = preferences[ENABLED_RUNTIME_IDS],
                    termuxSetupCompleted = preferences[ALPINE_SETUP_COMPLETED] ?: false,
                ),
                termuxSetupCompleted = preferences[ALPINE_SETUP_COMPLETED] ?: false,
            ),
            termuxSetupCompleted = preferences[ALPINE_SETUP_COMPLETED] ?: false,
            termuxEnvironmentVariables = parseTermuxEnvironmentVariables(
                preferences[ALPINE_ENVIRONMENT_VARIABLES].orEmpty()
            ),
            language = AppLanguage.fromStorage(preferences[LANGUAGE]),
            themeMode = AppThemeMode.fromStorage(preferences[THEME_MODE]),
            defaultChatModelKey = preferences[DEFAULT_CHAT_MODEL_KEY].orEmpty(),
            defaultTitleModelKey = preferences[DEFAULT_TITLE_MODEL_KEY].orEmpty(),
            defaultNamingModelKey = preferences[DEFAULT_NAMING_MODEL_KEY].orEmpty(),
            defaultCompactingModelKey = preferences[DEFAULT_COMPACTING_MODEL_KEY].orEmpty(),
            defaultSelectedSkillIds = parseStringArray(
                preferences[DEFAULT_SELECTED_SKILL_IDS].orEmpty()
            ),
            onboardingSeenVersion = preferences[ONBOARDING_SEEN_VERSION] ?: 0,
            onboardingCompletedVersion = preferences[ONBOARDING_COMPLETED_VERSION] ?: 0,
            privacyPolicyAccepted = preferences[PRIVACY_POLICY_ACCEPTED] ?: false,
        )
    }

    val providerConfigs: Flow<List<LlmProviderConfig>> = context.dataStore.data.map { preferences ->
        parseProviderConfigs(preferences[PROVIDER_CONFIGS].orEmpty())
    }

    suspend fun migrateLegacyProvidersToPi() {
        context.dataStore.edit { prefs ->
            val rawConfigs = prefs[PROVIDER_CONFIGS].orEmpty()
            val parsedConfigs = parseProviderConfigs(rawConfigs).toMutableList()
            val requiresConfigMigration = runCatching {
                val array = JSONArray(rawConfigs)
                (0 until array.length()).any { index ->
                    val item = array.optJSONObject(index)
                    item != null && (
                        item.optString("piProviderId").isBlank() ||
                            item.optString("authMethod").isBlank() ||
                            item.has("providerType") ||
                            item.has("basicFunctionCallingCompatibilityMode")
                        )
                }
            }.getOrDefault(false)
            if (
                !requiresConfigMigration &&
                prefs[PI_PROVIDER_ID]?.isNotBlank() == true &&
                prefs[PROVIDER_AUTH_METHOD]?.isNotBlank() == true &&
                prefs[PROVIDER] == null
            ) {
                return@edit
            }
            val legacyBaseUrl = prefs[BASE_URL] ?: AppSettings().baseUrl
            val legacyApiKey = prefs[API_KEY].orEmpty()
            val legacyModelId = prefs[MODEL_ID] ?: AppSettings().modelId
            val migratedPiProviderId = prefs[PI_PROVIDER_ID]
                ?.takeIf(String::isNotBlank)
                ?: inferLegacyPiProviderId(prefs[PROVIDER], legacyBaseUrl)
            val definition = PiProviderCatalog.resolve(migratedPiProviderId)
            var matchingConfig = prefs[PROVIDER_CONFIG_ID]
                ?.let { currentId -> parsedConfigs.firstOrNull { it.id == currentId } }
                ?: parsedConfigs.firstOrNull { config ->
                    config.piProviderId == definition.id &&
                        config.baseUrl.trim() == legacyBaseUrl.trim() &&
                        config.apiKey.trim() == legacyApiKey.trim() &&
                        config.availableModels().contains(legacyModelId.trim())
                }

            val hasLegacySingleProvider = prefs[PROVIDER] != null ||
                prefs[API_KEY]?.isNotBlank() == true ||
                prefs[BASE_URL]?.isNotBlank() == true ||
                prefs[MODEL_ID]?.isNotBlank() == true
            if (matchingConfig == null && hasLegacySingleProvider) {
                val baseProviderId = definition.id.sanitizeProviderId()
                    .ifBlank { "provider" }
                val migratedProviderId = generateSequence(baseProviderId) { current ->
                    val suffix = current.substringAfterLast('_').toIntOrNull()
                    "${baseProviderId}_${(suffix ?: 1) + 1}"
                }.first { candidate -> parsedConfigs.none { it.providerId == candidate } }
                matchingConfig = LlmProviderConfig(
                    id = UUID.randomUUID().toString(),
                    providerId = migratedProviderId,
                    name = definition.displayName,
                    piProviderId = definition.id,
                    authMethod = definition.defaultAuthMethod(),
                    apiKey = legacyApiKey,
                    baseUrl = legacyBaseUrl.ifBlank { definition.defaultBaseUrl },
                    modelId = legacyModelId.ifBlank { definition.defaultModelId },
                    manualModelIds = listOf(
                        legacyModelId.ifBlank { definition.defaultModelId },
                    ).filter(String::isNotBlank),
                    enabledModelIds = listOf(
                        legacyModelId.ifBlank { definition.defaultModelId },
                    ).filter(String::isNotBlank),
                )
                parsedConfigs += matchingConfig
            }

            if (requiresConfigMigration || matchingConfig != null) {
                prefs[PROVIDER_CONFIGS] = serializeProviderConfigs(parsedConfigs)
            }
            prefs[PI_PROVIDER_ID] = definition.id
            prefs[PROVIDER_AUTH_METHOD] = (
                matchingConfig?.authMethod ?: definition.defaultAuthMethod()
                ).storageValue
            matchingConfig?.let { config ->
                prefs[PROVIDER_CONFIG_ID] = config.id
                prefs[API_KEY] = config.apiKey
                prefs[API_KEYS] = serializeStringArray(config.apiKeys)
                prefs[MULTI_KEY_ENABLED] = config.multiKeyEnabled
                prefs[KEY_ROTATION_STRATEGY] = config.keyRotationStrategy
                prefs[KEY_COOLDOWN_MINUTES] = config.keyCooldownMinutes.coerceIn(0, 120)
                prefs[KEY_SWITCH_STATUS_CODES] = serializeStringArray(
                    config.keySwitchStatusCodes.map(Int::toString),
                )
                prefs[OAUTH_CREDENTIAL_JSON] = config.oauthCredentialJson
                prefs[PROVIDER_ENVIRONMENT_VARIABLES] =
                    serializeProviderEnvironmentVariables(
                        config.providerEnvironmentVariables,
                    )
                prefs[BASE_URL] = config.baseUrl
                prefs[MODEL_ID] = legacyModelId.ifBlank { config.modelId }
                prefs[USER_AGENT] = normalizeLlmUserAgent(config.userAgent)
            }
            prefs.remove(PROVIDER)
            prefs.remove(BASIC_FUNCTION_CALLING_COMPATIBILITY_MODE)
            prefs.remove(UNSUPPORTED_PARALLEL_TOOL_CALL_PROVIDER_KEYS)
        }
    }

    suspend fun upsertProviderConfig(config: LlmProviderConfig) {
        context.dataStore.edit { prefs ->
            val current = parseProviderConfigs(prefs[PROVIDER_CONFIGS].orEmpty()).toMutableList()
            val existingIndex = current.indexOfFirst { it.id == config.id }
            val updatedConfig = config.copy(updatedAtMillis = System.currentTimeMillis())
            if (existingIndex >= 0) {
                current[existingIndex] = updatedConfig
            } else {
                current.add(updatedConfig)
            }
            prefs[PROVIDER_CONFIGS] = serializeProviderConfigs(current)
        }
    }

    suspend fun removeProviderConfig(id: String) {
        context.dataStore.edit { prefs ->
            val current = parseProviderConfigs(prefs[PROVIDER_CONFIGS].orEmpty())
            val updated = current.filter { it.id != id }
            prefs[PROVIDER_CONFIGS] = serializeProviderConfigs(updated)
        }
    }

    suspend fun updateProviderOAuthCredential(
        id: String,
        credentialJson: String,
    ) {
        if (id.isBlank() || credentialJson.isBlank()) return
        context.dataStore.edit { prefs ->
            val current = parseProviderConfigs(prefs[PROVIDER_CONFIGS].orEmpty())
            val updated = current.map { config ->
                if (config.id == id) {
                    config.copy(
                        oauthCredentialJson = credentialJson,
                        updatedAtMillis = System.currentTimeMillis(),
                    )
                } else {
                    config
                }
            }
            prefs[PROVIDER_CONFIGS] = serializeProviderConfigs(updated)
            if (prefs[PROVIDER_CONFIG_ID] == id) {
                prefs[OAUTH_CREDENTIAL_JSON] = credentialJson
            }
        }
    }

    suspend fun setProviderDeveloperRoleUnsupported(
        id: String,
        unsupported: Boolean,
    ) {
        if (id.isBlank()) return
        context.dataStore.edit { prefs ->
            val current = parseProviderConfigs(prefs[PROVIDER_CONFIGS].orEmpty())
            val updated = current.map { config ->
                if (config.id == id && config.developerRoleUnsupported != unsupported) {
                    config.copy(
                        developerRoleUnsupported = unsupported,
                        updatedAtMillis = System.currentTimeMillis(),
                    )
                } else {
                    config
                }
            }
            prefs[PROVIDER_CONFIGS] = serializeProviderConfigs(updated)
        }
    }

    suspend fun setProviderEnabled(
        id: String,
        enabled: Boolean,
    ) {
        context.dataStore.edit { prefs ->
            val current = parseProviderConfigs(prefs[PROVIDER_CONFIGS].orEmpty())
            val currentPiProviderId = prefs[PI_PROVIDER_ID]
                ?.takeIf(String::isNotBlank)
                ?: inferLegacyPiProviderId(
                    prefs[PROVIDER],
                    prefs[BASE_URL] ?: AppSettings().baseUrl,
                )
            val currentProviderConfigId = prefs[PROVIDER_CONFIG_ID].orEmpty()
            val currentApiKey = prefs[API_KEY].orEmpty()
            val currentBaseUrl = prefs[BASE_URL] ?: AppSettings().baseUrl
            val currentModelId = prefs[MODEL_ID] ?: AppSettings().modelId
            val toggledConfigWasCurrent = current
                .firstOrNull { it.id == id }
                ?.matchesStoredModel(
                    piProviderId = currentPiProviderId,
                    providerConfigId = currentProviderConfigId,
                    apiKey = currentApiKey,
                    baseUrl = currentBaseUrl,
                    modelId = currentModelId,
                ) == true
            val updated = current.map { config ->
                if (config.id == id) config.copy(isEnabled = enabled) else config
            }
            prefs[PROVIDER_CONFIGS] = serializeProviderConfigs(updated)

            val availableOptions = updated.availableModelOptions()
            val currentStillAvailable = availableOptions.any {
                it.matchesStoredModel(
                    piProviderId = currentPiProviderId,
                    providerConfigId = currentProviderConfigId,
                    apiKey = currentApiKey,
                    baseUrl = currentBaseUrl,
                    modelId = currentModelId,
                )
            }
            val fallbackOption = availableOptions.firstOrNull()
            if (!enabled && toggledConfigWasCurrent && !currentStillAvailable && fallbackOption != null) {
                prefs[PI_PROVIDER_ID] = fallbackOption.piProviderId
                prefs[PROVIDER_CONFIG_ID] = fallbackOption.providerConfigId
                prefs[PROVIDER_AUTH_METHOD] = fallbackOption.authMethod.storageValue
                prefs[API_KEY] = fallbackOption.apiKey
                prefs[API_KEYS] = serializeStringArray(
                    fallbackOption.apiKeys.filter { it != fallbackOption.apiKey },
                )
                prefs[MULTI_KEY_ENABLED] = fallbackOption.multiKeyEnabled
                prefs[KEY_ROTATION_STRATEGY] = fallbackOption.keyRotationStrategy
                prefs[KEY_COOLDOWN_MINUTES] = fallbackOption.keyCooldownMinutes.coerceIn(0, 120)
                prefs[KEY_SWITCH_STATUS_CODES] = serializeStringArray(
                    fallbackOption.keySwitchStatusCodes.map(Int::toString),
                )
                prefs[OAUTH_CREDENTIAL_JSON] = fallbackOption.oauthCredentialJson
                prefs[PROVIDER_ENVIRONMENT_VARIABLES] = serializeProviderEnvironmentVariables(
                    fallbackOption.providerEnvironmentVariables,
                )
                prefs[BASE_URL] = fallbackOption.baseUrl
                prefs[MODEL_ID] = fallbackOption.modelId
                prefs[USER_AGENT] = normalizeLlmUserAgent(fallbackOption.userAgent)
                prefs[CUSTOM_HEADERS] = serializeCustomHeaders(fallbackOption.customHeaders)
                prefs[SERVICE_TIER] = fallbackOption.serviceTier
                prefs[COMPATIBILITY_MODE] = fallbackOption.compatibilityMode
                prefs[DEVELOPER_ROLE_UNSUPPORTED] = fallbackOption.developerRoleUnsupported
            }
        }
    }

    suspend fun replaceImportedSettings(
        settings: AppSettings,
        providerConfigs: List<LlmProviderConfig>,
    ) {
        context.dataStore.edit {
            it[PI_PROVIDER_ID] = settings.piProviderId
            it[PROVIDER_CONFIG_ID] = settings.providerConfigId
            it[PROVIDER_AUTH_METHOD] = settings.providerAuthMethod.storageValue
            it[API_KEY] = settings.apiKey
            it[API_KEYS] = serializeStringArray(settings.apiKeys)
            it[MULTI_KEY_ENABLED] = settings.multiKeyEnabled
            it[KEY_ROTATION_STRATEGY] = settings.keyRotationStrategy
            it[KEY_COOLDOWN_MINUTES] = settings.keyCooldownMinutes.coerceIn(0, 120)
            it[KEY_SWITCH_STATUS_CODES] = serializeStringArray(
                settings.keySwitchStatusCodes.map(Int::toString),
            )
            it[OAUTH_CREDENTIAL_JSON] = settings.oauthCredentialJson
            it[PROVIDER_ENVIRONMENT_VARIABLES] = serializeProviderEnvironmentVariables(
                settings.providerEnvironmentVariables,
            )
            it[BASE_URL] = settings.baseUrl
            it[MODEL_ID] = settings.modelId
            it[USER_AGENT] = normalizeLlmUserAgent(settings.userAgent)
            it[CUSTOM_HEADERS] = serializeCustomHeaders(settings.customHeaders)
            it[SERVICE_TIER] = settings.serviceTier
            it[COMPATIBILITY_MODE] = settings.compatibilityMode
            it[DEVELOPER_ROLE_UNSUPPORTED] = settings.developerRoleUnsupported
            it[REASONING_EFFORT] = normalizeReasoningEffort(settings.reasoningEffort)
            it[SYSTEM_PROMPT] = settings.systemPrompt
            it[TAVILY_API_KEY] = settings.tavilyApiKey
            it[TAVILY_BASE_URL] = normalizeTavilyBaseUrl(settings.tavilyBaseUrl)
            it[WEB_SEARCH_ENGINE] = normalizeWebSearchEngine(settings.webSearchEngine)
            it[SAVE_RESEARCH_TO_MEMORY] = settings.saveResearchToMemory
            it[UNRESTRICTED_MODE] = settings.unrestrictedMode
            it[LLM_INACTIVITY_RECONNECT_TIMEOUT_SECONDS] =
                normalizeLlmInactivityReconnectTimeoutSeconds(
                    settings.llmInactivityReconnectTimeoutSeconds
                )
            it[KEEP_TASKS_RUNNING_IN_BACKGROUND] = settings.keepTasksRunningInBackground
            it[NOTIFY_ON_TASK_COMPLETION] = settings.notifyOnTaskCompletion
            it[AGENT_WORKSPACE_MODE] = settings.agentWorkspaceMode.storageValue
            it[WORKSPACE_MODE_INITIALIZED] = true
            it[AUTO_CLEAN_OLD_COMMAND_HISTORY] = settings.autoCleanOldCommandHistory
            it[OLD_COMMAND_HISTORY_RETENTION_HOURS] =
                normalizeOldCommandHistoryRetentionHours(settings.oldCommandHistoryRetentionHours)
            it[ENABLED_RUNTIME_IDS] = serializeRuntimeIds(settings.enabledRuntimeIds)
            settings.defaultRuntimeId?.let { runtimeId ->
                it[DEFAULT_RUNTIME_ID] = runtimeId.storageValue
            } ?: it.remove(DEFAULT_RUNTIME_ID)
            it[ALPINE_SETUP_COMPLETED] = settings.termuxSetupCompleted
            it[ALPINE_ENVIRONMENT_VARIABLES] =
                serializeTermuxEnvironmentVariables(settings.termuxEnvironmentVariables)
            it[LANGUAGE] = settings.language.storageValue
            it[THEME_MODE] = settings.themeMode.storageValue
            it[DEFAULT_CHAT_MODEL_KEY] = settings.defaultChatModelKey
            it[DEFAULT_TITLE_MODEL_KEY] = settings.defaultTitleModelKey
            it[DEFAULT_NAMING_MODEL_KEY] = settings.defaultNamingModelKey
            it[DEFAULT_COMPACTING_MODEL_KEY] = settings.defaultCompactingModelKey
            it[DEFAULT_SELECTED_SKILL_IDS] = serializeStringArray(settings.defaultSelectedSkillIds)
            it.remove(PROVIDER)
            it.remove(BASIC_FUNCTION_CALLING_COMPATIBILITY_MODE)
            it.remove(UNSUPPORTED_PARALLEL_TOOL_CALL_PROVIDER_KEYS)
            it[ONBOARDING_SEEN_VERSION] = settings.onboardingSeenVersion
            it[ONBOARDING_COMPLETED_VERSION] = settings.onboardingCompletedVersion
            it[PRIVACY_POLICY_ACCEPTED] =
                (it[PRIVACY_POLICY_ACCEPTED] ?: false) || settings.privacyPolicyAccepted
            it[PROVIDER_CONFIGS] = serializeProviderConfigs(providerConfigs)
        }
    }

    suspend fun updateLanguage(language: AppLanguage) {
        context.dataStore.edit { it[LANGUAGE] = language.storageValue }
    }

    suspend fun updateSettings(settings: AppSettings) {
        context.dataStore.edit {
            it[PI_PROVIDER_ID] = settings.piProviderId
            it[PROVIDER_CONFIG_ID] = settings.providerConfigId
            it[PROVIDER_AUTH_METHOD] = settings.providerAuthMethod.storageValue
            it[API_KEY] = settings.apiKey
            it[API_KEYS] = serializeStringArray(settings.apiKeys)
            it[MULTI_KEY_ENABLED] = settings.multiKeyEnabled
            it[KEY_ROTATION_STRATEGY] = settings.keyRotationStrategy
            it[KEY_COOLDOWN_MINUTES] = settings.keyCooldownMinutes.coerceIn(0, 120)
            it[KEY_SWITCH_STATUS_CODES] = serializeStringArray(
                settings.keySwitchStatusCodes.map(Int::toString),
            )
            it[OAUTH_CREDENTIAL_JSON] = settings.oauthCredentialJson
            it[PROVIDER_ENVIRONMENT_VARIABLES] = serializeProviderEnvironmentVariables(
                settings.providerEnvironmentVariables,
            )
            it[BASE_URL] = settings.baseUrl
            it[MODEL_ID] = settings.modelId
            it[USER_AGENT] = normalizeLlmUserAgent(settings.userAgent)
            it[CUSTOM_HEADERS] = serializeCustomHeaders(settings.customHeaders)
            it[SERVICE_TIER] = settings.serviceTier
            it[COMPATIBILITY_MODE] = settings.compatibilityMode
            it[DEVELOPER_ROLE_UNSUPPORTED] = settings.developerRoleUnsupported
            it[REASONING_EFFORT] = normalizeReasoningEffort(settings.reasoningEffort)
            it[SYSTEM_PROMPT] = settings.systemPrompt
            it[TAVILY_API_KEY] = settings.tavilyApiKey
            it[TAVILY_BASE_URL] = normalizeTavilyBaseUrl(settings.tavilyBaseUrl)
            it[WEB_SEARCH_ENGINE] = normalizeWebSearchEngine(settings.webSearchEngine)
            it[SAVE_RESEARCH_TO_MEMORY] = settings.saveResearchToMemory
            it[UNRESTRICTED_MODE] = settings.unrestrictedMode
            it[LLM_INACTIVITY_RECONNECT_TIMEOUT_SECONDS] =
                normalizeLlmInactivityReconnectTimeoutSeconds(
                    settings.llmInactivityReconnectTimeoutSeconds
                )
            it[KEEP_TASKS_RUNNING_IN_BACKGROUND] = settings.keepTasksRunningInBackground
            it[NOTIFY_ON_TASK_COMPLETION] = settings.notifyOnTaskCompletion
            it[AGENT_WORKSPACE_MODE] = settings.agentWorkspaceMode.storageValue
            it[WORKSPACE_MODE_INITIALIZED] = true
            it[AUTO_CLEAN_OLD_COMMAND_HISTORY] = settings.autoCleanOldCommandHistory
            it[OLD_COMMAND_HISTORY_RETENTION_HOURS] =
                normalizeOldCommandHistoryRetentionHours(settings.oldCommandHistoryRetentionHours)
            it[ENABLED_RUNTIME_IDS] = serializeRuntimeIds(settings.enabledRuntimeIds)
            settings.defaultRuntimeId?.let { runtimeId ->
                it[DEFAULT_RUNTIME_ID] = runtimeId.storageValue
            } ?: it.remove(DEFAULT_RUNTIME_ID)
            it[ALPINE_SETUP_COMPLETED] = settings.termuxSetupCompleted
            it[ALPINE_ENVIRONMENT_VARIABLES] =
                serializeTermuxEnvironmentVariables(settings.termuxEnvironmentVariables)
            it[LANGUAGE] = settings.language.storageValue
            it[THEME_MODE] = settings.themeMode.storageValue
            it[DEFAULT_CHAT_MODEL_KEY] = settings.defaultChatModelKey
            it[DEFAULT_TITLE_MODEL_KEY] = settings.defaultTitleModelKey
            it[DEFAULT_NAMING_MODEL_KEY] = settings.defaultNamingModelKey
            it[DEFAULT_COMPACTING_MODEL_KEY] = settings.defaultCompactingModelKey
            it[DEFAULT_SELECTED_SKILL_IDS] = serializeStringArray(settings.defaultSelectedSkillIds)
            it.remove(PROVIDER)
            it.remove(BASIC_FUNCTION_CALLING_COMPATIBILITY_MODE)
            it.remove(UNSUPPORTED_PARALLEL_TOOL_CALL_PROVIDER_KEYS)
            it[PRIVACY_POLICY_ACCEPTED] =
                (it[PRIVACY_POLICY_ACCEPTED] ?: false) || settings.privacyPolicyAccepted
        }
    }

    suspend fun updatePrivacyPolicyAccepted(accepted: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[PRIVACY_POLICY_ACCEPTED] = accepted
        }
    }

    suspend fun updateOnboardingSeenVersion(version: Int) {
        context.dataStore.edit { prefs ->
            prefs[ONBOARDING_SEEN_VERSION] = version
        }
    }

    suspend fun updateDefaultSelectedSkillIds(skillIds: List<String>) {
        context.dataStore.edit { preferences ->
            preferences[DEFAULT_SELECTED_SKILL_IDS] = serializeStringArray(skillIds)
        }
    }

    suspend fun isWorkspaceModeInitialized(): Boolean =
        context.dataStore.data.map { preferences ->
            preferences[WORKSPACE_MODE_INITIALIZED] ?: false
        }.first()

    private companion object {
        val PROVIDER = stringPreferencesKey("provider")
        val PI_PROVIDER_ID = stringPreferencesKey("pi_provider_id")
        val PROVIDER_CONFIG_ID = stringPreferencesKey("provider_config_id")
        val PROVIDER_AUTH_METHOD = stringPreferencesKey("provider_auth_method")
        val API_KEY = stringPreferencesKey("api_key")
        val API_KEYS = stringPreferencesKey("api_keys")
        val MULTI_KEY_ENABLED = booleanPreferencesKey("multi_key_enabled")
        val KEY_ROTATION_STRATEGY = stringPreferencesKey("key_rotation_strategy")
        val KEY_COOLDOWN_MINUTES = intPreferencesKey("key_cooldown_minutes")
        val KEY_SWITCH_STATUS_CODES = stringPreferencesKey("key_switch_status_codes")
        val OAUTH_CREDENTIAL_JSON = stringPreferencesKey("oauth_credential_json")
        val PROVIDER_ENVIRONMENT_VARIABLES = stringPreferencesKey("provider_environment_variables")
        val BASE_URL = stringPreferencesKey("base_url")
        val MODEL_ID = stringPreferencesKey("model_id")
        val USER_AGENT = stringPreferencesKey("user_agent")
        val CUSTOM_HEADERS = stringPreferencesKey("custom_headers")
        val SERVICE_TIER = stringPreferencesKey("service_tier")
        val COMPATIBILITY_MODE = booleanPreferencesKey("compatibility_mode")
        val DEVELOPER_ROLE_UNSUPPORTED = booleanPreferencesKey("developer_role_unsupported")
        val REASONING_EFFORT = stringPreferencesKey("reasoning_effort")
        val SYSTEM_PROMPT = stringPreferencesKey("system_prompt")
        val TAVILY_API_KEY = stringPreferencesKey("tavily_api_key")
        val TAVILY_BASE_URL = stringPreferencesKey("tavily_base_url")
        val WEB_SEARCH_ENGINE = stringPreferencesKey("web_search_engine")
        val WEB_SEARCH_ENGINE_MIGRATED =
            booleanPreferencesKey("web_search_engine_migrated_v310")
        val WEB_SEARCH_ENGINE_REVERTED_V311 =
            booleanPreferencesKey("web_search_engine_reverted_v311")
        val SAVE_RESEARCH_TO_MEMORY = booleanPreferencesKey("save_research_to_memory")
        val UNRESTRICTED_MODE = booleanPreferencesKey("unrestricted_mode")
        val LLM_INACTIVITY_RECONNECT_TIMEOUT_SECONDS =
            intPreferencesKey("llm_inactivity_reconnect_timeout_seconds")
        val KEEP_TASKS_RUNNING_IN_BACKGROUND =
            booleanPreferencesKey("keep_tasks_running_in_background")
        val NOTIFY_ON_TASK_COMPLETION =
            booleanPreferencesKey("notify_on_task_completion")
        val AGENT_WORKSPACE_MODE = stringPreferencesKey("agent_workspace_mode")
        val WORKSPACE_MODE_INITIALIZED =
            booleanPreferencesKey("workspace_mode_initialized")
        val AUTO_CLEAN_OLD_COMMAND_HISTORY =
            booleanPreferencesKey("auto_clean_old_command_history")
        val OLD_COMMAND_HISTORY_RETENTION_HOURS =
            intPreferencesKey("old_command_history_retention_hours")
        val ENABLED_RUNTIME_IDS =
            stringPreferencesKey("enabled_runtime_ids")
        val DEFAULT_RUNTIME_ID =
            stringPreferencesKey("default_runtime_id")
        val ALPINE_SETUP_COMPLETED =
            booleanPreferencesKey("termux_setup_completed")
        val ALPINE_ENVIRONMENT_VARIABLES =
            stringPreferencesKey("termux_environment_variables")
        val LANGUAGE = stringPreferencesKey("language")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val DEFAULT_CHAT_MODEL_KEY = stringPreferencesKey("default_chat_model_key")
        val DEFAULT_TITLE_MODEL_KEY = stringPreferencesKey("default_title_model_key")
        val DEFAULT_NAMING_MODEL_KEY = stringPreferencesKey("default_naming_model_key")
        val DEFAULT_COMPACTING_MODEL_KEY = stringPreferencesKey("default_compacting_model_key")
        val MODEL_CATALOG_CACHE_JSON = stringPreferencesKey("model_catalog_cache_json")
        val THINKING_CATALOG_CACHE_JSON = stringPreferencesKey("thinking_catalog_cache_json")
        val DEFAULT_SELECTED_SKILL_IDS = stringPreferencesKey("default_selected_skill_ids")
        val UNSUPPORTED_PARALLEL_TOOL_CALL_PROVIDER_KEYS =
            stringPreferencesKey("unsupported_parallel_tool_call_provider_keys")
        val BASIC_FUNCTION_CALLING_COMPATIBILITY_MODE =
            booleanPreferencesKey("basic_function_calling_compatibility_mode")
        val PROVIDER_CONFIGS = stringPreferencesKey("provider_configs")
        val ONBOARDING_SEEN_VERSION = intPreferencesKey("onboarding_seen_version")
        val ONBOARDING_COMPLETED_VERSION = intPreferencesKey("onboarding_completed_version")
        val PRIVACY_POLICY_ACCEPTED = booleanPreferencesKey("privacy_policy_accepted")

    }
}

private fun parseStringArray(rawValue: String): List<String> {
    if (rawValue.isBlank()) return emptyList()
    return runCatching {
        val array = JSONArray(rawValue)
        buildList {
            for (index in 0 until array.length()) {
                array.optString(index).trim().takeIf(String::isNotBlank)?.let(::add)
            }
        }.distinct()
    }.getOrDefault(emptyList())
}

private fun serializeStringArray(values: List<String>): String =
    JSONArray().apply {
        values.map(String::trim).filter(String::isNotBlank).distinct().forEach(::put)
    }.toString()

private fun LlmProviderConfig.matchesStoredModel(
    piProviderId: String,
    providerConfigId: String,
    apiKey: String,
    baseUrl: String,
    modelId: String,
): Boolean =
    (id == providerConfigId || this.piProviderId == piProviderId) &&
        this.apiKey.trim() == apiKey.trim() &&
        this.baseUrl.trim() == baseUrl.trim() &&
        enabledModels().contains(modelId.trim())

private fun ProviderModelOption.matchesStoredModel(
    piProviderId: String,
    providerConfigId: String,
    apiKey: String,
    baseUrl: String,
    modelId: String,
): Boolean =
    (this.providerConfigId == providerConfigId || this.piProviderId == piProviderId) &&
        this.apiKey.trim() == apiKey.trim() &&
        this.baseUrl.trim() == baseUrl.trim() &&
        this.modelId.trim() == modelId.trim()

private fun serializeProviderEnvironmentVariables(
    variables: List<PiProviderEnvironmentVariable>,
): String = JSONArray().apply {
    variables
        .mapNotNull { variable ->
            variable.name.trim().takeIf(String::isNotBlank)?.let { name ->
                PiProviderEnvironmentVariable(name, variable.value)
            }
        }
        .distinctBy { it.name.uppercase() }
        .forEach { variable ->
            put(
                JSONObject()
                    .put("name", variable.name)
                    .put("value", variable.value)
            )
        }
}.toString()

private val EnvironmentVariableNamePattern = Regex("^[A-Za-z_][A-Za-z0-9_]*$")

private val HostProcessLinkerCriticalVariables = setOf("LD_PRELOAD", "LD_LIBRARY_PATH")

fun normalizeTermuxEnvironmentVariables(
    variables: List<TermuxEnvironmentVariable>,
): List<TermuxEnvironmentVariable> =
    variables
        .mapNotNull { variable ->
            val name = variable.name.trim()
            if (!EnvironmentVariableNamePattern.matches(name)) {
                null
            } else {
                TermuxEnvironmentVariable(name = name, value = variable.value)
            }
        }
        .filterNot { variable ->
            variable.name in HostProcessLinkerCriticalVariables
        }
        .distinctBy { it.name }

private fun resolveEnabledRuntimeIds(
    rawValue: String?,
    termuxSetupCompleted: Boolean,
): Set<LocalRuntimeId> {
    val stored = parseRuntimeIds(rawValue.orEmpty())
    if (stored.isNotEmpty() || rawValue != null) return stored
    return buildSet {
        if (termuxSetupCompleted) add(LocalRuntimeId.Termux)
    }
}

private fun resolveDefaultRuntimeId(
    rawValue: String?,
    enabledRuntimeIds: Set<LocalRuntimeId>,
    termuxSetupCompleted: Boolean,
): LocalRuntimeId? {
    LocalRuntimeId.fromStorage(rawValue)?.let { runtimeId ->
        if (runtimeId in enabledRuntimeIds) return runtimeId
    }
    return when {
        termuxSetupCompleted && LocalRuntimeId.Termux in enabledRuntimeIds -> LocalRuntimeId.Termux
        else -> enabledRuntimeIds.filter { it == LocalRuntimeId.Termux }.firstOrNull()
    }
}

private fun parseRuntimeIds(rawValue: String): Set<LocalRuntimeId> {
    if (rawValue.isBlank()) return emptySet()
    return runCatching {
        val array = JSONArray(rawValue)
        buildSet {
            for (index in 0 until array.length()) {
                LocalRuntimeId.fromStorage(array.optString(index))?.let(::add)
            }
        }
    }.getOrDefault(emptySet())
}

private fun serializeRuntimeIds(runtimeIds: Set<LocalRuntimeId>): String =
    JSONArray().apply {
        runtimeIds.sortedBy { it.storageValue }.forEach { put(it.storageValue) }
    }.toString()

private fun parseTermuxEnvironmentVariables(rawValue: String): List<TermuxEnvironmentVariable> {
    if (rawValue.isBlank()) return emptyList()
    return runCatching {
        val array = JSONArray(rawValue)
        normalizeTermuxEnvironmentVariables(
            buildList {
                for (index in 0 until array.length()) {
                    val item = array.optJSONObject(index) ?: continue
                    add(
                        TermuxEnvironmentVariable(
                            name = item.optString("name"),
                            value = item.optString("value"),
                        )
                    )
                }
            }
        )
    }.getOrDefault(emptyList())
}

private fun serializeTermuxEnvironmentVariables(
    variables: List<TermuxEnvironmentVariable>,
): String =
    JSONArray().apply {
        normalizeTermuxEnvironmentVariables(variables).forEach { variable ->
            put(
                JSONObject().apply {
                    put("name", variable.name)
                    put("value", variable.value)
                }
            )
        }
    }.toString()

private fun serializeModelCatalogCache(cache: Map<String, ModelCatalogInfo>): String = JSONArray().apply {
    cache.forEach { (key, info) ->
        put(JSONObject().apply {
            put("key", key)
            put("displayName", info.displayName)
            put("labId", info.labId)
            put("labName", info.labName)
            put("labLogoUrl", info.labLogoUrl)
            put("labLogoPathData", JSONArray(info.labLogoPathData))
            put("labLogoViewportWidth", info.labLogoViewportWidth)
            put("labLogoViewportHeight", info.labLogoViewportHeight)
        })
    }
}.toString()

private fun parseModelCatalogCache(raw: String): Map<String, ModelCatalogInfo> = runCatching {
    val array = JSONArray(raw)
    buildMap {
        for (index in 0 until array.length()) {
            val item = array.optJSONObject(index) ?: continue
            val key = item.optString("key").takeIf(String::isNotBlank) ?: continue
            val paths = item.optJSONArray("labLogoPathData")?.let { values ->
                buildList { for (i in 0 until values.length()) add(values.optString(i)) }
            }.orEmpty()
            put(key, ModelCatalogInfo(
                displayName = item.optString("displayName"), labId = item.optString("labId"),
                labName = item.optString("labName"), labLogoUrl = item.optString("labLogoUrl"),
                labLogoPathData = paths,
                labLogoViewportWidth = item.optDouble("labLogoViewportWidth", 40.0).toFloat(),
                labLogoViewportHeight = item.optDouble("labLogoViewportHeight", 40.0).toFloat(),
            ))
        }
    }
}.getOrDefault(emptyMap())

private fun serializeThinkingCatalogCache(
    levels: Map<String, List<String>>,
    clamps: Map<String, Map<String, String>> = emptyMap(),
    reasoningModels: Set<String> = emptySet(),
    limits: Map<String, ModelsDevModelLimits> = emptyMap(),
): String = JSONArray().apply {
    val allKeys = (levels.keys + clamps.keys + reasoningModels + limits.keys).distinct()
    allKeys.forEach { key ->
        put(JSONObject().apply {
            put("key", key)
            put("reasoning", key in reasoningModels)
            levels[key]?.let { put("levels", JSONArray(it)) }
            clamps[key]?.let { clampMap ->
                if (clampMap.isNotEmpty()) {
                    put("clamps", JSONObject().apply {
                        clampMap.forEach { (k, v) -> put(k, v) }
                    })
                }
            }
            limits[key]?.let { modelLimits ->
                val hasAny = modelLimits.contextWindow != null ||
                    modelLimits.maxOutputTokens != null ||
                    modelLimits.supportsImageInput != null
                if (hasAny) {
                    put("limits", JSONObject().apply {
                        modelLimits.contextWindow?.let { put("context_window", it) }
                        modelLimits.maxOutputTokens?.let { put("max_output_tokens", it) }
                        modelLimits.supportsImageInput?.let { put("supports_image_input", it) }
                    })
                }
            }
        })
    }
}.toString()

private data class ThinkingCatalogCache(
    val levels: Map<String, List<String>> = emptyMap(),
    val clamps: Map<String, Map<String, String>> = emptyMap(),
    val reasoningModels: Set<String> = emptySet(),
    val limits: Map<String, ModelsDevModelLimits> = emptyMap(),
)

private fun parseThinkingCatalogCache(raw: String): ThinkingCatalogCache = runCatching {
    val array = JSONArray(raw)
    val levelsMap = mutableMapOf<String, List<String>>()
    val clampsMap = mutableMapOf<String, Map<String, String>>()
    val reasoningModels = mutableSetOf<String>()
    val limitsMap = mutableMapOf<String, ModelsDevModelLimits>()
    for (index in 0 until array.length()) {
        val item = array.optJSONObject(index) ?: continue
        val key = item.optString("key").takeIf(String::isNotBlank) ?: continue
        if (item.optBoolean("reasoning")) reasoningModels += key
        item.optJSONArray("levels")?.let { values ->
            val levels = buildList {
                for (i in 0 until values.length()) {
                    values.optString(i).trim().takeIf(String::isNotBlank)?.let(::add)
                }
            }
            levelsMap[key] = levels
        }
        item.optJSONObject("clamps")?.let { clampsObj ->
            val clamps = buildMap {
                for (k in clampsObj.keys()) {
                    clampsObj.optString(k).takeIf(String::isNotBlank)?.let { put(k, it) }
                }
            }
            if (clamps.isNotEmpty()) clampsMap[key] = clamps
        }
        item.optJSONObject("limits")?.let { limitsObj ->
            val modelLimits = ModelsDevModelLimits(
                contextWindow = limitsObj.optInt("context_window", 0).takeIf { it > 0 },
                maxOutputTokens = limitsObj.optInt("max_output_tokens", 0).takeIf { it > 0 },
                supportsImageInput = if (limitsObj.has("supports_image_input")) {
                    limitsObj.optBoolean("supports_image_input")
                } else {
                    null
                },
            )
            limitsMap[key] = modelLimits
        }
    }
    ThinkingCatalogCache(levelsMap, clampsMap, reasoningModels, limitsMap)
}.getOrDefault(ThinkingCatalogCache())

private fun parseCustomHeaders(rawValue: String): List<LlmCustomHeader> {
    if (rawValue.isBlank()) return emptyList()
    return runCatching {
        val array = JSONArray(rawValue)
        buildList {
            for (index in 0 until array.length()) {
                val item = array.optJSONObject(index) ?: continue
                val name = item.optString("name").trim()
                if (name.isNotBlank()) {
                    add(LlmCustomHeader(name = name, value = item.optString("value")))
                }
            }
        }
    }.getOrDefault(emptyList())
}

private fun serializeCustomHeaders(headers: List<LlmCustomHeader>): String =
    JSONArray().apply {
        headers.forEach { header ->
            if (header.name.isNotBlank()) {
                put(
                    JSONObject().apply {
                        put("name", header.name.trim())
                        put("value", header.value)
                    }
                )
            }
        }
    }.toString()
