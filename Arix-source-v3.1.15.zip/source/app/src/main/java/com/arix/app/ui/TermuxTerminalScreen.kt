package com.arix.app.ui

import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color as AndroidColor
import android.graphics.Typeface
import android.util.Log
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Launch
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.termux.terminal.KeyHandler
import com.termux.terminal.TerminalEmulator
import com.termux.terminal.TerminalSession
import com.termux.terminal.TerminalSessionClient
import com.termux.terminal.TerminalColors
import com.termux.terminal.TextStyle
import com.termux.view.TerminalView
import com.termux.view.TerminalViewClient
import com.arix.app.runtime.TermuxTerminalLaunchSpec
import com.arix.app.ui.theme.ArixBackground
import com.arix.app.ui.theme.ArixOnSurface
import com.arix.app.ui.theme.ArixOnSurfaceVariant
import com.arix.app.ui.theme.ArixPrimary
import com.arix.app.ui.theme.ArixSurface
import com.arix.app.ui.theme.ArixSurfaceHigh
import com.arix.app.ui.theme.ArixSurfaceHigher
import com.arix.app.ui.theme.ArixTertiary
import java.io.File
import kotlin.math.roundToInt

private object TermuxTerminalSessionHolder {
    private val sessions =
        java.util.concurrent.ConcurrentHashMap<String, TerminalSession>()
    private val titles = java.util.concurrent.ConcurrentHashMap<String, String>()

    fun session(key: String): TerminalSession? = sessions[key]

    fun storeSession(key: String, session: TerminalSession?) {
        if (session == null) sessions.remove(key) else sessions[key] = session
    }

    fun title(key: String): String = titles[key] ?: "Termux"

    fun storeTitle(key: String, value: String) {
        titles[key] = value
    }

    private val scope = kotlinx.coroutines.CoroutineScope(
        kotlinx.coroutines.SupervisorJob() + kotlinx.coroutines.Dispatchers.Main,
    )

    val backgroundCommands: TerminalBackgroundCommandsState by lazy {
        TerminalBackgroundCommandsState(scope)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TermuxTerminalScreen(
    createLaunchSpec: suspend () -> Result<TermuxTerminalLaunchSpec>,
    onBack: () -> Unit,
    screenTitle: String = "Termux",
    sessionKey: String = "main",
) {
    val context = LocalContext.current
    var launchSpec by remember { mutableStateOf<TermuxTerminalLaunchSpec?>(null) }
    var errorMessage by remember { mutableStateOf("") }
    var terminalView by remember { mutableStateOf<TerminalView?>(null) }
    var sessionRestartEpoch by remember { mutableIntStateOf(0) }
    var terminalSession by remember { mutableStateOf(TermuxTerminalSessionHolder.session(sessionKey)) }
    var title by remember { mutableStateOf(TermuxTerminalSessionHolder.title(sessionKey)) }
    var controlDown by remember { mutableStateOf(false) }
    var altDown by remember { mutableStateOf(false) }

    var quickCommands by remember { mutableStateOf<List<TerminalQuickCommand>>(emptyList()) }
    var showQuickCommands by remember { mutableStateOf(false) }
    var pendingLaunchCommand by remember { mutableStateOf<String?>(null) }

    val backgroundCommands = TermuxTerminalSessionHolder.backgroundCommands
    var showBackgroundCommands by remember { mutableStateOf(false) }

    val density = LocalDensity.current
    val terminalTextSizePx = remember(context) { defaultTermuxTerminalTextSizePx(context) }
    val terminalTypeface = remember(context) { embeddedTerminalTypeface(context) }
    val isDarkTheme = isSystemInDarkTheme()
    val terminalBackgroundColor = remember(isDarkTheme) {
        if (isDarkTheme) AndroidColor.BLACK else AndroidColor.WHITE
    }
    val terminalTextColor = remember(isDarkTheme) {
        if (isDarkTheme) AndroidColor.WHITE else AndroidColor.BLACK
    }

    LaunchedEffect(isDarkTheme) {
        val colorScheme = TerminalColors.COLOR_SCHEME
        colorScheme.mDefaultColors[TextStyle.COLOR_INDEX_BACKGROUND] = terminalBackgroundColor
        colorScheme.mDefaultColors[TextStyle.COLOR_INDEX_FOREGROUND] = terminalTextColor
        colorScheme.setCursorColorForBackground()
    }

    LaunchedEffect(sessionRestartEpoch) {
        val result = createLaunchSpec()
        result.fold(
            onSuccess = { launchSpec = it },
            onFailure = { errorMessage = it.message ?: "Unable to start Termux terminal." },
        )
    }

    LaunchedEffect(context) {
        quickCommands = TerminalQuickCommandsStore.loadCommands(context)
    }

    LaunchedEffect(pendingLaunchCommand, terminalSession) {
        val command = pendingLaunchCommand ?: return@LaunchedEffect
        val session = terminalSession ?: return@LaunchedEffect
        pendingLaunchCommand = null
        val bytes = ("$command\r").toByteArray(Charsets.UTF_8)
        runCatching { session.write(bytes, 0, bytes.size) }
        terminalView?.let { view ->
            view.requestFocus()
            showKeyboard(view.context, view)
        }
    }

    fun updateTerminalTitle(newTitle: String) {
        val resolved = newTitle.ifBlank { screenTitle }
        title = resolved
        TermuxTerminalSessionHolder.storeTitle(sessionKey, resolved)
    }

    fun restartFinishedSession() {
        val held = TermuxTerminalSessionHolder.session(sessionKey)
        if (held != null && held.isRunning) return
        terminalView?.let { view ->
            runCatching { view.setTerminalCursorBlinkerState(false, false) }
        }
        TermuxTerminalSessionHolder.storeSession(sessionKey, null)
        terminalSession = null
        launchSpec = null
        errorMessage = ""
        sessionRestartEpoch += 1
    }

    fun launchQuickCommand(command: TerminalQuickCommand) {
        val session = terminalSession
        if (session != null && !session.isRunning) {
            pendingLaunchCommand = command.command
            restartFinishedSession()
            showQuickCommands = false
            return
        }
        if (session == null) {
            pendingLaunchCommand = command.command
            Toast.makeText(
                context,
                "Launching when the terminal is ready…",
                Toast.LENGTH_SHORT,
            ).show()
        } else {
            val bytes = ("${command.command}\r").toByteArray(Charsets.UTF_8)
            runCatching { session.write(bytes, 0, bytes.size) }
            terminalView?.requestFocus()
        }
        showQuickCommands = false
    }

    DisposableEffect(Unit) {
        onDispose {
            terminalView?.let { view ->
                runCatching { view.setTerminalCursorBlinkerState(false, false) }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ArixBackground)
            .imePadding()
            .navigationBarsPadding(),
    ) {
        TerminalTopBar(
            title = title,
            onBack = onBack,
            quickCommandCount = quickCommands.size,
            onShowQuickCommands = {
                quickCommands = TerminalQuickCommandsStore.loadCommands(context)
                showQuickCommands = true
            },
            backgroundRunCount = backgroundCommands.runs.count { it.isRunning },
            onShowBackgroundCommands = {
                backgroundCommands.refreshAll()
                showBackgroundCommands = true
            },
        )

        val spec = launchSpec
        when {
            spec == null && errorMessage.isBlank() -> {
                Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    CircularProgressIndicator(
                        modifier = Modifier.align(Alignment.Center),
                        color = ArixOnSurface,
                    )
                }
            }

            errorMessage.isNotBlank() -> {
                Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    Text(
                        text = errorMessage,
                        color = ArixOnSurfaceVariant,
                        modifier = Modifier
                            .align(Alignment.Center)
                            .padding(horizontal = 24.dp),
                    )
                }
            }

            spec != null -> key(sessionRestartEpoch) {
                var lastAppliedTextSizePx by remember { mutableStateOf(-1) }
                var lastAppliedTypeface by remember { mutableStateOf<Typeface?>(null) }
                var lastAppliedBackgroundColor by remember { mutableStateOf(Int.MIN_VALUE) }
                AndroidView(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp),
                    factory = { viewContext ->
                        val view = TerminalView(viewContext, null).apply {
                            setBackgroundColor(terminalBackgroundColor)
                            setTextSize(terminalTextSizePx)
                            setTypeface(terminalTypeface)
                            isFocusable = true
                            isFocusableInTouchMode = true
                        }
                        lastAppliedTextSizePx = terminalTextSizePx
                        lastAppliedTypeface = terminalTypeface
                        lastAppliedBackgroundColor = terminalBackgroundColor
                        val sessionClient = ArixTerminalSessionClient(
                            context = viewContext,
                            invalidateTerminal = { view ->
                                runCatching { view.onScreenUpdated() }
                            },
                            updateTitle = ::updateTerminalTitle,
                        )
                        val existingSession = TermuxTerminalSessionHolder.session(sessionKey)
                        val session = if (existingSession != null && existingSession.isRunning) {
                            runCatching { existingSession.updateTerminalSessionClient(sessionClient) }
                            view.attachSession(existingSession)
                            existingSession
                        } else {
                            val created = TerminalSession(
                                spec.executable,
                                spec.workingDirectory,
                                spec.arguments,
                                spec.environment,
                                2_000,
                                sessionClient,
                            )
                            TermuxTerminalSessionHolder.storeSession(sessionKey, created)
                            view.attachSession(created)
                            created
                        }
                        val viewClient = ArixTerminalViewClient(
                            terminalView = view,
                            readControlKeyState = { controlDown },
                            readAltKeyState = { altDown },
                            onModifiersConsumed = { consumedControl, consumedAlt ->
                                if (consumedControl) controlDown = false
                                if (consumedAlt) altDown = false
                            },
                            onRestartSession = ::restartFinishedSession,
                        )
                        view.setTerminalViewClient(viewClient)
                        sessionClient.attachTerminalView(view)
                        view.requestFocus()
                        view.post {
                            view.updateSize()
                            runCatching { view.setTerminalCursorBlinkerRate(500) }
                            runCatching { view.setTerminalCursorBlinkerState(true, true) }
                            showKeyboard(view.context, view)
                        }
                        terminalView = view
                        terminalSession = session
                        view
                    },
                    update = { view ->
                        if (lastAppliedBackgroundColor != terminalBackgroundColor) {
                            lastAppliedBackgroundColor = terminalBackgroundColor
                            view.setBackgroundColor(terminalBackgroundColor)
                        }
                        if (lastAppliedTextSizePx != terminalTextSizePx) {
                            lastAppliedTextSizePx = terminalTextSizePx
                            view.setTextSize(terminalTextSizePx)
                        }
                        if (lastAppliedTypeface != terminalTypeface) {
                            lastAppliedTypeface = terminalTypeface
                            view.setTypeface(terminalTypeface)
                        }
                        terminalView = view
                        if (!view.hasFocus()) view.requestFocus()
                    },
                )
            }
        }

        CompositionLocalProvider(LocalDensity provides Density(density.density, fontScale = 1f)) {
            TerminalExtraKeysBar(
                terminalView = terminalView,
                terminalSession = terminalSession,
                controlDown = controlDown,
                altDown = altDown,
                onControlDownChange = { controlDown = it },
                onAltDownChange = { altDown = it },
                onRestartFinishedSession = ::restartFinishedSession,
            )
        }
    }

    if (showQuickCommands) {
        ModalBottomSheet(
            onDismissRequest = { showQuickCommands = false },
            containerColor = Color.Transparent,
            scrimColor = ArixScrimColor,
            dragHandle = null,
        ) {
            TerminalQuickCommandsSheet(
                commands = quickCommands,
                onLaunchCommand = ::launchQuickCommand,
                onAddCommand = { raw ->
                    val stored = TerminalQuickCommandsStore.addCommand(context, raw)
                    if (stored != null) {
                        quickCommands = TerminalQuickCommandsStore.loadCommands(context)
                        true
                    } else {
                        false
                    }
                },
                onDeleteCommand = { command ->
                    TerminalQuickCommandsStore.removeCommand(context, command.id)
                    quickCommands = TerminalQuickCommandsStore.loadCommands(context)
                },
                onDismiss = { showQuickCommands = false },
            )
        }
    }

    if (showBackgroundCommands) {
        ModalBottomSheet(
            onDismissRequest = { showBackgroundCommands = false },
            containerColor = Color.Transparent,
            scrimColor = ArixScrimColor,
            dragHandle = null,
        ) {
            TerminalBackgroundCommandsSheet(
                state = backgroundCommands,
                onDismiss = { showBackgroundCommands = false },
            )
        }
    }
}

@Composable
private fun TerminalTopBar(
    title: String,
    onBack: () -> Unit,
    quickCommandCount: Int,
    onShowQuickCommands: () -> Unit,
    backgroundRunCount: Int,
    onShowBackgroundCommands: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .background(ArixBackground.copy(alpha = 0.86f))
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier
                .padding(end = 12.dp)
                .background(ArixSurface, CircleShape)
                .clickable(onClick = onBack)
                .padding(10.dp),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                contentDescription = "Back",
                tint = ArixOnSurface,
                modifier = Modifier.padding(2.dp),
            )
        }
        Text(
            text = title,
            color = ArixOnSurface,
            modifier = Modifier.weight(1f),
        )
        if (backgroundRunCount > 0) {
            Spacer(Modifier.width(8.dp))
            BackgroundCommandsHeaderButton(
                count = backgroundRunCount,
                onClick = onShowBackgroundCommands,
            )
        }
        QuickCommandsHeaderButton(
            count = quickCommandCount,
            onClick = onShowQuickCommands,
        )
    }
}

@Composable
private fun BackgroundCommandsHeaderButton(
    count: Int,
    onClick: () -> Unit,
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(18.dp))
            .background(
                androidx.compose.ui.graphics.Brush.horizontalGradient(
                    listOf(
                        ArixTertiary.copy(alpha = 0.28f),
                        ArixTertiary.copy(alpha = 0.10f),
                    ),
                ),
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Rounded.Launch,
                contentDescription = "Background commands",
                tint = ArixTertiary,
                modifier = Modifier.size(18.dp),
            )
            Spacer(Modifier.width(6.dp))
            Text(
                text = "$count",
                color = ArixTertiary,
                fontSize = 13.sp,
                fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
            )
        }
    }
}

private val ArixScrimColor: Color = Color(0x66000000)

@Composable
private fun QuickCommandsHeaderButton(
    count: Int,
    onClick: () -> Unit,
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(18.dp))
            .background(
                androidx.compose.ui.graphics.Brush.horizontalGradient(
                    listOf(
                        ArixPrimary.copy(alpha = 0.24f),
                        ArixPrimary.copy(alpha = 0.10f),
                    ),
                ),
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Rounded.Bolt,
                contentDescription = "Quick commands",
                tint = ArixPrimary,
                modifier = Modifier.size(18.dp),
            )
            Spacer(Modifier.width(6.dp))
            Text(
                text = if (count > 0) "$count" else "",
                color = ArixPrimary,
                fontSize = 13.sp,
                fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
            )
        }
    }
}

@Composable
private fun TerminalExtraKeysBar(
    terminalView: TerminalView?,
    terminalSession: TerminalSession?,
    controlDown: Boolean,
    altDown: Boolean,
    onControlDownChange: (Boolean) -> Unit,
    onAltDownChange: (Boolean) -> Unit,
    onRestartFinishedSession: () -> Unit = {},
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(ArixSurfaceHigh)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        ExtraKeyRow {
            ExtraKey("ESC") { terminalView.sendKey(KeyEvent.KEYCODE_ESCAPE, controlDown, altDown) }
            ExtraKey("TAB") { terminalView.sendKey(KeyEvent.KEYCODE_TAB, controlDown, altDown) }
            ExtraKey("CTRL", active = controlDown) { onControlDownChange(!controlDown) }
            ExtraKey("ALT", active = altDown) { onAltDownChange(!altDown) }
            ExtraKey("-") { terminalView.sendText("-", controlDown, altDown) }
            ExtraKey("/") { terminalView.sendText("/", controlDown, altDown) }
            ExtraKey("|") { terminalView.sendText("|", controlDown, altDown) }
            ExtraKey("HOME") { terminalView.sendKey(KeyEvent.KEYCODE_MOVE_HOME, controlDown, altDown) }
            ExtraKey("END") { terminalView.sendKey(KeyEvent.KEYCODE_MOVE_END, controlDown, altDown) }
            ExtraKey("PGUP") { terminalView.sendKey(KeyEvent.KEYCODE_PAGE_UP, controlDown, altDown) }
            ExtraKey("PGDN") { terminalView.sendKey(KeyEvent.KEYCODE_PAGE_DOWN, controlDown, altDown) }
        }
        ExtraKeyRow {
            ExtraKey("KEYB") { terminalView?.let { showKeyboard(it.context, it) } }
            ExtraKey("BKSP") { terminalView.sendKey(KeyEvent.KEYCODE_DEL, controlDown, altDown) }
            ExtraKey("DEL") { terminalView.sendKey(KeyEvent.KEYCODE_FORWARD_DEL, controlDown, altDown) }
            ExtraKey("INS") { terminalView.sendKey(KeyEvent.KEYCODE_INSERT, controlDown, altDown) }
            ExtraKey("LEFT") { terminalView.sendKey(KeyEvent.KEYCODE_DPAD_LEFT, controlDown, altDown) }
            ExtraKey("DOWN") { terminalView.sendKey(KeyEvent.KEYCODE_DPAD_DOWN, controlDown, altDown) }
            ExtraKey("UP") { terminalView.sendKey(KeyEvent.KEYCODE_DPAD_UP, controlDown, altDown) }
            ExtraKey("RIGHT") { terminalView.sendKey(KeyEvent.KEYCODE_DPAD_RIGHT, controlDown, altDown) }
            ExtraKey("ENTER") {
                val session = terminalSession
                if (session != null && !session.isRunning) {
                    onRestartFinishedSession()
                } else {
                    session?.write("\r")
                }
            }
        }
    }
}

@Composable
private fun ExtraKeyRow(content: @Composable () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(7.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        content()
        Spacer(Modifier.width(1.dp))
    }
}

@Composable
private fun ExtraKey(
    label: String,
    active: Boolean = false,
    onClick: () -> Unit,
) {
    Box(
        modifier = Modifier
            .heightIn(min = 32.dp)
            .background(
                color = if (active) ArixOnSurfaceVariant.copy(alpha = 0.28f) else ArixSurfaceHigher,
                shape = RoundedCornerShape(6.dp),
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = if (active) ArixOnSurface else ArixOnSurfaceVariant,
            fontSize = 12.sp,
        )
    }
}

private class ArixTerminalSessionClient(
    private val context: Context,
    private val invalidateTerminal: (TerminalView) -> Unit,
    private val updateTitle: (String) -> Unit,
) : TerminalSessionClient {
    override fun onTextChanged(changedSession: TerminalSession) {
        currentTerminalView()?.let(invalidateTerminal)
    }

    override fun onTitleChanged(changedSession: TerminalSession) {
        runCatching { updateTitle(changedSession.title.orEmpty()) }
    }

    override fun onSessionFinished(finishedSession: TerminalSession) {
        currentTerminalView()?.let(invalidateTerminal)
    }

    override fun onCopyTextToClipboard(session: TerminalSession, text: String) {
        runCatching {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("terminal", text))
        }
    }

    override fun onPasteTextFromClipboard(session: TerminalSession?) {
        runCatching {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val text = clipboard.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString().orEmpty()
            if (text.isNotEmpty()) {
                val bytes = text.toByteArray(Charsets.UTF_8)
                session?.write(bytes, 0, bytes.size)
            }
        }
    }

    override fun onBell(session: TerminalSession) = Unit

    override fun onColorsChanged(session: TerminalSession) {
        currentTerminalView()?.let(invalidateTerminal)
    }

    override fun onTerminalCursorStateChange(state: Boolean) {
        currentTerminalView()?.let(invalidateTerminal)
    }

    override fun setTerminalShellPid(session: TerminalSession, pid: Int) = Unit

    override fun getTerminalCursorStyle(): Int? = TerminalEmulator.TERMINAL_CURSOR_STYLE_BLOCK

    @Volatile
    private var attachedTerminalView: TerminalView? = null

    fun attachTerminalView(view: TerminalView) {
        attachedTerminalView = view
    }

    private fun currentTerminalView(): TerminalView? = attachedTerminalView

    override fun logError(tag: String, message: String) {
        Log.e(tag, message)
    }

    override fun logWarn(tag: String, message: String) {
        Log.w(tag, message)
    }

    override fun logInfo(tag: String, message: String) {
        Log.i(tag, message)
    }

    override fun logDebug(tag: String, message: String) {
        Log.d(tag, message)
    }

    override fun logVerbose(tag: String, message: String) {
        Log.v(tag, message)
    }

    override fun logStackTraceWithMessage(tag: String, message: String, e: Exception) {
        Log.e(tag, message, e)
    }

    override fun logStackTrace(tag: String, e: Exception) {
        Log.e(tag, e.message, e)
    }
}

private class ArixTerminalViewClient(
    private val terminalView: TerminalView,
    private val readControlKeyState: () -> Boolean = { false },
    private val readAltKeyState: () -> Boolean = { false },
    private val onModifiersConsumed: (control: Boolean, alt: Boolean) -> Unit = { _, _ -> },
    private val onRestartSession: () -> Unit = {},
) : TerminalViewClient {
    override fun onScale(scale: Float): Float = scale.coerceIn(0.7f, 1.6f)

    override fun onSingleTapUp(e: MotionEvent) {
        showKeyboard(terminalView.context, terminalView)
    }

    override fun shouldBackButtonBeMappedToEscape(): Boolean = false
    override fun shouldEnforceCharBasedInput(): Boolean = true
    override fun shouldUseCtrlSpaceWorkaround(): Boolean = true
    override fun isTerminalViewSelected(): Boolean = terminalView.hasFocus()
    override fun copyModeChanged(copyMode: Boolean) = Unit

    override fun onKeyDown(keyCode: Int, e: KeyEvent, session: TerminalSession): Boolean {
        if (
            keyCode == KeyEvent.KEYCODE_ENTER &&
                !session.isRunning &&
                !e.isCtrlPressed &&
                !e.isAltPressed &&
                !e.isShiftPressed
        ) {
            onRestartSession()
            return true
        }
        return false
    }

    override fun onKeyUp(keyCode: Int, e: KeyEvent): Boolean = false
    override fun onLongPress(event: MotionEvent): Boolean = false

    override fun readControlKey(): Boolean = readControlKeyState()
    override fun readAltKey(): Boolean = readAltKeyState()
    override fun readShiftKey(): Boolean = false
    override fun readFnKey(): Boolean = false

    override fun onCodePoint(codePoint: Int, ctrlDown: Boolean, session: TerminalSession): Boolean {
        val altDown = readAltKeyState()
        if (ctrlDown || altDown) {
            onModifiersConsumed(ctrlDown, altDown)
        }
        return false
    }

    override fun onEmulatorSet() = Unit
    override fun logError(tag: String, message: String) {
        Log.e(tag, message)
    }

    override fun logWarn(tag: String, message: String) {
        Log.w(tag, message)
    }

    override fun logInfo(tag: String, message: String) {
        Log.i(tag, message)
    }

    override fun logDebug(tag: String, message: String) {
        Log.d(tag, message)
    }

    override fun logVerbose(tag: String, message: String) {
        Log.v(tag, message)
    }

    override fun logStackTraceWithMessage(tag: String, message: String, e: Exception) {
        Log.e(tag, message, e)
    }

    override fun logStackTrace(tag: String, e: Exception) {
        Log.e(tag, e.message, e)
    }
}

private fun showKeyboard(
    context: Context,
    view: android.view.View,
) {
    view.post {
        view.requestFocus()
        val inputMethodManager = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        inputMethodManager.showSoftInput(view, 0)
    }
}

private fun defaultTermuxTerminalTextSizePx(context: Context): Int {
    val dipInPixels = context.resources.displayMetrics.density
    val minFontSize = (4f * dipInPixels).toInt()
    var fontSize = (12f * dipInPixels).roundToInt()
    if (fontSize % 2 == 1) fontSize--
    return fontSize.coerceIn(minFontSize, 256)
}

private fun embeddedTerminalTypeface(context: Context): Typeface =
    runCatching {
        Typeface.createFromAsset(context.assets, "fonts/JetBrainsMono-Regular.ttf")
    }.getOrElse {
        systemTerminalTypeface()
    }

private fun systemTerminalTypeface(): Typeface {
    val systemMono = File("/system/fonts/DroidSansMono.ttf")
    return if (systemMono.isFile && systemMono.length() > 0L) {
        Typeface.createFromFile(systemMono)
    } else {
        Typeface.MONOSPACE
    }
}

private fun TerminalView?.sendKey(
    keyCode: Int,
    controlDown: Boolean,
    altDown: Boolean,
) {
    val view = this ?: return
    val keyMod = buildKeyMod(controlDown, altDown)
    if (!view.handleKeyCode(keyCode, keyMod)) {
        val metaState = buildMetaState(controlDown, altDown)
        val event = KeyEvent(0, 0, KeyEvent.ACTION_DOWN, keyCode, 0, metaState)
        view.onKeyDown(keyCode, event)
    }
    view.requestFocus()
}

private fun TerminalView?.sendText(
    text: String,
    controlDown: Boolean,
    altDown: Boolean,
) {
    val view = this ?: return
    text.codePoints().forEach { codePoint ->
        view.inputCodePoint(TerminalView.KEY_EVENT_SOURCE_VIRTUAL_KEYBOARD, codePoint, controlDown, altDown)
    }
    view.requestFocus()
}

private fun buildKeyMod(
    controlDown: Boolean,
    altDown: Boolean,
): Int {
    var keyMod = 0
    if (controlDown) keyMod = keyMod or KeyHandler.KEYMOD_CTRL
    if (altDown) keyMod = keyMod or KeyHandler.KEYMOD_ALT
    return keyMod
}

private fun buildMetaState(
    controlDown: Boolean,
    altDown: Boolean,
): Int {
    var metaState = 0
    if (controlDown) metaState = metaState or KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_LEFT_ON
    if (altDown) metaState = metaState or KeyEvent.META_ALT_ON or KeyEvent.META_ALT_LEFT_ON
    return metaState
}
