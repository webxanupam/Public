package com.arix.app

import kotlinx.coroutines.flow.MutableStateFlow

object ArixIncomingRequests {

    data class IncomingText(
        val text: String,
        val source: Source,
    )

    enum class Source { ShareSheet, TextSelection }

    val pendingText = MutableStateFlow<IncomingText?>(null)

    val petContext = MutableStateFlow<String?>(null)

    fun offerText(text: String, source: Source) {
        if (text.isBlank()) return
        pendingText.value = IncomingText(text.trim(), source)
        petContext.value = text.trim()
    }

}
