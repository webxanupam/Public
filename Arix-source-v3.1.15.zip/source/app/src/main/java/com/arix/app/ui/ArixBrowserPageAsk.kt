package com.arix.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.SmartToy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.arix.app.ArixIncomingRequests
import com.arix.app.arixRuntime
import com.arix.app.browser.ArixBrowserSnapshot

/**
 * v3.1.15 — "Call it from any web page" (Mika port): a slim ask bar at the
 * bottom of the built-in browser. Say what you want done ON THE PAGE you are
 * reading; Arix works right there on the same page — while it works, a small
 * running card replaces the bar; touch the page and its automation pauses
 * (USER_TOUCH_ACTIVE) until you let it continue.
 */
@Composable
fun BrowserPageAskBar(
    snapshot: ArixBrowserSnapshot,
    onOpenChat: () -> Unit,
    onStop: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val runtime = androidx.compose.ui.platform.LocalContext.current.arixRuntime
    val executionStates by runtime.sessionExecutionManager.executionStates.collectAsState()
    val running = executionStates.values.any { it.isRunning }
    val runningState = executionStates.values.firstOrNull { it.isRunning }

    if (running) {
        PageAskRunningCard(
            status = runningState?.pendingStatusText?.takeIf { it.isNotBlank() } ?: "Working on the page…",
            onOpenChat = onOpenChat,
            onStop = onStop,
            modifier = modifier,
        )
    } else {
        PageAskInputBar(snapshot = snapshot, modifier = modifier)
    }
}

@Composable
private fun PageAskInputBar(
    snapshot: ArixBrowserSnapshot,
    modifier: Modifier = Modifier,
) {
    var value by remember { mutableStateOf("") }

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
        shape = RoundedCornerShape(22.dp),
        tonalElevation = 1.dp,
    ) {
        Row(
            modifier = Modifier.padding(start = 14.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                Icons.Rounded.SmartToy,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp),
            )
            Spacer(Modifier.width(10.dp))
            BasicTextField(
                value = value,
                onValueChange = { value = it },
                textStyle = MaterialTheme.typography.bodyMedium.copy(
                    color = MaterialTheme.colorScheme.onSurface,
                ),
                cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(
                    onSend = {
                        submitPageAsk(value, snapshot)
                        value = ""
                    },
                ),
                decorationBox = { inner ->
                    if (value.isEmpty()) {
                        Text(
                            "Ask Arix about this page…",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    inner()
                },
                modifier = Modifier.weight(1f),
            )
            IconButton(
                onClick = {
                    submitPageAsk(value, snapshot)
                    value = ""
                },
                enabled = value.isNotBlank(),
            ) {
                Icon(
                    Icons.AutoMirrored.Rounded.Send,
                    contentDescription = "Ask Arix",
                    tint = if (value.isNotBlank()) {
                        MaterialTheme.colorScheme.primary
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                    },
                )
            }
        }
    }
}

/**
 * Sends the ask into the chat with the page's context attached; the agent then
 * drives the very same page through the browser tool (same session, same
 * cookies, visible in this tab while it works).
 */
private fun submitPageAsk(ask: String, snapshot: ArixBrowserSnapshot) {
    if (ask.isBlank() || !snapshot.hasCommittedPage) return
    val title = snapshot.title.ifBlank { snapshot.host }
    val message =
        "On the page I'm reading in the browser — \"$title\" (${snapshot.url}) — please: $ask"
    ArixIncomingRequests.offerText(message, ArixIncomingRequests.Source.ShareSheet)
}

@Composable
private fun PageAskRunningCard(
    status: String,
    onOpenChat: () -> Unit,
    onStop: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
        shape = RoundedCornerShape(22.dp),
        tonalElevation = 1.dp,
    ) {
        Row(
            modifier = Modifier.padding(start = 14.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                Icons.Rounded.SmartToy,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp),
            )
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    "Arix is working",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Text(
                    status,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                )
            }
            TextButton(onClick = onOpenChat) { Text("Chat") }
            IconButton(onClick = onStop) {
                Icon(
                    Icons.Rounded.Close,
                    contentDescription = "Stop",
                    tint = MaterialTheme.colorScheme.error,
                )
            }
        }
    }
}
