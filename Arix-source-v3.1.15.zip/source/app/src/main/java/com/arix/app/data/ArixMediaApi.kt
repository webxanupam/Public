package com.arix.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import okhttp3.OkHttpClient
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

object ArixMediaApi {

    const val BrowserUserAgent =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"

    val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(9, TimeUnit.SECONDS)
        .readTimeout(14, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private val imageClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    fun thumbUrl(original: String, widthPx: Int = 244): String {
        if (original.isBlank() || !original.startsWith("http")) return original
        if (original.contains("anilist.co", ignoreCase = true)) return original
        if (original.contains("wsrv.nl", ignoreCase = true)) return original
        return "https://wsrv.nl/?url=" + android.net.Uri.encode(original) +
            "&w=$widthPx&output=webp&q=72&il"
    }

    private val posterMemory: LruCache<String, Bitmap> = object : LruCache<String, Bitmap>(36) {}
    private var posterDiskDir: File? = null

    fun initializePosterCache(context: Context) {
        posterDiskDir = File(context.cacheDir, "posters").apply { mkdirs() }
    }

    private fun posterKey(url: String): String = md5(url)

    fun loadPoster(url: String, widthPx: Int = 244): Bitmap? {
        if (url.isBlank()) return null
        val key = posterKey(url)
        posterMemory.get(key)?.let { return it }
        posterDiskDir?.let { dir ->
            val file = File(dir, key)
            if (file.exists()) {
                runCatching {
                    val cached = BitmapFactory.decodeFile(file.absolutePath)
                    if (cached != null) {
                        posterMemory.put(key, cached)
                        return cached
                    }
                }
            }
        }
        val normalized = if (url.startsWith("//")) "https:$url" else url
        val downloaded = downloadBitmap(normalized)
            ?: downloadBitmap(thumbUrl(normalized, widthPx))
        var bitmap = downloaded ?: return null
        if (bitmap.width > widthPx * 2) {
            val scale = (widthPx * 2).toFloat() / bitmap.width
            bitmap = Bitmap.createScaledBitmap(
                bitmap,
                (bitmap.width * scale).toInt().coerceAtLeast(1),
                (bitmap.height * scale).toInt().coerceAtLeast(1),
                true,
            )
        }
        posterMemory.put(key, bitmap)
        posterDiskDir?.let { dir ->
            runCatching {
                val file = File(dir, key)
                file.outputStream().use { output ->
                    val format = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                        Bitmap.CompressFormat.WEBP_LOSSY
                    } else {
                        @Suppress("DEPRECATION")
                        Bitmap.CompressFormat.WEBP
                    }
                    bitmap.compress(format, 78, output)
                }
            }
        }
        return bitmap
    }

    private fun downloadBitmap(url: String): Bitmap? = runCatching {
        val request = okhttp3.Request.Builder()
            .url(url)
            .header("User-Agent", BrowserUserAgent)
            .header("Accept", "image/avif,image/webp,image/*,*/*;q=0.8")
            .build()
        imageClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return@runCatching null
            val bytes = response.body?.byteStream()?.use { it.readBytes() } ?: return@runCatching null
            if (bytes.isEmpty() || bytes.size > 8 * 1024 * 1024) return@runCatching null
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        }
    }.getOrNull()

    fun md5(value: String): String {
        val digest = MessageDigest.getInstance("MD5")
        return digest.digest(value.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }
}
