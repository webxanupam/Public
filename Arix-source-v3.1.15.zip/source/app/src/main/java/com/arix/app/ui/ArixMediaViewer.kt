package com.arix.app.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
internal fun ArixMediaViewerDialog(
    onDismiss: () -> Unit,
    bitmap: ImageBitmap? = null,
    imageBytes: ByteArray? = null,
    imageMimeType: String = "",
    remoteUrl: String? = null,
    title: String = "",
    detail: String = "",
    fileName: String = "",
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val decodedBitmap by produceState<Bitmap?>(
        initialValue = null,
        key1 = imageBytes,
    ) {
        if (bitmap != null || imageBytes == null) return@produceState
        value = withContext(Dispatchers.IO) {
            runCatching {
                BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size)
            }.getOrNull()
        }
    }
    val shownBitmap = bitmap ?: decodedBitmap?.asImageBitmap()

    var working by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf("") }

    val resolvedFileName = remember(fileName, remoteUrl, title) {
        fileName.ifBlank {
            remoteUrl?.substringAfterLast('/')?.takeIf { it.isNotBlank() }
                ?: title.ifBlank { "arix-image-${System.currentTimeMillis()}.jpg" }
        }
    }
    val resolvedMime = imageMimeType.ifBlank { "image/jpeg" }
    val canSave = imageBytes != null || (remoteUrl != null && remoteUrl.startsWith("http"))
    val canShare = canSave
    val canOpenOriginal = remoteUrl != null && remoteUrl.startsWith("http") &&
        !remoteUrl.startsWith("arix-local-file")

    var scale by remember { mutableStateOf(1f) }
    var offsetX by remember { mutableStateOf(0f) }
    var offsetY by remember { mutableStateOf(0f) }
    val animatedScale by animateFloatAsState(
        targetValue = scale,
        animationSpec = tween(durationMillis = 180),
        label = "viewer-scale",
    )
    val animatedOffsetX by animateFloatAsState(
        targetValue = offsetX,
        animationSpec = tween(durationMillis = 180),
        label = "viewer-offset-x",
    )
    val animatedOffsetY by animateFloatAsState(
        targetValue = offsetY,
        animationSpec = tween(durationMillis = 180),
        label = "viewer-offset-y",
    )

    fun resetTransform() {
        scale = 1f
        offsetX = 0f
        offsetY = 0f
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = false,
        ),
    ) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xEE05060B)),
        ) {
            val viewportWidth = maxWidth.value
            val viewportHeight = maxHeight.value
            val transformState = rememberTransformableState { zoomChange, panChange, _ ->
                val newScale = (scale * zoomChange).coerceIn(1f, 8f)
                val maxPanX = ((newScale - 1f) / 2f) * viewportWidth
                val maxPanY = ((newScale - 1f) / 2f) * viewportHeight
                scale = newScale
                if (newScale > 1f) {
                    offsetX = (offsetX + panChange.x).coerceIn(-maxPanX, maxPanX)
                    offsetY = (offsetY + panChange.y).coerceIn(-maxPanY, maxPanY)
                } else {
                    offsetX = 0f
                    offsetY = 0f
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .transformable(state = transformState)
                    .pointerInput(shownBitmap) {
                        detectTapGestures(
                            onDoubleTap = {
                                if (scale > 1.05f) {
                                    resetTransform()
                                } else {
                                    scale = 2.6f
                                }
                            },
                            onTap = {
                                if (scale <= 1.05f) onDismiss()
                            },
                        )
                    },
                contentAlignment = Alignment.Center,
            ) {
                if (shownBitmap != null) {
                    Image(
                        bitmap = shownBitmap,
                        contentDescription = title.ifBlank { "image preview" },
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                scaleX = animatedScale
                                scaleY = animatedScale
                                translationX = animatedOffsetX
                                translationY = animatedOffsetY
                                transformOrigin = androidx.compose.ui.graphics.TransformOrigin.Center
                            },
                    )
                } else {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxSize(),
                    ) {
                        CircularProgressIndicator(color = Color(0xFFC3AFFF))
                        Spacer(Modifier.height(10.dp))
                        Text(
                            text = "Loading…",
                            color = Color(0xB3FFFFFF),
                            style = MaterialTheme.typography.labelMedium,
                        )
                    }
                }
            }

            Row(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xCC000000), Color(0x66000000), Color.Transparent),
                        ),
                    )
                    .statusBarsPadding()
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 8.dp),
                ) {
                    if (title.isNotBlank()) {
                        Text(
                            text = title,
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    if (detail.isNotBlank()) {
                        Text(
                            text = detail,
                            color = Color(0xB3FFFFFF),
                            style = MaterialTheme.typography.labelSmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Rounded.Close,
                        contentDescription = "Close",
                        tint = Color.White,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0x59FFFFFF))
                            .padding(7.dp),
                    )
                }
            }

            if (canSave || canShare || canOpenOriginal) {
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, Color(0x66000000), Color(0xCC000000)),
                            ),
                        )
                        .padding(horizontal = 14.dp, vertical = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    if (notice.isNotBlank()) {
                        Text(
                            text = notice,
                            color = Color(0xCCEAEAEA),
                            style = MaterialTheme.typography.labelSmall,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        if (canSave) {
                            ArixViewerActionButton(
                                label = "Save",
                                icon = Icons.Rounded.Download,
                                enabled = !working,
                                modifier = Modifier.weight(1f),
                            ) {
                                working = true
                                notice = ""
                                scope.launch {
                                    val outcome = withContext(Dispatchers.IO) {
                                        runCatching {
                                            if (imageBytes != null) {
                                                ArixMediaActions.downloadToDownloads(
                                                    context = context,
                                                    fileName = resolvedFileName,
                                                    mimeType = resolvedMime,
                                                    bytes = imageBytes,
                                                )
                                                0L
                                            } else {
                                                ArixMediaActions.downloadUrlToDownloads(
                                                    context = context,
                                                    url = remoteUrl.orEmpty(),
                                                    fileName = resolvedFileName,
                                                    mimeType = resolvedMime,
                                                )
                                            }
                                        }
                                    }
                                    working = false
                                    notice = outcome.fold(
                                        onSuccess = { "Saved to Downloads" },
                                        onFailure = { it.message ?: "Could not save" },
                                    )
                                }
                            }
                        }
                        if (canShare) {
                            ArixViewerActionButton(
                                label = "Share",
                                icon = Icons.Rounded.Share,
                                enabled = !working,
                                modifier = Modifier.weight(1f),
                            ) {
                                working = true
                                notice = ""
                                scope.launch {
                                    val shared = withContext(Dispatchers.IO) {
                                        runCatching {
                                            if (imageBytes != null) {
                                                ArixMediaActions.shareBytes(
                                                    context = context,
                                                    fileName = resolvedFileName,
                                                    mimeType = resolvedMime,
                                                    bytes = imageBytes,
                                                )
                                            } else if (remoteUrl != null) {
                                                val staged = ArixMediaActions.stageShareUrlFile(
                                                    context = context,
                                                    url = remoteUrl,
                                                    fileName = resolvedFileName,
                                                )
                                                ArixMediaActions.shareStagedFile(
                                                    context = context,
                                                    file = staged,
                                                    mimeType = resolvedMime,
                                                )
                                            } else {
                                                false
                                            }
                                        }
                                    }
                                    working = false
                                    if (!shared.getOrDefault(false)) {
                                        notice = "Could not share"
                                    }
                                }
                            }
                        }
                        if (canOpenOriginal) {
                            ArixViewerActionButton(
                                label = "Open",
                                icon = Icons.Rounded.OpenInNew,
                                enabled = true,
                                modifier = Modifier.weight(1f),
                            ) {
                                ArixLinkActions.openUrl(context, remoteUrl.orEmpty())
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ArixViewerActionButton(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    enabled: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0x73FFFFFF))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (enabled) Color.White else Color(0x80FFFFFF),
            modifier = Modifier.size(18.dp),
        )
        Text(
            text = label,
            color = if (enabled) Color.White else Color(0x80FFFFFF),
            style = MaterialTheme.typography.labelLarge,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

object ArixLinkActions {
    fun openUrl(context: android.content.Context, url: String) {
        val trimmed = url.trim()
        if (trimmed.isBlank()) return
        val normalized = when {
            trimmed.startsWith("http://") || trimmed.startsWith("https://") -> trimmed
            trimmed.startsWith("www.") -> "https://$trimmed"
            else -> trimmed
        }
        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
            data = android.net.Uri.parse(normalized)
            addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val ok = runCatching { context.startActivity(intent) }.isSuccess
        if (!ok) {
            android.widget.Toast.makeText(
                context.applicationContext,
                "No app can open this link",
                android.widget.Toast.LENGTH_SHORT,
            ).show()
        }
    }
}
