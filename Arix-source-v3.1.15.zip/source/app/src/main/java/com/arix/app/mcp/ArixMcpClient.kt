package com.arix.app.mcp

import com.arix.app.runtime.TermuxRuntime
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okio.BufferedSource
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class ArixMcpClient(
    private val config: ArixMcpServerConfig,
    private val httpClient: OkHttpClient,
    private val termuxRuntime: TermuxRuntime?,
    private val onLog: (String) -> Unit = {},
    private val onClosed: (unexpected: Boolean) -> Unit = {},
    private val onOAuthUpdated: (ArixMcpOAuthConfig) -> Unit = {},
) {
    private val idCounter = AtomicLong(1)
    private val writeMutex = Mutex()
    private val refreshMutex = Mutex()

    private var sessionHeader: String? = null
    private var oauthClient: ArixMcpOAuthClient? = null
    private var liveOAuth: ArixMcpOAuthConfig? = config.oauth

    private var process: java.lang.Process? = null
    private var stdoutReader: BufferedReader? = null

    private val pendingStdio = ConcurrentHashMap<Long, kotlinx.coroutines.CompletableDeferred<JSONObject>>()
    @Volatile private var stdioClosed = false

    var alive: Boolean = true
        private set

    suspend fun connect() {
        if (config.isStdio) {
            startStdio()
        }
        val initializeResult = request(
            "initialize",
            JSONObject().apply {
                put(
                    "protocolVersion",
                    "2025-06-18",
                )
                put(
                    "clientInfo",
                    JSONObject().apply {
                        put("name", "arix")
                        put("version", com.arix.app.BuildConfig.VERSION_NAME)
                    },
                )
                put("capabilities", JSONObject())
            },
        )
        runCatching {
            val serverProtocol = initializeResult.optJSONObject("result")
                ?.optString("protocolVersion")
            if (serverProtocol.isNullOrBlank()) {
                negotiatedProtocol = "2025-06-18"
            } else {
                negotiatedProtocol = serverProtocol
            }
        }
        notify(
            "notifications/initialized",
            JSONObject(),
        )
    }

    private var negotiatedProtocol: String = "2025-06-18"

    suspend fun listTools(): List<ArixMcpToolDescriptor> {
        val response = request(
            "tools/list",
            JSONObject().apply { put("_meta", JSONObject()) },
        )
        val result = response.optJSONObject("result") ?: return emptyList()
        val tools = result.optJSONArray("tools") ?: return emptyList()
        return buildList {
            for (index in 0 until tools.length()) {
                tools.optJSONObject(index)?.let { tool ->
                    val descriptor = ArixMcpToolDescriptor.fromJson(tool)
                    if (descriptor.name.isNotBlank()) add(descriptor)
                }
            }
        }
    }

    suspend fun callTool(name: String, arguments: JSONObject): ArixMcpCallResult {
        val response = request(
            "tools/call",
            JSONObject().apply {
                put("name", name)
                put("arguments", arguments)
            },
        )
        val error = response.optJSONObject("error")
        if (error != null) {
            return ArixMcpCallResult(
                text = "MCP error ${error.optInt("code", -1)}: ${error.optString("message")}",
                isError = true,
            )
        }
        val result = response.optJSONObject("result") ?: JSONObject()
        val content = result.optJSONArray("content") ?: JSONArray()
        val textParts = mutableListOf<String>()
        val images = mutableListOf<Pair<String, String>>()
        for (index in 0 until content.length()) {
            val block = content.optJSONObject(index) ?: continue
            when (block.optString("type")) {
                "text" -> textParts += block.optString("text")
                "image" -> {
                    images += block.optString("mimeType") to block.optString("data")
                    textParts += "[image content]"
                }
                "resource" -> textParts += "[resource content]"
                else -> textParts += block.toString()
            }
        }
        return ArixMcpCallResult(
            text = if (textParts.isEmpty()) "(empty result)" else textParts.joinToString("\n"),
            isError = result.optBoolean("isError", false),
            images = images,
        )
    }

    fun close() {
        alive = false
        stdioClosed = true
        runCatching { stdoutReader?.close() }
        val dying = process
        process = null
        stdoutReader = null
        pendingStdio.values.forEach { deferred ->
            runCatching { deferred.cancel() }
        }
        pendingStdio.clear()
        if (dying != null) {
            Thread {
                runCatching {
                    dying.destroy()
                    if (!dying.waitFor(800, TimeUnit.MILLISECONDS)) {
                        dying.destroyForcibly()
                    }
                }
            }.apply { isDaemon = true }.start()
        }
        onClosed(false)
    }

    private suspend fun httpPost(body: JSONObject): JSONObject {
        val url = config.url.orEmpty().trim()
        if (url.isEmpty()) throw IllegalStateException("Server URL is empty")
        val oauth = liveOAuth ?: config.oauth
        val bearer = if (oauth != null && oauth.hasTokens) {
            oauthClient = oauthClient ?: ArixMcpOAuthClient(config.name)
            oauth.accessToken
        } else {
            null
        }
        val requestBuilder = Request.Builder()
            .url(url)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .header("Accept", "application/json, text/event-stream")
        sessionHeader?.let { requestBuilder.header("Mcp-Session-Id", it) }
        if (bearer != null) {
            requestBuilder.header("Authorization", "Bearer $bearer")
        }
        val usedHeaderNames = mutableSetOf<String>()
        if (bearer != null) usedHeaderNames.add("authorization")
        config.headers.forEach { (name, value) ->
            if (!usedHeaderNames.contains(name.lowercase())) {
                requestBuilder.header(name, value)
                usedHeaderNames.add(name.lowercase())
            }
        }
        val expectedId = body.opt("id")
        var response = executeHttp(requestBuilder.build(), expectedId)
        if (response.optInt("httpStatus") == 401 && oauth != null && bearer != null) {
            response = refreshMutex.withLock {
                if (liveOAuth == null || liveOAuth == oauth) {
                    val refreshed = (oauthClient ?: ArixMcpOAuthClient(config.name).also { oauthClient = it })
                        .forceRefresh(oauth)
                    if (refreshed != null) {
                        liveOAuth = refreshed
                        onOAuthUpdated(refreshed)
                    }
                }
                val retryToken = liveOAuth?.takeIf { it.hasTokens && it != oauth }
                    ?: return@withLock response
                val retryBuilder = requestBuilder
                    .header("Authorization", "Bearer ${retryToken.accessToken}")
                    .build()
                executeHttp(retryBuilder, expectedId)
            }
        }
        val status = response.optInt("httpStatus", 200)
        if (status >= 400 && response.optJSONObject("error") == null && response.optJSONObject("result") == null) {
            val unauthorized = oauth != null && !oauth.hasTokens
            throw IllegalStateException(
                "MCP server ${config.name} answered HTTP $status" +
                    if (unauthorized) {
                        " — this connector is not authorized yet; sign in " +
                            "from Settings → MCP Servers → ${config.name} first"
                    } else {
                        ""
                    },
            )
        }
        return response
    }

    private suspend fun executeHttp(request: Request, expectedId: Any?): JSONObject =
        withContext(Dispatchers.IO) {
            suspendCancellableCoroutine { continuation ->
                val call = httpClient.newCall(request)
                continuation.invokeOnCancellation { call.cancel() }
                call.enqueue(
                    object : okhttp3.Callback {
                        override fun onFailure(call: Call, e: java.io.IOException) {
                            if (continuation.isActive) {
                                continuation.resumeWithException(e)
                            }
                        }

                        override fun onResponse(call: Call, response: okhttp3.Response) {
                            response.use {
                                val status = it.code
                                it.header("Mcp-Session-Id")?.let { sessionId ->
                                    if (sessionId.isNotBlank()) {
                                        sessionHeader = sessionId
                                    }
                                }
                                val contentType = it.header("Content-Type").orEmpty().lowercase()
                                try {
                                    val body = it.body
                                    val parsed = if (body != null && contentType.contains("text/event-stream")) {
                                        readSseStream(status, expectedId, body.source())
                                    } else {
                                        parseHttpResponse(status, expectedId, body?.string().orEmpty())
                                    }
                                    continuation.resume(parsed)
                                } catch (e: Exception) {
                                    continuation.resumeWithException(e)
                                }
                            }
                        }
                    },
                )
            }
        }

    private fun parseHttpResponse(status: Int, expectedId: Any?, body: String): JSONObject {
        val trimmed = body.trim()
        if (trimmed.startsWith("{")) {
            val json = try {
                JSONObject(trimmed)
            } catch (failure: org.json.JSONException) {
                throw IllegalStateException(
                    "HTTP $status: malformed JSON response: " +
                        trimmed.take(120).replace('\n', ' '),
                )
            }
            json.put("httpStatus", status)
            return json
        }
        return scanSseBody(status, expectedId, trimmed)
            ?: if (status == 401) {
                JSONObject().put("httpStatus", 401)
            } else {
                throw IllegalStateException("HTTP $status: no JSON-RPC response in stream")
            }
    }

    private fun readSseStream(status: Int, expectedId: Any?, source: BufferedSource): JSONObject {
        var events = 0
        val dataBuffer = StringBuilder()
        while (true) {
            val line = runCatching { source.readUtf8Line() }.getOrNull() ?: break
            when {
                line.startsWith("data:") -> dataBuffer.append(line.removePrefix("data:").trim())
                line.isEmpty() && dataBuffer.isNotEmpty() -> {
                    val json = runCatching { JSONObject(dataBuffer.toString()) }.getOrNull()
                    dataBuffer.setLength(0)
                    events += 1
                    if (events >= 100) break
                    if (json != null && isResponseFor(json, expectedId)) {
                        json.put("httpStatus", status)
                        return json
                    }
                }
            }
        }
        if (dataBuffer.isNotEmpty()) {
            val json = runCatching { JSONObject(dataBuffer.toString()) }.getOrNull()
            if (json != null && isResponseFor(json, expectedId)) {
                json.put("httpStatus", status)
                return json
            }
        }
        return if (status == 401) {
            JSONObject().put("httpStatus", 401)
        } else {
            throw IllegalStateException("HTTP $status: no JSON-RPC response in stream")
        }
    }

    private fun scanSseBody(status: Int, expectedId: Any?, body: String): JSONObject? {
        var events = 0
        var dataBuffer = StringBuilder()
        for (line in body.lineSequence()) {
            when {
                line.startsWith("data:") -> dataBuffer.append(line.removePrefix("data:").trim())
                line.isEmpty() && dataBuffer.isNotEmpty() -> {
                    val json = runCatching { JSONObject(dataBuffer.toString()) }.getOrNull()
                    dataBuffer = StringBuilder()
                    events += 1
                    if (events >= 100) return null
                    if (json != null && isResponseFor(json, expectedId)) {
                        json.put("httpStatus", status)
                        return json
                    }
                }
            }
        }
        if (dataBuffer.isNotEmpty()) {
            val json = runCatching { JSONObject(dataBuffer.toString()) }.getOrNull()
            if (json != null && isResponseFor(json, expectedId)) {
                json.put("httpStatus", status)
                return json
            }
        }
        return null
    }

    private fun isResponseFor(json: JSONObject, expectedId: Any?): Boolean {
        val eventId = json.opt("id") ?: return false
        if (expectedId == null) return true
        return eventId == expectedId || eventId.toString() == expectedId.toString()
    }

    private fun startStdio() {
        val runtime = termuxRuntime
            ?: throw IllegalStateException("stdio servers need the embedded runtime")
        val proc = runtime.startMcpStdioProcess(
            command = config.command.orEmpty().trim(),
            args = config.args,
            env = config.env,
            owner = config.name,
        ) ?: throw IllegalStateException(
            "The Termux runtime is not ready — open Tools ▸ Terminal once to finish setup",
        )
        process = proc
        stdoutReader = BufferedReader(InputStreamReader(proc.inputStream, Charsets.UTF_8))
        stdioClosed = false
        Thread {
            runCatching {
                proc.errorStream.bufferedReader().useLines { lines ->
                    lines.forEach { line ->
                        if (line.isNotBlank()) onLog("[${config.name}] $line")
                    }
                }
            }
        }.apply { isDaemon = true }.start()
        Thread {
            runCatching {
                while (!stdioClosed) {
                    val line = stdoutReader?.readLine() ?: break
                    if (line.isBlank()) continue
                    val json = runCatching { JSONObject(line) }.getOrNull() ?: continue
                    val id = json.optLong("id", Long.MIN_VALUE)
                    if (id != Long.MIN_VALUE) {
                        pendingStdio.remove(id)?.complete(json)
                    }
                }
            }
            alive = false
            pendingStdio.values.forEach { runCatching { it.cancel() } }
            pendingStdio.clear()
            if (!stdioClosed) onClosed(true)
        }.apply { isDaemon = true }.start()
    }

    private suspend fun writeStdioLine(json: JSONObject) {
        writeMutex.withLock {
            val wrote = withTimeoutOrNull(STDIO_REQUEST_TIMEOUT_MS) {
                withContext(Dispatchers.IO) {
                    process?.outputStream?.apply {
                        write((json.toString() + "\n").toByteArray(Charsets.UTF_8))
                        flush()
                    } ?: throw IllegalStateException("stdio process is not running")
                    true
                }
            }
            if (wrote != true) {
                runCatching { process?.outputStream?.close() }
                throw IllegalStateException(
                    "stdio write timed out — ${config.name} stopped reading stdin",
                )
            }
        }
    }

    private suspend fun request(method: String, params: JSONObject?): JSONObject {
        val id = idCounter.getAndIncrement()
        val payload = JSONObject().apply {
            put("jsonrpc", "2.0")
            put("id", id)
            put("method", method)
            if (params != null) put("params", params)
        }
        if (config.isStdio) {
            return stdioRequest(id, payload)
        }
        val response = httpPost(payload)
        val error = response.optJSONObject("error")
        if (error != null && error.optInt("code", 0) != 0) {
            throw ArixMcpException(
                rpcCode = error.optInt("code"),
                message = error.optString("message"),
            )
        }
        return response
    }

    private suspend fun stdioRequest(id: Long, payload: JSONObject): JSONObject {
        val deferred = kotlinx.coroutines.CompletableDeferred<JSONObject>()
        pendingStdio[id] = deferred
        try {
            writeStdioLine(payload)
            val response = withTimeoutOrNull(STDIO_REQUEST_TIMEOUT_MS) { deferred.await() }
                ?: throw IllegalStateException("stdio request timed out after ${STDIO_REQUEST_TIMEOUT_MS / 1000}s")
            val error = response.optJSONObject("error")
            if (error != null && error.optInt("code", 0) != 0) {
                throw ArixMcpException(
                    rpcCode = error.optInt("code"),
                    message = error.optString("message"),
                )
            }
            return response
        } finally {
            pendingStdio.remove(id)
        }
    }

    private suspend fun notify(method: String, params: JSONObject?) {
        val payload = JSONObject().apply {
            put("jsonrpc", "2.0")
            put("method", method)
            if (params != null) put("params", params)
        }
        if (config.isStdio) {
            writeStdioLine(payload)
        } else {
            withContext(Dispatchers.IO) {
                val url = config.url.orEmpty().trim()
                if (url.isEmpty()) return@withContext
                val requestBuilder = Request.Builder()
                    .url(url)
                    .post(payload.toString().toRequestBody("application/json".toMediaType()))
                    .header("Accept", "application/json, text/event-stream")
                sessionHeader?.let { requestBuilder.header("Mcp-Session-Id", it) }
                config.headers.forEach { (name, value) -> requestBuilder.header(name, value) }
                runCatching { httpClient.newCall(requestBuilder.build()).execute().close() }
            }
        }
    }

    companion object {
        const val STDIO_REQUEST_TIMEOUT_MS = 120_000L

        fun mcpOkHttpClient(): OkHttpClient = OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(120, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }
}

class ArixMcpException(val rpcCode: Int?, message: String) : Exception(message)
