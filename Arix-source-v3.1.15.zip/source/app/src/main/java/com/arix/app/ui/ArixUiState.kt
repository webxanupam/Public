package com.arix.app.ui

import com.arix.app.data.ActiveSkillContext
import org.json.JSONObject
import com.arix.app.data.AppSettings
import com.arix.app.data.ChatUsageStatisticsSnapshot
import com.arix.app.data.InstalledSkill
import com.arix.app.data.LlmProviderConfig
import com.arix.app.data.ScheduledTask
import com.arix.app.data.SessionExecutionState
import com.arix.app.data.pi.PiCoreSetupState
import com.arix.app.data.pi.PiProviderAuthState
import com.arix.app.runtime.LocalRuntimeSetupState

internal const val DraftSessionId = "draft"

internal const val AssistantScreenContextSentinel =
    "[Screen context captured at wake time — a snapshot, not the live screen]"

internal fun stripAssistantScreenContext(text: String): String =
    if (text.contains(AssistantScreenContextSentinel)) {
        text.substringBefore("\n\n$AssistantScreenContextSentinel")
            .ifBlank { text.substringBefore(AssistantScreenContextSentinel) }
            .trim()
    } else {
        text
    }

enum class AppScreen {
    Welcome,
    Chat,
    Terminal,
    Browser,
    Files,
    Settings,
}

enum class MessageAuthor {
    User,
    Agent,
}

enum class MessageDisplayKind {
    Standard,
    HiddenContext,
    CompactStatus,
}

enum class AttachmentKind {
    Image,
    File;

    companion object {
        fun fromStored(
            value: String,
            mimeType: String,
        ): AttachmentKind = when {
            value == Image.name -> Image
            value == File.name -> File
            mimeType.startsWith("image/") -> Image
            else -> File
        }
    }
}

enum class AttachmentWorkspaceState {
    Pending,
    Ready,
    Failed,
}

data class ChatAttachment(
    val id: String,
    val uri: String,
    val name: String,
    val mimeType: String,
    val sizeBytes: Long?,
    val kind: AttachmentKind,
    val workspacePath: String = "",
    val workspaceState: AttachmentWorkspaceState = AttachmentWorkspaceState.Ready,
    val workspaceError: String = "",
    val workspaceBytesCopied: Long = 0L,
    val workspaceBytesPerSecond: Long = 0L,
    val inlineBase64: String = "",
)

data class ChatToolInvocation(
    val id: String,
    val toolName: String,
    val argumentsJson: String,
    val outputJson: String = "",
    val isRunning: Boolean = false,
    val startedAtUptimeMillis: Long = 0L,
    val completedAtUptimeMillis: Long? = null,
    val startedAtMillis: Long = 0L,
    val completedAtMillis: Long? = null,
    val timelineOrder: Long = 0L,
)

data class ChatUsageStatistics(
    val inputTokens: Long? = null,
    val outputTokens: Long? = null,
    val totalTokens: Long? = null,
    val reasoningTokens: Long? = null,
    val cachedInputTokens: Long? = null,
    val cacheWriteTokens: Long? = null,
    val outputDurationMillis: Long? = null,
    val requestCount: Int = 1,
    val tokenUsageSource: String = "unavailable",
    val startedAtMillis: Long = 0L,
    val firstTokenAtMillis: Long? = null,
    val completedAtMillis: Long = 0L,
) {
    val firstTokenLatencyMillis: Long?
        get() = firstTokenAtMillis?.let { firstToken ->
            if (startedAtMillis > 0L) (firstToken - startedAtMillis).coerceAtLeast(0L) else null
        }

    val outputTokensPerSecond: Double?
        get() {
            val output = outputTokens ?: return null
            outputDurationMillis?.takeIf { it > 0L }?.let { duration ->
                return output * 1_000.0 / duration
            }
            val outputStartedAt = firstTokenAtMillis ?: startedAtMillis.takeIf { it > 0L } ?: return null
            if (completedAtMillis <= outputStartedAt) return null
            val seconds = (completedAtMillis - outputStartedAt) / 1000.0
            if (seconds <= 0.0) return null
            return output / seconds
        }
}

data class ReasoningSummaryChunk(
    val id: String,
    val title: String = "",
    val detail: String = "",
    val rawText: String = "",
    val isPending: Boolean = false,
    val createdAtMillis: Long = 0L,
    val timelineOrder: Long = 0L,
)

data class ReasoningTrace(
    val id: String,
    val rawText: String = "",
    val chunks: List<ReasoningSummaryChunk> = emptyList(),
    val toolInvocations: List<ChatToolInvocation> = emptyList(),
    val latestStatusText: String = "",
    val startedAtMillis: Long = 0L,
    val completedAtMillis: Long? = null,
) {
    val hasSummary: Boolean
        get() = chunks.any { it.title.isNotBlank() || it.detail.isNotBlank() }

    val hasTimelineContent: Boolean
        get() = chunks.isNotEmpty() || toolInvocations.isNotEmpty()
}

sealed interface AssistantResponseBlock {
    val id: String

    data class Text(
        override val id: String,
        val text: String,
    ) : AssistantResponseBlock

    data class ToolGroup(
        override val id: String,
        val toolInvocations: List<ChatToolInvocation>,
    ) : AssistantResponseBlock

    data class Reasoning(
        override val id: String,
        val trace: ReasoningTrace,
    ) : AssistantResponseBlock

    data class Status(
        override val id: String,
        val text: String,
        val detail: String = "",
    ) : AssistantResponseBlock
}

internal fun List<AssistantResponseBlock>.sanitizedForReasoningOff(): List<AssistantResponseBlock> =
    flatMap { block ->
        when (block) {
            is AssistantResponseBlock.Text -> listOf(block)
            is AssistantResponseBlock.Reasoning -> block.trace.toolInvocations
                .takeIf { it.isNotEmpty() }
                ?.let { tools ->
                    listOf(AssistantResponseBlock.ToolGroup(block.id, tools))
                }
                .orEmpty()
            is AssistantResponseBlock.Status,
            is AssistantResponseBlock.ToolGroup -> listOf(block)
        }
    }

internal fun List<AssistantResponseBlock>.withAssistantFinalTextFallback(
    finalText: String,
    newBlockId: () -> String,
): List<AssistantResponseBlock> {
    if (finalText.isBlank() || lastOrNull() is AssistantResponseBlock.Text) return this
    return this + AssistantResponseBlock.Text(id = newBlockId(), text = finalText)
}

data class ChatMessage(
    val id: String,
    val author: MessageAuthor,
    val text: String,
    val createdAtMillis: Long = 0L,
    val attachments: List<ChatAttachment> = emptyList(),
    val toolInvocations: List<ChatToolInvocation> = emptyList(),
    val thoughtDurationMillis: Long? = null,
    val reasoningTrace: ReasoningTrace? = null,
    val branchGroup: ChatBranchGroup? = null,
    val responseGroupId: String? = null,
    val assistantActionsHidden: Boolean = false,
    val isIncomplete: Boolean = false,
    val statusText: String = "",
    val statusDetail: String = "",
    val providerPayloadJson: String = "",
    val displayKind: MessageDisplayKind = MessageDisplayKind.Standard,
    val usageStatistics: ChatUsageStatistics? = null,
)

data class ChatSession(
    val id: String,
    val title: String,
    val preview: String,
    val hasCustomTitle: Boolean = false,
    val messages: List<ChatMessage>,
    val messageCount: Int = messages.size,
    val lastMessageAtMillis: Long? = messages.maxOfOrNull { it.createdAtMillis },
    val selectedSkillIds: List<String> = emptyList(),
    val activeSkills: List<ActiveSkillContext> = emptyList(),
    val selectedModelKey: String = "",
)

data class ArixUiState(
    val currentScreen: AppScreen = AppScreen.Chat,
    val isStartupRouteResolved: Boolean = false,
    val sessions: List<ChatSession> = emptyList(),
    val usageStatisticsSnapshots: List<ChatUsageStatisticsSnapshot> = emptyList(),
    val currentSessionId: String = DraftSessionId,
    val draftInput: String = "",
    val draftAttachments: List<ChatAttachment> = emptyList(),
    val draftSelectedModelKey: String = "",
    val draftSelectedSkillIds: List<String> = emptyList(),
    val draftWorkspaceId: String? = null,
    val editingSessionId: String? = null,
    val editingMessageId: String? = null,
    val settings: AppSettings = AppSettings(),
    val isSending: Boolean = false,
    val pendingResponseSessionId: String? = null,
    val pendingToolInvocations: List<ChatToolInvocation> = emptyList(),
    val pendingResponseBlocks: List<AssistantResponseBlock> = emptyList(),
    val pendingAssistantText: String = "",
    val pendingStatusText: String = "",
    val pendingStatusDetail: String = "",
    val compactingSessionId: String? = null,
    val sessionExecutionStates: Map<String, SessionExecutionState> = emptyMap(),
    val unviewedCompletedSessionIds: Set<String> = emptySet(),
    val termuxSetupState: LocalRuntimeSetupState = LocalRuntimeSetupState(
        runtimeId = com.arix.app.data.LocalRuntimeId.Termux,
    ),
    val installedSkills: List<InstalledSkill> = emptyList(),
    val scheduledTasks: List<ScheduledTask> = emptyList(),
    val providerConfigs: List<LlmProviderConfig> = emptyList(),
    val modelCatalogInfo: Map<String, com.arix.app.data.ModelCatalogInfo> = emptyMap(),
    val thinkingLevelsByProviderModel: Map<String, List<String>> = emptyMap(),
    val thinkingLevelClampsByProviderModel: Map<String, Map<String, String>> = emptyMap(),
    val reasoningModels: Set<String> = emptySet(),
    val modelLimitsByProviderModel: Map<String, com.arix.app.data.ModelsDevModelLimits> = emptyMap(),
    val isFetchingModels: Boolean = false,
    val providerAuthState: PiProviderAuthState = PiProviderAuthState(),
    val piCoreSetupState: PiCoreSetupState = PiCoreSetupState(),
    val showStarterPromptHint: Boolean = false,
    val exitRequestSerial: Int = 0,
)
