package com.arix.app.ui
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.automirrored.rounded.ArrowForwardIos
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowDropDown
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Extension
import androidx.compose.material.icons.rounded.FileUpload
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import kotlinx.coroutines.delay
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.arix.app.BuildConfig

import com.arix.app.R
import com.arix.app.arixRuntime
import java.util.Locale
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.roundToInt
import com.arix.app.data.AgentWorkspaceMode
import com.arix.app.data.AutomaticModelPurpose
import com.arix.app.data.ChatUsageStatisticsSnapshot
import com.arix.app.data.AppLanguage
import com.arix.app.data.AppThemeMode
import com.arix.app.data.LlmProviderConfig
import com.arix.app.data.PiProviderCatalog
import com.arix.app.data.LocalRuntimeId
import com.arix.app.data.ProviderModelOption
import com.arix.app.data.ScheduledTask
import com.arix.app.data.ScheduledTaskCreator
import com.arix.app.data.ScheduledTaskSchedule
import com.arix.app.data.formatScheduledTaskTime
import com.arix.app.data.summary
import com.arix.app.data.availableModelOptions
import com.arix.app.data.availableModels
import com.arix.app.data.enabledModels
import com.arix.app.data.ProviderAuthMethod
import com.arix.app.data.pi.PiProviderAuthState
import com.arix.app.data.findModelOption
import com.arix.app.data.normalizeLlmInactivityReconnectTimeoutSeconds
import com.arix.app.data.normalizeOldCommandHistoryRetentionHours
import com.arix.app.data.normalizeTavilyBaseUrl
import com.arix.app.data.normalizeWebSearchEngine
import com.arix.app.data.quickActionLabel
import com.arix.app.data.resolveAutomaticModelKey
import com.arix.app.data.sortedForAutomaticModelPurpose
import com.arix.app.runtime.LocalRuntimeIssue
import org.json.JSONArray
import org.json.JSONObject
import com.arix.app.runtime.LocalRuntimeSetupState
import com.arix.app.runtime.AndroidTermuxFileManagerRuntime
import com.arix.app.ui.theme.ArixBackground
import com.arix.app.ui.theme.ArixOnSurface
import com.arix.app.ui.theme.ArixOnPrimary
import com.arix.app.ui.theme.ArixOnSurfaceVariant
import com.arix.app.ui.theme.ArixPrimary
import com.arix.app.ui.theme.ArixScrim
import com.arix.app.ui.theme.LightArixPalette
import com.arix.app.ui.theme.ArixSettingsBackground
import com.arix.app.ui.theme.ArixSurface
import com.arix.app.ui.theme.ArixSurfaceHigh
import kotlinx.coroutines.launch

private enum class SettingsPage {
    Hub,
    Providers,
    DefaultModels,
    DefaultChatModel,
    DefaultTitleModel,
    DefaultNamingModel,
    DefaultCompactingModel,
    AddProvider,
    EditProvider,
    Personalization,
    WebTools,
    Reliability,
    Skills,
    AddSkill,
    Extensions,
    PhoneControl,
    ScheduledTasks,
    AddScheduledTask,
    EditScheduledTask,
    Termux,
    McpServers,
    Connectors,
    TelegramBot,
    Statistics,
    Storage,
    Permissions,
    Developer,
    About,
}

private fun SettingsPage.depth(): Int = when (this) {
    SettingsPage.Hub -> 0
    SettingsPage.Providers,
    SettingsPage.Personalization,
    SettingsPage.WebTools,
    SettingsPage.Reliability,
    SettingsPage.Skills,
    SettingsPage.Extensions,
    SettingsPage.PhoneControl,
    SettingsPage.ScheduledTasks,
    SettingsPage.Termux,
    SettingsPage.McpServers,
    SettingsPage.Connectors,
    SettingsPage.TelegramBot,
    SettingsPage.Statistics,
    SettingsPage.Storage,
    SettingsPage.Permissions,
    SettingsPage.Developer,
    SettingsPage.About -> 1
    SettingsPage.DefaultModels,
    SettingsPage.AddProvider,
    SettingsPage.EditProvider,
    SettingsPage.AddSkill,
    SettingsPage.AddScheduledTask,
    SettingsPage.EditScheduledTask -> 2
    SettingsPage.DefaultChatModel,
    SettingsPage.DefaultTitleModel,
    SettingsPage.DefaultNamingModel,
    SettingsPage.DefaultCompactingModel -> 3
}

private fun formatTaskMinute(minuteOfDay: Int): String {
    val normalized = minuteOfDay.coerceIn(0, 1_439)
    return "%02d:%02d".format(Locale.US, normalized / 60, normalized % 60)
}

private fun parseTaskMinute(value: String): Int? {
    val parts = value.trim().split(':')
    if (parts.size != 2) return null
    val hour = parts[0].toIntOrNull() ?: return null
    val minute = parts[1].toIntOrNull() ?: return null
    if (hour !in 0..23 || minute !in 0..59) return null
    return hour * 60 + minute
}

private fun parseTaskTimes(value: String): List<Int> =
    value.split(',', ';', '\n')
        .mapNotNull(::parseTaskMinute)
        .distinct()
        .sorted()

private fun parseTaskDays(value: String): List<Int> =
    value.split(',', ';', ' ')
        .mapNotNull { raw ->
            val normalized = raw.trim().lowercase(Locale.US)
            when (normalized.take(3)) {
                "mon" -> 1
                "tue" -> 2
                "wed" -> 3
                "thu" -> 4
                "fri" -> 5
                "sat" -> 6
                "sun" -> 7
                else -> normalized.toIntOrNull()
            }?.takeIf { it in 1..7 }
        }
        .distinct()
        .sorted()

private const val PageTransitionDuration = 320
private val PageTransitionEasing = CubicBezierEasing(0.22f, 0.84f, 0.18f, 1f)
private val SettingsTopFadeHeight = 40.dp
private val StatisticsInputColor = Color(0xFF5D7CFF)
private val StatisticsOutputColor = Color(0xFF7B68EE)
private val StatisticsCacheColor = Color(0xFF2FB7A5)
private val StatisticsCacheWriteColor = Color(0xFFE8A33D)

@Composable
private fun statisticsReasoningColor(): Color =
    if (ArixBackground == LightArixPalette.background) Color(0xFF4457C7) else Color(0xFFA9B8FF)

@Composable
private fun statisticsNeutralChartColor(): Color =
    if (ArixBackground == LightArixPalette.background) Color(0xFFC9CDD6) else Color(0xFFDCE4FF)

@Composable
private fun settingsEnabledProvidersSummary(enabledCount: Int): String =
    stringResource(R.string.settings_enabled_providers_count, enabledCount)

@Composable
private fun settingsReleaseSummary(versionName: String): String =
    stringResource(R.string.settings_release_summary, versionName)

private fun settingsTopOverlayBodyGradient(): Brush = Brush.verticalGradient(
    colorStops = arrayOf(
        0.0f to ArixSettingsBackground.copy(alpha = 0.96f),
        0.18f to ArixSettingsBackground.copy(alpha = 0.86f),
        0.42f to ArixSettingsBackground.copy(alpha = 0.48f),
        0.72f to ArixSettingsBackground.copy(alpha = 0.22f),
        1.0f to ArixSettingsBackground.copy(alpha = 0.12f),
    )
)

private fun settingsTopOverlayTailGradient(): Brush = Brush.verticalGradient(
    colorStops = arrayOf(
        0.0f to ArixSettingsBackground.copy(alpha = 0.12f),
        0.42f to ArixSettingsBackground.copy(alpha = 0.05f),
        1.0f to Color.Transparent,
    )
)

private data class SettingsSyncSnapshot(
    val systemPrompt: String,
    val tavilyApiKey: String,
    val tavilyBaseUrl: String,
    val webSearchEngine: String,
    val saveResearchToMemory: Boolean,
    val unrestrictedMode: Boolean,
    val llmInactivityReconnectTimeoutSeconds: Int,
    val keepTasksRunningInBackground: Boolean,
    val notifyOnTaskCompletion: Boolean,
    val agentWorkspaceMode: AgentWorkspaceMode,
    val autoCleanOldCommandHistory: Boolean,
    val oldCommandHistoryRetentionHours: Int,
    val language: AppLanguage,
    val themeMode: AppThemeMode,
    val defaultChatModelKey: String,
    val defaultTitleModelKey: String,
    val defaultNamingModelKey: String,
    val defaultCompactingModelKey: String,
)

@Composable
fun SettingsScreen(
    systemPrompt: String,
    tavilyApiKey: String,
    tavilyBaseUrl: String,
    webSearchEngine: String,
    saveResearchToMemory: Boolean,
    unrestrictedMode: Boolean,
    llmInactivityReconnectTimeoutSeconds: Int,
    keepTasksRunningInBackground: Boolean,
    notifyOnTaskCompletion: Boolean,
    agentWorkspaceMode: AgentWorkspaceMode,
    autoCleanOldCommandHistory: Boolean,
    oldCommandHistoryRetentionHours: Int,
    language: AppLanguage,
    themeMode: AppThemeMode,
    defaultChatModelKey: String,
    defaultTitleModelKey: String,
    defaultNamingModelKey: String,
    defaultCompactingModelKey: String,
    providerConfigs: List<LlmProviderConfig>,
    usageStatisticsSnapshots: List<ChatUsageStatisticsSnapshot>,
    scheduledTasks: List<ScheduledTask>,
    termuxSetupState: LocalRuntimeSetupState,
    enabledRuntimeIds: Set<LocalRuntimeId>,
    defaultRuntimeId: LocalRuntimeId?,
    termuxFileManagerRuntime: AndroidTermuxFileManagerRuntime,
    installedSkills: List<com.arix.app.data.InstalledSkill>,
    isFetchingModels: Boolean,
    providerAuthState: PiProviderAuthState,
    onSave: (
        String,
        String,
        String,
        String,
        Boolean,
        Boolean,
        Int,
        Boolean,
        Boolean,
        AgentWorkspaceMode,
        Boolean,
        Int,
        AppLanguage,
        AppThemeMode,
        String,
        String,
        String,
        String,
    ) -> Unit,
    onUpsertProviderConfig: (LlmProviderConfig) -> Unit,
    onRemoveProviderConfig: (String) -> Unit,
    onSetProviderEnabled: (String, Boolean) -> Unit,
    onFetchModels: (LlmProviderConfig, (List<String>) -> Unit) -> Unit,
    onStartProviderLogin: (String, String, ProviderAuthMethod, String) -> Unit,
    onSubmitProviderAuthPrompt: (String, String, Boolean) -> Unit,
    onClearProviderAuthState: () -> Unit,
    onImportSkillFolder: () -> Unit,
    onImportSkillZip: ((Boolean) -> Unit) -> Unit,
    onInstallSkillUrl: (String, (Boolean) -> Unit) -> Unit,
    onToggleSkillEnabled: (String, Boolean) -> Unit,
    onRemoveSkill: (String) -> Unit,
    onReinstallBuiltInSkill: (String) -> Unit = {},
    onSaveScheduledTask: (String?, String, String, ScheduledTaskSchedule, Boolean) -> Unit,
    onToggleScheduledTaskEnabled: (String, Boolean) -> Unit,
    onRemoveScheduledTask: (String) -> Unit,
    onImportAppData: () -> Unit,
    onExportAppData: () -> Unit,
    onExportLogs: () -> Unit,
    onInitializeTermuxRuntime: () -> Unit,
    onResetTermuxRuntime: () -> Unit,
    onRefreshTermuxSetup: () -> Unit,
    onSetDefaultRuntime: (LocalRuntimeId) -> Unit,
    onOpenWebsite: () -> Unit,
    onOpenPrivacyPolicy: () -> Unit,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    var systemPromptValue by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(systemPrompt))
    }
    var tavilyApiKeyValue by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(tavilyApiKey))
    }
    var tavilyBaseUrlValue by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(tavilyBaseUrl))
    }
    var webSearchEngineValue by rememberSaveable {
        mutableStateOf(normalizeWebSearchEngine(webSearchEngine))
    }
    var saveResearchToMemoryValue by rememberSaveable {
        mutableStateOf(saveResearchToMemory)
    }
    var unrestrictedModeValue by rememberSaveable {
        mutableStateOf(unrestrictedMode)
    }
    var llmInactivityReconnectTimeoutValue by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(llmInactivityReconnectTimeoutSeconds.toString()))
    }
    var keepTasksRunningInBackgroundValue by rememberSaveable {
        mutableStateOf(keepTasksRunningInBackground)
    }
    var notifyOnTaskCompletionValue by rememberSaveable {
        mutableStateOf(notifyOnTaskCompletion)
    }
    var agentWorkspaceModeValue by rememberSaveable {
        mutableStateOf(agentWorkspaceMode)
    }
    var autoCleanOldCommandHistoryValue by rememberSaveable {
        mutableStateOf(autoCleanOldCommandHistory)
    }
    var oldCommandHistoryRetentionHoursValue by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(oldCommandHistoryRetentionHours.toString()))
    }
    var languageValue by rememberSaveable {
        mutableStateOf(language)
    }
    var themeModeValue by rememberSaveable {
        mutableStateOf(themeMode)
    }
    LaunchedEffect(
        autoCleanOldCommandHistory,
        oldCommandHistoryRetentionHours,
    ) {
        autoCleanOldCommandHistoryValue = autoCleanOldCommandHistory
        oldCommandHistoryRetentionHoursValue = TextFieldValue(oldCommandHistoryRetentionHours.toString())
    }
    LaunchedEffect(language) {
        languageValue = language
    }
    var defaultChatModelKeyValue by rememberSaveable { mutableStateOf(defaultChatModelKey) }
    var defaultTitleModelKeyValue by rememberSaveable { mutableStateOf(defaultTitleModelKey) }
    var defaultNamingModelKeyValue by rememberSaveable { mutableStateOf(defaultNamingModelKey) }
    var defaultCompactingModelKeyValue by rememberSaveable { mutableStateOf(defaultCompactingModelKey) }

    LaunchedEffect(systemPrompt, tavilyApiKey, tavilyBaseUrl, webSearchEngine) {
        if (systemPromptValue.text != systemPrompt) {
            systemPromptValue = TextFieldValue(systemPrompt)
        }
        if (tavilyApiKeyValue.text != tavilyApiKey) {
            tavilyApiKeyValue = TextFieldValue(tavilyApiKey)
        }
        if (tavilyBaseUrlValue.text != tavilyBaseUrl) {
            tavilyBaseUrlValue = TextFieldValue(tavilyBaseUrl)
        }
        if (webSearchEngineValue != normalizeWebSearchEngine(webSearchEngine)) {
            webSearchEngineValue = normalizeWebSearchEngine(webSearchEngine)
        }
    }
    LaunchedEffect(
        saveResearchToMemory,
        unrestrictedMode,
        keepTasksRunningInBackground,
        notifyOnTaskCompletion,
    ) {
        saveResearchToMemoryValue = saveResearchToMemory
        unrestrictedModeValue = unrestrictedMode
        keepTasksRunningInBackgroundValue = keepTasksRunningInBackground
        notifyOnTaskCompletionValue = notifyOnTaskCompletion
    }
    LaunchedEffect(llmInactivityReconnectTimeoutSeconds) {
        if (llmInactivityReconnectTimeoutValue.text.trim() != llmInactivityReconnectTimeoutSeconds.toString()) {
            llmInactivityReconnectTimeoutValue = TextFieldValue(llmInactivityReconnectTimeoutSeconds.toString())
        }
    }
    LaunchedEffect(agentWorkspaceMode, themeMode) {
        if (agentWorkspaceModeValue != agentWorkspaceMode) {
            agentWorkspaceModeValue = agentWorkspaceMode
        }
        if (themeModeValue != themeMode) {
            themeModeValue = themeMode
        }
    }
    LaunchedEffect(
        defaultChatModelKey,
        defaultTitleModelKey,
        defaultNamingModelKey,
        defaultCompactingModelKey,
    ) {
        if (defaultChatModelKeyValue != defaultChatModelKey) {
            defaultChatModelKeyValue = defaultChatModelKey
        }
        if (defaultTitleModelKeyValue != defaultTitleModelKey) {
            defaultTitleModelKeyValue = defaultTitleModelKey
        }
        if (defaultNamingModelKeyValue != defaultNamingModelKey) {
            defaultNamingModelKeyValue = defaultNamingModelKey
        }
        if (defaultCompactingModelKeyValue != defaultCompactingModelKey) {
            defaultCompactingModelKeyValue = defaultCompactingModelKey
        }
    }

    fun settingsSyncSnapshot() = SettingsSyncSnapshot(
        systemPrompt = systemPrompt,
        tavilyApiKey = tavilyApiKey,
        tavilyBaseUrl = normalizeTavilyBaseUrl(tavilyBaseUrl),
        webSearchEngine = normalizeWebSearchEngine(webSearchEngine),
        saveResearchToMemory = saveResearchToMemory,
        unrestrictedMode = unrestrictedMode,
        llmInactivityReconnectTimeoutSeconds = normalizeLlmInactivityReconnectTimeoutSeconds(
            llmInactivityReconnectTimeoutSeconds,
        ),
        keepTasksRunningInBackground = keepTasksRunningInBackground,
        notifyOnTaskCompletion = notifyOnTaskCompletion,
        agentWorkspaceMode = agentWorkspaceMode,
        autoCleanOldCommandHistory = autoCleanOldCommandHistory,
        oldCommandHistoryRetentionHours = normalizeOldCommandHistoryRetentionHours(
            oldCommandHistoryRetentionHours,
        ),
        language = language,
        themeMode = themeMode,
        defaultChatModelKey = defaultChatModelKey,
        defaultTitleModelKey = defaultTitleModelKey,
        defaultNamingModelKey = defaultNamingModelKey,
        defaultCompactingModelKey = defaultCompactingModelKey,
    )
    var lastSyncedSettings by remember { mutableStateOf(settingsSyncSnapshot()) }
    LaunchedEffect(
        systemPrompt,
        tavilyApiKey,
        tavilyBaseUrl,
        webSearchEngine,
        saveResearchToMemory,
        unrestrictedMode,
        llmInactivityReconnectTimeoutSeconds,
        keepTasksRunningInBackground,
        notifyOnTaskCompletion,
        agentWorkspaceMode,
        autoCleanOldCommandHistory,
        oldCommandHistoryRetentionHours,
        language,
        themeMode,
        defaultChatModelKey,
        defaultTitleModelKey,
        defaultNamingModelKey,
        defaultCompactingModelKey,
    ) {
        lastSyncedSettings = settingsSyncSnapshot()
    }

    val enabledModelOptions = remember(providerConfigs) { providerConfigs.availableModelOptions() }

    var editingProviderId by rememberSaveable { mutableStateOf<String?>(null) }
    var editingScheduledTaskId by rememberSaveable { mutableStateOf<String?>(null) }
    fun persistSettings() {
        val synced = lastSyncedSettings
        fun <T> edited(local: T, syncedValue: T, current: T): T =
            if (local != syncedValue) local else current
        onSave(
            edited(systemPromptValue.text, synced.systemPrompt, systemPrompt),
            edited(tavilyApiKeyValue.text, synced.tavilyApiKey, tavilyApiKey),
            edited(
                normalizeTavilyBaseUrl(tavilyBaseUrlValue.text),
                synced.tavilyBaseUrl,
                normalizeTavilyBaseUrl(tavilyBaseUrl),
            ),
            edited(
                normalizeWebSearchEngine(webSearchEngineValue),
                synced.webSearchEngine,
                normalizeWebSearchEngine(webSearchEngine),
            ),
            edited(saveResearchToMemoryValue, synced.saveResearchToMemory, saveResearchToMemory),
            edited(unrestrictedModeValue, synced.unrestrictedMode, unrestrictedMode),
            edited(
                normalizeLlmInactivityReconnectTimeoutSeconds(
                    llmInactivityReconnectTimeoutValue.text.trim().toIntOrNull()
                ),
                synced.llmInactivityReconnectTimeoutSeconds,
                normalizeLlmInactivityReconnectTimeoutSeconds(llmInactivityReconnectTimeoutSeconds),
            ),
            edited(keepTasksRunningInBackgroundValue, synced.keepTasksRunningInBackground, keepTasksRunningInBackground),
            edited(notifyOnTaskCompletionValue, synced.notifyOnTaskCompletion, notifyOnTaskCompletion),
            edited(agentWorkspaceModeValue, synced.agentWorkspaceMode, agentWorkspaceMode),
            edited(autoCleanOldCommandHistoryValue, synced.autoCleanOldCommandHistory, autoCleanOldCommandHistory),
            edited(
                normalizeOldCommandHistoryRetentionHours(
                    oldCommandHistoryRetentionHoursValue.text.trim().toIntOrNull()
                ),
                synced.oldCommandHistoryRetentionHours,
                normalizeOldCommandHistoryRetentionHours(oldCommandHistoryRetentionHours),
            ),
            edited(languageValue, synced.language, language),
            edited(themeModeValue, synced.themeMode, themeMode),
            edited(defaultChatModelKeyValue, synced.defaultChatModelKey, defaultChatModelKey),
            edited(defaultTitleModelKeyValue, synced.defaultTitleModelKey, defaultTitleModelKey),
            edited(defaultNamingModelKeyValue, synced.defaultNamingModelKey, defaultNamingModelKey),
            edited(defaultCompactingModelKeyValue, synced.defaultCompactingModelKey, defaultCompactingModelKey),
        )
    }

    fun persistAndExit() {
        persistSettings()
        onBack()
    }

    LifecycleEventEffect(Lifecycle.Event.ON_STOP) {
        persistSettings()
    }

    var currentPage by rememberSaveable { mutableStateOf(SettingsPage.Hub.name) }
    val page = SettingsPage.entries.firstOrNull { it.name == currentPage } ?: SettingsPage.Hub

    fun parentPage(): SettingsPage = when (page) {
        SettingsPage.DefaultModels -> SettingsPage.Providers
        SettingsPage.DefaultChatModel,
        SettingsPage.DefaultTitleModel,
        SettingsPage.DefaultNamingModel,
        SettingsPage.DefaultCompactingModel -> SettingsPage.DefaultModels
        SettingsPage.AddProvider, SettingsPage.EditProvider -> SettingsPage.Providers
        SettingsPage.AddSkill -> SettingsPage.Skills
        SettingsPage.AddScheduledTask, SettingsPage.EditScheduledTask -> SettingsPage.ScheduledTasks
        SettingsPage.Connectors -> SettingsPage.McpServers
        else -> SettingsPage.Hub
    }

    BackHandler {
        when (page) {
            SettingsPage.Hub -> persistAndExit()
            else -> currentPage = parentPage().name
        }
    }

    val pageStateHolder = rememberSaveableStateHolder()
    AnimatedContent(
        targetState = page,
        transitionSpec = {
            val isForward = targetState.depth() > initialState.depth()
            val enterSlide = slideInHorizontally(
                animationSpec = tween(PageTransitionDuration, easing = PageTransitionEasing),
                initialOffsetX = { if (isForward) it / 3 else -it / 3 },
            ) + fadeIn(tween(PageTransitionDuration, easing = PageTransitionEasing))
            val exitSlide = slideOutHorizontally(
                animationSpec = tween(PageTransitionDuration, easing = PageTransitionEasing),
                targetOffsetX = { if (isForward) -it / 3 else it / 3 },
            ) + fadeOut(tween(PageTransitionDuration, easing = PageTransitionEasing))
            enterSlide togetherWith exitSlide
        },
        label = "settings_page_transition",
    ) { targetPage ->
        pageStateHolder.SaveableStateProvider(targetPage.name) {
            when (targetPage) {
            SettingsPage.Hub -> SettingsHub(
                activeProviderName = providerConfigs.count { it.isEnabled }.let { enabledCount ->
                    when {
                        enabledCount > 1 -> settingsEnabledProvidersSummary(enabledCount)
                        enabledCount == 1 -> providerConfigs.firstOrNull { it.isEnabled }?.name.orEmpty()
                        enabledModelOptions.isNotEmpty() -> enabledModelOptions.first().fullLabel
                        else -> stringResource(R.string.settings_no_providers_configured)
                    }
                },
                systemPromptSnippet = systemPromptValue.text.take(60),
                tavilyConfigured = tavilyApiKeyValue.text.isNotBlank(),
                reliabilitySummary = buildString {
                    append(
                        stringResource(
                            R.string.settings_reconnect_after_seconds,
                            normalizeLlmInactivityReconnectTimeoutSeconds(
                                llmInactivityReconnectTimeoutValue.text.trim().toIntOrNull()
                            ),
                        )
                    )
                    append(" · ")
                    append(
                        stringResource(
                            if (keepTasksRunningInBackgroundValue) {
                                R.string.settings_background_runs_on
                            } else {
                                R.string.settings_background_runs_off
                            },
                        )
                    )
                },
                termuxReady = termuxSetupState.isReady,
                defaultRuntimeId = defaultRuntimeId,
                skillCount = installedSkills.size,
                scheduledTaskCount = scheduledTasks.size,
                statisticsSummary = buildSettingsStatisticsSummary(
                    remember(usageStatisticsSnapshots) { buildUsageStatisticsReport(usageStatisticsSnapshots) },
                ),
                onNavigate = { page ->
                    currentPage = page.name
                },
                onBack = ::persistAndExit,
            )

            SettingsPage.Providers -> ProvidersListPage(
                providerConfigs = providerConfigs,
                onSetProviderEnabled = onSetProviderEnabled,
                onOpenDefaultModels = { currentPage = SettingsPage.DefaultModels.name },
                onEdit = { id ->
                    editingProviderId = id
                    currentPage = SettingsPage.EditProvider.name
                },
                onRemove = onRemoveProviderConfig,
                onAddNew = { currentPage = SettingsPage.AddProvider.name },
                onBack = { currentPage = SettingsPage.Hub.name },
            )

            SettingsPage.DefaultModels -> DefaultModelsPage(
                modelOptions = enabledModelOptions,
                defaultChatModelKey = defaultChatModelKeyValue,
                defaultTitleModelKey = defaultTitleModelKeyValue,
                defaultNamingModelKey = defaultNamingModelKeyValue,
                defaultCompactingModelKey = defaultCompactingModelKeyValue,
                onOpenDefaultChatModel = { currentPage = SettingsPage.DefaultChatModel.name },
                onOpenDefaultTitleModel = { currentPage = SettingsPage.DefaultTitleModel.name },
                onOpenDefaultNamingModel = { currentPage = SettingsPage.DefaultNamingModel.name },
                onOpenDefaultCompactingModel = { currentPage = SettingsPage.DefaultCompactingModel.name },
                onBack = { currentPage = SettingsPage.Providers.name },
            )

            SettingsPage.DefaultChatModel -> ModelSelectionListPage(
                title = stringResource(R.string.settings_default_chat_model),
                subtitle = stringResource(R.string.settings_default_chat_model_subtitle),
                selectedKey = defaultChatModelKeyValue,
                options = enabledModelOptions,
                purpose = AutomaticModelPurpose.Chat,
                automaticLabel = enabledModelOptions.findModelOption(
                    enabledModelOptions.resolveAutomaticModelKey(AutomaticModelPurpose.Chat)
                )?.fullLabel?.let { stringResource(R.string.settings_automatic_model_with_name, it) }
                    ?: stringResource(R.string.settings_automatic_model),
                automaticSubtitle = stringResource(R.string.settings_prioritize_sota_models),
                onSelected = {
                    defaultChatModelKeyValue = it
                    persistSettings()
                },
                onBack = { currentPage = SettingsPage.DefaultModels.name },
            )

            SettingsPage.DefaultTitleModel -> ModelSelectionListPage(
                title = stringResource(R.string.settings_default_title_model),
                subtitle = stringResource(R.string.settings_default_title_model_subtitle),
                selectedKey = defaultTitleModelKeyValue,
                options = enabledModelOptions,
                purpose = AutomaticModelPurpose.Title,
                automaticLabel = enabledModelOptions.findModelOption(
                    enabledModelOptions.resolveAutomaticModelKey(AutomaticModelPurpose.Title)
                        .ifBlank { enabledModelOptions.resolveAutomaticModelKey(AutomaticModelPurpose.Chat) }
                )?.fullLabel?.let { stringResource(R.string.settings_automatic_model_with_name, it) }
                    ?: stringResource(R.string.settings_automatic_model),
                automaticSubtitle = stringResource(R.string.settings_prioritize_sota_models),
                onSelected = {
                    defaultTitleModelKeyValue = it
                    persistSettings()
                },
                onBack = { currentPage = SettingsPage.DefaultModels.name },
            )

            SettingsPage.DefaultNamingModel -> ModelSelectionListPage(
                title = stringResource(R.string.settings_default_naming_model),
                subtitle = stringResource(R.string.settings_default_naming_model_subtitle),
                selectedKey = defaultNamingModelKeyValue,
                options = enabledModelOptions,
                purpose = AutomaticModelPurpose.Naming,
                automaticLabel = enabledModelOptions.findModelOption(
                    enabledModelOptions.resolveAutomaticModelKey(AutomaticModelPurpose.Naming)
                        .ifBlank { enabledModelOptions.resolveAutomaticModelKey(AutomaticModelPurpose.Chat) }
                )?.fullLabel?.let { stringResource(R.string.settings_automatic_model_with_name, it) }
                    ?: stringResource(R.string.settings_automatic_model),
                automaticSubtitle = stringResource(R.string.settings_prioritize_sota_models),
                onSelected = {
                    defaultNamingModelKeyValue = it
                    persistSettings()
                },
                onBack = { currentPage = SettingsPage.DefaultModels.name },
            )

            SettingsPage.DefaultCompactingModel -> ModelSelectionListPage(
                title = stringResource(R.string.settings_default_compacting_model),
                subtitle = stringResource(R.string.settings_default_compacting_model_subtitle),
                selectedKey = defaultCompactingModelKeyValue,
                options = enabledModelOptions,
                purpose = AutomaticModelPurpose.Compacting,
                automaticLabel = enabledModelOptions.findModelOption(
                    enabledModelOptions.resolveAutomaticModelKey(AutomaticModelPurpose.Compacting)
                        .ifBlank { enabledModelOptions.resolveAutomaticModelKey(AutomaticModelPurpose.Chat) }
                )?.fullLabel?.let { stringResource(R.string.settings_automatic_model_with_name, it) }
                    ?: stringResource(R.string.settings_automatic_model),
                automaticSubtitle = stringResource(R.string.settings_prioritize_efficient_summary_models),
                onSelected = {
                    defaultCompactingModelKeyValue = it
                    persistSettings()
                },
                onBack = { currentPage = SettingsPage.DefaultModels.name },
            )

            SettingsPage.AddProvider -> ProviderEditPage(
                existingConfig = null,
                existingProviderIds = providerConfigs.map { it.providerId }.toSet(),
                isFetchingModels = isFetchingModels,
                onSave = { config ->
                    onUpsertProviderConfig(config)
                    currentPage = SettingsPage.Providers.name
                },
                onModelEnabledChange = {},
                onFetchModels = onFetchModels,
                authState = providerAuthState,
                onStartProviderLogin = onStartProviderLogin,
                onSubmitAuthPrompt = onSubmitProviderAuthPrompt,
                onClearAuthState = onClearProviderAuthState,
                onBack = { currentPage = SettingsPage.Providers.name },
            )

            SettingsPage.EditProvider -> {
                val configToEdit = providerConfigs.firstOrNull { it.id == editingProviderId }
                ProviderEditPage(
                    existingConfig = configToEdit,
                    existingProviderIds = providerConfigs.map { it.providerId }.toSet(),
                    isFetchingModels = isFetchingModels,
                    onSave = { config ->
                        onUpsertProviderConfig(config)
                        currentPage = SettingsPage.Providers.name
                    },
                    onModelEnabledChange = onUpsertProviderConfig,
                    onFetchModels = onFetchModels,
                    authState = providerAuthState,
                    onStartProviderLogin = onStartProviderLogin,
                    onSubmitAuthPrompt = onSubmitProviderAuthPrompt,
                    onClearAuthState = onClearProviderAuthState,
                    onBack = { currentPage = SettingsPage.Providers.name },
                )
            }

            SettingsPage.Personalization -> PersonalizationPage(
                title = stringResource(R.string.settings_personalization),
                systemPromptValue = systemPromptValue,
                onSystemPromptChanged = { systemPromptValue = it },
                unrestrictedMode = unrestrictedModeValue,
                onUnrestrictedModeChanged = { unrestrictedModeValue = it },
                onBack = { currentPage = SettingsPage.Hub.name },
            )

            SettingsPage.WebTools -> WebToolsPage(
                title = stringResource(R.string.settings_web_tools),
                tavilyApiKeyValue = tavilyApiKeyValue,
                onTavilyApiKeyChanged = { tavilyApiKeyValue = it },
                tavilyBaseUrlValue = tavilyBaseUrlValue,
                onTavilyBaseUrlChanged = { tavilyBaseUrlValue = it },
                webSearchEngine = webSearchEngineValue,
                onWebSearchEngineChanged = { webSearchEngineValue = it },
                saveResearchToMemory = saveResearchToMemoryValue,
                onSaveResearchToMemoryChanged = { saveResearchToMemoryValue = it },
                onBack = { currentPage = SettingsPage.Hub.name },
            )

            SettingsPage.Reliability -> ReliabilityPage(
                title = stringResource(R.string.settings_reliability),
                llmInactivityReconnectTimeoutValue = llmInactivityReconnectTimeoutValue,
                onLlmInactivityReconnectTimeoutChanged = { llmInactivityReconnectTimeoutValue = it },
                keepTasksRunningInBackground = keepTasksRunningInBackgroundValue,
                onKeepTasksRunningInBackgroundChanged = { keepTasksRunningInBackgroundValue = it },
                notifyOnTaskCompletion = notifyOnTaskCompletionValue,
                onNotifyOnTaskCompletionChanged = { notifyOnTaskCompletionValue = it },
                onBack = { currentPage = SettingsPage.Hub.name },
            )

            SettingsPage.Skills -> SkillsListPage(
                title = stringResource(R.string.settings_agent_skills),
                installedSkills = installedSkills,
                onToggleSkillEnabled = onToggleSkillEnabled,
                onRemoveSkill = onRemoveSkill,
                onAddNew = { currentPage = SettingsPage.AddSkill.name },
                onReinstallBuiltIn = onReinstallBuiltInSkill,
                onBack = { currentPage = SettingsPage.Hub.name },
            )

            SettingsPage.AddSkill -> AddSkillPage(
                title = stringResource(R.string.settings_agent_skills),
                onImportSkillFolder = onImportSkillFolder,
                onImportSkillZip = { callback ->
                    onImportSkillZip { success ->
                        callback(success)
                        if (success) currentPage = SettingsPage.Skills.name
                    }
                },
                onInstallSkillUrl = { url, callback ->
                    onInstallSkillUrl(url) { success ->
                        callback(success)
                        if (success) currentPage = SettingsPage.Skills.name
                    }
                },
                onBack = { currentPage = SettingsPage.Skills.name },
            )

            SettingsPage.Extensions -> {
                val runtime = context.arixRuntime
                ArixExtensionsPage(
                    packageManager = runtime.extensionPackageManager,
                    extensionManager = runtime.appExtensionManager,
                    onBack = { currentPage = SettingsPage.Hub.name },
                )
            }

            SettingsPage.PhoneControl -> {
                val app = context.applicationContext as com.arix.app.ArixApplication
                ArixPhoneControlPage(
                    phone = app.phone,
                    onBack = { currentPage = SettingsPage.Hub.name },
                )
            }

            SettingsPage.ScheduledTasks -> ScheduledTasksPage(
                tasks = scheduledTasks,
                onToggleEnabled = onToggleScheduledTaskEnabled,
                onRemove = onRemoveScheduledTask,
                onEdit = { taskId ->
                    editingScheduledTaskId = taskId
                    currentPage = SettingsPage.EditScheduledTask.name
                },
                onAddNew = { currentPage = SettingsPage.AddScheduledTask.name },
                onBack = { currentPage = SettingsPage.Hub.name },
            )

            SettingsPage.AddScheduledTask -> ScheduledTaskEditPage(
                existingTask = null,
                onSave = { name, prompt, schedule, enabled ->
                    onSaveScheduledTask(null, name, prompt, schedule, enabled)
                    currentPage = SettingsPage.ScheduledTasks.name
                },
                onBack = { currentPage = SettingsPage.ScheduledTasks.name },
            )

            SettingsPage.EditScheduledTask -> ScheduledTaskEditPage(
                existingTask = scheduledTasks.firstOrNull { it.id == editingScheduledTaskId },
                onSave = { name, prompt, schedule, enabled ->
                    onSaveScheduledTask(editingScheduledTaskId, name, prompt, schedule, enabled)
                    currentPage = SettingsPage.ScheduledTasks.name
                },
                onBack = { currentPage = SettingsPage.ScheduledTasks.name },
            )

            SettingsPage.Termux -> TermuxSettingsPage(
                title = "Termux",
                setupState = termuxSetupState,
                isDefaultRuntime = defaultRuntimeId == LocalRuntimeId.Termux,
                onInitialize = onInitializeTermuxRuntime,
                onReset = onResetTermuxRuntime,
                onRefresh = onRefreshTermuxSetup,
                onSetDefault = { onSetDefaultRuntime(LocalRuntimeId.Termux) },
                onBack = { currentPage = SettingsPage.Hub.name },
            )

            SettingsPage.McpServers -> {
                val runtime = context.arixRuntime
                ArixMcpServersPage(
                    repository = runtime.mcpRepository,
                    manager = runtime.mcpManager,
                    onBrowseConnectors = { currentPage = SettingsPage.Connectors.name },
                    onBack = { currentPage = parentPage().name },
                )
            }

            SettingsPage.Connectors -> {
                val runtime = context.arixRuntime
                ArixConnectorsPage(
                    repository = runtime.mcpRepository,
                    installer = com.arix.app.mcp.ArixConnectorInstaller(
                        repository = runtime.mcpRepository,
                        manager = runtime.mcpManager,
                    ),
                    onBack = { currentPage = parentPage().name },
                )
            }

            SettingsPage.TelegramBot -> ArixTelegramBotPage(
                onBack = { currentPage = parentPage().name },
            )

            SettingsPage.Statistics -> StatisticsSettingsPage(
                title = stringResource(R.string.settings_statistics),
                usageStatisticsSnapshots = usageStatisticsSnapshots,
                onBack = { currentPage = SettingsPage.Hub.name },
            )

            SettingsPage.Storage -> StorageSettingsPage(
                title = stringResource(R.string.settings_storage),
                onResetTermuxRuntime = onResetTermuxRuntime,
                onBack = { currentPage = SettingsPage.Hub.name },
            )

            SettingsPage.Permissions -> PermissionsSettingsPage(
                title = stringResource(R.string.settings_permissions),
                onBack = { currentPage = SettingsPage.Hub.name },
            )

            SettingsPage.Developer -> DeveloperSettingsPage(
                title = stringResource(R.string.settings_developer),
                onImportAppData = onImportAppData,
                onExportAppData = onExportAppData,
                onExportLogs = onExportLogs,
                developerRoleFallbackProviders = providerConfigs.filter {
                    it.developerRoleUnsupported
                },
                onClearDeveloperRoleFallback = { configId ->
                    providerConfigs.firstOrNull { it.id == configId }?.let { config ->
                        onUpsertProviderConfig(
                            config.copy(developerRoleUnsupported = false),
                        )
                    }
                },
                autoCleanOldCommandHistory = autoCleanOldCommandHistoryValue,
                oldCommandHistoryRetentionHours = oldCommandHistoryRetentionHoursValue,
                onAutoCleanOldCommandHistoryChanged = { autoCleanOldCommandHistoryValue = it },
                onOldCommandHistoryRetentionHoursChanged = { oldCommandHistoryRetentionHoursValue = it },
                onBack = { currentPage = SettingsPage.Hub.name },
            )

            SettingsPage.About -> AboutPage(
                title = stringResource(R.string.settings_about),
                onOpenWebsite = onOpenWebsite,
                onOpenPrivacyPolicy = onOpenPrivacyPolicy,
                onBack = { currentPage = SettingsPage.Hub.name },
            )
            }
        }
    }
}

@Composable
private fun SettingsHub(
    activeProviderName: String,
    systemPromptSnippet: String,
    tavilyConfigured: Boolean,
    reliabilitySummary: String,
    termuxReady: Boolean,
    defaultRuntimeId: LocalRuntimeId?,
    skillCount: Int,
    scheduledTaskCount: Int,
    statisticsSummary: String,
    onNavigate: (SettingsPage) -> Unit,
    onBack: () -> Unit,
) {
    var topBarBodyHeightPx by remember { mutableIntStateOf(0) }
    val density = LocalDensity.current
    val fallbackTopBarBodyHeight = with(density) {
        WindowInsets.statusBars.getTop(this).toDp() + 68.dp
    }
    val topBarBodyHeight = with(density) {
        if (topBarBodyHeightPx > 0) topBarBodyHeightPx.toDp() else fallbackTopBarBodyHeight
    }
    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = ArixSettingsBackground,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(top = topBarBodyHeight)
                    .padding(horizontal = 20.dp)
                    .imePadding()
                    .navigationBarsPadding(),
            ) {
                Spacer(Modifier.height(6.dp))
                Spacer(Modifier.height(16.dp))

            SettingsCardGroup {
                SettingsNavRow(
                    icon = Icons.Rounded.Cloud,
                    title = stringResource(R.string.settings_model_providers),
                    subtitle = activeProviderName,
                    onClick = { onNavigate(SettingsPage.Providers) },
                )
                CardDivider()
                SettingsNavRow(
                    icon = Icons.Rounded.Person,
                    title = stringResource(R.string.settings_personalization),
                    subtitle = systemPromptSnippet.ifBlank { stringResource(R.string.settings_custom_instructions) },
                    onClick = { onNavigate(SettingsPage.Personalization) },
                )
                CardDivider()
                SettingsNavRow(
                    icon = Icons.Rounded.Refresh,
                    title = stringResource(R.string.settings_reliability),
                    subtitle = reliabilitySummary,
                    onClick = { onNavigate(SettingsPage.Reliability) },
                )
            }

            Spacer(Modifier.height(16.dp))

            SettingsCardGroup {
                SettingsNavRow(
                    icon = Icons.Rounded.Extension,
                    title = stringResource(R.string.settings_agent_skills),
                    subtitle = stringResource(R.string.settings_skills_count_configured, skillCount),
                    onClick = { onNavigate(SettingsPage.Skills) },
                )
                CardDivider()
                SettingsNavRow(
                    icon = Icons.Rounded.AutoAwesome,
                    title = stringResource(R.string.settings_extensions),
                    subtitle = stringResource(R.string.settings_extensions_subtitle),
                    onClick = { onNavigate(SettingsPage.Extensions) },
                )
                CardDivider()
                SettingsNavRow(
                    icon = Icons.Rounded.PhoneAndroid,
                    title = "Phone control",
                    subtitle = "Run apps on a hidden background screen (Mika port)",
                    onClick = { onNavigate(SettingsPage.PhoneControl) },
                )
                CardDivider()
                SettingsNavRow(
                    icon = Icons.Rounded.Schedule,
                    title = stringResource(R.string.settings_scheduled_tasks),
                    subtitle = stringResource(R.string.settings_scheduled_tasks_count_configured, scheduledTaskCount),
                    onClick = { onNavigate(SettingsPage.ScheduledTasks) },
                )
                CardDivider()
                SettingsNavRow(
                    icon = Icons.Rounded.Code,
                    title = "Termux",
                    subtitle = if (termuxReady) { stringResource(R.string.settings_termux_subtitle_ready) } else { stringResource(R.string.settings_termux_subtitle_setup) },
                    onClick = { onNavigate(SettingsPage.Termux) },
                )
            }

            Spacer(Modifier.height(16.dp))

            SettingsCardGroup {
                SettingsNavRow(
                    icon = Icons.Rounded.Extension,
                    title = stringResource(R.string.settings_mcp_servers),
                    subtitle = stringResource(R.string.mcp_browse_connectors_hint),
                    onClick = { onNavigate(SettingsPage.McpServers) },
                )
                CardDivider()
                SettingsNavRow(
                    icon = Icons.AutoMirrored.Rounded.Send,
                    title = stringResource(R.string.settings_telegram_bot),
                    subtitle = stringResource(R.string.telegram_enable_subtitle),
                    onClick = { onNavigate(SettingsPage.TelegramBot) },
                )
            }

            Spacer(Modifier.height(16.dp))

            SettingsCardGroup {
                SettingsNavRow(
                    icon = LucideIcons.ChartNoAxesColumn,
                    title = stringResource(R.string.settings_statistics),
                    subtitle = statisticsSummary.ifBlank { stringResource(R.string.settings_statistics_empty) },
                    onClick = { onNavigate(SettingsPage.Statistics) },
                )
                CardDivider()
                SettingsNavRow(
                    icon = Icons.Rounded.DeleteOutline,
                    title = stringResource(R.string.settings_storage),
                    subtitle = stringResource(R.string.settings_storage_hint),
                    onClick = { onNavigate(SettingsPage.Storage) },
                )
            }

            Spacer(Modifier.height(16.dp))

            SettingsCardGroup {
                SettingsNavRow(
                    icon = Icons.Rounded.VerifiedUser,
                    title = stringResource(R.string.settings_permissions),
                    subtitle = stringResource(R.string.settings_permissions_subtitle),
                    onClick = { onNavigate(SettingsPage.Permissions) },
                )
            }

            Spacer(Modifier.height(16.dp))

            SettingsCardGroup {
                SettingsNavRow(
                    icon = Icons.Rounded.Code,
                    title = stringResource(R.string.settings_developer),
                    subtitle = stringResource(R.string.settings_developer_subtitle),
                    onClick = { onNavigate(SettingsPage.Developer) },
                )
            }

            Spacer(Modifier.height(16.dp))

            SettingsCardGroup {
                SettingsNavRow(
                    icon = Icons.Rounded.Info,
                    title = stringResource(R.string.settings_about),
                    subtitle = settingsReleaseSummary(BuildConfig.VERSION_NAME),
                    onClick = { onNavigate(SettingsPage.About) },
                )
            }

            Spacer(Modifier.height(32.dp))
            }

            SettingsTopBarOverlay(
                modifier = Modifier.align(Alignment.TopCenter),
                title = stringResource(R.string.settings_title),
                onBack = onBack,
                onBodyHeightChanged = { topBarBodyHeightPx = it },
            )
        }
    }
}

@Composable
private fun StatisticsSettingsPage(
    title: String,
    usageStatisticsSnapshots: List<ChatUsageStatisticsSnapshot>,
    onBack: () -> Unit,
) {
    val report = remember(usageStatisticsSnapshots) { buildUsageStatisticsReport(usageStatisticsSnapshots) }
    SubPageScaffold(title = title, onBack = onBack) {
        SettingsCardGroup {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Text(
                    text = stringResource(R.string.statistics_overview),
                    style = MaterialTheme.typography.titleMedium,
                    color = ArixOnSurface,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatisticsMetricTile(
                        label = stringResource(R.string.statistics_total_tokens),
                        value = formatSettingsTokenCount(report.totalTokens),
                        modifier = Modifier.weight(1f),
                    )
                    StatisticsMetricTile(
                        label = stringResource(R.string.statistics_sessions),
                        value = report.sessionCount.toString(),
                        modifier = Modifier.weight(1f),
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatisticsMetricTile(
                        label = stringResource(R.string.statistics_average_speed),
                        value = report.averageOutputTokensPerSecond?.let(::formatSettingsTokenRate)
                            ?: stringResource(R.string.statistics_unavailable),
                        modifier = Modifier.weight(1f),
                    )
                    StatisticsMetricTile(
                        label = stringResource(R.string.statistics_average_latency),
                        value = report.averageFirstTokenLatencyMillis?.let(::formatSettingsDuration)
                            ?: stringResource(R.string.statistics_unavailable),
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        SettingsCardGroup {
            StatisticsChartSection(
                title = stringResource(R.string.statistics_daily_token_usage),
                subtitle = stringResource(R.string.statistics_recent_7_days),
            ) {
                TokenBarChart(points = report.dailyTokenUsage.takeLast(7))
            }
        }

        Spacer(Modifier.height(16.dp))

        SettingsCardGroup {
            StatisticsChartSection(
                title = stringResource(R.string.statistics_recent_token_usage),
                subtitle = stringResource(R.string.statistics_recent_14_days),
            ) {
                TokenLineChart(points = report.dailyTokenUsage.takeLast(14))
            }
        }

        Spacer(Modifier.height(16.dp))

        SettingsCardGroup {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Text(
                    text = stringResource(R.string.statistics_historical_token_usage),
                    style = MaterialTheme.typography.titleMedium,
                    color = ArixOnSurface,
                )
                HistoryPeakRow(
                    label = stringResource(R.string.statistics_peak_day),
                    value = report.peakDay?.let { "${it.label} · ${formatSettingsTokenCount(it.tokens)}" }
                        ?: stringResource(R.string.statistics_unavailable),
                )
                HistoryPeakRow(
                    label = stringResource(R.string.statistics_largest_turn),
                    value = report.largestTurnTokens?.let(::formatSettingsTokenCount)
                        ?: stringResource(R.string.statistics_unavailable),
                )
                HistoryPeakRow(
                    label = stringResource(R.string.statistics_recorded_turns),
                    value = report.turnCount.toString(),
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        SettingsCardGroup {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Text(
                    text = stringResource(R.string.statistics_token_mix),
                    style = MaterialTheme.typography.titleMedium,
                    color = ArixOnSurface,
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(26.dp),
                ) {
                    TokenMixPieChart(
                        inputTokens = report.inputTokens,
                        outputTokens = report.outputTokens,
                        reasoningTokens = report.reasoningTokens,
                        modifier = Modifier.size(112.dp),
                    )
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(start = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        TokenMixLegend(stringResource(R.string.statistics_input), StatisticsInputColor, report.inputTokens)
                        TokenMixLegend(stringResource(R.string.statistics_output), StatisticsOutputColor, report.outputTokens)
                        TokenMixLegend(stringResource(R.string.statistics_reasoning), statisticsReasoningColor(), report.reasoningTokens)
                        if (report.cachedInputTokens > 0L || report.cacheWriteTokens > 0L) {
                            TokenMixLegend(
                                stringResource(R.string.statistics_cached_input),
                                StatisticsCacheColor,
                                report.cachedInputTokens,
                            )
                            TokenMixLegend(
                                stringResource(R.string.statistics_cache_write),
                                StatisticsCacheWriteColor,
                                report.cacheWriteTokens,
                            )
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        SettingsCardGroup {
            StatisticsChartSection(
                title = stringResource(R.string.statistics_speed),
                subtitle = stringResource(R.string.statistics_speed_subtitle),
            ) {
                SpeedBarChart(points = report.recentSpeedSamples.takeLast(12))
            }
        }
    }
}

@Composable
private fun StatisticsMetricTile(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(ArixSurfaceHigh)
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
            color = ArixOnSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = ArixOnSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun StatisticsChartSection(
    title: String,
    subtitle: String,
    chart: @Composable () -> Unit,
) {
    Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            color = ArixOnSurface,
        )
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
        )
        chart()
    }
}

@Composable
private fun TokenBarChart(points: List<DailyTokenUsage>) {
    val maxTokens = points.maxOfOrNull { it.tokens }?.coerceAtLeast(1L) ?: 1L
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(164.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        points.forEach { point ->
            val fraction = point.tokens.toFloat() / maxTokens
            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Bottom,
            ) {
                Text(
                    text = formatSettingsTokenCount(point.tokens),
                    style = MaterialTheme.typography.labelSmall,
                    color = ArixOnSurfaceVariant,
                    maxLines = 1,
                )
                Spacer(Modifier.height(6.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height((18 + 96 * fraction).dp)
                        .clip(RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp, bottomStart = 6.dp, bottomEnd = 6.dp))
                        .background(ArixPrimary.copy(alpha = 0.18f + 0.44f * fraction)),
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = point.shortLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = ArixOnSurfaceVariant,
                    maxLines = 1,
                )
            }
        }
    }
}

@Composable
private fun TokenLineChart(points: List<DailyTokenUsage>) {
    var selectedIndex by remember(points) { mutableStateOf<Int?>(null) }
    val selectedPoint = selectedIndex?.let(points::getOrNull)
    val lineColor = StatisticsInputColor
    val fillColor = StatisticsInputColor.copy(alpha = 0.12f)
    val labelColor = ArixOnSurfaceVariant
    val maxTokens = points.maxOfOrNull { it.tokens }?.coerceAtLeast(1L) ?: 1L
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .height(150.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(ArixSurfaceHigh)
                .pointerInput(points) {
                    detectTapGestures { offset ->
                        if (points.isEmpty()) return@detectTapGestures
                        val horizontalPadding = 24f
                        val chartWidth = (size.width - horizontalPadding * 2f).coerceAtLeast(1f)
                        val progress = ((offset.x - horizontalPadding) / chartWidth).coerceIn(0f, 1f)
                        selectedIndex = (progress * (points.size - 1)).roundToInt().coerceIn(0, points.lastIndex)
                    }
                },
        ) {
            val chartPadding = 12.dp
            val chartHeight = 126.dp
            val chartWidth = maxWidth - chartPadding * 2
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
            ) {
                if (points.isEmpty()) return@Canvas
                val step = if (points.size <= 1) 0f else size.width / (points.size - 1)
                val coordinates = points.mapIndexed { index, point ->
                    val x = if (points.size <= 1) size.width / 2f else step * index
                    val y = size.height - (point.tokens.toFloat() / maxTokens) * size.height
                    androidx.compose.ui.geometry.Offset(x, y)
                }
                for (index in 0 until coordinates.lastIndex) {
                    drawLine(
                        color = lineColor,
                        start = coordinates[index],
                        end = coordinates[index + 1],
                        strokeWidth = 5f,
                        cap = StrokeCap.Round,
                    )
                }
                coordinates.forEachIndexed { index, point ->
                    val selected = selectedIndex == index
                    drawCircle(color = fillColor, radius = if (selected) 17f else 12f, center = point)
                    drawCircle(color = if (selected) StatisticsOutputColor else lineColor, radius = if (selected) 7f else 5f, center = point)
                }
            }
            selectedPoint?.let { point ->
                val selectedX = if (points.size <= 1) {
                    maxWidth / 2
                } else {
                    chartPadding + chartWidth * (selectedIndex!!.toFloat() / points.lastIndex)
                }
                val selectedY = chartPadding + chartHeight * (1f - point.tokens.toFloat() / maxTokens)
                val tooltipWidth = 116.dp
                val tooltipX = (selectedX - tooltipWidth / 2)
                    .coerceIn(4.dp, (maxWidth - tooltipWidth - 4.dp).coerceAtLeast(4.dp))
                val tooltipY = (selectedY - 34.dp).coerceAtLeast(4.dp)
                Box(
                    modifier = Modifier
                        .offset(x = tooltipX, y = tooltipY)
                        .width(tooltipWidth)
                        .clip(RoundedCornerShape(10.dp))
                        .background(ArixSurface.copy(alpha = 0.96f))
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = stringResource(
                            R.string.statistics_selected_day_tokens,
                            point.label,
                            formatSettingsTokenCount(point.tokens),
                        ),
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
                        color = ArixOnSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            points.firstOrNull()?.let {
                Text(it.shortLabel, style = MaterialTheme.typography.labelSmall, color = labelColor)
            }
            points.lastOrNull()?.let {
                Text(it.shortLabel, style = MaterialTheme.typography.labelSmall, color = labelColor)
            }
        }
    }
}

@Composable
private fun TokenMixPieChart(
    inputTokens: Long,
    outputTokens: Long,
    reasoningTokens: Long,
    modifier: Modifier = Modifier,
) {
    val values = listOf(inputTokens, outputTokens, reasoningTokens)
    val colors = listOf(StatisticsInputColor, StatisticsOutputColor, statisticsReasoningColor())
    val total = values.sum()
    val neutralColor = statisticsNeutralChartColor()
    Canvas(modifier = modifier) {
        if (total <= 0L) {
            drawArc(
                color = neutralColor,
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                style = Stroke(width = size.minDimension * 0.20f, cap = StrokeCap.Butt),
            )
            return@Canvas
        }
        var startAngle = -90f
        values.forEachIndexed { index, value ->
            if (value <= 0L) return@forEachIndexed
            val sweep = 360f * value / total
            drawArc(
                color = colors[index],
                startAngle = startAngle,
                sweepAngle = sweep,
                useCenter = false,
                style = Stroke(width = size.minDimension * 0.20f, cap = StrokeCap.Butt),
            )
            startAngle += sweep
        }
    }
}

@Composable
private fun SpeedBarChart(points: List<SpeedSample>) {
    val visiblePoints = points.takeLast(7)
    if (visiblePoints.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(132.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(ArixSurfaceHigh),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = stringResource(R.string.statistics_no_speed_samples),
                style = MaterialTheme.typography.bodyMedium,
                color = ArixOnSurfaceVariant,
            )
        }
        return
    }
    val maxSpeed = visiblePoints.maxOfOrNull { it.tokensPerSecond }?.coerceAtLeast(1.0) ?: 1.0
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(164.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        visiblePoints.forEach { sample ->
            val speed = sample.tokensPerSecond
            val fraction = (speed / maxSpeed).toFloat()
            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Bottom,
            ) {
                Text(
                    text = formatSettingsTokenRate(speed),
                    style = MaterialTheme.typography.labelSmall,
                    color = ArixOnSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Clip,
                )
                Spacer(Modifier.height(6.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height((18 + 96 * fraction).dp)
                        .clip(RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp, bottomStart = 6.dp, bottomEnd = 6.dp))
                        .background(ArixPrimary.copy(alpha = 0.18f + 0.44f * fraction)),
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = sample.shortLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = ArixOnSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Clip,
                )
            }
        }
    }
}

@Composable
private fun TokenMixLegend(
    label: String,
    color: Color,
    tokens: Long,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(color),
        )
        Text(
            text = label,
            modifier = Modifier.weight(1f),
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
        )
        Text(
            text = formatSettingsTokenCount(tokens),
            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
            color = ArixOnSurface,
        )
    }
}

@Composable
private fun HistoryPeakRow(
    label: String,
    value: String,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(ArixSurfaceHigh)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = label,
            modifier = Modifier.weight(1f),
            style = MaterialTheme.typography.bodyMedium,
            color = ArixOnSurfaceVariant,
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
            color = ArixOnSurface,
        )
    }
}

@Composable
private fun buildSettingsStatisticsSummary(
    usageStatisticsReport: UsageStatisticsReport,
): String {
    val report = usageStatisticsReport
    return if (report.turnCount == 0) {
        ""
    } else {
        stringResource(
            R.string.settings_statistics_summary,
            formatSettingsTokenCount(report.totalTokens),
            report.turnCount,
        )
    }
}

private fun buildUsageStatisticsReport(
    usageStatisticsSnapshots: List<ChatUsageStatisticsSnapshot>,
): UsageStatisticsReport {
    val stats = usageStatisticsSnapshots.map { it.statistics }
    val zone = ZoneId.systemDefault()
    val today = LocalDate.now(zone)
    val daily = (13 downTo 0).map { daysAgo ->
        val date = today.minusDays(daysAgo.toLong())
        DailyTokenUsage(
            date = date,
            label = "${date.monthValue}/${date.dayOfMonth}",
            shortLabel = date.dayOfMonth.toString(),
            tokens = stats
                .filter { stat ->
                    val millis = stat.completedAtMillis.takeIf { it > 0L } ?: stat.startedAtMillis
                    millis > 0L && Instant.ofEpochMilli(millis).atZone(zone).toLocalDate() == date
                }
                .sumOf { it.totalTokens ?: 0L },
        )
    }
    val speedSamples = stats.mapNotNull { stat ->
        val speed = stat.outputTokensPerSecond ?: return@mapNotNull null
        val millis = stat.completedAtMillis.takeIf { it > 0L } ?: stat.startedAtMillis
        if (millis <= 0L) return@mapNotNull null
        val date = Instant.ofEpochMilli(millis).atZone(zone).toLocalDate()
        SpeedSample(
            date = date,
            label = "${date.monthValue}/${date.dayOfMonth}",
            shortLabel = "${date.monthValue}/${date.dayOfMonth}",
            tokensPerSecond = speed,
            timestampMillis = millis,
        )
    }.sortedBy { it.timestampMillis }
    val speeds = speedSamples.map { it.tokensPerSecond }
    val latencies = stats.mapNotNull { it.firstTokenLatencyMillis }
    return UsageStatisticsReport(
        totalTokens = stats.sumOf { it.totalTokens ?: 0L },
        inputTokens = stats.sumOf { it.inputTokens ?: 0L },
        outputTokens = stats.sumOf { it.outputTokens ?: 0L },
        reasoningTokens = stats.sumOf { it.reasoningTokens ?: 0L },
        cachedInputTokens = stats.sumOf { it.cachedInputTokens ?: 0L },
        cacheWriteTokens = stats.sumOf { it.cacheWriteTokens ?: 0L },
        sessionCount = usageStatisticsSnapshots.map { it.sessionId }.distinct().size,
        turnCount = stats.size,
        dailyTokenUsage = daily,
        peakDay = daily.maxByOrNull { it.tokens }?.takeIf { it.tokens > 0L },
        largestTurnTokens = stats.mapNotNull { it.totalTokens }.maxOrNull(),
        averageOutputTokensPerSecond = speeds.takeIf { it.isNotEmpty() }?.average(),
        averageFirstTokenLatencyMillis = latencies.takeIf { it.isNotEmpty() }?.average()?.roundToInt()?.toLong(),
        recentSpeedSamples = speedSamples,
    )
}

private fun formatSettingsTokenCount(tokens: Long): String = when {
    tokens >= 1_000_000L -> String.format(Locale.US, "%.1fM", tokens / 1_000_000.0)
    tokens >= 1_000L -> String.format(Locale.US, "%.1fK", tokens / 1_000.0)
    else -> tokens.toString()
}

private fun formatSettingsTokenRate(tokensPerSecond: Double): String =
    String.format(Locale.US, "%.1f tok/s", tokensPerSecond)

private fun formatSettingsDuration(millis: Long): String =
    if (millis >= 1_000L) {
        String.format(Locale.US, "%.2fs", millis / 1000.0)
    } else {
        "${millis}ms"
    }

private data class UsageStatisticsReport(
    val totalTokens: Long,
    val inputTokens: Long,
    val outputTokens: Long,
    val reasoningTokens: Long,
    val cachedInputTokens: Long = 0L,
    val cacheWriteTokens: Long = 0L,
    val sessionCount: Int,
    val turnCount: Int,
    val dailyTokenUsage: List<DailyTokenUsage>,
    val peakDay: DailyTokenUsage?,
    val largestTurnTokens: Long?,
    val averageOutputTokensPerSecond: Double?,
    val averageFirstTokenLatencyMillis: Long?,
    val recentSpeedSamples: List<SpeedSample>,
)

private data class DailyTokenUsage(
    val date: LocalDate,
    val label: String,
    val shortLabel: String,
    val tokens: Long,
)

private data class SpeedSample(
    val date: LocalDate,
    val label: String,
    val shortLabel: String,
    val tokensPerSecond: Double,
    val timestampMillis: Long,
)

@Composable
private fun ProvidersListPage(
    providerConfigs: List<LlmProviderConfig>,
    onSetProviderEnabled: (String, Boolean) -> Unit,
    onOpenDefaultModels: () -> Unit,
    onEdit: (String) -> Unit,
    onRemove: (String) -> Unit,
    onAddNew: () -> Unit,
    onBack: () -> Unit,
) {
    SubPageScaffold(
        title = stringResource(R.string.settings_model_providers),
        onBack = onBack,
        trailingIcon = Icons.Rounded.Add,
        onTrailingAction = onAddNew,
    ) {
        if (providerConfigs.isEmpty()) {
            SettingsCardGroup {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        stringResource(R.string.settings_no_providers_configured),
                        style = MaterialTheme.typography.titleMedium,
                        color = ArixOnSurface,
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        stringResource(R.string.settings_add_provider_description),
                        style = MaterialTheme.typography.bodyMedium,
                        color = ArixOnSurfaceVariant,
                    )
                    Spacer(Modifier.height(16.dp))
                    SettingsActionButton(
                        label = stringResource(R.string.settings_add_provider),
                        onClick = onAddNew,
                    )
                }
            }
        } else {
            providerConfigs.forEach { config ->
                ProviderCard(
                    config = config,
                    onEnabledChange = { enabled -> onSetProviderEnabled(config.id, enabled) },
                    onEdit = { onEdit(config.id) },
                    onRemove = { onRemove(config.id) },
                )
                Spacer(Modifier.height(12.dp))
            }
        }

        Spacer(Modifier.height(8.dp))
        SettingsCardGroup {
            SettingsNavRow(
                icon = Icons.Rounded.AutoAwesome,
                title = stringResource(R.string.settings_default_models),
                subtitle = stringResource(R.string.settings_default_models_subtitle),
                onClick = onOpenDefaultModels,
            )
        }
    }
}

@Composable
private fun DefaultModelsPage(
    modelOptions: List<ProviderModelOption>,
    defaultChatModelKey: String,
    defaultTitleModelKey: String,
    defaultNamingModelKey: String,
    defaultCompactingModelKey: String,
    onOpenDefaultChatModel: () -> Unit,
    onOpenDefaultTitleModel: () -> Unit,
    onOpenDefaultNamingModel: () -> Unit,
    onOpenDefaultCompactingModel: () -> Unit,
    onBack: () -> Unit,
) {
    val automaticChatLabel = modelOptions.findModelOption(
        modelOptions.resolveAutomaticModelKey(AutomaticModelPurpose.Chat)
    )?.fullLabel
    val automaticTitleLabel = modelOptions.findModelOption(
        modelOptions.resolveAutomaticModelKey(AutomaticModelPurpose.Title)
            .ifBlank { modelOptions.resolveAutomaticModelKey(AutomaticModelPurpose.Chat) }
    )?.fullLabel
    val automaticNamingLabel = modelOptions.findModelOption(
        modelOptions.resolveAutomaticModelKey(AutomaticModelPurpose.Naming)
            .ifBlank { modelOptions.resolveAutomaticModelKey(AutomaticModelPurpose.Chat) }
    )?.fullLabel
    val automaticCompactingLabel = modelOptions.findModelOption(
        modelOptions.resolveAutomaticModelKey(AutomaticModelPurpose.Compacting)
            .ifBlank { modelOptions.resolveAutomaticModelKey(AutomaticModelPurpose.Chat) }
    )?.fullLabel
    SubPageScaffold(
        title = stringResource(R.string.settings_default_models),
        onBack = onBack,
    ) {
        SettingsCardGroup {
            SettingsNavRow(
                icon = Icons.Rounded.AutoAwesome,
                title = stringResource(R.string.settings_default_chat_model),
                subtitle = if (defaultChatModelKey.isBlank()) {
                    automaticChatLabel?.let { stringResource(R.string.settings_automatic_model_with_name, it) }
                        ?: stringResource(R.string.settings_automatic_model)
                } else {
                    modelOptions.findModelOption(defaultChatModelKey)?.fullLabel.orEmpty()
                },
                onClick = onOpenDefaultChatModel,
            )
            CardDivider()
            SettingsNavRow(
                icon = Icons.Rounded.Edit,
                title = stringResource(R.string.settings_default_title_model),
                subtitle = if (defaultTitleModelKey.isBlank()) {
                    automaticTitleLabel?.let { stringResource(R.string.settings_automatic_model_with_name, it) }
                        ?: stringResource(R.string.settings_automatic_model)
                } else {
                    modelOptions.findModelOption(defaultTitleModelKey)?.fullLabel.orEmpty()
                },
                onClick = onOpenDefaultTitleModel,
            )
            CardDivider()
            SettingsNavRow(
                icon = Icons.Rounded.Person,
                title = stringResource(R.string.settings_default_naming_model),
                subtitle = if (defaultNamingModelKey.isBlank()) {
                    automaticNamingLabel?.let { stringResource(R.string.settings_automatic_model_with_name, it) }
                        ?: stringResource(R.string.settings_automatic_model)
                } else {
                    modelOptions.findModelOption(defaultNamingModelKey)?.fullLabel.orEmpty()
                },
                onClick = onOpenDefaultNamingModel,
            )
            CardDivider()
            SettingsNavRow(
                icon = Icons.Rounded.AutoAwesome,
                title = stringResource(R.string.settings_default_compacting_model),
                subtitle = if (defaultCompactingModelKey.isBlank()) {
                    automaticCompactingLabel?.let { stringResource(R.string.settings_automatic_model_with_name, it) }
                        ?: stringResource(R.string.settings_automatic_model)
                } else {
                    modelOptions.findModelOption(defaultCompactingModelKey)?.fullLabel.orEmpty()
                },
                onClick = onOpenDefaultCompactingModel,
            )
        }
    }
}

@Composable
private fun ProviderCard(
    config: LlmProviderConfig,
    onEnabledChange: (Boolean) -> Unit,
    onEdit: () -> Unit,
    onRemove: () -> Unit,
) {
    val availableModels = config.availableModels()
    val enabledModels = config.enabledModels()
    val provider = PiProviderCatalog.resolve(config.piProviderId)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(ArixSurface)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Checkbox(
            checked = config.isEnabled,
            onCheckedChange = { enabled -> onEnabledChange(enabled) },
        )

        Spacer(Modifier.width(10.dp))
        ProviderBrandIconBadge(
            provider = provider,
            badgeSize = 40.dp,
            iconSize = 25.dp,
            cornerRadius = 8.dp,
        )
        Spacer(Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = config.name,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = ArixOnSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = "${provider.displayName} · ${config.providerId}",
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = stringResource(R.string.settings_provider_models_enabled_count, enabledModels.size, availableModels.size),
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }

        IconButton(onClick = onEdit) {
            Icon(
                Icons.Rounded.Edit,
                contentDescription = stringResource(R.string.action_edit),
                tint = ArixOnSurfaceVariant,
            )
        }

        IconButton(onClick = onRemove) {
            Icon(
                Icons.Rounded.Delete,
                contentDescription = stringResource(R.string.action_remove),
                tint = Color(0xFFD25757),
            )
        }
    }
}

@Composable
private fun ModelSelectionListPage(
    title: String,
    subtitle: String,
    selectedKey: String,
    options: List<ProviderModelOption>,
    purpose: AutomaticModelPurpose,
    automaticLabel: String,
    automaticSubtitle: String,
    onSelected: (String) -> Unit,
    onBack: () -> Unit,
) {
    val selectedOption = options.findModelOption(selectedKey)
    val sortedOptions = remember(options, purpose) {
        options.sortedForAutomaticModelPurpose(purpose)
    }
    var searchQuery by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(""))
    }
    val trimmedSearchQuery = searchQuery.text.trim()
    val filteredOptions = remember(sortedOptions, trimmedSearchQuery) {
        if (trimmedSearchQuery.isBlank()) {
            sortedOptions
        } else {
            val needle = trimmedSearchQuery.lowercase()
            sortedOptions.filter { option ->
                option.fullLabel.contains(needle, ignoreCase = true) ||
                    option.modelId.contains(needle, ignoreCase = true) ||
                    option.providerName.contains(needle, ignoreCase = true) ||
                    option.providerId.contains(needle, ignoreCase = true) ||
                    PiProviderCatalog.resolve(option.piProviderId).displayName
                        .contains(needle, ignoreCase = true)
            }
        }
    }

    SubPageScaffold(
        title = title,
        onBack = onBack,
    ) {
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodyMedium,
            color = ArixOnSurfaceVariant,
        )
        Spacer(Modifier.height(14.dp))

        if (options.isEmpty()) {
            SettingsCardGroup {
                Column(
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(
                        text = stringResource(R.string.settings_no_enabled_models_available),
                        style = MaterialTheme.typography.titleMedium,
                        color = ArixOnSurface,
                    )
                    Text(
                        text = stringResource(R.string.settings_enable_provider_model_first),
                        style = MaterialTheme.typography.bodyMedium,
                        color = ArixOnSurfaceVariant,
                    )
                }
            }
            return@SubPageScaffold
        }

        SettingsCardGroup {
            ModelSelectionSearchField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
            )
        }
        Spacer(Modifier.height(12.dp))

        SettingsCardGroup {
            ModelSelectionListRow(
                title = automaticLabel,
                subtitle = automaticSubtitle,
                selected = selectedOption == null,
                onClick = { onSelected("") },
            )
            filteredOptions.forEach { option ->
                CardDivider()
                ModelSelectionListRow(
                    title = option.fullLabel,
                    subtitle = option.providerName,
                    selected = option.key == selectedOption?.key,
                    onClick = { onSelected(option.key) },
                )
            }
            if (filteredOptions.isEmpty()) {
                CardDivider()
                Text(
                    text = stringResource(R.string.settings_no_models_match_search),
                    style = MaterialTheme.typography.bodyMedium,
                    color = ArixOnSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 18.dp),
                )
            }
        }
    }
}

@Composable
private fun ModelSelectionSearchField(
    value: TextFieldValue,
    onValueChange: (TextFieldValue) -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector = Icons.Rounded.Search,
            contentDescription = null,
            tint = ArixOnSurfaceVariant,
            modifier = Modifier.size(20.dp),
        )
        Spacer(Modifier.width(12.dp))
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier
                .weight(1f)
                .settingsBringIntoViewOnFocus(),
            textStyle = MaterialTheme.typography.bodyLarge.copy(color = ArixOnSurface),
            cursorBrush = SolidColor(ArixPrimary),
            singleLine = true,
            decorationBox = { innerTextField ->
                Box {
                    if (value.text.isEmpty()) {
                        Text(
                            text = stringResource(R.string.settings_search_models),
                            style = MaterialTheme.typography.bodyLarge,
                            color = ArixOnSurfaceVariant.copy(alpha = 0.5f),
                        )
                    }
                    innerTextField()
                }
            },
        )
    }
}

@Composable
private fun ModelSelectionListRow(
    title: String,
    subtitle: String,
    selected: Boolean,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(if (selected) ArixSettingsBackground.copy(alpha = 0.9f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = ArixOnSurface,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = ArixOnSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.width(14.dp))
        Icon(
            imageVector = Icons.Rounded.Check,
            contentDescription = null,
            tint = if (selected) ArixPrimary else Color.Transparent,
            modifier = Modifier.size(22.dp),
        )
    }
}

@Composable
private fun ProviderEditPage(
    existingConfig: LlmProviderConfig?,
    existingProviderIds: Set<String>,
    isFetchingModels: Boolean,
    onSave: (LlmProviderConfig) -> Unit,
    onModelEnabledChange: (LlmProviderConfig) -> Unit,
    onFetchModels: (LlmProviderConfig, (List<String>) -> Unit) -> Unit,
    authState: PiProviderAuthState,
    onStartProviderLogin: (String, String, ProviderAuthMethod, String) -> Unit,
    onSubmitAuthPrompt: (String, String, Boolean) -> Unit,
    onClearAuthState: () -> Unit,
    onBack: () -> Unit,
) {
    val isNew = existingConfig == null
    val formState = rememberProviderFormState(existingConfig)
    var showManageKeys by rememberSaveable { mutableStateOf(false) }
    BackHandler(enabled = showManageKeys) { showManageKeys = false }

    if (isNew) {
        SubPageScaffold(
            title = stringResource(R.string.settings_add_provider),
            onBack = onBack,
        ) {
            AddProviderWizard(
                state = formState,
                existingProviderIds = existingProviderIds,
                isFetchingModels = isFetchingModels,
                onFetchModels = onFetchModels,
                authState = authState,
                onStartProviderLogin = onStartProviderLogin,
                onSubmitAuthPrompt = onSubmitAuthPrompt,
                onClearAuthState = onClearAuthState,
                onManageKeys = { showManageKeys = true },
                onSave = onSave,
            )
        }
        if (showManageKeys) {
            ProviderManageKeysPage(
                state = formState,
                onBack = { showManageKeys = false },
            )
        }
        return
    }

    SubPageScaffold(
        title = stringResource(R.string.settings_edit_provider),
        onBack = onBack,
        trailingIcon = Icons.Rounded.Check,
        trailingEnabled = formState.isValid(existingProviderIds),
        onTrailingAction = {
            onSave(formState.buildConfig())
            onBack()
        },
    ) {
        ProviderConfigurationForm(
            state = formState,
            existingProviderIds = existingProviderIds,
            isFetchingModels = isFetchingModels,
            onFetchModels = onFetchModels,
            onManageKeys = { showManageKeys = true },
            onModelEnabledChange = onModelEnabledChange,
            authState = authState,
            onStartProviderLogin = onStartProviderLogin,
            onSubmitAuthPrompt = onSubmitAuthPrompt,
            onClearAuthState = onClearAuthState,
        )
    }
    if (showManageKeys) {
        ProviderManageKeysPage(
            state = formState,
            onBack = { showManageKeys = false },
        )
    }
}

@Composable
private fun PersonalizationPage(
    title: String,
    systemPromptValue: TextFieldValue,
    onSystemPromptChanged: (TextFieldValue) -> Unit,
    unrestrictedMode: Boolean,
    onUnrestrictedModeChanged: (Boolean) -> Unit,
    onBack: () -> Unit,
) {
    SubPageScaffold(
        title = title,
        onBack = onBack,
        trailingIcon = Icons.Rounded.Check,
        onTrailingAction = onBack,
    ) {
        SettingsCardGroup {
            ChatGptTextField(
                label = stringResource(R.string.settings_custom_instructions),
                value = systemPromptValue,
                onValueChange = onSystemPromptChanged,
                minLines = 8,
            )
        }

        Spacer(Modifier.height(8.dp))
        Text(
            text = stringResource(R.string.settings_custom_instructions_variables_hint),
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp),
        )

        Spacer(Modifier.height(16.dp))
        SettingsCardGroup {
            SettingsToggleStyleRow(
                title = "18+ unrestricted mode",
                subtitle = "Confirm you are an adult (18+). When ON, Arix instructs the model " +
                    "that ALL topics are permitted — including explicit adult content — with no " +
                    "refusals, warnings or moralizing. Your provider's own model policy still " +
                    "applies at the server side.",
                checked = unrestrictedMode,
                onCheckedChange = onUnrestrictedModeChanged,
            )
        }
    }
}

@Composable
private fun SettingsToggleStyleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                color = ArixOnSurface,
            )
            if (subtitle.isNotBlank()) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
        )
    }
}

@Composable
private fun ReliabilityPage(
    title: String,
    llmInactivityReconnectTimeoutValue: TextFieldValue,
    onLlmInactivityReconnectTimeoutChanged: (TextFieldValue) -> Unit,
    keepTasksRunningInBackground: Boolean,
    onKeepTasksRunningInBackgroundChanged: (Boolean) -> Unit,
    notifyOnTaskCompletion: Boolean,
    onNotifyOnTaskCompletionChanged: (Boolean) -> Unit,
    onBack: () -> Unit,
) {
    SubPageScaffold(
        title = title,
        onBack = onBack,
        trailingIcon = Icons.Rounded.Check,
        onTrailingAction = onBack,
    ) {
        Text(
            text = stringResource(R.string.settings_multitasking),
            style = MaterialTheme.typography.labelLarge,
            color = ArixOnSurface,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
        Spacer(Modifier.height(8.dp))

        SettingsCardGroup {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                SettingsToggleRow(
                    title = stringResource(R.string.settings_keep_tasks_running_background),
                    subtitle = stringResource(R.string.settings_keep_tasks_running_background_subtitle),
                    checked = keepTasksRunningInBackground,
                    onCheckedChange = onKeepTasksRunningInBackgroundChanged,
                )
                Spacer(Modifier.height(4.dp))
                SettingsToggleRow(
                    title = stringResource(R.string.settings_notify_background_tasks_finish),
                    subtitle = stringResource(R.string.settings_notify_background_tasks_finish_subtitle),
                    checked = notifyOnTaskCompletion,
                    onCheckedChange = onNotifyOnTaskCompletionChanged,
                )
            }
        }

        Spacer(Modifier.height(16.dp))
        Text(
            text = stringResource(R.string.settings_reconnect),
            style = MaterialTheme.typography.labelLarge,
            color = ArixOnSurface,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
        Spacer(Modifier.height(8.dp))

        SettingsCardGroup {
            ChatGptTextField(
                label = stringResource(R.string.settings_reconnect_after_idle_seconds),
                value = llmInactivityReconnectTimeoutValue,
                onValueChange = {
                    val digitsOnly = it.text.filter(Char::isDigit)
                    onLlmInactivityReconnectTimeoutChanged(
                        it.copy(
                            text = digitsOnly,
                            selection = androidx.compose.ui.text.TextRange(digitsOnly.length),
                        )
                    )
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            )
        }

        Spacer(Modifier.height(8.dp))
        Text(
            text = stringResource(R.string.settings_reconnect_after_idle_description),
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp),
        )

    }
}

private fun formatStorageBytes(bytes: Long): String = when {
    bytes >= 1_048_576 -> "%.1f MB".format(bytes / 1_048_576.0)
    bytes >= 1_024 -> "%.1f KB".format(bytes / 1_024.0)
    else -> "$bytes B"
}

private fun directorySize(file: java.io.File?): Long {
    if (file == null || !file.exists()) return 0
    var total = 0L
    file.walkBottomUp().forEach { entry ->
        if (entry.isFile) total += entry.length()
    }
    return total
}

private fun clearAppCache(context: android.content.Context): Long {
    var freed = 0L
    listOfNotNull(context.cacheDir, context.externalCacheDir).forEach { root ->
        root.listFiles()?.forEach { entry ->
            if (entry.isDirectory) {
                freed += directorySize(entry)
                entry.deleteRecursively()
            } else {
                freed += entry.length()
                entry.delete()
            }
        }
    }
    return freed
}

@Composable
private fun StorageSettingsPage(
    title: String,
    onResetTermuxRuntime: () -> Unit,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var cacheBytes by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<Long?>(null) }
    var termuxWorkspaceBytes by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<Long?>(null) }
    var termuxInstallBytes by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<Long?>(null) }
    var skillsBytes by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<Long?>(null) }
    var diagnosticsBytes by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<Long?>(null) }
    var cleaningCache by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    var cleaningWorkspace by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    var cleaningSkills by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    var cleaningDiagnostics by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    var resettingTermux by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    var pendingTermuxReset by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    var feedback by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("") }
    val cleanedLabel = stringResource(R.string.settings_storage_clean_done)
    val nothingLabel = stringResource(R.string.settings_storage_clean_nothing)
    val confirmTermuxLabel = stringResource(R.string.settings_storage_confirm_termux)

    fun refresh() {
        scope.launch {
            data class StorageSnapshot(
                val cache: Long,
                val workspace: Long,
                val install: Long,
                val skills: Long,
                val diagnostics: Long,
            )

            val snapshot = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                val filesRoot = context.filesDir
                val runtimesRoot = java.io.File(filesRoot, "runtimes")
                val termuxRoot = java.io.File(runtimesRoot, "termux")
                StorageSnapshot(
                    cache = directorySize(context.cacheDir) + directorySize(context.externalCacheDir),
                    workspace = directorySize(java.io.File(termuxRoot, "workspace")),
                    install = directorySize(termuxRoot) + directorySize(java.io.File(runtimesRoot, "termux-installing")),
                    skills = directorySize(java.io.File(filesRoot, "agent-skills")),
                    diagnostics = directorySize(java.io.File(filesRoot, "diagnostics")),
                )
            }
            cacheBytes = snapshot.cache
            termuxWorkspaceBytes = snapshot.workspace
            termuxInstallBytes = snapshot.install
            skillsBytes = snapshot.skills
            diagnosticsBytes = snapshot.diagnostics
        }
    }

    androidx.compose.runtime.LaunchedEffect(Unit) { refresh() }

    SubPageScaffold(
        title = title,
        onBack = onBack,
    ) {
        if (feedback.isNotBlank()) {
            Text(
                text = feedback,
                style = MaterialTheme.typography.bodySmall,
                color = ArixPrimary,
                modifier = Modifier.padding(horizontal = 4.dp),
            )
            Spacer(Modifier.height(12.dp))
        }
        if (pendingTermuxReset) {
            Text(
                text = confirmTermuxLabel,
                style = MaterialTheme.typography.bodySmall,
                color = androidx.compose.ui.graphics.Color(0xFFE5757A),
                modifier = Modifier.padding(horizontal = 4.dp),
            )
            Spacer(Modifier.height(12.dp))
        }

        StorageSectionCard(
            title = stringResource(R.string.settings_storage_termux_workspace),
            subtitle = if ((termuxWorkspaceBytes ?: 0L) > 0L) {
                stringResource(
                    R.string.settings_storage_termux_workspace_hint,
                    formatStorageBytes(termuxWorkspaceBytes ?: 0L),
                )
            } else {
                stringResource(R.string.settings_storage_termux_workspace_hint_empty)
            },
            buttonLabel = stringResource(R.string.settings_storage_clean_termux_workspace),
            buttonIcon = Icons.Rounded.DeleteOutline,
            enabled = (termuxWorkspaceBytes ?: 0L) > 0L,
            isLoading = cleaningWorkspace,
            onAction = {
                cleaningWorkspace = true
                scope.launch {
                    val freed = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                        val workspace = java.io.File(context.filesDir, "runtimes/termux/workspace")
                        var total = 0L
                        workspace.listFiles()?.forEach { entry ->
                            total += directorySize(entry)
                            entry.deleteRecursively()
                        }
                        total
                    }
                    cleaningWorkspace = false
                    feedback = if (freed > 0L) cleanedLabel else nothingLabel
                    refresh()
                }
            },
        )

        Spacer(Modifier.height(16.dp))

        StorageSectionCard(
            title = stringResource(R.string.settings_storage_termux_install),
            subtitle = if ((termuxInstallBytes ?: 0L) > 0L) {
                stringResource(
                    R.string.settings_storage_termux_install_hint,
                    formatStorageBytes(termuxInstallBytes ?: 0L),
                )
            } else {
                stringResource(R.string.settings_storage_termux_install_hint_empty)
            },
            buttonLabel = stringResource(R.string.settings_storage_reset_termux),
            buttonIcon = Icons.Rounded.DeleteOutline,
            enabled = (termuxInstallBytes ?: 0L) > 0L,
            isLoading = resettingTermux,
            onAction = {
                if (!pendingTermuxReset) {
                    pendingTermuxReset = true
                    feedback = ""
                } else {
                    pendingTermuxReset = false
                    resettingTermux = true
                    onResetTermuxRuntime()
                    scope.launch {
                        kotlinx.coroutines.delay(2500)
                        resettingTermux = false
                        feedback = cleanedLabel
                        refresh()
                    }
                }
            },
        )

        Spacer(Modifier.height(16.dp))

        StorageSectionCard(
            title = stringResource(R.string.settings_storage_skills),
            subtitle = if ((skillsBytes ?: 0L) > 0L) {
                stringResource(R.string.settings_storage_skills_hint, formatStorageBytes(skillsBytes ?: 0L))
            } else {
                stringResource(R.string.settings_storage_skills_hint_empty)
            },
            buttonLabel = stringResource(R.string.settings_storage_clean_skills),
            buttonIcon = Icons.Rounded.DeleteOutline,
            enabled = (skillsBytes ?: 0L) > 0L,
            isLoading = cleaningSkills,
            onAction = {
                cleaningSkills = true
                scope.launch {
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                        java.io.File(context.filesDir, "agent-skills").listFiles()?.forEach { it.deleteRecursively() }
                        java.io.File(context.filesDir, "agent-skills-tmp").listFiles()?.forEach { it.deleteRecursively() }
                    }
                    cleaningSkills = false
                    feedback = cleanedLabel
                    refresh()
                }
            },
        )

        Spacer(Modifier.height(16.dp))

        StorageSectionCard(
            title = stringResource(R.string.settings_storage_diagnostics),
            subtitle = if ((diagnosticsBytes ?: 0L) > 0L) {
                stringResource(R.string.settings_storage_diagnostics_hint, formatStorageBytes(diagnosticsBytes ?: 0L))
            } else {
                stringResource(R.string.settings_storage_diagnostics_hint_empty)
            },
            buttonLabel = stringResource(R.string.settings_storage_clean_diagnostics),
            buttonIcon = Icons.Rounded.DeleteOutline,
            enabled = (diagnosticsBytes ?: 0L) > 0L,
            isLoading = cleaningDiagnostics,
            onAction = {
                cleaningDiagnostics = true
                scope.launch {
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                        java.io.File(context.filesDir, "diagnostics").listFiles()?.forEach { it.delete() }
                    }
                    cleaningDiagnostics = false
                    feedback = cleanedLabel
                    refresh()
                }
            },
        )

        Spacer(Modifier.height(16.dp))

        StorageSectionCard(
            title = stringResource(R.string.settings_storage_app_cache),
            subtitle = stringResource(
                R.string.settings_storage_app_cache_hint,
                formatStorageBytes(cacheBytes ?: 0L),
            ),
            buttonLabel = stringResource(R.string.settings_storage_clear_cache),
            buttonIcon = Icons.Rounded.DeleteOutline,
            enabled = (cacheBytes ?: 0L) > 0L,
            isLoading = cleaningCache,
            onAction = {
                cleaningCache = true
                scope.launch {
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                        clearAppCache(context)
                    }
                    cleaningCache = false
                    feedback = cleanedLabel
                    refresh()
                }
            },
        )
    }
}

@Composable
private fun StorageSectionCard(
    title: String,
    subtitle: String,
    buttonLabel: String,
    buttonIcon: androidx.compose.ui.graphics.vector.ImageVector?,
    enabled: Boolean,
    isLoading: Boolean,
    onAction: () -> Unit,
) {
    SettingsCardGroup {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelLarge,
                    color = ArixOnSurface,
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                )
            }
            SettingsActionButton(
                label = buttonLabel,
                onClick = onAction,
                enabled = enabled,
                isLoading = isLoading,
                icon = buttonIcon,
            )
        }
    }
}

@Composable
private fun WebToolsPage(
    title: String,
    tavilyApiKeyValue: TextFieldValue,
    onTavilyApiKeyChanged: (TextFieldValue) -> Unit,
    tavilyBaseUrlValue: TextFieldValue,
    onTavilyBaseUrlChanged: (TextFieldValue) -> Unit,
    webSearchEngine: String,
    onWebSearchEngineChanged: (String) -> Unit,
    saveResearchToMemory: Boolean,
    onSaveResearchToMemoryChanged: (Boolean) -> Unit,
    onBack: () -> Unit,
) {
    SubPageScaffold(
        title = title,
        onBack = onBack,
        trailingIcon = Icons.Rounded.Check,
        onTrailingAction = onBack,
    ) {
        SettingsCardGroup {
            SelectionDropdownField(
                label = "Search engine",
                supportingText = "The results page the browser-driven web search navigates to (no third-party search API). DuckDuckGo is the default.",
                selectedLabel = when (webSearchEngine) {
                    "bing" -> "Bing"
                    "google" -> "Google"
                    else -> "DuckDuckGo"
                },
                options = com.arix.app.data.SupportedWebSearchEngines.map { engine ->
                    SelectionOption(
                        key = engine,
                        title = when (engine) {
                            "bing" -> "Bing"
                            "google" -> "Google"
                            else -> "DuckDuckGo"
                        },
                        subtitle = when (engine) {
                            "bing" -> "International results page"
                            "google" -> "Standard results page"
                            else -> "Lightweight HTML results page (default)"
                        },
                        selected = engine == webSearchEngine,
                        onClick = { onWebSearchEngineChanged(engine) },
                    )
                },
            )
            CardDivider()
            SettingsToggleStyleRow(
                title = "Save research to memory",
                subtitle = "Store structured research memos (topic, sources, citations) in the long-term 'research' memory after browser research turns. Off by default.",
                checked = saveResearchToMemory,
                onCheckedChange = onSaveResearchToMemoryChanged,
            )
        }

        Spacer(Modifier.height(8.dp))
        Text(
            text = "WebSearch and FetchURL are performed by the real built-in browser: " +
                "search results are harvested from the engine's page, top sources are read in " +
                "parallel research tabs, and every answer can cite exact paragraphs ([pN]). " +
                "Sites can expose tools to the agent through the built-in WebMCP polyfill " +
                "(document.modelContext).",
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
    }
}

@Composable
private fun SkillsListPage(
    title: String,
    installedSkills: List<com.arix.app.data.InstalledSkill>,
    onToggleSkillEnabled: (String, Boolean) -> Unit,
    onRemoveSkill: (String) -> Unit,
    onAddNew: () -> Unit,
    onReinstallBuiltIn: (String) -> Unit = {},
    onBack: () -> Unit,
) {
    SubPageScaffold(
        title = title,
        onBack = onBack,
        trailingIcon = Icons.Rounded.Add,
        onTrailingAction = onAddNew,
    ) {
        Text(
            text = stringResource(R.string.settings_skills_description),
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp),
        )

        Spacer(Modifier.height(16.dp))

        val builtInCatalog = com.arix.app.data.ArixBuiltInSkills.all
        if (builtInCatalog.isNotEmpty()) {
            Text(
                text = "Built-in skills",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = ArixOnSurface,
            )
            Spacer(Modifier.height(8.dp))
            builtInCatalog.forEach { builtIn ->
                val installed = installedSkills.firstOrNull { it.id == builtIn.id }
                if (installed != null) {
                    SkillCard(
                        skill = installed,
                        onToggleEnabled = { enabled -> onToggleSkillEnabled(installed.id, enabled) },
                        onRemove = { onRemoveSkill(installed.id) },
                    )
                } else {
                    RemovedBuiltInSkillCard(
                        name = builtIn.name,
                        description = builtIn.description,
                        onReinstall = { onReinstallBuiltIn(builtIn.id) },
                    )
                }
                Spacer(Modifier.height(12.dp))
            }
            if (installedSkills.any { it.source.kind != com.arix.app.data.SkillInstallKind.Builtin }) {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "Your skills",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = ArixOnSurface,
                )
                Spacer(Modifier.height(8.dp))
            }
        }

        val userSkills = installedSkills.filter {
            it.source.kind != com.arix.app.data.SkillInstallKind.Builtin
        }
        if (installedSkills.isEmpty() && builtInCatalog.isEmpty()) {
            SettingsCardGroup {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        stringResource(R.string.settings_no_skills_installed),
                        style = MaterialTheme.typography.titleMedium,
                        color = ArixOnSurface,
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        stringResource(R.string.settings_import_skills_description),
                        style = MaterialTheme.typography.bodyMedium,
                        color = ArixOnSurfaceVariant,
                    )
                    Spacer(Modifier.height(16.dp))
                    SettingsActionButton(
                        label = stringResource(R.string.settings_add_skill),
                        onClick = onAddNew,
                    )
                }
            }
        } else {
            userSkills.forEach { skill ->
                SkillCard(
                    skill = skill,
                    onToggleEnabled = { enabled -> onToggleSkillEnabled(skill.id, enabled) },
                    onRemove = { onRemoveSkill(skill.id) },
                )
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

@Composable
private fun RemovedBuiltInSkillCard(
    name: String,
    description: String,
    onReinstall: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(ArixSurface.copy(alpha = 0.7f))
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = name,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = ArixOnSurfaceVariant,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.width(10.dp))
        Text(
            text = "Add",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = ArixPrimary,
            modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .background(ArixPrimary.copy(alpha = 0.14f))
                .clickable(onClick = onReinstall)
                .padding(horizontal = 14.dp, vertical = 8.dp),
        )
    }
}

@Composable
private fun SkillCard(
    skill: com.arix.app.data.InstalledSkill,
    onToggleEnabled: (Boolean) -> Unit,
    onRemove: () -> Unit,
) {
    var expanded by rememberSaveable(skill.id) { mutableStateOf(false) }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(ArixSurface)
            .animateContentSize()
            .padding(16.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = skill.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = ArixOnSurface,
                )
                if (skill.description.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = skill.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Spacer(Modifier.height(8.dp))
                ActionPreviewPill(label = skill.quickActionLabel())
            }
            IconButton(onClick = { expanded = !expanded }, modifier = Modifier.size(36.dp)) {
                Icon(
                    if (expanded) Icons.Rounded.ArrowDropDown else Icons.AutoMirrored.Rounded.ArrowForwardIos,
                    contentDescription = if (expanded) stringResource(R.string.action_collapse) else stringResource(R.string.action_expand),
                    tint = ArixOnSurfaceVariant,
                    modifier = Modifier.size(20.dp),
                )
            }
            IconButton(onClick = onRemove, modifier = Modifier.size(36.dp)) {
                Icon(
                    Icons.Rounded.Delete,
                    contentDescription = stringResource(R.string.action_remove),
                    tint = Color(0xFFD25757),
                    modifier = Modifier.size(20.dp),
                )
            }
        }

        Spacer(Modifier.height(12.dp))
        SettingsToggleRow(
            title = "",
            subtitle = "",
            checked = skill.isEnabled,
            onCheckedChange = onToggleEnabled,
        )
        if (expanded) {
            Spacer(Modifier.height(14.dp))
            Spacer(Modifier.height(14.dp))
            DetailLine(stringResource(R.string.settings_skill_id), skill.id)
            DetailLine(stringResource(R.string.settings_skill_files), "${skill.resourceEntries.size}")
            DetailLine(stringResource(R.string.settings_skill_allowed_tools), skill.allowedTools.ifEmpty { listOf(stringResource(R.string.settings_any)) }.joinToString(", "))
            if (skill.compatibility.isNotBlank()) {
                DetailLine(stringResource(R.string.settings_skill_compatibility), skill.compatibility)
            }
            if (skill.source.label.isNotBlank()) {
                DetailLine(stringResource(R.string.settings_skill_source), skill.source.label)
            }
            DetailLine(stringResource(R.string.settings_skill_path), skill.skillRootPath)
        }
    }
}

@Composable
private fun AddSkillPage(
    title: String,
    onImportSkillFolder: () -> Unit,
    onImportSkillZip: ((Boolean) -> Unit) -> Unit,
    onInstallSkillUrl: (String, (Boolean) -> Unit) -> Unit,
    onBack: () -> Unit,
) {
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    var skillUrlValue by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(""))
    }
    var isInstalling by remember { mutableStateOf(false) }

    val tabOptions = listOf(
        stringResource(R.string.settings_skill_source_folder),
        "Zip",
        "URL",
    )

    SubPageScaffold(title = title, onBack = onBack) {
        Text(
            text = stringResource(R.string.settings_add_skill_description),
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp),
        )

        Spacer(Modifier.height(16.dp))

        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
            tabOptions.forEachIndexed { index, label ->
                SegmentedButton(
                    shape = SegmentedButtonDefaults.itemShape(index = index, count = tabOptions.size),
                    onClick = { selectedTab = index },
                    selected = selectedTab == index,
                    colors = SegmentedButtonDefaults.colors(
                        activeContainerColor = ArixPrimary,
                        activeContentColor = Color.White,
                        inactiveContainerColor = ArixSurfaceHigh,
                        inactiveContentColor = ArixOnSurface,
                    ),
                ) {
                    Text(label)
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        when (selectedTab) {
            0 -> {
                SettingsCardGroup {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Icon(
                            Icons.Rounded.Folder,
                            contentDescription = null,
                            tint = ArixOnSurfaceVariant,
                            modifier = Modifier.size(48.dp),
                        )
                        Spacer(Modifier.height(12.dp))
                        Text(
                            stringResource(R.string.settings_select_skill_folder_description),
                            style = MaterialTheme.typography.bodyMedium,
                            color = ArixOnSurfaceVariant,
                        )
                        Spacer(Modifier.height(16.dp))
                        SettingsActionButton(
                            label = stringResource(R.string.settings_choose_folder),
                            onClick = {
                                onImportSkillFolder()
                            },
                        )
                    }
                }
            }

            1 -> {
                SettingsCardGroup {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Icon(
                            Icons.Rounded.Folder,
                            contentDescription = null,
                            tint = ArixOnSurfaceVariant,
                            modifier = Modifier.size(48.dp),
                        )
                        Spacer(Modifier.height(12.dp))
                        Text(
                            stringResource(R.string.settings_select_skill_zip_description),
                            style = MaterialTheme.typography.bodyMedium,
                            color = ArixOnSurfaceVariant,
                        )
                        Spacer(Modifier.height(16.dp))
                        SettingsActionButton(
                            label = stringResource(R.string.settings_choose_zip),
                            onClick = {
                                onImportSkillZip {}
                            },
                        )
                    }
                }
            }

            2 -> {
                SettingsCardGroup {
                    ChatGptTextField(
                        label = stringResource(R.string.settings_remote_skill_url),
                        value = skillUrlValue,
                        onValueChange = { skillUrlValue = it },
                    )
                }

                Spacer(Modifier.height(8.dp))
                Text(
                    text = stringResource(R.string.settings_remote_skill_url_description),
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 4.dp),
                )

                Spacer(Modifier.height(16.dp))

                if (isInstalling) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(24.dp),
                            strokeWidth = 2.dp,
                            color = ArixPrimary,
                        )
                        Spacer(Modifier.width(12.dp))
                        Text(stringResource(R.string.settings_installing), color = ArixOnSurfaceVariant)
                    }
                } else {
                    SettingsActionButton(
                        label = stringResource(R.string.settings_install_from_url),
                        onClick = {
                            if (skillUrlValue.text.isNotBlank()) {
                                isInstalling = true
                                onInstallSkillUrl(skillUrlValue.text) { success ->
                                    isInstalling = false
                                    if (success) {
                                        skillUrlValue = TextFieldValue("")
                                    }
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        }
    }
}

@Composable
private fun ScheduledTasksPage(
    tasks: List<ScheduledTask>,
    onToggleEnabled: (String, Boolean) -> Unit,
    onRemove: (String) -> Unit,
    onEdit: (String) -> Unit,
    onAddNew: () -> Unit,
    onBack: () -> Unit,
) {
    SubPageScaffold(
        title = stringResource(R.string.settings_scheduled_tasks),
        onBack = onBack,
        trailingIcon = Icons.Rounded.Add,
        onTrailingAction = onAddNew,
    ) {
        Text(
            text = stringResource(R.string.settings_scheduled_tasks_description),
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
        Spacer(Modifier.height(16.dp))

        if (tasks.isEmpty()) {
            SettingsCardGroup {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        text = stringResource(R.string.settings_no_scheduled_tasks),
                        style = MaterialTheme.typography.titleMedium,
                        color = ArixOnSurface,
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = stringResource(R.string.settings_create_scheduled_task_description),
                        style = MaterialTheme.typography.bodyMedium,
                        color = ArixOnSurfaceVariant,
                    )
                    Spacer(Modifier.height(16.dp))
                    SettingsActionButton(
                        label = stringResource(R.string.settings_add_task),
                        onClick = onAddNew,
                    )
                }
            }
        } else {
            tasks.sortedWith(compareBy<ScheduledTask> { it.nextRunAtMillis ?: Long.MAX_VALUE }.thenBy { it.name })
                .forEach { task ->
                    ScheduledTaskCard(
                        task = task,
                        onToggleEnabled = { enabled -> onToggleEnabled(task.id, enabled) },
                        onEdit = { onEdit(task.id) },
                        onRemove = { onRemove(task.id) },
                    )
                    Spacer(Modifier.height(12.dp))
                }
        }
    }
}

@Composable
private fun ScheduledTaskCard(
    task: ScheduledTask,
    onToggleEnabled: (Boolean) -> Unit,
    onEdit: () -> Unit,
    onRemove: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(ArixSurfaceHigh)
            .padding(16.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = task.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = ArixOnSurface,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = task.schedule.summary(),
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                )
            }
            IconButton(onClick = onEdit, modifier = Modifier.size(36.dp)) {
                Icon(
                    Icons.Rounded.Edit,
                    contentDescription = stringResource(R.string.action_edit),
                    tint = ArixOnSurface,
                    modifier = Modifier.size(18.dp),
                )
            }
            IconButton(onClick = onRemove, modifier = Modifier.size(36.dp)) {
                Icon(
                    Icons.Rounded.Delete,
                    contentDescription = stringResource(R.string.action_delete),
                    tint = Color(0xFFD25757),
                    modifier = Modifier.size(20.dp),
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(
            text = task.prompt.take(160),
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurface,
        )
        Spacer(Modifier.height(12.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Bottom,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = task.nextRunAtMillis?.formatScheduledTaskTime()
                        ?.let { stringResource(R.string.settings_next_run, it) }
                        ?: stringResource(R.string.settings_no_next_run_scheduled),
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                )
                Text(
                    text = if (task.createdBy == ScheduledTaskCreator.Agent) {
                        stringResource(R.string.settings_created_by_agent)
                    } else {
                        stringResource(R.string.settings_created_manually)
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = ArixOnSurfaceVariant,
                )
            }
            Switch(
                checked = task.isEnabled,
                onCheckedChange = onToggleEnabled,
            )
        }
    }
}

@Composable
private fun ScheduledTaskEditPage(
    existingTask: ScheduledTask?,
    onSave: (String, String, ScheduledTaskSchedule, Boolean) -> Unit,
    onBack: () -> Unit,
) {
    val existingInterval = existingTask?.schedule as? ScheduledTaskSchedule.Interval
    val existingDaily = existingTask?.schedule as? ScheduledTaskSchedule.Daily
    val existingWeekly = existingTask?.schedule as? ScheduledTaskSchedule.Weekly
    var nameValue by rememberSaveable(existingTask?.id, stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(existingTask?.name.orEmpty()))
    }
    var promptValue by rememberSaveable(existingTask?.id, stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(existingTask?.prompt.orEmpty()))
    }
    var enabledValue by rememberSaveable(existingTask?.id) {
        mutableStateOf(existingTask?.isEnabled ?: true)
    }
    var scheduleMode by rememberSaveable(existingTask?.id) {
        mutableIntStateOf(
            when (existingTask?.schedule) {
                is ScheduledTaskSchedule.Daily -> 1
                is ScheduledTaskSchedule.Weekly -> 2
                else -> 0
            }
        )
    }
    var intervalMinutesValue by rememberSaveable(existingTask?.id, stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(((existingInterval?.intervalMillis ?: 60L * 60L * 1000L) / 60_000L).toString()))
    }
    var activeStartValue by rememberSaveable(existingTask?.id, stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(existingInterval?.activeStartMinuteOfDay?.let(::formatTaskMinute).orEmpty()))
    }
    var activeEndValue by rememberSaveable(existingTask?.id, stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(existingInterval?.activeEndMinuteOfDay?.let(::formatTaskMinute).orEmpty()))
    }
    var dailyTimesValue by rememberSaveable(existingTask?.id, stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(existingDaily?.timesMinutesOfDay?.joinToString(",") { formatTaskMinute(it) } ?: "09:00"))
    }
    var weeklyDaysValue by rememberSaveable(existingTask?.id, stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(existingWeekly?.daysOfWeek?.joinToString(",") ?: "1"))
    }
    var weeklyTimeValue by rememberSaveable(existingTask?.id, stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(existingWeekly?.minuteOfDay?.let(::formatTaskMinute) ?: "09:00"))
    }

    fun buildSchedule(): ScheduledTaskSchedule? = when (scheduleMode) {
        0 -> ScheduledTaskSchedule.Interval(
            intervalMillis = (intervalMinutesValue.text.trim().toLongOrNull() ?: 60L).coerceAtLeast(1L) * 60_000L,
            activeStartMinuteOfDay = parseTaskMinute(activeStartValue.text),
            activeEndMinuteOfDay = parseTaskMinute(activeEndValue.text),
        )
        1 -> parseTaskTimes(dailyTimesValue.text).takeIf { it.isNotEmpty() }?.let { times ->
            ScheduledTaskSchedule.Daily(timesMinutesOfDay = times)
        }
        else -> {
            val days = parseTaskDays(weeklyDaysValue.text)
            val time = parseTaskMinute(weeklyTimeValue.text)
            if (days.isEmpty() || time == null) null else ScheduledTaskSchedule.Weekly(days, time)
        }
    }

    SubPageScaffold(
        title = if (existingTask == null) {
            stringResource(R.string.settings_add_scheduled_task)
        } else {
            stringResource(R.string.settings_edit_scheduled_task)
        },
        onBack = onBack,
        trailingIcon = Icons.Rounded.Check,
        trailingEnabled = nameValue.text.isNotBlank() && promptValue.text.isNotBlank(),
        onTrailingAction = {
            buildSchedule()?.let { schedule ->
                onSave(nameValue.text, promptValue.text, schedule, enabledValue)
            }
        },
    ) {
        SettingsCardGroup {
            ChatGptTextField(
                label = stringResource(R.string.settings_name),
                value = nameValue,
                onValueChange = { nameValue = it },
            )
            CardDivider()
            ChatGptTextField(
                label = stringResource(R.string.settings_prompt),
                value = promptValue,
                minLines = 4,
                onValueChange = { promptValue = it },
            )
        }
        Spacer(Modifier.height(16.dp))
        SettingsCardGroup {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                SettingsToggleRow(
                    title = stringResource(R.string.settings_enabled),
                    subtitle = stringResource(R.string.settings_disabled_tasks_saved_subtitle),
                    checked = enabledValue,
                    onCheckedChange = { enabledValue = it },
                )
            }
        }
        Spacer(Modifier.height(16.dp))
        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
            listOf(
                stringResource(R.string.settings_schedule_interval),
                stringResource(R.string.settings_schedule_daily),
                stringResource(R.string.settings_schedule_weekly),
            ).forEachIndexed { index, label ->
                SegmentedButton(
                    shape = SegmentedButtonDefaults.itemShape(index = index, count = 3),
                    onClick = { scheduleMode = index },
                    selected = scheduleMode == index,
                    colors = SegmentedButtonDefaults.colors(
                        activeContainerColor = ArixPrimary,
                        activeContentColor = Color.White,
                        inactiveContainerColor = ArixSurfaceHigh,
                        inactiveContentColor = ArixOnSurface,
                    ),
                ) {
                    Text(label)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        SettingsCardGroup {
            when (scheduleMode) {
                0 -> {
                    ChatGptTextField(
                        label = stringResource(R.string.settings_every_n_minutes),
                        value = intervalMinutesValue,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        onValueChange = { intervalMinutesValue = it.copy(text = it.text.filter(Char::isDigit)) },
                    )
                    CardDivider()
                    ChatGptTextField(
                        label = stringResource(R.string.settings_active_start_time),
                        value = activeStartValue,
                        onValueChange = { activeStartValue = it },
                    )
                    CardDivider()
                    ChatGptTextField(
                        label = stringResource(R.string.settings_active_end_time),
                        value = activeEndValue,
                        onValueChange = { activeEndValue = it },
                    )
                }
                1 -> ChatGptTextField(
                    label = stringResource(R.string.settings_times_comma_separated),
                    value = dailyTimesValue,
                    onValueChange = { dailyTimesValue = it },
                )
                else -> {
                    ChatGptTextField(
                        label = stringResource(R.string.settings_days_of_week_input),
                        value = weeklyDaysValue,
                        onValueChange = { weeklyDaysValue = it },
                    )
                    CardDivider()
                    ChatGptTextField(
                        label = stringResource(R.string.settings_time_hhmm),
                        value = weeklyTimeValue,
                        onValueChange = { weeklyTimeValue = it },
                    )
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            text = stringResource(R.string.settings_interval_window_hint),
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
    }
}

@Composable
private fun RuntimeCleanupDeveloperSettingsSection(
    autoCleanOldCommandHistory: Boolean,
    oldCommandHistoryRetentionHours: TextFieldValue,
    onAutoCleanOldCommandHistoryChanged: (Boolean) -> Unit,
    onOldCommandHistoryRetentionHoursChanged: (TextFieldValue) -> Unit,
) {
    SettingsCardGroup {
        Column(modifier = Modifier.padding(16.dp)) {
            SettingsToggleRow(
                title = stringResource(R.string.settings_old_command_history_retention_hours),
                subtitle = stringResource(R.string.settings_old_command_history_retention_hours_description),
                checked = autoCleanOldCommandHistory,
                onCheckedChange = onAutoCleanOldCommandHistoryChanged,
            )
            AnimatedVisibility(visible = autoCleanOldCommandHistory) {
                Column {
                    Spacer(Modifier.height(12.dp))
                    ChatGptTextField(
                        value = oldCommandHistoryRetentionHours,
                        onValueChange = { value ->
                            onOldCommandHistoryRetentionHoursChanged(
                                value.copy(text = value.text.filter(Char::isDigit)),
                            )
                        },
                        label = stringResource(R.string.settings_old_command_history_retention_hours_value),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = stringResource(R.string.settings_old_command_history_retention_hours_value_description),
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun TermuxSettingsPage(
    title: String,
    setupState: LocalRuntimeSetupState,
    isDefaultRuntime: Boolean,
    onInitialize: () -> Unit,
    onReset: () -> Unit,
    onRefresh: () -> Unit,
    onSetDefault: () -> Unit,
    onBack: () -> Unit,
) {
    LaunchedEffect(Unit) {
        onRefresh()
    }
    SubPageScaffold(
        title = title,
        onBack = onBack,
    ) {
        Text(
            text = stringResource(R.string.settings_termux_description),
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp),
        )

        Spacer(Modifier.height(16.dp))

        SettingsCardGroup {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = stringResource(R.string.settings_runtime_status),
                    style = MaterialTheme.typography.labelLarge,
                    color = ArixOnSurface,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = termuxSetupStatusText(setupState),
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                )
                if (setupState.detail.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = setupState.detail,
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                    )
                }
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SettingsActionButton(
                        label = when (setupState.issue) {
                            LocalRuntimeIssue.Ready -> stringResource(R.string.settings_ready)
                            else -> stringResource(R.string.settings_initialize)
                        },
                        onClick = onInitialize,
                        modifier = Modifier.weight(1f),
                        enabled = !setupState.isReady,
                    )
                    SettingsSubtleActionButton(
                        label = stringResource(R.string.common_refresh),
                        onClick = onRefresh,
                        modifier = Modifier.weight(1f),
                    )
                }
                Spacer(Modifier.height(10.dp))
                SettingsSubtleActionButton(
                    label = stringResource(R.string.settings_reset_termux_data),
                    onClick = onReset,
                    modifier = Modifier.fillMaxWidth(),
                )
                if (setupState.isReady && !isDefaultRuntime) {
                    Spacer(Modifier.height(10.dp))
                    SettingsActionButton(
                        label = stringResource(R.string.settings_use_as_default_runtime),
                        onClick = onSetDefault,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        SettingsCardGroup {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = stringResource(R.string.settings_on_demand_packages),
                    style = MaterialTheme.typography.labelLarge,
                    color = ArixOnSurface,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = stringResource(R.string.settings_on_demand_packages_description),
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun termuxSetupStatusText(
    setupState: LocalRuntimeSetupState,
): String = when (setupState.issue) {
    LocalRuntimeIssue.Ready -> stringResource(R.string.settings_termux_status_ready)
    LocalRuntimeIssue.NotConfigured,
    LocalRuntimeIssue.NotInstalled -> stringResource(R.string.settings_termux_status_not_installed)
    LocalRuntimeIssue.UnsupportedAbi -> stringResource(R.string.settings_termux_status_unsupported_abi)
    LocalRuntimeIssue.MissingAssets -> stringResource(R.string.settings_termux_status_missing_assets)
    LocalRuntimeIssue.Failed -> stringResource(R.string.settings_termux_status_failed)
    LocalRuntimeIssue.PermissionMissing,
    LocalRuntimeIssue.ExternalAppsDisabled,
    LocalRuntimeIssue.DispatchFailed -> stringResource(R.string.settings_termux_status_not_ready)
}

@Composable
private fun DeveloperSettingsPage(
    title: String,
    onImportAppData: () -> Unit,
    onExportAppData: () -> Unit,
    onExportLogs: () -> Unit,
    developerRoleFallbackProviders: List<LlmProviderConfig>,
    onClearDeveloperRoleFallback: (String) -> Unit,
    autoCleanOldCommandHistory: Boolean,
    oldCommandHistoryRetentionHours: TextFieldValue,
    onAutoCleanOldCommandHistoryChanged: (Boolean) -> Unit,
    onOldCommandHistoryRetentionHoursChanged: (TextFieldValue) -> Unit,
    onBack: () -> Unit,
) {
    SubPageScaffold(title = title, onBack = onBack) {
        Text(
            text = stringResource(R.string.settings_developer_description),
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp),
        )

        Spacer(Modifier.height(16.dp))

        SettingsCardGroup {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = stringResource(R.string.settings_app_data),
                    style = MaterialTheme.typography.labelLarge,
                    color = ArixOnSurface,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = stringResource(R.string.settings_app_data_description),
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                )
                Spacer(Modifier.height(16.dp))
                SettingsSubtleActionButton(
                    label = stringResource(R.string.settings_import_app_data),
                    onClick = onImportAppData,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(10.dp))
                SettingsSubtleActionButton(
                    label = stringResource(R.string.settings_export_app_data),
                    onClick = onExportAppData,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }

        Spacer(Modifier.height(14.dp))

        SettingsCardGroup {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = stringResource(R.string.settings_logs),
                    style = MaterialTheme.typography.labelLarge,
                    color = ArixOnSurface,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = stringResource(R.string.settings_logs_description),
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                )
                Spacer(Modifier.height(16.dp))
                SettingsSubtleActionButton(
                    label = stringResource(R.string.settings_export_logs),
                    onClick = onExportLogs,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }

        Spacer(Modifier.height(14.dp))

        if (developerRoleFallbackProviders.isNotEmpty()) {
            SettingsCardGroup {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = stringResource(R.string.settings_developer_role_fallbacks),
                        style = MaterialTheme.typography.labelLarge,
                        color = ArixOnSurface,
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = stringResource(
                            R.string.settings_developer_role_fallbacks_description,
                        ),
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                    )
                    developerRoleFallbackProviders.forEach { config ->
                        Spacer(Modifier.height(16.dp))
                        SettingsToggleRow(
                            title = config.name,
                            subtitle = config.providerId,
                            checked = true,
                            onCheckedChange = { enabled ->
                                if (!enabled) onClearDeveloperRoleFallback(config.id)
                            },
                        )
                    }
                }
            }

            Spacer(Modifier.height(14.dp))
        }

        RuntimeCleanupDeveloperSettingsSection(
            autoCleanOldCommandHistory = autoCleanOldCommandHistory,
            oldCommandHistoryRetentionHours = oldCommandHistoryRetentionHours,
            onAutoCleanOldCommandHistoryChanged = onAutoCleanOldCommandHistoryChanged,
            onOldCommandHistoryRetentionHoursChanged = onOldCommandHistoryRetentionHoursChanged,
        )
    }
}

private data class ArixPermissionRowModel(
    val title: String,
    val why: String,
    val granted: Boolean?,
    val actionLabel: String?,
    val onAction: (() -> Unit)?,
)

@Composable
private fun PermissionsSettingsPage(
    title: String,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    var refreshTick by remember { mutableIntStateOf(0) }
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) refreshTick++
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val runtimePermissionLauncher = rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions(),
    ) { refreshTick++ }

    @Suppress("UNUSED_EXPRESSION") refreshTick

    fun check(permission: String): Boolean? =
        if (android.os.Build.VERSION.SDK_INT >= 33 && permission == android.Manifest.permission.POST_NOTIFICATIONS ||
            permission == android.Manifest.permission.RECORD_AUDIO
        ) {
            androidx.core.content.ContextCompat.checkSelfPermission(context, permission) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
        } else {
            null
        }

    val rows = buildList {
        add(
            ArixPermissionRowModel(
                title = stringResource(R.string.permissions_notifications_title),
                why = stringResource(R.string.permissions_notifications_why),
                granted = if (android.os.Build.VERSION.SDK_INT >= 33) {
                    check(android.Manifest.permission.POST_NOTIFICATIONS)
                } else {
                    true
                },
                actionLabel = if (android.os.Build.VERSION.SDK_INT >= 33) {
                    stringResource(R.string.permissions_action_request)
                } else {
                    null
                },
                onAction = if (android.os.Build.VERSION.SDK_INT >= 33) {
                    {
                        runtimePermissionLauncher.launch(
                            arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),
                        )
                    }
                } else {
                    null
                },
            )
        )
        add(
            ArixPermissionRowModel(
                title = stringResource(R.string.permissions_microphone_title),
                why = stringResource(R.string.permissions_microphone_why),
                granted = check(android.Manifest.permission.RECORD_AUDIO),
                actionLabel = stringResource(R.string.permissions_action_request),
                onAction = {
                    runtimePermissionLauncher.launch(arrayOf(android.Manifest.permission.RECORD_AUDIO))
                },
            )
        )
        add(
            ArixPermissionRowModel(
                title = stringResource(R.string.permissions_files_title),
                why = stringResource(R.string.permissions_files_why),
                granted = check(android.Manifest.permission.READ_EXTERNAL_STORAGE),
                actionLabel = stringResource(R.string.permissions_action_request),
                onAction = {
                    runtimePermissionLauncher.launch(
                        com.arix.app.runtime.ArixDeviceStorage.runtimePermissions(),
                    )
                },
            )
        )
        add(
            ArixPermissionRowModel(
                title = stringResource(R.string.permissions_alarms_title),
                why = stringResource(R.string.permissions_alarms_why),
                granted = if (android.os.Build.VERSION.SDK_INT >= 31) {
                    (context.getSystemService(android.content.Context.ALARM_SERVICE)
                        as? android.app.AlarmManager)?.canScheduleExactAlarms()
                } else {
                    true
                },
                actionLabel = if (android.os.Build.VERSION.SDK_INT >= 31) {
                    stringResource(R.string.permissions_action_open_settings)
                } else {
                    null
                },
                onAction = if (android.os.Build.VERSION.SDK_INT >= 31) {
                    {
                        runCatching {
                            context.startActivity(
                                android.content.Intent(
                                    android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                                ),
                            )
                        }
                    }
                } else {
                    null
                },
            )
        )
    }

    SubPageScaffold(title = title, onBack = onBack) {
        rows.forEachIndexed { index, row ->
            if (index > 0) Spacer(Modifier.height(12.dp))
            SettingsCardGroup {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = row.title,
                            style = MaterialTheme.typography.bodyMedium,
                            color = ArixOnSurface,
                            modifier = Modifier.weight(1f),
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            text = stringResource(
                                when (row.granted) {
                                    true -> R.string.permissions_status_granted
                                    false -> R.string.permissions_status_denied
                                    null -> R.string.permissions_status_available
                                }
                            ),
                            style = MaterialTheme.typography.labelMedium,
                            color = when (row.granted) {
                                true -> Color(0xFF89C8AF)
                                false -> ArixOnSurfaceVariant
                                null -> ArixOnSurfaceVariant
                            },
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = row.why,
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                    )
                    if (row.actionLabel != null && row.granted == false && row.onAction != null) {
                        Spacer(Modifier.height(10.dp))
                        androidx.compose.material3.OutlinedButton(
                            onClick = row.onAction,
                        ) {
                            Text(row.actionLabel)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AboutPage(
    title: String,
    onOpenWebsite: () -> Unit,
    onOpenPrivacyPolicy: () -> Unit,
    onBack: () -> Unit,
) {
    val releaseLabel = stringResource(R.string.settings_release_summary, BuildConfig.VERSION_NAME)
    SubPageScaffold(title = title, onBack = onBack) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Image(
                painter = painterResource(R.drawable.arix_mark),
                contentDescription = stringResource(R.string.settings_arix_logo),
                modifier = Modifier.size(112.dp),
            )
            Spacer(Modifier.height(14.dp))
            Text(
                text = "Arix",
                style = MaterialTheme.typography.titleLarge,
                color = ArixOnSurface,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = releaseLabel,
                style = MaterialTheme.typography.bodyMedium,
                color = ArixOnSurfaceVariant,
            )
        }

        Spacer(Modifier.height(24.dp))

        SettingsCardGroup {
            AboutInfoRow(label = stringResource(R.string.settings_author), value = stringResource(R.string.settings_author_name))
            CardDivider()
            AboutInfoRow(label = stringResource(R.string.settings_version), value = releaseLabel)
            CardDivider()
            SettingsNavRow(
                icon = Icons.Rounded.Link,
                title = stringResource(R.string.settings_website),
                subtitle = "",
                onClick = onOpenWebsite,
            )
            CardDivider()
            SettingsNavRow(
                icon = Icons.Rounded.Link,
                title = stringResource(R.string.settings_privacy_policy),
                subtitle = "",
                onClick = onOpenPrivacyPolicy,
            )
        }

    }
}

@Composable
private fun AboutInfoRow(
    label: String,
    value: String,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = ArixOnSurfaceVariant,
            modifier = Modifier.width(84.dp),
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyLarge,
            color = ArixOnSurface,
            modifier = Modifier.weight(1f),
        )
    }
}

@Composable
internal fun SubPageScaffold(
    title: String,
    onBack: () -> Unit,
    trailingIcon: ImageVector? = null,
    trailingEnabled: Boolean = true,
    trailingLoading: Boolean = false,
    trailingContentDescription: String = title,
    onTrailingAction: (() -> Unit)? = null,
    secondaryTrailingIcon: ImageVector? = null,
    secondaryTrailingEnabled: Boolean = true,
    secondaryTrailingContentDescription: String = title,
    onSecondaryTrailingAction: (() -> Unit)? = null,
    tertiaryTrailingIcon: ImageVector? = null,
    tertiaryTrailingEnabled: Boolean = true,
    tertiaryTrailingContentDescription: String = title,
    onTertiaryTrailingAction: (() -> Unit)? = null,
    content: @Composable () -> Unit,
) {
    var topBarBodyHeightPx by remember { mutableIntStateOf(0) }
    val density = LocalDensity.current
    val fallbackTopBarBodyHeight = with(density) {
        WindowInsets.statusBars.getTop(this).toDp() + 68.dp
    }
    val topBarBodyHeight = with(density) {
        if (topBarBodyHeightPx > 0) topBarBodyHeightPx.toDp() else fallbackTopBarBodyHeight
    }
    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = ArixSettingsBackground,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(top = topBarBodyHeight)
                    .padding(horizontal = 20.dp)
                    .imePadding()
                    .navigationBarsPadding(),
            ) {
                Spacer(Modifier.height(6.dp))
                content()
                Spacer(Modifier.height(32.dp))
            }

            SettingsTopBarOverlay(
                modifier = Modifier.align(Alignment.TopCenter),
                title = title,
                onBack = onBack,
                trailingIcon = trailingIcon,
                trailingEnabled = trailingEnabled,
                trailingLoading = trailingLoading,
                trailingContentDescription = trailingContentDescription,
                onTrailingAction = onTrailingAction,
                secondaryTrailingIcon = secondaryTrailingIcon,
                secondaryTrailingEnabled = secondaryTrailingEnabled,
                secondaryTrailingContentDescription = secondaryTrailingContentDescription,
                onSecondaryTrailingAction = onSecondaryTrailingAction,
                tertiaryTrailingIcon = tertiaryTrailingIcon,
                tertiaryTrailingEnabled = tertiaryTrailingEnabled,
                tertiaryTrailingContentDescription = tertiaryTrailingContentDescription,
                onTertiaryTrailingAction = onTertiaryTrailingAction,
                onBodyHeightChanged = { topBarBodyHeightPx = it },
            )
        }
    }
}

@Composable
private fun SettingsTopBarOverlay(
    modifier: Modifier = Modifier,
    title: String,
    onBack: () -> Unit,
    trailingIcon: ImageVector? = null,
    trailingEnabled: Boolean = true,
    trailingLoading: Boolean = false,
    trailingContentDescription: String = title,
    onTrailingAction: (() -> Unit)? = null,
    secondaryTrailingIcon: ImageVector? = null,
    secondaryTrailingEnabled: Boolean = true,
    secondaryTrailingContentDescription: String = title,
    onSecondaryTrailingAction: (() -> Unit)? = null,
    tertiaryTrailingIcon: ImageVector? = null,
    tertiaryTrailingEnabled: Boolean = true,
    tertiaryTrailingContentDescription: String = title,
    onTertiaryTrailingAction: (() -> Unit)? = null,
    onBodyHeightChanged: (Int) -> Unit,
) {
    Column(
        modifier = modifier.fillMaxWidth(),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(settingsTopOverlayBodyGradient())
                .onSizeChanged { onBodyHeightChanged(it.height) },
        ) {
            SettingsTopBar(
                title = title,
                onBack = onBack,
                trailingIcon = trailingIcon,
                trailingEnabled = trailingEnabled,
                trailingLoading = trailingLoading,
                trailingContentDescription = trailingContentDescription,
                onTrailingAction = onTrailingAction,
                secondaryTrailingIcon = secondaryTrailingIcon,
                secondaryTrailingEnabled = secondaryTrailingEnabled,
                secondaryTrailingContentDescription = secondaryTrailingContentDescription,
                onSecondaryTrailingAction = onSecondaryTrailingAction,
                tertiaryTrailingIcon = tertiaryTrailingIcon,
                tertiaryTrailingEnabled = tertiaryTrailingEnabled,
                tertiaryTrailingContentDescription = tertiaryTrailingContentDescription,
                onTertiaryTrailingAction = onTertiaryTrailingAction,
            )
        }
        Spacer(
            modifier = Modifier
                .fillMaxWidth()
                .height(SettingsTopFadeHeight)
                .background(settingsTopOverlayTailGradient())
        )
    }
}

@Composable
private fun SettingsTopBar(
    title: String,
    onBack: () -> Unit,
    trailingIcon: ImageVector? = null,
    trailingEnabled: Boolean = true,
    trailingLoading: Boolean = false,
    trailingContentDescription: String = title,
    onTrailingAction: (() -> Unit)? = null,
    secondaryTrailingIcon: ImageVector? = null,
    secondaryTrailingEnabled: Boolean = true,
    secondaryTrailingContentDescription: String = title,
    onSecondaryTrailingAction: (() -> Unit)? = null,
    tertiaryTrailingIcon: ImageVector? = null,
    tertiaryTrailingEnabled: Boolean = true,
    tertiaryTrailingContentDescription: String = title,
    onTertiaryTrailingAction: (() -> Unit)? = null,
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp),
    ) {
        SettingsCircleButton(
            icon = Icons.AutoMirrored.Rounded.ArrowBack,
            contentDescription = stringResource(R.string.common_back),
            onClick = onBack,
            modifier = Modifier.align(Alignment.CenterStart),
        )
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            color = ArixOnSurface,
            modifier = Modifier
                .align(Alignment.Center)
                .offset(x = if (tertiaryTrailingIcon != null) (-48).dp else 0.dp),
        )
        Row(
            modifier = Modifier.align(Alignment.CenterEnd),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (tertiaryTrailingIcon != null && onTertiaryTrailingAction != null) {
                SettingsCircleButton(
                    icon = tertiaryTrailingIcon,
                    contentDescription = tertiaryTrailingContentDescription,
                    enabled = tertiaryTrailingEnabled,
                    onClick = onTertiaryTrailingAction,
                )
            }
            if (secondaryTrailingIcon != null && onSecondaryTrailingAction != null) {
                SettingsCircleButton(
                    icon = secondaryTrailingIcon,
                    contentDescription = secondaryTrailingContentDescription,
                    enabled = secondaryTrailingEnabled,
                    onClick = onSecondaryTrailingAction,
                )
            }
            if (trailingLoading) {
                Box(modifier = Modifier.size(44.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp,
                        color = ArixPrimary,
                    )
                }
            } else if (trailingIcon != null && onTrailingAction != null) {
                SettingsCircleButton(
                    icon = trailingIcon,
                    contentDescription = trailingContentDescription,
                    enabled = trailingEnabled,
                    onClick = onTrailingAction,
                )
            } else if (secondaryTrailingIcon == null) {
                Spacer(Modifier.size(44.dp))
            }
        }
    }
}

@Composable
private fun SettingsCircleButton(
    icon: ImageVector,
    contentDescription: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    Box(
        modifier = modifier
            .size(44.dp)
            .shadow(10.dp, RoundedCornerShape(50), ambientColor = ArixScrim, spotColor = ArixScrim)
            .clip(RoundedCornerShape(50))
            .background(if (enabled) ArixSurface else ArixSurface.copy(alpha = 0.55f))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            icon,
            contentDescription = contentDescription,
            tint = if (enabled) ArixOnSurface else ArixOnSurface.copy(alpha = 0.45f),
        )
    }
}
