package com.arix.app.ui

import androidx.compose.runtime.LaunchedEffect
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.arix.app.R
import com.arix.app.ui.theme.ArixOnSurface
import com.arix.app.ui.theme.ArixOnSurfaceVariant
import com.arix.app.ui.theme.ArixSurfaceHigh
import com.arix.app.ui.theme.ArixSurfaceVariant

@Composable
internal fun MarkdownCodeFence(
    code: MarkdownSourceText,
    language: String,
) {
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) {
        if (copied) {
            kotlinx.coroutines.delay(1600)
            copied = false
        }
    }
    val displayLabel = language.ifBlank { "code" }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .streamingBlockReveal(code.sourceOffset)
            .clip(RoundedCornerShape(18.dp))
            .background(ArixSurfaceHigh),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(ArixSurfaceVariant.copy(alpha = 0.55f))
                .padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = displayLabel,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 0.4.sp,
                ),
                color = ArixOnSurfaceVariant,
                modifier = Modifier.weight(1f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            val copyIcon: ImageVector = if (copied) Icons.Rounded.CheckCircle else Icons.Rounded.ContentCopy
            val copyIconTint = if (copied) Color(0xFF4E8D5A) else ArixOnSurfaceVariant
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .clickable {
                        clipboard.setText(AnnotatedString(code.text))
                        copied = true
                        android.widget.Toast.makeText(
                            context,
                            context.getString(R.string.code_block_copied),
                            android.widget.Toast.LENGTH_SHORT,
                        ).show()
                    }
                    .padding(horizontal = 10.dp, vertical = 4.dp),
            ) {
                Icon(
                    imageVector = copyIcon,
                    contentDescription = stringResource(R.string.common_copy),
                    tint = copyIconTint,
                    modifier = Modifier.size(18.dp),
                )
            }
        }
        Text(
            text = remember(code.text, language) {
                MarkdownCodeHighlight.highlight(code.text, language)
            },
            style = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
            color = ArixOnSurface,
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 14.dp, vertical = 12.dp),
        )
    }
}
