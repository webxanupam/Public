package com.arix.app.data

import android.os.SystemClock
import org.json.JSONObject
object ArixLatencyTracer {

    private const val StageCount = 14

    const val INPUT_RECEIVED = 0
    const val REQUEST_CREATED = 1
    const val PROVIDER_SELECTED = 2
    const val BRIDGE_REUSED = 3
    const val BRIDGE_STARTED = 4
    const val MODEL_REQUEST_STARTED = 5
    const val FIRST_TOKEN = 6
    const val FIRST_VISIBLE_UPDATE = 7
    const val TOOL_REQUEST = 8
    const val TOOL_STARTED = 9
    const val TOOL_FIRST_OUTPUT = 10
    const val TOOL_COMPLETED = 11
    const val MODEL_RESUMED = 12
    const val FINAL_TOKEN = 13

    private const val NOT_RECORDED = -1L

    private class TurnRecord(val turnId: String) {
        val timestamps = LongArray(StageCount) { NOT_RECORDED }
        val uptimeBase = SystemClock.uptimeMillis()
        var toolCallCount = 0
    }

    private val turns = LinkedHashMap<String, TurnRecord>(16, 0.75f, true)

    private val lock = Any()

    fun record(turnId: String, stage: Int) {
        if (turnId.isBlank()) return
        val record = synchronized(lock) {
            turns.getOrPut(turnId) {
                if (turns.size >= MaxTrackedTurns) {
                    turns.remove(turns.keys.first())
                }
                TurnRecord(turnId)
            }
        }
        if (record.timestamps[stage] == NOT_RECORDED) {
            record.timestamps[stage] = (SystemClock.uptimeMillis() - record.uptimeBase)
                .coerceAtLeast(0L)
        }
    }

    fun recordToolCall(turnId: String) {
        synchronized(lock) {
            turns[turnId]?.toolCallCount = turns[turnId]?.toolCallCount?.plus(1) ?: 1
        }
    }

    fun report(): JSONObject {
        val turnsSnapshot = synchronized(lock) { turns.values.toList() }
        val turnsJson = org.json.JSONArray()
        turnsSnapshot.takeLast(ReportTurns).forEach { turn ->
            turnsJson.put(turnJson(turn))
        }
        return JSONObject()
            .put("ok", true)
            .put("turns", turnsJson)
    }

    fun lastFirstResponseMillis(): Long? {
        val last = synchronized(lock) { turns.values.lastOrNull() } ?: return null
        val input = last.timestamps[INPUT_RECEIVED]
        val first = last.timestamps[FIRST_VISIBLE_UPDATE]
        if (input == NOT_RECORDED || first == NOT_RECORDED) return null
        return first - input
    }

    private fun turnJson(turn: TurnRecord): JSONObject {
        val t = turn.timestamps
        fun delta(from: Int, to: Int): Long? {
            if (t[from] == NOT_RECORDED || t[to] == NOT_RECORDED) return null
            return t[to] - t[from]
        }
        return JSONObject()
            .put("turn_id", turn.turnId)
            .put("tool_calls", turn.toolCallCount)
            .putOpt("input_to_first_token_ms", delta(INPUT_RECEIVED, FIRST_TOKEN))
            .putOpt("input_to_first_visible_ms", delta(INPUT_RECEIVED, FIRST_VISIBLE_UPDATE))
            .putOpt("request_created_to_model_start_ms", delta(REQUEST_CREATED, MODEL_REQUEST_STARTED))
            .putOpt("bridge_start_to_model_start_ms", delta(BRIDGE_STARTED, MODEL_REQUEST_STARTED))
            .putOpt("first_token_to_final_token_ms", delta(FIRST_TOKEN, FINAL_TOKEN))
            .putOpt("tool_request_to_first_output_ms", delta(TOOL_REQUEST, TOOL_FIRST_OUTPUT))
            .putOpt("tool_completion_to_model_resumed_ms", delta(TOOL_COMPLETED, MODEL_RESUMED))
            .putOpt("total_input_to_final_ms", delta(INPUT_RECEIVED, FINAL_TOKEN))
    }

    fun resetForTest() {
        synchronized(lock) { turns.clear() }
    }

    private const val MaxTrackedTurns = 12
    private const val ReportTurns = 6
}
