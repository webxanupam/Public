package com.arix.app.mission

import java.util.UUID
import org.json.JSONArray
import org.json.JSONObject

object ArixMissionContract {
    const val MISSION_NOT_FOUND = "MISSION_NOT_FOUND"
    const val MISSION_INVALID_STATE = "MISSION_INVALID_STATE"
    const val MAX_STEPS_HARD_CAP = 24
    const val MAX_REPLAN_CYCLES = 3
    const val MAX_TOTAL_TASK_EXECUTIONS_FACTOR = 4
    const val MAX_TOTAL_TASK_EXECUTIONS_FLOOR = 12
    const val DEFAULT_GLOBAL_TIMEOUT_MILLIS = 30L * 60_000L
    const val DEFAULT_STEP_TIMEOUT_MILLIS = 10L * 60_000L
    const val DEFAULT_MAX_CONCURRENCY = 3
}

enum class MissionStatus(val storageValue: String) {
    Planning("planning"),

    AwaitingApproval("awaiting_approval"),

    Running("running"),

    Paused("paused"),

    Interrupted("interrupted"),

    Completed("completed"),

    Failed("failed"),

    Cancelled("cancelled"),

    ;

    val isTerminal: Boolean get() = this == Completed || this == Failed || this == Cancelled
    val isResumable: Boolean get() = this == Paused || this == Interrupted

    companion object {
        fun fromStorage(value: String?): MissionStatus =
            entries.firstOrNull { it.storageValue == value?.trim()?.lowercase() } ?: Planning
    }
}

enum class MissionTaskStatus(val storageValue: String) {
    Pending("pending"),

    Queued("queued"),

    Running("running"),

    Verifying("verifying"),

    Completed("completed"),

    Failed("failed"),

    Skipped("skipped"),

    Cancelled("cancelled"),

    ;

    val isTerminal: Boolean get() =
        this == Completed || this == Failed || this == Skipped || this == Cancelled

    companion object {
        fun fromStorage(value: String?): MissionTaskStatus =
            entries.firstOrNull { it.storageValue == value?.trim()?.lowercase() } ?: Pending
    }
}

data class MissionRetryPolicy(
    val maxAttempts: Int = 2,
    val backoffBaseMillis: Long = 800L,
    val backoffCapMillis: Long = 15_000L,
) {
    fun delayForRetry(retry: Int): Long {
        if (retry <= 0) return 0L
        val exponential = backoffBaseMillis * (1L shl (retry - 1).coerceAtMost(10))
        return exponential.coerceAtMost(backoffCapMillis)
    }

    fun canRetry(attemptsUsed: Int): Boolean = attemptsUsed < maxAttempts

    companion object {
        val NONE = MissionRetryPolicy(maxAttempts = 1)
    }
}

data class MissionTask(
    val taskId: String = "task-" + UUID.randomUUID().toString().take(8),
    val description: String,
    val requiredCapability: String,
    val preferredTool: String? = null,
    val instruction: String = "",
    val dependsOn: List<String> = emptyList(),
    val priority: Int = 5,
    val timeoutMillis: Long = ArixMissionContract.DEFAULT_STEP_TIMEOUT_MILLIS,
    val retryPolicy: MissionRetryPolicy = MissionRetryPolicy(),
    val requiresVerification: Boolean = true,
    val mutating: Boolean = false,
    val status: MissionTaskStatus = MissionTaskStatus.Pending,
    val attemptsUsed: Int = 0,
    val resultSummary: String = "",
    val resultJson: String = "",
    val error: String = "",
    val errorCategory: String = "",
    val startedAtMillis: Long? = null,
    val completedAtMillis: Long? = null,
    val executedWithTool: String = "",
) {
    val isReady: Boolean get() = status == MissionTaskStatus.Pending
    val isCompleted: Boolean get() = status == MissionTaskStatus.Completed
    val isFailed: Boolean get() = status == MissionTaskStatus.Failed
    val isTerminal: Boolean get() = status.isTerminal
}

data class MissionCheckpoint(
    val checkpointId: String = "cp-" + UUID.randomUUID().toString().take(8),
    val atMillis: Long = System.currentTimeMillis(),
    val phase: String,
    val detail: String = "",
)

data class ArixMission(
    val missionId: String = "mission-" + UUID.randomUUID().toString().take(12),
    val objective: String,
    val projectId: String = "",
    val sessionId: String = "",
    val plan: List<MissionTask> = emptyList(),
    val status: MissionStatus = MissionStatus.Planning,
    val currentStep: String = "understand",
    val progress: Float = 0f,
    val understanding: String = "",
    val replanCycles: Int = 0,
    val totalTaskExecutions: Int = 0,
    val activeTools: List<String> = emptyList(),
    val checkpoints: List<MissionCheckpoint> = emptyList(),
    val startedAtMillis: Long = System.currentTimeMillis(),
    val updatedAtMillis: Long = startedAtMillis,
    val globalTimeoutMillis: Long = ArixMissionContract.DEFAULT_GLOBAL_TIMEOUT_MILLIS,
    val maxConcurrency: Int = ArixMissionContract.DEFAULT_MAX_CONCURRENCY,
    val requireApproval: Boolean = false,
    val finalResult: String = "",
    val error: String = "",
    val errorCategory: String = "",
) {
    val pendingSteps: List<MissionTask> get() = plan.filter { !it.isTerminal }
    val completedSteps: List<MissionTask> get() = plan.filter { it.isCompleted }
    val failedSteps: List<MissionTask> get() = plan.filter { it.isFailed }

    val allStepsTerminal: Boolean get() = plan.isNotEmpty() && plan.all { it.isTerminal }

    fun withProgress(): ArixMission {
        val total = plan.size.coerceAtLeast(1)
        val done = plan.count { it.isTerminal }
        return copy(
            progress = if (status == MissionStatus.Completed) 1f else done.toFloat() / total,
        )
    }
}

fun MissionTask.toJson(): JSONObject = JSONObject().apply {
    put("taskId", taskId)
    put("description", description)
    put("requiredCapability", requiredCapability)
    put("preferredTool", preferredTool ?: JSONObject.NULL)
    put("instruction", instruction)
    put("dependsOn", JSONArray(dependsOn))
    put("priority", priority)
    put("timeoutMillis", timeoutMillis)
    put("retryPolicy", JSONObject()
        .put("maxAttempts", retryPolicy.maxAttempts)
        .put("backoffBaseMillis", retryPolicy.backoffBaseMillis)
        .put("backoffCapMillis", retryPolicy.backoffCapMillis))
    put("requiresVerification", requiresVerification)
    put("mutating", mutating)
    put("status", status.storageValue)
    put("attemptsUsed", attemptsUsed)
    put("resultSummary", resultSummary)
    put("resultJson", resultJson)
    put("error", error)
    put("errorCategory", errorCategory)
    put("startedAtMillis", startedAtMillis ?: JSONObject.NULL)
    put("completedAtMillis", completedAtMillis ?: JSONObject.NULL)
    put("executedWithTool", executedWithTool)
}

fun parseMissionTask(json: JSONObject): MissionTask? {
    val taskId = json.optString("taskId").trim()
    val description = json.optString("description").trim()
    val capability = json.optString("requiredCapability").trim()
    if (taskId.isEmpty() || description.isEmpty() || capability.isEmpty()) return null
    val retryJson = json.optJSONObject("retryPolicy")
    val dependsOn = json.optJSONArray("dependsOn")?.let { array ->
        buildList {
            for (index in 0 until array.length()) {
                array.optString(index).trim().takeIf { it.isNotEmpty() }?.let(::add)
            }
        }
    }.orEmpty()
    return MissionTask(
        taskId = taskId,
        description = description,
        requiredCapability = capability,
        preferredTool = json.optString("preferredTool").trim().takeIf { it.isNotEmpty() },
        instruction = json.optString("instruction"),
        dependsOn = dependsOn,
        priority = json.optInt("priority", 5).coerceIn(1, 9),
        timeoutMillis = json.optLong("timeoutMillis", ArixMissionContract.DEFAULT_STEP_TIMEOUT_MILLIS)
            .coerceIn(5_000L, 60L * 60_000L),
        retryPolicy = MissionRetryPolicy(
            maxAttempts = retryJson?.optInt("maxAttempts", 2) ?: 2,
            backoffBaseMillis = retryJson?.optLong("backoffBaseMillis", 800L) ?: 800L,
            backoffCapMillis = retryJson?.optLong("backoffCapMillis", 15_000L) ?: 15_000L,
        ),
        requiresVerification = json.optBoolean("requiresVerification", true),
        mutating = json.optBoolean("mutating", false),
        status = MissionTaskStatus.fromStorage(json.optString("status")),
        attemptsUsed = json.optInt("attemptsUsed", 0).coerceAtLeast(0),
        resultSummary = json.optString("resultSummary"),
        resultJson = json.optString("resultJson"),
        error = json.optString("error"),
        errorCategory = json.optString("errorCategory"),
        startedAtMillis = if (json.isNull("startedAtMillis")) null else json.optLong("startedAtMillis"),
        completedAtMillis = if (json.isNull("completedAtMillis")) null else json.optLong("completedAtMillis"),
        executedWithTool = json.optString("executedWithTool"),
    )
}

fun ArixMission.toJson(): JSONObject = JSONObject().apply {
    put("schemaVersion", ArixMissionPersistence.SchemaVersion)
    put("missionId", missionId)
    put("objective", objective)
    put("projectId", projectId)
    put("sessionId", sessionId)
    put("plan", JSONArray(plan.map { it.toJson() }))
    put("status", status.storageValue)
    put("currentStep", currentStep)
    put("progress", progress.toDouble())
    put("understanding", understanding)
    put("replanCycles", replanCycles)
    put("totalTaskExecutions", totalTaskExecutions)
    put("activeTools", JSONArray(activeTools))
    put("checkpoints", JSONArray(checkpoints.map { checkpoint ->
        JSONObject()
            .put("checkpointId", checkpoint.checkpointId)
            .put("atMillis", checkpoint.atMillis)
            .put("phase", checkpoint.phase)
            .put("detail", checkpoint.detail)
    }))
    put("startedAtMillis", startedAtMillis)
    put("updatedAtMillis", updatedAtMillis)
    put("globalTimeoutMillis", globalTimeoutMillis)
    put("maxConcurrency", maxConcurrency)
    put("requireApproval", requireApproval)
    put("finalResult", finalResult)
    put("error", error)
    put("errorCategory", errorCategory)
}

fun parseArixMission(json: JSONObject): ArixMission? {
    val missionId = json.optString("missionId").trim()
    val objective = json.optString("objective").trim()
    if (missionId.isEmpty() || objective.isEmpty()) return null
    val planArray = json.optJSONArray("plan") ?: JSONArray()
    val plan = buildList {
        for (index in 0 until planArray.length()) {
            planArray.optJSONObject(index)?.let { taskJson ->
                parseMissionTask(taskJson)?.let(::add)
            }
        }
    }
    val checkpointsArray = json.optJSONArray("checkpoints") ?: JSONArray()
    val checkpoints = buildList {
        for (index in 0 until checkpointsArray.length()) {
            val cp = checkpointsArray.optJSONObject(index) ?: continue
            add(
                MissionCheckpoint(
                    checkpointId = cp.optString("checkpointId"),
                    atMillis = cp.optLong("atMillis"),
                    phase = cp.optString("phase"),
                    detail = cp.optString("detail"),
                ),
            )
        }
    }
    return ArixMission(
        missionId = missionId,
        objective = objective,
        projectId = json.optString("projectId"),
        sessionId = json.optString("sessionId"),
        plan = plan,
        status = MissionStatus.fromStorage(json.optString("status")),
        currentStep = json.optString("currentStep", "understand"),
        progress = json.optDouble("progress", 0.0).toFloat(),
        understanding = json.optString("understanding"),
        replanCycles = json.optInt("replanCycles", 0),
        totalTaskExecutions = json.optInt("totalTaskExecutions", 0),
        activeTools = json.optJSONArray("activeTools")?.let { array ->
            buildList {
                for (index in 0 until array.length()) add(array.optString(index))
            }
        }.orEmpty(),
        checkpoints = checkpoints,
        startedAtMillis = json.optLong("startedAtMillis", System.currentTimeMillis()),
        updatedAtMillis = json.optLong("updatedAtMillis", System.currentTimeMillis()),
        globalTimeoutMillis = json.optLong("globalTimeoutMillis", ArixMissionContract.DEFAULT_GLOBAL_TIMEOUT_MILLIS),
        maxConcurrency = json.optInt("maxConcurrency", ArixMissionContract.DEFAULT_MAX_CONCURRENCY)
            .coerceIn(1, 8),
        requireApproval = json.optBoolean("requireApproval", false),
        finalResult = json.optString("finalResult"),
        error = json.optString("error"),
        errorCategory = json.optString("errorCategory"),
    )
}
