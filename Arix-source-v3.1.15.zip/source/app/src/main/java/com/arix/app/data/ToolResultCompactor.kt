package com.arix.app.data

import org.json.JSONArray
import org.json.JSONObject

object ToolResultCompactor {

    private const val DefaultMaxChars = 8_000

    private const val HeadFraction = 0.45

    private const val JsonStringValueCap = 900

    private val JsonAwareTools = setOf(
        "browser",
        "web_search",
        "fetch_url",
        "web_scrape",
        "arix_swarm",
        "arix_ensure_package",
        "arix_runtime_manage",
        "arix_diagnostics",
        "media_search",
    )

    fun compactModelVisible(
        toolName: String,
        rawOutput: String,
        maxChars: Int = DefaultMaxChars,
    ): String {
        if (rawOutput.length <= maxChars) return rawOutput
        val budget = maxChars.coerceAtLeast(1_000)
        if (toolName in JsonAwareTools) {
            val compactedJson = compactLongJsonValues(rawOutput, JsonStringValueCap)
            if (compactedJson.length <= budget) return compactedJson
        }
        return compactHeadTail(rawOutput, budget)
    }

    fun compactHeadTail(text: String, maxChars: Int): String {
        if (text.length <= maxChars) return text
        val headChars = (maxChars * HeadFraction).toInt().coerceAtLeast(200)
        val tailChars = (maxChars - headChars).coerceAtLeast(200)
        val omitted = text.length - headChars - tailChars
        return buildString {
            append(text.take(headChars))
            append(
                "\n…[compacted: $omitted chars omitted (${omitted * 100 / text.length}% of " +
                    "${text.length}) — head+tail kept; re-run the tool with tighter scope " +
                    "or read the source directly if the middle is needed]…\n",
            )
            append(text.takeLast(tailChars))
        }
    }

    fun compactLongJsonValues(rawOutput: String, valueCap: Int = JsonStringValueCap): String {
        val trimmed = rawOutput.trim()
        if (!trimmed.startsWith("{") && !trimmed.startsWith("[")) return rawOutput
        return runCatching {
            if (trimmed.startsWith("{")) {
                JSONObject(trimmed).also { compactJsonObject(it, valueCap) }.toString()
            } else {
                JSONArray(trimmed).also { compactJsonArray(it, valueCap) }.toString()
            }
        }.getOrDefault(rawOutput)
    }

    private fun compactJsonObject(json: JSONObject, valueCap: Int) {
        for (key in json.keys().asSequence().toList()) {
            when (val value = json.opt(key)) {
                is String -> {
                    if (value.length > valueCap) {
                        json.put(key, capStringValue(value, valueCap))
                    }
                }
                is JSONObject -> compactJsonObject(value, valueCap)
                is JSONArray -> compactJsonArray(value, valueCap)
                else -> Unit
            }
        }
    }

    private fun compactJsonArray(json: JSONArray, valueCap: Int) {
        for (index in 0 until json.length()) {
            when (val value = json.opt(index)) {
                is String -> {
                    if (value.length > valueCap) {
                        json.put(index, capStringValue(value, valueCap))
                    }
                }
                is JSONObject -> compactJsonObject(value, valueCap)
                is JSONArray -> compactJsonArray(value, valueCap)
                else -> Unit
            }
        }
    }

    private fun capStringValue(value: String, valueCap: Int): String {
        if (value.length <= valueCap) return value
        val head = valueCap / 2
        val tail = valueCap - head
        return value.take(head) +
            "…[${value.length - valueCap} chars omitted]…" +
            value.takeLast(tail)
    }
}
