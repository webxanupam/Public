package com.arix.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.arixExtensionStateDataStore by preferencesDataStore(
    name = "arix_extension_state",
)

data class ArixExtensionLoadOptions(
    val disabledExtensionPaths: Set<String> = emptySet(),
    val disabledPackageSources: Set<String> = emptySet(),
) {
    fun toJsonArrays(): Pair<List<String>, List<String>> =
        disabledExtensionPaths.toList() to disabledPackageSources.toList()
}

/**
 * Persists which extensions the user disabled. Extension ids are stable
 * strings in one of three shapes:
 *  - `package:npm:@scope/name` for Pi packages installed from the catalog
 *  - `import:arix:/root/.arix/extensions/<dir>` for imported Arix extensions
 *  - `import:pi:/root/.pi/agent/extensions/<dir>` for imported Pi extensions
 * A bare guest path is also accepted for older records.
 */
class ArixExtensionStateRepository(
    private val context: Context,
) {
    val disabledExtensionIds: Flow<Set<String>> =
        context.arixExtensionStateDataStore.data.map { preferences ->
            (preferences[DISABLED_EXTENSION_IDS] ?: emptySet())
                .map(::normalizeExtensionStateId)
                .toSet()
        }

    suspend fun setEnabled(
        extensionId: String,
        enabled: Boolean,
    ) {
        val normalizedId = extensionId.trim()
        if (normalizedId.isBlank()) return
        val stableId = normalizeExtensionStateId(normalizedId)
        val baseName = stableId.substringAfterLast('/')
        context.arixExtensionStateDataStore.edit { preferences ->
            val disabledIds = (preferences[DISABLED_EXTENSION_IDS] ?: emptySet())
                .mapTo(mutableSetOf(), ::normalizeExtensionStateId)
            if (enabled) {
                disabledIds.remove(stableId)
                disabledIds.removeAll { it.substringAfterLast('/') == baseName }
            } else {
                disabledIds.add(stableId)
            }
            preferences[DISABLED_EXTENSION_IDS] = disabledIds
        }
    }

    suspend fun loadOptions(): ArixExtensionLoadOptions =
        loadOptionsForIds(disabledExtensionIds.first())

    suspend fun replaceDisabledExtensionIds(extensionIds: Set<String>) {
        context.arixExtensionStateDataStore.edit { preferences ->
            preferences[DISABLED_EXTENSION_IDS] = extensionIds
                .map(::normalizeExtensionStateId)
                .filter(String::isNotBlank)
                .toSet()
        }
    }

    private companion object {
        val DISABLED_EXTENSION_IDS = stringSetPreferencesKey("disabled_extension_ids")
    }
}

internal fun loadOptionsForIds(
    disabledExtensionIds: Set<String>,
): ArixExtensionLoadOptions {
    val disabledExtensionPaths = mutableSetOf<String>()
    val disabledPackageSources = mutableSetOf<String>()
    disabledExtensionIds.forEach { rawId ->
        val id = rawId.trim()
        when {
            id.startsWith("package:") -> {
                id.removePrefix("package:")
                    .trim()
                    .takeIf(String::isNotBlank)
                    ?.let(disabledPackageSources::add)
            }

            id.startsWith("import:") -> {
                id.substringAfter(':', "")
                    .substringAfter(':', "")
                    .trim()
                    .takeIf(String::isNotBlank)
                    ?.let(::normalizeImportedExtensionPath)
                    ?.let(disabledExtensionPaths::add)
            }

            id.startsWith("/") -> {
                disabledExtensionPaths.add(normalizeImportedExtensionPath(id))
            }
        }
    }
    return ArixExtensionLoadOptions(
        disabledExtensionPaths = disabledExtensionPaths,
        disabledPackageSources = disabledPackageSources,
    )
}

internal fun normalizeExtensionStateId(rawId: String): String {
    val id = rawId.trim()
    if (!id.startsWith("import:")) return id
    val scope = id.substringAfter(':', "").substringBefore(':', "").trim()
    val importedPath = id.substringAfter(':', "").substringAfter(':', "").trim()
    if (scope.isBlank() || importedPath.isBlank()) return id
    return "import:$scope:${normalizeImportedExtensionPath(importedPath)}"
}

internal fun normalizeImportedExtensionPath(rawPath: String): String {
    val path = rawPath.trim()
    val guestRoots = listOf(
        ArixExtensionGuestDirectory,
        PiUserExtensionGuestDirectory,
    )
    guestRoots.forEach { guestRoot ->
        val rootIndex = path.lastIndexOf(guestRoot)
        if (rootIndex >= 0) return path.substring(rootIndex)
    }
    return path
}

/** Guest directory for Arix-imported extensions inside the Termux root. */
const val ArixExtensionGuestDirectory = "/root/.arix/extensions"

/** Standard Pi agent extension directory (shared with Pi packages). */
const val PiUserExtensionGuestDirectory = "/root/.pi/agent/extensions"
