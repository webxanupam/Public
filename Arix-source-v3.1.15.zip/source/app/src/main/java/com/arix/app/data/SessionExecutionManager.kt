package com.arix.app.data

import android.app.Application
import android.os.SystemClock
import com.arix.app.ArixForegroundService
import com.arix.app.ArixNotificationController
import com.arix.app.AppForegroundTracker
import com.arix.app.runtime.RuntimeRouter
import com.arix.app.runtime.RuntimeShellTool
import com.arix.app.data.pi.PiAgentRunner
import com.arix.app.data.pi.PiCompletionClient
import com.arix.app.data.pi.PiKernelBridge
import com.arix.app.ui.AttachmentKind
import com.arix.app.ui.AssistantResponseBlock
import com.arix.app.ui.ChatAttachment
import com.arix.app.ui.ChatMessage
import com.arix.app.ui.ChatSession
import com.arix.app.ui.ChatToolInvocation
import com.arix.app.ui.ChatUsageStatistics
import com.arix.app.ui.MessageDisplayKind
import com.arix.app.ui.MessageAuthor
import com.arix.app.ui.ReasoningSummaryChunk
import com.arix.app.ui.ReasoningTrace
import com.arix.app.ui.sanitizedForReasoningOff
import com.arix.app.ui.withAssistantFinalTextFallback
import com.arix.app.data.chatdb.ChatAgentSessionEntity
import com.arix.app.ui.syncActiveBranches
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

private const val AssistantCheckpointIntervalMillis = 1_000L

internal fun completedReconnectStatus(status: String): String {
    val match = Regex("^Reconnecting\\.\\.\\.\\s*(.*)$", RegexOption.IGNORE_CASE).matchEntire(status.trim())
        ?: return status
    return "Reconnected" + match.groupValues[1].takeIf(String::isNotBlank)?.let { " $it" }.orEmpty()
}

internal fun committedInterruptionStatus(status: String): String =
    if (status.startsWith("Reconnecting", ignoreCase = true)) completedReconnectStatus(status) else ""

internal fun completePendingReconnectBlocks(
    blocks: List<AssistantResponseBlock>,
): List<AssistantResponseBlock> = blocks.map { block ->
    if (block is AssistantResponseBlock.Status &&
        block.text.startsWith("Reconnecting", ignoreCase = true)
    ) {
        block.copy(text = completedReconnectStatus(block.text))
    } else {
        block
    }
}

enum class SessionFollowUpMode {
    Queue,
    Steer,
}

enum class SessionTurnOutcome {
    Success,
    ValidationError,
    Failure,
    Neutral,
}

data class PendingSessionInput(
    val id: String,
    val mode: SessionFollowUpMode,
    val preview: String,
    val attachmentCount: Int,
)

data class SessionExecutionState(
    val sessionId: String,
    val isRunning: Boolean = false,
    val pendingToolInvocations: List<ChatToolInvocation> = emptyList(),
    val pendingResponseBlocks: List<AssistantResponseBlock> = emptyList(),
    val pendingAssistantText: String = "",
    val pendingStatusText: String = "",
    val pendingStatusDetail: String = "",
    val pendingInputs: List<PendingSessionInput> = emptyList(),
    val activeResponseGroupId: String? = null,
    val activeTurnStartedAtMillis: Long? = null,
    val reasoningPhase: ArixReasoningPhase = ArixReasoningPhase.IDLE,
)

data class SessionTurnRequest(
    val sessionId: String,
    val settings: AppSettings,
    val requestMessages: List<ChatMessage>,
    val selectedSkillIds: List<String>,
    val activeSkills: List<ActiveSkillContext>,
    val providerConfigs: List<LlmProviderConfig> = emptyList(),
    val turnContextBlock: String? = null,
)

data class SessionTurnEvent(
    val sessionId: String,
    val outcome: SessionTurnOutcome,
    val toolCallCount: Int = 0,
    val distinctToolCount: Int = 0,
    val toolNames: List<String> = emptyList(),
    val durationMillis: Long? = null,
    val tokenUsage: LlmTokenUsage? = null,
    val tokenUsageSource: String = "unavailable",
    val inputMessageCount: Int = 0,
    val userMessageCount: Int = 0,
)

private enum class ReasoningCompletionTrigger {
    BodyStarted,
    TurnFinished,
}

private data class AssistantResponseIdentity(
    val responseGroupId: String,
    val messageIdPrefix: String,
    val createdAtMillis: Long,
    val checkpointFromPosition: Int,
) {
    fun messageIdFor(blockId: String): String = "$messageIdPrefix-$blockId"
}

class SessionExecutionManager(
    private val application: Application,
    private val scope: CoroutineScope,
    private val settingsRepository: SettingsRepository,
    private val extensionsRepository: AgentExtensionsRepository,
    private val chatStateStore: ChatStateStore,
    private val chatRepository: ChatRepository,
    private val runtimeRouter: RuntimeRouter,
    private val workspaceFileBridge: WorkspaceFileBridge,
    private val skillManager: AgentSkillManager,
    private val scheduledTaskManager: ScheduledTaskManager,
    private val notificationController: ArixNotificationController,
    private val appForegroundTracker: AppForegroundTracker,
    private val diagnosticLogger: ArixDiagnosticLogger = ArixDiagnosticLogger.NoOp,
    private val piCompletionClient: PiCompletionClient? = null,
    private val piKernelBridge: PiKernelBridge,
    private val piAgentRunner: PiAgentRunner,
    private val missionEngine: com.arix.app.mission.ArixMissionEngine? = null,
    private val swarmManager: ArixSwarmManager? = null,
) {
    private val skillRuntimeMirror = SkillRuntimeMirror(runtimeRouter)
    private val aiBrain by lazy { ArixAiBrain(skillManager, diagnosticLogger) }
    private val currentSettings = MutableStateFlow(AppSettings())
    private val currentProviderConfigs = MutableStateFlow<List<LlmProviderConfig>>(emptyList())
    private val currentExtensionsState = MutableStateFlow(AgentExtensionsState())
    private val _executionStates = MutableStateFlow<Map<String, SessionExecutionState>>(emptyMap())
    private val _turnEvents = MutableSharedFlow<SessionTurnEvent>(extraBufferCapacity = 8)
    private val executionHandles = ConcurrentHashMap<String, SessionExecutionHandle>()
    private val queuedTurnRequestBuilder = QueuedTurnRequestBuilder(chatStateStore)

    private val continuationDepths = ConcurrentHashMap<String, Int>()
    private val continuationJobs = ConcurrentHashMap<String, kotlinx.coroutines.Job>()

    val executionStates: StateFlow<Map<String, SessionExecutionState>> = _executionStates.asStateFlow()
    val turnEvents = _turnEvents.asSharedFlow()

    init {
        scope.launch {
            settingsRepository.settings.collect { settings ->
                currentSettings.value = settings
                if (
                    settings.keepTasksRunningInBackground &&
                    _executionStates.value.values.any { it.isRunning }
                ) {
                    ensureForegroundServiceRunning()
                }
            }
        }
        scope.launch {
            extensionsRepository.extensionState.collect { currentExtensionsState.value = it }
        }
        scope.launch {
            settingsRepository.providerConfigs.collect { currentProviderConfigs.value = it }
        }
        swarmManager?.let { swarm ->
            scope.launch {
                swarm.subAgentActivity.collect { activity ->
                    routeSubAgentActivity(activity)
                }
            }
        }
        missionEngine?.let { engine ->
            scope.launch {
                engine.events.collect { event ->
                    routeMissionTimelineEvent(event)
                }
            }
        }
    }

    fun isSessionRunning(sessionId: String): Boolean =
        _executionStates.value[sessionId]?.isRunning == true

    fun startTurn(request: SessionTurnRequest) {
        val handle = SessionExecutionHandle(sessionId = request.sessionId)
        handle.replaceRetainedMessages(request.requestMessages)
        if (executionHandles.putIfAbsent(request.sessionId, handle) != null) return

        val isContinuationTurn = request.requestMessages.lastOrNull()
            ?.id?.startsWith("ckpt-continue-") == true
        if (!isContinuationTurn) {
            resetContinuationBudget(request.sessionId)
        } else {
            continuationJobs.remove(request.sessionId)?.cancel()
        }

        val validationError = validateRequest(request)
        if (validationError != null) {
            diagnosticLogger.event(
                category = "session",
                event = "turn_validation_failed",
                level = "warn",
                sessionId = request.sessionId,
                details = mapOf("message" to validationError),
            )
            executionHandles.remove(request.sessionId, handle)
            val completion = appendAgentMessage(
                sessionId = request.sessionId,
                blocks = listOf(
                    AssistantResponseBlock.Text(
                        id = "agent-validation-${System.currentTimeMillis()}",
                        text = validationError,
                    )
                ),
                thoughtDurationMillis = null,
                outcome = SessionTurnOutcome.ValidationError,
                baseMessages = request.requestMessages,
            )
            _turnEvents.tryEmit(completion.toTurnEvent(request.sessionId))
            return
        }

        updateExecutionState(request.sessionId) {
            it.copy(
                sessionId = request.sessionId,
                isRunning = true,
                pendingToolInvocations = emptyList(),
                pendingResponseBlocks = emptyList(),
                pendingAssistantText = "",
                pendingStatusText = "",
                pendingStatusDetail = "",
                activeResponseGroupId = null,
                activeTurnStartedAtMillis = System.currentTimeMillis(),
            )
        }
        diagnosticLogger.event(
            category = "session",
            event = "turn_queued",
            sessionId = request.sessionId,
            details = mapOf(
                "provider" to request.settings.piProviderId,
                "model" to request.settings.modelId,
                "base_url" to DiagnosticRedactor.sanitizedBaseUrl(request.settings.baseUrl),
                "request_message_count" to request.requestMessages.size,
                "selected_skill_count" to request.selectedSkillIds.size,
            ),
        )

        handle.job = scope.launch {
            runSession(
                handle = handle,
                initialRequest = request,
            )
        }
        handle.job?.invokeOnCompletion { cause ->
            if (cause != null) {
                swarmManager?.stopForSession(request.sessionId)
            }
        }
    }

    fun submitFollowUp(
        sessionId: String,
        message: ChatMessage,
        mode: SessionFollowUpMode,
    ): Boolean {
        val handle = executionHandles[sessionId] ?: return false
        val pending = PendingEnvelope(
            id = "pending-${System.currentTimeMillis()}-${message.id}",
            mode = mode,
            message = message,
        )
        synchronized(handle.lock) {
            when (mode) {
                SessionFollowUpMode.Queue -> handle.queuedInputs += pending
                SessionFollowUpMode.Steer -> handle.steerInputs += pending
            }
        }
        updateExecutionState(sessionId) { current ->
            current.copy(
                pendingInputs = current.pendingInputs + pending.toUiState()
            )
        }
        return true
    }

    fun pauseSession(sessionId: String): ChatSession? {
        val handle = executionHandles[sessionId] ?: return null
        if (handle.pauseRequested) return null
        handle.pauseRequested = true
        val snapshot = _executionStates.value[sessionId]
        val runningRunIds = snapshot?.pendingToolInvocations?.let(::extractActiveManagedRunIds).orEmpty()
        val completion = finalizePausedTurn(
            handle = handle,
            snapshot = snapshot ?: SessionExecutionState(sessionId = sessionId),
        )
        deactivateAssistantCheckpoint(handle, handle.activeResponseIdentity)
        scope.launch(Dispatchers.IO) {
            runCatching { chatStateStore.flush() }
        }
        handle.pauseFinalized = true
        executionHandles.remove(sessionId, handle)
        runCatching { com.arix.app.companion.ArixMochiBus.noteTurnSettled() }
        updateExecutionState(sessionId) {
            it.copy(
                sessionId = sessionId,
                isRunning = false,
                pendingToolInvocations = emptyList(),
                pendingResponseBlocks = emptyList(),
                pendingAssistantText = "",
                pendingStatusText = "",
                pendingStatusDetail = "",
                pendingInputs = emptyList(),
                activeResponseGroupId = null,
                activeTurnStartedAtMillis = null,
            )
        }
        _turnEvents.tryEmit(completion.toTurnEvent(sessionId))
        handle.job?.cancel(CancellationException("Paused by user."))
        if (runningRunIds.isNotEmpty()) {
            scope.launch(Dispatchers.IO) {
                val shellTool = RuntimeShellTool(runtimeRouter)
                runningRunIds.forEach { runId ->
                    runCatching { shellTool.killByRunId(runId) }
                }
            }
        }
        runCatching {
            com.arix.app.browser.ArixBrowserMemory.onSessionCancelled(application)
        }
        return chatStateStore.state.value.sessions.firstOrNull { it.id == sessionId }
    }

    suspend fun startScheduledTask(task: ScheduledTask): Boolean {
        if (!task.isEnabled || task.prompt.isBlank()) return false
        if (task.isMultiStep && missionEngine != null) {
            val engine = missionEngine
            val objective = buildMultiStepAutomationObjective(task)
            val started = runCatching {
                engine.startMission(
                    objective = objective,
                    options = com.arix.app.mission.ArixMissionEngine.MissionOptions(
                        projectId = task.projectId,
                        sessionId = task.defaultSessionId(),
                        requireApproval = false,
                    ),
                )
            }.getOrNull()
            return started?.optBoolean("ok", false) == true
        }
        val settings = settingsRepository.settings.first()
        val providerConfigs = settingsRepository.providerConfigs.first()
        val sessionId = task.defaultSessionId()
        val now = System.currentTimeMillis()
        val userMessage = ChatMessage(
            id = "scheduled-${task.id.take(8)}-$now",
            author = MessageAuthor.User,
            text = task.prompt,
            createdAtMillis = now,
        )

        if (isSessionRunning(sessionId)) {
            return submitFollowUp(
                sessionId = sessionId,
                message = userMessage,
                mode = SessionFollowUpMode.Queue,
            )
        }

        var selectedModelKey = ""
        var requestMessages: List<ChatMessage> = emptyList()
        var selectedSkillIds: List<String> = emptyList()
        var activeSkills: List<ActiveSkillContext> = emptyList()

        val persistedSessionWithMessages = chatRepository.getSessionWithMessages(sessionId)

        chatStateStore.updateAndFlush { persisted ->
            val updatedSessions = persisted.sessions.toMutableList()
            val existingIndex = updatedSessions.indexOfFirst { it.id == sessionId }
            val updatedSession = if (existingIndex >= 0) {
                val existing = updatedSessions.removeAt(existingIndex)
                val baseMessages = existing.messages.ifEmpty {
                    persistedSessionWithMessages?.messages.orEmpty()
                }
                existing.withDerivedMessages(baseMessages + userMessage)
            } else {
                ChatSession(
                    id = sessionId,
                    title = task.name.ifBlank { "Scheduled task" },
                    preview = userMessage.summaryText(),
                    hasCustomTitle = true,
                    messages = listOf(userMessage),
                    selectedModelKey = resolveDefaultChatModelKey(settings, providerConfigs),
                )
            }
            selectedModelKey = updatedSession.selectedModelKey
            requestMessages = updatedSession.messages
            selectedSkillIds = updatedSession.selectedSkillIds
            activeSkills = updatedSession.activeSkills
            updatedSessions.add(0, updatedSession)
            persisted.copy(
                sessions = updatedSessions,
                currentSessionId = sessionId,
            )
        }

        startTurn(
            SessionTurnRequest(
                sessionId = sessionId,
                settings = resolveModelSettings(
                    baseSettings = settings,
                    providerConfigs = providerConfigs,
                    preferredModelKey = selectedModelKey,
                    fallbackModelKey = resolveDefaultChatModelKey(settings, providerConfigs),
                ),
                requestMessages = requestMessages,
                selectedSkillIds = selectedSkillIds,
                activeSkills = activeSkills,
                providerConfigs = providerConfigs,
            )
        )
        return true
    }

    private suspend fun runSession(
        handle: SessionExecutionHandle,
        initialRequest: SessionTurnRequest,
    ) {
        var nextRequest: SessionTurnRequest? = initialRequest
        var lastCompletion: CompletionSummary? = null

        try {
            while (nextRequest != null && !handle.pauseRequested) {
                lastCompletion = executeTurn(
                    handle = handle,
                    request = nextRequest,
                )
                if (handle.pauseRequested) break
                promoteRemainingSteersToQueue(handle)
                if (handle.pauseRequested) break

                val nextQueued = pollNextQueuedInput(handle) ?: break
                nextRequest = buildQueuedTurnRequest(
                    handle = handle,
                    queuedInput = nextQueued.message,
                )
            }
        } finally {
            deactivateAssistantCheckpoint(handle, handle.activeResponseIdentity)
            clearPendingInputs(handle)
            runCatching { com.arix.app.browser.ArixBrowserSession.onAgentTaskComplete() }
            if (executionHandles.remove(handle.sessionId, handle)) {
                updateExecutionState(handle.sessionId) {
                    it.copy(
                        sessionId = handle.sessionId,
                        isRunning = false,
                        pendingToolInvocations = emptyList(),
                        pendingResponseBlocks = emptyList(),
                        pendingAssistantText = "",
                        pendingStatusText = "",
                        pendingStatusDetail = "",
                        pendingInputs = emptyList(),
                        activeResponseGroupId = null,
                        activeTurnStartedAtMillis = null,
                        reasoningPhase = when {
                            handle.pauseRequested -> ArixReasoningPhase.CANCELLED
                            lastCompletion?.outcome == SessionTurnOutcome.Failure -> ArixReasoningPhase.ERROR
                            lastCompletion != null -> ArixReasoningPhase.COMPLETE
                            else -> ArixReasoningPhase.IDLE
                        },
                    )
                }
            }

            if (
                !handle.pauseRequested &&
                lastCompletion != null &&
                currentSettings.value.notifyOnTaskCompletion &&
                !appForegroundTracker.isForeground.value
            ) {
                notificationController.notifyCompletion(
                    sessionId = handle.sessionId,
                    sessionTitle = lastCompletion.sessionTitle,
                    summary = lastCompletion.summary,
                    failed = lastCompletion.outcome == SessionTurnOutcome.Failure,
                )
            }
        }
    }

    private data class PreTurnSetup(
        val routedSkills: List<ActiveSkillContext>,
        val mirroredSkillPaths: List<String>,
        val agentSessionMetadata: ChatAgentSessionEntity?,
        val cachedThinkingLevelMaps: Map<String, Map<String, String>>,
        val cachedReasoningModels: Set<String>,
        val cachedThinkingLevels: Map<String, List<String>> = emptyMap(),
        val cachedModelLimits: Map<String, ModelsDevModelLimits> = emptyMap(),
    )

    private suspend fun executeTurn(
        handle: SessionExecutionHandle,
        request: SessionTurnRequest,
    ): CompletionSummary {
        val turnStartedAtMillis = System.currentTimeMillis()
        val turnId = "turn-$turnStartedAtMillis"
        ArixLatencyTracer.record(turnId, ArixLatencyTracer.INPUT_RECEIVED)
        ArixLatencyTracer.record(turnId, ArixLatencyTracer.REQUEST_CREATED)
        ArixLatencyTracer.record(turnId, ArixLatencyTracer.PROVIDER_SELECTED)
        val responseIdentity = activateAssistantResponse(handle)
        updateExecutionState(handle.sessionId) { current ->
            current.copy(
                activeResponseGroupId = responseIdentity.responseGroupId,
                pendingToolInvocations = emptyList(),
                pendingResponseBlocks = emptyList(),
                pendingAssistantText = "",
                pendingStatusText = "",
                pendingStatusDetail = "",
            )
        }
        var firstAssistantTokenAtMillis: Long? = null
        diagnosticLogger.event(
            category = "session",
            event = "turn_start",
            sessionId = handle.sessionId,
            turnId = turnId,
            details = mapOf(
                "session_title" to resolveSessionTitle(handle.sessionId),
                "provider" to request.settings.piProviderId,
                "model" to request.settings.modelId,
                "base_url" to DiagnosticRedactor.sanitizedBaseUrl(request.settings.baseUrl),
            ),
        )
        val selfManagementTool = ArixSelfManagementTool(
            settingsRepository = settingsRepository,
            extensionsRepository = extensionsRepository,
            skillManager = skillManager,
            scheduledTaskManager = scheduledTaskManager,
            piKernelBridge = piKernelBridge,
            sessionId = handle.sessionId,
            diagnosticLogger = diagnosticLogger,
        )

        updateExecutionState(handle.sessionId) {
            it.copy(
                sessionId = handle.sessionId,
                isRunning = true,
                pendingToolInvocations = emptyList(),
                pendingResponseBlocks = emptyList(),
                pendingAssistantText = "",
                pendingStatusText = "",
                pendingStatusDetail = "",
                activeTurnStartedAtMillis = turnStartedAtMillis,
                reasoningPhase = ArixReasoningPhase.THINKING,
            )
        }

        return try {
            val resolvedAvailableSkills = currentExtensionsState.value.installedSkills
                .filter { it.isEnabled }
                .sortedBy { it.name.lowercase() }
            val explicitlySelectedSkills = resolveSelectedActiveSkills(
                selectedSkillIds = request.selectedSkillIds,
            )
            val preTurnSetup = coroutineScope {
                val routedSkillsDeferred = if (explicitlySelectedSkills.isEmpty()) {
                    async {
                        aiBrain.routeSkillsForTurn(
                            settings = request.settings,
                            userText = request.requestMessages.lastOrNull { it.author == MessageAuthor.User }
                                ?.text.orEmpty(),
                            enabledSkills = resolvedAvailableSkills,
                        )
                    }
                } else {
                    null
                }
                val mirroredSkillPathsDeferred = async { skillRuntimeMirror.sync(resolvedAvailableSkills) }
                val agentSessionMetadataDeferred = async {
                    chatRepository.getAgentSessionMetadata(handle.sessionId)
                        ?.takeIf { metadata -> validateAgentSessionFile(metadata.piSessionId, metadata.jsonlPath) }
                }
                val cachedThinkingLevelMapsDeferred = async { settingsRepository.loadThinkingLevelMapsCache() }
                val cachedReasoningModelsDeferred = async { settingsRepository.loadReasoningModelsCache() }
                val cachedThinkingLevelsDeferred = async { settingsRepository.loadThinkingCatalogCache() }
                val cachedModelLimitsDeferred = async { settingsRepository.loadModelLimitsCache() }
                PreTurnSetup(
                    routedSkills = routedSkillsDeferred?.await() ?: emptyList(),
                    mirroredSkillPaths = mirroredSkillPathsDeferred.await(),
                    agentSessionMetadata = agentSessionMetadataDeferred.await(),
                    cachedThinkingLevelMaps = cachedThinkingLevelMapsDeferred.await(),
                    cachedReasoningModels = cachedReasoningModelsDeferred.await(),
                    cachedThinkingLevels = cachedThinkingLevelsDeferred.await(),
                    cachedModelLimits = cachedModelLimitsDeferred.await(),
                )
            }
            val routedSkills = preTurnSetup.routedSkills
            val mirroredSkillPaths = preTurnSetup.mirroredSkillPaths
            val agentSessionMetadata = preTurnSetup.agentSessionMetadata
            val resolvedSkillSelection = resolveTurnSkillSelection(
                explicitActiveSkills = explicitlySelectedSkills,
                implicitActiveSkills = routedSkills,
            )
            val resolvedActiveSkills = resolvedSkillSelection.activeSkills
            updateSessionSelections(
                sessionId = handle.sessionId,
                selectedSkillIds = emptyList(),
                activeSkills = emptyList(),
            )

            val workspaceDirectory = workspaceFileBridge.workspaceDirectory(
                sessionId = handle.sessionId,
                mode = request.settings.agentWorkspaceMode,
            )
            val activeRuntimeId = LocalRuntimeId.fromStorage(agentSessionMetadata?.runtime)
                ?: runtimeRouter.runtimeFor(request.settings, null)?.id
                ?: request.settings.defaultRuntimeId
                ?: LocalRuntimeId.Termux
            val runtimeWorkspaceDirectory = runtimeRouter.runtimeWorkspaceDirectory(
                settings = request.settings,
            )
            val reasoningTraceToolRoutingEnabled = request.settings.supportsVisibleReasoningTrace()
            val emitToolEvent: suspend (AgentToolEvent) -> Unit = { event ->
                if (!handle.pauseRequested) {
                    handleToolEvent(
                        handle = handle,
                        event = event,
                        reasoningTraceToolRoutingEnabled = reasoningTraceToolRoutingEnabled,
                    )
                }
            }

            diagnosticLogger.event(
                category = "session",
                event = "pi_agent_runner_start",
                sessionId = handle.sessionId,
                turnId = turnId,
                details = mapOf(
                    "runtime_id" to activeRuntimeId.storageValue,
                    "workspace_directory" to runtimeWorkspaceDirectory,
                    "session_file" to agentSessionMetadata?.jsonlPath.orEmpty(),
                    "message_count" to request.requestMessages.size,
                ),
            )
            val modelKey = thinkingCatalogKey(request.settings.piProviderId, request.settings.modelId)
            val thinkingLevelMap = preTurnSetup.cachedThinkingLevelMaps[modelKey].orEmpty()
            val isReasoningModel = modelKey in preTurnSetup.cachedReasoningModels
            val modelsDevThinkingLevels = preTurnSetup.cachedThinkingLevels[modelKey]
            val modelsDevLimits = preTurnSetup.cachedModelLimits[modelKey]

            val streamingTextBuffer = StreamingTextDeltaBuffer(
                flush = { bufferedDelta ->
                    ArixLatencyTracer.record(turnId, ArixLatencyTracer.FIRST_VISIBLE_UPDATE)
                    val newTextBlockId = handle.nextPendingBlockId("pending-text")
                    updateExecutionState(handle.sessionId) { current ->
                        val pendingResponseBlocks = appendAssistantResponseText(
                            blocks = completePendingReconnectBlocks(current.pendingResponseBlocks),
                            delta = bufferedDelta,
                        ) { newTextBlockId }
                        current.copy(
                            pendingStatusText = "",
                            pendingStatusDetail = "",
                            pendingAssistantText = pendingTrailingAssistantText(pendingResponseBlocks),
                            pendingResponseBlocks = pendingResponseBlocks,
                        )
                    }
                },
            )

            var mochiNotedThinking = false
            runCatching { com.arix.app.companion.ArixMochiBus.noteProcessingStarted() }
            val result = piAgentRunner.runTurn(
                settings = request.settings,
                messages = buildRequestMessages(
                    messages = request.requestMessages,
                    settings = request.settings,
                    turnContextBlock = request.turnContextBlock,
                ),
                workspaceDirectory = runtimeWorkspaceDirectory,
                skillPaths = mirroredSkillPaths,
                activeSkills = resolvedActiveSkills,
                selfManagementTool = selfManagementTool,
                sessionId = handle.sessionId,
                sessionFile = agentSessionMetadata?.jsonlPath.orEmpty(),
                runtimeId = activeRuntimeId,
                thinkingLevelMap = thinkingLevelMap,
                isReasoningModel = isReasoningModel,
                modelsDevThinkingLevels = modelsDevThinkingLevels,
                modelsDevLimits = modelsDevLimits,
                onToolEvent = emitToolEvent,
                onToolProgress = emitToolEvent,
                onAssistantReasoningDelta = { delta ->
                    if (handle.pauseRequested) return@runTurn
                    if (delta.isEmpty()) return@runTurn
                    if (!mochiNotedThinking) {
                        mochiNotedThinking = true
                        runCatching { com.arix.app.companion.ArixMochiBus.noteThinkingStarted() }
                    }
                    transitionReasoningPhase(handle, ArixReasoningPhase.THINKING)
                    handle.finishDirectReasoningSummaryChunk()
                    appendReasoningDelta(
                        handle = handle,
                        delta = delta,
                    )
                },
                onAssistantReasoningSummaryDelta = { delta ->
                    if (handle.pauseRequested) return@runTurn
                    if (delta.isEmpty()) return@runTurn
                    if (!mochiNotedThinking) {
                        mochiNotedThinking = true
                        runCatching { com.arix.app.companion.ArixMochiBus.noteThinkingStarted() }
                    }
                    transitionReasoningPhase(handle, ArixReasoningPhase.THINKING)
                    appendDirectReasoningSummaryDelta(
                        handle = handle,
                        delta = delta,
                    )
                },
                onAssistantTextDelta = { delta ->
                    if (handle.pauseRequested) return@runTurn
                    if (delta.isEmpty()) return@runTurn
                    if (firstAssistantTokenAtMillis == null) {
                        firstAssistantTokenAtMillis = System.currentTimeMillis()
                        ArixLatencyTracer.record(turnId, ArixLatencyTracer.FIRST_TOKEN)
                        runCatching { com.arix.app.companion.ArixMochiBus.noteGeneratingStarted() }
                    }
                    handle.finishDirectReasoningSummaryChunk()
                    completeActiveReasoning(
                        handle = handle,
                        trigger = ReasoningCompletionTrigger.BodyStarted,
                    )
                    transitionReasoningPhase(handle, ArixReasoningPhase.FINALIZING)
                    runCatching { com.arix.app.companion.ArixMochiBus.noteSpeechChunk(delta.length) }
                    streamingTextBuffer.append(delta)
                },
                onAssistantTextReset = {
                    if (handle.pauseRequested) return@runTurn
                    streamingTextBuffer.flushNow()
                    updateExecutionState(handle.sessionId) { current ->
                        if (current.pendingAssistantText.isEmpty()) {
                            current
                        } else {
                            current.copy(pendingAssistantText = "")
                        }
                    }
                },
                onAssistantResponseReset = {
                    if (!handle.pauseRequested) {
                        handle.finishDirectReasoningSummaryChunk()
                        completeActiveReasoning(
                            handle = handle,
                            trigger = ReasoningCompletionTrigger.BodyStarted,
                        )
                    }
                },
                onStreamingStatus = { status ->
                    val isStatusReset = status == null || status.text.isBlank()
                    if (handle.pauseRequested && !isStatusReset) return@runTurn
                    if (status?.text?.startsWith("Reconnecting", ignoreCase = true) == true) {
                        completeActiveReasoning(
                            handle = handle,
                            trigger = ReasoningCompletionTrigger.BodyStarted,
                        )
                    }
                    val newStatusBlockId = handle.nextPendingBlockId("pending-status")
                    updateExecutionState(handle.sessionId) { current ->
                        val text = status?.text.orEmpty()
                        if (text.startsWith("Reconnecting", ignoreCase = true)) {
                            val last = current.pendingResponseBlocks.lastOrNull()
                            val blocks = if (last is AssistantResponseBlock.Status &&
                                last.text.startsWith("Reconnecting", ignoreCase = true)
                            ) {
                                current.pendingResponseBlocks.dropLast(1) + last.copy(
                                    text = text,
                                    detail = status?.detail.orEmpty(),
                                )
                            } else {
                                current.pendingResponseBlocks + AssistantResponseBlock.Status(
                                    id = newStatusBlockId,
                                    text = text,
                                    detail = status?.detail.orEmpty(),
                                )
                            }
                            current.copy(
                                pendingResponseBlocks = blocks,
                                pendingStatusText = "",
                                pendingStatusDetail = "",
                            )
                        } else {
                            current.copy(
                                pendingResponseBlocks = completePendingReconnectBlocks(current.pendingResponseBlocks),
                                pendingStatusText = text,
                                pendingStatusDetail = status?.detail.orEmpty(),
                            )
                        }
                    }
                },
                pollInjectedUserMessages = {
                    if (handle.pauseRequested) return@runTurn emptyList()
                    val drained = drainSteerInputs(handle)
                    if (drained.isNotEmpty()) {
                        appendSteerInterruptionMessages(handle, drained)
                    }
                    drained.map { buildSteerRequestMessage(it.message, request.settings) }
                },
            )
            diagnosticLogger.event(
                category = "session",
                event = "pi_agent_runner_end",
                sessionId = handle.sessionId,
                turnId = turnId,
                details = mapOf(
                    "success" to result.isSuccess,
                    "error" to (result.exceptionOrNull()?.message ?: ""),
                ),
            )
            if (handle.pauseRequested) {
                return finalizePausedTurn(
                    handle = handle,
                    snapshot = _executionStates.value[handle.sessionId] ?: SessionExecutionState(sessionId = handle.sessionId),
                )
            }

            completeActiveReasoning(
                handle = handle,
                trigger = ReasoningCompletionTrigger.TurnFinished,
            )
            val thoughtDurationMillis = (System.currentTimeMillis() - turnStartedAtMillis).coerceAtLeast(0L)
            val turnCompletedAtMillis = System.currentTimeMillis()
            val estimatedTokenUsage = estimateRequestTokenUsage(request)
            streamingTextBuffer.flushNow()
            ArixLatencyTracer.record(turnId, ArixLatencyTracer.FINAL_TOKEN)
            val completion = result.fold(
                onSuccess = { turnResult ->
                    val estimatedOutputTokens = approximateReasoningTokenCount(turnResult.assistantText).toLong()
                    val resolvedTokenUsage = turnResult.tokenUsage ?: estimatedTokenUsage.copy(
                        outputTokens = estimatedOutputTokens,
                        totalTokens = (estimatedTokenUsage.totalTokens ?: 0L) + estimatedOutputTokens,
                    )
                    val responseBlocks = currentAssistantResponseBlocks(handle.sessionId).let { blocks ->
                        if (request.settings.reasoningEffort == "off" && blocks.none {
                                it is AssistantResponseBlock.Reasoning &&
                                    (it.trace.rawText.isNotBlank() || it.trace.chunks.isNotEmpty())
                            }) blocks.sanitizedForReasoningOff() else blocks
                    }
                    val visibleThoughtDurationMillis = thoughtDurationMillis.takeIf {
                        request.settings.reasoningEffort != "off"
                    }
                    diagnosticLogger.event(
                        category = "session",
                        event = "turn_model_success",
                        sessionId = handle.sessionId,
                        turnId = turnId,
                        details = mapOf(
                            "reply_chars" to turnResult.assistantText.length,
                            "duration_millis" to thoughtDurationMillis,
                        ),
                    )
                    appendAgentMessage(
                        sessionId = handle.sessionId,
                        blocks = ensureAssistantResponseFinalText(
                            blocks = responseBlocks,
                            finalText = turnResult.assistantText,
                        ) { handle.nextPendingBlockId("agent-text") },
                        thoughtDurationMillis = visibleThoughtDurationMillis,
                        outcome = SessionTurnOutcome.Success,
                        tokenUsage = resolvedTokenUsage,
                        tokenUsageSource = if (turnResult.tokenUsage != null) "api" else "estimated",
                        turnStartedAtMillis = turnStartedAtMillis,
                        firstTokenAtMillis = firstAssistantTokenAtMillis,
                        turnCompletedAtMillis = turnCompletedAtMillis,
                        inputMessageCount = request.requestMessages.size,
                        userMessageCount = request.requestMessages.count { it.author == MessageAuthor.User },
                        providerPayloadJson = turnResult.providerPayloadJson,
                        handle = handle,
                    ).copy(
                        piSessionId = turnResult.piSessionId,
                        piSessionFile = turnResult.piSessionFile,
                        piRuntime = turnResult.runtime,
                        piEntryIds = turnResult.piEntryIds,
                    )
                },
                onFailure = { throwable ->
                    updateExecutionState(handle.sessionId) { current ->
                        current.copy(
                            pendingStatusText = "",
                            pendingStatusDetail = "",
                            pendingResponseBlocks = completePendingReconnectBlocks(current.pendingResponseBlocks),
                        )
                    }
                    val responseBlocks = currentAssistantResponseBlocks(handle.sessionId).let { blocks ->
                        if (request.settings.reasoningEffort == "off" && blocks.none {
                                it is AssistantResponseBlock.Reasoning &&
                                    (it.trace.rawText.isNotBlank() || it.trace.chunks.isNotEmpty())
                            }) blocks.sanitizedForReasoningOff() else blocks
                    }
                    val checkpointCandidate = responseBlocks
                        .mapNotNull { (it as? AssistantResponseBlock.Text)?.text }
                        .joinToString("\n\n")
                        .trim()
                    val willAutoContinue = isRetryableFailure(throwable) &&
                        checkpointCandidate.length >= MinCheckpointChars &&
                        (continuationDepths[handle.sessionId] ?: 0) < MaxAutoContinuations &&
                        !handle.pauseRequested
                    val visibleThoughtDurationMillis = thoughtDurationMillis.takeIf {
                        request.settings.reasoningEffort != "off"
                    }
                    diagnosticLogger.exception(
                        category = "session",
                        event = "turn_model_failed",
                        sessionId = handle.sessionId,
                        turnId = turnId,
                        throwable = throwable,
                        details = mapOf("duration_millis" to thoughtDurationMillis),
                    )
                    appendAgentMessage(
                        sessionId = handle.sessionId,
                        blocks = appendAssistantResponseText(
                            blocks = responseBlocks,
                            delta = buildString {
                                if (responseBlocks.lastOrNull() is AssistantResponseBlock.Text) {
                                    append("\n\n")
                                }
                                append("Request failed: ${formatFailureMessage(throwable)}")
                                if (willAutoContinue) {
                                    append(
                                        "\n\n(Checkpoint saved — Arix is continuing automatically " +
                                            "from exactly where it stopped, attempt " +
                                            "${(continuationDepths[handle.sessionId] ?: 0) + 1}/$MaxAutoContinuations.)",
                                    )
                                }
                            },
                        ) { handle.nextPendingBlockId("agent-text") },
                        thoughtDurationMillis = visibleThoughtDurationMillis,
                        outcome = SessionTurnOutcome.Failure,
                        tokenUsage = estimatedTokenUsage,
                        tokenUsageSource = "estimated",
                        turnStartedAtMillis = turnStartedAtMillis,
                        firstTokenAtMillis = firstAssistantTokenAtMillis,
                        turnCompletedAtMillis = System.currentTimeMillis(),
                        inputMessageCount = request.requestMessages.size,
                        userMessageCount = request.requestMessages.count { it.author == MessageAuthor.User },
                        handle = handle,
                    ).also {
                        if (willAutoContinue) {
                            scheduleCheckpointContinuation(
                                sessionId = handle.sessionId,
                                delayMillis = if (isQuotaExhaustionFailure(throwable.message.orEmpty())) {
                                    QuotaContinuationDelayMillis
                                } else {
                                    StreamContinuationDelayMillis
                                },
                            )
                        }
                    }
                },
            )
            chatStateStore.flush()
            if (completion.piSessionId.isNotBlank() && completion.piSessionFile.isNotBlank()) {
                chatRepository.upsertAgentSessionMetadata(
                    chatSessionId = handle.sessionId,
                    piSessionId = completion.piSessionId,
                    jsonlPath = completion.piSessionFile,
                    runtime = completion.piRuntime,
                )
                chatRepository.upsertAgentMessageRefs(
                    chatSessionId = handle.sessionId,
                    arixMessageIds = completion.appendedMessageIds,
                    piEntryIds = completion.piEntryIds,
                )
            }
            _turnEvents.tryEmit(completion.toTurnEvent(handle.sessionId))
            runCatching {
                when (completion.outcome) {
                    SessionTurnOutcome.Success ->
                        com.arix.app.companion.ArixMochiBus.noteHappy()
                    SessionTurnOutcome.Failure -> {
                        val msg = completion.lastAssistantText
                        if (msg.contains("429", ignoreCase = true) ||
                            msg.contains("rate limit", ignoreCase = true) ||
                            msg.contains("rate_limit", ignoreCase = true)
                        ) {
                            com.arix.app.companion.ArixMochiBus.noteRateLimited()
                        } else {
                            com.arix.app.companion.ArixMochiBus.noteError()
                        }
                    }
                    SessionTurnOutcome.ValidationError ->
                        com.arix.app.companion.ArixMochiBus.noteError()
                    SessionTurnOutcome.Neutral ->
                        com.arix.app.companion.ArixMochiBus.noteTurnSettled()
                }
            }
            diagnosticLogger.event(
                category = "session",
                event = "turn_end",
                sessionId = handle.sessionId,
                turnId = turnId,
                level = if (completion.outcome == SessionTurnOutcome.Failure) "warn" else "info",
                details = mapOf(
                    "outcome" to completion.outcome.name,
                    "tool_call_count" to completion.toolCallCount,
                    "distinct_tool_count" to completion.distinctToolCount,
                    "duration_millis" to completion.durationMillis,
                ),
            )
            completion
        } catch (_: CancellationException) {
            diagnosticLogger.event(
                category = "session",
                event = "turn_cancelled",
                level = "warn",
                sessionId = handle.sessionId,
                turnId = turnId,
                details = mapOf("pause_finalized" to handle.pauseFinalized),
            )
            clearPendingInputs(handle)
            val completion = if (handle.pauseFinalized) {
                CompletionSummary(
                    sessionTitle = resolveSessionTitle(handle.sessionId),
                    summary = "",
                    outcome = SessionTurnOutcome.Neutral,
                    toolCallCount = 0,
                    distinctToolCount = 0,
                    toolNames = emptyList(),
                    durationMillis = null,
                )
            } else {
                finalizePausedTurn(
                    handle = handle,
                    snapshot = _executionStates.value[handle.sessionId] ?: SessionExecutionState(sessionId = handle.sessionId),
                )
            }
            if (!handle.pauseFinalized) {
                chatStateStore.flush()
                handle.pauseFinalized = true
                _turnEvents.tryEmit(completion.toTurnEvent(handle.sessionId))
            }
            completion
        } finally {
            if (executionHandles[handle.sessionId] === handle) {
                updateExecutionState(handle.sessionId) { current ->
                    current.copy(
                        pendingToolInvocations = emptyList(),
                        pendingResponseBlocks = emptyList(),
                        pendingAssistantText = "",
                        pendingStatusText = "",
                        pendingStatusDetail = "",
                        activeResponseGroupId = null,
                        activeTurnStartedAtMillis = null,
                    )
                }
            }
        }
    }

    private suspend fun validateAgentSessionFile(
        expectedSessionId: String,
        sessionFile: String,
    ): Boolean {
        if (expectedSessionId.isBlank() || sessionFile.isBlank()) return false
        val termux = runtimeRouter.runtimeById(LocalRuntimeId.Termux)
            as? com.arix.app.runtime.TermuxRuntime ?: return false
        val headerLine = runCatching {
            termux.readGuestFileFirstLine(sessionFile)
        }.getOrNull() ?: return false
        val header = runCatching { JSONObject(headerLine) }.getOrNull() ?: return false
        return header.optString("type") == "session" && header.optString("id") == expectedSessionId
    }

    private fun buildQueuedTurnRequest(
        handle: SessionExecutionHandle,
        queuedInput: ChatMessage,
    ): SessionTurnRequest? {
        val request = queuedTurnRequestBuilder.build(
            sessionId = handle.sessionId,
            queuedInput = queuedInput,
            baseMessages = handle.retainedMessagesSnapshot(),
            baseSettings = currentSettings.value,
            providerConfigs = currentProviderConfigs.value,
        )
        request?.let { handle.replaceRetainedMessages(it.requestMessages) }
        return request
    }

    private fun updateSessionSelections(
        sessionId: String,
        selectedSkillIds: List<String>,
        activeSkills: List<ActiveSkillContext>,
    ) {
        chatStateStore.update { persisted ->
            val sessionIndex = persisted.sessions.indexOfFirst { it.id == sessionId }
            if (sessionIndex < 0) return@update persisted
            val updatedSessions = persisted.sessions.toMutableList()
            val session = updatedSessions.removeAt(sessionIndex)
            updatedSessions.add(
                sessionIndex.coerceAtMost(updatedSessions.size),
                session.copy(
                    selectedSkillIds = selectedSkillIds,
                    activeSkills = activeSkills,
                ),
            )
            persisted.copy(sessions = updatedSessions)
        }
    }

    private suspend fun resolveSelectedActiveSkills(
        selectedSkillIds: List<String>,
    ): List<ActiveSkillContext> {
        if (selectedSkillIds.isEmpty()) return emptyList()
        val installedSkillsById = currentExtensionsState.value.installedSkills
            .filter { it.isEnabled }
            .associateBy { it.id }
        return buildList {
            selectedSkillIds.distinct().forEach { skillId ->
                val installedSkill = installedSkillsById[skillId] ?: return@forEach
                val activeSkill = skillManager.buildActiveSkillContext(installedSkill)
                    .getOrElse { return@forEach }
                add(activeSkill)
            }
        }
    }

    private fun resolveTurnSkillSelection(
        explicitActiveSkills: List<ActiveSkillContext>,
        implicitActiveSkills: List<ActiveSkillContext>,
    ): TurnSkillSelection = resolveTurnSkillSelectionForTest(
        explicitActiveSkills = explicitActiveSkills,
        implicitActiveSkills = implicitActiveSkills,
    )

    private fun appendAgentMessage(
        sessionId: String,
        blocks: List<AssistantResponseBlock>,
        thoughtDurationMillis: Long?,
        outcome: SessionTurnOutcome,
        tokenUsage: LlmTokenUsage? = null,
        tokenUsageSource: String = "unavailable",
        turnStartedAtMillis: Long? = null,
        firstTokenAtMillis: Long? = null,
        turnCompletedAtMillis: Long? = null,
        inputMessageCount: Int = 0,
        userMessageCount: Int = 0,
        providerPayloadJson: String = "",
        statusText: String = "",
        statusDetail: String = "",
        handle: SessionExecutionHandle? = null,
        baseMessages: List<ChatMessage> = handle?.retainedMessagesSnapshot().orEmpty(),
    ): CompletionSummary {
        var sessionTitle = resolveSessionTitle(sessionId)
        var replySummary = blocks.lastOrNull()
            ?.let(::assistantResponseBlockSummaryText)
            .orEmpty()

        val normalizedBlocks = normalizeAssistantResponseBlocks(blocks)
        val responseIdentity = handle?.activeResponseIdentity
        val appendedMessages = assistantMessagesForBlocks(
            normalizedBlocks = normalizedBlocks,
            thoughtDurationMillis = thoughtDurationMillis,
            assistantActionsHidden = false,
            isIncomplete = false,
            responseIdentity = responseIdentity,
            messageCreatedAtMillis = turnCompletedAtMillis,
            usageStatistics = buildChatUsageStatistics(
                tokenUsage = tokenUsage,
                tokenUsageSource = tokenUsageSource,
                turnStartedAtMillis = turnStartedAtMillis,
                firstTokenAtMillis = firstTokenAtMillis,
                turnCompletedAtMillis = turnCompletedAtMillis,
            ),
            providerPayloadJson = providerPayloadJson,
            statusText = statusText,
            statusDetail = statusDetail,
        )
        val lastAssistantTextMessage = appendedMessages.lastOrNull {
            it.author != MessageAuthor.User && it.text.isNotBlank()
        }

        deactivateAssistantCheckpoint(handle, responseIdentity)
        chatStateStore.update { persisted ->
            val sessionIndex = persisted.sessions.indexOfFirst { it.id == sessionId }
            if (sessionIndex < 0) return@update persisted

            val updatedSessions = persisted.sessions.toMutableList()
            val session = updatedSessions.removeAt(sessionIndex)
            val currentMessages = session.messages.ifEmpty { baseMessages }
            val messagesWithoutCheckpoint = responseIdentity?.let { identity ->
                currentMessages.filterNot { it.responseGroupId == identity.responseGroupId }
            } ?: currentMessages
            val updatedSession = session.withDerivedMessages(
                messagesWithoutCheckpoint + appendedMessages
            )
            handle?.replaceRetainedMessages(updatedSession.messages)
            sessionTitle = updatedSession.title
            replySummary = updatedSession.preview
            updatedSessions.add(0, updatedSession)
            persisted.copy(sessions = updatedSessions)
        }

        val toolInvocations = normalizedBlocks.toolInvocations()
        val toolNames = toolInvocations.map { it.toolName }.distinct()
        return CompletionSummary(
            sessionTitle = sessionTitle,
            summary = replySummary,
            outcome = outcome,
            toolCallCount = toolInvocations.size,
            distinctToolCount = toolNames.size,
            toolNames = toolNames,
            durationMillis = thoughtDurationMillis,
            tokenUsage = tokenUsage,
            tokenUsageSource = tokenUsageSource,
            inputMessageCount = inputMessageCount,
            userMessageCount = userMessageCount,
            appendedMessageIds = appendedMessages.map(ChatMessage::id),
            lastAssistantMessageId = lastAssistantTextMessage?.id.orEmpty(),
            lastAssistantText = lastAssistantTextMessage?.text.orEmpty(),
        )
    }

    private suspend fun routeSubAgentActivity(activity: ArixSubAgentActivity) {
        val handle = executionHandles[activity.parentSessionId] ?: return
        if (_executionStates.value[activity.parentSessionId]?.isRunning != true) return
        handleToolEvent(
            handle = handle,
            event = AgentToolEvent(
                id = "subagent-${activity.agentId}",
                name = "${activity.agentName} · ${activity.toolName}",
                argumentsJson = activity.argumentsJson,
                outputJson = activity.outputJson,
                isRunning = activity.isRunning,
            ),
            reasoningTraceToolRoutingEnabled = false,
            routeIntoReasoning = false,
        )
    }

    private suspend fun routeMissionTimelineEvent(event: com.arix.app.mission.ArixMissionEngine.MissionEvent) {
        val engine = missionEngine ?: return
        val mission = engine.states.value.firstOrNull { it.missionId == event.missionId } ?: return
        val sessionId = mission.sessionId.takeIf { it.isNotBlank() } ?: return
        val handle = executionHandles[sessionId] ?: return
        if (_executionStates.value[sessionId]?.isRunning != true) return
        val runningStatuses = setOf("queued", "planning", "running", "waiting", "verifying", "replanning")
        val payload = JSONObject()
            .put("mission_id", event.missionId)
            .put("phase", event.phase)
            .put("status", event.status)
            .put("message", event.message)
            .apply { event.taskId?.let { put("task_id", it) } }
            .toString()
        handleToolEvent(
            handle = handle,
            event = AgentToolEvent(
                id = "mission-${event.missionId}",
                name = "mission · ${event.phase}",
                argumentsJson = "",
                outputJson = payload,
                isRunning = event.status in runningStatuses,
            ),
            reasoningTraceToolRoutingEnabled = false,
            routeIntoReasoning = false,
        )
    }

    private suspend fun handleToolEvent(
        handle: SessionExecutionHandle,
        event: AgentToolEvent,
        reasoningTraceToolRoutingEnabled: Boolean,
        routeIntoReasoning: Boolean = true,
    ) {
        val nowUptime = SystemClock.uptimeMillis()
        val nowMillis = System.currentTimeMillis()
        val existingInvocation = _executionStates.value[handle.sessionId]
            ?.pendingToolInvocations
            ?.firstOrNull { it.id == event.id }
        var invocation = ChatToolInvocation(
            id = event.id,
            toolName = event.name,
            argumentsJson = event.argumentsJson,
            outputJson = event.outputJson.orEmpty(),
            isRunning = event.isRunning ?: (event.outputJson == null),
            startedAtUptimeMillis = existingInvocation?.startedAtUptimeMillis ?: nowUptime,
            completedAtUptimeMillis = if (event.isRunning == true || event.outputJson == null) {
                null
            } else {
                existingInvocation?.completedAtUptimeMillis ?: nowUptime
            },
            startedAtMillis = existingInvocation?.startedAtMillis ?: nowMillis,
            completedAtMillis = if (event.isRunning == true || event.outputJson == null) {
                null
            } else {
                existingInvocation?.completedAtMillis ?: nowMillis
            },
            timelineOrder = existingInvocation?.timelineOrder ?: 0L,
        )
        if (event.outputJson == null) {
            flushActiveReasoningSummary(
                handle = handle,
            )
            handle.finishDirectReasoningSummaryChunk()
            transitionReasoningPhase(
                handle = handle,
                phase = ArixReasoningPhase.USING_TOOL,
                statusLabel = toolAwarePhaseLabel(event.name),
            )
        } else if (event.isRunning != true) {
            transitionReasoningPhase(handle, ArixReasoningPhase.VERIFYING)
        }
        val currentBlocks = _executionStates.value[handle.sessionId]?.pendingResponseBlocks.orEmpty()
        val shouldRouteToolIntoReasoning = routeIntoReasoning && (
            handle.activeReasoningBlockId != null ||
                reasoningTraceToolRoutingEnabled ||
                currentBlocks.any { it is AssistantResponseBlock.Reasoning }
            )
        var reasoningBlockId = handle.activeReasoningBlockId
        if (reasoningBlockId == null && shouldRouteToolIntoReasoning) {
            reasoningBlockId = handle.nextPendingBlockId("pending-reasoning")
            handle.startReasoningBlock(reasoningBlockId, nowMillis)
        }
        if (shouldRouteToolIntoReasoning && invocation.timelineOrder <= 0L) {
            invocation = invocation.copy(timelineOrder = handle.nextReasoningTimelineOrder())
        }
        updateExecutionState(handle.sessionId) { current ->
            val targetReasoningBlockId = reasoningBlockId
            val currentBlocks = completePendingReconnectBlocks(current.pendingResponseBlocks)
            val pendingToolInvocations = upsertToolInvocation(
                current.pendingToolInvocations,
                invocation,
            )
            val blocksWithReasoningTrace = if (
                targetReasoningBlockId != null &&
                currentBlocks.none { it is AssistantResponseBlock.Reasoning && it.id == targetReasoningBlockId }
            ) {
                currentBlocks + AssistantResponseBlock.Reasoning(
                    id = targetReasoningBlockId,
                    trace = ReasoningTrace(
                        id = targetReasoningBlockId,
                        latestStatusText = formatReasoningToolStatus(invocation),
                        startedAtMillis = nowMillis,
                    ),
                )
            } else {
                currentBlocks
            }
            val pendingResponseBlocks = upsertAssistantResponseToolInvocation(
                blocks = blocksWithReasoningTrace,
                toolInvocation = invocation,
                reasoningBlockId = targetReasoningBlockId,
            ) { handle.nextPendingBlockId("pending-tools") }
            current.copy(
                pendingToolInvocations = pendingToolInvocations,
                pendingResponseBlocks = pendingResponseBlocks,
            )
        }
    }

    private fun activateAssistantResponse(handle: SessionExecutionHandle): AssistantResponseIdentity {
        val startedAtMillis = System.currentTimeMillis()
        val turnId = "turn-$startedAtMillis-${UUID.randomUUID().toString().take(8)}"
        return AssistantResponseIdentity(
            responseGroupId = "agent-group-$turnId",
            messageIdPrefix = "agent-$turnId",
            createdAtMillis = startedAtMillis,
            checkpointFromPosition = syncActiveBranches(handle.retainedMessagesSnapshot()).size,
        ).also { identity ->
            synchronized(handle.lock) {
                handle.assistantCheckpointJob?.cancel()
                handle.assistantCheckpointJob = null
                handle.lastAssistantCheckpointUptimeMillis = null
                handle.activeResponseIdentity = identity
            }
        }
    }

    private fun deactivateAssistantCheckpoint(
        handle: SessionExecutionHandle?,
        identity: AssistantResponseIdentity?,
    ) {
        if (handle == null || identity == null) return
        synchronized(handle.lock) {
            if (handle.activeResponseIdentity != identity) return
            handle.activeResponseIdentity = null
            handle.assistantCheckpointJob?.cancel()
            handle.assistantCheckpointJob = null
        }
    }

    private fun assistantMessagesForBlocks(
        normalizedBlocks: List<AssistantResponseBlock>,
        thoughtDurationMillis: Long?,
        assistantActionsHidden: Boolean,
        isIncomplete: Boolean = false,
        responseIdentity: AssistantResponseIdentity? = null,
        messageCreatedAtMillis: Long? = null,
        usageStatistics: ChatUsageStatistics? = null,
        providerPayloadJson: String = "",
        statusText: String = "",
        statusDetail: String = "",
    ): List<ChatMessage> {
        val messageTimestamp = if (isIncomplete) {
            responseIdentity?.createdAtMillis ?: messageCreatedAtMillis ?: System.currentTimeMillis()
        } else {
            messageCreatedAtMillis ?: System.currentTimeMillis()
        }
        val responseGroupId = responseIdentity?.responseGroupId ?: "agent-group-$messageTimestamp"
        return normalizedBlocks.mapIndexedNotNull { index, block ->
            when (block) {
                is AssistantResponseBlock.Text -> {
                    if (block.text.isBlank()) {
                        null
                    } else {
                        ChatMessage(
                            id = responseIdentity?.messageIdFor(block.id) ?: "agent-${messageTimestamp + index}",
                            author = MessageAuthor.Agent,
                            text = block.text,
                            createdAtMillis = messageTimestamp + index,
                            responseGroupId = responseGroupId,
                            assistantActionsHidden = assistantActionsHidden,
                            isIncomplete = isIncomplete,
                        )
                    }
                }

                is AssistantResponseBlock.ToolGroup -> {
                    if (block.toolInvocations.isEmpty()) {
                        null
                    } else {
                        ChatMessage(
                            id = responseIdentity?.messageIdFor(block.id) ?: "agent-${messageTimestamp + index}",
                            author = MessageAuthor.Agent,
                            text = "",
                            createdAtMillis = messageTimestamp + index,
                            toolInvocations = block.toolInvocations,
                            responseGroupId = responseGroupId,
                            assistantActionsHidden = assistantActionsHidden,
                            isIncomplete = isIncomplete,
                        )
                    }
                }

                is AssistantResponseBlock.Reasoning -> {
                    ChatMessage(
                        id = responseIdentity?.messageIdFor(block.id) ?: "agent-${messageTimestamp + index}",
                        author = MessageAuthor.Agent,
                        text = "",
                        createdAtMillis = messageTimestamp + index,
                        toolInvocations = block.trace.toolInvocations,
                        reasoningTrace = block.trace,
                        responseGroupId = responseGroupId,
                        assistantActionsHidden = assistantActionsHidden,
                        isIncomplete = isIncomplete,
                    )
                }

                is AssistantResponseBlock.Status -> {
                    if (block.text.isBlank()) null else ChatMessage(
                        id = responseIdentity?.messageIdFor(block.id) ?: "agent-${messageTimestamp + index}",
                        author = MessageAuthor.Agent,
                        text = "",
                        createdAtMillis = messageTimestamp + index,
                        responseGroupId = responseGroupId,
                        assistantActionsHidden = assistantActionsHidden,
                        isIncomplete = isIncomplete,
                        statusText = block.text,
                        statusDetail = block.detail,
                    )
                }
            }
        }.let { messages ->
            if (messages.isEmpty()) {
                if (statusText.isBlank()) {
                    emptyList()
                } else {
                    listOf(
                        ChatMessage(
                            id = responseIdentity?.messageIdFor("status") ?: "agent-$messageTimestamp",
                            author = MessageAuthor.Agent,
                            text = "",
                            createdAtMillis = messageTimestamp,
                            responseGroupId = responseGroupId,
                            assistantActionsHidden = assistantActionsHidden,
                            isIncomplete = isIncomplete,
                            statusText = statusText,
                            statusDetail = statusDetail,
                        )
                    )
                }
            } else {
                messages.toMutableList().apply {
                    if (none { it.reasoningTrace != null }) {
                        val lastIndex = lastIndex
                        set(
                            lastIndex,
                            get(lastIndex).copy(
                                thoughtDurationMillis = thoughtDurationMillis,
                                usageStatistics = usageStatistics,
                                providerPayloadJson = providerPayloadJson,
                                statusText = statusText.ifBlank { get(lastIndex).statusText },
                                statusDetail = statusDetail.ifBlank { get(lastIndex).statusDetail },
                            ),
                        )
                    } else {
                        val lastIndex = lastIndex
                        set(
                            lastIndex,
                            get(lastIndex).copy(
                                usageStatistics = usageStatistics,
                                providerPayloadJson = providerPayloadJson,
                                statusText = statusText.ifBlank { get(lastIndex).statusText },
                                statusDetail = statusDetail.ifBlank { get(lastIndex).statusDetail },
                            ),
                        )
                    }
                }
            }
        }
    }

    private fun buildChatUsageStatistics(
        tokenUsage: LlmTokenUsage?,
        tokenUsageSource: String,
        turnStartedAtMillis: Long?,
        firstTokenAtMillis: Long?,
        turnCompletedAtMillis: Long?,
    ): ChatUsageStatistics? {
        if (
            tokenUsage == null &&
            turnStartedAtMillis == null &&
            firstTokenAtMillis == null &&
            turnCompletedAtMillis == null
        ) {
            return null
        }
        return ChatUsageStatistics(
            inputTokens = tokenUsage?.inputTokens,
            outputTokens = tokenUsage?.outputTokens,
            totalTokens = tokenUsage?.withMissingTotalResolved()?.totalTokens,
            reasoningTokens = tokenUsage?.reasoningTokens,
            cachedInputTokens = tokenUsage?.cachedInputTokens,
            cacheWriteTokens = tokenUsage?.cacheWriteTokens,
            outputDurationMillis = tokenUsage?.outputDurationMillis,
            requestCount = tokenUsage?.requestCount ?: 1,
            tokenUsageSource = tokenUsageSource,
            startedAtMillis = turnStartedAtMillis ?: 0L,
            firstTokenAtMillis = firstTokenAtMillis,
            completedAtMillis = turnCompletedAtMillis ?: 0L,
        )
    }

    private fun currentAssistantResponseBlocks(sessionId: String): List<AssistantResponseBlock> =
        _executionStates.value[sessionId]?.pendingResponseBlocks.orEmpty()

    private fun finalizePausedTurn(
        handle: SessionExecutionHandle,
        snapshot: SessionExecutionState,
    ): CompletionSummary {
        val finalizedToolInvocations = finalizeInterruptedToolInvocations(snapshot.pendingToolInvocations)
        val finalizedResponseBlocks = finalizeInterruptedAssistantResponseBlocks(snapshot.pendingResponseBlocks)
        val thoughtDurationMillis = snapshot.activeTurnStartedAtMillis
            ?.let { startedAt -> (System.currentTimeMillis() - startedAt).coerceAtLeast(0L) }
        val blocks = finalizedResponseBlocks.ifEmpty {
            buildList {
                if (snapshot.pendingAssistantText.isNotBlank()) {
                    add(
                        AssistantResponseBlock.Text(
                            id = handle.nextPendingBlockId("agent-text"),
                            text = snapshot.pendingAssistantText,
                        )
                    )
                }
                if (finalizedToolInvocations.isNotEmpty()) {
                    add(
                        AssistantResponseBlock.ToolGroup(
                            id = handle.nextPendingBlockId("agent-tools"),
                            toolInvocations = finalizedToolInvocations,
                        )
                    )
                }
            }
        }
        val finalStatusText = committedInterruptionStatus(snapshot.pendingStatusText)
        val finalStatusDetail = if (finalStatusText.isBlank()) "" else snapshot.pendingStatusDetail
        val completion = if (blocks.isEmpty() && finalStatusText.isBlank()) {
            CompletionSummary(
                sessionTitle = resolveSessionTitle(handle.sessionId),
                summary = "",
                outcome = SessionTurnOutcome.Neutral,
                toolCallCount = 0,
                distinctToolCount = 0,
                toolNames = emptyList(),
                durationMillis = thoughtDurationMillis,
            )
        } else {
            appendAgentMessage(
                sessionId = handle.sessionId,
                blocks = blocks,
                thoughtDurationMillis = thoughtDurationMillis,
                outcome = SessionTurnOutcome.Neutral,
                statusText = finalStatusText,
                statusDetail = finalStatusDetail,
                handle = handle,
            )
        }
        updateExecutionState(handle.sessionId) { current ->
            if (current.pendingStatusText.isBlank() && current.pendingStatusDetail.isBlank()) {
                current
            } else {
                current.copy(
                    pendingStatusText = "",
                    pendingStatusDetail = "",
                )
            }
        }
        return completion
    }

    private fun appendSteerInterruptionMessages(
        handle: SessionExecutionHandle,
        drained: List<PendingEnvelope>,
    ) {
        if (drained.isEmpty()) return
        val snapshot = _executionStates.value[handle.sessionId]
            ?: SessionExecutionState(sessionId = handle.sessionId)
        val pendingBlocks = snapshot.pendingResponseBlocks.ifEmpty {
            buildList {
                if (snapshot.pendingAssistantText.isNotBlank()) {
                    add(
                        AssistantResponseBlock.Text(
                            id = handle.nextPendingBlockId("agent-text"),
                            text = snapshot.pendingAssistantText,
                        )
                    )
                }
                if (snapshot.pendingToolInvocations.isNotEmpty()) {
                    add(
                        AssistantResponseBlock.ToolGroup(
                            id = handle.nextPendingBlockId("agent-tools"),
                            toolInvocations = snapshot.pendingToolInvocations,
                        )
                    )
                }
            }
        }
        val responseIdentity = handle.activeResponseIdentity
        val interruptedAssistantMessages = assistantMessagesForBlocks(
            normalizedBlocks = normalizeAssistantResponseBlocks(pendingBlocks),
            thoughtDurationMillis = null,
            assistantActionsHidden = true,
            responseIdentity = responseIdentity,
        )
        val userMessages = drained.map { it.message }
        deactivateAssistantCheckpoint(handle, responseIdentity)
        chatStateStore.update { persisted ->
            val sessionIndex = persisted.sessions.indexOfFirst { it.id == handle.sessionId }
            if (sessionIndex < 0) return@update persisted

            val updatedSessions = persisted.sessions.toMutableList()
            val session = updatedSessions.removeAt(sessionIndex)
            val currentMessages = session.messages.ifEmpty { handle.retainedMessagesSnapshot() }
            val messagesWithoutCheckpoint = responseIdentity?.let { identity ->
                currentMessages.filterNot { it.responseGroupId == identity.responseGroupId }
            } ?: currentMessages
            val updatedSession = session.withDerivedMessages(
                syncActiveBranches(messagesWithoutCheckpoint + interruptedAssistantMessages + userMessages)
            )
            handle.replaceRetainedMessages(updatedSession.messages)
            updatedSessions.add(
                0,
                updatedSession,
            )
            persisted.copy(sessions = updatedSessions)
        }
        updateExecutionState(handle.sessionId) { current ->
            current.copy(
                pendingToolInvocations = emptyList(),
                pendingResponseBlocks = emptyList(),
                pendingAssistantText = "",
                pendingStatusText = "",
                pendingStatusDetail = "",
            )
        }
        val continuedResponseIdentity = activateAssistantResponse(handle)
        updateExecutionState(handle.sessionId) { current ->
            current.copy(activeResponseGroupId = continuedResponseIdentity.responseGroupId)
        }
    }

    private fun drainSteerInputs(
        handle: SessionExecutionHandle,
    ): List<PendingEnvelope> {
        val drained = synchronized(handle.lock) {
            buildList {
                while (handle.steerInputs.isNotEmpty()) {
                    add(handle.steerInputs.removeFirst())
                }
            }
        }
        if (drained.isEmpty()) return emptyList()

        val drainedIds = drained.map { it.id }.toSet()
        updateExecutionState(handle.sessionId) { current ->
            current.copy(
                pendingInputs = current.pendingInputs.filterNot { drainedIds.contains(it.id) }
            )
        }
        return drained
    }

    private fun promoteRemainingSteersToQueue(
        handle: SessionExecutionHandle,
    ) {
        val movedIds = synchronized(handle.lock) {
            if (handle.steerInputs.isEmpty()) {
                emptyList()
            } else {
                buildList {
                    while (handle.steerInputs.isNotEmpty()) {
                        val entry = handle.steerInputs.removeFirst()
                        handle.queuedInputs.addFirst(entry.copy(mode = SessionFollowUpMode.Queue))
                        add(entry.id)
                    }
                }
            }
        }
        if (movedIds.isEmpty()) return

        updateExecutionState(handle.sessionId) { current ->
            current.copy(
                pendingInputs = current.pendingInputs.map { pending ->
                    if (movedIds.contains(pending.id)) {
                        pending.copy(mode = SessionFollowUpMode.Queue)
                    } else {
                        pending
                    }
                }
            )
        }
    }

    private fun pollNextQueuedInput(
        handle: SessionExecutionHandle,
    ): PendingEnvelope? {
        val next = synchronized(handle.lock) {
            if (handle.queuedInputs.isEmpty()) {
                null
            } else {
                handle.queuedInputs.removeFirst()
            }
        } ?: return null

        updateExecutionState(handle.sessionId) { current ->
            current.copy(
                pendingInputs = current.pendingInputs.filterNot { it.id == next.id }
            )
        }
        return next
    }

    private fun clearPendingInputs(
        handle: SessionExecutionHandle,
    ) {
        synchronized(handle.lock) {
            handle.queuedInputs.clear()
            handle.steerInputs.clear()
        }
        if (executionHandles[handle.sessionId] !== handle) return
        updateExecutionState(handle.sessionId) { current ->
            current.copy(pendingInputs = emptyList())
        }
    }

    private fun updateExecutionState(
        sessionId: String,
        transform: (SessionExecutionState) -> SessionExecutionState,
    ) {
        _executionStates.update { states ->
            states.toMutableMap().apply {
                val current = get(sessionId) ?: SessionExecutionState(sessionId = sessionId)
                put(sessionId, transform(current))
            }
        }
        requestAssistantCheckpoint(sessionId)
        if (
            currentSettings.value.keepTasksRunningInBackground &&
            _executionStates.value.values.any { it.isRunning }
        ) {
            ensureForegroundServiceRunning()
        }
    }

    private fun transitionReasoningPhase(
        handle: SessionExecutionHandle,
        phase: ArixReasoningPhase,
        statusLabel: String? = null,
    ) {
        if (handle.pauseRequested && phase != ArixReasoningPhase.CANCELLED) return
        var mochiBroadcastPhase: ArixReasoningPhase? = null
        updateExecutionState(handle.sessionId) { current ->
            val currentPhase = current.reasoningPhase
            if (currentPhase.isTerminal && phase != currentPhase) return@updateExecutionState current
            if (currentPhase == phase) {
                if (statusLabel != null && statusLabel != current.pendingStatusText &&
                    !current.pendingStatusText.startsWith("Reconnecting", ignoreCase = true)
                ) {
                    current.copy(pendingStatusText = statusLabel, pendingStatusDetail = "")
                } else {
                    current
                }
            } else {
                mochiBroadcastPhase = phase
                current.copy(
                    reasoningPhase = phase,
                    pendingStatusText = statusLabel ?: phase.progressLabel.orEmpty(),
                    pendingStatusDetail = "",
                )
            }
        }
        mochiBroadcastPhase?.let { committedPhase ->
            runCatching {
                when (committedPhase) {
                    ArixReasoningPhase.THINKING -> com.arix.app.companion.ArixMochiBus.noteThinkingStarted()
                    ArixReasoningPhase.USING_TOOL,
                    ArixReasoningPhase.VERIFYING,
                    -> com.arix.app.companion.ArixMochiBus.noteToolWorkingStarted()
                    ArixReasoningPhase.FINALIZING -> com.arix.app.companion.ArixMochiBus.noteGeneratingStarted()
                    ArixReasoningPhase.ERROR -> com.arix.app.companion.ArixMochiBus.noteError()
                    ArixReasoningPhase.CANCELLED -> com.arix.app.companion.ArixMochiBus.noteTurnSettled()
                    ArixReasoningPhase.COMPLETE -> com.arix.app.companion.ArixMochiBus.noteTurnSettled()
                    ArixReasoningPhase.IDLE -> Unit
                }
            }
        }
    }

    private fun requestAssistantCheckpoint(sessionId: String) {
        val handle = executionHandles[sessionId] ?: return
        val identity = handle.activeResponseIdentity ?: return
        val blocks = _executionStates.value[sessionId]?.pendingResponseBlocks.orEmpty()
        if (blocks.isEmpty()) return

        val nowUptimeMillis = SystemClock.uptimeMillis()
        var persistNow = false
        synchronized(handle.lock) {
            if (handle.activeResponseIdentity != identity) return
            val remainingMillis = handle.lastAssistantCheckpointUptimeMillis?.let { lastCheckpointUptimeMillis ->
                AssistantCheckpointIntervalMillis - (nowUptimeMillis - lastCheckpointUptimeMillis)
            } ?: 0L
            if (remainingMillis <= 0L) {
                handle.lastAssistantCheckpointUptimeMillis = nowUptimeMillis
                handle.assistantCheckpointJob?.cancel()
                handle.assistantCheckpointJob = null
                persistNow = true
            } else if (handle.assistantCheckpointJob?.isActive != true) {
                handle.assistantCheckpointJob = scope.launch {
                    delay(remainingMillis)
                    persistAssistantCheckpoint(handle, identity)
                }
            }
        }
        if (persistNow) {
            persistAssistantCheckpoint(handle, identity)
        }
    }

    private fun persistAssistantCheckpoint(
        handle: SessionExecutionHandle,
        identity: AssistantResponseIdentity,
    ) {
        val blocks = _executionStates.value[handle.sessionId]?.pendingResponseBlocks.orEmpty()
        if (blocks.isEmpty() || handle.activeResponseIdentity != identity) return
        synchronized(handle.lock) {
            if (handle.activeResponseIdentity != identity) return
            handle.lastAssistantCheckpointUptimeMillis = SystemClock.uptimeMillis()
            handle.assistantCheckpointJob = null
        }
        val checkpointMessages = assistantMessagesForBlocks(
            normalizedBlocks = normalizeAssistantResponseBlocks(blocks),
            thoughtDurationMillis = null,
            assistantActionsHidden = false,
            isIncomplete = true,
            responseIdentity = identity,
        )
        if (checkpointMessages.isEmpty()) return

        chatStateStore.updateAssistantCheckpoint(
            checkpoint = AssistantResponseCheckpoint(
                target = AssistantResponseCheckpointTarget(
                    sessionId = handle.sessionId,
                    responseGroupId = identity.responseGroupId,
                ),
                fromPosition = identity.checkpointFromPosition,
                messages = checkpointMessages,
            ),
            shouldPersist = { handle.activeResponseIdentity == identity },
        )
    }

    private fun ensureForegroundServiceRunning() {
        try {
            ArixForegroundService.ensureRunning(application)
        } catch (throwable: Throwable) {
            diagnosticLogger.exception(
                category = "session",
                event = "foreground_service_start_failed",
                throwable = throwable,
            )
        }
    }

    private fun validateSettings(settings: AppSettings): String? = when {
        !settings.isProviderSetupValid() ->
            "The selected provider is not fully configured."

        else -> null
    }

    private fun validateRequest(request: SessionTurnRequest): String? =
        validateSettings(request.settings)

    private fun resolveSessionTitle(sessionId: String): String =
        chatStateStore.state.value.sessions.firstOrNull { it.id == sessionId }?.title.orEmpty()

    private fun buildRequestMessages(
        messages: List<ChatMessage>,
        settings: AppSettings,
        turnContextBlock: String? = null,
    ): List<LlmMessage> = SessionContextBuilder.buildRequestMessages(messages, settings, turnContextBlock)

    private fun buildSteerRequestMessage(
        message: ChatMessage,
        settings: AppSettings,
    ): LlmMessage = SessionContextBuilder.buildSteerRequestMessage(message, settings)

    private fun formatReasoningDurationLabel(trace: ReasoningTrace): String {
        val startedAt = trace.startedAtMillis.takeIf { it > 0L } ?: return "0s"
        val endedAt = trace.completedAtMillis ?: System.currentTimeMillis()
        val totalSeconds = ((endedAt - startedAt).coerceAtLeast(0L) + 500L) / 1000L
        return "${totalSeconds.coerceAtLeast(0L)}s"
    }

    private fun formatFailureMessage(throwable: Throwable): String {
        val message = throwable.message?.trim().orEmpty()
        if (message.isBlank()) {
            return throwable.javaClass.simpleName.ifBlank { "Unknown error" }
        }
        if (isQuotaExhaustionFailure(message)) {
            val limitHint = QuotaLimitPattern.find(message)?.groupValues?.get(1)?.trim().orEmpty()
            val poolSize = AllKeysExhaustedPattern.find(message)?.groupValues?.get(1)?.trim().orEmpty()
            val benched = message.contains("key benched", ignoreCase = true)
            val isGoogle = message.contains("generativelanguage", ignoreCase = true) ||
                message.contains("googleapis", ignoreCase = true)
            return buildString {
                if (poolSize.isNotBlank()) {
                    append("All $poolSize configured API keys hit the provider quota")
                    if (limitHint.isNotBlank()) append(" (limit: $limitHint tokens/minute)")
                    append(
                        ". Arix already rotated through every key automatically — " +
                            "add another API key in Settings → Provider, or wait a minute " +
                            "for the quota window to reset (v3.0.84 also cut the tokens " +
                            "each turn consumes, so the pool lasts much longer).",
                    )
                } else if (benched) {
                    append("The provider quota was exhausted on the active API key")
                    if (limitHint.isNotBlank()) append(" (limit: $limitHint tokens/minute)")
                    append(
                        ". Arix already switched to a backup key automatically and will " +
                            "continue from the checkpoint — no action needed.",
                    )
                } else {
                    append("The provider quota was exhausted")
                    if (limitHint.isNotBlank()) append(" (limit: $limitHint tokens/minute)")
                    append(
                        ". Add another API key in Settings → Provider (Arix rotates keys " +
                            "automatically when more than one is configured) or wait a minute " +
                            "for the quota window to reset.",
                    )
                }
                if (isGoogle) {
                    append(
                        " Note: keys created in the same Google Cloud project share one " +
                            "quota — create the second key in a DIFFERENT project " +
                            "(aistudio.google.com → switch project → new key) so the keys " +
                            "really have separate limits.",
                    )
                }
            }
        }
        return message
    }

    private fun isQuotaExhaustionFailure(message: String): Boolean =
        message.contains("429") ||
            message.contains("RESOURCE_EXHAUSTED", ignoreCase = true) ||
            message.contains("exceeded your current quota", ignoreCase = true) ||
            message.contains("quota", ignoreCase = true) && message.contains("exhaust", ignoreCase = true) ||
            message.contains("all ") && message.contains("API keys are exhausted")

    private val QuotaLimitPattern = Regex("""limit:?\s*(\d[\d,]*)""", RegexOption.IGNORE_CASE)

    private val AllKeysExhaustedPattern =
        Regex("""all\s+(\d+)\s+configured API keys are exhausted""", RegexOption.IGNORE_CASE)

    private fun isRetryableFailure(throwable: Throwable): Boolean {
        val message = throwable.message?.lowercase().orEmpty()
        if (isQuotaExhaustionFailure(throwable.message.orEmpty())) return true
        return message.contains("timeout") ||
            message.contains("timed out") ||
            message.contains("connection") ||
            message.contains("reset") ||
            message.contains("broken pipe") ||
            message.contains("eof") ||
            message.contains("stream") ||
            message.contains("502") ||
            message.contains("503") ||
            message.contains("504") ||
            message.contains("overloaded") ||
            message.contains("internal error") ||
            message.contains("temporarily unavailable") ||
            throwable is java.io.IOException
    }

    internal fun checkpointTextOf(messageText: String): String {
        val index = messageText.indexOf("\n\nRequest failed:")
        val index2 = if (index >= 0) index else messageText.indexOf("Request failed:")
        return (if (index2 >= 0) messageText.substring(0, index2) else messageText).trim()
    }

    fun canContinueFromCheckpoint(sessionId: String): Boolean {
        if (isSessionRunning(sessionId)) return false
        if (continuationJobs[sessionId]?.isActive == true) return false
        val session = chatStateStore.state.value.sessions.firstOrNull { it.id == sessionId }
            ?: return false
        val lastAssistant = session.messages.lastOrNull { it.author == MessageAuthor.Agent }
            ?: return false
        if (lastAssistant.text.isBlank()) return false
        val interrupted = lastAssistant.text.contains("Request failed:") || lastAssistant.isIncomplete
        if (!interrupted) return false
        return checkpointTextOf(lastAssistant.text).length >= MinCheckpointChars / 2
    }

    private fun scheduleCheckpointContinuation(sessionId: String, delayMillis: Long) {
        continuationJobs.remove(sessionId)?.cancel()
        val depth = continuationDepths[sessionId] ?: 0
        if (depth >= MaxAutoContinuations) return
        continuationJobs[sessionId] = scope.launch {
            delay(delayMillis)
            if (!canContinueFromCheckpoint(sessionId)) return@launch
            val session = chatStateStore.state.value.sessions.firstOrNull { it.id == sessionId }
            val lastUser = session?.messages?.lastOrNull { it.author == MessageAuthor.User }
            val lastAssistant = session?.messages?.lastOrNull { it.author == MessageAuthor.Agent }
            val lastUserAfterFailure = lastUser != null && lastAssistant != null &&
                lastUser.createdAtMillis > lastAssistant.createdAtMillis
            if (lastUserAfterFailure) return@launch
            continueSessionFromCheckpoint(sessionId, automatic = true)
        }
    }

    suspend fun continueSessionFromCheckpoint(sessionId: String, automatic: Boolean): Boolean {
        if (isSessionRunning(sessionId)) return false
        val persisted = chatStateStore.state.first()
        val existing = persisted.sessions.firstOrNull { it.id == sessionId } ?: return false
        val lastAssistant = existing.messages.lastOrNull { it.author == MessageAuthor.Agent && it.text.isNotBlank() }
            ?: return false
        val checkpoint = checkpointTextOf(lastAssistant.text)
        if (checkpoint.isBlank()) return false
        val settings = currentSettings.value
        val providerConfigs = currentProviderConfigs.value
        val depth = continuationDepths[sessionId] ?: 0
        if (automatic && depth >= MaxAutoContinuations) return false
        continuationDepths[sessionId] = depth + 1

        val tail = if (checkpoint.length > ContinuationContextChars) {
            checkpoint.substring(checkpoint.length - ContinuationContextChars)
        } else {
            checkpoint
        }
        val continuationPrompt = buildString {
            append(
                "Your previous response was interrupted before it finished. " +
                    "Below is the END of what you already wrote. Continue EXACTLY " +
                    "from where it stops — complete the interrupted sentence/line " +
                    "first, then finish the original task completely.\n" +
                    "Rules: output ONLY the continuation; never repeat or restate " +
                    "text from below; never apologize or summarize; keep the exact " +
                    "same formatting (markdown, code fences, list numbering); if " +
                    "the text stops inside a code block, continue inside that code " +
                    "block.\n\n--- END OF RESPONSE SO FAR ---\n",
            )
            append(tail)
            append("\n--- CONTINUE FROM HERE ---")
        }
        val now = System.currentTimeMillis()
        val statusNote = ChatMessage(
            id = "ckpt-status-$sessionId-$now",
            author = MessageAuthor.User,
            text = if (automatic) {
                "Continuing from checkpoint (attempt ${depth + 1}/$MaxAutoContinuations)…"
            } else {
                "Continuing from checkpoint…"
            },
            createdAtMillis = now,
            displayKind = MessageDisplayKind.CompactStatus,
        )
        val continuationMessage = ChatMessage(
            id = "ckpt-continue-$sessionId-$now",
            author = MessageAuthor.User,
            text = continuationPrompt,
            createdAtMillis = now + 1,
            displayKind = MessageDisplayKind.HiddenContext,
        )
        var selectedModelKey = existing.selectedModelKey
        var requestMessages = existing.messages + listOf(statusNote, continuationMessage)
        var selectedSkillIds = existing.selectedSkillIds
        var activeSkills = existing.activeSkills
        chatStateStore.updateAndFlush { current ->
            val sessions = current.sessions.toMutableList()
            val index = sessions.indexOfFirst { it.id == sessionId }
            if (index >= 0) {
                val existingSession = sessions.removeAt(index)
                val merged = existingSession.withDerivedMessages(
                    existingSession.messages + listOf(statusNote, continuationMessage),
                )
                selectedModelKey = merged.selectedModelKey
                requestMessages = merged.messages
                selectedSkillIds = merged.selectedSkillIds
                activeSkills = merged.activeSkills
                sessions.add(0, merged)
            } else {
                sessions.add(0, existing)
            }
            current.copy(sessions = sessions, currentSessionId = current.currentSessionId)
        }
        startTurn(
            SessionTurnRequest(
                sessionId = sessionId,
                settings = resolveModelSettings(
                    baseSettings = settings,
                    providerConfigs = providerConfigs,
                    preferredModelKey = selectedModelKey,
                    fallbackModelKey = resolveDefaultChatModelKey(settings, providerConfigs),
                ),
                requestMessages = requestMessages,
                selectedSkillIds = selectedSkillIds,
                activeSkills = activeSkills,
                providerConfigs = providerConfigs,
            ),
        )
        return true
    }

    fun cancelScheduledContinuation(sessionId: String) {
        continuationJobs.remove(sessionId)?.cancel()
    }

    fun resetContinuationBudget(sessionId: String) {
        continuationJobs.remove(sessionId)?.cancel()
        continuationDepths.remove(sessionId)
    }

    private fun AppSettings.supportsVisibleReasoningTrace(): Boolean {
        return baseUrl.contains("deepseek", ignoreCase = true) ||
            baseUrl.contains("openrouter", ignoreCase = true) ||
            modelId.contains("deepseek", ignoreCase = true) ||
            modelId.contains("openrouter", ignoreCase = true)
    }

    private fun formatReasoningToolStatus(invocation: ChatToolInvocation): String {
        val arguments = parseJsonObject(invocation.argumentsJson)
        return when (invocation.toolName.lowercase()) {
            "bash" -> if (invocation.isRunning) "Executing bash command" else "Executed bash command"
            "read" -> if (invocation.isRunning) "Reading file" else "Read file"
            "edit" -> if (invocation.isRunning) "Editing file" else "Edited file"
            "write" -> if (invocation.isRunning) "Writing file" else "Wrote file"
            "grep" -> if (invocation.isRunning) "Searching files" else "Searched files"
            "find" -> if (invocation.isRunning) "Finding files" else "Found files"
            "ls" -> if (invocation.isRunning) "Listing files" else "Listed files"
            "arix_config_get" -> formatReasoningToolAction(
                isRunning = invocation.isRunning,
                runningVerb = "Reading",
                completedVerb = "Read",
                subject = formatArixReasoningCategories(arguments),
                fallback = "Arix settings",
            )

            "arix_config_set" -> formatReasoningToolAction(
                isRunning = invocation.isRunning,
                runningVerb = "Updating",
                completedVerb = "Updated",
                subject = arguments?.optString("category").orEmpty(),
                fallback = "Arix settings",
            )

            "arix_skill_manage" -> formatReasoningToolAction(
                isRunning = invocation.isRunning,
                runningVerb = arixSkillReasoningVerb(arguments, running = true),
                completedVerb = arixSkillReasoningVerb(arguments, running = false),
                subject = arguments?.optString("skill_id").orEmpty()
                    .ifBlank { arguments?.optString("skillId").orEmpty() }
                    .ifBlank { arguments?.optString("url").orEmpty() },
                fallback = "Agent Skills",
            )

            "arix_mcp_manage" -> formatReasoningToolAction(
                isRunning = invocation.isRunning,
                runningVerb = arixMcpReasoningVerb(arguments, running = true),
                completedVerb = arixMcpReasoningVerb(arguments, running = false),
                subject = arguments?.optString("server_id").orEmpty()
                    .ifBlank { arguments?.optString("serverId").orEmpty() }
                    .ifBlank { arguments?.optString("display_name").orEmpty() }
                    .ifBlank { arguments?.optString("displayName").orEmpty() },
                fallback = "MCP servers",
            )

            "arix_agent_mode_manage" -> when (arguments?.optString("action").orEmpty().lowercase()) {
                "set_authorization" -> if (invocation.isRunning) "Updating Agent Mode authorization" else "Updated Agent Mode authorization"
                "stop_session" -> if (invocation.isRunning) "Stopping Agent Mode session" else "Stopped Agent Mode session"
                else -> if (invocation.isRunning) "Checking Agent Mode authorization" else "Checked Agent Mode authorization"
            }

            "arix_developer_manage" -> if (invocation.isRunning) "Reading Arix diagnostics" else "Read Arix diagnostics"
            "browser" -> when (arguments?.optString("action").orEmpty().lowercase()) {
                "navigate" -> if (invocation.isRunning) "Opening web page" else "Opened web page"
                "get_readable", "get_text" -> if (invocation.isRunning) "Reading page content" else "Read page content"
                "click" -> if (invocation.isRunning) "Clicking page element" else "Clicked page element"
                "type" -> if (invocation.isRunning) "Typing into page" else "Typed into page"
                "screenshot" -> if (invocation.isRunning) "Capturing page screenshot" else "Captured page screenshot"
                else -> if (invocation.isRunning) "Using browser" else "Used browser"
            }
            else -> if (invocation.isRunning) {
                "Using ${invocation.toolName}"
            } else {
                "Used ${invocation.toolName}"
            }
        }
    }

    private fun formatArixReasoningCategories(arguments: JSONObject?): String {
        val categories = arguments?.optJSONArray("categories") ?: return ""
        return buildList {
            for (index in 0 until categories.length()) {
                val value = categories.optString(index).trim()
                if (value.isNotBlank()) add(value)
            }
        }.joinToString(", ")
    }

    private fun arixSkillReasoningVerb(
        arguments: JSONObject?,
        running: Boolean,
    ): String = when (arguments?.optString("action").orEmpty().lowercase()) {
        "install_remote" -> if (running) "Installing" else "Installed"
        "remove" -> if (running) "Removing" else "Removed"
        "set_enabled" -> if (running) "Updating" else "Updated"
        else -> if (running) "Reading" else "Read"
    }

    private fun arixMcpReasoningVerb(
        arguments: JSONObject?,
        running: Boolean,
    ): String = when (arguments?.optString("action").orEmpty().lowercase()) {
        "upsert_streamable_http", "upsert_stdio" -> if (running) "Saving" else "Saved"
        "remove" -> if (running) "Removing" else "Removed"
        "set_enabled" -> if (running) "Updating" else "Updated"
        else -> if (running) "Reading" else "Read"
    }

    private fun formatReasoningToolAction(
        isRunning: Boolean,
        runningVerb: String,
        completedVerb: String,
        subject: String,
        fallback: String,
    ): String {
        val action = if (isRunning) runningVerb else completedVerb
        val normalizedSubject = subject.trim().take(96)
        return if (normalizedSubject.isBlank()) {
            "$action $fallback"
        } else {
            "$action $normalizedSubject"
        }
    }

    private fun upsertToolInvocation(
        invocations: List<ChatToolInvocation>,
        toolInvocation: ChatToolInvocation,
    ): List<ChatToolInvocation> {
        val nowUptime = SystemClock.uptimeMillis()
        val nowMillis = System.currentTimeMillis()
        val existingIndex = invocations.indexOfFirst { it.id == toolInvocation.id }
        val normalized = if (existingIndex < 0) {
            toolInvocation.copy(
                startedAtUptimeMillis = toolInvocation.startedAtUptimeMillis.takeIf { it > 0L } ?: nowUptime,
                completedAtUptimeMillis = if (toolInvocation.isRunning) {
                    null
                } else {
                    toolInvocation.completedAtUptimeMillis ?: nowUptime
                },
                startedAtMillis = toolInvocation.startedAtMillis.takeIf { it > 0L } ?: nowMillis,
                completedAtMillis = if (toolInvocation.isRunning) {
                    null
                } else {
                    toolInvocation.completedAtMillis ?: nowMillis
                },
            )
        } else {
            val existing = invocations[existingIndex]
            toolInvocation.copy(
                startedAtUptimeMillis = existing.startedAtUptimeMillis
                    .takeIf { it > 0L }
                    ?: toolInvocation.startedAtUptimeMillis.takeIf { it > 0L }
                    ?: nowUptime,
                completedAtUptimeMillis = if (toolInvocation.isRunning) {
                    null
                } else {
                    toolInvocation.completedAtUptimeMillis
                        ?: existing.completedAtUptimeMillis
                        ?: nowUptime
                },
                startedAtMillis = existing.startedAtMillis
                    .takeIf { it > 0L }
                    ?: toolInvocation.startedAtMillis.takeIf { it > 0L }
                    ?: nowMillis,
                completedAtMillis = if (toolInvocation.isRunning) {
                    null
                } else {
                    toolInvocation.completedAtMillis
                        ?: existing.completedAtMillis
                        ?: nowMillis
                },
                timelineOrder = existing.timelineOrder
                    .takeIf { it > 0L }
                    ?: toolInvocation.timelineOrder,
            )
        }
        return if (existingIndex < 0) {
            invocations + normalized
        } else {
            invocations.toMutableList().apply { set(existingIndex, normalized) }
        }
    }

    private class StreamingTextDeltaBuffer(
        private val flush: (String) -> Unit,
    ) {
        private val buffer = StringBuilder()
        private var lastFlushAtUptimeMillis = 0L
        private var firstDelta = true

        fun append(delta: String) {
            if (delta.isEmpty()) return
            val payload = synchronized(this) {
                buffer.append(delta)
                val now = SystemClock.uptimeMillis()
                val shouldFlush = firstDelta ||
                    buffer.length >= maxBufferedChars ||
                    (now - lastFlushAtUptimeMillis) >= flushIntervalMillis
                if (!shouldFlush) return
                firstDelta = false
                lastFlushAtUptimeMillis = now
                val payload = buffer.toString()
                buffer.setLength(0)
                payload
            }
            flush(payload)
        }

        fun flushNow() {
            val payload = synchronized(this) {
                if (buffer.isEmpty()) return
                lastFlushAtUptimeMillis = SystemClock.uptimeMillis()
                val payload = buffer.toString()
                buffer.setLength(0)
                payload
            }
            flush(payload)
        }

        private companion object {
            const val flushIntervalMillis = 100L
            const val maxBufferedChars = 8_192
        }
    }

    private fun appendAssistantResponseText(
        blocks: List<AssistantResponseBlock>,
        delta: String,
        newBlockId: () -> String,
    ): List<AssistantResponseBlock> {
        if (delta.isEmpty()) return blocks
        val lastBlock = blocks.lastOrNull()
        return if (lastBlock is AssistantResponseBlock.Text) {
            blocks.toMutableList().apply {
                set(lastIndex, lastBlock.copy(text = lastBlock.text + delta))
            }
        } else {
            blocks + AssistantResponseBlock.Text(
                id = newBlockId(),
                text = delta,
            )
        }
    }

    private fun appendReasoningDelta(
        handle: SessionExecutionHandle,
        delta: String,
    ) {
        val now = System.currentTimeMillis()
        val existingBlockId = handle.activeReasoningBlockId
        val newBlockId = handle.nextPendingBlockId("pending-reasoning")
        var activeBlockId: String? = existingBlockId
        var startedNewBlock = false
        updateExecutionState(handle.sessionId) { current ->
            startedNewBlock = false
            val blocks = completePendingReconnectBlocks(current.pendingResponseBlocks).toMutableList()
            val activeIndex = existingBlockId?.let { id ->
                blocks.indexOfFirst { it is AssistantResponseBlock.Reasoning && it.id == id }
            } ?: -1
            if (activeIndex >= 0) {
                val block = blocks[activeIndex] as AssistantResponseBlock.Reasoning
                blocks[activeIndex] = block.copy(
                    trace = block.trace.copy(rawText = block.trace.rawText + delta),
                )
                activeBlockId = existingBlockId
            } else {
                activeBlockId = newBlockId
                startedNewBlock = true
                blocks += AssistantResponseBlock.Reasoning(
                    id = newBlockId,
                    trace = ReasoningTrace(
                        id = newBlockId,
                        rawText = delta,
                        startedAtMillis = now,
                    ),
                )
            }
            current.copy(
                pendingStatusText = "",
                pendingStatusDetail = "",
                pendingResponseBlocks = blocks,
            )
        }
        if (startedNewBlock) {
            handle.startReasoningBlock(newBlockId, now)
        }

        val blockId = activeBlockId ?: return
        val trace = currentReasoningTrace(handle.sessionId, blockId) ?: return
        maybeSubmitReasoningSummary(
            handle = handle,
            trace = trace,
            forceRemaining = false,
        )
    }

    private fun appendDirectReasoningSummaryDelta(
        handle: SessionExecutionHandle,
        delta: String,
    ) {
        val now = System.currentTimeMillis()
        val existingBlockId = handle.activeReasoningBlockId
        val newBlockId = handle.nextPendingBlockId("pending-reasoning")
        val newChunkId = handle.nextReasoningChunkId(existingBlockId ?: newBlockId)
        val newTimelineOrder = handle.nextReasoningTimelineOrder()
        var startedNewBlock = false
        var activatedChunkId: String? = null
        updateExecutionState(handle.sessionId) { current ->
            startedNewBlock = false
            activatedChunkId = null
            val blocks = current.pendingResponseBlocks.toMutableList()
            val activeIndex = existingBlockId?.let { id ->
                blocks.indexOfFirst { it is AssistantResponseBlock.Reasoning && it.id == id }
            } ?: -1
            val blockIndex = if (activeIndex >= 0) {
                activeIndex
            } else {
                startedNewBlock = true
                blocks += AssistantResponseBlock.Reasoning(
                    id = newBlockId,
                    trace = ReasoningTrace(
                        id = newBlockId,
                        startedAtMillis = now,
                    ),
                )
                blocks.lastIndex
            }

            val block = blocks[blockIndex] as AssistantResponseBlock.Reasoning
            val chunkId = handle.activeDirectReasoningSummaryChunkId
                ?.takeIf { id -> block.trace.chunks.any { it.id == id } }
                ?: newChunkId.also { activatedChunkId = it }
            val existingChunk = block.trace.chunks.firstOrNull { it.id == chunkId }
            val updatedDetail = existingChunk?.detail.orEmpty() + delta
            val updatedChunks = if (existingChunk == null) {
                block.trace.chunks + ReasoningSummaryChunk(
                    id = chunkId,
                    title = "Reasoning",
                    detail = updatedDetail,
                    isPending = false,
                    createdAtMillis = now,
                    timelineOrder = newTimelineOrder,
                )
            } else {
                block.trace.chunks.map { chunk ->
                    if (chunk.id == chunkId) {
                        chunk.copy(
                            detail = updatedDetail,
                            isPending = false,
                        )
                    } else {
                        chunk
                    }
                }
            }
            blocks[blockIndex] = block.copy(
                trace = block.trace.copy(
                    chunks = updatedChunks,
                    latestStatusText = updatedDetail,
                )
            )
            current.copy(
                pendingStatusText = "",
                pendingStatusDetail = "",
                pendingResponseBlocks = blocks,
            )
        }
        if (startedNewBlock) {
            handle.startReasoningBlock(newBlockId, now)
        }
        if (activatedChunkId != null) {
            handle.activeDirectReasoningSummaryChunkId = activatedChunkId
        }
    }

    private fun completeActiveReasoning(
        handle: SessionExecutionHandle,
        trigger: ReasoningCompletionTrigger,
    ) {
        val blockId = handle.activeReasoningBlockId ?: return
        val now = System.currentTimeMillis()
        val trace = currentReasoningTrace(handle.sessionId, blockId) ?: run {
            handle.finishReasoningBlock()
            return
        }
        if (trace.rawText.isNotBlank()) {
            maybeSubmitReasoningSummary(
                handle = handle,
                trace = trace,
                forceRemaining = true,
            )
        }
        updateExecutionState(handle.sessionId) { current ->
            current.copy(
                pendingResponseBlocks = current.pendingResponseBlocks.map { block ->
                    if (block is AssistantResponseBlock.Reasoning && block.id == blockId) {
                        block.copy(
                            trace = block.trace.copy(
                                completedAtMillis = block.trace.completedAtMillis ?: now,
                            )
                        )
                    } else {
                        block
                    }
                }
            )
        }
        handle.finishReasoningBlock()
    }

    private fun flushActiveReasoningSummary(
        handle: SessionExecutionHandle,
    ) {
        val blockId = handle.activeReasoningBlockId ?: return
        val trace = currentReasoningTrace(handle.sessionId, blockId) ?: return
        if (trace.rawText.isBlank()) return
        maybeSubmitReasoningSummary(
            handle = handle,
            trace = trace,
            forceRemaining = true,
        )
    }

    private fun maybeSubmitReasoningSummary(
        handle: SessionExecutionHandle,
        trace: ReasoningTrace,
        forceRemaining: Boolean,
    ) {
        if (!forceRemaining) return
        val rawText = trace.rawText
        if (rawText.isBlank()) return
        synchronized(handle.lock) {
            if (handle.reasoningFirstSummarySubmitted) return
            handle.reasoningFirstSummarySubmitted = true
            handle.reasoningLastSubmittedCharIndex = rawText.length
            handle.reasoningLastTimedSummaryAtMillis = System.currentTimeMillis()
            submitReasoningSummary(
                handle = handle,
                blockId = trace.id,
                rawText = rawText.take(ReasoningSummaryMaxInputChars),
            )
        }
    }

    private companion object {
        const val ReasoningSummaryMaxInputChars = 8_000

        const val MaxAutoContinuations = 3

        const val MinCheckpointChars = 120

        const val ContinuationContextChars = 6_000

        const val QuotaContinuationDelayMillis = 45_000L

        const val StreamContinuationDelayMillis = 6_000L
    }

    private fun submitReasoningSummary(
        handle: SessionExecutionHandle,
        blockId: String,
        rawText: String,
    ) {
        val trimmed = rawText.trim()
        if (trimmed.isBlank()) return
        val chunkId = handle.nextReasoningChunkId(blockId)
        val createdAtMillis = System.currentTimeMillis()
        val timelineOrder = handle.nextReasoningTimelineOrder()
        updateReasoningTrace(handle.sessionId, blockId) { trace ->
            trace.copy(
                chunks = trace.chunks + ReasoningSummaryChunk(
                    id = chunkId,
                    rawText = trimmed,
                    isPending = true,
                    createdAtMillis = createdAtMillis,
                    timelineOrder = timelineOrder,
                )
            )
        }

        scope.launch(Dispatchers.IO) {
            val summary = reasoningSummarizer.summarizeReasoningChunk(trimmed)
                ?: reasoningSummarizer.fallbackReasoningSummary()
            updateReasoningTrace(handle.sessionId, blockId) { trace ->
                val latestStatusText = summary.detail.ifBlank { summary.title }
                trace.copy(
                    chunks = trace.chunks.map { chunk ->
                        if (chunk.id != chunkId) {
                            chunk
                        } else {
                            chunk.copy(
                                title = summary.title,
                                detail = summary.detail,
                                isPending = false,
                            )
                        }
                    },
                    latestStatusText = latestStatusText,
                )
            }
        }
    }

    private val reasoningSummarizer = SessionReasoningSummarizer(
        settingsRepository = settingsRepository,
        piCompletionClient = piCompletionClient,
        currentSettings = currentSettings,
        currentProviderConfigs = currentProviderConfigs,
    )

    private fun currentReasoningTrace(
        sessionId: String,
        blockId: String,
    ): ReasoningTrace? =
        _executionStates.value[sessionId]?.pendingResponseBlocks
            ?.filterIsInstance<AssistantResponseBlock.Reasoning>()
            ?.firstOrNull { it.id == blockId }
            ?.trace

    private fun updateReasoningTrace(
        sessionId: String,
        blockId: String,
        transform: (ReasoningTrace) -> ReasoningTrace,
    ) {
        updateExecutionState(sessionId) { current ->
            current.copy(
                pendingResponseBlocks = current.pendingResponseBlocks.map { block ->
                    if (block is AssistantResponseBlock.Reasoning && block.id == blockId) {
                        block.copy(trace = transform(block.trace))
                    } else {
                        block
                    }
                }
            )
        }
        updatePersistedReasoningTrace(
            sessionId = sessionId,
            blockId = blockId,
            transform = transform,
        )
    }

    private fun updatePersistedReasoningTrace(
        sessionId: String,
        blockId: String,
        transform: (ReasoningTrace) -> ReasoningTrace,
    ) {
        val hasPersistedTrace = chatStateStore.state.value.sessions.any { session ->
            session.id == sessionId && session.messages.any { it.reasoningTrace?.id == blockId }
        }
        if (!hasPersistedTrace) return

        chatStateStore.update { persisted ->
            val sessionIndex = persisted.sessions.indexOfFirst { it.id == sessionId }
            if (sessionIndex < 0) return@update persisted

            val session = persisted.sessions[sessionIndex]
            var changed = false
            val updatedMessages = session.messages.map { message ->
                val trace = message.reasoningTrace
                if (trace == null || trace.id != blockId) {
                    message
                } else {
                    val updatedTrace = transform(trace)
                    if (updatedTrace == trace) {
                        message
                    } else {
                        changed = true
                        message.copy(
                            reasoningTrace = updatedTrace,
                            toolInvocations = updatedTrace.toolInvocations,
                        )
                    }
                }
            }
            if (!changed) return@update persisted

            val updatedSessions = persisted.sessions.toMutableList()
            updatedSessions[sessionIndex] = session.withDerivedMessages(updatedMessages)
            persisted.copy(sessions = updatedSessions)
        }
    }

    private fun upsertAssistantResponseToolInvocation(
        blocks: List<AssistantResponseBlock>,
        toolInvocation: ChatToolInvocation,
        reasoningBlockId: String?,
        newBlockId: () -> String,
    ): List<AssistantResponseBlock> {
        val existingReasoningIndex = blocks.indexOfFirst { block ->
            block is AssistantResponseBlock.Reasoning &&
                block.trace.toolInvocations.any { it.id == toolInvocation.id }
        }
        if (existingReasoningIndex >= 0) {
            val reasoningBlock = blocks[existingReasoningIndex] as AssistantResponseBlock.Reasoning
            return blocks.toMutableList().apply {
                set(
                    existingReasoningIndex,
                    reasoningBlock.copy(
                        trace = reasoningBlock.trace.copy(
                            toolInvocations = upsertToolInvocation(
                                reasoningBlock.trace.toolInvocations,
                                toolInvocation,
                            ),
                            latestStatusText = formatReasoningToolStatus(toolInvocation),
                        ),
                    )
                )
            }
        }

        val reasoningIndex = reasoningBlockId?.let { id ->
            blocks.indexOfFirst { it is AssistantResponseBlock.Reasoning && it.id == id }
        } ?: -1
        if (reasoningIndex >= 0) {
            val reasoningBlock = blocks[reasoningIndex] as AssistantResponseBlock.Reasoning
            return blocks.toMutableList().apply {
                set(
                    reasoningIndex,
                    reasoningBlock.copy(
                        trace = reasoningBlock.trace.copy(
                            toolInvocations = upsertToolInvocation(
                                reasoningBlock.trace.toolInvocations,
                                toolInvocation,
                            ),
                            latestStatusText = formatReasoningToolStatus(toolInvocation),
                        ),
                    )
                )
            }
        }

        val existingIndex = blocks.indexOfFirst { block ->
            block is AssistantResponseBlock.ToolGroup &&
                block.toolInvocations.any { it.id == toolInvocation.id }
        }
        if (existingIndex >= 0) {
            val toolBlock = blocks[existingIndex] as AssistantResponseBlock.ToolGroup
            return blocks.toMutableList().apply {
                set(
                    existingIndex,
                    toolBlock.copy(
                        toolInvocations = upsertToolInvocation(toolBlock.toolInvocations, toolInvocation),
                    ),
                )
            }
        }

        val lastBlock = blocks.lastOrNull()
        return if (lastBlock is AssistantResponseBlock.ToolGroup) {
            blocks.toMutableList().apply {
                set(
                    lastIndex,
                    lastBlock.copy(
                        toolInvocations = upsertToolInvocation(lastBlock.toolInvocations, toolInvocation),
                    ),
                )
            }
        } else {
            blocks + AssistantResponseBlock.ToolGroup(
                id = newBlockId(),
                toolInvocations = upsertToolInvocation(emptyList(), toolInvocation),
            )
        }
    }

    private fun pendingTrailingAssistantText(
        blocks: List<AssistantResponseBlock>,
    ): String = (blocks.lastOrNull() as? AssistantResponseBlock.Text)?.text.orEmpty()

    private fun ensureAssistantResponseFinalText(
        blocks: List<AssistantResponseBlock>,
        finalText: String,
        newBlockId: () -> String,
    ): List<AssistantResponseBlock> {
        if (finalText.isBlank()) return normalizeAssistantResponseBlocks(blocks)
        val normalized = normalizeAssistantResponseBlocks(blocks)
        return normalized.withAssistantFinalTextFallback(finalText, newBlockId)
    }

    private fun normalizeAssistantResponseBlocks(
        blocks: List<AssistantResponseBlock>,
    ): List<AssistantResponseBlock> = buildList {
        blocks.forEach { block ->
            when (block) {
                is AssistantResponseBlock.Text -> {
                    if (block.text.isBlank()) return@forEach
                    val previous = lastOrNull()
                    if (previous is AssistantResponseBlock.Text) {
                        removeAt(lastIndex)
                        add(previous.copy(text = previous.text + block.text))
                    } else {
                        add(block)
                    }
                }

                is AssistantResponseBlock.ToolGroup -> {
                    if (block.toolInvocations.isEmpty()) return@forEach
                    val previous = lastOrNull()
                    if (previous is AssistantResponseBlock.ToolGroup) {
                        removeAt(lastIndex)
                        add(
                            previous.copy(
                                toolInvocations = previous.toolInvocations + block.toolInvocations,
                            ),
                        )
                    } else {
                        add(block)
                    }
                }

                is AssistantResponseBlock.Reasoning -> {
                    if (
                        block.trace.rawText.isBlank() &&
                        block.trace.chunks.isEmpty() &&
                        block.trace.toolInvocations.isEmpty()
                    ) {
                        return@forEach
                    }
                    add(block)
                }

                is AssistantResponseBlock.Status -> if (block.text.isNotBlank()) add(block)
            }
        }
    }

    private fun List<AssistantResponseBlock>.toolInvocations(): List<ChatToolInvocation> =
        flatMap { block ->
            when (block) {
                is AssistantResponseBlock.ToolGroup -> block.toolInvocations
                is AssistantResponseBlock.Text -> emptyList()
                is AssistantResponseBlock.Reasoning -> block.trace.toolInvocations
                is AssistantResponseBlock.Status -> emptyList()
            }
        }.distinctBy { it.id }

    private fun finalizeInterruptedAssistantResponseBlocks(
        blocks: List<AssistantResponseBlock>,
    ): List<AssistantResponseBlock> = normalizeAssistantResponseBlocks(
        blocks.map { block ->
            when (block) {
                is AssistantResponseBlock.Text -> block
                is AssistantResponseBlock.Reasoning -> block.copy(
                    trace = block.trace.copy(
                        toolInvocations = finalizeInterruptedToolInvocations(block.trace.toolInvocations),
                        completedAtMillis = block.trace.completedAtMillis ?: System.currentTimeMillis(),
                    )
                )
                is AssistantResponseBlock.ToolGroup -> block.copy(
                    toolInvocations = finalizeInterruptedToolInvocations(block.toolInvocations),
                )
                is AssistantResponseBlock.Status -> block.copy(
                    text = completedReconnectStatus(block.text),
                )
            }
        }
    )

    private fun assistantResponseBlockSummaryText(
        block: AssistantResponseBlock,
    ): String = when (block) {
        is AssistantResponseBlock.Text -> block.text.trim()
        is AssistantResponseBlock.ToolGroup -> ChatMessage(
            id = block.id,
            author = MessageAuthor.Agent,
            text = "",
            toolInvocations = block.toolInvocations,
        ).summaryText()
        is AssistantResponseBlock.Reasoning -> block.trace.chunks.lastOrNull { chunk ->
            chunk.detail.isNotBlank() || chunk.title.isNotBlank()
        }?.let { chunk ->
            chunk.detail.ifBlank { chunk.title }
        } ?: "Thought for ${formatReasoningDurationLabel(block.trace)}"
        is AssistantResponseBlock.Status -> block.text
    }

    private fun finalizeInterruptedToolInvocations(
        invocations: List<ChatToolInvocation>,
    ): List<ChatToolInvocation> = invocations.map { invocation ->
        if (!isInterruptedToolInvocation(invocation)) {
            invocation
        } else {
            invocation.copy(
                isRunning = false,
                outputJson = buildInterruptedToolOutput(invocation),
                completedAtUptimeMillis = invocation.completedAtUptimeMillis ?: SystemClock.uptimeMillis(),
                completedAtMillis = invocation.completedAtMillis ?: System.currentTimeMillis(),
            )
        }
    }

    private fun isInterruptedToolInvocation(invocation: ChatToolInvocation): Boolean {
        if (invocation.isRunning) return true
        if (invocation.toolName.lowercase() != "bash") return false
        val output = parseJsonObject(invocation.outputJson) ?: return false
        return output.optString("status") == "running" || output.optString("status") == "launching"
    }

    private fun buildInterruptedToolOutput(invocation: ChatToolInvocation): String {
        val output = parseJsonObject(invocation.outputJson) ?: JSONObject()
        output.put("ok", false)
        output.put("status", "cancelled")
        output.put("running", false)
        output.put("completed", true)
        if (!output.has("stdout")) output.put("stdout", "")
        if (!output.has("stderr")) output.put("stderr", "")
        if (!output.has("exit_code")) output.put("exit_code", 143)
        if (!output.has("err")) output.put("err", -1)
        output.put("errmsg", "Stopped by user.")
        return output.toString()
    }

    private fun extractActiveManagedRunIds(
        invocations: List<ChatToolInvocation>,
    ): List<String> = invocations.mapNotNull { invocation ->
        if (invocation.toolName.lowercase() != "bash") return@mapNotNull null
        val output = parseJsonObject(invocation.outputJson) ?: return@mapNotNull null
        val status = output.optString("status")
        if (status != "running" && status != "launching") {
            return@mapNotNull null
        }
        output.optString("run_id").trim().ifBlank { null }
    }.distinct()

    private fun estimateRequestTokenUsage(request: SessionTurnRequest): LlmTokenUsage =
        SessionContextBuilder.estimateRequestTokenUsage(request)

    private fun parseJsonObject(rawValue: String): JSONObject? =
        if (rawValue.isBlank()) null else runCatching { JSONObject(rawValue) }.getOrNull()

    private fun approximateReasoningTokenCount(text: String): Int =
        SessionContextBuilder.approximateTokenCount(text)

    private data class PendingEnvelope(
        val id: String,
        val mode: SessionFollowUpMode,
        val message: ChatMessage,
    ) {
        fun toUiState(): PendingSessionInput = PendingSessionInput(
            id = id,
            mode = mode,
            preview = message.summaryText().take(72),
            attachmentCount = message.attachments.size,
        )
    }

    private data class CompletionSummary(
        val sessionTitle: String,
        val summary: String,
        val outcome: SessionTurnOutcome,
        val toolCallCount: Int,
        val distinctToolCount: Int,
        val toolNames: List<String>,
        val durationMillis: Long?,
        val tokenUsage: LlmTokenUsage? = null,
        val tokenUsageSource: String = "unavailable",
        val inputMessageCount: Int = 0,
        val userMessageCount: Int = 0,
        val appendedMessageIds: List<String> = emptyList(),
        val lastAssistantMessageId: String = "",
        val lastAssistantText: String = "",
        val piSessionId: String = "",
        val piSessionFile: String = "",
        val piRuntime: String = "",
        val piEntryIds: List<String> = emptyList(),
    ) {
        fun toTurnEvent(sessionId: String): SessionTurnEvent = SessionTurnEvent(
            sessionId = sessionId,
            outcome = outcome,
            toolCallCount = toolCallCount,
            distinctToolCount = distinctToolCount,
            toolNames = toolNames,
            durationMillis = durationMillis,
            tokenUsage = tokenUsage,
            tokenUsageSource = tokenUsageSource,
            inputMessageCount = inputMessageCount,
            userMessageCount = userMessageCount,
        )
    }

    private class SessionExecutionHandle(
        val sessionId: String,
    ) {
        val lock = Any()
        val queuedInputs = ArrayDeque<PendingEnvelope>()
        val steerInputs = ArrayDeque<PendingEnvelope>()
        private var retainedMessages: List<ChatMessage> = emptyList()
        private var pendingBlockCounter: Long = 0
        private var reasoningChunkCounter: Long = 0
        private var reasoningTimelineCounter: Long = 0
        @Volatile
        var activeReasoningBlockId: String? = null
        @Volatile
        var activeDirectReasoningSummaryChunkId: String? = null
        @Volatile
        var reasoningFirstSummarySubmitted: Boolean = false
        @Volatile
        var reasoningLastSubmittedCharIndex: Int = 0
        @Volatile
        var reasoningLastTimedSummaryAtMillis: Long = 0L
        @Volatile
        var activeResponseIdentity: AssistantResponseIdentity? = null
        var lastAssistantCheckpointUptimeMillis: Long? = null
        var assistantCheckpointJob: Job? = null

        @Volatile
        var pauseRequested: Boolean = false

        @Volatile
        var pauseFinalized: Boolean = false

        @Volatile
        var job: Job? = null

        fun nextPendingBlockId(prefix: String): String = synchronized(lock) {
            val nextId = pendingBlockCounter
            pendingBlockCounter += 1
            "$prefix-$sessionId-$nextId"
        }

        fun nextReasoningChunkId(blockId: String): String = synchronized(lock) {
            val nextId = reasoningChunkCounter
            reasoningChunkCounter += 1
            "$blockId-summary-$nextId"
        }

        fun nextReasoningTimelineOrder(): Long = synchronized(lock) {
            reasoningTimelineCounter += 1
            reasoningTimelineCounter
        }

        fun startReasoningBlock(blockId: String, nowMillis: Long) = synchronized(lock) {
            activeReasoningBlockId = blockId
            activeDirectReasoningSummaryChunkId = null
            reasoningFirstSummarySubmitted = false
            reasoningLastSubmittedCharIndex = 0
            reasoningLastTimedSummaryAtMillis = nowMillis
        }

        fun finishDirectReasoningSummaryChunk() = synchronized(lock) {
            activeDirectReasoningSummaryChunkId = null
        }

        fun finishReasoningBlock() = synchronized(lock) {
            activeReasoningBlockId = null
            activeDirectReasoningSummaryChunkId = null
            reasoningFirstSummarySubmitted = false
            reasoningLastSubmittedCharIndex = 0
            reasoningLastTimedSummaryAtMillis = 0L
        }

        fun retainedMessagesSnapshot(): List<ChatMessage> = synchronized(lock) {
            retainedMessages
        }

        fun replaceRetainedMessages(messages: List<ChatMessage>) {
            synchronized(lock) {
                retainedMessages = messages
            }
        }
    }
}

internal data class TurnSkillSelection(
    val selectedSkillIds: List<String>,
    val activeSkills: List<ActiveSkillContext>,
)

internal fun buildMultiStepAutomationObjective(task: ScheduledTask): String = buildString {
    append("Automation '")
    append(task.name.replace('\'', ' '))
    append("': run the following steps end-to-end, verifying each result.\n")
    if (task.condition.isNotBlank()) {
        append("PRECONDITION (check first with real data; if it is false, finish with a short ")
        append("'skipped' report and do nothing else): ")
        append(task.condition.trim())
        append('\n')
    }
    append("STEPS (in order, later steps may build on earlier results):\n")
    runCatching {
        val array = org.json.JSONArray(task.stepsJson)
        for (index in 0 until array.length()) {
            val step = array.optJSONObject(index) ?: continue
            val prompt = step.optString("prompt").trim()
            if (prompt.isEmpty()) continue
            append(index + 1)
            append(". ")
            append(prompt)
            append('\n')
        }
    }
    if (isEmpty() || endsWith("STEPS (in order, later steps may build on earlier results):\n")) {
        append("1. ")
        append(task.prompt)
        append('\n')
    }
}

internal fun resolveTurnSkillSelectionForTest(
    explicitActiveSkills: List<ActiveSkillContext>,
    implicitActiveSkills: List<ActiveSkillContext>,
): TurnSkillSelection {
    val normalizedExplicitSkills = explicitActiveSkills.distinctBy { it.skillId }
    return TurnSkillSelection(
        selectedSkillIds = normalizedExplicitSkills.map { it.skillId },
        activeSkills = (normalizedExplicitSkills + implicitActiveSkills).distinctBy { it.skillId },
    )
}
