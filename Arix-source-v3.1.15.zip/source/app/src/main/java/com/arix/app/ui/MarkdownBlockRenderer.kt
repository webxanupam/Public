package com.arix.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import com.arix.app.ui.theme.ArixOnSurface
import com.arix.app.ui.theme.ArixOutlineSoft

internal const val DefaultTextBlockMinHeightDp = 24

internal const val DefaultTextBlockMaxHeightDp = 2048

@Composable
fun MarkdownContent(
    markdown: String,
    modifier: Modifier = Modifier,
    color: Color = ArixOnSurface,
    workspaceDirectory: String? = null,
    allowRootImageRead: Boolean = false,
    onLinkClick: (String) -> Unit = {},
) {
    StreamingRevealContent(source = markdown, isStreaming = false) { revealedMarkdown ->
        MarkdownContentBlocks(
            markdown = revealedMarkdown,
            modifier = modifier,
            color = color,
            workspaceDirectory = workspaceDirectory,
            allowRootImageRead = allowRootImageRead,
            onLinkClick = onLinkClick,
        )
    }
}

@Composable
private fun MarkdownContentBlocks(
    markdown: String,
    modifier: Modifier = Modifier,
    color: Color = ArixOnSurface,
    workspaceDirectory: String? = null,
    allowRootImageRead: Boolean = false,
    onLinkClick: (String) -> Unit = {},
) {
    val parseCache = remember { StreamingMarkdownParseCache() }
    val normalizedMarkdown = remember(markdown) { markdown.replace("\r\n", "\n") }
    val blocks = remember(normalizedMarkdown) { parseMarkdownIncremental(normalizedMarkdown, parseCache) }

    SelectionContainer {
        Column(
            modifier = modifier,
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            blocks.forEach { block ->
                when (block) {
                    is MarkdownBlock.Paragraph -> {
                        MarkdownParagraph(block.text, color, onLinkClick)
                    }

                    is MarkdownBlock.Heading -> {
                        MarkdownHeading(block.level, block.text, onLinkClick)
                    }

                    is MarkdownBlock.UnorderedList -> {
                        MarkdownBullets(block.items, onLinkClick)
                    }

                    is MarkdownBlock.OrderedList -> {
                        MarkdownNumbers(block.items, onLinkClick)
                    }

                    is MarkdownBlock.Quote -> {
                        MarkdownQuote(block.text, onLinkClick)
                    }

                    is MarkdownBlock.Table -> {
                        MarkdownTable(block.headers, block.rows, onLinkClick)
                    }

                    is MarkdownBlock.CodeFence -> {
                        MarkdownCodeFence(block.code, block.language)
                    }

                    is MarkdownBlock.Image -> MarkdownImageBlock(
                        image = block.image,
                        workspaceDirectory = workspaceDirectory,
                        allowRootImageRead = allowRootImageRead,
                        onLinkClick = onLinkClick,
                    )

                    is MarkdownBlock.ImageGroup -> MarkdownImageGroup(block.images)
                    is MarkdownBlock.LocalFile -> MarkdownLocalFileBlock(
                        path = block.path,
                        workspaceDirectory = workspaceDirectory,
                    )
                    is MarkdownBlock.RemoteFile -> MarkdownRemoteFileBlock(
                        url = block.url,
                        onLinkClick = onLinkClick,
                    )
                    is MarkdownBlock.MediaLink -> MarkdownMediaLinkBlock(
                        spec = block.spec,
                        onLinkClick = onLinkClick,
                    )
                    is MarkdownBlock.LinkCard -> MarkdownLinkCardBlock(
                        url = block.url,
                        onLinkClick = onLinkClick,
                    )
                    is MarkdownBlock.MagnetLink -> MarkdownMagnetLinkBlock(
                        uri = block.uri,
                    )
                    is MarkdownBlock.EmbedFrame -> MarkdownEmbedFrameBlock(
                        spec = block.spec,
                        onLinkClick = onLinkClick,
                    )
                    is MarkdownBlock.Mermaid -> MarkdownMermaidBlock(block.diagram)
                    MarkdownBlock.Rule -> HorizontalDivider(color = ArixOutlineSoft)
                }
            }
        }
    }
}

@Composable
private fun MarkdownParagraph(
    text: MarkdownSourceText,
    color: Color,
    onLinkClick: (String) -> Unit,
) {
    MarkdownRichTextBlock(
        text = text,
        style = MaterialTheme.typography.bodyLarge,
        color = color,
        onLinkClick = onLinkClick,
        variant = MarkdownHtmlTextVariant.Paragraph,
    )
}

@Composable
private fun MarkdownHeading(
    level: Int,
    text: MarkdownSourceText,
    onLinkClick: (String) -> Unit,
) {
    val style = when (level) {
        1 -> MaterialTheme.typography.headlineMedium
        2 -> MaterialTheme.typography.titleLarge
        3 -> MaterialTheme.typography.titleMedium
        else -> MaterialTheme.typography.labelLarge
    }

    MarkdownRichTextBlock(
        text = text,
        style = style,
        color = ArixOnSurface,
        onLinkClick = onLinkClick,
        variant = MarkdownHtmlTextVariant.Heading(level),
    )
}

@Composable
private fun MarkdownBullets(
    items: List<MarkdownSourceText>,
    onLinkClick: (String) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEach { item ->
            Row(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "\u2022",
                    style = MaterialTheme.typography.bodyLarge,
                    color = ArixOnSurface,
                    modifier = Modifier.streamingBlockReveal(item.sourceOffset),
                )
                Spacer(modifier = Modifier.width(10.dp))
                MarkdownRichTextBlock(
                    text = item,
                    style = MaterialTheme.typography.bodyLarge,
                    color = ArixOnSurface,
                    modifier = Modifier.weight(1f),
                    onLinkClick = onLinkClick,
                    variant = MarkdownHtmlTextVariant.ListItem,
                )
            }
        }
    }
}

@Composable
private fun MarkdownNumbers(
    items: List<MarkdownSourceText>,
    onLinkClick: (String) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEachIndexed { index, item ->
            Row(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "${index + 1}.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = ArixOnSurface,
                    modifier = Modifier.streamingBlockReveal(item.sourceOffset),
                )
                Spacer(modifier = Modifier.width(10.dp))
                MarkdownRichTextBlock(
                    text = item,
                    style = MaterialTheme.typography.bodyLarge,
                    color = ArixOnSurface,
                    modifier = Modifier.weight(1f),
                    onLinkClick = onLinkClick,
                    variant = MarkdownHtmlTextVariant.ListItem,
                )
            }
        }
    }
}

@Composable
private fun MarkdownQuote(
    text: MarkdownSourceText,
    onLinkClick: (String) -> Unit,
) {
    Row(modifier = Modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .width(4.dp)
                .background(ArixOutlineSoft, RoundedCornerShape(999.dp))
        )
        Spacer(modifier = Modifier.width(12.dp))
        MarkdownRichTextBlock(
            text = text,
            style = MaterialTheme.typography.bodyLarge,
            color = ArixOnSurface,
            modifier = Modifier.weight(1f),
            onLinkClick = onLinkClick,
            variant = MarkdownHtmlTextVariant.Quote,
        )
    }
}

@Composable
internal fun MarkdownRichTextBlock(
    text: MarkdownSourceText,
    style: TextStyle,
    color: Color,
    onLinkClick: (String) -> Unit,
    variant: MarkdownHtmlTextVariant,
    modifier: Modifier = Modifier,
) {
    val shouldUseMathHtml = remember(text.text) {
        containsRenderableMarkdownMath(text.text)
    }
    if (shouldUseMathHtml) {
        MarkdownTextHtmlBlock(
            text = text.text,
            variant = variant,
            modifier = modifier,
            onLinkClick = onLinkClick,
        )
        return
    }

    val inlineAnnotated = remember(text.text, text.sourceOffset) {
        inlineMarkdown(text.text, text.sourceOffset)
    }
    MarkdownText(
        text = inlineAnnotated,
        style = style,
        color = color,
        modifier = modifier,
        onLinkClick = onLinkClick,
    )
}

@Composable
private fun MarkdownText(
    text: AnnotatedString,
    style: androidx.compose.ui.text.TextStyle,
    color: Color,
    modifier: Modifier = Modifier,
    onLinkClick: (String) -> Unit,
) {
    val hasLinks = text.getStringAnnotations(
        tag = LinkAnnotationTag,
        start = 0,
        end = text.length,
    ).isNotEmpty()

    if (!hasLinks) {
        RevealingMarkdownText(
            text = text,
            style = style.copy(textDirection = TextDirection.Content),
            color = color,
            modifier = modifier,
        )
        return
    }

    RevealingMarkdownText(
        text = text,
        style = style.copy(textDirection = TextDirection.Content),
        color = color,
        modifier = modifier,
        onClick = { offset ->
            text.getStringAnnotations(
                tag = LinkAnnotationTag,
                start = offset,
                end = offset,
            ).firstOrNull()?.let { annotation ->
                onLinkClick(annotation.item)
            }
        },
    )
}
