package com.arix.app.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.webkit.MimeTypeMap
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.arix.app.media.ArixMediaItem
import com.arix.app.media.ArixMediaKind
import com.arix.app.media.ArixPlaybackController
import com.arix.app.ui.theme.ArixOnSurface
import com.arix.app.ui.theme.ArixOnSurfaceVariant
import com.arix.app.ui.theme.ArixPrimary
import com.arix.app.ui.theme.ArixSurface
import java.io.File
import java.text.DateFormat
import java.util.Date
import java.util.zip.ZipFile
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val ViewerMaxStageBytes = 96L * 1024 * 1024
private const val ViewerMaxTextBytes = 512 * 1024
private const val ViewerMaxTextLines = 50_000
private const val ViewerTextChunkChars = 2_000
private const val ViewerHexBytes = 4096
private const val ViewerMaxZipEntries = 5_000
private const val ViewerMaxImageDimensionPx = 2048
private const val ViewerMaxPdfPageWidthPx = 1600

private val viewerImageExtensions = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp")
private val viewerVideoExtensions = setOf("mp4", "mkv", "webm", "mov", "m4v", "3gp", "avi", "ts", "m3u8")
private val viewerAudioExtensions = setOf("mp3", "m4a", "aac", "wav", "flac", "ogg", "oga", "opus", "amr", "mid", "midi")
private val viewerPdfExtensions = setOf("pdf")
private val viewerZipExtensions = setOf("zip", "apk", "jar", "aar", "apks", "xapk", "war")
private val viewerTextExtensions = setOf(
    "txt", "md", "markdown", "log", "csv", "tsv", "json", "jsonl", "xml", "html", "htm", "css", "svg",
    "yaml", "yml", "toml", "ini", "cfg", "conf", "properties", "env", "gradle", "kts", "kt", "java",
    "js", "mjs", "cjs", "ts", "tsx", "jsx", "py", "rb", "go", "rs", "c", "h", "cpp", "hpp", "cc", "cs",
    "swift", "php", "sh", "bash", "zsh", "fish", "bat", "ps1", "sql", "lua", "pl", "r", "dart", "vue",
    "gitignore", "gitattributes", "editorconfig", "dockerfile", "makefile", "lock", "diff", "patch", "tex", "rst",
)

private enum class ArixViewerKind { Image, Video, Audio, Pdf, Text, Zip }

private fun viewerExtension(name: String): String = name.substringAfterLast('.', "").lowercase()

private fun viewerKind(name: String): ArixViewerKind {
    val ext = viewerExtension(name)
    val lower = name.lowercase()
    return when {
        ext in viewerImageExtensions -> ArixViewerKind.Image
        ext in viewerVideoExtensions -> ArixViewerKind.Video
        ext in viewerAudioExtensions -> ArixViewerKind.Audio
        ext in viewerPdfExtensions -> ArixViewerKind.Pdf
        ext in viewerZipExtensions -> ArixViewerKind.Zip
        // v3.1.14 — every other file previews natively as text; the viewer
        // probes for binary content and falls back to a hex dump, so no file
        // is ever a dead end.
        else -> ArixViewerKind.Text
    }
}

internal fun arixFileViewerIsText(name: String): Boolean = viewerKind(name) == ArixViewerKind.Text


private fun viewerMimeType(name: String): String =
    MimeTypeMap.getSingleton().getMimeTypeFromExtension(viewerExtension(name))
        ?: if (viewerKind(name) == ArixViewerKind.Text) "text/plain" else "application/octet-stream"

private fun formatViewerSize(bytes: Long): String {
    if (bytes < 0L) return "unknown size"
    if (bytes < 1024L) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024.0) return String.format("%.1f KB", kb)
    val mb = kb / 1024.0
    if (mb < 1024.0) return String.format("%.1f MB", mb)
    return String.format("%.2f GB", mb / 1024.0)
}

private class ArixViewerSource(
    val name: String,
    val size: Long,
    val modifiedAtMillis: Long,
    private val hostFile: suspend () -> File?,
    val readPrefix: suspend (Long) -> ByteArray,
) {
    private var staged: File? = null

    suspend fun localFile(context: Context): File = withContext(Dispatchers.IO) {
        staged?.takeIf { it.isFile }?.let { return@withContext it }
        val host = runCatching { hostFile() }.getOrNull()
        if (host != null && host.isFile && host.canRead()) {
            return@withContext host
        }
        check(size < 0L || size <= ViewerMaxStageBytes) { "This file is too large to preview." }
        val bytes = readPrefix(ViewerMaxStageBytes)
        val dir = File(context.cacheDir, "file-viewer").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val safeName = name.replace(Regex("[^A-Za-z0-9._ ()-]"), "_").ifBlank { "arix-file" }
        val target = File(dir, safeName)
        target.writeBytes(bytes)
        staged = target
        target
    }
}

private sealed interface ViewerLoad<out T> {
    object Loading : ViewerLoad<Nothing>
    class Ready<T>(val value: T) : ViewerLoad<T>
    class Failed(val message: String) : ViewerLoad<Nothing>
}

@Composable
private fun <T> ViewerLoader(
    key: Any?,
    onShare: () -> Unit,
    loader: suspend () -> T,
    content: @Composable (T) -> Unit,
) {
    var state by remember(key) { mutableStateOf<ViewerLoad<T>>(ViewerLoad.Loading) }
    LaunchedEffect(key) {
        state = try {
            ViewerLoad.Ready(withContext(Dispatchers.IO) { loader() })
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (failure: Throwable) {
            ViewerLoad.Failed(failure.message ?: failure.javaClass.simpleName)
        }
    }
    when (val current = state) {
        is ViewerLoad.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = ArixPrimary)
        }
        is ViewerLoad.Failed -> Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text(
                "Unable to preview this file",
                style = MaterialTheme.typography.titleSmall,
                color = ArixOnSurface,
            )
            Text(
                current.message,
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 8.dp, bottom = 16.dp),
            )
            OutlinedButton(onClick = onShare) { Text("Share") }
        }
        is ViewerLoad.Ready -> content(current.value)
    }
}

@Composable
internal fun ArixFileViewer(
    name: String,
    size: Long,
    modifiedAtMillis: Long,
    hostFile: suspend () -> File?,
    readPrefix: suspend (Long) -> ByteArray,
    onEdit: (() -> Unit)?,
    onDismiss: () -> Unit,
    onExtract: ((destinationName: String) -> Unit)? = null,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val source = remember(name, size, modifiedAtMillis) {
        ArixViewerSource(name, size, modifiedAtMillis, hostFile, readPrefix)
    }
    val kind = remember(name) { viewerKind(name) }
    val mime = remember(name) { viewerMimeType(name) }
    var menuOpen by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf<String?>(null) }

    fun share() {
        scope.launch {
            val ok = runCatching {
                val staged = stageViewerFileForExternal(context, source)
                ArixMediaActions.shareStagedFile(context, staged, mime)
            }.getOrDefault(false)
            notice = if (ok) null else "Unable to share this file."
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = ArixSurface) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Rounded.Close, "Close", tint = ArixOnSurface)
                    }
                    Column(modifier = Modifier.weight(1f).padding(horizontal = 4.dp)) {
                        Text(
                            name,
                            style = MaterialTheme.typography.titleMedium,
                            color = ArixOnSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            formatViewerSize(size) + "  " + mime,
                            style = MaterialTheme.typography.labelSmall,
                            color = ArixOnSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    if (onEdit != null) {
                        IconButton(onClick = onEdit) {
                            Icon(Icons.Rounded.Edit, "Edit", tint = ArixOnSurface)
                        }
                    }
                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Icon(Icons.Rounded.MoreVert, "More", tint = ArixOnSurface)
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text("Share") },
                                onClick = { menuOpen = false; share() },
                            )
                        }
                    }
                }
                notice?.let {
                    Text(
                        it,
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                    )
                }
                Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    when (kind) {
                        ArixViewerKind.Image -> ViewerImageContent(source, ::share)
                        ArixViewerKind.Video -> ViewerMediaContent(source, video = true, onShare = ::share)
                        ArixViewerKind.Audio -> ViewerMediaContent(source, video = false, onShare = ::share)
                        ArixViewerKind.Pdf -> ViewerPdfContent(source, ::share)
                        ArixViewerKind.Text -> ViewerTextContent(source, mime, ::share)
                        ArixViewerKind.Zip -> ViewerZipContent(source, ::share, onExtract)
                    }
                }
            }
        }
    }
}

private suspend fun stageViewerFileForExternal(context: Context, source: ArixViewerSource): File {
    val bytesFile = source.localFile(context)
    val dir = File(context.cacheDir, "assistant-local-open").apply { mkdirs() }
    val safeName = source.name.replace(Regex("[^A-Za-z0-9._ ()-]"), "_").ifBlank { "arix-file" }
    val target = File(dir, safeName)
    if (bytesFile.absolutePath != target.absolutePath) {
        withContext(Dispatchers.IO) { bytesFile.copyTo(target, overwrite = true) }
    }
    return target
}

@Composable
private fun ViewerImageContent(source: ArixViewerSource, onShare: () -> Unit) {
    val context = LocalContext.current
    ViewerLoader(
        key = source,
        onShare = onShare,
        loader = {
            val file = source.localFile(context)
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            check(bounds.outWidth > 0 && bounds.outHeight > 0) { "Unsupported or corrupt image." }
            var sample = 1
            var width = bounds.outWidth
            var height = bounds.outHeight
            while (maxOf(width, height) > ViewerMaxImageDimensionPx) {
                width /= 2
                height /= 2
                sample *= 2
            }
            val options = BitmapFactory.Options().apply { inSampleSize = sample }
            BitmapFactory.decodeFile(file.absolutePath, options) ?: error("Unable to decode image.")
        },
    ) { bitmap ->
        var scale by remember(bitmap) { mutableStateOf(1f) }
        var offset by remember(bitmap) { mutableStateOf(Offset.Zero) }
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
                .pointerInput(bitmap) {
                    detectTapGestures(onDoubleTap = {
                        scale = 1f
                        offset = Offset.Zero
                    })
                }
                .pointerInput(bitmap) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        scale = (scale * zoom).coerceIn(1f, 8f)
                        offset = if (scale <= 1f) Offset.Zero else offset + pan
                    }
                },
            contentAlignment = Alignment.Center,
        ) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(
                        scaleX = scale,
                        scaleY = scale,
                        translationX = offset.x,
                        translationY = offset.y,
                    ),
            )
        }
    }
}

@Composable
private fun ViewerMediaContent(source: ArixViewerSource, video: Boolean, onShare: () -> Unit) {
    val context = LocalContext.current
    DisposableEffect(source) {
        onDispose { runCatching { ArixPlaybackController.stop() } }
    }
    ViewerLoader(
        key = source,
        onShare = onShare,
        loader = { source.localFile(context) },
    ) { file ->
        val url = remember(file) { android.net.Uri.fromFile(file).toString() }
        if (video) {
            Box(
                modifier = Modifier.fillMaxSize().background(Color.Black),
                contentAlignment = Alignment.Center,
            ) {
                ArixVideoPlayer(streamUrl = url)
            }
        } else {
            LaunchedEffect(url) {
                ArixPlaybackController.initialize(context.applicationContext)
                ArixPlaybackController.playNow(
                    ArixMediaItem(
                        id = "viewer:$url",
                        title = source.name,
                        kind = ArixMediaKind.Audio,
                        streamUrl = url,
                        sourceName = "File",
                    ),
                )
            }
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                ArixNativePlayerCard(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    showQueue = false,
                )
            }
        }
    }
}

private class ViewerPdfHolder(
    private val descriptor: ParcelFileDescriptor,
    private val renderer: PdfRenderer,
) {
    private val lock = Any()
    private var closed = false
    val pageCount: Int = renderer.pageCount

    fun render(index: Int, widthPx: Int): Bitmap? = synchronized(lock) {
        if (closed || index < 0 || index >= pageCount) return@synchronized null
        runCatching {
            val page = renderer.openPage(index)
            try {
                val width = widthPx.coerceIn(1, ViewerMaxPdfPageWidthPx)
                val height = (width.toFloat() * page.height / page.width.coerceAtLeast(1)).toInt().coerceAtLeast(1)
                val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                bitmap.eraseColor(android.graphics.Color.WHITE)
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                bitmap
            } finally {
                page.close()
            }
        }.getOrNull()
    }

    fun close() {
        synchronized(lock) {
            if (closed) return
            closed = true
            runCatching { renderer.close() }
            runCatching { descriptor.close() }
        }
    }
}

@Composable
private fun ViewerPdfContent(source: ArixViewerSource, onShare: () -> Unit) {
    val context = LocalContext.current
    ViewerLoader(
        key = source,
        onShare = onShare,
        loader = {
            val file = source.localFile(context)
            val descriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            try {
                ViewerPdfHolder(descriptor, PdfRenderer(descriptor))
            } catch (failure: Throwable) {
                runCatching { descriptor.close() }
                throw failure
            }
        },
    ) { holder ->
        DisposableEffect(holder) {
            onDispose { holder.close() }
        }
        LazyColumn(
            modifier = Modifier.fillMaxSize().background(Color(0xFF3A3A3A)),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(count = holder.pageCount, key = { it }) { index ->
                ViewerPdfPage(holder, index)
            }
        }
    }
}

@Composable
private fun ViewerPdfPage(holder: ViewerPdfHolder, index: Int) {
    val density = LocalDensity.current
    BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
        val widthPx = with(density) { maxWidth.roundToPx() }
        var bitmap by remember(holder, index, widthPx) { mutableStateOf<Bitmap?>(null) }
        LaunchedEffect(holder, index, widthPx) {
            bitmap = withContext(Dispatchers.IO) { holder.render(index, widthPx) }
        }
        DisposableEffect(holder, index, widthPx) {
            onDispose {
                val old = bitmap
                bitmap = null
                if (old != null && !old.isRecycled) old.recycle()
            }
        }
        val current = bitmap
        if (current != null && !current.isRecycled) {
            Image(
                bitmap = current.asImageBitmap(),
                contentDescription = "Page ${index + 1}",
                contentScale = ContentScale.FillWidth,
                modifier = Modifier.fillMaxWidth(),
            )
        } else {
            Box(
                modifier = Modifier.fillMaxWidth().height(420.dp).background(Color.White),
                contentAlignment = Alignment.Center,
            ) {
                CircularProgressIndicator(color = ArixPrimary)
            }
        }
    }
}

private class ViewerTextResult(
    val lines: List<String>,
    val truncated: Boolean,
    val binary: Boolean,
)

@Composable
private fun ViewerTextContent(source: ArixViewerSource, mime: String, onShare: () -> Unit) {
    ViewerLoader(
        key = source,
        onShare = onShare,
        loader = {
            val bytes = source.readPrefix((ViewerMaxTextBytes + 1).toLong())
            val byteTruncated = bytes.size > ViewerMaxTextBytes
            val used = if (byteTruncated) bytes.copyOf(ViewerMaxTextBytes) else bytes
            val probe = minOf(used.size, ViewerHexBytes)
            var binary = false
            for (i in 0 until probe) {
                if (used[i].toInt() == 0) {
                    binary = true
                    break
                }
            }
            if (binary) {
                ViewerTextResult(emptyList(), byteTruncated, true)
            } else {
                val text = String(used, Charsets.UTF_8)
                val lines = ArrayList<String>()
                var lineTruncated = false
                for (line in text.lineSequence()) {
                    if (line.length > ViewerTextChunkChars) {
                        var start = 0
                        while (start < line.length) {
                            lines.add(line.substring(start, minOf(start + ViewerTextChunkChars, line.length)))
                            start += ViewerTextChunkChars
                            if (lines.size >= ViewerMaxTextLines) break
                        }
                    } else {
                        lines.add(line)
                    }
                    if (lines.size >= ViewerMaxTextLines) {
                        lineTruncated = true
                        break
                    }
                }
                ViewerTextResult(lines, byteTruncated || lineTruncated, false)
            }
        },
    ) { result ->
        if (result.binary) {
            ViewerInfoContent(source, mime)
        } else {
            Column(Modifier.fillMaxSize()) {
                if (result.truncated) {
                    Text(
                        "Showing only the first part of this file (truncated at 512 KB).",
                        style = MaterialTheme.typography.labelSmall,
                        color = ArixPrimary,
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
                    )
                }
                SelectionContainer(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
                    ) {
                        itemsIndexed(result.lines, key = { index, _ -> index }) { _, line ->
                            Text(
                                text = line.ifEmpty { " " },
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp,
                                lineHeight = 16.sp,
                                color = ArixOnSurface,
                            )
                        }
                    }
                }
            }
        }
    }
}

private class ViewerZipEntry(val name: String, val size: Long, val directory: Boolean)

private class ViewerZipResult(val entries: List<ViewerZipEntry>, val total: Int)

@Composable
private fun ViewerZipContent(
    source: ArixViewerSource,
    onShare: () -> Unit,
    onExtract: ((destinationName: String) -> Unit)?,
) {
    val context = LocalContext.current
    ViewerLoader(
        key = source,
        onShare = onShare,
        loader = {
            val file = source.localFile(context)
            ZipFile(file).use { zip ->
                val entries = ArrayList<ViewerZipEntry>()
                var total = 0
                val enumeration = zip.entries()
                while (enumeration.hasMoreElements()) {
                    val entry = enumeration.nextElement()
                    total++
                    if (entries.size < ViewerMaxZipEntries) {
                        entries.add(ViewerZipEntry(entry.name, entry.size, entry.isDirectory))
                    }
                }
                ViewerZipResult(entries, total)
            }
        },
    ) { result ->
        Column(Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    if (result.total > result.entries.size) {
                        "${result.total} entries (showing the first ${result.entries.size})"
                    } else {
                        "${result.total} entries"
                    },
                    style = MaterialTheme.typography.labelMedium,
                    color = ArixOnSurfaceVariant,
                    modifier = Modifier.weight(1f),
                )
                if (onExtract != null && result.entries.isNotEmpty()) {
                    Button(
                        onClick = { onExtract(source.name.substringBeforeLast('.')) },
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(
                            horizontal = 14.dp,
                            vertical = 6.dp,
                        ),
                    ) { Text("Extract") }
                }
            }
            LazyColumn(modifier = Modifier.weight(1f).fillMaxWidth()) {
                itemsIndexed(result.entries, key = { index, _ -> index }) { _, entry ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            entry.name,
                            style = MaterialTheme.typography.bodySmall,
                            color = ArixOnSurface,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f),
                        )
                        Text(
                            if (entry.directory) "folder" else formatViewerSize(entry.size),
                            style = MaterialTheme.typography.labelSmall,
                            color = ArixOnSurfaceVariant,
                            modifier = Modifier.padding(start = 12.dp),
                        )
                    }
                }
            }
        }
    }
}

private fun viewerHexDump(bytes: ByteArray): List<String> {
    val lines = ArrayList<String>()
    var offset = 0
    while (offset < bytes.size) {
        val end = minOf(offset + 16, bytes.size)
        val builder = StringBuilder()
        builder.append(String.format("%08x  ", offset))
        for (i in offset until offset + 16) {
            if (i < end) {
                builder.append(String.format("%02x ", bytes[i].toInt() and 0xff))
            } else {
                builder.append("   ")
            }
        }
        builder.append(' ')
        for (i in offset until end) {
            val value = bytes[i].toInt() and 0xff
            builder.append(if (value in 32..126) value.toChar() else '.')
        }
        lines.add(builder.toString())
        offset = end
    }
    return lines
}

@Composable
private fun ViewerInfoContent(source: ArixViewerSource, mime: String) {
    ViewerLoader(
        key = source,
        onShare = {},
        loader = { viewerHexDump(source.readPrefix(ViewerHexBytes.toLong())) },
    ) { hexLines ->
        val modified = remember(source) {
            if (source.modifiedAtMillis > 0L) {
                DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)
                    .format(Date(source.modifiedAtMillis))
            } else {
                "unknown"
            }
        }
        Column(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                Text("Name: ${source.name}", style = MaterialTheme.typography.bodySmall, color = ArixOnSurface)
                Text("Size: ${formatViewerSize(source.size)}", style = MaterialTheme.typography.bodySmall, color = ArixOnSurface)
                Text("Modified: $modified", style = MaterialTheme.typography.bodySmall, color = ArixOnSurface)
                Text("Type: $mime", style = MaterialTheme.typography.bodySmall, color = ArixOnSurface)
                Text(
                    "Hex preview (first 4 KB)",
                    style = MaterialTheme.typography.labelMedium,
                    color = ArixOnSurfaceVariant,
                    modifier = Modifier.padding(top = 12.dp),
                )
            }
            SelectionContainer(modifier = Modifier.weight(1f).fillMaxWidth()) {
                LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
                    itemsIndexed(hexLines, key = { index, _ -> index }) { _, line ->
                        Text(
                            text = line,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            lineHeight = 15.sp,
                            color = ArixOnSurface,
                            softWrap = false,
                        )
                    }
                }
            }
        }
    }
}
