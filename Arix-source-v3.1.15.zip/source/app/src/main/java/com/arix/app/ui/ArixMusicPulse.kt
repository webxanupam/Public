package com.arix.app.ui

import android.content.Context
import android.media.audiofx.Visualizer
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

object ArixMusicPulse {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val _level = MutableStateFlow(0f)
    val level: StateFlow<Float> = _level.asStateFlow()

    private val _beatPhase = MutableStateFlow(0f)
    val beatPhase: StateFlow<Float> = _beatPhase.asStateFlow()

    private val _beatIndex = MutableStateFlow(0L)
    val beatIndex: StateFlow<Long> = _beatIndex.asStateFlow()

    private val _beatStrength = MutableStateFlow(0f)
    val beatStrength: StateFlow<Float> = _beatStrength.asStateFlow()

    private val _energy = MutableStateFlow(0f)
    val energy: StateFlow<Float> = _energy.asStateFlow()

    private val _surge = MutableStateFlow(0f)
    val surge: StateFlow<Float> = _surge.asStateFlow()

    private val _headsetOn = MutableStateFlow(false)
    val headsetOn: StateFlow<Boolean> = _headsetOn.asStateFlow()

    private val _bpm = MutableStateFlow(0f)
    val bpm: StateFlow<Float> = _bpm.asStateFlow()

    private val _bassEnv = MutableStateFlow(0f)
    val bassEnv: StateFlow<Float> = _bassEnv.asStateFlow()

    private val _midEnv = MutableStateFlow(0f)
    val midEnv: StateFlow<Float> = _midEnv.asStateFlow()

    private val _trebleEnv = MutableStateFlow(0f)
    val trebleEnv: StateFlow<Float> = _trebleEnv.asStateFlow()

    private val _active = MutableStateFlow(false)
    val active: StateFlow<Boolean> = _active.asStateFlow()

    @Volatile
    var ambientTempoBpm: Float = 0f

    private val _ambientMode = MutableStateFlow(false)

    private var ambientAnchorMs = 0L

    private var ambientWraps = 0L

    private var visualizer: Visualizer? = null
    private var frameTickerJob: Job? = null
    private var visualizerRetryJob: Job? = null

    @Volatile private var lastEmitUptimeMs = 0L
    private var lastLevel = 0f
    private var started = false
    private var contextRef: java.lang.ref.WeakReference<Context>? = null
    private var attachedSessionId = 0
    @Volatile private var lastFrameUptimeMs = 0L
    private var grooveWrapAdvances = 0
    private var beatPeriodEma = 0f

    private var bassMean = 0f
    private var bassMeanSquare = 0f
    private var bassSamples = 0
    private var lastBeatUptimeMs = 0L
    private val beatIntervalsMs = ArrayDeque<Long>()

    private var loudSlowMean = 0f
    private var loudFastMean = 0f
    private var lastDropUptimeMs = 0L
    private var lastLoudUptimeMs = 0L

    fun start(context: Context) {
        if (started) return
        started = true
        val appContext = context.applicationContext
        contextRef = java.lang.ref.WeakReference(appContext)
        scope.launch {
            com.arix.app.media.ArixPlaybackController.state.collect { state ->
                val audible = state.hasMedia && (state.isPlaying || state.isBuffering)
                if (audible) {
                    attach(appContext)
                } else {
                    detach()
                }
            }
        }
    }

    fun onRecordAudioPermissionGranted() {
        if (!_active.value) return
        if (visualizer != null) return
        if (tryAttachVisualizer()) {
            resetDetector()
            startVisualizerRetry()
        }
    }

    private fun attach(context: Context) {
        if (
            _active.value &&
            (visualizer != null || visualizerRetryJob?.isActive == true)
        ) return
        _active.value = true
        resetDetector()
        startFrameTicker()

        tryAttachVisualizer()
        startVisualizerRetry()
    }

    private fun tryAttachVisualizer(): Boolean {
        val appContext = contextRef?.get()
        if (appContext != null && !hasRecordAudioPermission(appContext)) return false
        val sessionId = runCatching {
            com.arix.app.media.ArixPlaybackController.player.audioSessionId
        }.getOrDefault(0)
        if (sessionId == 0) return false
        if (visualizer != null && sessionId != attachedSessionId) {
            releaseVisualizer()
        }
        val created = runCatching { createVisualizer(sessionId) }.getOrNull() ?: return false
        visualizer = created
        attachedSessionId = sessionId
        lastFrameUptimeMs = SystemClock.uptimeMillis()
        return true
    }

    private fun hasRecordAudioPermission(context: Context): Boolean =
        androidx.core.content.ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.RECORD_AUDIO,
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED

    private fun releaseVisualizer() {
        visualizer?.let { viz ->
            runCatching {
                viz.enabled = false
                viz.setDataCaptureListener(null, 0, false, false)
                viz.release()
            }
        }
        visualizer = null
        attachedSessionId = 0
    }

    private fun startVisualizerRetry() {
        if (visualizerRetryJob?.isActive == true) return
        visualizerRetryJob = scope.launch {
            while (isActive && _active.value) {
                delay(2_500L)
                if (!isActive || !_active.value) break
                if (visualizer == null) {
                    if (tryAttachVisualizer()) {
                        resetDetector()
                        ambientAnchorMs = 0L
                    }
                } else {
                    val silentFor = SystemClock.uptimeMillis() - lastFrameUptimeMs
                    if (silentFor > 4_000L) {
                        releaseVisualizer()
                        if (tryAttachVisualizer()) resetDetector()
                    }
                }
            }
        }
    }

    @androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
    private fun createVisualizer(sessionId: Int): Visualizer {
        val viz = Visualizer(sessionId)
        try {
            val captureSize = preferredCaptureSize()
            runCatching { viz.captureSize = captureSize }
            viz.setDataCaptureListener(
                object : Visualizer.OnDataCaptureListener {
                    override fun onWaveFormDataCapture(
                        visualizer: Visualizer?,
                        waveform: ByteArray?,
                        samplingRate: Int,
                    ) = Unit

                    override fun onFftDataCapture(
                        visualizer: Visualizer?,
                        fft: ByteArray?,
                        samplingRate: Int,
                    ) {
                        val bytes = fft ?: return
                        if (bytes.size < 4) return
                        val now = SystemClock.uptimeMillis()
                        lastFrameUptimeMs = now
                        if (now - lastEmitUptimeMs < MinEmitIntervalMs) return
                        lastEmitUptimeMs = now
                        val frame = analyzeFrame(bytes, samplingRate / 1000)
                        mainHandler.post { publishFrame(frame) }
                    }
                },
                Visualizer.getMaxCaptureRate(),
                 false,
                 true,
            )
            viz.enabled = true
        } catch (t: Throwable) {
            runCatching { viz.release() }
            throw t
        }
        return viz
    }

    private class FrameAnalysis(
        val bassEnergy: Float,
        val midEnergy: Float,
        val trebleEnergy: Float,
        val loudness: Float,
    )

    private fun analyzeFrame(fft: ByteArray, samplingRateHz: Int): FrameAnalysis {
        val bins = fft.size / 2
        if (bins <= 1) return FrameAnalysis(0f, 0f, 0f, 0f)
        val nyquist = samplingRateHz / 2f
        val hzPerBin = nyquist / bins
        val bassFromBin = maxOf(0, (BassMinHz / hzPerBin).toInt())
        val bassToBin = minOf(bins - 1, (BassMaxHz / hzPerBin).toInt())
        val midFromBin = (MidMinHz / hzPerBin).toInt().coerceAtLeast(bassToBin + 1)
        val midToBin = minOf(bins - 1, (MidMaxHz / hzPerBin).toInt())
        val trebleFromBin = (TrebleMinHz / hzPerBin).toInt().coerceAtLeast(midToBin + 1)
        val trebleToBin = minOf(bins - 1, (TrebleMaxHz / hzPerBin).toInt())

        var bassSum = 0.0
        var bassCount = 0
        var midSum = 0.0
        var midCount = 0
        var trebleSum = 0.0
        var trebleCount = 0
        var totalSum = 0.0
        for (bin in 0 until bins) {
            val re = fft[bin * 2].toDouble() / 128.0
            val im = fft[bin * 2 + 1].toDouble() / 128.0
            val magnitude = sqrt(re * re + im * im)
            totalSum += magnitude
            when {
                bin in bassFromBin..bassToBin -> {
                    bassSum += magnitude
                    bassCount++
                }
                bin in midFromBin..midToBin -> {
                    midSum += magnitude
                    midCount++
                }
                bin in trebleFromBin..trebleToBin -> {
                    trebleSum += magnitude
                    trebleCount++
                }
            }
        }
        val bass = ((bassSum / maxOf(1, bassCount)).toFloat() * BassEnergyGain)
            .coerceIn(0f, 1f)
        val mid = ((midSum / maxOf(1, midCount)).toFloat() * MidEnergyGain)
            .coerceIn(0f, 1f)
        val treble = ((trebleSum / maxOf(1, trebleCount)).toFloat() * TrebleEnergyGain)
            .coerceIn(0f, 1f)
        val loud = ((totalSum / bins).toFloat() * LoudnessGain).coerceIn(0f, 1f)
        return FrameAnalysis(bass, mid, treble, loud)
    }

    private fun publishFrame(frame: FrameAnalysis) {
        val now = SystemClock.uptimeMillis()

        val dtMs = (now - lastEmitUptimeMs).coerceAtLeast(0)
        val decayed = if (dtMs == 0L) lastLevel else lastLevel * exp(-dtMs / DecayTimeConstantMs)
        lastLevel = max(frame.loudness, decayed * 0.92f)
        _level.value = lastLevel

        val envDecay = exp(-dtMs / BandEnvDecayMs)
        fun bandEnvelope(last: Float, live: Float): Float =
            max(live, last * envDecay)
        _bassEnv.value = bandEnvelope(_bassEnv.value, frame.bassEnergy)
        _midEnv.value = bandEnvelope(_midEnv.value, frame.midEnergy)
        _trebleEnv.value = bandEnvelope(_trebleEnv.value, frame.trebleEnergy)

        loudSlowMean += (frame.loudness - loudSlowMean) * EnergySlowAlpha
        loudFastMean += (frame.loudness - loudFastMean) * EnergyFastAlpha
        _energy.value = loudSlowMean.coerceIn(0f, 1f)
        val energyGap = loudFastMean - loudSlowMean
        if (
            energyGap > DropGapThreshold &&
            loudSlowMean > 0.10f &&
            now - lastDropUptimeMs > DropRefractoryMs
        ) {
            lastDropUptimeMs = now
            _surge.value = (energyGap * DropSurgeGain).coerceIn(0.55f, 1f)
        }
        _surge.value = (_surge.value * exp(-dtMs / SurgeDecayMs)).coerceIn(0f, 1f)

        val n = bassSamples.coerceAtLeast(0)
        val alpha = if (n < WarmupFrames) 1f / (n + 1f) else MeanAlpha
        bassMean = bassMean + alpha * (frame.bassEnergy - bassMean)
        bassMeanSquare = bassMeanSquare + alpha * (frame.bassEnergy * frame.bassEnergy - bassMeanSquare)
        bassSamples++
        val variance = (bassMeanSquare - bassMean * bassMean).coerceAtLeast(0f)
        val deviation = sqrt(variance)

        val sinceLastBeat = now - lastBeatUptimeMs
        val threshold = if (bassSamples < WarmupFrames) {
            bassMean + BeatSensitivityWarmup * deviation
        } else {
            bassMean + BeatSensitivity * deviation
        }
        val hasBeat = frame.bassEnergy > MinimumBassForBeat &&
            frame.bassEnergy > threshold &&
            sinceLastBeat > BeatRefractoryMs
        if (hasBeat) {
            if (lastBeatUptimeMs > 0) {
                val interval = now - lastBeatUptimeMs
                if (interval in MinBeatIntervalMs..MaxBeatIntervalMs) {
                    beatIntervalsMs.addLast(interval)
                    while (beatIntervalsMs.size > BeatIntervalHistory) beatIntervalsMs.removeFirst()
                    _bpm.value = medianBpm()
                }
            }
            val clear = frame.bassEnergy - bassMean
            _beatStrength.value = (clear / BeatStrengthNorm).coerceIn(0.15f, 1f)
            lastBeatUptimeMs = now
            _beatIndex.value = _beatIndex.value + 1
        }
        if (lastLevel > HeadsetOnLevel) lastLoudUptimeMs = now
    }

    private fun medianBpm(): Float {
        if (beatIntervalsMs.isEmpty()) return 0f
        val sorted = beatIntervalsMs.sorted()
        val medianMs = sorted[sorted.size / 2]
        if (medianMs <= 0) return 0f
        return (60_000f / medianMs).coerceIn(60f, 200f)
    }

    private fun preferredCaptureSize(): Int {
        val range = runCatching { Visualizer.getCaptureSizeRange() }.getOrNull()
        if (range == null || range.size < 2 || range[1] <= range[0]) return 256
        if (256 in range[0]..range[1]) return 256
        var candidate = range[0]
        var next = range[0]
        while (next * 2 <= range[1]) {
            candidate = next
            next *= 2
        }
        return candidate.coerceIn(range[0], range[1])
    }

    private fun startFrameTicker() {
        if (frameTickerJob?.isActive == true) return
        frameTickerJob = scope.launch {
            while (isActive && _active.value) {
                publishBeatPhase()
                publishAmbientClock()
                updateHeadsetFlag()
                delay(FrameMillis)
            }
            _ambientMode.value = false
        }
    }

    private fun publishAmbientClock() {
        val tempo = ambientTempoBpm
        val captureAlive = visualizer != null &&
            SystemClock.uptimeMillis() - lastFrameUptimeMs < 3_000L
        val shouldRun = _active.value && !captureAlive && tempo > 0f
        _ambientMode.value = shouldRun
        if (!shouldRun) {
            ambientWraps = 0L
            return
        }
        val periodMs = 60_000f / tempo
        val now = SystemClock.uptimeMillis()
        if (ambientAnchorMs == 0L) {
            ambientAnchorMs = now
            ambientWraps = 0L
        }
        val elapsed = (now - ambientAnchorMs).toFloat()
        val phase = ((elapsed % periodMs) / periodMs).coerceIn(0f, 1f)
        _beatPhase.value = phase
        val wraps = (elapsed / periodMs).toLong()
        if (wraps > ambientWraps) {
            ambientWraps = wraps
            _beatIndex.value = _beatIndex.value + 1
            _beatStrength.value = 0.45f
        }
        val sway = 0.32f + 0.08f * sin(elapsed / 1_800f)
        if (lastLevel < sway) {
            lastLevel = sway
            _level.value = sway
        }
        if (_energy.value < 0.18f) _energy.value = 0.18f
    }

    private fun updateHeadsetFlag() {
        val levelNow = lastLevel
        val now = SystemClock.uptimeMillis()
        if (!_headsetOn.value) {
            if (levelNow > HeadsetOnLevel) {
                _headsetOn.value = true
                lastLoudUptimeMs = now
            }
        } else {
            if (levelNow > HeadsetOnLevel) {
                lastLoudUptimeMs = now
            } else if (
                levelNow < HeadsetOffLevel &&
                now - lastLoudUptimeMs > HeadsetOffDelayMs
            ) {
                _headsetOn.value = false
            }
        }
    }

    private fun publishBeatPhase() {
        val bpmNow = _bpm.value
        if (bpmNow > 0f) {
            val targetPeriod = 60_000f / bpmNow
            beatPeriodEma = if (beatPeriodEma <= 0f) {
                targetPeriod
            } else {
                beatPeriodEma + BeatPeriodEmaAlpha * (targetPeriod - beatPeriodEma)
            }
        }
        val periodMs = when {
            beatPeriodEma > 0f -> beatPeriodEma
            lastBeatUptimeMs > 0 && beatIntervalsMs.isNotEmpty() -> {
                val sorted = beatIntervalsMs.sorted()
                sorted[sorted.size / 2].toFloat()
            }
            else -> 0f
        }
        if (periodMs <= 0f) return
        val now = SystemClock.uptimeMillis()
        val sinceBeat = ((now - lastBeatUptimeMs) + BeatLookaheadMs).coerceAtLeast(0)
        _beatPhase.value = ((sinceBeat % periodMs) / periodMs).coerceIn(0f, 1f)
        if (periodMs > 0f && _active.value) {
            val wrapCount = (sinceBeat / periodMs).toInt()
            when {
                sinceBeat < periodMs -> grooveWrapAdvances = 0
                wrapCount > grooveWrapAdvances -> {
                    val advance = (wrapCount - grooveWrapAdvances).coerceIn(1, 8)
                    _beatIndex.value = _beatIndex.value + advance
                    grooveWrapAdvances = wrapCount
                }
            }
        }
    }

    private fun resetDetector() {
        bassMean = 0f
        bassMeanSquare = 0f
        bassSamples = 0
        lastBeatUptimeMs = 0L
        beatIntervalsMs.clear()
        loudSlowMean = 0f
        loudFastMean = 0f
        lastDropUptimeMs = 0L
        lastLoudUptimeMs = 0L
        _bpm.value = 0f
        _beatIndex.value = 0L
        _beatPhase.value = 0f
        _beatStrength.value = 0f
        _energy.value = 0f
        _surge.value = 0f
        lastLevel = 0f
        _level.value = 0f
        beatPeriodEma = 0f
    }

    private fun detach() {
        _active.value = false
        releaseVisualizer()
        visualizerRetryJob?.cancel()
        visualizerRetryJob = null
        frameTickerJob?.cancel()
        frameTickerJob = null
        lastEmitUptimeMs = 0L
        lastFrameUptimeMs = 0L
        grooveWrapAdvances = 0
        ambientAnchorMs = 0L
        ambientWraps = 0L
        _ambientMode.value = false
        lastLevel = 0f
        _level.value = 0f
        _bassEnv.value = 0f
        _midEnv.value = 0f
        _trebleEnv.value = 0f
        _beatPhase.value = 0f
        _beatIndex.value = 0L
        _beatStrength.value = 0f
        _energy.value = 0f
        _surge.value = 0f
        _headsetOn.value = false
        _bpm.value = 0f
    }

    private const val BassMinHz = 40f
    private const val BassMaxHz = 200f

    private const val MidMinHz = 200f
    private const val MidMaxHz = 2_000f
    private const val TrebleMinHz = 2_000f
    private const val TrebleMaxHz = 8_000f

    private const val BassEnergyGain = 4.2f
    private const val MidEnergyGain = 3.6f
    private const val TrebleEnergyGain = 4.8f
    private const val LoudnessGain = 3.1f

    private const val BandEnvDecayMs = 160f

    private const val BeatSensitivity = 1.55f
    private const val BeatSensitivityWarmup = 2.6f
    private const val MinimumBassForBeat = 0.12f

    private const val MeanAlpha = 0.06f
    private const val WarmupFrames = 24

    private const val BeatRefractoryMs = 250L
    private const val MinBeatIntervalMs = 250L
    private const val MaxBeatIntervalMs = 1_500L
    private const val BeatIntervalHistory = 8

    private const val MinEmitIntervalMs = 20L
    private const val DecayTimeConstantMs = 150f
    private const val FrameMillis = 16L

    private const val BeatLookaheadMs = 70L

    private const val BeatPeriodEmaAlpha = 0.30f

    private const val BeatStrengthNorm = 0.42f

    private const val EnergySlowAlpha = 0.0005f

    private const val EnergyFastAlpha = 0.01f

    private const val DropGapThreshold = 0.16f

    private const val DropRefractoryMs = 4_000L

    private const val DropSurgeGain = 4.5f

    private const val SurgeDecayMs = 900f

    private const val HeadsetOnLevel = 0.16f
    private const val HeadsetOffLevel = 0.05f
    private const val HeadsetOffDelayMs = 1_200L
}
