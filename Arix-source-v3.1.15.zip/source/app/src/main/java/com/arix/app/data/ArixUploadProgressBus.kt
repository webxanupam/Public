package com.arix.app.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

object ArixUploadProgressBus {

    data class UploadProgress(
        val id: Long,
        val fileName: String,
        val serverLabel: String,
        val bytesWritten: Long,
        val totalBytes: Long,
        val bytesPerSecond: Long,
        val done: Boolean,
        val failed: Boolean,
        val errorMessage: String? = null,
        val url: String? = null,
    ) {
        val percent: Int
            get() = if (totalBytes <= 0L) 0
            else ((bytesWritten * 100L) / totalBytes).toInt().coerceIn(0, 100)
    }

    const val TerminalHoldMillis: Long = 4_000L

    private var nextId: Long = 0L

    private val _progress = MutableStateFlow<UploadProgress?>(null)

    val progress: StateFlow<UploadProgress?> = _progress.asStateFlow()

    fun noteStarted(fileName: String, serverLabel: String, totalBytes: Long) {
        val id = ++nextId
        _progress.update {
            UploadProgress(
                id = id,
                fileName = fileName,
                serverLabel = serverLabel,
                bytesWritten = 0L,
                totalBytes = totalBytes,
                bytesPerSecond = 0L,
                done = false,
                failed = false,
            )
        }
    }

    fun noteProgress(
        fileName: String,
        serverLabel: String,
        bytesWritten: Long,
        totalBytes: Long,
        bytesPerSecond: Long,
    ) {
        _progress.update { current ->
            if (current == null || current.done || current.failed) {
                current
            } else {
                current.copy(
                    fileName = fileName,
                    serverLabel = serverLabel,
                    bytesWritten = bytesWritten.coerceAtLeast(0L),
                    totalBytes = totalBytes,
                    bytesPerSecond = bytesPerSecond.coerceAtLeast(0L),
                )
            }
        }
    }

    fun noteDone(fileName: String, serverLabel: String, totalBytes: Long, url: String) {
        _progress.update { current ->
            if (current != null && !current.failed) {
                current.copy(
                    fileName = fileName,
                    serverLabel = serverLabel,
                    bytesWritten = totalBytes,
                    totalBytes = totalBytes,
                    bytesPerSecond = 0L,
                    done = true,
                    url = url,
                )
            } else {
                UploadProgress(
                    id = ++nextId,
                    fileName = fileName,
                    serverLabel = serverLabel,
                    bytesWritten = totalBytes,
                    totalBytes = totalBytes,
                    bytesPerSecond = 0L,
                    done = true,
                    failed = false,
                    url = url,
                )
            }
        }
    }

    fun noteFailed(fileName: String, serverLabel: String, errorMessage: String) {
        _progress.update { current ->
            if (current != null && !current.done) {
                current.copy(
                    fileName = fileName,
                    serverLabel = serverLabel,
                    done = false,
                    failed = true,
                    errorMessage = errorMessage,
                )
            } else {
                UploadProgress(
                    id = ++nextId,
                    fileName = fileName,
                    serverLabel = serverLabel,
                    bytesWritten = 0L,
                    totalBytes = -1L,
                    bytesPerSecond = 0L,
                    done = false,
                    failed = true,
                    errorMessage = errorMessage,
                )
            }
        }
    }

    fun clear() {
        _progress.update { null }
    }
}
