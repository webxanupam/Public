package com.arix.app.agent.setup

import com.arix.app.agent.setup.PairingCodeInput

/** 配对通知输入框的落点:清单与通知里用的是这个全名;实现在手机能力里。 */
class PairingCodeReceiver : PairingCodeInput()
