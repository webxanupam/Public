package com.arix.app.ui

import androidx.compose.runtime.Composable
import com.arix.app.data.SessionExecutionState

@Composable
fun ConversationDrawer(
    sessions: List<ChatSession>,
    selectedSessionId: String,
    sessionExecutionStates: Map<String, SessionExecutionState>,
    unviewedCompletedSessionIds: Set<String>,
    onClearAll: () -> Unit,
    onSessionSelected: (String) -> Unit,
    onRenameSession: (String, String) -> Unit,
    onExportSession: (ChatSession) -> Unit,
    onDeleteSession: (String) -> Unit,
) {
    ArixConversationDrawer(
        sessions = sessions.map { session ->
            SharedConversationSummary(
                id = session.id,
                title = session.title,
                indicator = when {
                    sessionExecutionStates[session.id]?.isRunning == true ->
                        SharedConversationIndicator.Working
                    unviewedCompletedSessionIds.contains(session.id) ->
                        SharedConversationIndicator.UnviewedComplete
                    else -> SharedConversationIndicator.None
                },
            )
        },
        selectedSessionId = selectedSessionId,
        onClearAll = onClearAll,
        onSessionSelected = onSessionSelected,
        onRenameSession = onRenameSession,
        onExportSession = { sessionId ->
            sessions.firstOrNull { it.id == sessionId }?.let(onExportSession)
        },
        onDeleteSession = onDeleteSession,
    )
}
