package com.arix.app.data

import android.content.Context
import java.io.File

object LegacyAetherStoreMigrator {

    private var lastCopyFailure: String? = null
    private const val MarkerPreferencesName = "arix_store_migration"
    private const val MarkerKey = "migrated_from_legacy_aether_stores"

    private val dataStorePairs = listOf(
        "aether_settings" to "arix_settings",
        "aether_chats" to "arix_chats",
        "aether_agent_extensions" to "arix_agent_extensions",
        "aether_scheduled_tasks" to "arix_scheduled_tasks",
    )

    private val sharedPreferencesPairs = listOf(
        "aether_discovered_skills" to "arix_discovered_skills",
    )

    private val databasePairs = listOf(
        "aether_chat_history" to "arix_chat_history",
    )

    private val databaseSidecarSuffixes = listOf("", "-wal", "-shm", "-journal")

    fun migrate(
        context: Context,
        onDiagnostic: ((event: String, error: String) -> Unit)? = null,
    ) {
        val appContext = context.applicationContext
        val marker = appContext.getSharedPreferences(MarkerPreferencesName, Context.MODE_PRIVATE)
        if (marker.getBoolean(MarkerKey, false)) return
        try {
            migrateDataStores(appContext)
            migrateSharedPreferences(appContext)
            migrateDatabases(appContext)
        } catch (error: Exception) {
            onDiagnostic?.invoke("legacy_store_migration_failed", error.message.orEmpty())
        } finally {
            lastCopyFailure?.let { failure ->
                onDiagnostic?.invoke("legacy_store_copy_failed", failure)
            }
            marker.edit().putBoolean(MarkerKey, true).apply()
        }
    }

    private fun migrateDataStores(context: Context) {
        val datastoreDir = File(context.filesDir, "datastore")
        dataStorePairs.forEach { (legacyName, currentName) ->
            copyIfLegacyExists(
                source = File(datastoreDir, "$legacyName.preferences_pb"),
                target = File(datastoreDir, "$currentName.preferences_pb"),
            )
        }
    }

    private fun migrateSharedPreferences(context: Context) {
        val prefsDir = File(context.filesDir.parentFile, "shared_prefs")
        sharedPreferencesPairs.forEach { (legacyName, currentName) ->
            copyIfLegacyExists(
                source = File(prefsDir, "$legacyName.xml"),
                target = File(prefsDir, "$currentName.xml"),
            )
        }
    }

    private fun migrateDatabases(context: Context) {
        val dbDir = File(context.filesDir.parentFile, "databases")
        databasePairs.forEach { (legacyName, currentName) ->
            databaseSidecarSuffixes.forEach { suffix ->
                copyIfLegacyExists(
                    source = File(dbDir, "$legacyName.db$suffix"),
                    target = File(dbDir, "$currentName.db$suffix"),
                )
            }
        }
    }

    private fun copyIfLegacyExists(source: File, target: File) {
        if (!source.isFile || source.length() == 0L) return
        try {
            target.parentFile?.mkdirs()
            if (target.exists()) {
                target.delete()
            }
            source.copyTo(target, overwrite = true)
        } catch (error: Exception) {
            lastCopyFailure = "${source.name} → ${target.name}: ${error.message.orEmpty()}"
        }
    }

    val lastRecordedCopyFailure: String?
        get() = lastCopyFailure
}
