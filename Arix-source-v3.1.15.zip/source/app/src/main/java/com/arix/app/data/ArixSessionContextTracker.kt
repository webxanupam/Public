package com.arix.app.data

import java.util.ArrayDeque
import org.json.JSONObject

class ArixSessionContextTracker {

    data class RecordedAction(
        val toolName: String,
        val summary: String,
        val referents: Map<String, String>,
        val ok: Boolean,
        val atMillis: Long,
    )

    private val lock = Any()
    private val recent = ArrayDeque<RecordedAction>(MaxRecordedActions)

    fun recordToolCall(toolName: String, argumentsJson: String, output: String, ok: Boolean) {
        val referents = extractReferents(toolName, argumentsJson, output, ok)
        val summary = summarize(toolName, referents)
        synchronized(lock) {
            recent.addLast(
                RecordedAction(
                    toolName = toolName,
                    summary = summary,
                    referents = referents,
                    ok = ok,
                    atMillis = System.currentTimeMillis(),
                ),
            )
            while (recent.size > MaxRecordedActions) recent.removeFirst()
        }
    }

    fun promptBlock(): String? = synchronized(lock) {
        if (recent.isEmpty()) return null
        val successful = recent.filter { it.ok }
        if (successful.isEmpty()) return null
        val lastFile = successful.lastOrNull { it.referents.containsKey(KEY_FILE) }?.referents?.get(KEY_FILE)
        val lines = mutableListOf<String>()
        if (lastFile != null) lines.add("Last file/artifact touched: $lastFile")
        val tail = successful.takeLast(TailActions)
            .map { action -> "- ${action.summary}" }
        if (lines.isEmpty() && tail.isEmpty()) return null
        return buildString {
            lines.forEach { append(it).append('\n') }
            if (tail.isNotEmpty()) {
                append("Recent successful actions (most recent last):")
                tail.forEach { append('\n').append(it) }
            }
        }.trim().takeIf { it.isNotEmpty() }?.take(MaxBlockChars)
    }

    fun latestReferent(key: String): String? = synchronized(lock) {
        recent.lastOrNull { it.ok && it.referents.containsKey(key) }?.referents?.get(key)
    }

    fun recordedCount(): Int = synchronized(lock) { recent.size }

    fun reset() = synchronized(lock) { recent.clear() }

    private fun extractReferents(
        toolName: String,
        argumentsJson: String,
        output: String,
        ok: Boolean,
    ): Map<String, String> {
        if (!ok) return emptyMap()
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
        val result = runCatching { JSONObject(output) }.getOrNull()
        val referents = mutableMapOf<String, String>()
        when (toolName) {
            "arix_memory" -> {
                arguments?.optString("content")?.trim()?.takeIf { it.isNotEmpty() }?.let {
                    referents[KEY_MEMORY] = it
                }
            }
        }
        val nestedResult = result?.optJSONObject("result")
        sequenceOf(result, nestedResult).forEach { payload ->
            if (payload == null) return@forEach
            payload.optString("file").trim().takeIf { it.isNotEmpty() }?.let {
                referents[KEY_FILE] = it
            }
            payload.optString("path").trim().takeIf { it.isNotEmpty() && it.startsWith("/") }?.let {
                referents[KEY_FILE] = it
            }
        }
        return referents.filterValues { it.length <= MaxReferentChars }
    }

    private fun summarize(toolName: String, referents: Map<String, String>): String {
        if (referents.isEmpty()) return "$toolName succeeded"
        val subject = referents[KEY_FILE] ?: referents[KEY_MEMORY]
        return if (subject != null) "$toolName → $subject" else "$toolName succeeded"
    }

    companion object {
        const val KEY_FILE = "file"
        const val KEY_MEMORY = "memory"

        private const val MaxRecordedActions = 30
        private const val TailActions = 6
        private const val MaxBlockChars = 700
        private const val MaxReferentChars = 200
    }
}
