package com.arix.app.data

import com.arix.app.ui.AttachmentKind
import com.arix.app.ui.ChatAttachment
import com.arix.app.ui.ChatMessage
import com.arix.app.ui.MessageAuthor
import com.arix.app.ui.MessageDisplayKind
import org.json.JSONArray
import org.json.JSONObject

internal object SessionContextBuilder {

    private fun parseJsonObject(rawValue: String): JSONObject? =
        if (rawValue.isBlank()) null else runCatching { JSONObject(rawValue) }.getOrNull()

    fun buildRequestMessages(
        messages: List<ChatMessage>,
        settings: AppSettings,
        turnContextBlock: String? = null,
    ): List<LlmMessage> {
        val llmMessages = messages
            .filter { it.displayKind != MessageDisplayKind.CompactStatus }
            .flatMap { message -> buildRequestMessagesForChatMessage(message, settings) }
        if (turnContextBlock.isNullOrBlank()) return llmMessages
        val sanitized = llmMessages.map { message ->
            if (message.role != "user") {
                message
            } else {
                val cleanedParts = message.contentParts.map { part ->
                    if (part is LlmTextPart) {
                        LlmTextPart(ArixLegacyContextBlockSanitizer.strip(part.text))
                    } else {
                        part
                    }
                }
                message.copy(contentParts = cleanedParts)
            }
        }
        val lastUserIndex = sanitized.indexOfLast { it.role == "user" }
        if (lastUserIndex < 0) return sanitized
        val target = sanitized[lastUserIndex]
        val prefixedParts = target.contentParts.mapIndexed { index, part ->
            if (index == 0 && part is LlmTextPart) {
                LlmTextPart("$turnContextBlock\n\n${part.text}")
            } else if (index == 0) {
                LlmTextPart(turnContextBlock)
            } else {
                part
            }
        }
        return sanitized.toMutableList().also { it[lastUserIndex] = target.copy(contentParts = prefixedParts) }
    }

    private fun buildRequestMessagesForChatMessage(
        message: ChatMessage,
        settings: AppSettings,
    ): List<LlmMessage> {
        if (message.author != MessageAuthor.Agent || message.toolInvocations.isEmpty()) {
            return listOf(buildRequestMessage(message, settings))
        }
        val assistant = buildRequestMessage(message, settings)
        val existingPayload = assistant.providerPayload
        val providerPayload = existingPayload ?: JSONObject().apply {
            put("piAssistantMessage", JSONObject().apply {
                put("role", "assistant")
                put("api", "arix")
                put("provider", settings.piProviderId.ifBlank { "arix" })
                put("model", settings.modelId.ifBlank { "unknown" })
                put("content", JSONArray().apply {
                    if (message.text.isNotBlank()) {
                        put(JSONObject().put("type", "text").put("text", message.text))
                    }
                    message.toolInvocations.forEach { invocation ->
                        put(JSONObject().apply {
                            put("type", "toolCall")
                            put("id", invocation.id)
                            put("name", invocation.toolName)
                            put("arguments", parseJsonObject(invocation.argumentsJson) ?: JSONObject())
                        })
                    }
                })
                put("stopReason", "toolUse")
                put("timestamp", message.createdAtMillis ?: System.currentTimeMillis())
            })
        }
        val assistantWithPayload = assistant.copy(providerPayload = providerPayload)
        val results = message.toolInvocations.map { invocation ->
            LlmMessage(
                role = "toolResult",
                contentParts = listOf(LlmTextPart(invocation.outputJson)),
                toolCallId = invocation.id,
                toolName = invocation.toolName,
            )
        }
        return listOf(assistantWithPayload) + results
    }

    private fun buildRequestMessage(
        message: ChatMessage,
        settings: AppSettings,
    ): LlmMessage {
        val parts = mutableListOf<LlmContentPart>()
        if (message.text.isNotBlank()) {
            parts += LlmTextPart(message.text)
        }
        message.attachments.forEach { attachment ->
            parts += buildWorkspaceAttachmentParts(attachment, settings)
        }
        if (parts.isEmpty()) {
            parts += LlmTextPart("[Empty message]")
        }
        return LlmMessage(
            role = if (message.author == MessageAuthor.User) "user" else "assistant",
            contentParts = parts,
            providerPayload = parseJsonObject(message.providerPayloadJson),
        )
    }

    fun buildSteerRequestMessage(
        message: ChatMessage,
        settings: AppSettings,
    ): LlmMessage {
        val steerText = buildString {
            append(
                "The user sent this while you were already working. Treat it as supplemental context for the current task. " +
                    "Continue the ongoing work, do not restart just to acknowledge it, and only change course if the new note requires it."
            )
            if (message.text.isNotBlank()) {
                append("\n\nSupplemental user note:\n")
                append(message.text)
            } else if (message.attachments.isNotEmpty()) {
                append("\n\nThe user also attached additional files for the current task.")
            }
        }
        return buildRequestMessage(message.copy(text = steerText), settings)
    }

    private fun buildWorkspaceAttachmentParts(
        attachment: ChatAttachment,
        settings: AppSettings,
    ): List<LlmContentPart> {
        if (attachment.workspacePath.isBlank()) {
            if (
                attachment.kind == AttachmentKind.Image &&
                attachment.mimeType.startsWith("image/") &&
                attachment.inlineBase64.isNotBlank()
            ) {
                return listOf(
                    LlmTextPart(
                        "Visual attachment:\n" +
                            "Name: ${attachment.name}\n" +
                            "Type: ${attachment.mimeType}\n" +
                            "This image is attached directly to the model request and has no workspace copy."
                    ),
                    LlmImagePart(
                        mimeType = attachment.mimeType,
                        base64Data = attachment.inlineBase64,
                    ),
                )
            }
            return listOf(LlmTextPart(
                "Attached file '${attachment.name}' is missing a workspace path. Ask the user to re-upload it if you need to inspect the file."
            ))
        }

        val canInlineImage = canInlineWorkspaceImageAttachment(attachment, settings)
        val accessHint = if (isWorkspaceImageAttachment(attachment)) {
            if (canInlineImage) {
                "This image was copied into the workspace and is also inserted into this model request when local bytes are available. Use the native read tool on this path when you need to inspect it."
            } else {
                "This image was copied into the workspace. Call the native read tool on this exact path before answering questions about the image."
            }
        } else {
            "Inspect this file through read, grep, find, ls, or bash inside the workspace instead of assuming its contents."
        }

        val metadataPart = LlmTextPart(
            buildString {
                append("Workspace attachment:\n")
                append("Name: ${attachment.name}\n")
                append("Type: ${attachment.mimeType.ifBlank { "unknown" }}\n")
                attachment.sizeBytes?.let { append("Size: ${formatBytes(it)}\n") }
                append("Path: ${attachment.workspacePath}\n")
                append("This file was uploaded in the current session.\n")
                append(accessHint)
            }
        )
        val imagePart = attachment.takeIf {
            canInlineImage
        }?.let {
            LlmImagePart(
                mimeType = it.mimeType,
                base64Data = it.inlineBase64,
            )
        }
        return listOfNotNull(metadataPart, imagePart)
    }

    internal fun formatBytes(bytes: Long): String = when {
        bytes >= 1024 * 1024 -> String.format("%.1f MB", bytes / (1024f * 1024f))
        bytes >= 1024 -> String.format("%.1f KB", bytes / 1024f)
        else -> "$bytes B"
    }

    fun estimateRequestTokenUsage(request: SessionTurnRequest): LlmTokenUsage {
        val inputTokens = estimateChatMessagesTokens(request.requestMessages).toLong()
        return LlmTokenUsage(
            inputTokens = inputTokens,
            totalTokens = inputTokens,
            requestCount = 1,
        )
    }

    private fun estimateChatMessagesTokens(messages: List<ChatMessage>): Int =
        messages.sumOf { message ->
            approximateTokenCount(message.text) +
                message.attachments.sumOf(::estimateAttachmentTokens)
        }

    private fun estimateAttachmentTokens(attachment: ChatAttachment): Int =
        approximateTokenCount(attachment.name) +
            when (attachment.kind) {
                AttachmentKind.Image -> 85
                AttachmentKind.File -> {
                    val sizeBytes = attachment.sizeBytes ?: 0L
                    if (sizeBytes > 0L) {
                        (sizeBytes / 4L).coerceAtMost(16_000L).toInt()
                    } else {
                        0
                    }
                }
            }

    fun approximateTokenCount(text: String): Int {
        var count = 0
        var inToken = false
        for (char in text) {
            when {
                char.isWhitespace() -> inToken = false
                isCjkChar(char) -> {
                    count += 1
                    inToken = false
                }
                !inToken -> {
                    count += 1
                    inToken = true
                }
            }
        }
        return count
    }

    private fun isCjkChar(char: Char): Boolean {
        val block = Character.UnicodeBlock.of(char)
        return block == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS ||
            block == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A ||
            block == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_B ||
            block == Character.UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS ||
            block == Character.UnicodeBlock.HIRAGANA ||
            block == Character.UnicodeBlock.KATAKANA ||
            block == Character.UnicodeBlock.HANGUL_SYLLABLES
    }
}

internal fun shouldInlineWorkspaceImageAttachment(
    attachment: ChatAttachment,
    settings: AppSettings,
): Boolean =
    isWorkspaceImageAttachment(attachment) &&
        settings.modelCapabilities().supportsInlineImageWithTools

internal fun canInlineWorkspaceImageAttachment(
    attachment: ChatAttachment,
    settings: AppSettings,
): Boolean =
    shouldInlineWorkspaceImageAttachment(attachment, settings) &&
        attachment.inlineBase64.isNotBlank()

internal fun isWorkspaceImageAttachment(attachment: ChatAttachment): Boolean =
    attachment.kind == AttachmentKind.Image &&
        attachment.mimeType.startsWith("image/")
