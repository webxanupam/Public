package com.arix.app.ui

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.GestureDetector
import android.view.MotionEvent
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.view.ViewCompat
import com.arix.app.ArixApplication
import com.arix.app.R
import com.arix.app.data.LocalRuntimeId
import com.arix.app.data.RuntimeWorkspaceFileBridge
import com.arix.app.data.WorkspaceFileBridge
import com.arix.app.ui.theme.ArixBackground
import com.arix.app.ui.theme.ArixOnSurface
import com.arix.app.ui.theme.ArixOnSurfaceVariant
import com.arix.app.ui.theme.ArixOutline
import com.arix.app.ui.theme.ArixOutlineSoft
import com.arix.app.ui.theme.ArixPrimary
import com.arix.app.ui.theme.ArixSecondary
import com.arix.app.ui.theme.ArixSurface
import com.arix.app.ui.theme.ArixSurfaceHigh
import com.arix.app.ui.theme.ArixSurfaceVariant
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.URLDecoder
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.util.Base64
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

private const val MarkdownHtmlBridgeName = "ArixMarkdownHtmlBridge"

private const val MermaidScriptUrl = "https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.min.js"

private const val KatexCssUrl = "https://cdn.jsdelivr.net/npm/katex@0.16.11/dist/katex.min.css"

private const val KatexScriptUrl = "https://cdn.jsdelivr.net/npm/katex@0.16.11/dist/katex.min.js"

private const val KatexAutoRenderScriptUrl = "https://cdn.jsdelivr.net/npm/katex@0.16.11/dist/contrib/auto-render.min.js"

private const val MarkdownHtmlBaseUrl = "https://localhost/"

internal const val DefaultMermaidMinHeightDp = 220

internal const val DefaultMermaidMaxHeightDp = 640

private const val PreviewDialogMinHeightDp = 320

internal const val PreviewDialogMaxHeightDp = 820

internal data class MarkdownMermaidSpec(
    val code: MarkdownSourceText,
    val layout: MarkdownMediaLayout = defaultMarkdownMermaidLayout(),
)

@Composable
internal fun MarkdownEmbedFrameBlock(
    spec: MarkdownEmbedFrameSpec,
    onLinkClick: (String) -> Unit,
) {
    val clipboard = LocalClipboardManager.current
    val copiedLabel = stringResource(R.string.widget_link_copied)
    var copied by remember(spec.url) { mutableStateOf(false) }
    var fullscreen by remember(spec.url) { mutableStateOf(false) }
    val domain = remember(spec.url) {
        runCatching { android.net.Uri.parse(spec.url).host ?: spec.url }.getOrDefault(spec.url)
    }
    val title = spec.title.ifBlank { domain.removePrefix("www.") }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(ArixSurfaceHigh)
            .border(1.dp, ArixOutline.copy(alpha = 0.6f), RoundedCornerShape(18.dp)),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 14.dp, end = 6.dp, top = 10.dp, bottom = 0.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(ArixPrimary.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = Icons.Rounded.Language,
                    contentDescription = null,
                    tint = ArixPrimary,
                    modifier = Modifier.size(18.dp),
                )
            }
            Column(Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium,
                    color = ArixOnSurface,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = domain.removePrefix("www.") + " · embedded",
                    style = MaterialTheme.typography.labelSmall,
                    color = ArixOnSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            IconButton(
                onClick = { fullscreen = true },
                modifier = Modifier.size(36.dp),
            ) {
                Icon(
                    imageVector = Icons.Rounded.Fullscreen,
                    contentDescription = "Open embed fullscreen",
                    tint = ArixOnSurfaceVariant,
                    modifier = Modifier.size(19.dp),
                )
            }
            IconButton(
                onClick = {
                    if (copied) return@IconButton
                    clipboard.setText(androidx.compose.ui.text.AnnotatedString(spec.url))
                    copied = true
                },
                modifier = Modifier.size(36.dp),
            ) {
                Icon(
                    imageVector = if (copied) Icons.Rounded.CheckCircle else Icons.Rounded.ContentCopy,
                    contentDescription = if (copied) copiedLabel else "Copy embed URL",
                    tint = if (copied) ArixSecondary else ArixOnSurfaceVariant,
                    modifier = Modifier.size(17.dp),
                )
            }
            IconButton(
                onClick = { onLinkClick(spec.url) },
                modifier = Modifier.size(36.dp),
            ) {
                Icon(
                    imageVector = Icons.Rounded.OpenInNew,
                    contentDescription = "Open embed URL",
                    tint = ArixOnSurfaceVariant,
                    modifier = Modifier.size(17.dp),
                )
            }
        }

        ArixEmbedWebView(
            url = spec.url,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp)
                .padding(bottom = 10.dp)
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(12.dp))
                .background(ArixBackground),
        )
    }

    if (fullscreen) {
        Dialog(
            onDismissRequest = { fullscreen = false },
            properties = DialogProperties(
                usePlatformDefaultWidth = false,
                decorFitsSystemWindows = false,
                dismissOnBackPress = true,
            ),
        ) {
            val dialogView = androidx.compose.ui.platform.LocalView.current
            LaunchedEffect(dialogView) {
                val window = (dialogView.parent as? androidx.compose.ui.window.DialogWindowProvider)?.window
                window?.let { w ->
                    androidx.core.view.WindowCompat.setDecorFitsSystemWindows(w, false)
                    val controller = androidx.core.view.WindowCompat.getInsetsController(w, w.decorView)
                    controller.systemBarsBehavior =
                        androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    controller.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
                }
            }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black),
            ) {
                ArixEmbedWebView(
                    url = spec.url,
                    fullscreen = true,
                    modifier = Modifier.fillMaxSize(),
                )
                IconButton(
                    onClick = { fullscreen = false },
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(10.dp)
                        .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(999.dp)),
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Close,
                        contentDescription = "Close fullscreen embed",
                        tint = Color.White,
                    )
                }
            }
        }
    }
}

@Composable
private fun ArixEmbedWebView(
    url: String,
    modifier: Modifier = Modifier,
    fullscreen: Boolean = false,
) {
    val embedHtml = remember(url, fullscreen) {
        val escapedUrl = url
            .replace("&", "&amp;")
            .replace("\"", "&quot;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
        """<!DOCTYPE html>
            <html><head>
            <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
            <style>
              html,body{margin:0;padding:0;height:100%;background:#0B0D17;overflow:hidden;}
              iframe{border:0;width:100%;height:100%;}
            </style></head>
            <body><iframe src="$escapedUrl" allow="autoplay; encrypted-media; fullscreen; picture-in-picture" allowfullscreen frameborder="0"></iframe></body></html>"""
    }
    AndroidView(
        modifier = modifier,
        factory = { viewContext ->
            WebView(viewContext).apply {
                setBackgroundColor(0xFF0B0D17.toInt())
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.loadsImagesAutomatically = true
                settings.mediaPlaybackRequiresUserGesture = false
                settings.useWideViewPort = true
                settings.loadWithOverviewMode = true
                isFocusable = true
                isFocusableInTouchMode = true
                webChromeClient = object : WebChromeClient() {}
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(
                        view: WebView?,
                        request: WebResourceRequest?,
                    ): Boolean {
                        return false
                    }
                }
                layoutParams = android.view.ViewGroup.LayoutParams(
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                )
                loadDataWithBaseURL(
                    null,
                    embedHtml,
                    "text/html",
                    "utf-8",
                    null,
                )
            }
        },
        update = { webView ->
            if (webView.tag != embedHtml) {
                webView.tag = embedHtml
                webView.loadDataWithBaseURL(
                    null,
                    embedHtml,
                    "text/html",
                    "utf-8",
                    null,
                )
            }
        },
        onRelease = { webView ->
            runCatching {
                webView.stopLoading()
                webView.loadUrl("about:blank")
                webView.destroy()
            }
        },
    )
}

@Composable
internal fun MarkdownMermaidBlock(
    diagram: MarkdownMermaidSpec,
) {
    val renderErrorTitle = stringResource(R.string.markdown_mermaid_error_render)
    val invalidSyntaxError = stringResource(R.string.markdown_mermaid_error_invalid_syntax)
    val previewLayout = remember(diagram.layout) {
        diagram.layout.copy(
            heightDp = null,
            minHeightDp = PreviewDialogMinHeightDp,
            maxHeightDp = PreviewDialogMaxHeightDp,
            scroll = true,
            showAll = false,
        )
    }
    var showPreview by remember(diagram.code.text, diagram.layout) { mutableStateOf(false) }
    MarkdownMediaWidthContainer(layout = diagram.layout) { widthModifier ->
        MarkdownHtmlBlock(
            html = remember(diagram.code.text, diagram.layout) {
                buildMermaidHtml(
                    code = diagram.code.text,
                    layout = diagram.layout,
                    renderErrorTitle = renderErrorTitle,
                    invalidSyntaxError = invalidSyntaxError,
                )
            },
            layout = diagram.layout,
            defaultMinHeightDp = DefaultMermaidMinHeightDp,
            defaultMaxHeightDp = DefaultMermaidMaxHeightDp,
            modifier = widthModifier
                .clip(RoundedCornerShape(18.dp))
                .background(ArixSurface),
            onTap = { showPreview = true },
        )
    }

    if (showPreview) {
        MarkdownMermaidPreviewDialog(
            html = remember(diagram.code.text, previewLayout) {
                buildMermaidHtml(
                    code = diagram.code.text,
                    layout = previewLayout,
                    renderErrorTitle = renderErrorTitle,
                    invalidSyntaxError = invalidSyntaxError,
                )
            },
            onDismiss = { showPreview = false },
        )
    }
}

@Composable
internal fun MarkdownHtmlBlock(
    html: String,
    layout: MarkdownMediaLayout,
    defaultMinHeightDp: Int,
    defaultMaxHeightDp: Int,
    modifier: Modifier = Modifier,
    backgroundColor: Color = ArixSurface,
    onTap: (() -> Unit)? = null,
    onLinkClick: ((String) -> Unit)? = null,
) {
    val resolvedMinHeightDp = layout.minHeightDp ?: defaultMinHeightDp
    val resolvedMaxHeightDp = layout.maxHeightDp ?: defaultMaxHeightDp
    val scrollViewportHeightDp = if (layout.scroll) {
        (layout.heightDp ?: resolvedMaxHeightDp).coerceAtLeast(1)
    } else {
        null
    }
    var measuredHeightDp by remember(html) { mutableIntStateOf(resolvedMinHeightDp.coerceAtLeast(1)) }
    var hasMeasuredContent by remember(html) { mutableStateOf(false) }
    val effectiveMinHeightDp = if (hasMeasuredContent) 1 else resolvedMinHeightDp.coerceAtLeast(1)
    val appliedHeightDp = when {
        layout.showAll -> measuredHeightDp.coerceAtLeast(effectiveMinHeightDp)
        layout.heightDp != null -> layout.heightDp.coerceAtLeast(effectiveMinHeightDp)
        scrollViewportHeightDp != null -> measuredHeightDp.coerceIn(
            effectiveMinHeightDp,
            scrollViewportHeightDp,
        )
        else -> measuredHeightDp.coerceIn(
            effectiveMinHeightDp,
            resolvedMaxHeightDp.coerceAtLeast(effectiveMinHeightDp),
        )
    }

    AndroidView(
        modifier = modifier.height(appliedHeightDp.dp),
        factory = { context ->
            val gestureDetector = GestureDetector(
                context,
                object : GestureDetector.SimpleOnGestureListener() {
                    override fun onSingleTapConfirmed(event: MotionEvent): Boolean {
                        onTap?.invoke()
                        return false
                    }
                },
            )
            WebView(context).apply {
                setBackgroundColor(backgroundColor.toArgb())
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.loadsImagesAutomatically = true
                settings.allowFileAccess = true
                settings.allowContentAccess = true
                settings.useWideViewPort = true
                settings.loadWithOverviewMode = true
                isVerticalScrollBarEnabled = layout.scroll && !layout.showAll
                isHorizontalScrollBarEnabled = layout.scroll && !layout.showAll
                isFocusable = true
                isFocusableInTouchMode = true
                ViewCompat.setNestedScrollingEnabled(this, layout.scroll && !layout.showAll)
                webChromeClient = WebChromeClient()
                addJavascriptInterface(
                    MarkdownHtmlBridge(
                        onHeightMeasured = { measuredHeight ->
                            measuredHeightDp = measuredHeight.coerceAtLeast(1)
                            hasMeasuredContent = true
                        },
                        onTap = onTap,
                        onLinkClick = onLinkClick,
                    ),
                    MarkdownHtmlBridgeName,
                )
                setOnTouchListener { view, event ->
                    if (layout.scroll && !layout.showAll) {
                        when (event.actionMasked) {
                            MotionEvent.ACTION_DOWN,
                            MotionEvent.ACTION_MOVE -> view.parent?.requestDisallowInterceptTouchEvent(true)
                            MotionEvent.ACTION_UP,
                            MotionEvent.ACTION_CANCEL -> view.parent?.requestDisallowInterceptTouchEvent(false)
                        }
                    }
                    gestureDetector.onTouchEvent(event)
                    false
                }
                setOnClickListener { onTap?.invoke() }
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(
                        view: WebView?,
                        request: WebResourceRequest?,
                    ): Boolean {
                        val targetUrl = request?.url?.toString().orEmpty()
                        if (targetUrl.isBlank()) return false
                        onLinkClick?.invoke(targetUrl)
                        return true
                    }

                    override fun onPageFinished(
                        view: WebView?,
                        url: String?,
                    ) {
                        super.onPageFinished(view, url)
                        view?.evaluateJavascript("window.reportArixHeight && window.reportArixHeight();", null)
                    }
                }
            }
        },
        update = { webView ->
            webView.isVerticalScrollBarEnabled = layout.scroll && !layout.showAll
            webView.isHorizontalScrollBarEnabled = layout.scroll && !layout.showAll
            ViewCompat.setNestedScrollingEnabled(webView, layout.scroll && !layout.showAll)
            if (webView.tag != html) {
                webView.tag = html
                webView.loadDataWithBaseURL(
                    MarkdownHtmlBaseUrl,
                    html,
                    "text/html",
                    "utf-8",
                    null,
                )
            }
        },
        onRelease = { webView ->
            runCatching {
                webView.removeJavascriptInterface(MarkdownHtmlBridgeName)
            }
            runCatching {
                webView.stopLoading()
                webView.loadUrl("about:blank")
                webView.destroy()
            }
        },
    )
}

@Composable
private fun MarkdownMermaidPreviewDialog(
    html: String,
    onDismiss: () -> Unit,
) {
    MarkdownPreviewDialogFrame(
        title = stringResource(R.string.markdown_mermaid_preview_title),
        onDismiss = onDismiss,
    ) {
        MarkdownHtmlBlock(
            html = html,
            layout = MarkdownMediaLayout(
                minHeightDp = PreviewDialogMinHeightDp,
                maxHeightDp = PreviewDialogMaxHeightDp,
                scroll = true,
                showAll = false,
            ),
            defaultMinHeightDp = PreviewDialogMinHeightDp,
            defaultMaxHeightDp = PreviewDialogMaxHeightDp,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(ArixSurfaceHigh),
            backgroundColor = ArixSurfaceHigh,
        )
    }
}

@Composable
internal fun MarkdownPreviewDialogFrame(
    title: String,
    onDismiss: () -> Unit,
    content: @Composable () -> Unit,
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 24.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(ArixSurface.copy(alpha = 0.98f))
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = ArixOnSurface,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    text = stringResource(R.string.common_close),
                    style = MaterialTheme.typography.bodyMedium,
                    color = ArixPrimary,
                    modifier = Modifier.clickable(onClick = onDismiss),
                )
            }
            content()
        }
    }
}

internal sealed interface MarkdownHtmlTextVariant {
    data object Paragraph : MarkdownHtmlTextVariant
    data class Heading(val level: Int) : MarkdownHtmlTextVariant
    data object ListItem : MarkdownHtmlTextVariant
    data object Quote : MarkdownHtmlTextVariant
    data class TableCell(val isHeader: Boolean) : MarkdownHtmlTextVariant
}

@Composable
internal fun MarkdownTextHtmlBlock(
    text: String,
    variant: MarkdownHtmlTextVariant,
    modifier: Modifier = Modifier,
    onLinkClick: (String) -> Unit,
) {
    val themeTextColor = ArixOnSurface
    val themeLinkColor = ArixPrimary
    val themeCodeBackgroundColor = ArixSurfaceHigh
    val html = remember(text, variant, themeTextColor, themeLinkColor, themeCodeBackgroundColor) {
        buildMarkdownTextHtml(
            text = text,
            variant = variant,
        )
    }
    MarkdownHtmlBlock(
        html = html,
        layout = MarkdownMediaLayout(showAll = true),
        defaultMinHeightDp = DefaultTextBlockMinHeightDp,
        defaultMaxHeightDp = DefaultTextBlockMaxHeightDp,
        modifier = modifier.fillMaxWidth(),
        backgroundColor = Color.Transparent,
        onLinkClick = onLinkClick,
    )
}

private fun buildMarkdownTextHtml(
    text: String,
    variant: MarkdownHtmlTextVariant,
): String {
    val contentHtml = inlineMarkdownToHtml(text)
    val textColor = ArixOnSurface.toCssHex()
    val linkColor = ArixPrimary.toCssHex()
    val codeBackgroundColor = ArixSurfaceHigh.toCssHex()
    val variantCss = buildMarkdownTextVariantCss(variant)
    return """
        <!DOCTYPE html>
        <html>
        <head>
            <meta name="viewport" content="width=device-width, initial-scale=1.0" />
            <link rel="stylesheet" href="$KatexCssUrl" />
            <style>
                html, body {
                    margin: 0;
                    padding: 0;
                    background: transparent;
                }
                body {
                    color: $textColor;
                    font-family: sans-serif;
                }
                .arix-text {
                    $variantCss
                    white-space: pre-wrap;
                    overflow-wrap: anywhere;
                    word-break: break-word;
                }
                .arix-text a {
                    color: $linkColor;
                    text-decoration: none;
                }
                .arix-text strong {
                    font-weight: 600;
                }
                .arix-text em {
                    font-style: italic;
                }
                .arix-text code {
                    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
                    font-size: 0.92em;
                    background: $codeBackgroundColor;
                    border-radius: 8px;
                    padding: 0.08em 0.34em;
                }
                .arix-text .katex {
                    white-space: normal;
                }
                .arix-text .katex-display {
                    margin: 0.45em 0;
                    overflow-x: auto;
                    overflow-y: hidden;
                    padding-bottom: 2px;
                }
                .arix-text .katex-display > .katex {
                    white-space: nowrap;
                }
            </style>
            <script defer src="$KatexScriptUrl"></script>
            <script defer src="$KatexAutoRenderScriptUrl"></script>
        </head>
        <body>
            <div class="arix-text">$contentHtml</div>
            <script>
                function reportArixHeight() {
                    const height = Math.max(
                        document.documentElement.scrollHeight || 0,
                        document.body.scrollHeight || 0,
                        $DefaultTextBlockMinHeightDp
                    );
                    if (window.$MarkdownHtmlBridgeName && window.$MarkdownHtmlBridgeName.reportHeight) {
                        window.$MarkdownHtmlBridgeName.reportHeight(String(height));
                    }
                }

                function bindArixLinks() {
                    const anchors = document.querySelectorAll('a[href]');
                    anchors.forEach(function(anchor) {
                        anchor.onclick = function(event) {
                            event.preventDefault();
                            const href = anchor.getAttribute('href');
                            if (href && window.$MarkdownHtmlBridgeName && window.$MarkdownHtmlBridgeName.reportLink) {
                                window.$MarkdownHtmlBridgeName.reportLink(href);
                            }
                            return false;
                        };
                    });
                }

                function renderArixMath() {
                    bindArixLinks();
                    try {
                        if (window.renderMathInElement) {
                            window.renderMathInElement(document.body, {
                                delimiters: [
                                    { left: '$$', right: '$$', display: true },
                                    { left: '\\\\[', right: '\\\\]', display: true },
                                    { left: '$', right: '$', display: false },
                                    { left: '\\\\(', right: '\\\\)', display: false }
                                ],
                                throwOnError: false,
                                strict: 'ignore',
                                ignoredTags: ['script', 'noscript', 'style', 'textarea', 'pre', 'code', 'option'],
                            });
                        }
                    } catch (error) {
                    } finally {
                        bindArixLinks();
                        setTimeout(reportArixHeight, 0);
                        setTimeout(reportArixHeight, 120);
                        setTimeout(reportArixHeight, 360);
                    }
                }

                window.reportArixHeight = reportArixHeight;
                window.addEventListener('resize', reportArixHeight);
                window.addEventListener('load', function() {
                    setTimeout(renderArixMath, 0);
                    setTimeout(reportArixHeight, 120);
                });
            </script>
        </body>
        </html>
    """.trimIndent()
}

private fun buildMarkdownTextVariantCss(
    variant: MarkdownHtmlTextVariant,
): String = when (variant) {
    MarkdownHtmlTextVariant.Paragraph,
    MarkdownHtmlTextVariant.ListItem,
    MarkdownHtmlTextVariant.Quote -> "font-size: 16px; line-height: 24px; font-weight: 400;"
    is MarkdownHtmlTextVariant.Heading -> when (variant.level) {
        1 -> "font-size: 28px; line-height: 34px; font-weight: 600;"
        2 -> "font-size: 22px; line-height: 30px; font-weight: 600;"
        3 -> "font-size: 18px; line-height: 26px; font-weight: 600;"
        else -> "font-size: 14px; line-height: 20px; font-weight: 600;"
    }
    is MarkdownHtmlTextVariant.TableCell -> if (variant.isHeader) {
        "font-size: 14px; line-height: 20px; font-weight: 600;"
    } else {
        "font-size: 14px; line-height: 20px; font-weight: 400;"
    }
}

private fun inlineMarkdownToHtml(
    text: String,
): String = buildString {
    appendInlineHtml(text)
}

private fun StringBuilder.appendInlineHtml(
    text: String,
) {
    var index = 0
    while (index < text.length) {
        val mathMatch = parseMarkdownMathAt(text, index)
        if (mathMatch != null) {
            append(escapeHtml(mathMatch.rawText))
            index = mathMatch.endExclusive
            continue
        }

        if (text.startsWith("**", index)) {
            val end = text.indexOf("**", index + 2)
            if (end > index + 2) {
                append("<strong>")
                appendInlineHtml(text.substring(index + 2, end))
                append("</strong>")
                index = end + 2
                continue
            }
        }

        if (text.startsWith("`", index)) {
            val end = text.indexOf('`', index + 1)
            if (end > index + 1) {
                append("<code>")
                append(escapeHtml(text.substring(index + 1, end)))
                append("</code>")
                index = end + 1
                continue
            }
        }

        val linkMatch = parseInlineMarkdownLink(text, index)
        if (linkMatch != null) {
            append("<a href=\"")
            append(escapeHtml(linkMatch.destination))
            append("\">")
            appendInlineHtml(linkMatch.label)
            append("</a>")
            index = linkMatch.endExclusive
            continue
        }

        val autoLink = parseAutoLink(text, index)
        if (autoLink != null) {
            append("<a href=\"")
            append(escapeHtml(autoLink.targetUrl))
            append("\">")
            append(escapeHtml(autoLink.displayText))
            append("</a>")
            index += autoLink.displayText.length
            continue
        }

        if (text.startsWith("*", index)) {
            val end = text.indexOf('*', index + 1)
            if (end > index + 1) {
                append("<em>")
                appendInlineHtml(text.substring(index + 1, end))
                append("</em>")
                index = end + 1
                continue
            }
        }

        append(escapeHtml(text[index].toString()))
        index++
    }
}

internal fun buildMarkdownBadgeGroupHtml(
    images: List<MarkdownImageSpec>,
): String {
    val imageTags = images.joinToString("\n") { image ->
        """<img src="${escapeHtml(image.url)}" alt="${escapeHtml(image.altText)}" />"""
    }
    return """
        <!DOCTYPE html>
        <html>
        <head>
            <meta name="viewport" content="width=device-width, initial-scale=1.0" />
            <style>
                html, body {
                    margin: 0;
                    padding: 0;
                    background: transparent;
                }
                .badge-row {
                    display: flex;
                    flex-wrap: wrap;
                    align-items: center;
                    gap: 6px;
                }
                img {
                    display: block;
                    width: auto;
                    height: auto;
                    max-width: 100%;
                    max-height: 32px;
                }
            </style>
        </head>
        <body>
            <div class="badge-row">$imageTags</div>
            <script>
                function reportArixHeight() {
                    const height = Math.max(
                        document.documentElement.scrollHeight || 0,
                        document.body.scrollHeight || 0,
                        1
                    );
                    if (window.$MarkdownHtmlBridgeName && window.$MarkdownHtmlBridgeName.reportHeight) {
                        window.$MarkdownHtmlBridgeName.reportHeight(String(height));
                    }
                }
                document.querySelectorAll('img').forEach(function(image) {
                    image.addEventListener('load', reportArixHeight);
                    image.addEventListener('error', function() {
                        image.style.display = 'none';
                        reportArixHeight();
                    });
                });
                window.reportArixHeight = reportArixHeight;
                window.addEventListener('load', function() {
                    setTimeout(reportArixHeight, 0);
                    setTimeout(reportArixHeight, 120);
                });
            </script>
        </body>
        </html>
    """.trimIndent()
}

internal fun buildMarkdownInlineSvgHtml(
    svg: String,
): String {
    val sanitizedSvg = sanitizeInlineMarkdownSvg(svg)
    return """
        <!DOCTYPE html>
        <html>
        <head>
            <meta name="viewport" content="width=device-width, initial-scale=1.0" />
            <style>
                html, body {
                    margin: 0;
                    padding: 0;
                    background: transparent;
                }
                body {
                    padding: 0;
                }
                .image-shell {
                    display: flex;
                    align-items: center;
                    justify-content: flex-start;
                }
                .image-shell > svg {
                    display: block;
                    max-width: 100%;
                    height: auto;
                    border-radius: 12px;
                }
            </style>
        </head>
        <body>
            <div id="preview-image" class="image-shell">
                $sanitizedSvg
            </div>
            <script>
                function reportArixHeight() {
                    const height = Math.max(
                        document.documentElement.scrollHeight || 0,
                        document.body.scrollHeight || 0,
                        1
                    );
                    if (window.$MarkdownHtmlBridgeName && window.$MarkdownHtmlBridgeName.reportHeight) {
                        window.$MarkdownHtmlBridgeName.reportHeight(String(height));
                    }
                }

                const image = document.getElementById('preview-image');
                if (image) {
                    image.addEventListener('click', function() {
                        if (window.$MarkdownHtmlBridgeName && window.$MarkdownHtmlBridgeName.reportTap) {
                            window.$MarkdownHtmlBridgeName.reportTap();
                        }
                    });
                }

                window.addEventListener('load', function() {
                    setTimeout(reportArixHeight, 0);
                    setTimeout(reportArixHeight, 120);
                });
            </script>
        </body>
        </html>
    """.trimIndent()
}

internal fun buildMarkdownImageHtml(
    imageUrl: String,
    loadErrorMessage: String,
): String = """
    <!DOCTYPE html>
    <html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <style>
            html, body {
                margin: 0;
                padding: 0;
                background: transparent;
            }
            body {
                padding: 0;
            }
            .image-shell {
                display: flex;
                align-items: center;
                justify-content: flex-start;
            }
            img {
                display: block;
                max-width: 100%;
                height: auto;
                border-radius: 12px;
            }
            .image-error {
                color: #6b7280;
                display: none;
                font: 14px sans-serif;
                padding: 16px;
            }
        </style>
    </head>
    <body>
        <div class="image-shell">
            <img id="preview-image" src="${escapeHtml(imageUrl)}" alt="" />
        </div>
        <div id="image-error" class="image-error">${escapeHtml(loadErrorMessage)}</div>
        <script>
            function reportArixHeight() {
                const height = Math.max(
                    document.documentElement.scrollHeight || 0,
                    document.body.scrollHeight || 0,
                    1
                );
                if (window.$MarkdownHtmlBridgeName && window.$MarkdownHtmlBridgeName.reportHeight) {
                    window.$MarkdownHtmlBridgeName.reportHeight(String(height));
                }
            }

            const image = document.getElementById('preview-image');
            if (image) {
                image.addEventListener('load', function() {
                    setTimeout(reportArixHeight, 0);
                    setTimeout(reportArixHeight, 120);
                });
                image.addEventListener('click', function() {
                    if (window.$MarkdownHtmlBridgeName && window.$MarkdownHtmlBridgeName.reportTap) {
                        window.$MarkdownHtmlBridgeName.reportTap();
                    }
                });
                image.addEventListener('error', function() {
                    const error = document.getElementById('image-error');
                    if (error) {
                        error.style.display = 'block';
                    }
                    image.style.display = 'none';
                    reportArixHeight();
                });
            }

            window.addEventListener('load', function() {
                setTimeout(reportArixHeight, 0);
                setTimeout(reportArixHeight, 120);
            });
        </script>
    </body>
    </html>
""".trimIndent()

internal fun sanitizeInlineMarkdownSvg(svg: String): String {
    var sanitized = svg
        .trim { it <= ' ' || it == '\uFEFF' }
        .replace(Regex("(?is)^\\s*<\\?xml[^>]*>"), "")

    sanitized = sanitized
        .replace(Regex("(?is)<script\\b[^>]*>.*?</script>"), "")
        .replace(Regex("(?is)<script\\b[^>]*>.*"), "")

    sanitized = sanitized
        .replace(Regex("(?i)\\s+on[a-z]+\\s*=\\s*\"[^\"]*\""), "")
        .replace(Regex("(?i)\\s+on[a-z]+\\s*=\\s*'[^']*'"), "")
        .replace(Regex("(?i)\\s+on\\w+\\s*=\\s*[^>\\s]+"), "")

    sanitized = svgHrefAttributePattern.replace(sanitized) { match ->
        val value = match.groupValues[2]
            .ifEmpty { match.groupValues[3] }
            .ifEmpty { match.groupValues[4] }
        if (isObfuscatedJavascriptUri(value)) "" else match.value
    }
    return sanitized.trim()
}

private val svgHrefAttributePattern = Regex(
    "(?i)\\s+(?:xlink:href|href)\\s*=\\s*(\"([^\"]*)\"|'([^']*)'|([^\\s>]+))",
)

private fun isObfuscatedJavascriptUri(value: String): Boolean {
    val normalized = decodeSvgHtmlEntities(value)
        .filterNot { it.isWhitespace() || it == '\u0000' }
        .lowercase()
    return normalized.startsWith("javascript:")
}

private fun decodeSvgHtmlEntities(value: String): String =
    Regex("&#x([0-9a-fA-F]+);|&#([0-9]+);|&(colon|tab|newline|sol);", RegexOption.IGNORE_CASE)
        .replace(value) { match ->
            val hex = match.groupValues[1]
            val decimal = match.groupValues[2]
            val named = match.groupValues[3].lowercase()
            when {
                hex.isNotEmpty() ->
                    runCatching { hex.toInt(16).toChar().toString() }.getOrDefault(match.value)
                decimal.isNotEmpty() ->
                    runCatching { decimal.toInt().toChar().toString() }.getOrDefault(match.value)
                else -> when (named) {
                    "colon" -> ":"
                    "tab" -> "\t"
                    "newline" -> "\n"
                    "sol" -> "/"
                    else -> match.value
                }
            }
        }

internal fun decodeMarkdownSvgText(bytes: ByteArray): String =
    bytes.toString(Charsets.UTF_8)

private fun buildMermaidHtml(
    code: String,
    layout: MarkdownMediaLayout,
    renderErrorTitle: String,
    invalidSyntaxError: String,
): String {
    val escapedCode = escapeHtml(code)
    val renderErrorTitleLiteral = jsStringLiteral(renderErrorTitle)
    val invalidSyntaxErrorLiteral = jsStringLiteral(invalidSyntaxError)
    val svgMaxWidth = if (layout.scroll) "none" else "100%"
    val containerWidthRule = if (layout.scroll) {
        "display: inline-block; min-width: 100%;"
    } else {
        ""
    }
    return """
        <!DOCTYPE html>
        <html>
        <head>
            <meta name="viewport" content="width=device-width, initial-scale=1.0" />
            <style>
                html, body {
                    margin: 0;
                    padding: 0;
                    background: transparent;
                    color: #111827;
                    font-family: sans-serif;
                }
                #container {
                    padding: 12px;
                    $containerWidthRule
                }
                svg {
                    max-width: $svgMaxWidth;
                    height: auto;
                }
                pre {
                    white-space: pre-wrap;
                    font-family: monospace;
                    background: #f5f5f5;
                    border-radius: 12px;
                    padding: 12px;
                }
                .mermaid-error {
                    padding: 12px;
                    color: #1f2937;
                    font-family: sans-serif;
                }
                .mermaid-error-title {
                    font-size: 15px;
                    font-weight: 600;
                    margin-bottom: 8px;
                }
                .mermaid-error-detail {
                    color: #6b7280;
                    font-size: 13px;
                }
                .mermaid-source {
                    margin: 0 0 10px;
                }
            </style>
            <script src="$MermaidScriptUrl"></script>
        </head>
        <body>
            <div id="container">
                <pre id="diagram" class="mermaid">$escapedCode</pre>
            </div>
            <script>
                const renderErrorTitle = $renderErrorTitleLiteral;
                const invalidSyntaxError = $invalidSyntaxErrorLiteral;

                function escapeHtml(value) {
                    return String(value || '')
                        .replace(/&/g, '&amp;')
                        .replace(/</g, '&lt;')
                        .replace(/>/g, '&gt;')
                        .replace(/"/g, '&quot;')
                        .replace(/'/g, '&#39;');
                }

                function reportArixHeight() {
                    const height = Math.max(
                        document.documentElement.scrollHeight || 0,
                        document.body.scrollHeight || 0,
                        220
                    );
                    if (window.$MarkdownHtmlBridgeName && window.$MarkdownHtmlBridgeName.reportHeight) {
                        window.$MarkdownHtmlBridgeName.reportHeight(String(height));
                    }
                }

                function reportArixTap() {
                    if (window.$MarkdownHtmlBridgeName && window.$MarkdownHtmlBridgeName.reportTap) {
                        window.$MarkdownHtmlBridgeName.reportTap();
                    }
                }

                function showMermaidError(code, detail) {
                    document.getElementById('container').innerHTML =
                        '<div class="mermaid-error">' +
                        '<div class="mermaid-error-title">' + escapeHtml(renderErrorTitle) + '</div>' +
                        '<pre class="mermaid-source">' + escapeHtml(code) + '</pre>' +
                        '<div class="mermaid-error-detail">' + escapeHtml(detail || invalidSyntaxError) + '</div>' +
                        '</div>';
                }

                async function renderDiagram() {
                    const element = document.getElementById('diagram');
                    const code = element.textContent.trim();
                    try {
                        if (!window.mermaid) {
                            throw new Error('Mermaid library failed to load.');
                        }
                        mermaid.initialize({ startOnLoad: false, securityLevel: 'strict', theme: 'neutral' });
                        await mermaid.parse(code, { suppressErrors: false });
                        const rendered = await mermaid.render('arix-mermaid-' + Date.now(), code);
                        if ((rendered.svg || '').includes('class="error-icon"') || (rendered.svg || '').includes('Syntax error in text')) {
                            throw new Error('Mermaid reported a syntax error.');
                        }
                        document.getElementById('container').innerHTML = rendered.svg;
                        document.getElementById('container').onclick = reportArixTap;
                    } catch (error) {
                        showMermaidError(
                            code,
                            error && error.message ? error.message : invalidSyntaxError,
                        );
                        document.getElementById('container').onclick = reportArixTap;
                    } finally {
                        setTimeout(reportArixHeight, 0);
                        setTimeout(reportArixHeight, 120);
                        setTimeout(reportArixHeight, 360);
                    }
                }

                window.addEventListener('load', renderDiagram);
            </script>
        </body>
        </html>
    """.trimIndent()
}

internal fun escapeHtml(value: String): String = buildString {
    value.forEach { character ->
        when (character) {
            '&' -> append("&amp;")
            '<' -> append("&lt;")
            '>' -> append("&gt;")
            '"' -> append("&quot;")
            '\'' -> append("&#39;")
            else -> append(character)
        }
    }
}

private fun jsStringLiteral(value: String): String = buildString {
    append('"')
    value.forEach { character ->
        when (character) {
            '\\' -> append("\\\\")
            '"' -> {
                append('\\')
                append('"')
            }
            '\n' -> append("\\n")
            '\r' -> append("\\r")
            '\t' -> append("\\t")
            '<' -> append("\\u003C")
            '>' -> append("\\u003E")
            '&' -> append("\\u0026")
            else -> append(character)
        }
    }
    append('"')
}

private fun Color.toCssHex(): String {
    val argb = toArgb()
    val alpha = (argb ushr 24) and 0xFF
    val red = (argb ushr 16) and 0xFF
    val green = (argb ushr 8) and 0xFF
    val blue = argb and 0xFF
    return if (alpha == 0xFF) {
        String.format("#%02X%02X%02X", red, green, blue)
    } else {
        String.format("#%02X%02X%02X%02X", red, green, blue, alpha)
    }
}

private class MarkdownHtmlBridge(
    private val onHeightMeasured: (Int) -> Unit,
    private val onTap: (() -> Unit)? = null,
    private val onLinkClick: ((String) -> Unit)? = null,
) {
    private val mainHandler = Handler(Looper.getMainLooper())

    @JavascriptInterface
    fun reportHeight(height: String?) {
        height?.toIntOrNull()?.let(onHeightMeasured)
    }

    @JavascriptInterface
    fun reportTap() {
        val callback = onTap ?: return
        mainHandler.post { callback() }
    }

    @JavascriptInterface
    fun reportLink(url: String?) {
        val targetUrl = url?.takeIf { it.isNotBlank() } ?: return
        val callback = onLinkClick ?: return
        mainHandler.post { callback(targetUrl) }
    }
}
