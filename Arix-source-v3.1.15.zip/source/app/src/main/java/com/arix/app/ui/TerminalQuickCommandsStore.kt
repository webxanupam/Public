package com.arix.app.ui

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class TerminalQuickCommand(
    val id: String,
    val command: String,
    val createdAtMillis: Long,
)

internal object TerminalQuickCommandsStore {
    private const val PREFERENCES_NAME = "arix_terminal_quick_commands"
    private const val KEY_COMMANDS_JSON = "commands_json"
    private const val KEY_SEEDED = "seeded"
    private const val MAX_COMMANDS = 60
    private const val MAX_COMMAND_LENGTH = 400

    fun preferences(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE)

    fun loadCommands(context: Context): List<TerminalQuickCommand> {
        val preferences = preferences(context)
        if (!preferences.getBoolean(KEY_SEEDED, false) &&
            preferences.getString(KEY_COMMANDS_JSON, null) == null
        ) {
            seedStarterCommands(preferences)
        }
        val raw = preferences.getString(KEY_COMMANDS_JSON, null) ?: return emptyList()
        val commands = runCatching { parseCommands(raw) }.getOrDefault(emptyList())
        return commands
    }

    fun addCommand(context: Context, command: String): TerminalQuickCommand? {
        val trimmed = command.trim()
        if (trimmed.isEmpty()) return null
        val normalized = trimmed.substring(0, trimmed.length.coerceAtMost(MAX_COMMAND_LENGTH))
        val preferences = preferences(context)
        val current = loadCommands(context).toMutableList()
        val existing = current.firstOrNull { it.command.equals(normalized, ignoreCase = true) }
        if (existing != null) {
            val promoted = existing.copy(createdAtMillis = System.currentTimeMillis())
            current.remove(existing)
            current.add(0, promoted)
            persist(preferences, current)
            return promoted
        }
        val entry = TerminalQuickCommand(
            id = UUID.randomUUID().toString(),
            command = normalized,
            createdAtMillis = System.currentTimeMillis(),
        )
        current.add(0, entry)
        while (current.size > MAX_COMMANDS) {
            current.removeAt(current.lastIndex)
        }
        persist(preferences, current)
        return entry
    }

    fun removeCommand(context: Context, commandId: String) {
        val preferences = preferences(context)
        val current = loadCommands(context)
        persist(preferences, current.filterNot { it.id == commandId })
    }

    private fun seedStarterCommands(preferences: SharedPreferences) {
        val now = System.currentTimeMillis()
        val starters = listOf(
            "pkg update && pkg upgrade -y",
            "pkg install -y python nodejs git",
            "ls -la",
            "df -h",
            "clear",
        )
        val entries = starters.mapIndexed { index, command ->
            TerminalQuickCommand(
                id = UUID.randomUUID().toString(),
                command = command,
                createdAtMillis = now - index,
            )
        }
        preferences.edit()
            .putString(KEY_COMMANDS_JSON, serializeCommands(entries))
            .putBoolean(KEY_SEEDED, true)
            .apply()
    }

    private fun persist(preferences: SharedPreferences, commands: List<TerminalQuickCommand>) {
        preferences.edit()
            .putString(KEY_COMMANDS_JSON, serializeCommands(commands))
            .putBoolean(KEY_SEEDED, true)
            .apply()
    }

    private fun serializeCommands(commands: List<TerminalQuickCommand>): String {
        val array = JSONArray()
        commands.forEach { command ->
            array.put(
                JSONObject()
                    .put("id", command.id)
                    .put("command", command.command)
                    .put("created_at", command.createdAtMillis),
            )
        }
        return array.toString()
    }

    private fun parseCommands(raw: String): List<TerminalQuickCommand> {
        val array = JSONArray(raw)
        val commands = mutableListOf<TerminalQuickCommand>()
        for (index in 0 until array.length()) {
            val entry = array.optJSONObject(index) ?: continue
            val command = entry.optString("command").trim()
            if (command.isEmpty()) continue
            commands += TerminalQuickCommand(
                id = entry.optString("id").ifBlank { UUID.randomUUID().toString() },
                command = command,
                createdAtMillis = entry.optLong("created_at", 0L),
            )
        }
        return commands.sortedByDescending { it.createdAtMillis }
    }
}
