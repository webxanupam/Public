package com.arix.app.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.vladsch.flexmark.html2md.converter.FlexmarkHtmlConverter
import com.arix.app.data.pi.PiKernelBridge
import com.arix.app.runtime.TermuxRuntime
import java.io.File
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import org.json.JSONArray
import org.json.JSONObject

private const val PiPackagesUrl = "https://pi.dev/packages"
private const val MaxExtensionArchiveBytes = 32L * 1024L * 1024L
private const val MaxExtensionExtractedBytes = 128L * 1024L * 1024L
private const val MaxExtensionEntryBytes = 16L * 1024L * 1024L
private const val MaxExtensionZipEntries = 4096
private const val MaxExtensionBackupEntries = 8192
private const val ExtensionDependencyInstallTimeoutMillis = 5L * 60L * 1000L
private val ExtensionFilePattern = Regex(""".*\.(?:[cm]?[jt]s)$""", RegexOption.IGNORE_CASE)
private val ExtensionIndexNames = setOf(
    "index.ts",
    "index.js",
    "index.mts",
    "index.mjs",
    "index.cts",
    "index.cjs",
)

enum class ArixExtensionInstallKind {
    Package,
    Imported,
}

data class InstalledArixExtension(
    val id: String,
    val name: String,
    val source: String,
    val version: String = "",
    val description: String = "",
    val installedPath: String = "",
    val extensionCount: Int = 0,
    val scriptExtensionCount: Int = 0,
    val nativeEntrypointCount: Int = 0,
    val skillCount: Int = 0,
    val promptCount: Int = 0,
    val themeCount: Int = 0,
    val isEnabled: Boolean = true,
    val kind: ArixExtensionInstallKind,
)

enum class ArixPackageCompatibilityIssue {
    InteractiveUi,
    Theme,
    Prompt,
    Platform,
}

data class ArixExtensionCatalogEntry(
    val name: String,
    val source: String,
    val description: String,
    val author: String,
    val monthlyDownloads: Long,
    val packageUrl: String,
    val npmUrl: String,
    val repositoryUrl: String,
    val types: List<String> = emptyList(),
    val compatibilityIssue: ArixPackageCompatibilityIssue? = null,
)

data class ArixPackageDetails(
    val source: String,
    val name: String,
    val description: String,
    val version: String,
    val published: String,
    val downloads: String,
    val author: String,
    val license: String,
    val size: String,
    val dependencies: String,
    val types: List<String>,
    val manifestJson: String,
    val readmeMarkdown: String,
    val packageUrl: String,
    val npmUrl: String,
    val repositoryUrl: String,
    val compatibilityIssue: ArixPackageCompatibilityIssue?,
)

internal fun parseArixPackageCatalog(html: String): List<ArixExtensionCatalogEntry> {
    val document = Jsoup.parse(html, PiPackagesUrl)
    return document
        .select("article[data-package-card]")
        .mapNotNull { card ->
            val declaredTypes = card.attr("data-package-types")
                .split(',', ' ')
                .map { it.trim() }
                .filter { it.isNotBlank() }
            val badgeTypes = card.select(".packages-badges [data-type]")
                .map { it.attr("data-type").trim() }
                .filter { it.isNotBlank() && !it.equals("package", ignoreCase = true) }
            val types = (declaredTypes + badgeTypes)
                .distinctBy { it.lowercase(Locale.US) }
            val name = card.attr("data-package-name").trim()
            val installCommand = card.selectFirst("[data-copy-text^=\"pi install \"]")
                ?.attr("data-copy-text")
                ?.trim()
                .orEmpty()
            val source = installCommand.removePrefix("pi install ").trim()
            if (name.isBlank() || !source.startsWith("npm:")) {
                return@mapNotNull null
            }
            val metadata = card.select(".packages-meta span")
            val packagePath = card.selectFirst("[data-package-path]")
                ?.attr("data-package-path")
                .orEmpty()
            val links = card.select(".packages-links a[href]")
            val description = card.selectFirst(".packages-desc")?.text().orEmpty()
            val searchText = card.attr("data-package-search")
            ArixExtensionCatalogEntry(
                name = name,
                source = source,
                description = description,
                author = metadata.firstOrNull()?.text().orEmpty(),
                monthlyDownloads = card.attr("data-package-downloads").toLongOrNull() ?: 0L,
                packageUrl = if (packagePath.isBlank()) "" else "https://pi.dev$packagePath",
                npmUrl = links.firstOrNull { it.attr("href").contains("npmjs.com/package/") }
                    ?.attr("href")
                    .orEmpty(),
                repositoryUrl = links.firstOrNull {
                    val href = it.attr("href")
                    href.contains("github.com/") && !href.contains("/issues/new")
                }?.attr("href").orEmpty(),
                types = types,
                compatibilityIssue = detectArixPackageCompatibility(
                    name = name,
                    description = "$description $searchText",
                    types = types,
                ),
            )
        }
        .distinctBy(ArixExtensionCatalogEntry::source)
        .sortedWith(
            compareByDescending<ArixExtensionCatalogEntry> { it.monthlyDownloads }
                .thenBy { it.name.lowercase(Locale.US) }
        )
}

internal fun parseArixPackageDetails(
    html: String,
    packageUrl: String,
): ArixPackageDetails {
    val document = Jsoup.parse(html, packageUrl)
    val definitionValues = buildMap {
        val terms = document.select(".detail-grid dt")
        val definitions = document.select(".detail-grid dd")
        terms.forEachIndexed { index, term ->
            val key = term.text().trim().lowercase(Locale.US)
            if (key.isNotBlank()) {
                put(key, definitions.getOrNull(index)?.text().orEmpty())
            }
        }
    }
    val installCommand = document.selectFirst("[data-copy-text^=\"pi install \"]")
        ?.attr("data-copy-text")
        ?.trim()
        .orEmpty()
    val source = installCommand.removePrefix("pi install ").trim()
    val types = document.select(".packages-badges [data-type]")
        .map { it.attr("data-type").trim() }
        .filter { it.isNotBlank() && !it.equals("package", ignoreCase = true) }
        .ifEmpty {
            definitionValues["types"]
                .orEmpty()
                .split(',', ' ')
                .map(String::trim)
                .filter(String::isNotBlank)
        }
        .distinctBy { it.lowercase(Locale.US) }
    val links = document.select(".packages-detail-links a[href]")
    val readmeRoot = document.selectFirst(".packages-readme")
    readmeRoot?.select("[href]")?.forEach { element ->
        element.absUrl("href").takeIf(String::isNotBlank)?.let { element.attr("href", it) }
    }
    readmeRoot?.select("[src]")?.forEach { element ->
        element.absUrl("src").takeIf(String::isNotBlank)?.let { element.attr("src", it) }
    }
    val readmeMarkdown = readmeRoot
        ?.let { FlexmarkHtmlConverter.builder().build().convert(it.outerHtml()).trim() }
        .orEmpty()
    val description = document.selectFirst(".content-description")?.text().orEmpty()
    val name = document.selectFirst(".content-title")?.text().orEmpty()
        .ifBlank { definitionValues["package"].orEmpty() }
    val manifestJson = document.selectFirst(".raw-data-panel")?.text().orEmpty()
    return ArixPackageDetails(
        source = source,
        name = name,
        description = description,
        version = definitionValues["version"].orEmpty(),
        published = definitionValues["published"].orEmpty(),
        downloads = definitionValues["downloads"].orEmpty(),
        author = definitionValues["author"].orEmpty(),
        license = definitionValues["license"].orEmpty(),
        size = definitionValues["size"].orEmpty(),
        dependencies = definitionValues["dependencies"].orEmpty(),
        types = types,
        manifestJson = manifestJson,
        readmeMarkdown = readmeMarkdown,
        packageUrl = packageUrl,
        npmUrl = links.firstOrNull { it.attr("href").contains("npmjs.com/package/") }
            ?.attr("href")
            .orEmpty(),
        repositoryUrl = links.firstOrNull {
            val href = it.attr("href")
            href.contains("github.com/") && !href.contains("/issues/new")
        }?.attr("href").orEmpty(),
        compatibilityIssue = detectArixPackageCompatibility(
            name = name,
            description = description,
            types = types,
            readmeMarkdown = readmeMarkdown,
            manifestJson = manifestJson,
        ),
    )
}

internal fun detectArixPackageCompatibility(
    name: String,
    description: String,
    types: List<String>,
    readmeMarkdown: String = "",
    manifestJson: String = "",
): ArixPackageCompatibilityIssue? {
    val normalizedTypes = types.map { it.lowercase(Locale.US) }.toSet()
    val text = listOf(name, description, readmeMarkdown, manifestJson)
        .joinToString(" ")
        .lowercase(Locale.US)
    val interactiveUiSignals = listOf(
        "interactive tui",
        "terminal ui",
        "live overlay",
        "status bar",
        "powerline footer",
        "custom footer",
        "custom header",
        "keyboard shortcut",
        "clickable tui",
        "tui click",
        "tui overlay",
        "plan review with annotations",
        "structured questionnaire",
        "webview window",
        "local browser ui",
        "micro-ui",
        "ctx.ui",
        "registershortcut",
    )
    if (
        interactiveUiSignals.any(text::contains) ||
        Regex("""\btui\b""").containsMatchIn(text)
    ) {
        return ArixPackageCompatibilityIssue.InteractiveUi
    }
    if ("theme" in normalizedTypes) {
        return ArixPackageCompatibilityIssue.Theme
    }
    val platformSignals = listOf(
        "macos only",
        "windows only",
        "darwin only",
        "requires macos",
        "requires windows",
        "x64 only",
        "amd64 only",
    )
    if (platformSignals.any(text::contains)) {
        return ArixPackageCompatibilityIssue.Platform
    }
    if ("prompt" in normalizedTypes && normalizedTypes.none { it == "extension" || it == "skill" }) {
        return ArixPackageCompatibilityIssue.Prompt
    }
    return null
}

/**
 * Manages Pi/Arix extension packages: the pi.dev catalog, npm package
 * install/update/remove through the bridge, and .zip / single-file imports
 * into the guest extension directories.
 */
class ArixExtensionPackageManager(
    context: Context,
    private val termuxRuntime: TermuxRuntime,
    private val piKernelBridge: PiKernelBridge,
    private val stateRepository: ArixExtensionStateRepository,
    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build(),
) {
    private val appContext = context.applicationContext

    suspend fun fetchCatalog(): Result<List<ArixExtensionCatalogEntry>> = withContext(Dispatchers.IO) {
        runCatching {
            val request = Request.Builder()
                .url(PiPackagesUrl)
                .header("Accept", "text/html")
                .header("User-Agent", "Arix-Android")
                .build()
            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    error("Pi package catalog failed with HTTP ${response.code}.")
                }
                val html = response.body?.string() ?: error("Pi package catalog returned an empty body.")
                parseArixPackageCatalog(html)
            }
        }
    }

    suspend fun fetchPackageDetails(
        entry: ArixExtensionCatalogEntry,
    ): Result<ArixPackageDetails> = withContext(Dispatchers.IO) {
        runCatching {
            require(entry.packageUrl.startsWith("https://pi.dev/packages/")) {
                "Package details must come from pi.dev."
            }
            val request = Request.Builder()
                .url(entry.packageUrl)
                .header("Accept", "text/html")
                .header("User-Agent", "Arix-Android")
                .build()
            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    error("Pi package details failed with HTTP ${response.code}.")
                }
                val html = response.body?.string()
                    ?: error("Pi package details returned an empty body.")
                parseArixPackageDetails(html, entry.packageUrl).let { details ->
                    details.copy(
                        source = details.source.ifBlank { entry.source },
                        name = details.name.ifBlank { entry.name },
                        description = details.description.ifBlank { entry.description },
                        npmUrl = details.npmUrl.ifBlank { entry.npmUrl },
                        repositoryUrl = details.repositoryUrl.ifBlank { entry.repositoryUrl },
                        compatibilityIssue = details.compatibilityIssue ?: entry.compatibilityIssue,
                    )
                }
            }
        }
    }

    suspend fun listInstalled(): Result<List<InstalledArixExtension>> = withContext(Dispatchers.IO) {
        runCatching {
            val disabledIds = stateRepository.disabledExtensionIds.first()
            val packageResponse = piKernelBridge.listExtensionPackages()
            val packages = packageResponse.optJSONArray("packages")
            val installedPackages = buildList {
                if (packages != null) {
                    for (index in 0 until packages.length()) {
                        val item = packages.optJSONObject(index) ?: continue
                        val source = item.optString("source").trim()
                        if (source.isBlank()) continue
                        add(
                            InstalledArixExtension(
                                id = "package:$source",
                                name = item.optString("name").ifBlank {
                                    source.removePrefix("npm:")
                                },
                                source = source,
                                version = item.optString("version"),
                                description = item.optString("description"),
                                installedPath = item.optString("installed_path"),
                                extensionCount = item.optInt("extension_count"),
                                scriptExtensionCount = item.optInt(
                                    "arix_extension_count",
                                    item.optInt("aether_extension_count"),
                                ),
                                nativeEntrypointCount = item.optInt("native_entrypoint_count"),
                                skillCount = item.optInt("skill_count"),
                                promptCount = item.optInt("prompt_count"),
                                themeCount = item.optInt("theme_count"),
                                kind = ArixExtensionInstallKind.Package,
                            )
                        )
                    }
                }
            }
            val disabledOptions = stateRepository.loadOptions()
            (installedPackages + listImportedExtensions())
                .map { extension ->
                    val baseName = extension.installedPath.substringAfterLast('/')
                    val isExplicitlyDisabled = extension.id in disabledIds ||
                        extension.installedPath in disabledOptions.disabledExtensionPaths ||
                        disabledIds.any { it.substringAfterLast('/') == baseName } ||
                        disabledOptions.disabledExtensionPaths.any { it.substringAfterLast('/') == baseName }
                    extension.copy(isEnabled = !isExplicitlyDisabled)
                }
                .distinctBy(InstalledArixExtension::id)
                .sortedBy { it.name.lowercase(Locale.US) }
        }
    }

    suspend fun installPackage(source: String, onProgress: suspend (String) -> Unit = {}): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                val response = piKernelBridge.installExtensionPackage(
                    source,
                    stateRepository.loadOptions(),
                    onProgress,
                )
                requireExtensionReloadSucceeded(response.optJSONObject("reload"))
                Unit
            }
        }

    suspend fun updatePackage(source: String, onProgress: suspend (String) -> Unit = {}): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                val response = piKernelBridge.updateExtensionPackage(
                    source,
                    stateRepository.loadOptions(),
                    onProgress,
                )
                requireExtensionReloadSucceeded(response.optJSONObject("reload"))
                Unit
            }
        }

    suspend fun remove(extension: InstalledArixExtension): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            stateRepository.setEnabled(extension.id, enabled = true)
            when (extension.kind) {
                ArixExtensionInstallKind.Package -> {
                    val response = piKernelBridge.removeExtensionPackage(
                        extension.source,
                        stateRepository.loadOptions(),
                    )
                    require(response.optBoolean("removed")) {
                        "No installed extension matched ${extension.source}."
                    }
                    requireExtensionReloadSucceeded(
                        piKernelBridge.reloadAllExtensions(stateRepository.loadOptions())
                    )
                }

                ArixExtensionInstallKind.Imported -> {
                    removeImportedExtension(extension.installedPath)
                    requireExtensionReloadSucceeded(
                        piKernelBridge.reloadAllExtensions(stateRepository.loadOptions())
                    )
                }
            }
            Unit
        }
    }

    suspend fun setEnabled(
        extension: InstalledArixExtension,
        enabled: Boolean,
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            stateRepository.setEnabled(extension.id, enabled)
            requireExtensionReloadSucceeded(
                piKernelBridge.reloadAllExtensions(stateRepository.loadOptions())
            )
            Unit
        }
    }

    suspend fun loadOptions(): ArixExtensionLoadOptions = stateRepository.loadOptions()

    suspend fun importFromUri(uri: Uri): Result<InstalledArixExtension> = withContext(Dispatchers.IO) {
        runCatching {
            val displayName = queryDisplayName(uri)
            val importRoot = termuxRuntime.ensureGuestDirectory(ArixExtensionGuestDirectory)
            val transaction = if (displayName.endsWith(".zip", ignoreCase = true)) {
                importZip(uri, displayName, importRoot)
            } else {
                importExtensionFile(uri, displayName, importRoot)
            }
            try {
                requireExtensionReloadSucceeded(
                    piKernelBridge.reloadAllExtensions(stateRepository.loadOptions())
                )
                val installed = importedExtension(transaction.destination, "arix")
                    ?: error("The imported source did not contain a loadable Arix or Pi extension.")
                transaction.commit()
                installed
            } catch (throwable: Throwable) {
                val rollbackFailure = runCatching {
                    transaction.rollback()
                }.exceptionOrNull()
                rollbackFailure?.let(throwable::addSuppressed)
                if (rollbackFailure == null) {
                    runCatching {
                        requireExtensionReloadSucceeded(
                            piKernelBridge.reloadAllExtensions(stateRepository.loadOptions())
                        )
                    }.exceptionOrNull()?.let(throwable::addSuppressed)
                }
                throw throwable
            }
        }
    }

    private suspend fun listImportedExtensions(): List<InstalledArixExtension> {
        suspend fun resolveRoot(guestPath: String): File? = try {
            termuxRuntime.resolveGuestPath(guestPath)
        } catch (error: Throwable) {
            null
        }
        val roots = listOf(
            "arix" to resolveRoot(ArixExtensionGuestDirectory),
            "pi" to resolveRoot(PiUserExtensionGuestDirectory),
        )
        return roots.flatMap { (scope, root) ->
            root?.listFiles()
                .orEmpty()
                .filterNot { it.name.startsWith(".arix-import-") }
                .mapNotNull { importedExtension(it, scope) }
        }
    }

    private fun importedExtension(file: File, scope: String): InstalledArixExtension? {
        val manifest = if (file.isDirectory) {
            runCatching {
                File(file, "package.json").takeIf(File::isFile)
                    ?.readText(Charsets.UTF_8)
                    ?.let(::JSONObject)
            }.getOrNull()
        } else {
            null
        }
        val piEntryCount = when {
            file.isFile && ExtensionFilePattern.matches(file.name) -> 1
            file.isDirectory -> packageExtensionEntries(file, "pi").size
            else -> 0
        }
        val scriptEntryCount = if (file.isDirectory) {
            packageExtensionEntries(file, "arix").size +
                packageExtensionEntries(file, "aether").size
        } else {
            0
        }
        val nativeEntrypointCount = manifest?.nativeEntrypoints()?.length() ?: 0
        if (
            piEntryCount == 0 &&
            scriptEntryCount == 0 &&
            nativeEntrypointCount == 0
        ) return null
        val guestRoot = if (scope == "pi") PiUserExtensionGuestDirectory else ArixExtensionGuestDirectory
        return InstalledArixExtension(
            id = "import:$scope:$guestRoot/${file.name}",
            name = manifest?.optString("name").orEmpty().ifBlank { file.nameWithoutExtension },
            source = if (scope == "pi") "Pi user directory" else "Imported",
            version = manifest?.optString("version").orEmpty(),
            description = manifest?.optString("description").orEmpty(),
            installedPath = file.canonicalPath,
            extensionCount = piEntryCount,
            scriptExtensionCount = scriptEntryCount,
            nativeEntrypointCount = nativeEntrypointCount,
            kind = ArixExtensionInstallKind.Imported,
        )
    }

    private fun packageExtensionEntries(
        directory: File,
        namespace: String = "pi",
    ): List<File> {
        val manifest = runCatching {
            File(directory, "package.json").takeIf(File::isFile)
                ?.readText(Charsets.UTF_8)
                ?.let(::JSONObject)
        }.getOrNull()
        val configuredEntries = manifest
            ?.optJSONObject(namespace)
            ?.optJSONArray("extensions")
            ?.let { extensions ->
                buildList {
                    for (index in 0 until extensions.length()) {
                        val relativePath = extensions.optString(index).trim()
                        if (relativePath.isNotBlank()) {
                            add(File(directory, relativePath))
                        }
                    }
                }
            }
            .orEmpty()
            .filter(File::isFile)
        if (configuredEntries.isNotEmpty()) return configuredEntries
        if (namespace != "pi" || (manifest?.optJSONObject("aether") != null && manifest.optJSONObject("arix") != null)) {
            return emptyList()
        }
        return ExtensionIndexNames
            .map { File(directory, it) }
            .filter(File::isFile)
    }

    private fun importExtensionFile(
        uri: Uri,
        displayName: String,
        importRoot: File,
    ): ImportedExtensionTransaction {
        require(ExtensionFilePattern.matches(displayName)) {
            "Choose an extension JavaScript/TypeScript file or a .zip package."
        }
        val safeName = sanitizeFileName(displayName)
        val staging = File(importRoot, ".arix-import-${UUID.randomUUID()}-$safeName")
        val destination = File(importRoot, safeName)
        try {
            appContext.contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "Unable to open the selected extension file." }
                staging.outputStream().use { output ->
                    copyWithLimit(input, output, MaxExtensionEntryBytes)
                }
            }
            return replaceImportedExtension(staging, destination)
        } finally {
            staging.deleteRecursively()
        }
    }

    private suspend fun importZip(
        uri: Uri,
        displayName: String,
        importRoot: File,
    ): ImportedExtensionTransaction {
        val extractionRoot = File(importRoot, ".arix-import-${UUID.randomUUID()}").apply {
            require(mkdirs()) { "Unable to prepare extension import." }
        }
        try {
            appContext.contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "Unable to open the selected extension archive." }
                extractZip(input, extractionRoot)
            }
            val packageRoot = locatePackageRoot(extractionRoot)
            val manifestName = runCatching {
                File(packageRoot, "package.json").takeIf(File::isFile)
                    ?.readText(Charsets.UTF_8)
                    ?.let(::JSONObject)
                    ?.optString("name")
            }.getOrNull().orEmpty()
            val destinationName = sanitizeDirectoryName(
                manifestName.ifBlank { displayName.substringBeforeLast('.') }
            )
            val staging = File(importRoot, ".arix-import-${UUID.randomUUID()}-$destinationName")
            try {
                require(packageRoot.copyRecursively(staging, overwrite = false)) {
                    "Unable to stage the imported extension package."
                }
                installImportedPackageDependencies(
                    packageRoot = staging,
                    guestDirectory = "$ArixExtensionGuestDirectory/${staging.name}",
                )
                val destination = File(importRoot, destinationName)
                return replaceImportedExtension(staging, destination)
            } finally {
                staging.deleteRecursively()
            }
        } finally {
            extractionRoot.deleteRecursively()
        }
    }

    private suspend fun installImportedPackageDependencies(
        packageRoot: File,
        guestDirectory: String,
    ) {
        val plan = npmInstallPlanForPackage(packageRoot) ?: return
        val result = JSONObject(
            termuxRuntime.executeCommand(
                command = plan.command,
                workingDirectory = guestDirectory,
                awaitTimeoutMillis = ExtensionDependencyInstallTimeoutMillis,
            )
        )
        require(result.optBoolean("ok")) {
            result.optString("stderr").trim()
                .ifBlank { result.optString("stdout").trim() }
                .ifBlank { result.optString("errmsg").trim() }
                .ifBlank { "Unable to install extension npm dependencies." }
        }
    }

    private data class NpmInstallPlan(val command: String)

    private fun npmInstallPlanForPackage(packageRoot: File): NpmInstallPlan? {
        val manifest = runCatching {
            File(packageRoot, "package.json").takeIf(File::isFile)
                ?.readText(Charsets.UTF_8)
                ?.let(::JSONObject)
        }.getOrNull() ?: return null
        val hasDependencies = listOf("dependencies", "optionalDependencies", "peerDependencies")
            .any { (manifest.optJSONObject(it)?.length() ?: 0) > 0 }
        if (!hasDependencies) return null
        val command = if (File(packageRoot, "package-lock.json").isFile) "npm ci" else "npm install"
        return NpmInstallPlan(
            "$command --omit=dev --omit=optional --legacy-peer-deps --no-audit --no-fund --prefer-offline"
        )
    }

    private fun replaceImportedExtension(
        staging: File,
        destination: File,
    ): ImportedExtensionTransaction {
        val replaced = destination.exists()
        if (replaced) {
            destination.deleteRecursively()
        }
        require(staging.renameTo(destination)) { "Unable to move the imported extension into place." }
        return ImportedExtensionTransaction(
            destination = destination,
            replaced = replaced,
        )
    }

    private suspend fun removeImportedExtension(installedPath: String) {
        suspend fun resolveRoot(guestPath: String): File? = try {
            termuxRuntime.resolveGuestPath(guestPath)
        } catch (error: Throwable) {
            null
        }
        val guestRoots = listOf(
            resolveRoot(ArixExtensionGuestDirectory),
            resolveRoot(PiUserExtensionGuestDirectory),
        ).filterNotNull()
        val target = File(installedPath)
        require(guestRoots.any { root -> target.canonicalPath.startsWith(root.canonicalPath + File.separator) }) {
            "Refusing to remove an extension outside the managed directories."
        }
        require(target.deleteRecursively()) { "Unable to remove ${target.name}." }
    }

    private fun queryDisplayName(uri: Uri): String {
        appContext.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor ->
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0 && cursor.moveToFirst()) {
                    cursor.getString(index)?.takeIf(String::isNotBlank)?.let { return it }
                }
            }
        return uri.lastPathSegment?.substringAfterLast('/')?.takeIf(String::isNotBlank)
            ?: "extension-${UUID.randomUUID()}"
    }

    private fun sanitizeFileName(displayName: String): String =
        sanitizeDirectoryName(displayName.substringBeforeLast('.')) +
            "." + displayName.substringAfterLast('.', "js").lowercase(Locale.US)

    private fun sanitizeDirectoryName(value: String): String {
        val cleaned = value.trim()
            .replace(Regex("[^A-Za-z0-9._-]+"), "-")
            .trim('-', '.')
        return cleaned.ifBlank { "extension-${UUID.randomUUID().toString().take(8)}" }
    }

    private fun locatePackageRoot(extractionRoot: File): File {
        val manifest = File(extractionRoot, "package.json")
        if (manifest.isFile) return extractionRoot
        val children = extractionRoot.listFiles()
            ?.filter { it.isDirectory && !it.name.startsWith("__MACOSX") }
            .orEmpty()
        if (children.size == 1) {
            val nested = File(children[0], "package.json")
            if (nested.isFile) return children[0]
        }
        return extractionRoot
    }

    private fun copyWithLimit(input: java.io.InputStream, output: java.io.OutputStream, limit: Long) {
        val buffer = ByteArray(64 * 1024)
        var total = 0L
        while (true) {
            val read = input.read(buffer)
            if (read < 0) break
            total += read
            require(total <= limit) { "The selected extension file is too large." }
            output.write(buffer, 0, read)
        }
    }

    private fun extractZip(input: java.io.InputStream, destination: File) {
        val canonicalRoot = destination.canonicalPath + File.separator
        var entries = 0
        var total = 0L
        ZipInputStream(input.buffered()).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                entries += 1
                require(entries <= MaxExtensionZipEntries) { "Archive contains too many files." }
                val output = File(destination, entry.name)
                require(output.canonicalPath.startsWith(canonicalRoot)) {
                    "Unsafe path in archive: ${entry.name}"
                }
                if (entry.isDirectory) {
                    output.mkdirs()
                } else {
                    output.parentFile?.mkdirs()
                    output.outputStream().use { out ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            val read = zip.read(buffer)
                            if (read < 0) break
                            total += read
                            require(total <= MaxExtensionExtractedBytes) {
                                "Archive is too large when unpacked."
                            }
                            out.write(buffer, 0, read)
                        }
                    }
                }
                zip.closeEntry()
            }
        }
    }

    private fun JSONObject.nativeEntrypoints(): JSONArray {
        val appManifest = optJSONObject("arix") ?: optJSONObject("aether") ?: return JSONArray()
        val native = appManifest.optJSONObject("native") ?: return JSONArray()
        if (native.optBoolean("enabled", true) == false) return JSONArray()
        val entrypoints = native.optJSONArray("entrypoints")
        if (entrypoints != null) return entrypoints
        val single = native.optString("entrypoint").trim()
        return if (single.isNotBlank()) JSONArray().put(single) else JSONArray()
    }

    private fun requireExtensionReloadSucceeded(reload: JSONObject?) {
        if (reload == null || reload.optBoolean("succeeded", true)) return
        val arixReload = reload.optJSONObject("arix_reload")
        val errors = arixReload?.optJSONArray("errors") ?: reload.optJSONArray("errors")
        val message = buildList {
            if (errors != null) {
                for (index in 0 until errors.length()) {
                    errors.optJSONObject(index)
                        ?.optString("error")
                        ?.takeIf(String::isNotBlank)
                        ?.let(::add)
                }
            }
        }.distinct().take(3).joinToString("; ")
            .ifBlank { "The extension reload failed." }
        throw IllegalStateException(message)
    }
}

private class ImportedExtensionTransaction(
    val destination: File,
    private val replaced: Boolean,
) {
    private val backup = if (replaced) {
        val backupDir = File(destination.parentFile, ".arix-import-backup-${UUID.randomUUID()}")
        destination.renameTo(backupDir)
        backupDir
    } else {
        null
    }

    fun commit() {
        backup?.deleteRecursively()
    }

    fun rollback() {
        if (backup != null) {
            destination.deleteRecursively()
            require(backup.renameTo(destination)) { "Unable to restore the previous extension." }
        } else {
            destination.deleteRecursively()
        }
    }
}
