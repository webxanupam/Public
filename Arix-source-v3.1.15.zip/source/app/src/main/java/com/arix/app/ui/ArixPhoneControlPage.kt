package com.arix.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.arix.app.agent.ArixPhoneServices
import com.arix.app.agent.shell.BuiltinShellFix
import com.arix.app.agent.shell.BuiltinShellStatus
import com.arix.app.agent.setup.PhoneSetupCopy
import kotlinx.coroutines.launch

/**
 * v3.1.15 — Settings › Phone control (Mika port): the wireless-debugging pairing
 * wizard + live status of the phone-control helper. Same flow as Mika's setup:
 * pair once from Developer options › Wireless debugging; Arix then turns on its
 * accessibility service by itself and keeps the helper alive in the background.
 */
@Composable
fun ArixPhoneControlPage(
    phone: ArixPhoneServices,
    onBack: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val status by phone.shellControl.status.collectAsState()
    val discovery by phone.shellControl.pairingDiscovery.collectAsState()
    val paired = phone.shellControl.paired
    var code by remember { mutableStateOf("") }
    var port by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        phone.shellManager.start()
        phone.pairing.begin()
    }

    SubPageScaffold(
        title = "Phone control",
        onBack = onBack,
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState()),
        ) {
            Text(
                PhoneSetupCopy.INTRO,
                style = MaterialTheme.typography.bodySmall,
                color = com.arix.app.ui.theme.ArixOnSurfaceVariant,
            )

            Spacer(Modifier.height(16.dp))

            StatusCard(status)

            if (!paired && status !is BuiltinShellStatus.Running) {
                Spacer(Modifier.height(20.dp))
                Text("Pair once", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                Text(
                    "1. Open the phone's Settings › System › Developer options › Wireless debugging\n" +
                        "2. Tap \"Pair device with pairing code\"\n" +
                        "3. Enter the 6-digit code below (Arix fills the port by itself when it can see the window)",
                    style = MaterialTheme.typography.bodySmall,
                    color = com.arix.app.ui.theme.ArixOnSurfaceVariant,
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = code,
                    onValueChange = { value -> code = value.filter(Char::isDigit).take(6) },
                    label = { Text(PhoneSetupCopy.CODE_LABEL) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = port,
                    onValueChange = { value -> port = value.filter(Char::isDigit).take(5) },
                    label = { Text(PhoneSetupCopy.PORT_LABEL) },
                    supportingText = { Text(PhoneSetupCopy.PORT_HINT) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(
                        onClick = {
                            val c = code.trim()
                            if (c.length == 6) {
                                scope.launch {
                                    phone.pairing.submit(c, port.trim().toIntOrNull())
                                }
                            }
                        },
                        enabled = code.trim().length == 6,
                    ) { Text(PhoneSetupCopy.SUBMIT) }
                    TextButton(onClick = {
                        scope.launch { phone.pairing.begin() }
                    }) { Text("Look for the pairing window again") }
                }
                if (status == BuiltinShellStatus.Connecting) {
                    Spacer(Modifier.height(8.dp))
                    Text(PhoneSetupCopy.WORKING, style = MaterialTheme.typography.bodySmall)
                }
            }

            if (status is BuiltinShellStatus.Failed) {
                val failed = status as BuiltinShellStatus.Failed
                Spacer(Modifier.height(12.dp))
                Card(
                    Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text(failed.reason.let { PhoneSetupCopy.failure(it).title }, style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            failed.reason.let { PhoneSetupCopy.failure(it).body },
                            style = MaterialTheme.typography.bodySmall,
                            color = com.arix.app.ui.theme.ArixOnSurfaceVariant,
                        )
                        Spacer(Modifier.height(8.dp))
                        TextButton(onClick = {
                            scope.launch { phone.shellControl.retry() }
                        }) { Text(PhoneSetupCopy.fixLabel(failed.fix)) }
                    }
                }
            }

            if (paired || status is BuiltinShellStatus.Running) {
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = {
                        scope.launch { phone.shellControl.retry() }
                    }) { Text(PhoneSetupCopy.RECONNECT) }
                    TextButton(onClick = {
                        scope.launch { phone.shellControl.unpair() }
                    }) { Text(PhoneSetupCopy.UNPAIR) }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    PhoneSetupCopy.usageNote(phone.shellControl.restart),
                    style = MaterialTheme.typography.bodySmall,
                    color = com.arix.app.ui.theme.ArixOnSurfaceVariant,
                )
            }

            Spacer(Modifier.height(24.dp))
            Text(
                "How it works: Arix pairs with this phone's own wireless debugging once, then " +
                    "starts a tiny helper process with shell privileges. The agent works on a " +
                    "separate background screen — it opens apps, taps, types and scrolls there " +
                    "while you keep using your phone. Watch it any time in the small live view in " +
                    "the chat. It reads the screen the way a person does; no app APIs, works with " +
                    "any app.",
                style = MaterialTheme.typography.bodySmall,
                color = com.arix.app.ui.theme.ArixOnSurfaceVariant,
            )
            Spacer(Modifier.height(32.dp))
        }
    }
}

@Composable
private fun StatusCard(status: BuiltinShellStatus) {
    val (title, detail, ok) = when (status) {
        BuiltinShellStatus.NotPaired -> Triple(
            "Not set up",
            "Pair once below — it takes about a minute.",
            false,
        )
        BuiltinShellStatus.WirelessDebuggingOff -> Triple(
            "Wireless debugging is off",
            "Turn it on in Developer options and Arix reconnects by itself.",
            false,
        )
        BuiltinShellStatus.Connecting -> Triple(
            "Connecting…",
            "Pairing / starting the helper…",
            false,
        )
        BuiltinShellStatus.Running -> Triple(
            "Ready",
            "The background screen is ready — ask Arix to do something in any app.",
            true,
        )
        is BuiltinShellStatus.Failed -> Triple(
            "Error",
            PhoneSetupCopy.failure(status.reason).title,
            false,
        )
    }
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
    ) {
        Row(
            Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                if (ok) Icons.Rounded.CheckCircle else Icons.Rounded.PhoneAndroid,
                null,
                tint = if (ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.width(12.dp))
            Column {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(2.dp))
                Text(
                    detail,
                    style = MaterialTheme.typography.bodySmall,
                    color = com.arix.app.ui.theme.ArixOnSurfaceVariant,
                )
            }
        }
    }
}
