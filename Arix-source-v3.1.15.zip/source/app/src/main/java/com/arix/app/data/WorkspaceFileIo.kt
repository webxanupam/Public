package com.arix.app.data

import android.content.Context
import android.net.Uri
import android.webkit.MimeTypeMap
import com.arix.app.runtime.TermuxRuntime
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

internal object WorkspaceFileIo {

    suspend fun readWorkspaceFile(
        termuxRuntime: TermuxRuntime,
        path: String,
        workingDirectory: String,
        byteLimit: Int,
    ): Result<WorkspaceFilePayload> = withContext(Dispatchers.IO) {
        runCatching {
            require(byteLimit > 0) { "byteLimit must be greater than 0." }
            val resolved = termuxRuntime.resolveWorkspaceHostPath(path, workingDirectory)
                ?: error("Path is outside the workspace: $path")
            val file = resolved.hostFile
            require(file.isFile) { "File was not found in the workspace: ${resolved.guestPath}" }
            val sizeBytes = file.length()
            require(sizeBytes <= byteLimit) {
                "File is larger than $byteLimit bytes: ${resolved.guestPath}"
            }
            val bytes = file.readBytes()
            require(bytes.size <= byteLimit) {
                "File is larger than $byteLimit bytes: ${resolved.guestPath}"
            }
            WorkspaceFilePayload(
                absolutePath = resolved.guestPath,
                bytes = bytes,
                sizeBytes = bytes.size.toLong(),
            )
        }
    }

    suspend fun writeWorkspaceBytes(
        termuxRuntime: TermuxRuntime,
        absolutePath: String,
        bytes: ByteArray,
    ): Result<Long> = withContext(Dispatchers.IO) {
        runCatching {
            val resolved = termuxRuntime.resolveWorkspaceHostPath(absolutePath)
                ?: error("Path is outside the workspace: $absolutePath")
            resolved.hostFile.parentFile?.mkdirs()
            resolved.hostFile.outputStream().use { output ->
                output.write(bytes)
                output.flush()
            }
            bytes.size.toLong()
        }
    }

    suspend fun saveWorkspaceFileToDocument(
        appContext: Context,
        termuxRuntime: TermuxRuntime,
        path: String,
        destinationUri: Uri,
        workingDirectory: String,
        byteLimit: Int = 256 * 1024 * 1024,
    ): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val resolved = termuxRuntime.resolveWorkspaceHostPath(path, workingDirectory)
                ?: error("Path is outside the workspace: $path")
            val source = resolved.hostFile
            require(source.isFile) { "File was not found in the workspace: ${resolved.guestPath}" }
            require(source.length() <= byteLimit) {
                "File is larger than $byteLimit bytes: ${resolved.guestPath}"
            }
            val didWrite = appContext.contentResolver.openOutputStream(destinationUri, "w")
                ?.use { output ->
                    source.inputStream().use { input -> input.copyTo(output) }
                    output.flush()
                    true
                } ?: false
            if (!didWrite) {
                runCatching { appContext.contentResolver.delete(destinationUri, null, null) }
            }
            didWrite
        }.getOrDefault(false)
    }

    fun guessMimeType(path: String): String {
        val extension = path.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension).orEmpty()
    }
}
