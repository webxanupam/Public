package com.arix.app.mcp

import android.util.Log
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.atomic.AtomicBoolean

object ArixMcpLoopbackServer {

    private const val Tag = "ArixMcpLoopback"
    private const val Port = 33418
    private val running = AtomicBoolean(false)
    private val binding = AtomicBoolean(false)
    @Volatile private var serverSocket: ServerSocket? = null

    val isRunning: Boolean get() = running.get()

    fun start(onLog: (String) -> Unit = {}): Boolean {
        if (running.get() || binding.get()) return true
        synchronized(this) {
            if (running.get() || binding.get()) return true
            binding.set(true)
            Thread {
                val socket = try {
                    ServerSocket(Port, 8, InetAddress.getByName("127.0.0.1"))
                } catch (failure: Exception) {
                    synchronized(this) { binding.set(false) }
                    val detail = "MCP loopback callback server not started (port $Port busy): ${failure.message}"
                    Log.w(Tag, detail)
                    onLog(detail)
                    return@Thread
                }
                synchronized(this) {
                    if (!binding.get()) {
                        runCatching { socket.close() }
                        return@Thread
                    }
                    serverSocket = socket
                    binding.set(false)
                    running.set(true)
                }
                onLog("MCP loopback callback server listening on http://127.0.0.1:$Port/callback")
                while (running.get()) {
                    val client = try {
                        socket.accept()
                    } catch (failure: Exception) {
                        if (running.get()) {
                            runCatching { Thread.sleep(200) }
                            continue
                        }
                        break
                    }
                    handleClient(client)
                }
            }.apply {
                name = "arix-mcp-loopback"
                isDaemon = true
                start()
            }
        }
        return true
    }

    fun stop() {
        synchronized(this) {
            binding.set(false)
            running.set(false)
            runCatching { serverSocket?.close() }
            serverSocket = null
        }
    }

    private fun handleClient(client: Socket) {
        try {
            client.soTimeout = 1500
            client.use { socket ->
                val reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.ISO_8859_1))
                var requestLine: String? = null
                var lines = 0
                while (lines < 24) {
                    val line = reader.readLine() ?: break
                    if (line.isBlank()) break
                    if (requestLine == null) requestLine = line
                    lines++
                }
                val target = requestLine?.split(' ')?.getOrNull(1) ?: return
                val query = target.substringAfter('?', "")
                val hasOAuthParams = query.contains("code=") ||
                    query.contains("error=") ||
                    query.contains("state=")
                val page = if (hasOAuthParams) {
                    val redirect = "http://127.0.0.1:$Port" +
                        (if (target.startsWith("/")) target else "/$target")
                    ArixMcpOAuth.externalRedirect.value = redirect
                    successPage
                } else {
                    infoPage
                }
                socket.getOutputStream().write(
                    ("HTTP/1.1 200 OK\r\n" +
                        "Content-Type: text/html; charset=utf-8\r\n" +
                        "Content-Length: ${page.toByteArray(Charsets.UTF_8).size}\r\n" +
                        "Connection: close\r\n\r\n" +
                        page).toByteArray(Charsets.UTF_8),
                )
                socket.getOutputStream().flush()
            }
        } catch (_: Exception) {
        }
    }

    private val successPage: String = """
        <!DOCTYPE html><html><head><meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <style>
          body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;
               background:#14091F;color:#EDEDEF;font-family:system-ui,-apple-system,sans-serif}
          .card{text-align:center;padding:32px 28px;max-width:420px}
          .badge{width:64px;height:64px;border-radius:999px;margin:0 auto 18px;
                 background:linear-gradient(135deg,#00C4CC,#5B5BD6);display:flex;
                 align-items:center;justify-content:center;font-size:30px;font-weight:700}
          h1{font-size:19px;margin:0 0 8px}
          p{font-size:14px;line-height:1.5;color:#B9B9C4;margin:0}
        </style></head><body><div class="card">
        <div class="badge">A</div>
        <h1>Authorization complete</h1>
        <p>You can return to the Arix app now — the connector is finishing
        its sign-in.</p>
        </div></body></html>
    """.trimIndent()

    private val infoPage: String = """
        <!DOCTYPE html><html><head><meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <style>
          body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;
               background:#14091F;color:#EDEDEF;font-family:system-ui,-apple-system,sans-serif}
          .card{text-align:center;padding:32px 28px;max-width:420px}
          p{font-size:14px;line-height:1.5;color:#B9B9C4;margin:0}
        </style></head><body><div class="card">
        <p>Arix MCP callback server is waiting for an authorization
        redirect…</p>
        </div></body></html>
    """.trimIndent()
}
