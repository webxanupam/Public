package com.arix.app.data.pi

import com.arix.app.data.ActiveSkillContext
import com.arix.app.data.ArixAgentTurnResult
import com.arix.app.data.ArixDiagnosticLogger
import com.arix.app.data.ArixDynamicContextPolicy
import com.arix.app.data.ArixContextTier
import com.arix.app.data.ArixContextTurnSignals
import com.arix.app.data.ArixMemoryManager
import com.arix.app.data.ArixSessionContextTracker
import com.arix.app.data.ArixSelfManagementTool
import com.arix.app.data.ArixToolExecutor
import com.arix.app.data.ToolResultCompactor
import com.arix.app.data.AgentToolEvent
import com.arix.app.data.AppSettings
import com.arix.app.data.LlmImagePart
import com.arix.app.data.LlmMessage
import com.arix.app.data.LlmTextPart
import com.arix.app.data.LocalRuntimeId
import com.arix.app.data.ModelsDevModelLimits
import com.arix.app.data.StreamingStatus
import com.arix.app.data.SettingsRepository
import java.io.File
import java.util.Base64
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.channels.trySendBlocking
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

private const val InjectedMessagePollIntervalMillis = 150L

class PiAgentRunner(
    private val bridge: PiKernelBridge,
    private val toolExecutor: ArixToolExecutor? = null,
    private val settingsRepository: SettingsRepository? = null,
    private val termuxRuntime: com.arix.app.runtime.TermuxRuntime? = null,
    private val diagnosticLogger: ArixDiagnosticLogger = ArixDiagnosticLogger.NoOp,
    private val memoryManager: ArixMemoryManager? = null,
    private val sessionContextTracker: ArixSessionContextTracker? = null,
) {
    suspend fun runTurn(
        settings: AppSettings,
        messages: List<LlmMessage>,
        workspaceDirectory: String,
        runtimeId: LocalRuntimeId = LocalRuntimeId.Termux,
        skillPaths: List<String> = emptyList(),
        activeSkills: List<ActiveSkillContext> = emptyList(),
        selfManagementTool: ArixSelfManagementTool? = null,
        sessionId: String = "",
        sessionFile: String = "",
        allowSwarmTool: Boolean = true,
        thinkingLevelMap: Map<String, String> = emptyMap(),
        isReasoningModel: Boolean = true,
        modelsDevThinkingLevels: List<String>? = null,
        modelsDevLimits: ModelsDevModelLimits? = null,
        onToolEvent: suspend (AgentToolEvent) -> Unit = {},
        onToolProgress: (suspend (AgentToolEvent) -> Unit)? = null,
        onAssistantTextDelta: suspend (String) -> Unit = {},
        onAssistantReasoningDelta: suspend (String) -> Unit = {},
        onAssistantReasoningSummaryDelta: suspend (String) -> Unit = {},
        onAssistantTextReset: suspend () -> Unit = {},
        onAssistantRequestStarted: suspend () -> Unit = {},
        onAssistantResponseReset: suspend () -> Unit = {},
        onStreamingStatus: suspend (StreamingStatus?) -> Unit = {},
        pollInjectedUserMessages: suspend () -> List<LlmMessage> = { emptyList() },
        onRuntimeSetupProgress: (PiCoreSetupUpdate) -> Unit = {},
    ): Result<ArixAgentTurnResult> {
        return try {
            onStreamingStatus(null)
            diagnosticLogger.event(
                category = "pi_agent",
                event = "run_turn_start",
                sessionId = sessionId,
                details = mapOf(
                    "session_file" to sessionFile,
                    "runtime_id" to runtimeId.storageValue,
                    "workspace_directory" to workspaceDirectory,
                    "message_count" to messages.size,
                ),
            )
            runCatchingPreservingCancellation {
                val resolvedSessionId = sessionId.ifBlank {
                    "arix-session-${System.currentTimeMillis()}"
                }
                var currentRuntimeId = runtimeId
                val appendedPiEntryIds = ConcurrentLinkedQueue<String>()
                val latestUserText = messages.lastOrNull { it.role == "user" }
                    ?.contentParts
                    ?.filterIsInstance<LlmTextPart>()
                    ?.joinToString(" ") { it.text }
                    .orEmpty()
                toolExecutor?.beginSupervisedTurn(resolvedSessionId, latestUserText)
                toolExecutor?.beginBrowserResearchTurn(resolvedSessionId)
                val taskStateBlock = toolExecutor?.supervisorStateBlock(resolvedSessionId).orEmpty()
                val latestUserMessage = messages.lastOrNull { it.role == "user" }
                val contextTier = ArixDynamicContextPolicy.classifyLocalTier(
                    ArixContextTurnSignals(
                        userText = latestUserText,
                        attachmentCount = latestUserMessage?.contentParts?.count { part ->
                            part is LlmImagePart ||
                                (part is LlmTextPart && part.text.startsWith("Workspace attachment:"))
                        } ?: 0,
                        activeSkillCount = activeSkills.size,
                        hasActiveTaskState = taskStateBlock.isNotBlank(),
                        recentToolInvocationCount = messages.takeLast(6).count { it.role == "toolResult" },
                        sessionMessageCount = messages.size,
                    ),
                )
                val memoryBlock = memoryManager?.promptBlock(latestUserText, resolvedSessionId)
                val sessionContextBlock = sessionContextTracker?.promptBlock()
                val ephemeralTurnContext = buildEphemeralTurnContextBlock(
                    memoryBlock = memoryBlock,
                    sessionContextBlock = sessionContextBlock,
                    taskStateBlock = taskStateBlock,
                )
                val prompt = {
                    if (ArixDynamicContextPolicy.useCompactPrompt(contextTier)) {
                        buildPiAgentInstructionsCompact(
                            settings = settings,
                            workspaceDirectory = workspaceDirectory,
                            runtimeId = currentRuntimeId,
                        )
                    } else {
                        buildPiAgentInstructions(
                            settings = settings,
                            workspaceDirectory = workspaceDirectory,
                            runtimeId = currentRuntimeId,
                        )
                    }
                }
                val modelConfig = settings.toPiModelConfig(
                    thinkingLevelMap,
                    isReasoningModel,
                    modelsDevThinkingLevels,
                    modelsDevLimits,
                )
                val payload = JSONObject().apply {
                    put("model_config", modelConfig.toJson())
                    put("session_id", resolvedSessionId)
                    if (sessionFile.isNotBlank()) put("session_file", sessionFile)
                    put("system_prompt", prompt())
                    put("context_policy", ArixDynamicContextPolicy.contextPolicyPayload(contextTier))
                    if (!ephemeralTurnContext.isNullOrBlank()) {
                        put("turn_context", ephemeralTurnContext)
                    }
                    put(
                        "messages",
                        messagesForBridge(
                            messages = messages,
                            reuseExistingSession = sessionFile.isNotBlank(),
                            contextTier = contextTier,
                        )
                            .withSelectedSkillCommand(activeSkills.firstOrNull()?.name)
                            .toPiJson(),
                    )
                    put(
                        "skill_paths",
                        JSONArray(skillPaths),
                    )
                    put("workspace_directory", workspaceDirectory)
                    put("workspace_trusted", true)
                    put("termux_workspace_directory", workspaceDirectory)
                    put("runtime", runtimeId.storageValue)
                    put("platform", "android")
                    put("reasoning", settings.toPiThinkingLevel())
                    put(
                        "host_tools",
                        toolExecutor?.hostToolDefinitionsForTurn(
                            selfManagementTool = selfManagementTool,
                            allowSwarmTool = allowSwarmTool,
                            contextTier = contextTier,
                            turnUserText = latestUserText,
                        ) ?: ArixToolExecutor.hostToolDefinitions(
                            selfManagementTool = selfManagementTool,
                        ),
                    )
                }
                val requestedThinkingLevel = settings.toPiThinkingLevel()
                diagnosticLogger.event(
                    category = "pi_agent",
                    event = "context_tier_resolved",
                    sessionId = resolvedSessionId,
                    details = mapOf(
                        "tier" to contextTier.wireName,
                        "trim_fraction" to ArixDynamicContextPolicy.trimFractionFor(contextTier),
                        "compact_threshold" to ArixDynamicContextPolicy.compactThresholdFor(contextTier),
                        "reuse_session_file" to sessionFile.isNotBlank(),
                    ),
                )
                diagnosticLogger.event(
                    category = "pi_agent",
                    event = "reasoning_effort_resolved",
                    sessionId = resolvedSessionId,
                    details = mapOf(
                        "configured_effort" to settings.reasoningEffort,
                        "normalized_effort" to requestedThinkingLevel,
                        "model_config_reasoning" to modelConfig.reasoning,
                        "reasoning_model_catalog_match" to isReasoningModel,
                        "mapped_effort" to thinkingLevelMap[requestedThinkingLevel].orEmpty(),
                        "thinking_level_map" to thinkingLevelMap,
                        "provider" to settings.piProviderId,
                        "model" to settings.modelId,
                        "session_file_present" to sessionFile.isNotBlank(),
                    ),
                )

                try {
                    coroutineScope {
                    val parallelHostToolJobs = ConcurrentHashMap<String, Job>()
                    var lastSetupStatusLabel = ""
                    var lastSetupStatusAtMillis = 0L
                    val runtimeOperationJobs = ConcurrentHashMap<String, Job>()
                    val pendingRuntimeOperationRequests = ConcurrentHashMap<String, JSONObject>()
                    val pendingRuntimeOperationChunks =
                        ConcurrentHashMap<String, ConcurrentHashMap<Int, ByteArray>>()
                    val handledHostToolRequestIds = ConcurrentHashMap.newKeySet<String>()
                    val sequentialHostToolRequests = Channel<JSONObject>(Channel.UNLIMITED)
                    val sequentialHostToolWorker = launch {
                        for (requestPayload in sequentialHostToolRequests) {
                            handleHostToolRequest(
                                payload = requestPayload,
                                sessionId = resolvedSessionId,
                                settings = settings,
                                workspaceDirectory = workspaceDirectory,
                                selfManagementTool = selfManagementTool,
                                        currentRuntimeId = { currentRuntimeId },
                                onRuntimeChanged = { currentRuntimeId = it },
                                supervisorStateNote = {
                                    toolExecutor?.supervisorStateBlock(resolvedSessionId).orEmpty()
                                },
                            )
                        }
                    }

                    suspend fun dispatchHostToolRequest(eventPayload: JSONObject) {
                        val toolRequestId = eventPayload.optString("tool_request_id").trim()
                        if (toolRequestId.isBlank()) {
                            logMalformedHostToolRequest(eventPayload, resolvedSessionId)
                            return
                        }
                        if (!handledHostToolRequestIds.add(toolRequestId)) return
                        val requestPayload = JSONObject(eventPayload.toString())
                        if (eventPayload.optString("execution_mode") == "sequential") {
                            sequentialHostToolRequests.send(requestPayload)
                            return
                        }
                        val job = launch(start = CoroutineStart.LAZY) {
                            try {
                                handleHostToolRequest(
                                    payload = requestPayload,
                                    sessionId = resolvedSessionId,
                                    settings = settings,
                                    workspaceDirectory = workspaceDirectory,
                                    selfManagementTool = selfManagementTool,
                                                currentRuntimeId = { currentRuntimeId },
                                    onRuntimeChanged = { currentRuntimeId = it },
                                    supervisorStateNote = {
                                        toolExecutor?.supervisorStateBlock(resolvedSessionId).orEmpty()
                                    },
                                )
                            } finally {
                                parallelHostToolJobs.remove(toolRequestId)
                            }
                        }
                        parallelHostToolJobs[toolRequestId] = job
                        job.start()
                    }

                    suspend fun executeRuntimeOperation(
                        kind: String,
                        payload: JSONObject,
                        inputData: ByteArray?,
                        sessionId: String,
                        operationId: String,
                    ): JSONObject {
                        val runtime = termuxRuntime
                            ?: error("The Termux runtime is not available in this build.")
                        suspend fun sendOutputChunk(chunk: ByteArray) {
                            bridge.sendRuntimeOperationChunk(
                                JSONObject().apply {
                                    put("operation_id", operationId)
                                    put("session_id", sessionId)
                                    put("runtime", "termux")
                                    put("direction", "output")
                                    put("data_base64", Base64.getEncoder().encodeToString(chunk))
                                }
                            )
                        }
                        when (kind) {
                            "bash" -> {
                                val command = payload.optString("command")
                                if (command.isBlank()) {
                                    error("Missing 'command' for the bash operation.")
                                }
                                if (ArixToolExecutor.requiresDestructiveCommandConfirmation(command)) {
                                    val gateMessage = "BLOCKED by Arix's destructive-command guard: " +
                                        "this command matches a catastrophic pattern (recursive " +
                                        "force-delete of a system/home/device-storage root, mkfs, dd " +
                                        "to a block device, fork bomb, recursive chmod/chown of /, or " +
                                        "curl/wget piped into a shell). It was NOT executed. If the " +
                                        "user explicitly wants exactly this command, tell them to run " +
                                        "it themselves in the Console — do not try to work around " +
                                        "the guard."
                                    sendOutputChunk(gateMessage.toByteArray())
                                    return JSONObject().apply {
                                        put("ok", false)
                                        put("exit_code", 126)
                                        put("timed_out", false)
                                        put("needs_confirmation", true)
                                        put("stderr", gateMessage)
                                        put("errmsg", gateMessage)
                                    }
                                }
                                val cwd = payload.optString("cwd").trim().ifBlank { runtime.homeDirectory }
                                val timeoutSeconds = payload.optInt("timeout_seconds", 0)
                                    .coerceIn(0, 3_600)
                                val env = payload.optJSONObject("env")
                                val commandWithEnv = if (env != null && env.length() > 0) {
                                    val exports = env.keys().asSequence()
                                        .filter { key -> key.matches(Regex("[A-Za-z_][A-Za-z0-9_]*")) }
                                        .joinToString("; ") { key ->
                                            "export ${shellQuoteAssignment(key, env.optString(key))}"
                                        }
                                    if (exports.isBlank()) command else "$exports; $command"
                                } else {
                                    command
                                }
                                val chunkChannel = Channel<ByteArray>(capacity = 128)
                                val chunkSender = launch {
                                    for (chunk in chunkChannel) {
                                        if (!runCatching { sendOutputChunk(chunk) }.isSuccess) break
                                    }
                                }
                                val rawResult = try {
                                    runtime.executeStreamingCommand(
                                        command = commandWithEnv,
                                        workingDirectory = cwd,
                                        timeoutMillis = if (timeoutSeconds > 0) {
                                            timeoutSeconds * 1_000L
                                        } else {
                                            0L
                                        },
                                        onChunk = { chunk ->
                                            runCatching {
                                                chunkChannel.trySendBlocking(chunk)
                                            }
                                        },
                                    )
                                } finally {
                                    chunkChannel.close()
                                    runCatching { chunkSender.join() }
                                }
                                return JSONObject(rawResult)
                            }

                            "readFile" -> {
                                val guestPath = payload.optString("path").trim()
                                if (guestPath.isBlank()) error("Missing 'path' for the readFile operation.")
                                val file = runtime.resolveManagedGuestPath(guestPath)
                                if (!file.isFile) error("File not found: $guestPath")
                                val bytes = file.readBytes()
                                var offset = 0
                                while (offset < bytes.size) {
                                    val length = minOf(64 * 1024, bytes.size - offset)
                                    val chunk = bytes.copyOfRange(offset, offset + length)
                                    offset += length
                                    if (!runCatching { sendOutputChunk(chunk) }.isSuccess) break
                                }
                                return JSONObject().apply {
                                    put("size", bytes.size.toLong())
                                    put("data_base64", "")
                                }
                            }

                            "writeFile" -> {
                                val guestPath = payload.optString("path").trim()
                                if (guestPath.isBlank()) error("Missing 'path' for the writeFile operation.")
                                val content = inputData
                                    ?: runCatching {
                                        Base64.getDecoder().decode(payload.optString("data_base64"))
                                    }.getOrNull()
                                    ?: error("Missing content for the writeFile operation.")
                                val file = runtime.resolveManagedGuestPath(guestPath)
                                file.parentFile?.mkdirs()
                                if (payload.optBoolean("atomic", false)) {
                                    val staging = File(
                                        file.parentFile,
                                        ".${file.name}.arix-write-${System.currentTimeMillis()}",
                                    )
                                    staging.writeBytes(content)
                                    if (!staging.renameTo(file)) {
                                        staging.delete()
                                        file.writeBytes(content)
                                    }
                                } else {
                                    file.writeBytes(content)
                                }
                                return JSONObject().apply { put("size", content.size.toLong()) }
                            }

                            "mkdir" -> {
                                val guestPath = payload.optString("path").trim()
                                if (guestPath.isBlank()) error("Missing 'path' for the mkdir operation.")
                                val file = runtime.resolveManagedGuestPath(guestPath)
                                if (!file.exists() && !file.mkdirs() && !file.isDirectory) {
                                    error("Unable to create directory: $guestPath")
                                }
                                return JSONObject()
                            }

                            "access" -> {
                                val guestPath = payload.optString("path").trim()
                                if (guestPath.isBlank()) error("Missing 'path' for the access operation.")
                                val file = runtime.resolveManagedGuestPath(guestPath)
                                val mode = payload.optString("mode").trim().ifBlank { "read" }
                                if (!file.exists()) error("No such file or directory: $guestPath")
                                if (mode == "read" && !file.canRead()) {
                                    error("Permission denied (read): $guestPath")
                                }
                                if (mode == "write" && !file.canWrite()) {
                                    error("Permission denied (write): $guestPath")
                                }
                                return JSONObject()
                            }

                            "detectMime" -> {
                                val guestPath = payload.optString("path").trim()
                                if (guestPath.isBlank()) error("Missing 'path' for the detectMime operation.")
                                val file = runtime.resolveManagedGuestPath(guestPath)
                                if (!file.isFile) error("File not found: $guestPath")
                                val header = file.inputStream().use { input ->
                                    ByteArray(16).also { buffer ->
                                        var total = 0
                                        while (total < buffer.size) {
                                            val read = input.read(buffer, total, buffer.size - total)
                                            if (read == -1) break
                                            total += read
                                        }
                                    }
                                }
                                val mime = when {
                                    header.size >= 8 && header[0] == 0x89.toByte() &&
                                        header[1] == 0x50.toByte() && header[2] == 0x4E.toByte() &&
                                        header[3] == 0x47.toByte() -> "image/png"
                                    header.size >= 3 && header[0] == 0xFF.toByte() &&
                                        header[1] == 0xD8.toByte() && header[2] == 0xFF.toByte() -> "image/jpeg"
                                    header.size >= 6 && (
                                        header.copyOfRange(0, 6).toString(Charsets.US_ASCII) == "GIF87a" ||
                                            header.copyOfRange(0, 6).toString(Charsets.US_ASCII) == "GIF89a"
                                        ) -> "image/gif"
                                    header.size >= 2 && header[0] == 'B'.code.toByte() &&
                                        header[1] == 'M'.code.toByte() -> "image/bmp"
                                    header.size >= 12 && header.copyOfRange(0, 4)
                                        .toString(Charsets.US_ASCII) == "RIFF" &&
                                        header.copyOfRange(8, 12).toString(Charsets.US_ASCII) == "WEBP" -> "image/webp"
                                    else -> ""
                                }
                                return JSONObject().apply { put("mime_type", mime) }
                            }

                            else -> error("Unknown runtime operation kind: $kind")
                        }
                    }

                    suspend fun startRuntimeOperation(
                        eventPayload: JSONObject,
                        inputData: ByteArray? = null,
                    ) {
                        val operationId = eventPayload.optString("operation_id").trim()
                        if (operationId.isBlank() || runtimeOperationJobs.containsKey(operationId)) return
                        val operationRuntime = eventPayload.optString("runtime").trim()
                        val kind = eventPayload.optString("kind").trim()
                        val operationPayload = eventPayload.optJSONObject("payload") ?: JSONObject()
                        val job = launch(start = CoroutineStart.LAZY) {
                            val result = runCatching {
                                executeRuntimeOperation(
                                    kind = kind,
                                    payload = operationPayload,
                                    inputData = inputData,
                                    sessionId = resolvedSessionId,
                                    operationId = operationId,
                                )
                            }
                            if (result.isSuccess) {
                                bridge.sendRuntimeOperationResult(
                                    JSONObject().apply {
                                        put("operation_id", operationId)
                                        put("session_id", resolvedSessionId)
                                        put("runtime", operationRuntime)
                                        put("ok", true)
                                        put("result", result.getOrThrow() as Any)
                                    }
                                )
                            } else if (result.exceptionOrNull() !is CancellationException) {
                                val failure = result.exceptionOrNull()
                                diagnosticLogger.event(
                                    category = "pi_agent",
                                    event = "runtime_operation_failed",
                                    level = "warn",
                                    sessionId = resolvedSessionId,
                                    details = mapOf(
                                        "operation_id" to operationId,
                                        "kind" to kind,
                                        "error" to (failure?.message ?: "unknown").take(300),
                                    ),
                                )
                                bridge.sendRuntimeOperationResult(
                                    JSONObject().apply {
                                        put("operation_id", operationId)
                                        put("session_id", resolvedSessionId)
                                        put("runtime", operationRuntime)
                                        put("ok", false)
                                        put("error", failure?.message ?: "Runtime operation failed.")
                                    }
                                )
                            }
                        }
                        job.invokeOnCompletion { runtimeOperationJobs.remove(operationId) }
                        runtimeOperationJobs[operationId] = job
                        job.start()
                    }

                    suspend fun dispatchRuntimeOperation(eventPayload: JSONObject) {
                        val operationId = eventPayload.optString("operation_id").trim()
                        if (operationId.isBlank()) return
                        val inputChunkCount = eventPayload.optInt("input_chunk_count").coerceAtLeast(0)
                        if (inputChunkCount == 0) {
                            startRuntimeOperation(eventPayload)
                            return
                        }
                        pendingRuntimeOperationRequests[operationId] = JSONObject(eventPayload.toString())
                        pendingRuntimeOperationChunks[operationId] = ConcurrentHashMap()
                    }

                    suspend fun dispatchRuntimeOperationInputChunk(eventPayload: JSONObject) {
                        if (eventPayload.optString("direction") != "input") return
                        val operationId = eventPayload.optString("operation_id").trim()
                        val requestPayload = pendingRuntimeOperationRequests[operationId] ?: return
                        val sequence = eventPayload.optInt("sequence", -1)
                        if (sequence < 0) return
                        val chunk = runCatching {
                            Base64.getDecoder().decode(eventPayload.optString("data_base64"))
                        }.getOrNull() ?: return
                        val chunks = pendingRuntimeOperationChunks[operationId] ?: return
                        chunks.putIfAbsent(sequence, chunk)
                        val expected = requestPayload.optInt("input_chunk_count").coerceAtLeast(1)
                        if (chunks.size < expected) return
                        val ordered = (0 until expected).map { chunks[it] ?: return }
                        val byteCount = ordered.sumOf(ByteArray::size)
                        val inputData = ByteArray(byteCount)
                        var offset = 0
                        ordered.forEach { bytes ->
                            bytes.copyInto(inputData, offset)
                            offset += bytes.size
                        }
                        pendingRuntimeOperationRequests.remove(operationId)
                        pendingRuntimeOperationChunks.remove(operationId)
                        startRuntimeOperation(requestPayload, inputData)
                    }

                    val eventHandler: suspend (String, JSONObject) -> Unit = { event, eventPayload ->
                        when (event) {
                            "assistant_text_delta" ->
                                onAssistantTextDelta(eventPayload.optString("delta"))

                            "provider_key_rotated" -> {
                                val poolSize = eventPayload.optInt("pool_size", 1)
                                    .coerceAtLeast(1)
                                val reason = eventPayload.optString("reason")
                                onStreamingStatus(
                                    StreamingStatus(
                                        text = if (reason == "token_budget") {
                                            "Switching API key"
                                        } else {
                                            "API key quota reached"
                                        },
                                        detail = "Arix switched to backup API key " +
                                            "(${eventPayload.optInt("key_index", 0) + 1}/$poolSize) " +
                                            "so the task keeps running without interruption.",
                                    )
                                )
                            }

                            "assistant_reasoning_delta" -> {
                                val delta = eventPayload.optString("delta")
                                onAssistantReasoningDelta(delta)
                                if (eventPayload.optString("kind") == "summary") {
                                    onAssistantReasoningSummaryDelta(delta)
                                }
                            }

                            "assistant_request_start" -> onAssistantRequestStarted()

                            "assistant_stream_reset" -> onAssistantResponseReset()

                            "assistant_retry" ->
                                onStreamingStatus(reconnectStreamingStatus(eventPayload))

                            "compaction_start" -> onStreamingStatus(
                                StreamingStatus(
                                    text = "Summarizing conversation",
                                    detail = "The conversation history is being condensed to stay within " +
                                        "the model's context limit. Your chat continues normally.",
                                )
                            )

                            "compaction_end" -> onStreamingStatus(
                                StreamingStatus(
                                    text = "Summarizing conversation",
                                    detail = "Done — the conversation was compacted.",
                                )
                            )

                            "tool_call_start" -> {
                                onAssistantTextReset()
                                onToolEvent(eventPayload.toToolEvent(isRunning = true))
                            }

                            "tool_call_delta" -> {
                                val toolEvent = eventPayload.toToolEvent(isRunning = true)
                                if (toolEvent.outputJson == null) {
                                    onToolEvent(toolEvent)
                                } else {
                                    (onToolProgress ?: onToolEvent)(toolEvent)
                                }
                            }

                            "tool_call_end" ->
                                onToolEvent(eventPayload.toToolEvent(isRunning = false))

                            "host_tool_request" -> dispatchHostToolRequest(eventPayload)

                            "runtime_op_request" -> dispatchRuntimeOperation(eventPayload)

                            "runtime_op_chunk" -> dispatchRuntimeOperationInputChunk(eventPayload)

                            "runtime_op_cancel" -> {
                                val operationId = eventPayload.optString("operation_id").trim()
                                pendingRuntimeOperationRequests.remove(operationId)
                                pendingRuntimeOperationChunks.remove(operationId)
                                runtimeOperationJobs.remove(operationId)?.cancel()
                            }

                            "session_entry_appended" -> {
                                val entryId = eventPayload.optJSONObject("entry")?.optString("id").orEmpty()
                                if (entryId.isNotBlank()) appendedPiEntryIds += entryId
                            }

                            "assistant_error" -> onStreamingStatus(
                                StreamingStatus(
                                    text = "Agent engine error",
                                    detail = eventPayload.optString("error_message"),
                                )
                            )
                        }
                    }

                    val deferredInjectedMessages = ConcurrentLinkedQueue<LlmMessage>()
                    suspend fun forwardInjectedMessages() {
                        pollInjectedUserMessages().forEach { message ->
                            val accepted = runCatching {
                                bridge.steer(resolvedSessionId, message.toPiJson())
                                    .optBoolean("accepted")
                            }.getOrElse { throwable ->
                                if (throwable is CancellationException &&
                                    throwable !is TimeoutCancellationException
                                ) {
                                    throw throwable
                                }
                                false
                            }
                            if (!accepted) {
                                deferredInjectedMessages += message
                            }
                        }
                    }

                    val pollingJob = launch {
                        while (isActive) {
                            forwardInjectedMessages()
                            delay(InjectedMessagePollIntervalMillis)
                        }
                    }
                    try {
                        diagnosticLogger.event(
                            category = "pi_agent",
                            event = "bridge_run_turn_start",
                            sessionId = resolvedSessionId,
                            details = mapOf(
                                "payload_session_id" to payload.optString("session_id"),
                                "payload_session_file" to payload.optString("session_file"),
                            ),
                        )
                        var response = bridge.runTurn(payload, eventHandler) { update ->
                            onRuntimeSetupProgress(update)
                            val label = when (update.phase) {
                                PiCoreSetupPhase.CheckingTermux -> "Preparing the Termux runtime"
                                PiCoreSetupPhase.CheckingNode -> "Checking the agent runtime"
                                PiCoreSetupPhase.InstallingNode -> when (update.activity) {
                                    PiCoreSetupActivity.Downloading -> "Installing Node.js (first run only)"
                                    PiCoreSetupActivity.Extracting -> "Extracting the agent runtime"
                                    else -> "Installing the agent runtime"
                                }
                                PiCoreSetupPhase.PreparingBridge -> "Preparing the Arix bridge"
                                PiCoreSetupPhase.StartingBridge -> "Starting the Arix bridge"
                                PiCoreSetupPhase.VerifyingBridge -> "Verifying the Arix bridge"
                                else -> "Setting up the agent runtime"
                            }
                            val now = System.currentTimeMillis()
                            if (label != lastSetupStatusLabel || now - lastSetupStatusAtMillis > 1_000L) {
                                lastSetupStatusLabel = label
                                lastSetupStatusAtMillis = now
                                val detail = buildString {
                                    append("This happens once — setting up the local agent engine.")
                                    if (update.bytesPerSecond > 0L) {
                                        append(" ${update.bytesPerSecond / 1024} KB/s")
                                    }
                                    update.output.lineSequence()
                                        .map(String::trim)
                                        .lastOrNull(String::isNotBlank)
                                        ?.let { append('\n').append(it.take(120)) }
                                }
                                launch { onStreamingStatus(StreamingStatus(label, detail)) }
                            }
                        }
                        throwIfPiBridgeSetupError(response)
                        diagnosticLogger.event(
                            category = "pi_agent",
                            event = "bridge_run_turn_end",
                            sessionId = resolvedSessionId,
                            details = mapOf(
                                "response_ok" to response.optBoolean("ok"),
                                "response_session_id" to response.optString("session_id"),
                            ),
                        )
                        forwardInjectedMessages()
                        while (true) {
                            val injected = deferredInjectedMessages.poll() ?: break
                            response = bridge.followUp(
                                sessionId = resolvedSessionId,
                                message = injected.toPiJson(),
                                onEvent = eventHandler,
                            )
                            throwIfPiBridgeSetupError(response)
                        }

                        val completion = response.toPiCompletionResult()
                        if (
                            settings.providerConfigId.isNotBlank() &&
                            completion.updatedOauthCredentialJson.isNotBlank()
                        ) {
                            settingsRepository?.updateProviderOAuthCredential(
                                settings.providerConfigId,
                                completion.updatedOauthCredentialJson,
                            )
                        }
                        if (
                            settings.providerConfigId.isNotBlank() &&
                            completion.developerRoleUnsupportedDetected
                        ) {
                            settingsRepository?.setProviderDeveloperRoleUnsupported(
                                settings.providerConfigId,
                                true,
                            )
                        }
                        if (completion.errorMessage.isNotBlank()) {
                            error(completion.errorMessage)
                        }
                        ArixAgentTurnResult(
                            assistantText = completion.assistantText.ifBlank {
                                "The model finished without returning any assistant text."
                            },
                            tokenUsage = completion.usage,
                            providerPayloadJson = completion.toProviderPayloadJson(),
                            piSessionId = completion.sessionId,
                            piSessionFile = completion.sessionFile,
                            piSessionLeafId = completion.sessionLeafId,
                            runtime = completion.runtime,
                            cwd = completion.cwd,
                            piEntryIds = appendedPiEntryIds.toList(),
                        )
                    } finally {
                        pollingJob.cancelAndJoin()
                        sequentialHostToolRequests.close()
                        sequentialHostToolWorker.cancelAndJoin()
                        parallelHostToolJobs.values.toList().forEach { job ->
                            job.cancelAndJoin()
                        }
                        runtimeOperationJobs.values.toList().forEach { job ->
                            job.cancelAndJoin()
                        }
                        pendingRuntimeOperationRequests.clear()
                        pendingRuntimeOperationChunks.clear()
                    }
                    }
                } finally {
                    toolExecutor?.endSupervisedTurn(resolvedSessionId)
                }
            }
        } finally {
            diagnosticLogger.event(
                category = "pi_agent",
                event = "run_turn_end",
                sessionId = sessionId,
            )
            onStreamingStatus(null)
        }
    }

    private suspend fun handleHostToolRequest(
        payload: JSONObject,
        sessionId: String,
        settings: AppSettings,
        workspaceDirectory: String,
        selfManagementTool: ArixSelfManagementTool?,
        currentRuntimeId: () -> LocalRuntimeId,
        onRuntimeChanged: suspend (LocalRuntimeId) -> Unit,
        supervisorStateNote: () -> String,
    ) {
        val toolRequestId = payload.optString("tool_request_id").trim()
        val toolCallId = payload.optString("tool_call_id").trim()
        val toolName = payload.optString("tool_name").trim()
        if (toolRequestId.isBlank()) {
            logMalformedHostToolRequest(payload, sessionId)
            return
        }

        val argumentsJson = payload.argumentsJson()
        val executor = toolExecutor
        if (executor == null || !ArixToolExecutor.supports(toolName)) {
            bridge.sendHostToolResult(
                hostToolPayload(
                    sessionId = sessionId,
                    toolRequestId = toolRequestId,
                    toolCallId = toolCallId,
                    toolName = toolName.ifBlank { "unknown" },
                    argumentsJson = argumentsJson,
                    rawOutput = JSONObject().apply {
                        put("ok", false)
                        put("error_code", "TOOL_NOT_FOUND")
                        put("errmsg", "Tool '$toolName' does not exist in this runtime. Do not guess or " +
                            "substitute another tool.")
                    }.toString(),
                    isError = true,
                )
            )
            return
        }

        val result = runCatching {
            executor.execute(
                settings = settings,
                workspaceDirectory = workspaceDirectory,
                toolName = toolName,
                argumentsJson = argumentsJson,
                selfManagementTool = selfManagementTool,
                currentRuntimeId = currentRuntimeId(),
                onRuntimeChanged = onRuntimeChanged,
                sessionId = sessionId,
                onProgress = { progress ->
                    bridge.sendHostToolProgress(
                        hostToolPayload(
                            sessionId = sessionId,
                            toolRequestId = toolRequestId,
                            toolCallId = toolCallId,
                            toolName = toolName,
                            argumentsJson = argumentsJson,
                            rawOutput = progress,
                            isError = !ArixToolExecutor.inferToolOutputOk(progress),
                        )
                    )
                },
            )
        }

        val responsePayload = result.fold(
            onSuccess = { executionResult ->
                hostToolPayload(
                    sessionId = sessionId,
                    toolRequestId = toolRequestId,
                    toolCallId = toolCallId,
                    toolName = toolName,
                    argumentsJson = argumentsJson,
                    rawOutput = executionResult.rawOutput,
                    isError = executionResult.isError,
                    stateNote = supervisorStateNote(),
                )
            },
            onFailure = { throwable ->
                if (throwable is CancellationException) throw throwable
                hostToolPayload(
                    sessionId = sessionId,
                    toolRequestId = toolRequestId,
                    toolCallId = toolCallId,
                    toolName = toolName,
                    argumentsJson = argumentsJson,
                    rawOutput = JSONObject().apply {
                        put("ok", false)
                        put("errmsg", throwable.message ?: "Tool execution failed.")
                    }.toString(),
                    isError = true,
                )
            },
        )
        bridge.sendHostToolResult(responsePayload)
    }

    private fun logMalformedHostToolRequest(
        payload: JSONObject,
        sessionId: String,
    ) {
        diagnosticLogger.event(
            category = "pi_agent",
            event = "malformed_host_tool_request",
            level = "warn",
            sessionId = sessionId,
            details = mapOf(
                "tool_call_id" to payload.optString("tool_call_id").trim(),
                "tool_name" to payload.optString("tool_name").trim(),
                "reason" to "Missing tool_request_id.",
            ),
        )
    }
}

internal fun reconnectStreamingStatus(payload: JSONObject): StreamingStatus {
    val delayMillis = payload.optInt("delay_ms").coerceAtLeast(0)
    return StreamingStatus(
        text =
            "Reconnecting... ${payload.optInt("attempt")}/${payload.optInt("max_attempts")}",
        detail = buildString {
            append(payload.optString("error_message"))
            if (delayMillis > 0) {
                if (isNotEmpty()) append('\n')
                append("Retrying in ")
                if (delayMillis % 1_000 == 0) {
                    append(delayMillis / 1_000).append('s')
                } else {
                    append(delayMillis).append("ms")
                }
            }
        },
    )
}

private fun shellQuoteAssignment(key: String, value: String): String =
    "$key='${value.replace("'", "'\\''")}'"

private fun JSONObject.toToolEvent(isRunning: Boolean): AgentToolEvent =
    AgentToolEvent(
        id = optString("id").ifBlank { "pi-tool-${optInt("content_index", 0)}" },
        name = optString("name").ifBlank { "tool_call" },
        argumentsJson = argumentsJson(),
        outputJson = outputJson(),
        isRunning = isRunning,
    )

private fun JSONObject.argumentsJson(): String {
    val explicit = optString("arguments_json").trim()
    if (explicit.isNotBlank()) return explicit
    return when (val arguments = opt("arguments")) {
        is JSONObject -> arguments.toString()
        is JSONArray -> arguments.toString()
        is String -> arguments.ifBlank { "{}" }
        null,
        JSONObject.NULL -> optString("delta").ifBlank { "{}" }
        else -> JSONObject.wrap(arguments)?.toString() ?: "{}"
    }
}

private fun JSONObject.outputJson(): String? {
    val explicit = optString("output_json")
    if (explicit.isNotBlank()) return explicit
    return when (val output = opt("output")) {
        is JSONObject -> output.toString()
        is JSONArray -> output.toString()
        is String -> output.takeIf { it.isNotBlank() }
        else -> null
    }
}

private fun hostToolPayload(
    sessionId: String,
    toolRequestId: String,
    toolCallId: String,
    toolName: String,
    argumentsJson: String,
    rawOutput: String,
    isError: Boolean,
    stateNote: String = "",
): JSONObject = JSONObject().apply {
    put("session_id", sessionId)
    put("tool_request_id", toolRequestId)
    put("tool_call_id", toolCallId)
    put("tool_name", toolName)
    put("arguments_json", argumentsJson)
    put("output_json", rawOutput)
    if (toolName == "arix_runtime_manage") {
        put("raw_output_json", rawOutput)
    }
    put("is_error", isError)
    if (stateNote.isNotBlank()) put("state_note", stateNote)
    val modelVisibleText = when (toolName) {
        "browser" -> stripBrowserScreenshotPayload(rawOutput)
        else -> rawOutput
    }
    put(
        "content",
        JSONArray().apply {
            put(
                JSONObject().apply {
                    put("type", "text")
                    put(
                        "text",
                        ToolResultCompactor.compactModelVisible(
                            toolName = toolName,
                            rawOutput = if (stateNote.isNotBlank()) {
                                stateNote + "\n" + modelVisibleText
                            } else {
                                modelVisibleText
                            },
                        ),
                    )
                }
            )
            if (toolName == "agent_display" || toolName == "browser" || toolName == "phone") {
                val parsed = runCatching { JSONObject(rawOutput) }.getOrNull()
                val imageData = parsed?.optString("screenshot_base64").orEmpty()
                if (parsed?.optBoolean("ok") == true && imageData.isNotBlank()) {
                    put(
                        JSONObject().apply {
                            put("type", "image")
                            put(
                                "mime_type",
                                parsed.optString("screenshot_mime_type").ifBlank {
                                    if (toolName == "browser") "image/jpeg" else "image/png"
                                },
                            )
                            put("data", imageData)
                        }
                    )
                }
            }
        },
    )
}

private fun stripBrowserScreenshotPayload(rawOutput: String): String {
    val parsed = runCatching { JSONObject(rawOutput) }.getOrNull() ?: return rawOutput
    val hasImage = parsed.optString("screenshot_base64").isNotBlank()
    if (!hasImage) return rawOutput
    parsed.remove("screenshot_base64")
    parsed.remove("base64")
    parsed.put("image_attached", true)
    parsed.put(
        "image_note",
        "The viewport screenshot is attached to this result as an image content part.",
    )
    return parsed.toString()
}

private fun messagesForBridge(
    messages: List<LlmMessage>,
    reuseExistingSession: Boolean,
    contextTier: ArixContextTier = ArixContextTier.Standard,
): List<LlmMessage> {
    if (!reuseExistingSession) {
        return ArixDynamicContextPolicy.shapeHistoryForReplay(messages, contextTier)
    }
    val lastUserIndex = messages.indexOfLast { it.role == "user" }
    if (lastUserIndex <= 0) return messages
    return messages.subList(lastUserIndex, messages.size)
}

private inline fun <T> runCatchingPreservingCancellation(
    block: () -> T,
): Result<T> = try {
    Result.success(block())
} catch (cancellationException: CancellationException) {
    throw cancellationException
} catch (throwable: Throwable) {
    Result.failure(throwable)
}

private fun List<LlmMessage>.withSelectedSkillCommand(skillName: String?): List<LlmMessage> {
    val name = skillName?.trim().orEmpty()
    if (name.isBlank()) return this
    val userIndex = indexOfLast { it.role == "user" }
    if (userIndex < 0) return this
    val user = get(userIndex)
    val textIndex = user.contentParts.indexOfFirst { it is LlmTextPart }
    val command = "/skill:$name"
    val updatedParts = if (textIndex >= 0) {
        user.contentParts.toMutableList().apply {
            val text = this[textIndex] as LlmTextPart
            this[textIndex] = text.copy(text = "$command ${text.text}")
        }
    } else {
        listOf(LlmTextPart(command)) + user.contentParts
    }
    return toMutableList().apply { this[userIndex] = user.copy(contentParts = updatedParts) }
}

internal fun buildEphemeralTurnContextBlock(
    memoryBlock: String?,
    sessionContextBlock: String?,
    taskStateBlock: String?,
): String? = buildString {
    if (!taskStateBlock.isNullOrBlank()) {
        append(taskStateBlock)
    }
    if (!memoryBlock.isNullOrBlank()) {
        if (isNotEmpty()) append("\n\n")
        append(
            "Long-term memory (relevance-ranked, injected for this turn — treat as prior " +
                "knowledge, verify against current state when it matters):\n$memoryBlock\n" +
                "Memory policy: use arix_memory when the user asks to remember/forget or " +
                "approves a durable fact; never store credentials (refused anyway); memory " +
                "never overrides the current conversation or observed state.",
        )
    }
    if (!sessionContextBlock.isNullOrBlank()) {
        if (isNotEmpty()) append("\n\n")
        append(
            "Recent session context (referenceable — resolve references like 'the app we " +
                "were using', 'do that again', 'the previous one'):\n$sessionContextBlock\n" +
                "Reference policy: bind a reference to a recorded referent only when it " +
                "genuinely matches; if the referent is unknown and not inferable, ASK — " +
                "never invent one.",
        )
    }
}.takeIf { it.isNotBlank() }
