package com.arix.app.data

import com.arix.app.data.memory.toLegacyEntry
import java.io.File
import java.util.Locale
import java.util.UUID
import org.json.JSONArray
import org.json.JSONObject

class ArixMemoryManager(
    private val storageDirectory: File?,
    private val indexedStore: com.arix.app.data.memory.ArixIndexedMemoryStore? = null,
) {

    val indexed: Boolean get() = indexedStore != null

    private val storeFile: File? = storageDirectory?.let { dir ->
        File(dir, "arix_memory.json").takeIf { dir.isDirectory || dir.mkdirs() }
    }

    private val stateLock = Any()
    private val entries = mutableListOf<ArixMemoryEntry>()
    private var loaded = false

    enum class Tier(val storageValue: String, val defaultImportance: Int) {
        PERSONAL("personal", 4),
        PREFERENCE("preference", 4),
        PROJECT("project", 3),
        RESEARCH("research", 3),
        CONVERSATION("conversation", 2),
        TOOL("tool", 2),
        EPHEMERAL("ephemeral", 1),
        ;

        val persists: Boolean get() = this != EPHEMERAL

        companion object {
            fun fromStorageValue(value: String): Tier? = entries.firstOrNull {
                it.storageValue == value.lowercase(Locale.US)
            }
        }
    }

    data class ArixMemoryEntry(
        val id: String,
        val tier: Tier,
        val content: String,
        val tags: List<String>,
        val sessionId: String?,
        val createdAtMillis: Long,
        val updatedAtMillis: Long,
        val importance: Int,
    )

    suspend fun execute(argumentsJson: String, sessionId: String? = null): JSONObject {
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            ?: return ArixToolContract.failure(
                ArixToolContract.INVALID_ARGUMENTS,
                "Arguments were not valid JSON.",
            )
        val action = arguments.optString("action").trim().lowercase(Locale.US)
        return kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            try {
            when (action) {
                "remember", "save", "store" -> rememberAction(arguments, sessionId)
                "forget", "delete" -> forgetAction(arguments)
                "search" -> searchAction(arguments, sessionId)
                "list" -> listAction(arguments)
                "stats" -> statsAction()
                else -> ArixToolContract.failure(
                    ArixToolContract.INVALID_ARGUMENTS,
                    "Unknown action '$action'. Use: remember, forget, search, list, stats.",
                )
            }
        } catch (ce: kotlinx.coroutines.CancellationException) {
            throw ce
        } catch (t: Throwable) {
            ArixToolContract.failure(
                ArixToolContract.ACTION_FAILED,
                "The memory operation failed: ${t.message ?: "unknown error"}",
            )
        }
        }
    }

    private suspend fun rememberAction(arguments: JSONObject, sessionId: String?): JSONObject {
        val tierValue = arguments.optString("tier").trim().lowercase(Locale.US)
            .ifBlank { "personal" }
        val tier = Tier.fromStorageValue(tierValue)
            ?: return ArixToolContract.failure(
                ArixToolContract.INVALID_ARGUMENTS,
                "Unknown tier '$tierValue'. Use: personal, preference, project, research, conversation, tool, ephemeral.",
            )
        val content = arguments.optString("content").trim()
        if (content.isEmpty()) {
            return ArixToolContract.failure(
                ArixToolContract.INVALID_ARGUMENTS,
                "'content' is required for remember.",
            )
        }
        if (content.length > MaxEntryContentChars) {
            return ArixToolContract.failure(
                ArixToolContract.INVALID_ARGUMENTS,
                "Memory content is too long (max $MaxEntryContentChars characters). Store the essential fact, not the transcript.",
            )
        }
        val secretProblem = secretContentProblem(content)
        if (secretProblem != null) {
            return ArixToolContract.failure(
                ArixToolContract.PERMISSION_REQUIRED,
                "Refusing to store this in memory: $secretProblem Credentials, API keys and passwords belong in Settings → Providers, never in agent memory.",
            )
        }
        val tags = parseTags(arguments.optJSONArray("tags"))
        val importance = arguments.optInt("importance", tier.defaultImportance).coerceIn(1, 5)
        val entrySessionId = when (tier) {
            Tier.CONVERSATION -> sessionId ?: arguments.optString("session_id").trim().ifBlank { null }
            else -> null
        }
        val result = remember(
            tier = tier,
            content = content,
            tags = tags,
            importance = importance,
            sessionId = entrySessionId,
        )
        return ArixToolContract.success(
            JSONObject()
                .put("action", "remember")
                .put("tier", tier.storageValue)
                .put("id", result.first)
                .put("updated", result.second)
                .put("stdout", if (result.second) "Updated the existing memory." else "Remembered."),
            verified = true,
        )
    }

    private suspend fun forgetAction(arguments: JSONObject): JSONObject {
        val id = arguments.optString("id").trim()
        if (id.isNotEmpty()) {
            val removed = forgetById(id)
            return if (removed != null) {
                ArixToolContract.success(
                    JSONObject()
                        .put("action", "forget")
                        .put("deleted", 1)
                        .put("stdout", "Forgot that memory."),
                    verified = true,
                )
            } else {
                ArixToolContract.failure(
                    ArixToolContract.INVALID_ARGUMENTS,
                    "No memory with id '$id' exists.",
                )
            }
        }
        val tierValue = arguments.optString("tier").trim().lowercase(Locale.US)
        val tier = if (tierValue.isNotEmpty()) Tier.fromStorageValue(tierValue) else null
        if (tierValue.isNotEmpty() && tier == null) {
            return ArixToolContract.failure(
                ArixToolContract.INVALID_ARGUMENTS,
                "Unknown tier '$tierValue'.",
            )
        }
        val query = arguments.optString("query").trim()
        if (tier == null && query.isEmpty()) {
            return ArixToolContract.failure(
                ArixToolContract.INVALID_ARGUMENTS,
                "forget requires 'id', or 'query' and/or 'tier'.",
            )
        }
        val confirmed = arguments.optBoolean("confirm", false)
        if (!confirmed) {
            val matching = countMatching(tier, query)
            return ArixToolContract.failure(
                ArixToolContract.PERMISSION_REQUIRED,
                "This would delete $matching memory entr${if (matching == 1) "y" else "ies"}. " +
                    "Bulk deletion is destructive: confirm with the user first, then repeat the call " +
                    "with confirm=true.",
            )
        }
        val deleted = forgetMatching(tier, query)
        return ArixToolContract.success(
            JSONObject()
                .put("action", "forget")
                .put("deleted", deleted)
                .put("stdout", "Deleted $deleted memory entries."),
            verified = true,
        )
    }

    private suspend fun searchAction(arguments: JSONObject, sessionId: String?): JSONObject {
        val query = arguments.optString("query").trim()
        if (query.isEmpty()) {
            return ArixToolContract.failure(
                ArixToolContract.INVALID_ARGUMENTS,
                "'query' is required for search.",
            )
        }
        val tierValue = arguments.optString("tier").trim().lowercase(Locale.US)
        val tier = if (tierValue.isNotEmpty()) Tier.fromStorageValue(tierValue) else null
        val limit = arguments.optInt("limit", DefaultSearchLimit).coerceIn(1, MaxSearchLimit)
        val results = relevant(query = query, sessionId = sessionId, tier = tier, limit = limit)
        return ArixToolContract.success(
            JSONObject()
                .put("action", "search")
                .put("results", JSONArray().apply {
                    results.forEach { entry ->
                        put(entry.toJsonSummary())
                    }
                })
                .put("count", results.size)
                .put("stdout", "Found ${results.size} relevant memories."),
            verified = true,
        )
    }

    private suspend fun listAction(arguments: JSONObject): JSONObject {
        val tierValue = arguments.optString("tier").trim().lowercase(Locale.US)
        val tier = if (tierValue.isNotEmpty()) Tier.fromStorageValue(tierValue) else null
        if (tierValue.isNotEmpty() && tier == null) {
            return ArixToolContract.failure(
                ArixToolContract.INVALID_ARGUMENTS,
                "Unknown tier '$tierValue'.",
            )
        }
        val snapshot = synchronized(stateLock) { ensureLoadedLocked(); entries.toList() }
        val filtered = snapshot
            .filter { tier == null || it.tier == tier }
            .sortedWith(compareByDescending<ArixMemoryEntry> { it.tier.defaultImportance }.thenByDescending { it.updatedAtMillis })
            .take(MaxListEntries)
        return ArixToolContract.success(
            JSONObject()
                .put("action", "list")
                .put("results", JSONArray().apply {
                    filtered.forEach { entry -> put(entry.toJsonSummary()) }
                })
                .put("count", filtered.size)
                .put("stdout", "Listed ${filtered.size} memories."),
            verified = true,
        )
    }

    private suspend fun statsAction(): JSONObject {
        val stats = stats()
        return ArixToolContract.success(
            JSONObject()
                .put("action", "stats")
                .put("tiers", stats)
                .put("total", stats.values.sum())
                .put("stdout", "Memory store: ${stats.values.sum()} entries across ${stats.size} tiers."),
            verified = true,
        )
    }

    suspend fun remember(
        tier: Tier,
        content: String,
        tags: List<String> = emptyList(),
        importance: Int = tier.defaultImportance,
        sessionId: String? = null,
    ): Pair<String, Boolean> {
        val store = indexedStore
        if (store != null) {
            val outcome = store.remember(
                tier = tier,
                content = content,
                tags = tags,
                importance = importance,
                sessionId = sessionId,
            )
            return outcome.id to outcome.updated
        }
        return synchronized(stateLock) {
        ensureLoadedLocked()
        val now = System.currentTimeMillis()
        val normalized = content.trim()
        val existing = entries.firstOrNull { it.tier == tier && it.content.equals(normalized, ignoreCase = true) }
        if (existing != null) {
            val updated = existing.copy(
                tags = (existing.tags + tags).distinct().take(MaxTagsPerEntry),
                updatedAtMillis = now,
                importance = importance.coerceIn(1, 5),
            )
            entries[entries.indexOf(existing)] = updated
            persistLocked()
            updated.id to true
        } else {
            val entry = ArixMemoryEntry(
                id = UUID.randomUUID().toString().substring(0, 12),
                tier = tier,
                content = normalized,
                tags = tags.distinct().take(MaxTagsPerEntry),
                sessionId = sessionId,
                createdAtMillis = now,
                updatedAtMillis = now,
                importance = importance.coerceIn(1, 5),
            )
            entries.add(entry)
            enforceCapsLocked()
            persistLocked()
            entry.id to false
        }
        }
    }

    suspend fun activateIndexedStore(): Int = indexedStore
        ?.migrateLegacyJsonIfPresent(storageDirectory ?: return 0)
        ?.also { imported -> if (imported > 0) sweepIndexed() }
        ?: 0

    fun sweepIndexed(): Int = indexedStore?.sweep() ?: 0

    private suspend fun forgetById(id: String): ArixMemoryEntry? {
        val store = indexedStore
        if (store != null) {
            val entry = store.allEntries().firstOrNull { it.id == id }?.toLegacyEntry()
            if (entry != null) store.deleteById(id)
            return entry
        }
        return synchronized(stateLock) {
        ensureLoadedLocked()
        val entry = entries.firstOrNull { it.id == id }
        if (entry != null) {
            entries.remove(entry)
            persistLocked()
        }
        entry
        }
    }

    private fun countMatching(tier: Tier?, query: String): Int {
        val store = indexedStore
        if (store != null) {
            val tokens = tokenize(query)
            return store.allEntries().count { entry ->
                (tier == null || entry.tier == tier.storageValue) &&
                    (query.isEmpty() || entryContains(entry.toLegacyEntry(), query, tokens))
            }
        }
        val tokens = tokenize(query)
        return synchronized(stateLock) {
            ensureLoadedLocked()
            entries.count { entry ->
                (tier == null || entry.tier == tier) &&
                    (query.isEmpty() || entryContains(entry, query, tokens))
            }
        }
    }

    private suspend fun forgetMatching(tier: Tier?, query: String): Int {
        val store = indexedStore
        if (store != null) {
            return store.deleteMatching(tier, query)
        }
        val tokens = tokenize(query)
        return synchronized(stateLock) {
        ensureLoadedLocked()
        val before = entries.size
        entries.removeIf { entry ->
            (tier == null || entry.tier == tier) &&
                (query.isEmpty() || entryContains(entry, query, tokens))
        }
        val deleted = before - entries.size
        if (deleted > 0) persistLocked()
        deleted
        }
    }

    fun stats(): Map<String, Int> {
        indexedStore?.let { store -> return store.stats() }
        return synchronized(stateLock) {
        ensureLoadedLocked()
        val snapshot = entries.toList()
        Tier.entries.associate { tier ->
            tier.storageValue to snapshot.count { it.tier == tier }
        }.filterValues { it > 0 }
        }
    }

    fun relevant(
        query: String,
        sessionId: String? = null,
        tier: Tier? = null,
        limit: Int = DefaultSearchLimit,
        allowFallback: Boolean = false,
    ): List<ArixMemoryEntry> {
        if (query.isBlank()) return emptyList()
        val store = indexedStore
        if (store != null) {
            val ranked = store.rankedSearch(
                query = query,
                sessionId = sessionId,
                tier = tier,
                limit = limit,
            )
            return ranked.map { it.entity.toLegacyEntry() }
        }
        val tokens = tokenize(query)
        val snapshot = synchronized(stateLock) { ensureLoadedLocked(); entries.toList() }
        if (snapshot.isEmpty()) return emptyList()
        val now = System.currentTimeMillis()
        val scored = snapshot.asSequence()
            .filter { tier == null || it.tier == tier }
            .mapNotNull { entry ->
                val entryTokens = entry.tokens()
                var overlap = 0
                tokens.forEach { token ->
                    if (entryTokens.contains(token)) overlap += 1
                }
                if (overlap == 0) return@mapNotNull null
                var score = overlap * 2.0 + entry.importance
                val ageDays = ((now - entry.updatedAtMillis) / MillisPerDay).coerceAtLeast(0)
                score += 2.0 / (1.0 + ageDays / 30.0)
                if (sessionId != null && entry.tier == Tier.CONVERSATION && entry.sessionId == sessionId) {
                    score += 2.0
                }
                entry to score
            }
        val matched = scored
            .sortedByDescending { (_, score) -> score }
            .map { (entry, _) -> entry }
            .take(limit.coerceIn(1, MaxSearchLimit))
            .toList()
        if (matched.isNotEmpty() || !allowFallback || tokens.isEmpty()) return matched
        return snapshot.asSequence()
            .filter { tier == null || it.tier == tier }
            .sortedWith(compareByDescending<ArixMemoryEntry> { it.importance }.thenByDescending { it.updatedAtMillis })
            .take(limit.coerceIn(1, MaxSearchLimit))
            .toList()
    }

    fun promptBlock(query: String, sessionId: String?): String? {
        val picked = relevant(query = query, sessionId = sessionId, limit = MaxPromptEntries)
        if (picked.isEmpty()) return null
        val builder = StringBuilder()
        for (entry in picked) {
            val line = "- [${entry.tier.storageValue}] ${entry.content}" +
                if (entry.tags.isNotEmpty()) " (${entry.tags.joinToString(" ")})" else ""
            if (builder.length + line.length > MaxPromptBlockChars) break
            if (builder.isNotEmpty()) builder.append('\n')
            builder.append(line)
        }
        if (builder.isEmpty()) return null
        return builder.toString()
    }

    private fun ensureLoadedLocked() {
        if (loaded) return
        loaded = true
        val file = storeFile ?: return
        runCatching {
            if (!file.isFile) return@runCatching
            val raw = runCatching { file.readText() }.getOrElse {
                backupDamagedStore(file)
                storeDamaged = true
                return@runCatching
            }
            val parsed = runCatching { JSONObject(raw) }.getOrElse {
                backupDamagedStore(file)
                storeDamaged = true
                return@runCatching
            }
            val array = parsed.optJSONArray("entries") ?: run {
                backupDamagedStore(file)
                storeDamaged = true
                return@runCatching
            }
            val parsedEntries = mutableListOf<ArixMemoryEntry>()
            for (index in 0 until array.length()) {
                val entryJson = array.optJSONObject(index) ?: continue
                val tier = Tier.fromStorageValue(entryJson.optString("tier")) ?: continue
                if (tier == Tier.EPHEMERAL) continue
                val content = entryJson.optString("content").trim()
                if (content.isEmpty()) continue
                parsedEntries.add(
                    ArixMemoryEntry(
                        id = entryJson.optString("id").ifBlank { UUID.randomUUID().toString().substring(0, 12) },
                        tier = tier,
                        content = content.take(MaxEntryContentChars),
                        tags = parseTags(entryJson.optJSONArray("tags")),
                        sessionId = entryJson.optString("session_id").trim().ifBlank { null },
                        createdAtMillis = entryJson.optLong("created_at", System.currentTimeMillis()),
                        updatedAtMillis = entryJson.optLong("updated_at", System.currentTimeMillis()),
                        importance = entryJson.optInt("importance", tier.defaultImportance).coerceIn(1, 5),
                    ),
                )
            }
            if (file.length() > MaxStoreFileBytes) {
                parsedEntries.sortByDescending { it.updatedAtMillis }
                entries.addAll(parsedEntries.take(MaxTotalEntries))
                storeSalvagedOversized = true
            } else {
                entries.addAll(parsedEntries)
            }
        }
    }

    private fun backupDamagedStore(file: java.io.File) {
        runCatching {
            if (storeDamagedBackupCreated) return
            storeDamagedBackupCreated = true
            val backup = java.io.File(
                file.parentFile,
                file.nameWithoutExtension + "-damaged-" +
                    System.currentTimeMillis() + ".json",
            )
            file.copyTo(backup, overwrite = false)
        }
    }

    private var storeDamaged = false

    private var storeSalvagedOversized = false

    private var storeDamagedBackupCreated = false

    private fun persistLocked() {
        val file = storeFile ?: return
        runCatching {
            if (!tierOkToPersist()) return@runCatching
            val payload = JSONObject().put(
                "entries",
                JSONArray().apply {
                    entries.filter { it.tier.persists }.forEach { entry ->
                        put(
                            JSONObject()
                                .put("id", entry.id)
                                .put("tier", entry.tier.storageValue)
                                .put("content", entry.content)
                                .put("tags", JSONArray(entry.tags))
                                .putOpt("session_id", entry.sessionId)
                                .put("created_at", entry.createdAtMillis)
                                .put("updated_at", entry.updatedAtMillis)
                                .put("importance", entry.importance),
                        )
                    }
                },
            )
            val temp = File(file.parentFile, file.name + ".tmp")
            temp.writeText(payload.toString())
            if (!temp.renameTo(file)) {
                file.writeText(payload.toString())
                temp.delete()
            }
        }
    }

    private fun tierOkToPersist(): Boolean = true

    private fun enforceCapsLocked() {
        if (entries.size > MaxTotalEntries) {
            val sorted = entries.sortedWith(
                compareBy<ArixMemoryEntry> { it.importance }.thenBy { it.updatedAtMillis },
            )
            val toRemove = entries.size - MaxTotalEntries
            sorted.take(toRemove).forEach { entries.remove(it) }
        }
        Tier.entries.filter { it.persists }.forEach { tier ->
            val tierEntries = entries.filter { it.tier == tier }
            if (tierEntries.size > MaxEntriesPerTier) {
                val excess = tierEntries.size - MaxEntriesPerTier
                tierEntries
                    .sortedWith(compareBy<ArixMemoryEntry> { it.importance }.thenBy { it.updatedAtMillis })
                    .take(excess)
                    .forEach { entries.remove(it) }
            }
        }
    }

    private fun ArixMemoryEntry.tokens(): Set<String> =
        tokenize(content) + tags.map { it.lowercase(Locale.US) }.toSet()

    private fun entryContains(entry: ArixMemoryEntry, query: String, tokens: Set<String>): Boolean =
        entry.content.contains(query, ignoreCase = true) || entry.tokens().any { it in tokens }

    private fun parseTags(array: JSONArray?): List<String> {
        if (array == null) return emptyList()
        val tags = mutableListOf<String>()
        for (index in 0 until array.length()) {
            val tag = array.optString(index).trim().lowercase(Locale.US)
            if (tag.isNotEmpty()) tags.add(tag)
            if (tags.size >= MaxTagsPerEntry) break
        }
        return tags
    }

    private fun ArixMemoryEntry.toJsonSummary(): JSONObject = JSONObject()
        .put("id", id)
        .put("tier", tier.storageValue)
        .put("content", content)
        .put("importance", importance)
        .put("updated_at", updatedAtMillis)
        .put("tags", JSONArray(tags))

    companion object {
        const val MaxEntryContentChars = 400
        private const val MaxTagsPerEntry = 6
        private const val MaxEntriesPerTier = 400
        private const val MaxTotalEntries = 1200
        private const val MaxStoreFileBytes = 2 * 1024 * 1024
        private const val MaxSearchLimit = 25
        private const val DefaultSearchLimit = 8
        private const val MaxListEntries = 50
        private const val MaxPromptEntries = 8
        private const val MaxPromptBlockChars = 1200
        private const val MillisPerDay = 24L * 60L * 60L * 1000L

        private val Stopwords = setOf(
            "the", "a", "an", "and", "or", "of", "to", "in", "on", "at", "for", "is", "are",
            "was", "be", "my", "me", "i", "you", "your", "it", "this", "that", "with", "do",
            "does", "did", "what", "when", "where", "how", "who", "can", "will", "would",
            "please", "about", "from", "by", "as", "am", "have", "has", "had", "not", "no",
        )

        fun secretContentProblem(content: String): String? {
            val compact = content.replace("\\s+".toRegex(), "")
            val lowered = content.lowercase(Locale.US)
            if (lowered.contains("sk-") || lowered.contains("api key is") ||
                lowered.contains("password is") || lowered.contains("apikey:") ||
                lowered.contains("token is") || lowered.contains("bearer ")
            ) {
                return "the content looks like a credential."
            }
            if (compact.contains(Regex("(AKIA|ASIA)[A-Z0-9]{16}"))) {
                return "the content looks like an AWS access key."
            }
            val words = content.split(Regex("[\\s,;:]+")).filter { it.length >= 32 }
            if (words.any { word -> word.count { it.isLetterOrDigit() } >= 32 && word.count { it.isDigit() } >= 4 }) {
                return "the content contains a long secret-looking token."
            }
            return null
        }

        fun tokenize(text: String): Set<String> = text
            .lowercase(Locale.US)
            .split(Regex("[^a-z0-9\\u4e00-\\u9fff']+"))
            .filter { it.length >= 2 && it !in Stopwords }
            .toSet()
    }
}
