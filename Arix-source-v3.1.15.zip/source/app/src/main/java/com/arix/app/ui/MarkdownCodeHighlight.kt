package com.arix.app.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight

internal object MarkdownCodeHighlight {

    private data class Span(
        val start: Int,
        val end: Int,
        val style: SpanStyle,
    )

    private val kotlinKeywords = setOf(
        "package", "import", "class", "object", "interface", "fun", "val", "var",
        "when", "if", "else", "for", "while", "do", "return", "is", "in", "as",
        "private", "internal", "public", "protected", "override", "open", "abstract",
        "sealed", "data", "companion", "suspend", "lateinit", "const", "enum",
        "try", "catch", "finally", "throw", "this", "super", "null", "true", "false",
        "typealias", "operator", "inline", "reified", "vararg", "by", "get", "set",
        "init", "constructor", "break", "continue", "where", "out", "dynamic",
    )
    private val javaKeywords = setOf(
        "package", "import", "public", "private", "protected", "class", "interface",
        "extends", "implements", "static", "final", "void", "int", "long", "float",
        "double", "boolean", "char", "byte", "short", "new", "return", "if", "else",
        "for", "while", "do", "switch", "case", "break", "continue", "try", "catch",
        "finally", "throw", "throws", "this", "super", "null", "true", "false",
        "abstract", "synchronized", "volatile", "transient", "instanceof", "enum",
        "record", "var", "assert", "native", "strictfp",
    )
    private val pythonKeywords = setOf(
        "def", "class", "return", "if", "elif", "else", "for", "while", "in", "is",
        "not", "and", "or", "import", "from", "as", "with", "try", "except",
        "finally", "raise", "assert", "lambda", "pass", "break", "continue",
        "global", "nonlocal", "yield", "async", "await", "self", "None", "True",
        "False", "print", "del", "match", "case",
    )
    private val jsKeywords = setOf(
        "function", "const", "let", "var", "return", "if", "else", "for", "while",
        "do", "switch", "case", "break", "continue", "new", "delete", "typeof",
        "instanceof", "in", "of", "class", "extends", "super", "this", "null",
        "undefined", "true", "false", "async", "await", "try", "catch", "finally",
        "throw", "yield", "import", "export", "from", "default", "static", "get",
        "set", "void", "new.target",
    )
    private val shellKeywords = setOf(
        "if", "then", "else", "elif", "fi", "for", "do", "done", "while", "until",
        "case", "esac", "function", "in", "select", "local", "export", "return",
        "exit", "echo", "cd", "source", "set", "unset", "alias", "shift", "read",
        "printf", "trap", "sudo", "apt", "apt-get", "pip", "pip3", "npm", "yarn",
        "pnpm", "git", "curl", "wget", "tar", "unzip", "chmod", "chown", "mkdir",
        "rm", "cp", "mv", "ls", "cat", "grep", "sed", "awk", "which", "python",
        "python3", "node", "java", "kotlinc", "gradle", "adb", "am", "pm", "sh",
        "bash", "zsh", "termux-setup-storage", "pkg", "termux-info",
    )
    private val sqlKeywords = setOf(
        "SELECT", "FROM", "WHERE", "INSERT", "INTO", "VALUES", "UPDATE", "SET",
        "DELETE", "CREATE", "TABLE", "ALTER", "DROP", "INDEX", "VIEW", "JOIN",
        "LEFT", "RIGHT", "INNER", "OUTER", "FULL", "CROSS", "ON", "AS", "AND",
        "OR", "NOT", "NULL", "IS", "IN", "BETWEEN", "LIKE", "ORDER", "BY", "GROUP",
        "HAVING", "LIMIT", "OFFSET", "DISTINCT", "COUNT", "SUM", "AVG", "MIN",
        "MAX", "PRIMARY", "KEY", "FOREIGN", "REFERENCES", "UNIQUE", "DEFAULT",
        "CONSTRAINT", "CASCADE", "BEGIN", "COMMIT", "ROLLBACK", "TRANSACTION",
        "CASE", "WHEN", "THEN", "ELSE", "END", "UNION", "ALL", "EXISTS", "WITH",
    )
    private val goKeywords = setOf(
        "package", "import", "func", "var", "const", "type", "struct", "interface",
        "map", "chan", "go", "defer", "return", "if", "else", "for", "range",
        "switch", "case", "default", "break", "continue", "select", "fallthrough",
        "nil", "true", "false", "new", "make", "len", "cap", "append", "panic",
        "recover", "error", "string", "int", "int64", "float64", "bool", "byte",
    )
    private val rustKeywords = setOf(
        "fn", "let", "mut", "const", "static", "struct", "enum", "trait", "impl",
        "pub", "use", "mod", "crate", "self", "super", "where", "as", "in", "for",
        "while", "loop", "if", "else", "match", "return", "break", "continue",
        "dyn", "ref", "move", "async", "await", "unsafe", "type", "true", "false",
        "Some", "None", "Ok", "Err",
    )

    private fun keywordsFor(language: String): Set<String>? = when (language) {
        "kotlin", "kt" -> kotlinKeywords
        "java" -> javaKeywords
        "python", "py", "python3" -> pythonKeywords
        "javascript", "js", "jsx", "typescript", "ts", "tsx", "mjs", "cjs" -> jsKeywords
        "shell", "sh", "bash", "zsh", "console", "terminal" -> shellKeywords
        "sql", "sqlite" -> sqlKeywords
        "go", "golang" -> goKeywords
        "rust", "rs" -> rustKeywords
        else -> null
    }

    private fun isJsonLike(language: String): Boolean =
        language == "json" || language == "jsonc" || language == "json5"

    private val commentColor = Color(0xFF8A8F98)
    private val stringColor = Color(0xFF3E7B57)
    private val numberColor = Color(0xFF8B5CF0)
    private val keywordColor = Color(0xFF2F6DA3)
    private val annotationColor = Color(0xFF9C6B2F)
    private val jsonKeyColor = Color(0xFF2F6DA3)

    internal fun highlight(code: String, language: String): AnnotatedString {
        val spans = mutableListOf<Span>()
        val lineComment = lineCommentToken(language)
        val blockComment = language != "python" && language != "py" && language != "python3"
        var index = 0

        while (index < code.length) {
            val ch = code[index]

            if (lineComment != null && code.startsWith(lineComment, index)) {
                val end = code.indexOf('\n', index).let { if (it < 0) code.length else it }
                spans += Span(index, end, SpanStyle(color = commentColor))
                index = end
                continue
            }

            if (blockComment && ch == '/' && index + 1 < code.length && code[index + 1] == '*') {
                val end = code.indexOf("*/", index + 2).let {
                    if (it < 0) code.length else (it + 2).coerceAtMost(code.length)
                }
                spans += Span(index, end, SpanStyle(color = commentColor))
                index = end
                continue
            }

            if (ch == '"' || ch == '\'' || ch == '`') {
                val end = findStringEnd(code, index, ch)
                spans += Span(index, end, SpanStyle(color = stringColor))
                index = end
                continue
            }

            if (ch == '@' && index + 1 < code.length && code[index + 1].isLetter()) {
                var end = index + 1
                while (end < code.length && (code[end].isLetterOrDigit() || code[end] == '_')) end++
                spans += Span(index, end, SpanStyle(color = annotationColor))
                index = end
                continue
            }

            if (ch.isDigit() && (index == 0 || !code[index - 1].isLetterOrDigit())) {
                var end = index
                var isHex = false
                if (ch == '0' && index + 1 < code.length && (code[index + 1] == 'x' || code[index + 1] == 'X')) {
                    isHex = true
                    end += 2
                }
                var consumedDecimalPoint = false
                while (end < code.length) {
                    val current = code[end]
                    when {
                        current.isDigit() -> end++
                        current == '.' && !isHex && !consumedDecimalPoint &&
                            end + 1 < code.length && code[end + 1].isDigit() -> {
                            consumedDecimalPoint = true
                            end++
                        }
                        isHex && current.isLetterOrDigit() && current !in 'g'..'z' -> end++
                        else -> break
                    }
                }
                if (end < code.length && (code[end] == 'f' || code[end] == 'L' || code[end] == 'l' || code[end] == 'd' || code[end] == 'u')) end++
                spans += Span(index, end, SpanStyle(color = numberColor))
                index = end
                continue
            }

            if (ch.isLetter() || ch == '_') {
                var end = index
                while (end < code.length && (code[end].isLetterOrDigit() || code[end] == '_')) end++
                val word = code.substring(index, end)
                val keywords = keywordsFor(language)
                val style: SpanStyle? = when {
                    keywords != null && (word in keywords || word.uppercase() in keywords) ->
                        SpanStyle(color = keywordColor, fontWeight = FontWeight.Medium)
                    isJsonLike(language) && end < code.length && code[end] == ':' && language == "json" ->
                        SpanStyle(color = jsonKeyColor)
                    else -> null
                }
                if (style != null) {
                    spans += Span(index, end, style)
                }
                index = end
                continue
            }

            index++
        }

        return buildAnnotatedString {
            append(code)
            spans.forEach { span ->
                addStyle(span.style, span.start, span.end)
            }
        }
    }

    private fun lineCommentToken(language: String): String? = when (language) {
        "python", "py", "python3", "shell", "sh", "bash", "zsh", "console", "terminal",
        "yaml", "yml", "toml", "ini", "r", "ruby", "rb", "perl", "makefile", "dockerfile",
        -> "#"
        "kotlin", "kt", "java", "javascript", "js", "jsx", "typescript", "ts", "tsx",
        "mjs", "cjs", "go", "golang", "rust", "rs", "c", "cpp", "c++", "swift",
        "dart", "scala", "groovy", "jsonc", "json5",
        -> "//"
        else -> "//"
    }

    private fun findStringEnd(code: String, start: Int, quote: Char): Int {
        var index = start + 1
        while (index < code.length) {
            val c = code[index]
            if (c == '\\' && index + 1 < code.length) {
                index += 2
                continue
            }
            if (c == quote) return index + 1
            if (c == '\n' && quote != '`') return index
            index++
        }
        return code.length
    }
}
