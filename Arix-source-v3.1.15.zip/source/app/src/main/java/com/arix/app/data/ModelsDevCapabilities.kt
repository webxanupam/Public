package com.arix.app.data

import org.json.JSONArray
import org.json.JSONObject

val ModelsDevThinkingLevels: List<String> = listOf("off", "minimal", "low", "medium", "high", "xhigh", "max")

data class ModelsDevModelLimits(
    val contextWindow: Int? = null,
    val maxOutputTokens: Int? = null,
    val supportsImageInput: Boolean? = null,
)

data class ModelsDevModelCapabilities(
    val reasoning: Boolean,
    val thinkingLevels: List<String>,
    val thinkingLevelMap: Map<String, String>,
    val limits: ModelsDevModelLimits,
)

data class ModelsDevCapabilitiesResult(
    val levelsByProviderModel: Map<String, List<String>> = emptyMap(),
    val levelMapsByProviderModel: Map<String, Map<String, String>> = emptyMap(),
    val reasoningModels: Set<String> = emptySet(),
    val limitsByProviderModel: Map<String, ModelsDevModelLimits> = emptyMap(),
)

fun modelsDevCatalogKey(providerId: String, modelId: String): String =
    "${providerId.trim()}/${modelId.substringAfterLast('/').trim()}"

fun resolveModelsDevCapabilities(
    catalogJson: String,
    options: List<ProviderModelOption>,
): ModelsDevCapabilitiesResult {
    val catalog = runCatching { JSONObject(catalogJson) }.getOrNull()
        ?: return ModelsDevCapabilitiesResult()
    return resolveModelsDevCapabilities(catalog, options)
}

internal fun resolveModelsDevCapabilities(
    catalog: JSONObject,
    options: List<ProviderModelOption>,
): ModelsDevCapabilitiesResult {
    val providers = catalog.optJSONObject("providers") ?: return ModelsDevCapabilitiesResult()
    val index = ModelsDevCatalogIndex(providers, catalog.optJSONObject("models"))
    val levels = mutableMapOf<String, List<String>>()
    val levelMaps = mutableMapOf<String, Map<String, String>>()
    val reasoningModels = mutableSetOf<String>()
    val limits = mutableMapOf<String, ModelsDevModelLimits>()
    options.forEach { option ->
        val capabilities = index.resolve(option) ?: return@forEach
        val key = modelsDevCatalogKey(option.piProviderId, option.modelId)
        levels[key] = capabilities.thinkingLevels
        if (capabilities.thinkingLevelMap.isNotEmpty()) levelMaps[key] = capabilities.thinkingLevelMap
        if (capabilities.reasoning) reasoningModels += key
        limits[key] = capabilities.limits
    }
    return ModelsDevCapabilitiesResult(levels, levelMaps, reasoningModels, limits)
}

private class ModelsDevCatalogIndex(
    private val providers: JSONObject,
    canonicalModels: JSONObject?,
) {
    private class Entry(val providerId: String, val model: JSONObject)

    private val entriesByCanonicalId = mutableMapOf<String, MutableList<Entry>>()
    private val entriesByModelId = mutableMapOf<String, MutableList<Entry>>()
    private val canonicalIdsByShortId = mutableMapOf<String, MutableList<String>>()
    private val canonicalIds = mutableSetOf<String>()

    init {
        canonicalModels?.keys()?.forEach { id ->
            val canonicalId = id.trim().lowercase()
            canonicalIds += canonicalId
            canonicalIdsByShortId.getOrPut(canonicalId.substringAfterLast('/')) { mutableListOf() } += canonicalId
        }
        providers.keys().forEach { providerId ->
            val models = providers.optJSONObject(providerId)?.optJSONObject("models") ?: return@forEach
            models.keys().forEach { key ->
                val model = models.optJSONObject(key) ?: return@forEach
                val entry = Entry(providerId, model)
                model.optStringOrBlank("canonical_model_id").lowercase().takeIf(String::isNotBlank)?.let { canonicalId ->
                    entriesByCanonicalId.getOrPut(canonicalId) { mutableListOf() } += entry
                }
                val id = model.optStringOrBlank("id").ifBlank { key }
                setOf(key, id, id.substringAfterLast('/'))
                    .map { it.trim().lowercase() }
                    .filter(String::isNotBlank)
                    .forEach { lookupKey -> entriesByModelId.getOrPut(lookupKey) { mutableListOf() } += entry }
            }
        }
    }

    fun resolve(option: ProviderModelOption): ModelsDevModelCapabilities? {
        val definition = PiProviderCatalog.find(option.piProviderId)?.takeIf(PiProviderDefinition::isBuiltIn)
        definition?.modelsDevProviderIds().orEmpty().firstNotNullOfOrNull { providerId ->
            findInProvider(providerId, option)
        }?.let { return capabilitiesOf(listOf(it)) }

        val canonicalId = canonicalIdFor(option)
        val labId = canonicalId?.substringBefore('/', "")?.takeIf(String::isNotBlank)
            ?: option.modelId.substringBeforeLast('/', "").substringAfterLast('/').trim().lowercase()
                .takeIf(String::isNotBlank)
        if (labId != null) {
            val firstParty = canonicalId?.let(entriesByCanonicalId::get).orEmpty()
                .firstOrNull { it.providerId.equals(labId, ignoreCase = true) }
                ?: findInProvider(labId, option)
            if (firstParty != null) return capabilitiesOf(listOf(firstParty))
        }
        val candidates = canonicalId?.let(entriesByCanonicalId::get).orEmpty().ifEmpty {
            option.lookupKeys().firstNotNullOfOrNull { key -> entriesByModelId[key]?.takeIf(List<Entry>::isNotEmpty) }
                .orEmpty()
        }
        if (candidates.isEmpty()) return null
        return capabilitiesOf(candidates)
    }

    private fun findInProvider(providerId: String, option: ProviderModelOption): Entry? {
        val models = providers.optJSONObject(providerId)?.optJSONObject("models") ?: return null
        option.lookupKeys(caseSensitive = true).firstNotNullOfOrNull { key -> models.optJSONObject(key) }
            ?.let { return Entry(providerId, it) }
        val shortId = option.modelId.substringAfterLast('/').trim()
        return models.keys().asSequence().mapNotNull { key ->
            val model = models.optJSONObject(key) ?: return@mapNotNull null
            model.takeIf {
                listOf(key, model.optStringOrBlank("id")).any { id ->
                    id.substringAfterLast('/').trim().equals(shortId, ignoreCase = true)
                }
            }?.let { Entry(providerId, it) }
        }.firstOrNull()
    }

    private fun canonicalIdFor(option: ProviderModelOption): String? {
        val keys = option.lookupKeys()
        keys.firstOrNull { it in canonicalIds }?.let { return it }
        keys.forEach { key ->
            val fromEntries = entriesByModelId[key].orEmpty()
                .mapNotNull { entry -> entry.model.optStringOrBlank("canonical_model_id").lowercase().takeIf(String::isNotBlank) }
            mostCommon(fromEntries)?.let { return it }
        }
        val shortId = option.modelId.substringAfterLast('/').trim().lowercase()
        val byShortId = canonicalIdsByShortId[shortId].orEmpty()
        val prefix = option.modelId.substringBeforeLast('/', "").substringAfterLast('/').trim().lowercase()
        return byShortId.firstOrNull { prefix.isNotBlank() && it.startsWith("$prefix/") } ?: byShortId.firstOrNull()
    }

    private fun capabilitiesOf(entries: List<Entry>): ModelsDevModelCapabilities {
        val reasoningEntries = entries.filter { it.model.optBooleanOrNull("reasoning") == true }
        val levels = mutableSetOf<String>()
        var canDisable = false
        reasoningEntries.forEach { entry ->
            entry.model.optJSONArrayOrEmpty("reasoning_options").forEach { reasoningOption ->
                val option = reasoningOption ?: return@forEach
                when (option.optStringOrBlank("type")) {
                    "toggle" -> canDisable = true
                    "effort" -> option.optStringValues("values").forEach { value ->
                        val level = value.trim().lowercase()
                        when {
                            level == "none" || level == "off" -> canDisable = true
                            level.isNotBlank() && level in ModelsDevThinkingLevels -> levels += level
                        }
                    }
                }
            }
        }
        val reasoning = reasoningEntries.isNotEmpty()
        val thinkingLevels = if (!reasoning) {
            emptyList()
        } else {
            ModelsDevThinkingLevels.filter { level -> if (level == "off") canDisable else level in levels }
        }
        return ModelsDevModelCapabilities(
            reasoning = reasoning,
            thinkingLevels = thinkingLevels,
            thinkingLevelMap = if (reasoning && canDisable) mapOf("off" to "none") else emptyMap(),
            limits = ModelsDevModelLimits(
                contextWindow = mostCommon(entries.mapNotNull { it.model.limit("context") }),
                maxOutputTokens = mostCommon(entries.mapNotNull { it.model.limit("output") }),
                supportsImageInput = entries
                    .mapNotNull { entry -> entry.model.optJSONObject("modalities")?.optJSONArray("input") }
                    .takeIf(List<JSONArray>::isNotEmpty)
                    ?.any { input -> (0 until input.length()).any { input.optString(it) == "image" } },
            ),
        )
    }
}

private fun ProviderModelOption.lookupKeys(caseSensitive: Boolean = false): List<String> =
    listOf(
        modelId,
        modelId.substringAfter("$piProviderId/", modelId),
        modelId.substringAfterLast('/'),
    ).map { key -> key.trim().let { if (caseSensitive) it else it.lowercase() } }
        .filter(String::isNotBlank)
        .distinct()

private fun <T : Comparable<T>> mostCommon(values: List<T>): T? =
    values.groupingBy { it }.eachCount().entries
        .maxWithOrNull(compareBy<Map.Entry<T, Int>> { it.value }.thenBy { it.key })
        ?.key

private fun JSONObject.optStringOrBlank(key: String): String = optString(key).trim()

private fun JSONObject.optBooleanOrNull(key: String): Boolean? =
    if (has(key) && !isNull(key)) optBoolean(key) else null

private fun JSONObject.optJSONArrayOrEmpty(key: String): List<JSONObject?> =
    (optJSONArray(key) ?: JSONArray()).let { array -> (0 until array.length()).map { array.optJSONObject(it) } }

private fun JSONObject.optStringValues(key: String): List<String> =
    (optJSONArray(key) ?: JSONArray()).let { array -> (0 until array.length()).map { array.optString(it) } }

private fun JSONObject.limit(key: String): Int? =
    optJSONObject("limit")?.optDouble(key, Double.NaN)?.takeIf { !it.isNaN() && it > 0 && it <= Int.MAX_VALUE }?.toInt()
