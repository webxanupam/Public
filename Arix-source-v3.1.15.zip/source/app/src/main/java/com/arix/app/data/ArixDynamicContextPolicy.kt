package com.arix.app.data

import org.json.JSONArray
import org.json.JSONObject

enum class ArixContextTier(val wireName: String) {
    Minimal("minimal"),
    Standard("standard"),
    Deep("deep"),
}

data class ArixContextTurnSignals(
    val userText: String,
    val attachmentCount: Int = 0,
    val activeSkillCount: Int = 0,
    val hasActiveTaskState: Boolean = false,
    val recentToolInvocationCount: Int = 0,
    val sessionMessageCount: Int = 0,
)

object ArixDynamicContextPolicy {

    fun classifyStructural(signals: ArixContextTurnSignals): ArixContextTier? {
        val text = signals.userText.trim()
        if (text.isEmpty()) return ArixContextTier.Standard

        if (signals.attachmentCount > 0) return ArixContextTier.Deep
        if (signals.hasActiveTaskState) return ArixContextTier.Deep
        if (signals.recentToolInvocationCount > 0) return ArixContextTier.Deep
        if (signals.activeSkillCount > 0) return ArixContextTier.Deep
        if (text.length > LongRequestChars) return ArixContextTier.Deep

        return null
    }

    fun classifyLocalTier(signals: ArixContextTurnSignals): ArixContextTier =
        classifyStructural(signals) ?: run {
            val text = signals.userText.trim().lowercase()
            if (
                text.length <= MaxLocalMinimalChars &&
                !hasIntentMarker(text) &&
                !hasFileOrCodeMarker(text) &&
                !hasUrlMarker(text) &&
                !MemoryReferenceMarkers.any(text::contains) &&
                !ConversationReferenceMarkers.any(text::contains)
            ) {
                ArixContextTier.Minimal
            } else {
                ArixContextTier.Standard
            }
        }

    private fun hasIntentMarker(text: String): Boolean =
        BrowserIntentMarkers.any(text::contains) ||
            TerminalIntentMarkers.any(text::contains) ||
            MediaIntentMarkers.any(text::contains) ||
            WebResearchIntentMarkers.any(text::contains) ||
            AutomationIntentMarkers.any(text::contains) ||
            PaymentIntentMarkers.any(text::contains) ||
            FileShareIntentMarkers.any(text::contains)

    private fun hasFileOrCodeMarker(text: String): Boolean =
        text.contains("```") ||
            FileExtensionMarker.containsMatchIn(text) ||
            PathLikeMarker.containsMatchIn(text)

    private fun hasUrlMarker(text: String): Boolean =
        UrlLikeMarker.containsMatchIn(text)

    fun trimFractionFor(tier: ArixContextTier): Double = when (tier) {
        ArixContextTier.Minimal -> MinimalTrimFraction
        ArixContextTier.Standard -> StandardTrimFraction
        ArixContextTier.Deep -> DeepTrimFraction
    }

    fun compactThresholdFor(tier: ArixContextTier): Double = when (tier) {
        ArixContextTier.Minimal -> MinimalCompactThreshold
        ArixContextTier.Standard -> StandardCompactThreshold
        ArixContextTier.Deep -> DeepCompactThreshold
    }

    fun contextPolicyPayload(tier: ArixContextTier): JSONObject = JSONObject().apply {
        put("tier", tier.wireName)
        put("trim_fraction", trimFractionFor(tier))
        put("compact_threshold", compactThresholdFor(tier))
    }

    fun shapeHistoryForReplay(
        messages: List<LlmMessage>,
        tier: ArixContextTier,
    ): List<LlmMessage> {
        val lastUserIndex = messages.indexOfLast { it.role == "user" }
        if (lastUserIndex <= 0) return messages
        val history = messages.subList(0, lastUserIndex)
        val verbatimCount = recentVerbatimMessages(tier)
        val oldEnd = (history.size - verbatimCount).coerceAtLeast(0)
        var changed = false
        val shapedHistory = history.mapIndexed { index, message ->
            val shaped = compactHistoryMessage(
                message = message,
                tier = tier,
                capText = index < oldEnd,
                onChanged = { changed = true },
            )
            if (shaped !== message) changed = true
            shaped
        }
        if (!changed) return messages
        return shapedHistory + messages.subList(lastUserIndex, messages.size)
    }

    private fun recentVerbatimMessages(tier: ArixContextTier): Int = when (tier) {
        ArixContextTier.Minimal -> MinimalVerbatimMessages
        ArixContextTier.Standard -> StandardVerbatimMessages
        ArixContextTier.Deep -> DeepVerbatimMessages
    }

    private fun compactHistoryMessage(
        message: LlmMessage,
        tier: ArixContextTier,
        capText: Boolean,
        onChanged: () -> Unit = {},
    ): LlmMessage {
        val textCap = oldTextCap(tier)
        val toolCap = oldToolResultCap(tier)
        val keepImages = tier == ArixContextTier.Deep
        var changed = false

        if (message.role == "toolResult") {
            val parts = message.contentParts.map { part ->
                if (part is LlmTextPart) {
                    val compacted = compactHeadTail(part.text, toolCap)
                    if (compacted !== part.text) changed = true
                    LlmTextPart(compacted)
                } else {
                    part
                }
            }
            if (!changed) return message
            onChanged()
            return message.copy(contentParts = parts)
        }

        val parts = message.contentParts.map { part ->
            when (part) {
                is LlmTextPart -> {
                    if (capText) {
                        val compacted = compactHeadTail(part.text, textCap)
                        if (compacted !== part.text) changed = true
                        LlmTextPart(compacted)
                    } else {
                        part
                    }
                }
                is LlmImagePart -> {
                    changed = true
                    if (keepImages) {
                        part
                    } else {
                        LlmTextPart("[image attachment omitted from compacted history]")
                    }
                }
            }
        }
        val payload = message.providerPayload?.let { payload ->
            val piAssistant = payload.optJSONObject("piAssistantMessage")
            if (piAssistant != null) {
                val content = piAssistant.opt("content")
                if (content is JSONArray) {
                    val compactedContent = JSONArray()
                    var payloadChanged = false
                    for (index in 0 until content.length()) {
                        val item = content.optJSONObject(index) ?: continue
                        when (item.optString("type")) {
                            "text" -> {
                                val text = item.optString("text")
                                val compacted = if (capText) compactHeadTail(text, textCap) else text
                                if (compacted !== text) payloadChanged = true
                                compactedContent.put(item.put("text", compacted))
                            }
                            "toolCall" -> {
                                val arguments = item.optJSONObject("arguments")
                                if (arguments != null) {
                                    val compactedArguments = compactLongStringValues(
                                        arguments,
                                        toolCap,
                                    )
                                    if (compactedArguments !== arguments) payloadChanged = true
                                    compactedContent.put(item.put("arguments", compactedArguments))
                                } else {
                                    compactedContent.put(item)
                                }
                            }
                            else -> compactedContent.put(item)
                        }
                    }
                    if (payloadChanged) {
                        changed = true
                        JSONObject(payload.toString()).apply {
                            put("piAssistantMessage", JSONObject(piAssistant.toString()).apply {
                                put("content", compactedContent)
                            })
                        }
                    } else {
                        payload
                    }
                } else {
                    payload
                }
            } else {
                payload
            }
        }
        if (!changed && payload === message.providerPayload) return message
        onChanged()
        return message.copy(contentParts = parts, providerPayload = payload)
    }

    private fun compactLongStringValues(
        arguments: JSONObject,
        cap: Int,
    ): JSONObject {
        var changed = false
        val result = JSONObject()
        for (key in arguments.keys()) {
            val value = arguments.opt(key)
            when (value) {
                is String -> {
                    val compacted = compactHeadTail(value, cap)
                    if (compacted !== value) changed = true
                    result.put(key, compacted)
                }
                is JSONObject -> {
                    val nested = compactLongStringValues(value, cap)
                    if (nested !== value) changed = true
                    result.put(key, nested)
                }
                is JSONArray -> {
                    val nested = compactLongStringArrayValues(value, cap)
                    if (nested !== value) changed = true
                    result.put(key, nested)
                }
                else -> result.put(key, value)
            }
        }
        return if (changed) result else arguments
    }

    private fun compactLongStringArrayValues(
        values: JSONArray,
        cap: Int,
    ): JSONArray {
        var changed = false
        val result = JSONArray()
        for (index in 0 until values.length()) {
            val value = values.opt(index)
            when (value) {
                is String -> {
                    val compacted = compactHeadTail(value, cap)
                    if (compacted !== value) changed = true
                    result.put(compacted)
                }
                is JSONObject -> {
                    val nested = compactLongStringValues(value, cap)
                    if (nested !== value) changed = true
                    result.put(nested)
                }
                is JSONArray -> {
                    val nested = compactLongStringArrayValues(value, cap)
                    if (nested !== value) changed = true
                    result.put(nested)
                }
                else -> result.put(value)
            }
        }
        return if (changed) result else values
    }

    fun compactHeadTail(text: String, cap: Int): String {
        if (cap <= 0 || text.length <= cap) return text
        val head = (cap * HeadFraction).toInt().coerceAtLeast(1)
        val tail = (cap - head).coerceAtLeast(1)
        val omitted = text.length - head - tail
        return "${text.take(head)}\n[… $omitted chars compacted — re-read the source if needed …]\n${text.takeLast(tail)}"
    }

    private fun oldTextCap(tier: ArixContextTier): Int = when (tier) {
        ArixContextTier.Minimal -> MinimalOldTextCap
        ArixContextTier.Standard -> StandardOldTextCap
        ArixContextTier.Deep -> DeepOldTextCap
    }

    private fun oldToolResultCap(tier: ArixContextTier): Int = when (tier) {
        ArixContextTier.Minimal -> MinimalOldToolResultCap
        ArixContextTier.Standard -> StandardOldToolResultCap
        ArixContextTier.Deep -> DeepOldToolResultCap
    }

    val MinimalTierHostToolNames: Set<String> = setOf(
        "media_search",
        "web_search",
        "fetch_url",
    )

    fun hostToolNamesFor(
        tier: ArixContextTier,
    ): Set<String>? = when (tier) {
        ArixContextTier.Minimal -> MinimalTierHostToolNames
        ArixContextTier.Standard -> null
        ArixContextTier.Deep -> null
    }

    private val BrowserIntentMarkers = listOf(
        "browser", "web page", "webpage", "website", "web site", "site", "url",
        "click", "tap the", "press the button", "scroll", "navigate", "open the page",
        "login page", "log in", "sign in", "sign up", "form", "checkout", "cart",
        "post to", "publish", "tweet", "instagram", "facebook", "facebook", "inspect element",
        "screenshot the page", "fill in", "type into",
    )

    private val TerminalIntentMarkers = listOf(
        "terminal", "command", "bash", "shell", "console", "install", "uninstall",
        "pip", "npm", "node ", "python", "script", "build", "compile", "make",
        "git", "clone", "repo", "directory", "folder", "path", "file", "files",
        "code", "debug", "log", "logs", "package", "environment", "compile",
        "run this", "execute", "stdout", "stderr", "chmod", "chown",
        "project", "workspace", "termux",
    )

    private val MediaIntentMarkers = listOf(
        "play", "watch", "movie", "movies", "film", "song", "songs", "music",
        "video", "videos", "listen", "trailer", "stream", "anime", "series",
        "episode", "podcast", "radio", "latest movies", "tube",
    )

    private val WebResearchIntentMarkers = listOf(
        "search", "find information", "research", "look up", "lookup", "news",
        "what is the latest", "current events", "compare", "price of", "reviews of",
        "who is", "when did", "statistics", "source", "sources", "cite",
    )

    private val AutomationIntentMarkers = listOf(
        "mission", "autonomous", "automate", "automation", "schedule", "scheduled",
        "every day", "every day", "daily", "weekly", "every hour", "recurring",
        "background task", "multi-step", "swarm", "sub-agent", "subagent",
    )

    private val PaymentIntentMarkers = listOf(
        "pay", "payment", "upi", "send money", "transfer", "bill", "recharge",
        "subscription", "purchase", "buy me", "order",
    )

    private val FileShareIntentMarkers = listOf(
        "share", "upload", "send this file", "send the file", "get a link",
        "direct link", "download link", "file link", "host this", "filebin",
        "file transfer", "shareable",
    )

    fun useCompactPrompt(tier: ArixContextTier): Boolean = tier == ArixContextTier.Minimal

    private const val HeadFraction = 0.6

    private const val MaxLocalMinimalChars = 220

    private val FileExtensionMarker = Regex(
        """\b\w+\.(kt|kts|java|py|js|mjs|ts|tsx|jsx|xml|json|md|txt|csv|yml|yaml|sh|bash|gradle|html|css|js|sql|c|cpp|h|go|rs|rb|php|swift)\b""",
    )

    private val PathLikeMarker = Regex("""(^|\s)(/|~/|\./)[\w./-]+""")

    private val UrlLikeMarker = Regex(
        """(https?://\S+|(^|\s)(www\.[^\s]+|[a-z0-9-]+\.(com|org|net|io|dev|ai|app|in|co|xyz|me|tv|gg|gov|edu)\b))""",
    )

    private val MemoryReferenceMarkers = listOf(
        "remember", "forget", "recall", "memory", "memorize", "my name is",
        "call me", "i like", "i am from", "i live", "my favorite", "my favourite",
        "remind", "reminder", "alarm", "wake me", "notify me",
    )

    private val ConversationReferenceMarkers = listOf(
        "again", "earlier", "before", "last time", "previous", "you said",
        "you told", "you did", "continue", "keep going", "what did you",
        "the one you", "that thing", "same as",
    )

    private const val LongRequestChars = 1_200

    private const val MinimalTrimFraction = 0.35
    private const val StandardTrimFraction = 0.55
    private const val DeepTrimFraction = 0.80

    private const val MinimalCompactThreshold = 0.60
    private const val StandardCompactThreshold = 0.75
    private const val DeepCompactThreshold = 0.85

    private const val MinimalVerbatimMessages = 4
    private const val StandardVerbatimMessages = 10
    private const val DeepVerbatimMessages = 20

    private const val MinimalOldTextCap = 400
    private const val StandardOldTextCap = 1_000
    private const val DeepOldTextCap = 2_400

    private const val MinimalOldToolResultCap = 240
    private const val StandardOldToolResultCap = 600
    private const val DeepOldToolResultCap = 1_500
}
