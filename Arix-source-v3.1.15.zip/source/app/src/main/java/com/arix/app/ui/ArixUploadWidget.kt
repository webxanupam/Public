package com.arix.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.CloudUpload
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.arix.app.data.ArixFileShareClient
import com.arix.app.data.ArixUploadProgressBus
import com.arix.app.ui.theme.ArixOnSurface
import com.arix.app.ui.theme.ArixOnSurfaceVariant
import com.arix.app.ui.theme.ArixOutline
import com.arix.app.ui.theme.ArixPrimary
import com.arix.app.ui.theme.ArixSurface
import com.arix.app.ui.theme.ArixSurfaceHigh
import com.arix.app.ui.theme.ArixTertiary
import kotlinx.coroutines.delay

@Composable
fun ArixUploadProgressWidget(
    modifier: Modifier = Modifier,
) {
    val progress by ArixUploadProgressBus.progress.collectAsState()
    val current = progress

    var dismissedId by remember { mutableStateOf<Long?>(null) }
    LaunchedEffect(current?.id, current?.done, current?.failed) {
        if (current != null && (current.done || current.failed)) {
            delay(ArixUploadProgressBus.TerminalHoldMillis)
            dismissedId = current.id
        }
    }

    val visible = current != null && current.id != dismissedId

    val percentFloat = if (current != null && current.totalBytes > 0L) {
        (current.bytesWritten.toFloat() / current.totalBytes).coerceIn(0f, 1f)
    } else {
        0f
    }
    val animatedPercent by animateFloatAsState(
        targetValue = percentFloat,
        animationSpec = tween(durationMillis = 260),
        label = "arix_upload_percent",
    )

    AnimatedVisibility(
        visible = visible,
        enter = slideInVertically(animationSpec = tween(240)) { it / 2 } + fadeIn(tween(240)),
        exit = slideOutVertically(animationSpec = tween(200)) { it / 2 } + fadeOut(tween(200)),
        modifier = modifier,
    ) {
        val state = current ?: return@AnimatedVisibility
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(ArixSurfaceHigh)
                .border(1.dp, ArixOutline, RoundedCornerShape(18.dp)),
            verticalArrangement = Arrangement.spacedBy(0.dp),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp)
                    .background(
                        when {
                            state.failed -> Brush.horizontalGradient(
                                listOf(Color(0xFFE5757A), Color(0xFFE5757A)),
                            )
                            state.done -> Brush.horizontalGradient(
                                listOf(Color(0xFF34D399), Color(0xFF34D399)),
                            )
                            else -> Brush.horizontalGradient(listOf(ArixPrimary, ArixTertiary))
                        },
                    ),
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            when {
                                state.failed -> Color(0xFFE5757A).copy(alpha = 0.14f)
                                state.done -> Color(0xFF34D399).copy(alpha = 0.14f)
                                else -> ArixPrimary.copy(alpha = 0.14f)
                            },
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = when {
                            state.failed -> Icons.Rounded.ErrorOutline
                            state.done -> Icons.Rounded.CheckCircle
                            else -> Icons.Rounded.CloudUpload
                        },
                        contentDescription = null,
                        tint = when {
                            state.failed -> Color(0xFFE5757A)
                            state.done -> Color(0xFF34D399)
                            else -> ArixPrimary
                        },
                        modifier = Modifier.size(20.dp),
                    )
                }
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Text(
                        text = when {
                            state.failed -> "Upload failed"
                            state.done -> "Link ready — ${state.serverLabel}"
                            else -> "Uploading to ${state.serverLabel}…"
                        },
                        style = MaterialTheme.typography.labelLarge,
                        color = ArixOnSurface,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = state.fileName,
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    LinearProgressIndicator(
                        progress = { if (state.done) 1f else animatedPercent },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(5.dp)
                            .clip(RoundedCornerShape(999.dp)),
                        color = when {
                            state.failed -> Color(0xFFE5757A)
                            state.done -> Color(0xFF34D399)
                            else -> ArixPrimary
                        },
                        trackColor = ArixSurface,
                    )
                    Text(
                        text = buildString {
                            if (state.totalBytes > 0L) {
                                append("${state.percent}%")
                                append("  ·  ")
                                append(ArixFileShareClient.formatBytes(state.bytesWritten))
                                append(" / ")
                                append(ArixFileShareClient.formatBytes(state.totalBytes))
                                if (state.bytesPerSecond > 0L && !state.done) {
                                    append("  ·  ")
                                    append(ArixFileShareClient.formatBytes(state.bytesPerSecond))
                                    append("/s")
                                }
                            } else if (state.errorMessage != null) {
                                append(state.errorMessage)
                            }
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = ArixOnSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                if (!state.done && !state.failed && state.totalBytes > 0L) {
                    Text(
                        text = "${state.percent}%",
                        style = MaterialTheme.typography.titleMedium,
                        color = ArixPrimary,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
    }
}
