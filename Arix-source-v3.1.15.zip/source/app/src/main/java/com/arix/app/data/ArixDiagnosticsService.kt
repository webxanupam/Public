package com.arix.app.data

import com.arix.app.runtime.LocalRuntimeSetupState
import org.json.JSONArray
import org.json.JSONObject

class ArixDiagnosticsService(
    private val versionName: String,
    private val bridgeProcessAlive: () -> Boolean = { false },
    private val termuxSetupState: (suspend () -> LocalRuntimeSetupState?)? = null,
    private val memoryStats: () -> Map<String, Int>? = { null },
    private val memoryStoreHealthy: () -> Boolean = { true },
    private val providerConfigured: () -> Boolean = { false },
    private val scheduledTaskCount: (suspend () -> Int)? = null,
) {

    suspend fun healthReport(): JSONObject {
        val components = JSONArray()
        val now = System.currentTimeMillis()

        val hasProvider = runCatching { providerConfigured() }.getOrDefault(false)
        components.put(
            component(
                name = "ai_provider",
                ok = hasProvider,
                state = if (hasProvider) "configured" else "not_configured",
                detail = if (hasProvider) {
                    "An LLM provider is configured; model requests can be made."
                } else {
                    "No LLM provider is configured yet — chat cannot run. Configure one under Settings → Providers."
                },
            )
        )

        val bridgeAlive = runCatching { bridgeProcessAlive() }.getOrDefault(false)
        components.put(
            component(
                name = "pi_bridge",
ok = true,
                state = if (bridgeAlive) "running" else "not_running",
                detail = if (bridgeAlive) {
                    "The Arix bridge process is alive."
                } else {
                    "The Arix bridge is not started (normal before the first turn / after idle). " +
                        "It starts on the next agent turn; if that start fails, the turn error carries the failing stage."
                },
            )
        )

        val termux = runCatching { termuxSetupState?.invoke() }.getOrNull()
        components.put(
            component(
                name = "termux_runtime",
                ok = termux?.isReady ?: false,
                state = termux?.issue?.name?.lowercase() ?: "unknown",
                detail = termux?.detail?.takeIf { it.isNotBlank() }
                    ?: if (termux == null) "Runtime inspect unavailable in this build." else "",
            )
        )

        val memory = runCatching { memoryStats() }.getOrNull()
        val memoryHealthy = runCatching { memoryStoreHealthy() }.getOrDefault(true)
        val memoryTotal = memory?.values?.sum() ?: 0
        components.put(
            component(
                name = "memory",
                ok = memoryHealthy,
                state = if (memoryHealthy) "healthy" else "unavailable",
                detail = when {
                    !memoryHealthy -> "The memory store is not readable/writable; memory features degrade gracefully."
                    memoryTotal == 0 -> "Memory store is empty (healthy)."
                    else -> "Memory store is healthy: $memoryTotal entries " +
                        "(${memory!!.entries.joinToString { "${it.key}=${it.value}" }})."
                },
            )
        )

        val taskCount = runCatching { scheduledTaskCount?.invoke() }.getOrNull() ?: 0
        components.put(
            component(
                name = "scheduler",
                ok = true,
                state = if (taskCount > 0) "armed" else "idle",
                detail = if (taskCount > 0) {
                    "$taskCount scheduled task(s) registered."
                } else {
                    "No scheduled tasks are registered (background workflows are optional)."
                },
            )
        )

        val notOk = mutableListOf<String>()
        for (index in 0 until components.length()) {
            val entry = components.optJSONObject(index) ?: continue
            if (!entry.optBoolean("ok")) notOk.add(entry.optString("name"))
        }
        return JSONObject()
            .put("ok", notOk.isEmpty())
            .put("version", versionName)
            .put("generated_at", now)
            .put("components", components)
            .put(
                "summary",
                if (notOk.isEmpty()) {
                    "All subsystems report healthy."
                } else {
                    "Subsystems needing attention: ${notOk.joinToString(", ")}."
                },
            )
            .put(
                "next_action",
                if (notOk.isEmpty()) "" else {
                    "Address the components listed in 'summary'; each entry's 'detail' carries the concrete next step."
                },
            )
    }

    suspend fun execute(argumentsJson: String): JSONObject {
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
        val action = arguments?.optString("action")?.trim()?.lowercase() ?: "health"
        if (action.isNotEmpty() && action !in setOf("health", "status", "report")) {
            return ArixToolContract.failure(
                ArixToolContract.INVALID_ARGUMENTS,
                "Unknown action '$action'. Use 'health' (default).",
            )
        }
        val report = healthReport()
        return ArixToolContract.success(
            report.put("action", "health").put("stdout", report.optString("summary")),
            verified = true,
        )
    }

    private fun component(name: String, ok: Boolean, state: String, detail: String): JSONObject =
        JSONObject()
            .put("name", name)
            .put("ok", ok)
            .put("state", state)
            .put("detail", detail.take(MaxDetailChars))

    private companion object {
        const val MaxDetailChars = 400
    }
}
