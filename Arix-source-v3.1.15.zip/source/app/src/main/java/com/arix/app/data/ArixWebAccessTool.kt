package com.arix.app.data

import android.content.Context
import com.arix.app.browser.ArixBrowserResearch
import org.json.JSONArray
import org.json.JSONObject

object ArixWebAccessTool {

    const val ToolNameSearch = "web_search"
    const val ToolNameFetch = "fetch_url"

    suspend fun executeSearch(
        context: Context,
        settings: AppSettings,
        argumentsJson: String,
        sessionId: String?,
        memoryManager: ArixMemoryManager?,
        onProgress: (suspend (String) -> Unit)?,
    ): JSONObject {
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            ?: return failure(ToolNameSearch, "INVALID_ARGUMENTS", "Arguments were not valid JSON.")
        val query = arguments.optString("query").trim()
        if (query.isEmpty()) {
            return failure(ToolNameSearch, "INVALID_ARGUMENTS", "query is required.")
        }
        val topicId = arguments.optString("topic_id").trim().takeIf { it.isNotBlank() }
        val engine = normalizeWebSearchEngine(
            arguments.optString("engine").ifBlank { settings.webSearchEngine },
        )
        val maxResults = arguments.optInt("num_results", 6).coerceIn(1, 10)
        val fetchContent = arguments.optBoolean("fetch_content", true)
        val deep = arguments.optBoolean("deep", false)

        return try {
            val result = ArixBrowserResearch.search(
                context = context,
                query = query,
                engine = engine,
                sessionId = sessionId,
                maxResults = maxResults,
                fetchContent = fetchContent,
                topicId = topicId,
                deep = deep,
                onProgress = onProgress,
            )
            if (result.optBoolean("ok", false)) {
                maybeSaveResearchMemo(
                    memoryManager = memoryManager,
                    settings = settings,
                    topic = topicId ?: query.take(60),
                    query = query,
                    result = result,
                )
            }
            result
        } catch (error: com.arix.app.browser.ArixBrowserResearch.BrowserResearchFailure) {
            failure(ToolNameSearch, error.code, error.message)
        } catch (error: Throwable) {
            failure(ToolNameSearch, "SEARCH_FAILED", error.message ?: "The web search failed.")
        }
    }

    suspend fun executeFetch(
        context: Context,
        settings: AppSettings,
        argumentsJson: String,
        sessionId: String?,
    ): JSONObject {
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            ?: return failure(ToolNameFetch, "INVALID_ARGUMENTS", "Arguments were not valid JSON.")
        val url = arguments.optString("url").trim()
        if (url.isEmpty()) {
            return failure(ToolNameFetch, "INVALID_ARGUMENTS", "url is required.")
        }
        val topicId = arguments.optString("topic_id").trim().takeIf { it.isNotBlank() }
        val offset = arguments.optInt("offset", 0).coerceAtLeast(0)
        val maxChars = arguments.optInt("max_chars", 8_000).coerceIn(800, 12_000)
        return try {
            ArixBrowserResearch.fetchUrl(
                context = context,
                url = url,
                topicId = topicId,
                offset = offset,
                maxChars = maxChars,
            )
        } catch (error: com.arix.app.browser.ArixBrowserResearch.BrowserResearchFailure) {
            failure(ToolNameFetch, error.code, error.message)
        } catch (error: Throwable) {
            failure(ToolNameFetch, "FETCH_FAILED", error.message ?: "The page fetch failed.")
        }
    }

    private suspend fun maybeSaveResearchMemo(
        memoryManager: ArixMemoryManager?,
        settings: AppSettings,
        topic: String,
        query: String,
        result: JSONObject,
    ) {
        if (!settings.saveResearchToMemory) return
        val memory = memoryManager ?: return
        val cited = result.optJSONArray("cited_pages") ?: JSONArray()
        if (cited.length() == 0) return
        val failures = mutableListOf<String>()
        runCatching {
            val memo = buildString {
                append("Research: ").append(topic).append('\n')
                append("Query: ").append(query).append('\n')
                append("Engine: ").append(result.optString("engine"))
            }
            rememberResearch(memory, memo.toString(), topic)
        }.onFailure { failures += "topic: ${it.message}" }
        for (index in 0 until cited.length()) {
            val page = cited.optJSONObject(index) ?: continue
            runCatching {
                val sourceMemo = buildString {
                    append("Source (")
                    append(topic)
                    append("): ")
                    append(page.optString("url"))
                    append(" — ")
                    append(page.optString("title"))
                    append(" [p").append(index + 1).append(']')
                }
                rememberResearch(memory, sourceMemo.toString(), topic)
            }.onFailure { failures += "source[$index]: ${it.message}" }
        }
        if (failures.isNotEmpty()) {
            result.put(
                "memo_save_failures",
                failures.take(3).map { it.take(160) },
            )
        }
    }

    private suspend fun rememberResearch(
        memory: ArixMemoryManager,
        content: String,
        topic: String,
    ) {
        memory.execute(
            JSONObject()
                .put("action", "remember")
                .put("tier", "research")
                .put(
                    "tags",
                    JSONArray().put("research").put("web").put(topic.take(40)),
                )
                .put("content", content.take(ArixMemoryManager.MaxEntryContentChars))
                .toString(),
            null,
        )
    }

    fun searchToolDefinition(): JSONObject = JSONObject().apply {
        put("name", ToolNameSearch)
        put(
            "description",
            "Search the web USING THE REAL BROWSER (no third-party search API): Arix " +
                "navigates the search engine's results page, harvests the organic results, " +
                "then reads the top sources in parallel and returns their content as " +
                "paragraph-level citable passages. Call this for ANY question needing fresh " +
                "web information. Results carry [pN] passage markers with source URLs — cite " +
                "them in your answer as [pN] (url). fetch_content=true (default) also reads " +
                "the top 3 sources; deep=true raises the search budget for explicit " +
                "deep-research tasks. topic_id groups one research thread across calls " +
                "(pages already read are reused, never re-fetched).",
        )
        put("parameters", JSONObject().apply {
            put("type", "object")
            put("properties", JSONObject().apply {
                put("query", JSONObject().put("type", "string").put(
                    "description", "The search query, humanized (no year-stuffing, keep quoted subjects).",
                ))
                put("num_results", JSONObject().put("type", "integer").put(
                    "description", "How many organic results to return (1-10, default 6).",
                ))
                put("fetch_content", JSONObject().put("type", "boolean").put(
                    "description", "Also read the top sources in parallel for citable passages (default true).",
                ))
                put("topic_id", JSONObject().put("type", "string").put(
                    "description", "Working-set id grouping one research thread (reuse across calls).",
                ))
                put("deep", JSONObject().put("type", "boolean").put(
                    "description", "true for explicit deep-research turns (raises the search budget).",
                ))
                put("engine", JSONObject().put("type", "string").put(
                    "description", "Optional engine override: duckduckgo | google | bing (default from settings; DuckDuckGo).",
                ))
            })
            put("required", JSONArray().put("query"))
            put("additionalProperties", false)
        })
        put("execution_mode", "sequential")
    }

    fun fetchToolDefinition(): JSONObject = JSONObject().apply {
        put("name", ToolNameFetch)
        put(
            "description",
            "Fetch ONE url through the real browser (JavaScript pages render fully) and " +
                "return the readable content as ordered [pN] citable passages with the " +
                "source URL and title. Use for reading a specific page the user linked, a " +
                "search result, documentation, an article. Payment/captcha/OTP/credential " +
                "pages return input_required + user_takeover — tell the user to finish " +
                "those in the Browser tab. Use offset/max_chars for pagination on long " +
                "pages (the result's passages list shows every available [pN]).",
        )
        put("parameters", JSONObject().apply {
            put("type", "object")
            put("properties", JSONObject().apply {
                put("url", JSONObject().put("type", "string").put(
                    "description", "The full http(s) URL to read.",
                ))
                put("topic_id", JSONObject().put("type", "string").put(
                    "description", "Working-set id so re-reads reuse the cached page.",
                ))
                put("offset", JSONObject().put("type", "integer").put(
                    "description", "Character offset for pagination (default 0).",
                ))
                put("max_chars", JSONObject().put("type", "integer").put(
                    "description", "Max characters to return (800-12000, default 8000).",
                ))
            })
            put("required", JSONArray().put("url"))
            put("additionalProperties", false)
        })
        put("execution_mode", "sequential")
    }

    private fun failure(tool: String, code: String, message: String): JSONObject = JSONObject()
        .put("ok", false)
        .put("tool", tool)
        .put("code", code)
        .put("message", message)
}
