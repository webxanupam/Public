package com.arix.app.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import android.os.SystemClock
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.arix.app.ui.theme.ArixError
import com.arix.app.ui.theme.ArixOnSurface
import com.arix.app.ui.theme.ArixOnSurfaceVariant
import com.arix.app.ui.theme.ArixOutlineSoft
import com.arix.app.ui.theme.ArixPrimary
import com.arix.app.ui.theme.ArixSurface
import com.arix.app.ui.theme.ArixSurfaceVariant
import kotlinx.coroutines.delay
import org.json.JSONObject

internal const val SubAgentInvocationPrefix = "subagent-"

internal fun isSubAgentInvocation(invocation: ChatToolInvocation): Boolean =
    invocation.id.startsWith(SubAgentInvocationPrefix)

internal fun workActivityOf(tool: String): String {
    val t = tool.lowercase()
    return when {
        t.isBlank() -> "Thinking"
        "search" in t -> "Searching"
        "fetch" in t || "browse" in t || "web" in t || "url" in t -> "Reading"
        "bash" in t || "shell" in t || "term" in t || "run" in t || "exec" in t -> "Running"
        "write" in t || "edit" in t || "create" in t || "patch" in t -> "Writing"
        "read" in t || "grep" in t || "glob" in t || "list" in t -> "Reading"
        "image" in t || "media" in t -> "Looking at"
        else -> "Working with"
    }
}

private val WorkTargetKeys = listOf(
    "query", "q", "url", "uri", "path", "file_path", "filepath", "file", "command", "cmd", "pattern",
    "prompt", "name", "text", "task",
)

internal fun workTargetOf(argumentsJson: String): String {
    val json = runCatching { JSONObject(argumentsJson) }.getOrNull() ?: return ""
    for (key in WorkTargetKeys) {
        val value = json.optString(key).trim()
        if (value.isNotEmpty()) {
            val oneLine = value.lineSequence().firstOrNull { it.isNotBlank() }.orEmpty().trim()
                .removePrefix("https://").removePrefix("http://")
            return if (oneLine.length <= 64) oneLine else oneLine.take(63).trimEnd() + "…"
        }
    }
    return ""
}

internal fun workLineOf(toolName: String, argumentsJson: String): String {
    val tool = toolName.substringAfter(" · ", toolName).trim()
    val target = workTargetOf(argumentsJson)
    val verb = workActivityOf(tool)
    return if (target.isBlank()) "$verb $tool".trim() else "$verb $tool · $target"
}

@Composable
internal fun ArixLiveWorkLines(invocations: List<ChatToolInvocation>) {
    val running = invocations.filter { it.isRunning && !isSubAgentInvocation(it) }.takeLast(3)
    val subRunning = invocations.count { it.isRunning && isSubAgentInvocation(it) }
    if (running.isEmpty() && subRunning == 0) return
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        running.forEach { invocation ->
            key(invocation.id) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PulseDot(active = true, color = ArixPrimary)
                    ShimmerStatusText(
                        text = workLineOf(invocation.toolName, invocation.argumentsJson),
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 1,
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }
        if (subRunning > 0) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PulseDot(active = true, color = ArixPrimary)
                ShimmerStatusText(
                    text = if (subRunning == 1) "1 sub-agent working" else "$subRunning sub-agents working",
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 1,
                )
            }
        }
    }
}

private data class AgentRowModel(
    val id: String,
    val name: String,
    val state: String,
    val currentTool: String,
    val detail: String,
    val target: String,
    val toolCalls: Int,
    val running: Boolean,
    val startedAtUptime: Long,
    val completedAtUptime: Long?,
)

private fun agentRow(invocation: ChatToolInvocation): AgentRowModel {
    val name = invocation.toolName.substringBefore(" · ").trim().ifBlank { "Agent" }
    val tool = invocation.toolName.substringAfter(" · ", "").trim()
    val json = runCatching { JSONObject(invocation.outputJson) }.getOrNull()
    val state = json?.optString("state").orEmpty().ifBlank { if (invocation.isRunning) "working" else "completed" }
    return AgentRowModel(
        id = invocation.id,
        name = json?.optString("agent")?.takeIf { it.isNotBlank() } ?: name,
        state = state,
        currentTool = tool,
        detail = json?.optString("detail").orEmpty(),
        target = json?.optString("target").orEmpty().ifBlank { workTargetOf(invocation.argumentsJson) },
        toolCalls = json?.optInt("tool_calls", 0) ?: 0,
        running = invocation.isRunning,
        startedAtUptime = invocation.startedAtUptimeMillis,
        completedAtUptime = invocation.completedAtUptimeMillis,
    )
}

private val AgentDone = Color(0xFF3FB950)
private val AgentPalette = listOf(
    Color(0xFF8B7CF6), Color(0xFF38BDF8), Color(0xFFF59E0B), Color(0xFFEC4899),
    Color(0xFF10B981), Color(0xFFF97316), Color(0xFF6366F1), Color(0xFF14B8A6),
)

private fun agentColor(name: String): Color =
    AgentPalette[(name.lowercase().hashCode() and 0x7fffffff) % AgentPalette.size]

private fun stateLabel(row: AgentRowModel): String = when (row.state) {
    "starting" -> "Starting"
    "working" -> if (row.currentTool.isNotBlank()) {
        val where = if (row.target.isNotBlank()) " · ${row.target}" else ""
        "${workActivityOf(row.currentTool)} ${row.currentTool}$where"
    } else "Working"
    "completed" -> "Done"
    "failed" -> "Failed"
    "cancelled" -> "Stopped"
    "budget_exceeded" -> "Stopped - tool budget reached"
    else -> row.state.replaceFirstChar { it.uppercase() }
}

private fun formatElapsed(millis: Long): String {
    val seconds = (millis / 1000L).coerceAtLeast(0L)
    return if (seconds < 60L) "${seconds}s" else "${seconds / 60L}m ${(seconds % 60L).toString().padStart(2, '0')}s"
}

@Composable
private fun PulseRing(color: Color) {
    val transition = rememberInfiniteTransition(label = "agent_pulse")
    val pulse by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1100, easing = LinearEasing), RepeatMode.Restart),
        label = "agent_pulse_value",
    )
    Box(
        modifier = Modifier
            .size(14.dp)
            .graphicsLayer {
                val s = 0.45f + pulse * 1.0f
                scaleX = s
                scaleY = s
                alpha = (1f - pulse) * 0.55f
            }
            .clip(CircleShape)
            .background(color),
    )
}

@Composable
private fun PulseDot(active: Boolean, color: Color) {
    Box(modifier = Modifier.size(14.dp), contentAlignment = Alignment.Center) {
        if (active) PulseRing(color)
        Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(color))
    }
}

@Composable
private fun SpinRing(color: Color, modifier: Modifier) {
    val transition = rememberInfiniteTransition(label = "agent_spin")
    val angle by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(1300, easing = LinearEasing), RepeatMode.Restart),
        label = "agent_spin_angle",
    )
    Canvas(modifier = modifier) {
        val stroke = 2.2.dp.toPx()
        drawArc(
            color = color,
            startAngle = angle,
            sweepAngle = 110f,
            useCenter = false,
            topLeft = Offset(stroke / 2f, stroke / 2f),
            size = Size(size.width - stroke, size.height - stroke),
            style = Stroke(width = stroke, cap = StrokeCap.Round),
        )
    }
}

@Composable
private fun SweepBar(color: Color, modifier: Modifier) {
    val transition = rememberInfiniteTransition(label = "agent_sweep")
    val x by transition.animateFloat(
        initialValue = -0.55f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(tween(1150, easing = LinearEasing), RepeatMode.Restart),
        label = "agent_sweep_x",
    )
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(2.dp))
            .background(color.copy(alpha = 0.22f))
            .drawBehind {
                drawRect(color = color, topLeft = Offset(x * size.width, 0f), size = Size(size.width * 0.5f, size.height))
            },
    )
}

@Composable
internal fun ArixAgentPanel(
    invocations: List<ChatToolInvocation>,
    topPadding: Dp = 6.dp,
) {
    if (invocations.isEmpty()) return
    val rows = invocations.map(::agentRow)
    val running = rows.count { it.running }
    val failed = rows.count { !it.running && it.state in setOf("failed", "cancelled", "budget_exceeded") }
    val done = rows.size - running - failed
    var collapsed by rememberSaveable(rows.first().id) { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = topPadding)
            .animateContentSize(animationSpec = tween(180))
            .clip(RoundedCornerShape(16.dp))
            .background(ArixSurface)
            .border(1.dp, ArixOutlineSoft, RoundedCornerShape(16.dp)),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                ) { collapsed = !collapsed }
                .padding(horizontal = 14.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            PulseDot(
                active = running > 0,
                color = if (running > 0) ArixPrimary else if (failed > 0 && done == 0) ArixError else AgentDone,
            )
            Text(
                text = if (rows.size == 1) "Agent" else "Agents",
                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                color = ArixOnSurface,
            )
            Text(
                text = buildList {
                    if (running > 0) add("$running running")
                    if (done > 0) add("$done done")
                    if (failed > 0) add("$failed stopped")
                }.joinToString(" - "),
                style = MaterialTheme.typography.labelMedium,
                color = ArixOnSurfaceVariant,
                modifier = Modifier.weight(1f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = if (collapsed) "Show" else "Hide",
                style = MaterialTheme.typography.labelSmall,
                color = ArixOnSurfaceVariant,
            )
        }
        AnimatedVisibility(
            visible = !collapsed,
            enter = expandVertically(tween(200)) + fadeIn(tween(200)),
            exit = shrinkVertically(tween(160)) + fadeOut(tween(120)),
        ) {
            Column {
                rows.forEach { row ->
                    key(row.id) {
                        val shown = remember { MutableTransitionState(false).apply { targetState = true } }
                        AnimatedVisibility(
                            visibleState = shown,
                            enter = expandVertically(tween(220)) + fadeIn(tween(220)),
                        ) {
                            Column {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(1.dp)
                                        .background(ArixOutlineSoft.copy(alpha = 0.6f)),
                                )
                                AgentRow(row = row)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AgentRow(row: AgentRowModel) {
    var expanded by rememberSaveable(row.id) { mutableStateOf(false) }
    val accent = agentColor(row.name)
    val statusColor = when {
        row.running -> ArixPrimary
        row.state == "completed" -> AgentDone
        row.state == "cancelled" -> ArixOnSurfaceVariant
        else -> ArixError
    }
    val elapsed by produceState(
        initialValue = formatElapsed(
            (row.completedAtUptime ?: SystemClock.uptimeMillis()) - row.startedAtUptime,
        ),
        row.running, row.startedAtUptime, row.completedAtUptime,
    ) {
        while (true) {
            val end = row.completedAtUptime ?: SystemClock.uptimeMillis()
            value = if (row.startedAtUptime > 0L) formatElapsed(end - row.startedAtUptime) else ""
            if (!row.running) break
            delay(1000L)
        }
    }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                enabled = row.detail.isNotBlank() && !row.running,
            ) { expanded = !expanded }
            .padding(horizontal = 14.dp, vertical = 10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                modifier = Modifier.size(30.dp).clip(CircleShape).background(accent.copy(alpha = 0.18f)),
                contentAlignment = Alignment.Center,
            ) {
                if (row.running) SpinRing(color = accent, modifier = Modifier.matchParentSize())
                Text(
                    text = row.name.firstOrNull()?.uppercase() ?: "A",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                    color = accent,
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = row.name,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = ArixOnSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (row.running) {
                    ShimmerStatusText(
                        text = stateLabel(row) + if (row.toolCalls > 0) "  -  ${row.toolCalls} tool calls" else "",
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 1,
                    )
                } else {
                    Text(
                        text = stateLabel(row) + if (row.toolCalls > 0) "  -  ${row.toolCalls} tool calls" else "",
                        style = MaterialTheme.typography.bodySmall,
                        color = statusColor,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = elapsed,
                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                    color = ArixOnSurfaceVariant,
                    maxLines = 1,
                )
                Spacer(Modifier.height(4.dp))
                if (row.running) {
                    SweepBar(color = ArixPrimary, modifier = Modifier.width(34.dp).height(3.dp))
                } else {
                    val barColor by animateColorAsState(statusColor, tween(300), label = "agent_bar_color")
                    Box(
                        modifier = Modifier
                            .width(34.dp)
                            .height(3.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(barColor),
                    )
                }
            }
        }
        AnimatedVisibility(
            visible = expanded && row.detail.isNotBlank(),
            enter = expandVertically(tween(180)) + fadeIn(tween(180)),
            exit = shrinkVertically(tween(140)) + fadeOut(tween(100)),
        ) {
            Column {
                Spacer(Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(ArixSurfaceVariant.copy(alpha = 0.6f))
                        .padding(10.dp),
                ) {
                    Text(
                        text = row.detail,
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurface,
                        maxLines = 16,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
    }
}
