package com.arix.app.runtime

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import java.io.File

object AndroidSafStorageBridge {

    private const val ExternalStorageAuthority = "com.android.externalstorage.documents"
    private const val PrimaryVolumeDocumentId = "primary:"
    private const val PrimaryStorageRoot = "/storage/emulated/0"

    private val restrictedSubtrees = listOf("Android/data", "Android/obb")

    fun isRestrictedAndroidPath(hostFile: File): Boolean {
        val canonical = runCatching { hostFile.canonicalPath }.getOrDefault(hostFile.absolutePath)
        val normalized = canonical.trimEnd('/')
        if (!normalized.startsWith("/storage/emulated/")) return false
        val pathAfterStorage = normalized.removePrefix("/storage/emulated/")
        val relative = pathAfterStorage.substringAfter('/', "")
        for (subtree in restrictedSubtrees) {
            if (relative == subtree || relative.startsWith("$subtree/")) return true
        }
        return false
    }

    fun coveringTreeGrant(
        resolver: ContentResolver,
        hostFile: File,
    ): Pair<Uri, String>? {
        val target = runCatching { hostFile.canonicalPath }.getOrDefault(hostFile.absolutePath)
        if (!target.startsWith(PrimaryStorageRoot)) return null
        val targetRelative = target.removePrefix(PrimaryStorageRoot).trim('/')
        var best: Pair<Uri, String>? = null
        var bestDepth = -1
        for (permission in resolver.persistedUriPermissions) {
            val uri = permission.uri
            if (uri.authority != ExternalStorageAuthority) continue
            if (!permission.isReadPermission) continue
            val documentId = runCatching {
                DocumentsContract.getTreeDocumentId(uri)
            }.getOrNull() ?: continue
            if (!documentId.startsWith(PrimaryVolumeDocumentId, ignoreCase = true)) continue
            val grantRelative = documentId
                .removePrefix(PrimaryVolumeDocumentId)
                .trim('/')
            val covers = grantRelative.isEmpty() ||
                targetRelative == grantRelative ||
                targetRelative.startsWith("$grantRelative/")
            if (covers) {
                val depth = grantRelative.count { it == '/' }
                if (depth > bestDepth) {
                    bestDepth = depth
                    best = uri to targetRelative.removePrefix(grantRelative).trim('/')
                }
            }
        }
        return best
    }

    data class SafEntry(
        val name: String,
        val isDirectory: Boolean,
        val sizeBytes: Long,
        val modifiedAtMillis: Long,
        val documentId: String,
    )

    fun listSafDirectory(
        resolver: ContentResolver,
        treeUri: Uri,
        relative: String,
    ): List<SafEntry>? {
        val rootDocumentId = runCatching { DocumentsContract.getTreeDocumentId(treeUri) }.getOrNull()
            ?: return null
        val targetDocumentId = if (relative.isBlank()) {
            rootDocumentId
        } else {
            rootDocumentId.trimEnd('/') + "/" + relative.trim('/')
        }
        val childrenUri = runCatching {
            DocumentsContract.buildChildDocumentsUriUsingTree(
                treeUri,
                targetDocumentId,
            )
        }.getOrNull() ?: return null
        val entries = runCatching {
            resolver.query(
                childrenUri,
                arrayOf(
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE,
                    DocumentsContract.Document.COLUMN_SIZE,
                    DocumentsContract.Document.COLUMN_LAST_MODIFIED,
                ),
                null,
                null,
                null,
            )?.use { cursor ->
                buildList {
                    while (cursor.moveToNext()) {
                        val documentId = cursor.getString(0) ?: continue
                        val name = cursor.getString(1) ?: continue
                        val mimeType = cursor.getString(2) ?: continue
                        val size = cursor.getLong(3)
                        val modified = cursor.getLong(4)
                        add(
                            SafEntry(
                                name = name,
                                isDirectory = mimeType == DocumentsContract.Document.MIME_TYPE_DIR,
                                sizeBytes = size,
                                modifiedAtMillis = modified,
                                documentId = documentId,
                            ),
                        )
                    }
                }
            }
        }.getOrNull() ?: return null
        return entries
            .sortedWith(compareByDescending<SafEntry> { it.isDirectory }.thenBy { it.name.lowercase() })
    }

    fun openTreeGrantIntent(hostFile: File?): Intent {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_PREFIX_URI_PERMISSION)
        }
        if (hostFile != null) {
            val target = runCatching { hostFile.canonicalPath }.getOrDefault(hostFile.absolutePath)
            if (target.startsWith(PrimaryStorageRoot)) {
                val relative = target.removePrefix(PrimaryStorageRoot).trim('/')
                if (relative.isNotBlank()) {
                    val initialUri = DocumentsContract.buildDocumentUri(
                        ExternalStorageAuthority,
                        PrimaryVolumeDocumentId + relative,
                    )
                    intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI, initialUri)
                }
            }
        }
        return intent
    }

    fun initialUriForGuestDevicePath(guestPath: String): Uri? {
        if (!guestPath.startsWith("/device")) return null
        val relative = guestPath.removePrefix("/device").trim('/')
        if (relative.isBlank()) return null
        return runCatching {
            DocumentsContract.buildDocumentUri(
                ExternalStorageAuthority,
                PrimaryVolumeDocumentId + relative,
            )
        }.getOrNull()
    }
}
