package com.arix.app.ui

import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.SpringSpec
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideIn
import androidx.compose.animation.slideOut
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import kotlin.math.roundToInt

enum class ArixSheetOrigin {
    Top,
    Bottom,
    Start,
    End;

    val opposite: ArixSheetOrigin
        get() = when (this) {
            ArixSheetOrigin.Top -> ArixSheetOrigin.Bottom
            ArixSheetOrigin.Bottom -> ArixSheetOrigin.Top
            ArixSheetOrigin.Start -> ArixSheetOrigin.End
            ArixSheetOrigin.End -> ArixSheetOrigin.Start
        }
}

object ArixMotion {

    const val NaturalDampingRatio = 0.8f

    const val NaturalStiffness = 380f

    const val ControlStiffness = 680f

    fun <T> sheetSpring(
        visibilityThreshold: T? = null,
        dampingRatio: Float = NaturalDampingRatio,
        stiffness: Float = NaturalStiffness,
    ): SpringSpec<T> = spring(
        dampingRatio = dampingRatio,
        stiffness = stiffness,
        visibilityThreshold = visibilityThreshold,
    )

    fun <T> controlSpring(visibilityThreshold: T? = null): SpringSpec<T> = spring(
        dampingRatio = NaturalDampingRatio,
        stiffness = ControlStiffness,
        visibilityThreshold = visibilityThreshold,
    )

    fun initialSlideFraction(origin: ArixSheetOrigin): Pair<Float, Float> =
        when (origin) {
            ArixSheetOrigin.Top -> 0f to -1f
            ArixSheetOrigin.Bottom -> 0f to 1f
            ArixSheetOrigin.Start -> -1f to 0f
            ArixSheetOrigin.End -> 1f to 0f
        }

    fun directionalEnter(
        origin: ArixSheetOrigin,
        distanceFraction: Float = 0.35f,
    ): EnterTransition {
        val (xFraction, yFraction) = initialSlideFraction(origin)
        return slideIn(
            initialOffset = { full ->
                IntOffset(
                    (full.width * xFraction * distanceFraction).roundToInt(),
                    (full.height * yFraction * distanceFraction).roundToInt(),
                )
            },
            animationSpec = sheetSpring(),
        ) + fadeIn(animationSpec = tween(durationMillis = 90, easing = LinearEasing))
    }

    fun directionalExit(
        origin: ArixSheetOrigin,
        distanceFraction: Float = 0.35f,
    ): ExitTransition {
        val (xFraction, yFraction) = initialSlideFraction(origin)
        return slideOut(
            targetOffset = { full ->
                IntOffset(
                    (full.width * xFraction * distanceFraction).roundToInt(),
                    (full.height * yFraction * distanceFraction).roundToInt(),
                )
            },
            animationSpec = sheetSpring(),
        ) + fadeOut(animationSpec = tween(durationMillis = 90, easing = LinearEasing))
    }
}

fun Modifier.materialize(
    progress: () -> Float,
    origin: ArixSheetOrigin,
    travelFraction: Float = 0.18f,
    settledScale: Float = 1f,
): Modifier = composed {
    val layoutDirection = LocalLayoutDirection.current
    val rtl = layoutDirection == LayoutDirection.Rtl
    graphicsLayer {
        val p = progress().coerceIn(0f, 1f)
        val eased = 1f - p
        val (rawX, rawY) = ArixMotion.initialSlideFraction(origin)
        val directionalX = if (rawX < 0f && rtl || rawX > 0f && rtl) -rawX else rawX
        translationX = size.width * directionalX * travelFraction * eased
        translationY = size.height * rawY * travelFraction * eased
        val scale = 0.92f + 0.08f * p + (settledScale - 1f) * p
        scaleX = scale
        scaleY = scale
        alpha = 0.35f + 0.65f * p
        transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0.5f, 0.5f)
    }
}
