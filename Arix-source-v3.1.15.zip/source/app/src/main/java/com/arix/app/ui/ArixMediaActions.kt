package com.arix.app.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.arix.app.data.ArixMediaApi
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request

object ArixMediaActions {

    private const val MaxRemoteFileBytes = 512L * 1024L * 1024L

    private const val StreamCopyBufferBytes = 64 * 1024

    fun downloadToDownloads(
        context: Context,
        fileName: String,
        mimeType: String,
        bytes: ByteArray,
    ): Uri = ArixMediaDownloads.saveToDownloads(context, fileName, mimeType, bytes)

    fun downloadUrlToDownloads(
        context: Context,
        url: String,
        fileName: String,
        mimeType: String,
    ): Long {
        val appContext = context.applicationContext
        val connection = openRemoteStream(url)
        connection.use { bodyStream ->
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                val values = android.content.ContentValues().apply {
                    put(android.provider.MediaStore.Downloads.DISPLAY_NAME, fileName)
                    put(android.provider.MediaStore.Downloads.MIME_TYPE, mimeType.ifBlank { "application/octet-stream" })
                    put(android.provider.MediaStore.Downloads.IS_PENDING, 1)
                }
                val resolver = appContext.contentResolver
                val collection = android.provider.MediaStore.Downloads.getContentUri(
                    android.provider.MediaStore.VOLUME_EXTERNAL_PRIMARY,
                )
                val itemUri = resolver.insert(collection, values)
                    ?: error("The download could not be created in the system Downloads store.")
                try {
                    val written = resolver.openOutputStream(itemUri)?.use { output ->
                        copyWithLimit(bodyStream, output)
                    } ?: error("The download file could not be written.")
                    values.clear()
                    values.put(android.provider.MediaStore.Downloads.IS_PENDING, 0)
                    resolver.update(itemUri, values, null, null)
                    return written
                } catch (throwable: Throwable) {
                    runCatching { resolver.delete(itemUri, null, null) }
                    error("The download failed: ${throwable.message}")
                }
            }
            val downloadsDirectory = context.getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS)
                ?: error("External storage is not available for downloads on this device.")
            val targetFile = File(downloadsDirectory, fileName)
            targetFile.outputStream().use { output ->
                return copyWithLimit(bodyStream, output)
            }
        }
    }

    suspend fun stageShareUrlFile(
        context: Context,
        url: String,
        fileName: String,
    ): File = withContext(Dispatchers.IO) {
        val appContext = context.applicationContext
        val shareDir = File(appContext.cacheDir, "assistant-local-open").apply { mkdirs() }
        shareDir.listFiles()?.forEach { it.delete() }
        val safeName = fileName.replace(Regex("[^A-Za-z0-9._ ()-]"), "_").ifBlank { "arix-file" }
        val staged = File(shareDir, safeName)
        openRemoteStream(url).use { input ->
            staged.outputStream().use { output ->
                copyWithLimit(input, output)
            }
        }
        staged
    }

    private fun openRemoteStream(url: String): InputStream {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", ArixMediaApi.BrowserUserAgent)
            .get()
            .build()
        val response = com.arix.app.data.ArixMediaApi.httpClient.newCall(request).execute()
        if (!response.isSuccessful) {
            response.close()
            error("Download failed (HTTP ${response.code})")
        }
        val body = response.body ?: run {
            response.close()
            error("The server returned an empty file.")
        }
        return body.byteStream()
    }

    private fun copyWithLimit(input: InputStream, output: OutputStream): Long {
        val buffer = ByteArray(StreamCopyBufferBytes)
        var total = 0L
        while (true) {
            val read = input.read(buffer)
            if (read < 0) break
            total += read
            if (total > MaxRemoteFileBytes) {
                error("The file is larger than 512 MB and cannot be downloaded.")
            }
            output.write(buffer, 0, read)
        }
        output.flush()
        return total
    }

    suspend fun stageShareFile(
        context: Context,
        fileName: String,
        bytes: ByteArray,
    ): File = withContext(Dispatchers.IO) {
        val appContext = context.applicationContext
        val shareDir = File(appContext.cacheDir, "assistant-local-open").apply { mkdirs() }
        shareDir.listFiles()?.forEach { it.delete() }
        val safeName = fileName.replace(Regex("[^A-Za-z0-9._ ()-]"), "_").ifBlank { "arix-file" }
        File(shareDir, safeName).apply { writeBytes(bytes) }
    }

    fun shareStagedFile(
        context: Context,
        file: File,
        mimeType: String,
    ): Boolean = runCatching {
        val appContext = context.applicationContext
        val uri = FileProvider.getUriForFile(
            appContext,
            "${appContext.packageName}.fileprovider",
            file,
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType.ifBlank { "application/octet-stream" }
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        appContext.startActivity(
            Intent.createChooser(intent, file.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
        true
    }.getOrDefault(false)

    fun shareBytes(
        context: Context,
        fileName: String,
        mimeType: String,
        bytes: ByteArray,
    ): Boolean = runCatching {
        val appContext = context.applicationContext
        val shareDir = File(appContext.cacheDir, "assistant-local-open").apply { mkdirs() }
        shareDir.listFiles()?.forEach { it.delete() }
        val safeName = fileName.replace(Regex("[^A-Za-z0-9._ ()-]"), "_").ifBlank { "arix-file" }
        val shareFile = File(shareDir, safeName)
        shareFile.writeBytes(bytes)
        shareStagedFile(context, shareFile, mimeType)
    }.getOrDefault(false)

    fun shareText(
        context: Context,
        text: String,
        subject: String? = null,
    ): Boolean = runCatching {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
            subject?.let { putExtra(Intent.EXTRA_SUBJECT, it) }
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(
            Intent.createChooser(intent, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
        true
    }.getOrDefault(false)

    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0) return ""
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0
        return when {
            gb >= 1 -> "%.2f GB".format(gb)
            mb >= 1 -> "%.1f MB".format(mb)
            kb >= 1 -> "%.0f KB".format(kb)
            else -> "$bytes B"
        }
    }
}
