package com.arix.app.ui

import android.app.Application
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.viewmodel.compose.viewModel

object ArixSharedViewModelHost : ViewModelStoreOwner {

    private val processWideStore = ViewModelStore()

    override val viewModelStore: ViewModelStore get() = processWideStore
}

@Composable
fun rememberSharedArixViewModel(): ArixViewModel {
    val application = LocalContext.current.applicationContext as Application
    val factory = remember(application) {
        object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T =
                ArixViewModel(application) as T
        }
    }
    return viewModel(
        viewModelStoreOwner = ArixSharedViewModelHost,
        factory = factory,
    )
}
