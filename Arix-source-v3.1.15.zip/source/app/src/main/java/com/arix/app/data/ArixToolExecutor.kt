package com.arix.app.data

import android.content.Context
import com.arix.app.browser.ArixBrowserSession
import com.arix.app.runtime.RuntimeRouter
import com.arix.app.runtime.RuntimeShellTool
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

data class ArixToolExecutionResult(
    val toolName: String,
    val argumentsJson: String,
    val rawOutput: String,
) {
    val isError: Boolean = !ArixToolExecutor.inferToolOutputOk(rawOutput)
}

class ArixToolExecutor(
    private val runtimeRouter: RuntimeRouter,
    private val upiPaymentController: ArixUpiPaymentController? = null,
    private val memoryManager: ArixMemoryManager? = null,
    private val diagnosticsService: ArixDiagnosticsService? = null,
    private val sessionContextTracker: ArixSessionContextTracker? = null,
    private val termuxRuntime: com.arix.app.runtime.TermuxRuntime? = null,
    private val appContext: Context? = null,
    private val swarmManager: ArixSwarmManager? = null,
    private val projectRepository: ArixProjectRepository? = null,
    private val mcpManager: com.arix.app.mcp.ArixMcpManager? = null,
) {

    private val failureTracker = ConcurrentHashMap<String, FailureRecord>()

    internal val supervisor = ArixAgentSupervisor()

    private val deviceMutationMutex = Mutex()

    private class FailureRecord(
        val count: java.util.concurrent.atomic.AtomicInteger,
        @Volatile var lastAtMillis: Long,
    )

    suspend fun execute(
        settings: AppSettings,
        workspaceDirectory: String,
        toolName: String,
        argumentsJson: String,
        selfManagementTool: ArixSelfManagementTool? = null,
        currentRuntimeId: LocalRuntimeId = settings.defaultRuntimeId ?: LocalRuntimeId.Termux,
        onRuntimeChanged: suspend (LocalRuntimeId) -> Unit = {},
        onProgress: (suspend (String) -> Unit)? = null,
        sessionId: String? = null,
    ): ArixToolExecutionResult {
        val rawOutput = executeSupervised(
            settings = settings,
            workspaceDirectory = workspaceDirectory,
            toolName = toolName,
            argumentsJson = argumentsJson,
            selfManagementTool = selfManagementTool,
            currentRuntimeId = currentRuntimeId,
            onRuntimeChanged = onRuntimeChanged,
            onProgress = onProgress,
            sessionId = sessionId,
        )
        return ArixToolExecutionResult(toolName, argumentsJson, rawOutput)
    }

    private suspend fun executeSupervised(
        settings: AppSettings,
        workspaceDirectory: String,
        toolName: String,
        argumentsJson: String,
        selfManagementTool: ArixSelfManagementTool?,
        currentRuntimeId: LocalRuntimeId,
        onRuntimeChanged: suspend (LocalRuntimeId) -> Unit,
        onProgress: (suspend (String) -> Unit)? = null,
        sessionId: String? = null,
    ): String {
        if (sessionId != null) {
            supervisor.beforeToolCall(sessionId, toolName, argumentsJson)?.let { guard ->
                return guard.toString()
            }
        }

        val timeoutMs = ArixAgentSupervisor.timeoutFor(toolName)
        val managedRunIds = ConcurrentHashMap.newKeySet<String>()
        val trackedProgress: (suspend (String) -> Unit)? = onProgress?.let { original ->
            suspend { payload: String ->
                runCatching { JSONObject(payload) }.getOrNull()
                    ?.optString("run_id")?.trim()
                    ?.takeIf { it.isNotBlank() }
                    ?.let { managedRunIds += it }
                original(payload)
            }
        }
        val rawOutput = withTimeoutOrNull(timeoutMs) {
            if (toolName in ArixAgentSupervisor.MutatingDeviceTools) {
                deviceMutationMutex.withLock {
                    executeInternal(
                        settings, workspaceDirectory, toolName, argumentsJson,
                        selfManagementTool, currentRuntimeId, onRuntimeChanged, trackedProgress,
                        sessionId,
                    )
                }
            } else {
                executeInternal(
                    settings, workspaceDirectory, toolName, argumentsJson,
                    selfManagementTool, currentRuntimeId, onRuntimeChanged, trackedProgress,
                    sessionId,
                )
            }
        } ?: run {
            if (managedRunIds.isNotEmpty()) {
                val shellTool = RuntimeShellTool(runtimeRouter)
                managedRunIds.toList().forEach { runId ->
                    runCatching { shellTool.killByRunId(runId) }
                }
            }
            ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.TIMEOUT,
                    "Tool '$toolName' did not finish within ${timeoutMs / 1000}s. It was cancelled. " +
                        "Retry only with a smaller/faster variant of the work, or report the timeout.",
                ),
                toolName,
            ).toString()
        }

        if (sessionId != null) {
            supervisor.afterToolCall(sessionId, toolName, argumentsJson, rawOutput)
        }
        return rawOutput
    }

    private suspend fun executeInternal(
        settings: AppSettings,
        workspaceDirectory: String,
        toolName: String,
        argumentsJson: String,
        selfManagementTool: ArixSelfManagementTool?,
        currentRuntimeId: LocalRuntimeId,
        onRuntimeChanged: suspend (LocalRuntimeId) -> Unit,
        onProgress: (suspend (String) -> Unit)? = null,
        sessionId: String? = null,
    ): String {
        val loopKey = "$toolName|${argumentsJson.hashCode()}"
        val record = failureTracker[loopKey]
        if (record != null && record.count.get() >= MaxIdenticalFailures &&
            System.currentTimeMillis() - record.lastAtMillis < FailureWindowMillis
        ) {
            return ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.REPEATED_FAILURE,
                    "The identical call to '$toolName' with the same arguments has already failed " +
                        "${record.count.get()} times. Stop repeating it: report the failure to the user. A retry is " +
                        "only justified with CORRECTED, unambiguous input.",
                ),
                toolName,
            ).toString()
        }

        val rawOutput = executeValidated(
            settings = settings,
            workspaceDirectory = workspaceDirectory,
            toolName = toolName,
            argumentsJson = argumentsJson,
            selfManagementTool = selfManagementTool,
            currentRuntimeId = currentRuntimeId,
            onRuntimeChanged = onRuntimeChanged,
            onProgress = onProgress,
            sessionId = sessionId,
        )

        val outputOk = ArixToolExecutor.inferToolOutputOk(rawOutput)
        sessionContextTracker?.recordToolCall(
            toolName = toolName,
            argumentsJson = argumentsJson,
            output = rawOutput,
            ok = outputOk,
        )
        if (outputOk) {
            failureTracker.remove(loopKey)
        } else {
            val existing = failureTracker[loopKey]
            if (existing == null) {
                failureTracker[loopKey] = FailureRecord(
                    java.util.concurrent.atomic.AtomicInteger(1),
                    System.currentTimeMillis(),
                )
            } else {
                existing.count.incrementAndGet()
                existing.lastAtMillis = System.currentTimeMillis()
            }
            if (failureTracker.size > TrackerCapacity) evictStaleFailures()
        }
        return rawOutput
    }

    private suspend fun executeValidated(
        settings: AppSettings,
        workspaceDirectory: String,
        toolName: String,
        argumentsJson: String,
        selfManagementTool: ArixSelfManagementTool?,
        currentRuntimeId: LocalRuntimeId,
        onRuntimeChanged: suspend (LocalRuntimeId) -> Unit,
        onProgress: (suspend (String) -> Unit)? = null,
        sessionId: String? = null,
    ): String {
        if (toolName !in hostToolNames &&
            !(toolName.startsWith("mcp__") && mcpManager != null)
        ) {
            return ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.TOOL_NOT_FOUND,
                    "Tool '$toolName' does not exist in this runtime. Do not guess or substitute another " +
                        "tool; the available tools are exactly the ones listed for this turn.",
                ),
                toolName,
            ).toString()
        }

        val unavailable = unavailableReason(toolName, selfManagementTool)
        if (unavailable != null) {
            return ArixToolContract.withTool(
                ArixToolContract.failure(ArixToolContract.TOOL_UNAVAILABLE, unavailable),
                toolName,
            ).toString()
        }

        if (toolName in RegistryValidatedToolNames) {
            val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            if (arguments == null) {
                return ArixToolContract.withTool(
                    ArixToolContract.failure(
                        ArixToolContract.INVALID_ARGUMENTS,
                        "Arguments were not valid JSON.",
                    ),
                    toolName,
                ).toString()
            }
        }

        return dispatch(
            settings = settings,
            workspaceDirectory = workspaceDirectory,
            toolName = toolName,
            argumentsJson = argumentsJson,
            selfManagementTool = selfManagementTool,
            currentRuntimeId = currentRuntimeId,
            onRuntimeChanged = onRuntimeChanged,
            onProgress = onProgress,
            sessionId = sessionId,
        )
    }

    private fun evictStaleFailures() {
        val now = System.currentTimeMillis()
        failureTracker.entries.removeIf { now - it.value.lastAtMillis > FailureWindowMillis }
    }

    private suspend fun dispatch(
        settings: AppSettings,
        workspaceDirectory: String,
        toolName: String,
        argumentsJson: String,
        selfManagementTool: ArixSelfManagementTool?,
        currentRuntimeId: LocalRuntimeId,
        onRuntimeChanged: suspend (LocalRuntimeId) -> Unit,
        onProgress: (suspend (String) -> Unit)? = null,
        sessionId: String? = null,
    ): String {
        if (toolName.startsWith("mcp__")) {
            return mcpToolResult(toolName, argumentsJson)
        }
        return when (toolName) {
        "media_search" -> executeMediaSearchTool(argumentsJson, settings)

        "browser" -> executeBrowserTool(argumentsJson)

        "phone" -> executePhoneTool(argumentsJson)

        ArixWebAccessTool.ToolNameSearch -> executeWebSearchTool(
            settings = settings,
            argumentsJson = argumentsJson,
            sessionId = sessionId,
            onProgress = onProgress,
        )

        ArixWebAccessTool.ToolNameFetch -> executeWebFetchTool(
            settings = settings,
            argumentsJson = argumentsJson,
            sessionId = sessionId,
        )

        ArixWebScrapeTool.ToolName -> executeWebScrapeTool(
            workspaceDirectory = workspaceDirectory,
            argumentsJson = argumentsJson,
            onProgress = onProgress,
        )

        "arix_swarm" -> executeSwarmTool(argumentsJson, sessionId, onProgress)

        "arix_projects" -> executeProjectsTool(argumentsJson)

        "upi_pay" -> upiPaymentController?.execute(argumentsJson)
            ?: ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.TOOL_UNAVAILABLE,
                    "UPI payments are not available in this build.",
                ),
                toolName,
            ).toString()

        "arix_runtime_manage" -> executeRuntimeManage(
            settings = settings,
            currentRuntimeId = currentRuntimeId,
            workspaceDirectory = workspaceDirectory,
            argumentsJson = argumentsJson,
            onRuntimeChanged = onRuntimeChanged,
        )

        "arix_ensure_package" -> executeEnsurePackage(argumentsJson, onProgress)

        "arix_tasks" -> executeTasks(argumentsJson, sessionId)

        "arix_file_share" -> executeFileShareTool(
            argumentsJson = argumentsJson,
            workspaceDirectory = workspaceDirectory,
            onProgress = onProgress,
        )

        "arix_memory" -> {
            val memory = memoryManager
                ?: return ArixToolContract.withTool(
                    ArixToolContract.failure(
                        ArixToolContract.TOOL_UNAVAILABLE,
                        "The memory subsystem is not available in this build.",
                    ),
                    toolName,
                ).toString()
            val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
                ?: return ArixToolContract.withTool(
                    ArixToolContract.failure(
                        ArixToolContract.INVALID_ARGUMENTS,
                        "Arguments were not valid JSON.",
                    ),
                    toolName,
                ).toString()
            memory.execute(argumentsJson, arguments.optString("session_id").trim().ifBlank { null })
                .let { ArixToolContract.withTool(it, toolName).toString() }
        }

        "arix_diagnostics" -> {
            val diagnostics = diagnosticsService
                ?: return ArixToolContract.withTool(
                    ArixToolContract.failure(
                        ArixToolContract.TOOL_UNAVAILABLE,
                        "The diagnostics subsystem is not available in this build.",
                    ),
                    toolName,
                ).toString()
            diagnostics.execute(argumentsJson)
                .let { ArixToolContract.withTool(it, toolName).toString() }
        }

        in SelfManagementToolNames -> selfManagementTool?.execute(
            toolName = toolName,
            argumentsJson = argumentsJson,
        ) ?: unavailableToolOutput(toolName)

        else -> ArixToolContract.withTool(
            ArixToolContract.failure(
                ArixToolContract.TOOL_NOT_FOUND,
                "Tool '$toolName' does not exist in this runtime. Do not guess or substitute another " +
                    "tool; the available tools are exactly the ones listed for this turn.",
            ),
            toolName,
        ).toString()
    }
    }

    private suspend fun mcpToolResult(toolName: String, argumentsJson: String): String {
        val manager = mcpManager
            ?: return ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.TOOL_NOT_FOUND,
                    "MCP is not available in this runtime.",
                ),
                toolName,
            ).toString()
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull() ?: JSONObject()
        return runCatching {
            val result = manager.executeTool(toolName, arguments)
            if (result.isError) {
                ArixToolContract.withTool(
                    ArixToolContract.failure(ArixToolContract.ACTION_FAILED, result.text),
                    toolName,
                ).toString()
            } else {
                ArixToolContract.withTool(
                    ArixToolContract.success(
                        JSONObject().put(
                            "output",
                            result.text,
                        ),
                        verified = true,
                    ),
                    toolName,
                ).toString()
            }
        }.getOrElse { error ->
            ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.ACTION_FAILED,
                    "MCP tool call failed: ${error.message ?: error.javaClass.simpleName}",
                ),
                toolName,
            ).toString()
        }
    }

    private suspend fun executeMediaSearchTool(argumentsJson: String, settings: AppSettings): String {
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            ?: return ArixToolContract.withTool(
                ArixToolContract.failure(ArixToolContract.INVALID_ARGUMENTS, "Invalid JSON arguments."),
                "media_search",
            ).toString()
        val url = arguments.optString("url").trim()
        val site = arguments.optString("site").trim()
        val query = arguments.optString("query").trim()
        if (url.isBlank() && site.isBlank() && query.isBlank()) {
            return ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.INVALID_ARGUMENTS,
                    "One of query, url or site is required.",
                ),
                "media_search",
            ).toString()
        }
        val context = appContext
            ?: return ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.TOOL_UNAVAILABLE,
                    "The media resolver is not available in this build.",
                ),
                "media_search",
            ).toString()
        val rawQueryKind = arguments.optString("kind")
        val inferredKind = com.arix.app.media.ArixMediaKind.fromStorageOrNull(rawQueryKind)
            ?: inferMediaKindFromQuery(query)
        val explicitAdultFlag = arguments.has("allow_adult")
        val adultIntent = (explicitAdultFlag && arguments.optBoolean("allow_adult", false)) ||
            com.arix.app.media.ArixMediaResolver.looksLikeAdultQuery(query)
        val searchQuery = com.arix.app.media.ArixMediaSearchQuery(
            query = query,
            kind = inferredKind,
            site = site,
            url = url,
            limit = arguments.optInt("limit", 12).coerceIn(1, 24),
            allowAdult = if (explicitAdultFlag) {
                arguments.optBoolean("allow_adult", false)
            } else {
                settings.unrestrictedMode
            },
            adultIntent = adultIntent,
        )
        val result = runCatching {
            com.arix.app.media.ArixMediaResolver.search(context, searchQuery)
        }.fold(
            onSuccess = { it },
            onFailure = { throwable ->
                com.arix.app.media.ArixMediaSearchResult(
                    ok = false,
                    items = emptyList(),
                    source = "resolver",
                    message = throwable.message ?: "The media search failed.",
                    errorCode = "SEARCH_FAILED",
                )
            },
        )
        return result.toJson("media_search").toString()
    }

    private fun unavailableReason(toolName: String, selfManagementTool: ArixSelfManagementTool?): String? {
        when (toolName) {
            "upi_pay" -> if (upiPaymentController == null) return "UPI payments are not available in this build."

            "browser" -> if (appContext == null) {
                return "The built-in browser is not available in this build."
            }

            "phone" -> if (appContext == null) {
                return "The phone tool is not available in this build."
            }

            ArixWebAccessTool.ToolNameSearch, ArixWebAccessTool.ToolNameFetch -> {
                if (appContext == null) {
                    return "The built-in browser is not available in this build."
                }
            }

            ArixWebScrapeTool.ToolName -> {
                if (appContext == null) {
                    return "The web scraper is not available in this build."
                }
            }

            "arix_swarm" -> if (swarmManager == null) {
                return "The Agent Swarm is not available in this build."
            }

            "arix_file_share" -> if (termuxRuntime == null) {
                return "The file-transfer runtime is not available in this build."
            }

            in SelfManagementToolNames -> {
                if (selfManagementTool == null) return "Host dependency for '$toolName' is not available."
            }
        }
        return null
    }

    private suspend fun executeWebSearchTool(
        settings: AppSettings,
        argumentsJson: String,
        sessionId: String?,
        onProgress: (suspend (String) -> Unit)?,
    ): String {
        val context = appContext
            ?: return ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.TOOL_UNAVAILABLE,
                    "The built-in browser is not available in this build.",
                ),
                ArixWebAccessTool.ToolNameSearch,
            ).toString()
        return kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            ArixWebAccessTool.executeSearch(
                context = context,
                settings = settings,
                argumentsJson = argumentsJson,
                sessionId = sessionId,
                memoryManager = memoryManager,
                onProgress = onProgress,
            ).let { ArixToolContract.withTool(it, ArixWebAccessTool.ToolNameSearch).toString() }
        }
    }

    private suspend fun executeWebFetchTool(
        settings: AppSettings,
        argumentsJson: String,
        sessionId: String?,
    ): String {
        val context = appContext
            ?: return ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.TOOL_UNAVAILABLE,
                    "The built-in browser is not available in this build.",
                ),
                ArixWebAccessTool.ToolNameFetch,
            ).toString()
        return kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            ArixWebAccessTool.executeFetch(
                context = context,
                settings = settings,
                argumentsJson = argumentsJson,
                sessionId = sessionId,
            ).let { ArixToolContract.withTool(it, ArixWebAccessTool.ToolNameFetch).toString() }
        }
    }

    private suspend fun executeWebScrapeTool(
        workspaceDirectory: String,
        argumentsJson: String,
        onProgress: (suspend (String) -> Unit)?,
    ): String {
        val context = appContext
            ?: return ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.TOOL_UNAVAILABLE,
                    "The web scraper is not available in this build.",
                ),
                ArixWebScrapeTool.ToolName,
            ).toString()
        return ArixWebScrapeTool.execute(
            context = context,
            argumentsJson = argumentsJson,
            workspaceDirectory = workspaceDirectory.takeIf { it.isNotBlank() },
            onProgress = onProgress,
        ).let { ArixToolContract.withTool(it, ArixWebScrapeTool.ToolName).toString() }
    }

    /**
     * v3.1.15 — the phone tool (Mika port). One call = one action on the
     * background virtual display; the small live view in the chat follows along.
     */
    private suspend fun executePhoneTool(argumentsJson: String): String {
        val context = appContext
            ?: return ArixToolContract.withTool(
                ArixToolContract.failure(ArixToolContract.TOOL_UNAVAILABLE, "The phone tool is not available in this build."),
                "phone",
            ).toString()
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            ?: return ArixToolContract.withTool(
                ArixToolContract.failure(ArixToolContract.INVALID_ARGUMENTS, "Arguments were not valid JSON."),
                "phone",
            ).toString()
        val action = arguments.optString("action").trim().lowercase(java.util.Locale.US)
        val agent = com.arix.app.agent.ArixPhoneAgent.of(context)

        fun ok(result: JSONObject, verified: Boolean = true): String =
            ArixToolContract.withTool(ArixToolContract.success(result, verified), "phone").toString()

        fun fail(code: String, message: String): String =
            ArixToolContract.withTool(ArixToolContract.failure(code, message), "phone").toString()

        fun actionResult(result: com.arix.app.agent.ArixActionResult): String = when (result) {
            is com.arix.app.agent.ArixActionResult.Ok ->
                ok(JSONObject().put("action", action).put("detail", result.detail ?: "ok"))
            is com.arix.app.agent.ArixActionResult.Failed ->
                fail(result.code, result.detail ?: result.code)
        }

        try {
            return when (action) {
                "list_apps" -> {
                    val apps = agent.listApps()
                    ok(
                        JSONObject()
                            .put("action", "list_apps")
                            .put(
                                "apps",
                                JSONArray().apply {
                                    apps.forEach { (pkg, label) ->
                                        put(JSONObject().put("package", pkg).put("label", label))
                                    }
                                },
                            )
                            .put("count", apps.size),
                    )
                }

                "open_app" -> {
                    val pkg = arguments.optString("package").trim()
                    if (pkg.isEmpty()) return fail(ArixToolContract.INVALID_ARGUMENTS, "package is required for open_app.")
                    actionResult(agent.openApp(pkg, cold = arguments.optBoolean("cold", false)))
                }

                "read_screen" -> {
                    val snapshot = agent.readScreen()
                    val payload = JSONObject()
                        .put("action", "read_screen")
                        .put("snapshot_id", snapshot.snapshotId)
                        .put("width", snapshot.width)
                        .put("height", snapshot.height)
                        .put("has_window", snapshot.hasWindow)
                        .put("package", snapshot.packageName ?: JSONObject.NULL)
                    if (!snapshot.hasWindow) {
                        payload.put(
                            "note",
                            "No app is open on the background screen yet — call open_app first.",
                        )
                    }
                    payload.put(
                        "text",
                        snapshot.textLines.joinToString("\n").take(12_000),
                    )
                    payload.put(
                        "elements",
                        JSONArray().apply {
                            snapshot.elements.forEach { element ->
                                put(
                                    JSONObject()
                                        .put("ref", element.ref)
                                        .put("text", element.text)
                                        .put("clickable", element.clickable)
                                        .put("editable", element.editable)
                                        .put("scrollable", element.scrollable)
                                        .put(
                                            "bounds",
                                            JSONArray()
                                                .put(element.bounds.left)
                                                .put(element.bounds.top)
                                                .put(element.bounds.right)
                                                .put(element.bounds.bottom),
                                        ),
                                )
                            }
                        },
                    )
                    ok(payload, verified = snapshot.hasWindow)
                }

                "read_ocr" -> {
                    val lines = agent.readScreenOcr()
                    ok(
                        JSONObject()
                            .put("action", "read_ocr")
                            .put(
                                "lines",
                                JSONArray().apply {
                                    lines.forEach { line ->
                                        put(
                                            JSONObject()
                                                .put("text", line.text)
                                                .put(
                                                    "bounds",
                                                    JSONArray()
                                                        .put(line.left)
                                                        .put(line.top)
                                                        .put(line.right)
                                                        .put(line.bottom),
                                                ),
                                        )
                                    }
                                },
                            )
                            .put("count", lines.size),
                    )
                }

                "screenshot" -> {
                    val png = agent.screenshotPng()
                        ?: return fail(
                            ArixToolContract.ACTION_FAILED,
                            "No background screen yet — call open_app first.",
                        )
                    val payload = JSONObject()
                        .put("action", "screenshot")
                        .put("image_bytes", png.size)
                    if (arguments.optBoolean("read_image", true)) {
                        val base64 = android.util.Base64.encodeToString(png, android.util.Base64.NO_WRAP)
                        payload
                            .put("widget", "phone_screenshot")
                            .put("screenshot_base64", base64)
                            .put("screenshot_mime_type", "image/png")
                            .put("base64", base64)
                            .put("mime_type", "image/png")
                    }
                    ok(payload)
                }

                "tap" -> {
                    val x = arguments.optInt("x", -1)
                    val y = arguments.optInt("y", -1)
                    if (x < 0 || y < 0) return fail(ArixToolContract.INVALID_ARGUMENTS, "x and y are required for tap.")
                    actionResult(agent.tap(x, y))
                }

                "double_tap" -> {
                    val x = arguments.optInt("x", -1)
                    val y = arguments.optInt("y", -1)
                    if (x < 0 || y < 0) return fail(ArixToolContract.INVALID_ARGUMENTS, "x and y are required for double_tap.")
                    actionResult(agent.doubleTap(x, y))
                }

                "type" -> {
                    val text = arguments.optString("text")
                    if (text.isEmpty()) return fail(ArixToolContract.INVALID_ARGUMENTS, "text is required for type.")
                    val x = if (arguments.has("x") && !arguments.isNull("x")) arguments.optInt("x") else null
                    val y = if (arguments.has("y") && !arguments.isNull("y")) arguments.optInt("y") else null
                    actionResult(agent.typeText(text, x, y))
                }

                "clear_text" -> {
                    val x = if (arguments.has("x") && !arguments.isNull("x")) arguments.optInt("x") else null
                    val y = if (arguments.has("y") && !arguments.isNull("y")) arguments.optInt("y") else null
                    actionResult(agent.clearText(x, y))
                }

                "scroll" -> actionResult(agent.scroll(arguments.optBoolean("down", true)))

                "swipe" -> {
                    val x1 = arguments.optInt("x1", Int.MIN_VALUE)
                    val y1 = arguments.optInt("y1", Int.MIN_VALUE)
                    val x2 = arguments.optInt("x2", Int.MIN_VALUE)
                    val y2 = arguments.optInt("y2", Int.MIN_VALUE)
                    if (x1 == Int.MIN_VALUE || y1 == Int.MIN_VALUE || x2 == Int.MIN_VALUE || y2 == Int.MIN_VALUE) {
                        return fail(ArixToolContract.INVALID_ARGUMENTS, "x1, y1, x2, y2 are required for swipe.")
                    }
                    actionResult(
                        agent.swipe(x1, y1, x2, y2, arguments.optLong("duration_ms", 300L)),
                    )
                }

                "back" -> actionResult(agent.back())
                "home" -> actionResult(agent.home())

                "key" -> {
                    val keyCode = arguments.optInt("key_code", -1)
                    if (keyCode <= 0) return fail(ArixToolContract.INVALID_ARGUMENTS, "key_code is required for key.")
                    actionResult(agent.key(keyCode))
                }

                "wait_stable" -> {
                    val settled = agent.waitStable(arguments.optLong("duration_ms", 4000L).coerceIn(500, 15_000))
                    ok(JSONObject().put("action", "wait_stable").put("settled", settled))
                }

                "needs_user" -> {
                    val reason = arguments.optString("reason").ifBlank { arguments.optString("text") }
                        .ifBlank { "The agent needs you to act on the phone." }
                    agent.pipNeedsYouPublic(reason)
                    fail(
                        ArixToolContract.PERMISSION_REQUIRED,
                        "Needs the user: $reason — ask them in your reply and wait for their answer.",
                    )
                }

                "finish" -> {
                    fun stringList(key: String): List<String> {
                        val array = arguments.optJSONArray(key) ?: return emptyList()
                        return (0 until array.length()).mapNotNull { i -> array.optString(i).trim().takeIf { it.isNotEmpty() } }
                    }
                    actionResult(agent.finish(stringList("keep"), stringList("close")))
                }

                else -> fail(
                    ArixToolContract.INVALID_ARGUMENTS,
                    "Unknown phone action '$action'. Valid: list_apps, open_app, read_screen, screenshot, tap, " +
                        "double_tap, type, clear_text, scroll, swipe, back, home, key, wait_stable, needs_user, finish.",
                )
            }
        } catch (unavailable: com.arix.app.agent.ArixPhoneUnavailable) {
            return fail(ArixToolContract.TOOL_UNAVAILABLE, unavailable.hint)
        } catch (security: SecurityException) {
            return fail(ArixToolContract.PERMISSION_REQUIRED, security.message ?: "permission denied")
        } catch (error: Exception) {
            return fail(
                ArixToolContract.ACTION_FAILED,
                "The phone action failed: ${error.message ?: error.javaClass.simpleName}",
            )
        }
    }

    private suspend fun executeSwarmTool(
        argumentsJson: String,
        sessionId: String?,
        onProgress: (suspend (String) -> Unit)?,
    ): String {
        val swarm = swarmManager
            ?: return ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.TOOL_UNAVAILABLE,
                    "The Agent Swarm is not available in this build.",
                ),
                "arix_swarm",
            ).toString()
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            ?: return ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.INVALID_ARGUMENTS,
                    "Arguments were not valid JSON.",
                ),
                "arix_swarm",
            ).toString()
        val action = arguments.optString("action").trim().ifBlank { "spawn" }
        return when (action) {
            "micro", "delegate", "run_one" -> {
                val name = arguments.optString("name").trim().ifBlank { "micro-agent" }
                val prompt = arguments.optString("prompt").trim()
                if (prompt.isBlank()) {
                    return ArixToolContract.withTool(
                        ArixToolContract.failure(
                            ArixToolContract.INVALID_ARGUMENTS,
                            "action=micro needs a non-empty 'prompt' (and optionally 'name'/'role').",
                        ),
                        "arix_swarm",
                    ).toString()
                }
                swarm.runMicroAgent(
                    parentSessionId = sessionId.orEmpty(),
                    spec = ArixSwarmManager.SubAgentSpec(
                        name = name.take(40),
                        role = arguments.optString("role").trim().ifBlank { "general-purpose" },
                        prompt = prompt,
                    ),
                    timeoutMillis = arguments.optLong("timeout_ms", 0L)
                        .takeIf { it > 0L } ?: 180_000L,
                    maxToolCalls = arguments.optInt("max_tool_calls", 0)
                        .takeIf { it > 0 } ?: 12,
                    onProgress = onProgress,
                ).let { ArixToolContract.withTool(it, "arix_swarm").toString() }
            }
            "spawn", "run" -> {
                val agentsJson = arguments.optJSONArray("agents")
                    ?: return ArixToolContract.withTool(
                        ArixToolContract.failure(
                            ArixToolContract.INVALID_ARGUMENTS,
                            "Provide 'agents': [{name, role, prompt}, ...] (1-4 sub-agents).",
                        ),
                        "arix_swarm",
                    ).toString()
                val specs = mutableListOf<ArixSwarmManager.SubAgentSpec>()
                for (index in 0 until agentsJson.length()) {
                    val agent = agentsJson.optJSONObject(index) ?: continue
                    val name = agent.optString("name").trim()
                    val prompt = agent.optString("prompt").trim()
                    if (name.isBlank() || prompt.isBlank()) continue
                    specs.add(
                        ArixSwarmManager.SubAgentSpec(
                            name = name.take(40),
                            role = agent.optString("role").trim().ifBlank { "general-purpose" },
                            prompt = prompt,
                        ),
                    )
                }
                if (specs.isEmpty()) {
                    return ArixToolContract.withTool(
                        ArixToolContract.failure(
                            ArixToolContract.INVALID_ARGUMENTS,
                            "Every sub-agent needs a non-empty 'name' and 'prompt'.",
                        ),
                        "arix_swarm",
                    ).toString()
                }
                swarm.spawn(
                    parentSessionId = sessionId.orEmpty(),
                    agents = specs,
                    timeoutMillis = arguments.optLong("timeout_ms", 0L)
                        .takeIf { it > 0L } ?: 300_000L,
                    maxToolCalls = arguments.optInt("max_tool_calls", 0)
                        .takeIf { it > 0 } ?: 40,
                    onProgress = onProgress,
                ).let { ArixToolContract.withTool(it, "arix_swarm").toString() }
            }
            "status" -> swarm.status(arguments.optString("swarm_id").trim().takeIf { it.isNotBlank() })
                .let { ArixToolContract.withTool(it, "arix_swarm").toString() }
            "collect" -> swarm.collect(
                swarmId = arguments.optString("swarm_id").trim(),
                timeoutMillis = arguments.optLong("timeout_ms", 0L)
                    .takeIf { it > 0L } ?: 120_000L,
            ).let { ArixToolContract.withTool(it, "arix_swarm").toString() }
            "stop", "cancel" -> swarm.stop(arguments.optString("swarm_id").trim())
                .let { ArixToolContract.withTool(it, "arix_swarm").toString() }
            else -> ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.INVALID_ARGUMENTS,
                    "action must be 'spawn' (default), 'micro', 'status', 'collect' or 'stop'.",
                ),
                "arix_swarm",
            ).toString()
        }
    }

    private suspend fun executeProjectsTool(argumentsJson: String): String {
        val repository = projectRepository
            ?: return ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.TOOL_UNAVAILABLE,
                    "Projects are not available in this build.",
                ),
                "arix_projects",
            ).toString()
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            ?: return ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.INVALID_ARGUMENTS,
                    "Arguments were not valid JSON.",
                ),
                "arix_projects",
            ).toString()
        val action = arguments.optString("action").trim().lowercase(java.util.Locale.US)
        return when (action) {
            "list" -> {
                val projects = repository.snapshot()
                ArixToolContract.withTool(
                    ArixToolContract.success(
                        JSONObject()
                            .put("action", "list")
                            .put("count", projects.size)
                            .put(
                                "projects",
                                org.json.JSONArray(projects.map { project ->
                                    JSONObject()
                                        .put("id", project.id)
                                        .put("name", project.name)
                                        .put("description", project.description)
                                        .put("isArchived", project.isArchived)
                                }),
                            )
                            .put("stdout", "${projects.size} project(s)."),
                        verified = true,
                    ),
                    "arix_projects",
                ).toString()
            }
            "create" -> {
                val name = arguments.optString("name").trim()
                if (name.isBlank()) {
                    return ArixToolContract.withTool(
                        ArixToolContract.failure(
                            ArixToolContract.INVALID_ARGUMENTS,
                            "'name' is required for create.",
                        ),
                        "arix_projects",
                    ).toString()
                }
                runCatching { repository.create(name, arguments.optString("description").trim()) }
                    .fold(
                        onSuccess = { project ->
                            ArixToolContract.withTool(
                                ArixToolContract.success(
                                    JSONObject()
                                        .put("action", "create")
                                        .put("id", project.id)
                                        .put("name", project.name)
                                        .put("stdout", "Project '${project.name}' created."),
                                    verified = true,
                                ),
                                "arix_projects",
                            ).toString()
                        },
                        onFailure = { throwable ->
                            ArixToolContract.withTool(
                                ArixToolContract.failure(
                                    ArixToolContract.INVALID_ARGUMENTS,
                                    throwable.message ?: "Could not create the project.",
                                ),
                                "arix_projects",
                            ).toString()
                        },
                    )
            }
            "inspect" -> {
                val project = repository.find(arguments.optString("project_id").trim())
                    ?: repository.findByName(arguments.optString("name").trim())
                if (project == null) {
                    return ArixToolContract.withTool(
                        ArixToolContract.failure(
                            ArixToolContract.INVALID_ARGUMENTS,
                            "No such project.",
                        ),
                        "arix_projects",
                    ).toString()
                }
                ArixToolContract.withTool(
                    ArixToolContract.success(
                        JSONObject()
                            .put("action", "inspect")
                            .put("id", project.id)
                            .put("name", project.name)
                            .put("description", project.description)
                            .put("linkedSessions", project.linkedSessionIds.size)
                            .put("stdout", "Project '${project.name}'."),
                        verified = true,
                    ),
                    "arix_projects",
                ).toString()
            }
            "delete" -> {
                val projectId = arguments.optString("project_id").trim()
                val confirmed = arguments.optBoolean("confirm", false)
                if (!confirmed) {
                    return ArixToolContract.withTool(
                        ArixToolContract.failure(
                            ArixToolContract.PERMISSION_REQUIRED,
                            "Deleting a project unlinks its memories. Confirm with the user " +
                                "first, then repeat with confirm=true.",
                        ),
                        "arix_projects",
                    ).toString()
                }
                val deleted = repository.delete(projectId)
                ArixToolContract.withTool(
                    if (deleted) {
                        ArixToolContract.success(
                            JSONObject().put("action", "delete").put("stdout", "Project deleted."),
                            verified = true,
                        )
                    } else {
                        ArixToolContract.failure(ArixToolContract.INVALID_ARGUMENTS, "No such project.")
                    },
                    "arix_projects",
                ).toString()
            }
            else -> ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.INVALID_ARGUMENTS,
                    "action must be list, create, inspect or delete.",
                ),
                "arix_projects",
            ).toString()
        }
    }

    private suspend fun executeBrowserTool(argumentsJson: String): String {
        val context = appContext
            ?: return ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.TOOL_UNAVAILABLE,
                    "The built-in browser is not available in this build.",
                ),
                "browser",
            ).toString()
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            ?: return ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.INVALID_ARGUMENTS,
                    "Arguments were not valid JSON.",
                ),
                "browser",
            ).toString()
        return kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            runCatching { ArixBrowserSession.execute(context, arguments) }
                .fold(
                    onSuccess = { result ->
                        val parsed = runCatching { JSONObject(result.content) }.getOrNull()
                        if (parsed != null) {
                            if (parsed.optString("widget") != "browser_screenshot") {
                                parsed.remove("widget")
                            }
                            ArixToolContract.withTool(parsed, "browser").toString()
                        } else {
                            result.content
                        }
                    },
                    onFailure = { throwable ->
                        ArixToolContract.withTool(
                            ArixToolContract.failure(
                                ArixToolContract.ACTION_FAILED,
                                "The browser action failed: ${throwable.message ?: "unknown error"}",
                            ),
                            "browser",
                        ).toString()
                    },
                )
        }
    }

    private suspend fun executeRuntimeManage(
        settings: AppSettings,
        currentRuntimeId: LocalRuntimeId,
        workspaceDirectory: String,
        argumentsJson: String,
        onRuntimeChanged: suspend (LocalRuntimeId) -> Unit,
    ): String {
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            ?: return ArixToolContract.withTool(
                ArixToolContract.failure(ArixToolContract.INVALID_ARGUMENTS, "Invalid JSON arguments."),
                "arix_runtime_manage",
            ).toString()
        val action = arguments.optString("action").trim()
        if (action == "status") {
            val states = listOf(LocalRuntimeId.Termux).associateWith { runtimeId ->
                runtimeRouter.runtimeById(runtimeId).inspectSetup()
            }
            return JSONObject().apply {
                put("ok", true)
                put("action", "status")
                put("runtime", currentRuntimeId.storageValue)
                put("cwd", workspaceDirectory)
                put("available", JSONObject().apply {
                    states.forEach { (runtimeId, state) -> put(runtimeId.storageValue, state.isReady) }
                })
            }.toString()
        }
        if (action != "set") {
            return ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.INVALID_ARGUMENTS,
                    "action must be 'status' or 'set'.",
                ),
                "arix_runtime_manage",
            ).toString()
        }
        val requested = LocalRuntimeId.fromStorage(arguments.optString("runtime"))
            ?: return ArixToolContract.withTool(
                ArixToolContract.failure(ArixToolContract.INVALID_ARGUMENTS, "runtime must be 'termux'."),
                "arix_runtime_manage",
            ).toString()
        if (requested != LocalRuntimeId.Termux) {
            return ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.INVALID_ARGUMENTS,
                    "Termux is the only local runtime.",
                ),
                "arix_runtime_manage",
            ).toString()
        }
        val setup = runtimeRouter.runtimeById(requested).inspectSetup()
        val enabled = settings.enabledRuntimeIds.isEmpty() || requested in settings.enabledRuntimeIds
        if (!setup.isReady || !enabled) {
            return JSONObject().apply {
                put("ok", false)
                put("errmsg", "${requested.displayName} runtime is unavailable.")
                put("detail", setup.detail)
                put("runtime", currentRuntimeId.storageValue)
                put("cwd", workspaceDirectory)
            }.toString()
        }
        onRuntimeChanged(requested)
        return JSONObject().apply {
            put("ok", true)
            put("action", "set")
            put("runtime", requested.storageValue)
            put("cwd", workspaceDirectory)
        }.toString()
    }

    private suspend fun executeEnsurePackage(
        argumentsJson: String,
        onProgress: (suspend (String) -> Unit)? = null,
    ): String {
        val toolName = "arix_ensure_package"
        val runtime = termuxRuntime
            ?: return ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.TOOL_UNAVAILABLE,
                    "The Termux runtime is not available in this build.",
                ),
                toolName,
            ).toString()
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            ?: return ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.INVALID_ARGUMENTS,
                    "Arguments were not valid JSON.",
                ),
                toolName,
            ).toString()
        val command = arguments.optString("command").trim()
        if (command.isEmpty() || !command.matches(Regex("[A-Za-z0-9._+-]{1,64}"))) {
            return ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.INVALID_ARGUMENTS,
                    "Provide the missing 'command' name (a single executable token, e.g. \"python\").",
                ),
                toolName,
            ).toString()
        }
        val confirm = arguments.optBoolean("confirm", false)
        val explicitPackages = arguments.optJSONArray("packages")
            ?.let { array -> (0 until array.length()).map { array.optString(it).trim() } }
            ?.filter { it.isNotEmpty() && it.matches(Regex("[a-z0-9.+-]{1,64}")) }
            .orEmpty()

        val status = runCatching { runtime.isCommandAvailable(command) }
            .getOrElse { throwable ->
                return ArixToolContract.withTool(
                    ArixToolContract.failure(
                        ArixToolContract.TOOL_UNAVAILABLE,
                        "Unable to probe the Termux runtime: ${throwable.message ?: "unknown error"}.",
                    ),
                    toolName,
                ).toString()
            }
        if (status.installed) {
            return ArixToolContract.withTool(
                JSONObject().apply {
                    put("ok", true)
                    put("installed", true)
                    put("command", command)
                    put("version", status.versionOutput)
                    put(
                        "message",
                        "'$command' IS installed in the Termux environment" +
                            (
                                if (status.versionOutput.isNotBlank()) {
                                    " (${status.versionOutput})"
                                } else {
                                    ""
                                }
                                ) +
                            " — the same environment the Console tab uses. Continue the task with it.",
                    )
                },
                toolName,
            ).toString()
        }

        val packages = explicitPackages.ifEmpty {
            listOfNotNull(com.arix.app.runtime.termuxCommandToPackage(command))
        }
        if (packages.isEmpty()) {
            return ArixToolContract.withTool(
                JSONObject().apply {
                    put("ok", false)
                    put("installed", false)
                    put("command", command)
                    put("known_package", false)
                    put(
                        "errmsg",
                        "'$command' is not installed and no official Termux package is mapped for it. " +
                            "Find the package name yourself (bash: pkg search <name> or " +
                            "apt-cache search <name>), then call this tool again with packages=[<name>] " +
                            "after the user confirms.",
                    )
                },
                toolName,
            ).toString()
        }

        if (!confirm) {
            return ArixToolContract.withTool(
                JSONObject().apply {
                    put("ok", true)
                    put("installed", false)
                    put("needs_confirmation", true)
                    put("command", command)
                    put("known_package", true)
                    put("packages", JSONArray(packages))
                    put(
                        "message",
                        "'$command' is not installed in the shared Termux environment. Installing " +
                            "Termux package(s) ${packages.joinToString(" + ")} adds exactly this " +
                            "dependency (nothing else). Tell the user, then call this tool again with " +
                            "confirm=true ONLY after they approve. The install runs in the same " +
                            "environment as the Console (pkg/apt) and is verified afterwards.",
                    )
                },
                toolName,
            ).toString()
        }

        onProgress?.invoke(
            JSONObject().apply {
                put("ok", true)
                put("phase", "installing")
                put("command", command)
                put("packages", JSONArray(packages))
            }.toString(),
        )
        val installState = kotlinx.coroutines.coroutineScope {
            runCatching {
                runtime.installPackages(
                    packages = packages,
                    label = command,
                    verifyCommands = listOf(command),
                    onProgress = { progress ->
                        launch {
                            onProgress?.invoke(
                                JSONObject().apply {
                                    put("ok", true)
                                    put("phase", "installing")
                                    put("command", command)
                                    put("packages", JSONArray(packages))
                                    put("output", progress.output)
                                    put("activity", progress.activity.name)
                                }.toString(),
                            )
                        }
                    },
                )
            }.getOrElse { throwable ->
                return@coroutineScope ArixToolContract.failure(
                    ArixToolContract.TOOL_UNAVAILABLE,
                    "Termux package installation failed: ${throwable.message ?: "unknown error"}.",
                )
            }
        }
        val verifiedStatus = runCatching { runtime.isCommandAvailable(command) }
            .getOrNull()
        return if (installState is com.arix.app.runtime.LocalRuntimeSetupState &&
            installState.isReady &&
            verifiedStatus?.installed == true
        ) {
            ArixToolContract.withTool(
                JSONObject().apply {
                    put("ok", true)
                    put("installed", true)
                    put("verified", true)
                    put("command", command)
                    put("packages", JSONArray(packages))
                    put("version", verifiedStatus.versionOutput)
                    put(
                        "message",
                        "Installed ${packages.joinToString(" + ")} in the shared Termux environment; " +
                            "'$command' is verified available" +
                            (
                                if (verifiedStatus.versionOutput.isNotBlank()) {
                                    " (${verifiedStatus.versionOutput})"
                                } else {
                                    ""
                                }
                                ) +
                            ". Continue the task.",
                    )
                },
                toolName,
            ).toString()
        } else {
            val failureDetail = (installState as? com.arix.app.runtime.LocalRuntimeSetupState)
                ?.detail
                .orEmpty()
            ArixToolContract.withTool(
                JSONObject().apply {
                    put("ok", false)
                    put("installed", false)
                    put("verified", false)
                    put("command", command)
                    put("packages", JSONArray(packages))
                    put("errmsg", failureDetail.ifBlank { "The package install did not verify." })
                },
                toolName,
            ).toString()
        }
    }

    private suspend fun executeFileShareTool(
        argumentsJson: String,
        workspaceDirectory: String,
        onProgress: (suspend (String) -> Unit)? = null,
    ): String {
        val toolName = "arix_file_share"
        val runtime = termuxRuntime
            ?: return ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.TOOL_UNAVAILABLE,
                    "The file-transfer runtime is not available in this build.",
                ),
                toolName,
            ).toString()
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            ?: return ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.INVALID_ARGUMENTS,
                    "Arguments were not valid JSON.",
                ),
                toolName,
            ).toString()
        val requestedFile = (arguments.optString("file").ifBlank { arguments.optString("path") }).trim()
        if (requestedFile.isEmpty()) {
            return ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.INVALID_ARGUMENTS,
                    "Provide the 'file' to share: a workspace path (/workspace/report.pdf, " +
                        "report.pdf) or a device-storage path (/device/Download/clip.mp4).",
                ),
                toolName,
            ).toString()
        }
        val server = ArixFileShareClient.normalizeServerId(arguments.optString("server").ifBlank { null })
        val serverLabel = ArixFileShareClient.serverLabel(server)

        val candidates = buildList {
            if (requestedFile.startsWith("/")) {
                add(requestedFile)
            } else {
                val root = workspaceDirectory.takeIf { it.isNotBlank() } ?: "/workspace"
                add("${root.trimEnd('/')}/$requestedFile")
                add("${root.trimEnd('/')}/uploads/$requestedFile")
            }
        }
        val resolved = candidates.firstNotNullOfOrNull { candidate ->
            runCatching { runtime.resolveGuestPath(candidate) }.getOrNull()
                ?.takeIf { it.isFile }
        } ?: return ArixToolContract.withTool(
            ArixToolContract.failure(
                ArixToolContract.INVALID_ARGUMENTS,
                buildString {
                    append("No file found for '")
                    append(requestedFile)
                    append("'. Looked in: ")
                    append(candidates.joinToString(", "))
                    append(". Check the path with ls, then retry.")
                },
            ),
            toolName,
        ).toString()
        val fileName = resolved.name
        val totalBytes = resolved.length()

        ArixUploadProgressBus.noteStarted(fileName, serverLabel, totalBytes)
        onProgress?.invoke(
            JSONObject()
                .put("ok", true)
                .put("status", "uploading")
                .put("file", fileName)
                .put("server", server)
                .put("percent", 0)
                .toString(),
        )

        val result = withContext(Dispatchers.IO) {
            runCatching {
                ArixFileShareClient.uploadFile(
                    file = resolved,
                    server = server,
                    onProgress = { bytesWritten, total, bytesPerSecond ->
                        ArixUploadProgressBus.noteProgress(
                            fileName = fileName,
                            serverLabel = serverLabel,
                            bytesWritten = bytesWritten,
                            totalBytes = total,
                            bytesPerSecond = bytesPerSecond,
                        )
                    },
                )
            }
        }
        return result.fold(
            onSuccess = { upload ->
                ArixUploadProgressBus.noteDone(
                    fileName = fileName,
                    serverLabel = serverLabel,
                    totalBytes = totalBytes,
                    url = upload.url,
                )
                ArixToolContract.withTool(
                    JSONObject().apply {
                        put("ok", true)
                        put("widget", "file_share")
                        put("url", upload.url)
                        put("file", fileName)
                        put("server", server)
                        put("server_label", serverLabel)
                        put("size", totalBytes)
                        put("expires", ArixFileShareClient.serverHint(server))
                        put(
                            "message",
                            "Uploaded $fileName (${ArixFileShareClient.formatBytes(totalBytes)}) to " +
                                "$serverLabel — the direct link is ready in the chat card.",
                        )
                    },
                    toolName,
                ).toString()
            },
            onFailure = { throwable ->
                ArixUploadProgressBus.noteFailed(
                    fileName = fileName,
                    serverLabel = serverLabel,
                    errorMessage = throwable.message ?: "The upload failed.",
                )
                ArixToolContract.withTool(
                    ArixToolContract.failure(
                        "UPLOAD_FAILED",
                        throwable.message ?: "The upload failed. Try another server or a smaller file.",
                    ),
                    toolName,
                ).toString()
            },
        )
    }

    suspend fun hostToolDefinitionsForTurn(
        selfManagementTool: ArixSelfManagementTool? = null,
        allowSwarmTool: Boolean = true,
        contextTier: ArixContextTier = ArixContextTier.Standard,
        turnUserText: String = "",
    ): JSONArray {
        var base = hostToolDefinitions(selfManagementTool)
        mcpManager?.let { manager ->
            val mcpDefinitions = manager.toolDefinitions()
            for (index in 0 until mcpDefinitions.length()) {
                mcpDefinitions.optJSONObject(index)?.let(base::put)
            }
        }
        val mcpRequested = turnUserText.isNotBlank() && runCatching {
            val connected = mcpManager?.statuses?.value
                ?.filter { it.state == com.arix.app.mcp.ArixMcpServerStatus.State.CONNECTED }
                ?.map { it.name }
                .orEmpty()
            connected.isNotEmpty() && (
                turnUserText.contains("mcp", ignoreCase = true) ||
                    connected.any { name ->
                        turnUserText.contains(name, ignoreCase = true)
                    }
                )
        }.getOrDefault(false)
        if (!allowSwarmTool) {
            val filtered = JSONArray()
            for (index in 0 until base.length()) {
                val definition = base.optJSONObject(index) ?: continue
                if (definition.optString("name") == "arix_swarm") continue
                filtered.put(definition)
            }
            base = filtered
        }
        val advertisedNames = ArixDynamicContextPolicy.hostToolNamesFor(
            tier = contextTier,
        )
        if (advertisedNames != null) {
            val filtered = JSONArray()
            for (index in 0 until base.length()) {
                val definition = base.optJSONObject(index) ?: continue
                val name = definition.optString("name")
                if (name in advertisedNames ||
                    (mcpRequested && name.startsWith("mcp__"))
                ) {
                    filtered.put(definition)
                }
            }
            return filtered
        }
        return base
    }

    fun beginSupervisedTurn(sessionId: String, objective: String) {
        supervisor.beginTurn(sessionId, objective)
    }

    fun beginBrowserResearchTurn(sessionId: String) {
        runCatching { com.arix.app.browser.ArixBrowserResearch.beginTurn(sessionId) }
    }

    fun endSupervisedTurn(sessionId: String) {
        supervisor.endTurn(sessionId)
    }

    private fun executeTasks(argumentsJson: String, sessionId: String?): String {
        val toolName = "arix_tasks"
        fun fail(code: String, message: String) =
            ArixToolContract.withTool(ArixToolContract.failure(code, message), toolName).toString()
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            ?: return fail(ArixToolContract.INVALID_ARGUMENTS, "Arguments were not valid JSON.")
        if (sessionId == null) return fail(ArixToolContract.TOOL_UNAVAILABLE, "No active turn.")
        val plan = when (arguments.optString("action")) {
            "set" -> {
                val array = arguments.optJSONArray("tasks")
                val titles = if (array == null) emptyList() else (0 until array.length()).map { array.optString(it) }
                if (titles.none { it.isNotBlank() }) {
                    return fail(ArixToolContract.INVALID_ARGUMENTS, "action=set needs a non-empty tasks array.")
                }
                supervisor.setPlan(sessionId, titles)
            }
            "update" -> {
                val status = arguments.optString("status")
                if (status !in setOf(
                        ArixAgentSupervisor.StatusPending,
                        ArixAgentSupervisor.StatusInProgress,
                        ArixAgentSupervisor.StatusCompleted,
                    )
                ) {
                    return fail(ArixToolContract.INVALID_ARGUMENTS, "status must be pending, in_progress or completed.")
                }
                supervisor.updatePlan(sessionId, arguments.optInt("id", -1), status)
                    ?: return fail(ArixToolContract.TARGET_NOT_FOUND, "No plan step with that id; call action=set first.")
            }
            else -> return fail(ArixToolContract.INVALID_ARGUMENTS, "action must be set or update.")
        } ?: return fail(ArixToolContract.TOOL_UNAVAILABLE, "No active turn.")
        val result = JSONObject()
            .put("checklist", supervisor.planChecklist(plan))
            .put("remaining", plan.count { it.status != ArixAgentSupervisor.StatusCompleted })
        return ArixToolContract.withTool(ArixToolContract.success(result, verified = true), toolName).toString()
    }

    fun supervisorStateBlock(sessionId: String): String? =
        supervisor.compactStateBlock(sessionId)

    companion object {

        val hostToolNames: Set<String> = setOf(
            "media_search",
            "browser",
            "phone",
            ArixWebAccessTool.ToolNameSearch,
            ArixWebAccessTool.ToolNameFetch,
            ArixWebScrapeTool.ToolName,
            "arix_swarm",
            "arix_projects",
            "upi_pay",
            "arix_ensure_package",
            "arix_file_share",
            "arix_memory",
            "arix_diagnostics",
            "arix_tasks",
            "arix_runtime_manage",
            *SelfManagementToolNames.toTypedArray(),
        )

        private val RegistryValidatedToolNames = setOf(
            ArixWebAccessTool.ToolNameSearch,
            ArixWebAccessTool.ToolNameFetch,
            ArixWebScrapeTool.ToolName,
            "media_search",
            "phone",
            "arix_swarm",
            "arix_projects",
            "arix_memory",
            "arix_diagnostics",
            "arix_ensure_package",
            "arix_file_share",
        )

        private const val MaxIdenticalFailures = 2
        private const val FailureWindowMillis = 10 * 60_000L
        private const val TrackerCapacity = 128

        fun supports(toolName: String): Boolean =
            toolName in hostToolNames ||
                toolName.startsWith("mcp__")

        fun hostToolDefinitions(
            selfManagementTool: ArixSelfManagementTool? = null,
        ): JSONArray = JSONArray().apply {
            put(mediaSearchToolDefinition())
            put(browserToolDefinition())
            put(phoneToolDefinition())
            put(ArixWebAccessTool.searchToolDefinition())
            put(ArixWebAccessTool.fetchToolDefinition())
            put(ArixWebScrapeTool.toolDefinition())
            put(swarmToolDefinition())
            put(projectsToolDefinition())
            put(upiPayToolDefinition())
            put(ensurePackageToolDefinition())
            put(fileShareToolDefinition())
            put(arixMemoryToolDefinition())
            put(arixDiagnosticsToolDefinition())
            put(arixTasksToolDefinition())
            selfManagementTool?.toolDefinitions()?.forEach { definition ->
                put(
                    flattenOpenAiToolDefinition(
                        definition = definition,
                        executionMode = if (
                            definition.optJSONObject("function")?.optString("name") == "arix_config_get"
                        ) "parallel" else "sequential",
                    ),
                )
            }
        }

        fun inferToolOutputOk(output: String): Boolean {
            if (output.isBlank()) return false
            val parsed = runCatching { JSONObject(output) }.getOrNull() ?: return false
            return parsed.optBoolean("ok", false)
        }

        fun requiresDestructiveCommandConfirmation(command: String): Boolean {
            val normalized = command.trim()
            if (normalized.isEmpty()) return false
            val statements = normalized.split(DestructiveStatementSeparator)
                .map(String::trim)
                .filter(String::isNotEmpty)
            val commandTokens = statements.map { it.destructiveCommandToken() }
            for (index in statements.indices) {
                val current = commandTokens[index] ?: continue
                val next = commandTokens.getOrNull(index + 1) ?: continue
                if ((current == "curl" || current == "wget") && next in DestructiveShellCommands) {
                    return true
                }
            }
            statements.forEach { statement ->
                if (destructiveStatementMatches(statement)) return true
            }
            return false
        }

        private class DestructiveTokens(
            val commandToken: String,
            val args: List<String>,
        )

        private fun String.destructiveTokens(): DestructiveTokens? {
            val tokens = replace("'", "").replace("\"", "")
                .split(Regex("\\s+"))
                .filter { it.isNotEmpty() }
            if (tokens.isEmpty()) return null
            var index = 0
            var skippingXargsFlags = false
            while (index < tokens.size) {
                val token = tokens[index]
                when {
                    DestructiveEnvAssignment.matches(token) || token == "sudo" -> index += 1
                    token == "xargs" -> {
                        index += 1
                        skippingXargsFlags = true
                    }
                    skippingXargsFlags && token.startsWith("-") -> index += 1
                    else -> break
                }
            }
            if (index >= tokens.size) return null
            return DestructiveTokens(
                commandToken = tokens[index].substringAfterLast('/'),
                args = tokens.subList(index + 1, tokens.size),
            )
        }

        private fun String.destructiveCommandToken(): String? = destructiveTokens()?.commandToken

        private fun destructiveStatementMatches(statement: String): Boolean {
            if (DestructiveForkBombSignature.containsMatchIn(statement)) return true
            val tokens = statement.destructiveTokens() ?: return false
            return when {
                tokens.commandToken == "rm" -> destructiveRmMatches(tokens.args)
                tokens.commandToken == "mkfs" || tokens.commandToken.startsWith("mkfs.") -> true
                tokens.commandToken == "dd" -> tokens.args.any { it.startsWith("of=/dev/") }
                tokens.commandToken == "chmod" || tokens.commandToken == "chown" -> {
                    val recursive = tokens.args.any { it == "-R" || it == "-r" || it == "--recursive" }
                    val targetsRoot = tokens.args.any { it == "/" || it == "/*" }
                    recursive && targetsRoot
                }
                else -> false
            }
        }

        private fun destructiveRmMatches(args: List<String>): Boolean {
            var recursive = false
            var force = false
            var noPreserveRoot = false
            var endOfFlags = false
            val operands = mutableListOf<String>()
            for (arg in args) {
                if (!endOfFlags && arg == "--") {
                    endOfFlags = true
                    continue
                }
                if (!endOfFlags && arg.startsWith("--")) {
                    when (arg) {
                        "--recursive" -> recursive = true
                        "--force" -> force = true
                        "--no-preserve-root" -> noPreserveRoot = true
                    }
                    continue
                }
                if (!endOfFlags && arg.length > 1 && arg.startsWith("-")) {
                    if (arg.any { it == 'r' || it == 'R' }) recursive = true
                    if (arg.any { it == 'f' }) force = true
                    continue
                }
                operands += arg
            }
            if (!recursive) return false
            if (!force && !noPreserveRoot) return false
            return operands.any { operand ->
                when (operand) {
                    "/", "/*",
                    "/device", "/device/", "/device/*",
                    "~", "~/", "~/*",
                    "\$HOME", "\$HOME/*",
                    "\${HOME}", "\${HOME}/*" -> true
                    else -> false
                }
            }
        }

        private val DestructiveForkBombSignature = Regex("^\\s*:\\s*\\(\\s*\\)\\s*\\{")

        private val DestructiveShellCommands = setOf("sh", "bash", "zsh", "dash", "ksh")

        private val DestructiveStatementSeparator = Regex("[;|&\\r\\n]")

        private val DestructiveEnvAssignment = Regex("^[A-Za-z_][A-Za-z0-9_]*=")
    }
}

private val SelfManagementToolNames = setOf(
    "arix_config_get",
    "arix_config_set",
    "arix_skill_manage",
    "arix_scheduled_task_manage",
    "arix_developer_manage",
)

private fun unavailableToolOutput(toolName: String): String = JSONObject()
    .put("ok", false)
    .put("errmsg", "Host dependency for '$toolName' is not available.")
    .toString()

private fun flattenOpenAiToolDefinition(
    definition: JSONObject,
    executionMode: String,
): JSONObject {
    val function = definition.optJSONObject("function") ?: JSONObject()
    return JSONObject().apply {
        put("name", function.optString("name"))
        put("description", function.optString("description"))
        put("parameters", relaxStrictOptionalParameters(function.optJSONObject("parameters")))
        put("execution_mode", executionMode)
    }
}

private fun relaxStrictOptionalParameters(parameters: JSONObject?): JSONObject {
    val relaxed = JSONObject((parameters ?: JSONObject().put("type", "object")).toString())
    val properties = relaxed.optJSONObject("properties") ?: return relaxed
    val required = relaxed.optJSONArray("required") ?: return relaxed
    relaxed.put("required", JSONArray().apply {
        for (index in 0 until required.length()) {
            val name = required.optString(index)
            if (name.isNotBlank() && !properties.optJSONObject(name).allowsNull()) put(name)
        }
    })
    return relaxed
}

private fun JSONObject?.allowsNull(): Boolean = when (val type = this?.opt("type")) {
    "null" -> true
    is JSONArray -> (0 until type.length()).any { type.optString(it) == "null" }
    else -> false
}

private fun inferMediaKindFromQuery(query: String): com.arix.app.media.ArixMediaKind {
    val text = query.lowercase().trim()
    return when {
        MovieKindPattern.containsMatchIn(text) -> com.arix.app.media.ArixMediaKind.Movie
        AudioKindPattern.containsMatchIn(text) -> com.arix.app.media.ArixMediaKind.Audio
        MusicKindPattern.containsMatchIn(text) -> com.arix.app.media.ArixMediaKind.Music
        VideoKindPattern.containsMatchIn(text) -> com.arix.app.media.ArixMediaKind.Video
        else -> com.arix.app.media.ArixMediaKind.Video
    }
}

private val MovieKindPattern = Regex(
    """\b(?:movie|movies|film|films|full\s+movie|cinema|watch\s+online|hd\s+print)\b""",
)

private val MusicKindPattern = Regex(
    """\b(?:song|songs|music|track|album|mixtape|playlist|remix|lofi)\b""",
)

private val AudioKindPattern = Regex(
    """\b(?:podcast|audiobook|audio\s+only|sound\s+of|soundtrack|instrumental)\b""",
)

private val VideoKindPattern = Regex(
    """\b(?:video|videos|clip|clips|trailer|episode|ep\s*\d+|watch)\b""",
)

internal fun mediaSearchToolDefinition(): JSONObject = JSONObject().apply {
    put("name", "media_search")
    put(
        "description",
        "Search playable media (music/songs/videos/movies) or resolve media from a URL/site. " +
            "Results come back as tappable PLAY CARDS; the user taps one and it plays in Arix's " +
            "native player. Use for any play/watch/listen request. Movies: scraped from the " +
            "free-movie streaming site; 'latest/new movies' or opening the movie site returns its " +
            "HOMEPAGE MOVIE LIST (newest releases); when a movie is NOT found there, answer " +
            "the user YOURSELF from your own knowledge (exact title, a similar movie, or offer the " +
            "latest-movies list) — never scrape or invent links from other websites. Adult (18+) " +
            "requests go to permitted public adult tube sites with direct streams; songs/videos " +
            "from open catalogs; direct media URLs (.mp3/.mp4/.m3u8/.mpd) resolve natively; any " +
            "named public site is scraped generically (HTML5 media, og:video, JSON-LD, embeds, " +
            "packer-encoded players). ALWAYS set 'kind' accurately: movie for films (also for " +
            "latest-movies: query='latest movies'), music for songs, video for clips. If media " +
            "is protected, say so and suggest the browser tool.",
    )
    put("parameters", JSONObject().apply {
        put("type", "object")
        put("properties", JSONObject().apply {
            put("query", JSONObject().put("type", "string").put(
                "description",
                "Natural-language media query ('sad song', 'interstellar full movie').",
            ))
            put("kind", JSONObject().put("type", "string").put(
                "description",
                "'movie' (films/full-film sites), 'music' (songs), 'audio' (podcasts), 'video' " +
                    "(clips). Inferred from the query when omitted.",
            ))
            put("url", JSONObject().put("type", "string").put(
                "description", "Direct media URL or page URL to resolve ('play this URL').",
            ))
            put("site", JSONObject().put("type", "string").put(
                "description", "A specific site (domain/URL) to find media on.",
            ))
            put("limit", JSONObject().put("type", "integer").put(
                "description", "Max results (1-24, default 12).",
            ))
            put("allow_adult", JSONObject().put("type", "boolean").put(
                "description",
                "true for adult (18+) requests; defaults to the unrestricted-mode setting.",
            ))
        })
        put("required", JSONArray().put("query"))
        put("additionalProperties", false)
    })
    put("execution_mode", "sequential")
}

internal fun browserToolDefinition(): JSONObject = JSONObject().apply {
    put("name", "browser")
    put(
        "description",
        "Drive Arix's built-in WebView browser: load JS pages, read content, interact with " +
            "the DOM, screenshot, extract media and network APIs. Automation runs INVISIBLY " +
            "in the background — no screen opens; the user can watch live in the Browser tab " +
            "anytime; keep working either way. One call = one action. Flow: navigate → " +
            "wait_for_selector (settle) → find_elements (by element_text label, e.g. 'New " +
            "post', 'Publish') → click/type → VERIFY → screenshot for the user. TARGETING: " +
            "element_text matches visible text/aria-label/placeholder/label (shadow-DOM " +
            "aware); a selector from find_elements also works; coordinates are viewport CSS " +
            "pixels. Actions: navigate(url); get_readable(markdown, offset pagination); " +
            "get_text(raw, optional selector); find_elements(up to 24; selector or " +
            "element_text search); click(element_text/selector/coordinates; reports " +
            "url_before/navigation_occurred); type(text + target, clear_first, submit; real " +
            "editing pipeline incl. contenteditable; returns a verification read-back); " +
            "scroll(up/down amount, or element_text into view); screenshot(viewport image " +
            "card); get_page_info(viewport/scroll/canonical url); go_back; go_forward; " +
            "reload; wait_for_selector(selector, timeout_ms); wait_for_text(text, " +
            "timeout_ms — polls until the confirmation appears; THE way to prove a side " +
            "effect); extract_media(all media URLs); get_network_log(API/XHR/fetch " +
            "endpoints; filter substring, only_api=false for all resources); " +
            "inspect_element(element_text/selector/coordinates → attributes, outerHTML, " +
            "styles). MANDATORY VERIFICATION DISCIPLINE: VERIFY side effects before claiming " +
            "success — wait_for_text for the confirmation, navigation_occurred/URL change, the " +
            "item in a listing, or the type read-back verified=true — else retry differently and " +
            "report the actual state. Rules: navigate before any other action; find_elements " +
            "BEFORE click/type for a reliable target; USER_TOUCH_ACTIVE means the user's fingers " +
            "are on the page RIGHT NOW — wait a few seconds and RETRY; never give up mid-task " +
            "because of it.",
    )
    put("parameters", JSONObject().apply {
        put("type", "object")
        put("properties", JSONObject().apply {
            put("action", JSONObject().put("type", "string").put(
                "description",
                "One of: navigate, get_readable, get_text, find_elements, click, type, " +
                    "scroll, screenshot, get_page_info, go_back, go_forward, reload, " +
                    "wait_for_selector, wait_for_text, extract_media, get_network_log, " +
                    "inspect_element."
            ))
            put("url", JSONObject().put("type", "string").put(
                "description", "Full http(s) URL — required for navigate."
            ))
            put("selector", JSONObject().put("type", "string").put(
                "description", "CSS selector (click/type/scroll/get_text/wait_for_selector). Use one from find_elements for reliability."
            ))
            put("element_text", JSONObject().put("type", "string").put(
                "description", "Label targeting (preferred): the element's visible text, aria-label, placeholder or label ('New post', 'Publish'). For find/click/type/scroll/inspect_element."
            ))
            put("coordinate_x", JSONObject().put("type", "integer").put(
                "description", "X viewport coordinate (with coordinate_y) as click target."
            ))
            put("coordinate_y", JSONObject().put("type", "integer").put(
                "description", "Y viewport coordinate (with coordinate_x) as click target."
            ))
            put("text", JSONObject().put("type", "string").put(
                "description", "type: the text to type. wait_for_text: the confirmation text. click/find_elements without element_text: treated as the label."
            ))
            put("submit", JSONObject().put("type", "boolean").put(
                "description", "type: also submit the form (Enter / requestSubmit)."
            ))
            put("clear_first", JSONObject().put("type", "boolean").put(
                "description", "type: clear the field first (otherwise the full value is set in ONE action)."
            ))
            put("direction", JSONObject().put("type", "string").put(
                "description", "scroll: 'up' or 'down' (default down)."
            ))
            put("amount", JSONObject().put("type", "integer").put(
                "description", "scroll: pixels (default 600, max 5000)."
            ))
            put("offset", JSONObject().put("type", "integer").put(
                "description", "get_readable/get_text: character offset for pagination."
            ))
            put("max_chars", JSONObject().put("type", "integer").put(
                "description", "get_readable/get_text: max characters (256-12000)."
            ))
            put("timeout_ms", JSONObject().put("type", "integer").put(
                "description", "navigate/wait_for_selector/wait_for_text timeout in ms (navigate max 25000, waits max 30000)."
            ))
            put("read_image", JSONObject().put("type", "boolean").put(
                "description", "screenshot: true (default) attaches the image; false returns metadata only."
            ))
            put("filter", JSONObject().put("type", "string").put(
                "description", "get_network_log: optional case-insensitive URL substring filter."
            ))
            put("only_api", JSONObject().put("type", "boolean").put(
                "description", "get_network_log: true (default) keeps XHR/fetch/JSON endpoints; false lists every resource."
            ))
        })
        put("required", JSONArray().put("action"))
        put("additionalProperties", false)
    })
    put("execution_mode", "sequential")
}

/**
 * v3.1.15 — the phone tool (Mika's background-screen agent protocol, ported):
 * operates ANY app on a separate background virtual display while the user keeps
 * using their phone — the small live view in the chat shows what it is doing.
 * Reads the screen like a person (accessibility text + tap targets), taps,
 * types, scrolls; no app APIs, no per-app integration.
 */
internal fun phoneToolDefinition(): JSONObject = JSONObject().apply {
    put("name", "phone")
    put(
        "description",
        "Operate the user's phone apps on a hidden BACKGROUND screen (the user's own screen is " +
            "never taken over; they can watch via the small live view in the chat). Works with ANY " +
            "installed app by reading the screen and finding buttons the way a person does — no app " +
            "APIs. The background screen appears automatically on the first open_app. Typical flow: " +
            "list_apps → open_app → read_screen (get text + element refs/bounds) → tap/type → " +
            "read_screen/screenshot to VERIFY → finish. Actions: list_apps; open_app(package, cold) " +
            "opens the app on the background screen; read_screen returns visible text lines plus " +
            "elements (ref, text, clickable/editable/scrollable, bounds in screen pixels); " +
            "read_ocr reads on-screen text from pixels with on-device OCR (for custom-drawn UIs " +
            "the accessibility tree cannot read); " +
            "screenshot(read_image) attaches a PNG of the background screen; tap(x, y); double_tap; " +
            "type(text, optional x/y to focus a field first); clear_text; scroll(down=true|false); " +
            "swipe(x1,y1,x2,y2,duration_ms); back; home; key(key_code); wait_stable(timeout_ms) " +
            "waits for the screen to settle; needs_user(reason) flags that the user must act " +
            "(login, verification code, payment — the live view turns orange); finish(keep[], " +
            "close[]) ends the phone session: keep = apps to leave running in the background, " +
            "close = apps to close. VERIFY after every state change with read_screen or " +
            "screenshot. Coordinates are in background-screen pixels (read_screen reports width/" +
            "height). One call = one action.",
    )
    put("parameters", JSONObject().apply {
        put("type", "object")
        put("properties", JSONObject().apply {
            put("action", JSONObject().put("type", "string").put(
                "description",
                "One of: list_apps, open_app, read_screen, read_ocr, screenshot, tap, double_tap, type, " +
                    "clear_text, scroll, swipe, back, home, key, wait_stable, needs_user, finish.",
            ))
            put("package", JSONObject().put("type", "string").put(
                "description", "open_app: the app's package name (from list_apps).",
            ))
            put("cold", JSONObject().put("type", "boolean").put(
                "description", "open_app: restart the app first (fresh state). Default false.",
            ))
            put("x", JSONObject().put("type", "integer").put(
                "description", "Tap/type target X in background-screen pixels.",
            ))
            put("y", JSONObject().put("type", "integer").put(
                "description", "Tap/type target Y in background-screen pixels.",
            ))
            put("text", JSONObject().put("type", "string").put(
                "description", "type: the text to type. needs_user: why the user must act.",
            ))
            put("down", JSONObject().put("type", "boolean").put(
                "description", "scroll: true (default) scrolls down, false up.",
            ))
            put("x1", JSONObject().put("type", "integer").put("description", "swipe start X."))
            put("y1", JSONObject().put("type", "integer").put("description", "swipe start Y."))
            put("x2", JSONObject().put("type", "integer").put("description", "swipe end X."))
            put("y2", JSONObject().put("type", "integer").put("description", "swipe end Y."))
            put("duration_ms", JSONObject().put("type", "integer").put(
                "description", "swipe/wait duration in ms (swipe 50-3000, default 300; wait default 4000).",
            ))
            put("key_code", JSONObject().put("type", "integer").put(
                "description", "key: Android KeyEvent code (e.g. 66 enter, 61 tab).",
            ))
            put("reason", JSONObject().put("type", "string").put(
                "description", "needs_user: short reason shown to the user.",
            ))
            put("keep", JSONObject().put("type", "array").put(
                "description", "finish: package names to keep running in the background.",
            ))
            put("close", JSONObject().put("type", "array").put(
                "description", "finish: package names to close when the session ends.",
            ))
            put("read_image", JSONObject().put("type", "boolean").put(
                "description", "screenshot: true (default) attaches the PNG; false returns metadata only.",
            ))
        })
        put("required", JSONArray().put("action"))
        put("additionalProperties", false)
    })
    put("execution_mode", "sequential")
}

internal fun swarmToolDefinition(): JSONObject = JSONObject().apply {
    put("name", "arix_swarm")
    put(
        "description",
        "Split a task into NAMED sub-agents running in PARALLEL, each with its own context " +
            "and the full tool interface. Use for clearly separable parts or parallel " +
            "browsing/research. action=micro runs ONE focused sub-agent synchronously " +
            "(spawn + wait + result in one call; name/prompt/role; default 180s / 12 tool " +
            "calls) — the cheap single delegation. Multi-agent: spawn returns IMMEDIATELY " +
            "with a swarm_id; collect (default 120s, set timeout_ms) retrieves the " +
            "aggregated result — re-call to wait longer; status for live progress; stop " +
            "cancels and returns partials. The user SEES sub-agent progress live — give " +
            "agents meaningful names. Sub-agents cannot spawn further swarms. Keep each " +
            "prompt SELF-CONTAINED (they do not see this conversation).",
    )
    put("parameters", JSONObject().apply {
        put("type", "object")
        put("properties", JSONObject().apply {
            put("action", JSONObject().put("type", "string").put(
                "description", "One of: spawn (default), micro (single one-shot sub-agent), status, collect, stop.",
            ))
            put("name", JSONObject().put("type", "string").put(
                "description", "For micro: the sub-agent's display name (default 'micro-agent').",
            ))
            put("role", JSONObject().put("type", "string").put(
                "description", "For micro: the sub-agent's role (default 'general-purpose').",
            ))
            put("prompt", JSONObject().put("type", "string").put(
                "description", "For micro: the complete, self-contained task for the sub-agent.",
            ))
            put("agents", JSONObject().put("type", "array").put(
                "description", "For spawn: 1-4 sub-agents, each {name, role, prompt}.",
            ).put("items", JSONObject().put("type", "object").put("properties", JSONObject().apply {
                put("name", JSONObject().put("type", "string"))
                put("role", JSONObject().put("type", "string"))
                put("prompt", JSONObject().put("type", "string"))
            })))
            put("swarm_id", JSONObject().put("type", "string").put(
                "description", "For status/collect/stop: the swarm id from a spawn result.",
            ))
            put("timeout_ms", JSONObject().put("type", "integer").put(
                "description", "spawn: per-agent timeout ms (30000-600000, default 300000). collect: wait before returning partials (default 120000). micro: overall timeout (default 180000).",
            ))
            put("max_tool_calls", JSONObject().put("type", "integer").put(
                "description", "spawn: per-agent tool-call budget (5-80, default 40). micro: default 12.",
            ))
        })
        put("additionalProperties", false)
    })
    put("execution_mode", "sequential")
}

internal fun projectsToolDefinition(): JSONObject = JSONObject().apply {
    put("name", "arix_projects")
    put(
        "description",
        "Project workspaces: persistent containers grouping conversations, files, memories, " +
            "research, missions and agents around one effort. Use for 'my project', scoping " +
            "work, or what belongs to a project. actions: list; create (name[, description] — " +
            "unique names); inspect (project_id or name); delete (project_id, confirm=true " +
            "after user confirmation — memories are unlinked, not deleted).",
    )
    put("parameters", JSONObject().apply {
        put("type", "object")
        put("properties", JSONObject().apply {
            put("action", JSONObject().put("type", "string").put(
                "description", "One of: list, create, inspect, delete.",
            ))
            put("name", JSONObject().put("type", "string").put(
                "description", "Project name (create/inspect).",
            ))
            put("description", JSONObject().put("type", "string").put(
                "description", "For create: what this project is about.",
            ))
            put("project_id", JSONObject().put("type", "string").put(
                "description", "Project id (inspect/delete).",
            ))
            put("confirm", JSONObject().put("type", "boolean").put(
                "description", "For delete: true after the user confirmed.",
            ))
        })
        put("additionalProperties", false)
    })
    put("execution_mode", "sequential")
}

internal fun upiPayToolDefinition(): JSONObject = JSONObject().apply {
    put("name", "upi_pay")
    put(
        "description",
        "Send money via UPI (India) by opening the native UPI payment sheet — the user picks " +
            "their app (GPay, PhonePe, Paytm, BHIM, …) and confirms inside it; Arix never " +
            "touches credentials. Call for any pay/send/transfer request ('pay 300 to " +
            "9876543210'). Extract the payee (UPI ID like name@bank OR 10-digit UPI-registered " +
            "mobile) and amount in rupees; include payee name/note when provided. If payee or " +
            "amount is missing/ambiguous, ASK — payments move real money. NEVER attempt to " +
            "automate the UPI app by any other means; the user's in-app confirmation is the " +
            "only proof of payment.",
    )
    put("parameters", JSONObject().apply {
        put("type", "object")
        put("properties", JSONObject().apply {
            put("payee", JSONObject().put("type", "string").put(
                "description",
                "Who to pay: a UPI ID / virtual payment address (like 'name@okhdfcbank') or the " +
                    "10-digit mobile number registered with UPI."
            ))
            put("amount", JSONObject().put("type", "number").put(
                "description", "Amount to pay in rupees (INR), e.g. 300."
            ))
            put("payee_name", JSONObject().put("type", "string").put(
                "description", "Optional display name of the payee (pre-fills the UPI sheet)."
            ))
            put("note", JSONObject().put("type", "string").put(
                "description", "Optional short payment note/remark (max ~50 chars)."
            ))
        })
        put("required", JSONArray().put("payee").put("amount"))
        put("additionalProperties", false)
    })
    put("execution_mode", "sequential")
}

internal fun ensurePackageToolDefinition(): JSONObject = JSONObject().apply {
    put("name", "arix_ensure_package")
    put(
        "description",
        "Task-based dependency management for the SHARED Termux environment (the same one the " +
            "Console tab uses). Call with the missing 'command': it checks command -v in the real " +
            "environment and returns the Termux package + a confirmation request; after the user " +
            "approves, call again with confirm=true — it installs ONLY that dependency, verifies " +
            "the command works, and reports. NEVER install without approval; NEVER claim a " +
            "command is missing without this tool or a bash 'command -v' proving it.",
    )
    put("parameters", JSONObject().apply {
        put("type", "object")
        put("properties", JSONObject().apply {
            put("command", JSONObject().put("type", "string").put(
                "description",
                "The missing executable name, e.g. \"python\", \"node\", \"git\", \"ffmpeg\".",
            ))
            put("confirm", JSONObject().put("type", "boolean").put(
                "description",
                "true ONLY after the user explicitly approved the installation. Omit/false returns " +
                    "the package determination and confirmation request without installing.",
            ))
            put("packages", JSONObject().put("type", "array").put(
                "description",
                "Optional explicit Termux package names (use only when you determined them via " +
                    "pkg search / apt-cache search because the command has no mapping).",
            ))
        })
        put("required", JSONArray().put("command"))
        put("additionalProperties", false)
    })
    put("execution_mode", "sequential")
}

internal fun fileShareToolDefinition(): JSONObject = JSONObject().apply {
    put("name", "arix_file_share")
    put(
        "description",
        "Upload any workspace or device file to a public server and get a direct download " +
            "link (shown to the user as a shareable card with copy/share/open actions, with a live " +
            "upload progress widget while it streams). Use whenever the user asks to share, send, " +
            "upload, host or get a link for a file. Servers: filebin (default, 6-day availability), " +
            "tmpfiles (100 MB cap, 60 days), gofile (large files, no signup), quax (30 days), " +
            "x0 (200 MB cap). If one server fails or rejects the size, retry with another.",
    )
    put("parameters", JSONObject().apply {
        put("type", "object")
        put("properties", JSONObject().apply {
            put("file", JSONObject().put("type", "string").put(
                "description",
                "The file to share: an absolute guest path (/workspace/report.pdf, " +
                    "/device/Download/clip.mp4) or a name relative to the workspace " +
                    "(report.pdf).",
            ))
            put("server", JSONObject().put("type", "string").put(
                "description",
                "Optional server id: filebin (Server 1), tmpfiles (Server 2), gofile " +
                    "(Server 3), quax (Server 4) or x0 (Server 5). Default: filebin.",
            ))
        })
        put("required", JSONArray().put("file"))
        put("additionalProperties", false)
    })
    put("execution_mode", "sequential")
}

internal fun arixTasksToolDefinition(): JSONObject = JSONObject().apply {
    put("name", "arix_tasks")
    put(
        "description",
        "Your visible task list for multi-step work (3+ steps). action=set creates the list " +
            "(the first step starts in_progress; make the LAST step 'Verify the result'); " +
            "action=update changes one step's status. Keep exactly one step in_progress, mark a " +
            "step completed only when it is truly done and checked, and update the list as you go.",
    )
    put("parameters", JSONObject().apply {
        put("type", "object")
        put("properties", JSONObject().apply {
            put("action", JSONObject().put("type", "string").put("description", "set or update."))
            put("tasks", JSONObject().put("type", "array").put(
                "items", JSONObject().put("type", "string"),
            ).put("description", "Ordered step titles (set only, max 12)."))
            put("id", JSONObject().put("type", "integer").put("description", "Step number (update only)."))
            put("status", JSONObject().put("type", "string").put(
                "description", "pending, in_progress or completed (update only).",
            ))
        })
        put("required", JSONArray().put("action"))
        put("additionalProperties", false)
    })
    put("execution_mode", "sequential")
}

internal fun arixMemoryToolDefinition(): JSONObject = JSONObject().apply {
    put("name", "arix_memory")
    put(
        "description",
        "Arix's long-term memory. Tiers: personal (durable user facts), preference (how the " +
            "user wants things done), project, conversation (session scratch), tool (learned " +
            "outcomes), ephemeral (never on disk). Actions: remember (store; use when the user " +
            "asks to remember or approves a durable fact — 'remember this' → personal), forget " +
            "(by id; bulk by query/tier REQUIRES confirm=true after approval), search " +
            "(ranked lookup), list (browse a tier), stats. NEVER store credentials, API keys " +
            "or tokens — they are refused and belong in Settings → Providers.",
    )
    put("parameters", JSONObject().apply {
        put("type", "object")
        put("properties", JSONObject().apply {
            put("action", JSONObject().put("type", "string").put(
                "description",
                "One of: remember, forget, search, list, stats.",
            ))
            put("tier", JSONObject().put("type", "string").put(
                "description",
                "Memory tier: personal, preference, project, conversation, tool, ephemeral " +
                    "(remember defaults to personal).",
            ))
            put("content", JSONObject().put("type", "string").put(
                "description",
                "The fact to store (remember only; max 400 characters — store the essence, not the transcript).",
            ))
            put("query", JSONObject().put("type", "string").put(
                "description",
                "Search text (search), or the deletion matcher (forget — deletes every matching entry).",
            ))
            put("id", JSONObject().put("type", "string").put(
                "description",
                "Exact entry id to delete (forget).",
            ))
            put("tags", JSONObject().put("type", "array").put(
                "description",
                "Optional tags for retrieval (remember only).",
            ))
            put("importance", JSONObject().put("type", "integer").put(
                "description",
                "1-5, default per tier (remember only).",
            ))
            put("limit", JSONObject().put("type", "integer").put(
                "description",
                "Max results for search/list (default 8).",
            ))
            put("confirm", JSONObject().put("type", "boolean").put(
                "description",
                "Required true for bulk forget (query/tier) AFTER the user confirmed the deletion.",
            ))
            put("session_id", JSONObject().put("type", "string").put(
                "description",
                "Current session id (optional; scopes conversation-tier entries).",
            ))
        })
        put("required", JSONArray().put("action"))
        put("additionalProperties", false)
    })
    put("execution_mode", "sequential")
}

internal fun arixDiagnosticsToolDefinition(): JSONObject = JSONObject().apply {
    put("name", "arix_diagnostics")
    put(
        "description",
        "Read-only self-diagnostic of Arix's subsystems: ai_provider, pi_bridge, " +
            "termux_runtime, memory, scheduler — each reports ok/state/detail with a summary " +
            "and the next concrete action. Call when a capability fails unexpectedly or the " +
            "user asks what is working. 'not_running'/'not_configured'/zero items are VALID " +
            "states, not faults.",
    )
    put("parameters", JSONObject().apply {
        put("type", "object")
        put("properties", JSONObject().apply {
            put("action", JSONObject().put("type", "string").put(
                "description",
                "'health' (default) — build the full health report.",
            ))
        })
        put("required", JSONArray())
        put("additionalProperties", false)
    })
    put("execution_mode", "sequential")
}
