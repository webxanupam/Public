package com.arix.app.ui

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.GestureDetector
import android.view.MotionEvent
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Android
import androidx.compose.material.icons.rounded.Archive
import androidx.compose.material.icons.rounded.Article
import androidx.compose.material.icons.rounded.Book
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.InsertDriveFile
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Slideshow
import androidx.compose.material.icons.rounded.TableView
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.view.ViewCompat
import com.arix.app.ArixApplication
import com.arix.app.R
import com.arix.app.data.LocalRuntimeId
import com.arix.app.data.RuntimeWorkspaceFileBridge
import com.arix.app.data.WorkspaceFileBridge
import com.arix.app.ui.theme.ArixBackground
import com.arix.app.ui.theme.ArixOnSurface
import com.arix.app.ui.theme.ArixOnSurfaceVariant
import com.arix.app.ui.theme.ArixOutline
import com.arix.app.ui.theme.ArixOutlineSoft
import com.arix.app.ui.theme.ArixPrimary
import com.arix.app.ui.theme.ArixTertiary
import com.arix.app.ui.theme.ArixSecondary
import com.arix.app.ui.theme.ArixSurface
import com.arix.app.ui.theme.ArixSurfaceHigh
import com.arix.app.ui.theme.ArixSurfaceVariant
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.URLDecoder
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.util.Base64
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

@Composable
internal fun MarkdownLocalFileBlock(
    path: String,
    workspaceDirectory: String?,
) {
    val context = LocalContext.current
    val appRuntime = remember(context) {
        (context.applicationContext as? ArixApplication)?.runtime
    }
    val workspaceFileBridge = remember(context, appRuntime) {
        appRuntime?.workspaceFileBridge
            ?: WorkspaceFileBridge(
                context = context,
                termuxRuntime = com.arix.app.runtime.TermuxRuntime(context),
            )
    }
    val fileName = path.substringAfterLast('/').ifBlank { "file" }
    var working by remember(path) { mutableStateOf(false) }
    var message by remember(path) { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    val fileInfo by produceState(
        initialValue = null as Pair<Long, String>?,
        key1 = path,
        key2 = workspaceDirectory,
    ) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                val resolvedPath = workspaceFileBridge.resolveWorkspacePath(
                    path = path,
                    workingDirectory = workspaceDirectory?.trim().orEmpty(),
                )
                val hostFile = appRuntime?.termuxRuntime
                    ?.resolveWorkspaceHostPath(resolvedPath)
                    ?.hostFile
                    ?: File(resolvedPath)
                if (hostFile.isFile) {
                    hostFile.length() to (workspaceFileBridge.guessMimeType(fileName).ifBlank { "application/octet-stream" })
                } else {
                    null
                }
            }.getOrNull()
        }
    }

    ArixFileResponseCard(
        fileName = fileName,
        subtitle = path,
        sizeBytes = fileInfo?.first ?: 0L,
        mimeType = fileInfo?.second ?: "application/octet-stream",
        working = working,
        message = message,
        copyValue = path,
        onDownload = {
            working = true
            message = ""
            scope.launch {
                val outcome = withContext(Dispatchers.IO) {
                    runCatching {
                        val resolvedPath = workspaceFileBridge.resolveWorkspacePath(
                            path = path,
                            workingDirectory = workspaceDirectory?.trim().orEmpty(),
                        )
                        val hostFile = appRuntime?.termuxRuntime
                            ?.resolveWorkspaceHostPath(resolvedPath)
                            ?.hostFile
                            ?: File(resolvedPath)
                        require(hostFile.isFile) { "File was not found: $path" }
                        val bytes = hostFile.readBytes()
                        ArixMediaActions.downloadToDownloads(
                            context = context,
                            fileName = fileName,
                            mimeType = fileInfo?.second ?: "application/octet-stream",
                            bytes = bytes,
                        )
                    }
                }
                working = false
                message = if (outcome.isSuccess) {
                    context.getString(R.string.markdown_media_saved_downloads)
                } else {
                    outcome.exceptionOrNull()?.message
                        ?: context.getString(R.string.markdown_image_error_read_workspace)
                }
            }
        },
        onShare = {
            working = true
            message = ""
            scope.launch {
                val outcome = withContext(Dispatchers.IO) {
                    runCatching {
                        val resolvedPath = workspaceFileBridge.resolveWorkspacePath(
                            path = path,
                            workingDirectory = workspaceDirectory?.trim().orEmpty(),
                        )
                        val hostFile = appRuntime?.termuxRuntime
                            ?.resolveWorkspaceHostPath(resolvedPath)
                            ?.hostFile
                            ?: File(resolvedPath)
                        require(hostFile.isFile) { "File was not found: $path" }
                        ArixMediaActions.stageShareFile(context, fileName, hostFile.readBytes())
                    }
                }
                working = false
                outcome.fold(
                    onSuccess = { staged ->
                        ArixMediaActions.shareStagedFile(
                            context = context,
                            file = staged,
                            mimeType = fileInfo?.second ?: "application/octet-stream",
                        )
                    },
                    onFailure = {
                        message = it.message
                            ?: context.getString(R.string.markdown_image_error_read_workspace)
                    },
                )
            }
        },
    )
}

@Composable
internal fun MarkdownRemoteFileBlock(
    url: String,
    onLinkClick: (String) -> Unit,
) {
    val context = LocalContext.current
    val fileName = remember(url) { remoteFileDisplayName(url) }
    val domain = remember(url) {
        runCatching { Uri.parse(url).host ?: url }.getOrDefault(url)
    }
    var working by remember(url) { mutableStateOf(false) }
    var message by remember(url) { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val mimeType = remember(url) { remoteFileMimeType(url) }

    ArixFileResponseCard(
        fileName = fileName,
        subtitle = domain,
        sizeBytes = 0L,
        mimeType = mimeType,
        working = working,
        message = message,
        copyValue = url,
        onDownload = {
            working = true
            message = ""
            scope.launch {
                val outcome = withContext(Dispatchers.IO) {
                    runCatching {
                        ArixMediaActions.downloadUrlToDownloads(
                            context = context,
                            url = url,
                            fileName = fileName,
                            mimeType = mimeType,
                        )
                    }
                }
                working = false
                message = outcome.fold(
                    onSuccess = { bytes ->
                        "${context.getString(R.string.widget_file_downloaded)} · ${ArixMediaActions.formatFileSize(bytes)}"
                    },
                    onFailure = { it.message ?: context.getString(R.string.widget_file_download_failed) },
                )
            }
        },
        onShare = {
            working = true
            message = ""
            scope.launch {
                val outcome = withContext(Dispatchers.IO) {
                    runCatching {
                        ArixMediaActions.stageShareUrlFile(
                            context = context,
                            url = url,
                            fileName = fileName,
                        )
                    }
                }
                working = false
                outcome.fold(
                    onSuccess = { staged ->
                        val shared = ArixMediaActions.shareStagedFile(
                            context = context,
                            file = staged,
                            mimeType = mimeType,
                        )
                        if (!shared) {
                            message = context.getString(R.string.widget_file_share_failed)
                        }
                    },
                    onFailure = { message = it.message ?: context.getString(R.string.widget_file_share_failed) },
                )
            }
        },
    )
}

@Composable
internal fun MarkdownLinkCardBlock(
    url: String,
    onLinkClick: (String) -> Unit,
) {
    val context = LocalContext.current
    val domain = remember(url) {
        runCatching { android.net.Uri.parse(url).host ?: url }.getOrDefault(url)
    }
    val sourceLabel = remember(url) { linkCardSourceLabel(url) }

    var metadata by remember(url) {
        mutableStateOf(ArixLinkPreviewStore.cachedMetadata(url) ?: ArixLinkPreviewStore.LinkMetadata(null, null))
    }
    var metadataLoading by remember(url) { mutableStateOf(metadata.title == null) }
    LaunchedEffect(url) {
        if (metadata.title == null) {
            metadata = ArixLinkPreviewStore.metadata(url)
            metadataLoading = false
        }
    }

    var favicon by remember(domain) {
        mutableStateOf(ArixLinkPreviewStore.cachedFavicon(domain))
    }
    LaunchedEffect(domain) {
        if (favicon == null) {
            favicon = ArixLinkPreviewStore.favicon(domain)
        }
    }

    var copied by remember(url) { mutableStateOf(false) }
    val clipboard = LocalClipboardManager.current
    val copiedLabel = stringResource(R.string.widget_link_copied)

    val scheme = MaterialTheme.colorScheme
    val darkCard = scheme.background.luminance() < 0.5f
    val cardShape = RoundedCornerShape(18.dp)
    val cardBackground = Brush.verticalGradient(
        listOf(
            scheme.primaryContainer.copy(alpha = if (darkCard) 0.34f else 0.55f),
            scheme.surface.copy(alpha = if (darkCard) 0.88f else 0.96f),
        ),
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(cardShape)
            .background(cardBackground)
            .border(1.dp, scheme.outline, cardShape)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(3.dp)
                .clip(RoundedCornerShape(999.dp))
                .background(
                    Brush.horizontalGradient(listOf(scheme.primary, scheme.tertiary)),
                ),
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(13.dp))
                    .background(scheme.primary.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center,
            ) {
                val iconBitmap = favicon
                if (iconBitmap != null) {
                    Image(
                        bitmap = iconBitmap.asImageBitmap(),
                        contentDescription = null,
                        modifier = Modifier.size(28.dp),
                    )
                } else {
                    val initial = domain
                        .removePrefix("www.")
                        .firstOrNull { it.isLetterOrDigit() }
                        ?.uppercaseChar()
                        ?.toString()
                        ?: "?"
                    Text(
                        text = initial,
                        style = MaterialTheme.typography.titleMedium,
                        color = scheme.primary,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
            }
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = metadata.title ?: domain.removePrefix("www."),
                        style = MaterialTheme.typography.bodyMedium,
                        color = scheme.onSurface,
                        fontWeight = FontWeight.Medium,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false),
                    )
                    if (metadataLoading) {
                        Spacer(Modifier.width(8.dp))
                        CircularProgressIndicator(
                            modifier = Modifier.size(14.dp),
                            strokeWidth = 2.dp,
                            color = scheme.primary,
                        )
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Rounded.Language,
                        contentDescription = null,
                        tint = scheme.onSurfaceVariant,
                        modifier = Modifier.size(13.dp),
                    )
                    Spacer(Modifier.width(5.dp))
                    Text(
                        text = sourceLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = scheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }

        metadata.description?.let { description ->
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = scheme.onSurfaceVariant,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
            )
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(scheme.outlineVariant.copy(alpha = 0.4f)),
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            ArixWidgetActionButton(
                label = stringResource(R.string.widget_link_open),
                icon = Icons.Rounded.OpenInNew,
                primary = true,
                modifier = Modifier.weight(1f),
                onClick = { onLinkClick(url) },
            )
            ArixWidgetActionButton(
                label = if (copied) copiedLabel else stringResource(R.string.widget_link_copy),
                icon = if (copied) Icons.Rounded.CheckCircle else Icons.Rounded.ContentCopy,
                primary = false,
                enabled = !copied,
                modifier = Modifier.weight(1f),
                onClick = {
                    clipboard.setText(androidx.compose.ui.text.AnnotatedString(url))
                    copied = true
                },
            )
            ArixWidgetActionButton(
                label = stringResource(R.string.widget_file_share),
                icon = Icons.Rounded.Share,
                primary = false,
                modifier = Modifier.weight(1f),
                onClick = { ArixMediaActions.shareText(context, url) },
            )
        }
    }
}

private data class ArixFileTypeInfo(
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val label: String,
    val tint: Color,
)

private fun fileTypeInfo(fileName: String): ArixFileTypeInfo {
    val extension = fileName.substringAfterLast('.', "").lowercase()
    return when (extension) {
        "png", "jpg", "jpeg", "gif", "webp", "bmp", "svg", "avif", "heic" ->
            ArixFileTypeInfo(Icons.Rounded.Image, "Image", Color(0xFF4E8D5A))
        "pdf" -> ArixFileTypeInfo(Icons.Rounded.PictureAsPdf, "PDF", Color(0xFFD93025))
        "zip", "rar", "7z", "tar", "gz", "tgz" ->
            ArixFileTypeInfo(Icons.Rounded.Archive, "Archive", Color(0xFFB06000))
        "mp3", "wav", "ogg", "m4a", "flac", "aac" ->
            ArixFileTypeInfo(Icons.Rounded.MusicNote, "Audio", Color(0xFF8430B8))
        "mp4", "webm", "mkv", "mov", "avi", "m4v" ->
            ArixFileTypeInfo(Icons.Rounded.Movie, "Video", Color(0xFF1A73E8))
        "apk" -> ArixFileTypeInfo(Icons.Rounded.Android, "APK", Color(0xFF3DDC84))
        "doc", "docx", "odt" -> ArixFileTypeInfo(Icons.Rounded.Description, "Document", Color(0xFF1A56B0))
        "xls", "xlsx", "csv" -> ArixFileTypeInfo(Icons.Rounded.TableView, "Sheet", Color(0xFF188038))
        "ppt", "pptx" -> ArixFileTypeInfo(Icons.Rounded.Slideshow, "Slides", Color(0xFFD93025))
        "txt", "json", "md" -> ArixFileTypeInfo(Icons.Rounded.Article, "Text", Color(0xFF5F6368))
        "epub" -> ArixFileTypeInfo(Icons.Rounded.Book, "Ebook", Color(0xFFB06000))
        else -> ArixFileTypeInfo(Icons.Rounded.InsertDriveFile, "File", ArixPrimary)
    }
}

private fun remoteFileMimeType(url: String): String {
    val extension = url.substringBefore('#').substringBefore('?')
        .substringAfterLast('.', "").lowercase()
    return when (extension) {
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "gif" -> "image/gif"
        "webp" -> "image/webp"
        "bmp" -> "image/bmp"
        "svg" -> "image/svg+xml"
        "avif" -> "image/avif"
        "heic" -> "image/heic"
        "pdf" -> "application/pdf"
        "zip" -> "application/zip"
        "rar" -> "application/vnd.rar"
        "7z" -> "application/x-7z-compressed"
        "tar", "tgz", "gz" -> "application/gzip"
        "mp3" -> "audio/mpeg"
        "wav" -> "audio/wav"
        "ogg" -> "audio/ogg"
        "m4a" -> "audio/mp4"
        "flac" -> "audio/flac"
        "aac" -> "audio/aac"
        "mp4", "m4v" -> "video/mp4"
        "webm" -> "video/webm"
        "mkv" -> "video/x-matroska"
        "mov" -> "video/quicktime"
        "avi" -> "video/x-msvideo"
        "apk" -> "application/vnd.android.package-archive"
        "doc" -> "application/msword"
        "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        "xls" -> "application/vnd.ms-excel"
        "csv" -> "text/csv"
        "txt", "md" -> "text/plain"
        "json" -> "application/json"
        "epub" -> "application/epub+zip"
        else -> "application/octet-stream"
    }
}

@Composable
private fun ArixFileResponseCard(
    fileName: String,
    subtitle: String,
    sizeBytes: Long,
    mimeType: String,
    working: Boolean,
    message: String,
    copyValue: String? = null,
    onDownload: () -> Unit,
    onShare: () -> Unit,
) {
    val typeInfo = remember(fileName) { fileTypeInfo(fileName) }
    val sizeLabel = remember(sizeBytes) { ArixMediaActions.formatFileSize(sizeBytes) }
    val clipboard = LocalClipboardManager.current
    var copied by remember(copyValue) { mutableStateOf(false) }
    val copiedLabel = stringResource(R.string.widget_link_copied)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(ArixSurfaceHigh)
            .border(1.dp, ArixOutline.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(13.dp))
                    .background(typeInfo.tint.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = typeInfo.icon,
                    contentDescription = typeInfo.label,
                    tint = typeInfo.tint,
                    modifier = Modifier.size(24.dp),
                )
            }
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                Text(
                    text = fileName,
                    style = MaterialTheme.typography.bodyMedium,
                    color = ArixOnSurface,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                val subtitleText = listOfNotNull(
                    subtitle.takeIf { it.isNotBlank() },
                    sizeLabel.takeIf { it.isNotBlank() },
                ).joinToString("  ·  ")
                Text(
                    text = subtitleText.ifBlank { typeInfo.label },
                    style = MaterialTheme.typography.labelSmall,
                    color = ArixOnSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            if (working) {
                CircularProgressIndicator(
                    modifier = Modifier.size(18.dp),
                    strokeWidth = 2.dp,
                    color = ArixPrimary,
                )
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            ArixWidgetActionButton(
                label = stringResource(R.string.widget_file_download),
                icon = Icons.Rounded.Download,
                primary = true,
                enabled = !working,
                modifier = Modifier.weight(1f),
                onClick = onDownload,
            )
            if (copyValue != null) {
                ArixWidgetActionButton(
                    label = if (copied) copiedLabel else stringResource(R.string.widget_link_copy),
                    icon = if (copied) Icons.Rounded.CheckCircle else Icons.Rounded.ContentCopy,
                    primary = false,
                    enabled = !copied,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        clipboard.setText(androidx.compose.ui.text.AnnotatedString(copyValue))
                        copied = true
                    },
                )
            }
            ArixWidgetActionButton(
                label = stringResource(R.string.widget_file_share),
                icon = Icons.Rounded.Share,
                primary = false,
                enabled = !working,
                modifier = Modifier.weight(1f),
                onClick = onShare,
            )
        }
        if (message.isNotBlank()) {
            Text(
                text = message,
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
internal fun MarkdownMagnetLinkBlock(
    uri: String,
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var copied by remember(uri) { mutableStateOf(false) }
    val copiedLabel = stringResource(R.string.widget_link_copied)
    val hashName = remember(uri) {
        Regex("urn:btih:([A-Za-z0-9]+)", RegexOption.IGNORE_CASE)
            .find(uri)?.groupValues?.getOrNull(1)?.take(16)?.let { "Torrent · $it…" }
            ?: "Magnet download"
    }
    val displayName = remember(uri) {
        Regex("dn=([^&]+)", RegexOption.IGNORE_CASE)
            .find(uri)?.groupValues?.getOrNull(1)
            ?.urlDecodedOrNull()
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(ArixSurfaceHigh)
            .border(1.dp, ArixOutline, RoundedCornerShape(18.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(3.dp)
                .clip(RoundedCornerShape(999.dp))
                .background(Brush.horizontalGradient(listOf(ArixPrimary, ArixTertiary))),
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(13.dp))
                    .background(ArixPrimary.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = Icons.Rounded.Download,
                    contentDescription = null,
                    tint = ArixPrimary,
                    modifier = Modifier.size(22.dp),
                )
            }
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                Text(
                    text = displayName ?: hashName,
                    style = MaterialTheme.typography.titleSmall,
                    color = ArixOnSurface,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = "Magnet link · BitTorrent",
                    style = MaterialTheme.typography.labelSmall,
                    color = ArixOnSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        Text(
            text = uri,
            style = MaterialTheme.typography.bodySmall.copy(
                fontFamily = FontFamily.Monospace,
            ),
            color = ArixOnSurfaceVariant,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(ArixSurface)
                .border(1.dp, ArixOutline.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                .padding(horizontal = 10.dp, vertical = 8.dp),
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            ArixWidgetActionButton(
                label = stringResource(R.string.widget_link_open),
                icon = Icons.Rounded.OpenInNew,
                primary = true,
                modifier = Modifier.weight(1f),
                onClick = { ArixLinkActions.openUrl(context, uri) },
            )
            ArixWidgetActionButton(
                label = if (copied) copiedLabel else stringResource(R.string.widget_link_copy),
                icon = if (copied) Icons.Rounded.CheckCircle else Icons.Rounded.ContentCopy,
                primary = false,
                enabled = !copied,
                modifier = Modifier.weight(1f),
                onClick = {
                    clipboard.setText(AnnotatedString(uri))
                    copied = true
                },
            )
            ArixWidgetActionButton(
                label = stringResource(R.string.widget_file_share),
                icon = Icons.Rounded.Share,
                primary = false,
                modifier = Modifier.weight(1f),
                onClick = { ArixMediaActions.shareText(context, uri) },
            )
        }
    }
}

private fun String.urlDecodedOrNull(): String? = runCatching {
    java.net.URLDecoder.decode(this, Charsets.UTF_8.name())
}.getOrNull()?.takeIf { it.isNotBlank() }
