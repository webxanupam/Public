package com.arix.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Extension
import androidx.compose.material.icons.rounded.FileUpload
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Update
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.text.KeyboardOptions
import com.arix.app.data.ArixAppExtensionManager
import com.arix.app.data.ArixAppExtensionSettingsPage
import com.arix.app.data.ArixExtensionCatalogEntry
import com.arix.app.data.ArixExtensionPackageManager
import com.arix.app.data.ArixPackageDetails
import com.arix.app.data.ArixPackageCompatibilityIssue
import com.arix.app.data.InstalledArixExtension
import com.arix.app.data.ArixExtensionInstallKind
import com.arix.app.ui.theme.ArixError
import com.arix.app.ui.theme.ArixOnPrimary
import com.arix.app.ui.theme.ArixOnSurface
import com.arix.app.ui.theme.ArixOnSurfaceVariant
import com.arix.app.ui.theme.ArixPrimary
import com.arix.app.ui.theme.ArixSurface
import com.arix.app.ui.theme.ArixSurfaceHigh
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

/**
 * Settings page for the Arix Script Extension system (ported from Aether):
 * installed extensions with enable/disable/remove/update, the pi.dev package
 * catalog, .zip / single-file imports, and every settings card the installed
 * extensions register.
 */
@Composable
internal fun ArixExtensionsPage(
    packageManager: ArixExtensionPackageManager,
    extensionManager: ArixAppExtensionManager,
    onBack: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val extensionController = LocalArixExtensionUiController.current
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    var searchValue by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(""))
    }
    var installed by remember { mutableStateOf<List<InstalledArixExtension>>(emptyList()) }
    var hasLoadedInstalled by remember { mutableStateOf(false) }
    var installedError by remember { mutableStateOf("") }
    var catalog by remember { mutableStateOf<List<ArixExtensionCatalogEntry>>(emptyList()) }
    var isLoadingCatalog by remember { mutableStateOf(false) }
    var catalogError by remember { mutableStateOf("") }
    var operationSource by remember { mutableStateOf("") }
    var operationPhase by remember { mutableStateOf("") }
    var operationError by remember { mutableStateOf("") }
    var detailEntry by remember { mutableStateOf<ArixExtensionCatalogEntry?>(null) }
    var detail by remember { mutableStateOf<ArixPackageDetails?>(null) }
    var detailLoading by remember { mutableStateOf(false) }
    var removeCandidate by remember { mutableStateOf<InstalledArixExtension?>(null) }
    var installWarningEntry by remember { mutableStateOf<ArixExtensionCatalogEntry?>(null) }
    var refreshJob by remember { mutableStateOf<Job?>(null) }
    fun refreshInstalled() {
        refreshJob?.cancel()
        refreshJob = scope.launch {
            packageManager.listInstalled()
                .onSuccess {
                    installed = it
                    installedError = ""
                    hasLoadedInstalled = true
                }
                .onFailure {
                    installedError = it.message ?: "Unable to load installed extensions."
                    hasLoadedInstalled = true
                }
        }
    }

    fun refreshCatalog() {
        scope.launch {
            isLoadingCatalog = true
            packageManager.fetchCatalog()
                .onSuccess {
                    catalog = it
                    catalogError = ""
                }
                .onFailure { catalogError = it.message ?: "Unable to load the extension catalog." }
            isLoadingCatalog = false
        }
    }

    fun refreshAll() {
        refreshInstalled()
        refreshCatalog()
    }

    fun install(entry: ArixExtensionCatalogEntry) {
        operationSource = entry.source
        operationPhase = "installing"
        scope.launch {
            packageManager.installPackage(entry.source) { operationPhase = it }
                .onSuccess {
                    operationError = ""
                    refreshInstalled()
                }
                .onFailure { operationError = it.message ?: "Unable to install the extension." }
            operationSource = ""
            operationPhase = ""
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            operationSource = "import"
            operationPhase = "importing"
            scope.launch {
                packageManager.importFromUri(uri)
                    .onSuccess {
                        operationError = ""
                        refreshInstalled()
                    }
                    .onFailure { operationError = it.message ?: "Unable to import the extension." }
                operationSource = ""
                operationPhase = ""
            }
        }
    }

    LaunchedEffect(Unit) { refreshAll() }

    val installedSources = installed
        .filter { it.kind == ArixExtensionInstallKind.Package }
        .map { it.source }
        .toSet()
    val query = searchValue.text.trim()
    val visibleCatalog = catalog
        .asSequence()
        .filter { entry ->
            query.isBlank() || listOf(
                entry.name,
                entry.description,
                entry.author,
                entry.source,
            ).any { it.contains(query, ignoreCase = true) }
        }
        .take(40)
        .toList()

    SubPageScaffold(
        title = "Extensions",
        onBack = onBack,
        trailingIcon = Icons.Rounded.FileUpload,
        trailingEnabled = operationSource.isBlank(),
        trailingLoading = operationSource == "import",
        trailingContentDescription = "Import extension",
        onTrailingAction = { importLauncher.launch(arrayOf("application/zip", "application/x-zip-compressed", "text/*", "application/javascript", "application/typescript")) },
        secondaryTrailingIcon = Icons.Rounded.Refresh,
        secondaryTrailingEnabled = operationSource.isBlank(),
        secondaryTrailingContentDescription = "Refresh",
        onSecondaryTrailingAction = { refreshAll() },
    ) {
        if (operationSource.isNotBlank()) {
            ArixExtensionProgress(operationPhase.ifBlank { "working" })
            Spacer(Modifier.height(14.dp))
        }

        Text(
            text = "Script extensions run inside the Arix runtime and can add tools, settings cards and chat widgets. Only install extensions you trust.",
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp),
        )

        val snapshot = extensionController?.snapshot
        val runtimeError = extensionController?.runtimeError.orEmpty()
        val scriptErrors = snapshot?.errors.orEmpty()
        if (runtimeError.isNotBlank() || scriptErrors.isNotEmpty()) {
            Spacer(Modifier.height(14.dp))
            ArixScriptExtensionStatusCard(
                runtimeError = runtimeError,
                errors = scriptErrors.map { "${it.extensionId.ifBlank { it.path }}: ${it.message}" },
            )
        }

        if (operationError.isNotBlank()) {
            Spacer(Modifier.height(14.dp))
            Text(operationError, color = ArixError, style = MaterialTheme.typography.bodySmall)
        }

        Spacer(Modifier.height(16.dp))

        val tabs = listOf("Installed", "Discover")
        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
            tabs.forEachIndexed { index, label ->
                SegmentedButton(
                    shape = SegmentedButtonDefaults.itemShape(index = index, count = tabs.size),
                    onClick = { selectedTab = index },
                    selected = selectedTab == index,
                    colors = SegmentedButtonDefaults.colors(
                        activeContainerColor = ArixPrimary,
                        activeContentColor = ArixOnPrimary,
                        inactiveContainerColor = ArixSurfaceHigh,
                        inactiveContentColor = ArixOnSurface,
                    ),
                ) {
                    Text(label)
                }
            }
        }

        Spacer(Modifier.height(18.dp))

        if (selectedTab == 0 && installedError.isNotBlank()) {
            Text(installedError, color = ArixError)
            SettingsActionButton(
                label = "Retry",
                onClick = { refreshAll() },
                enabled = operationSource.isBlank() && !isLoadingCatalog,
            )
        }

        when (selectedTab) {
            0 -> {
                if (!hasLoadedInstalled) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 32.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            strokeWidth = 2.dp,
                            color = ArixPrimary,
                        )
                        Spacer(Modifier.width(12.dp))
                        Text("Loading installed extensions…", color = ArixOnSurfaceVariant)
                    }
                } else if (installed.isEmpty() && installedError.isBlank()) {
                    SettingsCardGroup {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Text(
                                "No extensions installed",
                                style = MaterialTheme.typography.titleMedium,
                                color = ArixOnSurface,
                            )
                            Spacer(Modifier.height(8.dp))
                            Text(
                                "Install from the catalog or import a .zip package.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = ArixOnSurfaceVariant,
                            )
                            Spacer(Modifier.height(16.dp))
                            SettingsActionButton(
                                label = "Import extension",
                                onClick = {
                                    importLauncher.launch(
                                        arrayOf("application/zip", "application/x-zip-compressed")
                                    )
                                },
                                enabled = operationSource.isBlank(),
                                isLoading = operationSource == "import",
                            )
                        }
                    }
                } else {
                    installed.forEach { extension ->
                        InstalledArixExtensionCard(
                            extension = extension,
                            isOperating = operationSource == extension.id ||
                                operationSource == extension.source,
                            actionsEnabled = operationSource.isBlank(),
                            onUpdate = {
                                operationSource = extension.source
                                operationPhase = "installing"
                                scope.launch {
                                    packageManager.updatePackage(extension.source) { operationPhase = it }
                                        .onSuccess {
                                            operationError = ""
                                            refreshInstalled()
                                        }
                                        .onFailure { operationError = it.message ?: "Unable to update." }
                                    operationSource = ""
                                    operationPhase = ""
                                }
                            },
                            onRemove = { removeCandidate = extension },
                            onSetEnabled = { enabled ->
                                scope.launch {
                                    packageManager.setEnabled(extension, enabled)
                                        .onSuccess { refreshInstalled() }
                                        .onFailure { operationError = it.message ?: "Unable to change the extension state." }
                                }
                            },
                        )
                        Spacer(Modifier.height(10.dp))
                    }

                    // Extension-provided settings cards.
                    snapshot?.settings.orEmpty().forEach { page ->
                        Spacer(Modifier.height(6.dp))
                        ArixExtensionSettingsCard(page = page, controller = extensionController)
                    }
                }
            }

            else -> {
                SettingsCardGroup {
                    ChatGptTextField(
                        label = "Search extensions",
                        value = searchValue,
                        onValueChange = { searchValue = it },
                    )
                }
                Spacer(Modifier.height(14.dp))

                when {
                    isLoadingCatalog && catalog.isEmpty() -> {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 32.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(22.dp),
                                strokeWidth = 2.dp,
                                color = ArixPrimary,
                            )
                            Spacer(Modifier.width(12.dp))
                            Text("Loading extensions…", color = ArixOnSurfaceVariant)
                        }
                    }

                    catalogError.isNotBlank() && catalog.isEmpty() -> {
                        SettingsCardGroup {
                            Column(modifier = Modifier.padding(18.dp)) {
                                Text(
                                    text = catalogError,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = ArixOnSurfaceVariant,
                                )
                                Spacer(Modifier.height(14.dp))
                                SettingsActionButton(label = "Retry", onClick = { refreshCatalog() })
                            }
                        }
                    }

                    visibleCatalog.isEmpty() -> {
                        Text(
                            text = "No extensions found",
                            style = MaterialTheme.typography.bodyMedium,
                            color = ArixOnSurfaceVariant,
                            modifier = Modifier.padding(vertical = 24.dp, horizontal = 4.dp),
                        )
                    }

                    else -> visibleCatalog.forEach { entry ->
                        ArixExtensionCatalogCard(
                            entry = entry,
                            installed = installedSources.contains(entry.source),
                            onClick = { detailEntry = entry },
                        )
                        Spacer(Modifier.height(10.dp))
                    }
                }
            }
        }
    }

    removeCandidate?.let { extension ->
        AlertDialog(
            onDismissRequest = { removeCandidate = null },
            title = { Text("Remove extension") },
            text = { Text("Remove ${extension.name}? Its files and settings will be deleted.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        val target = extension
                        removeCandidate = null
                        operationSource = target.id
                        operationPhase = "removing"
                        scope.launch {
                            packageManager.remove(target)
                                .onSuccess {
                                    operationError = ""
                                    refreshInstalled()
                                }
                                .onFailure { operationError = it.message ?: "Unable to remove the extension." }
                            operationSource = ""
                            operationPhase = ""
                        }
                    }
                ) { Text("Remove") }
            },
            dismissButton = {
                TextButton(onClick = { removeCandidate = null }) { Text("Cancel") }
            },
        )
    }

    installWarningEntry?.let { entry ->
        ArixPackageInstallWarningDialog(
            entry = entry,
            onConfirm = {
                installWarningEntry = null
                install(entry)
            },
            onDismiss = { installWarningEntry = null },
        )
    }

    detailEntry?.let { entry ->
        LaunchedEffect(entry) {
            detailLoading = true
            detail = null
            packageManager.fetchPackageDetails(entry)
                .onSuccess { detail = it }
                .onFailure { detail = null }
            detailLoading = false
        }
        ArixPackageDetailDialog(
            entry = entry,
            detail = detail,
            loading = detailLoading,
            installed = installedSources.contains(entry.source),
            installing = operationSource == entry.source,
            onInstall = {
                when (entry.compatibilityIssue) {
                    null -> install(entry)
                    else -> installWarningEntry = entry
                }
            },
            onDismiss = { detailEntry = null },
        )
    }
}

@Composable
private fun ArixExtensionProgress(phase: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(ArixSurfaceHigh)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = ArixPrimary)
        Spacer(Modifier.width(12.dp))
        Text(
            text = phase.replaceFirstChar { it.uppercase() } + "…",
            style = MaterialTheme.typography.bodyMedium,
            color = ArixOnSurface,
        )
    }
}

@Composable
private fun ArixScriptExtensionStatusCard(
    runtimeError: String,
    errors: List<String>,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(ArixSurfaceHigh)
            .padding(16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.WarningAmber, null, tint = ArixError, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(
                "Extension runtime notices",
                style = MaterialTheme.typography.titleSmall,
                color = ArixOnSurface,
            )
        }
        if (runtimeError.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            Text(runtimeError, style = MaterialTheme.typography.bodySmall, color = ArixOnSurfaceVariant)
        }
        errors.take(5).forEach { error ->
            Spacer(Modifier.height(4.dp))
            Text("• $error", style = MaterialTheme.typography.bodySmall, color = ArixOnSurfaceVariant)
        }
    }
}

@Composable
private fun InstalledArixExtensionCard(
    extension: InstalledArixExtension,
    isOperating: Boolean,
    actionsEnabled: Boolean,
    onUpdate: () -> Unit,
    onRemove: () -> Unit,
    onSetEnabled: (Boolean) -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(ArixSurface)
            .padding(16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Rounded.Extension,
                null,
                tint = if (extension.isEnabled) ArixPrimary else ArixOnSurfaceVariant,
                modifier = Modifier.size(22.dp),
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    extension.name,
                    style = MaterialTheme.typography.titleSmall,
                    color = ArixOnSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    buildString {
                        append(extension.source)
                        if (extension.version.isNotBlank()) append(" · v${extension.version}")
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = ArixOnSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            if (isOperating) {
                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = ArixPrimary)
            } else {
                IconButton(onClick = onRemove, enabled = actionsEnabled) {
                    Icon(Icons.Rounded.Delete, "Remove", tint = ArixOnSurfaceVariant)
                }
                if (extension.kind == ArixExtensionInstallKind.Package) {
                    IconButton(onClick = onUpdate, enabled = actionsEnabled) {
                        Icon(Icons.Rounded.Update, "Update", tint = ArixOnSurfaceVariant)
                    }
                }
            }
        }
        if (extension.description.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            Text(
                extension.description,
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
        val chips = buildList {
            if (extension.extensionCount > 0) add("${extension.extensionCount} Pi extension" + if (extension.extensionCount > 1) "s" else "")
            if (extension.scriptExtensionCount > 0) add("${extension.scriptExtensionCount} script")
            if (extension.skillCount > 0) add("${extension.skillCount} skill" + if (extension.skillCount > 1) "s" else "")
            if (extension.nativeEntrypointCount > 0) add("${extension.nativeEntrypointCount} native")
        }
        if (chips.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Text(chips.joinToString("  ·  "), style = MaterialTheme.typography.labelSmall, color = ArixOnSurfaceVariant)
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                if (extension.isEnabled) "Enabled" else "Disabled",
                style = MaterialTheme.typography.labelMedium,
                color = ArixOnSurfaceVariant,
                modifier = Modifier.weight(1f),
            )
            Switch(
                checked = extension.isEnabled,
                onCheckedChange = onSetEnabled,
                enabled = actionsEnabled,
                colors = SwitchDefaults.colors(
                    checkedTrackColor = ArixPrimary,
                    checkedThumbColor = ArixOnPrimary,
                ),
            )
        }
    }
}

@Composable
private fun ArixExtensionCatalogCard(
    entry: ArixExtensionCatalogEntry,
    installed: Boolean,
    onClick: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(ArixSurface)
            .clickable(onClick = onClick)
            .padding(16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                entry.name,
                style = MaterialTheme.typography.titleSmall,
                color = ArixOnSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            if (installed) {
                Text("Installed", style = MaterialTheme.typography.labelMedium, color = ArixPrimary)
            } else if (entry.compatibilityIssue != null) {
                Icon(
                    Icons.Rounded.WarningAmber,
                    "Compatibility notice",
                    tint = ArixOnSurfaceVariant,
                    modifier = Modifier.size(16.dp),
                )
            }
        }
        if (entry.description.isNotBlank()) {
            Spacer(Modifier.height(4.dp))
            Text(
                entry.description,
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(
            buildString {
                if (entry.author.isNotBlank()) append(entry.author)
                if (entry.monthlyDownloads > 0) {
                    if (isNotEmpty()) append("  ·  ")
                    append(formatArixExtensionDownloads(entry.monthlyDownloads))
                    append("/mo")
                }
            },
            style = MaterialTheme.typography.labelSmall,
            color = ArixOnSurfaceVariant,
        )
    }
}

private fun formatArixExtensionDownloads(downloads: Long): String = when {
    downloads >= 1_000_000L -> String.format("%.1fM", downloads / 1_000_000.0)
    downloads >= 1_000L -> String.format("%.1fk", downloads / 1_000.0)
    else -> downloads.toString()
}

@Composable
private fun ArixPackageInstallWarningDialog(
    entry: ArixExtensionCatalogEntry,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
) {
    val message = when (entry.compatibilityIssue) {
        ArixPackageCompatibilityIssue.InteractiveUi ->
            "This package advertises interactive terminal UI features. Those cannot render on Android, but its tools and settings still work."
        ArixPackageCompatibilityIssue.Theme ->
            "This package is a terminal theme; it has no effect inside Arix."
        ArixPackageCompatibilityIssue.Prompt ->
            "This package ships prompts, which Arix does not apply."
        ArixPackageCompatibilityIssue.Platform ->
            "This package targets another platform and may not work on Android."
        null -> ""
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Install ${entry.name}?") },
        text = { Text(message) },
        confirmButton = {
            TextButton(onClick = onConfirm) { Text("Install anyway") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
    )
}

@Composable
private fun ArixPackageDetailDialog(
    entry: ArixExtensionCatalogEntry,
    detail: ArixPackageDetails?,
    loading: Boolean,
    installed: Boolean,
    installing: Boolean,
    onInstall: () -> Unit,
    onDismiss: () -> Unit,
) {
    val uriHandler = LocalUriHandler.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(detail?.name?.ifBlank { entry.name } ?: entry.name) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (loading) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
                        horizontalArrangement = Arrangement.Center,
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = ArixPrimary)
                    }
                } else {
                    val description = detail?.description?.ifBlank { entry.description } ?: entry.description
                    if (description.isNotBlank()) {
                        Text(description, style = MaterialTheme.typography.bodyMedium, color = ArixOnSurface)
                        Spacer(Modifier.height(10.dp))
                    }
                    detail?.let { value ->
                        ArixPackageDetailLine("Source", value.source)
                        value.version.takeIf(String::isNotBlank)?.let { ArixPackageDetailLine("Version", it) }
                        value.author.takeIf(String::isNotBlank)?.let { ArixPackageDetailLine("Author", it) }
                        value.license.takeIf(String::isNotBlank)?.let { ArixPackageDetailLine("License", it) }
                        value.downloads.takeIf(String::isNotBlank)?.let { ArixPackageDetailLine("Downloads", it) }
                        if (value.types.isNotEmpty()) {
                            ArixPackageDetailLine("Types", value.types.joinToString(", "))
                        }
                    }
                    val links = buildList {
                        detail?.npmUrl?.takeIf(String::isNotBlank)?.let { add("npm" to it) }
                        detail?.repositoryUrl?.takeIf(String::isNotBlank)?.let { add("repository" to it) }
                    }
                    if (links.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        links.forEach { (label, url) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { runCatching { uriHandler.openUri(url) } }
                                    .padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(
                                    Icons.AutoMirrored.Rounded.OpenInNew,
                                    null,
                                    tint = ArixPrimary,
                                    modifier = Modifier.size(14.dp),
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    "Open $label",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = ArixPrimary,
                                )
                            }
                        }
                    }
                    detail?.readmeMarkdown?.takeIf(String::isNotBlank)?.let { readme ->
                        Spacer(Modifier.height(10.dp))
                        Text(
                            readme,
                            style = MaterialTheme.typography.bodySmall,
                            color = ArixOnSurfaceVariant,
                            maxLines = 12,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
        },
        confirmButton = {
            when {
                installing -> CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = ArixPrimary)
                installed -> TextButton(onClick = onDismiss) { Text("Close") }
                else -> Button(onClick = onInstall) { Text("Install") }
            }
        },
        dismissButton = {
            if (!installing) {
                TextButton(onClick = onDismiss) { Text("Cancel") }
            }
        },
    )
}

@Composable
private fun ArixPackageDetailLine(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text(
            "$label: ",
            style = MaterialTheme.typography.labelSmall,
            color = ArixOnSurfaceVariant,
        )
        Text(
            value,
            style = MaterialTheme.typography.labelSmall,
            color = ArixOnSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

// ------------------------------------------------------------------------- //
// Extension-provided settings cards                                         //
// ------------------------------------------------------------------------- //

@Composable
private fun ArixExtensionSettingsCard(
    page: ArixAppExtensionSettingsPage,
    controller: ArixExtensionUiController?,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(ArixSurface)
            .padding(vertical = 8.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                arixExtensionIcon(page.icon),
                null,
                tint = ArixPrimary,
                modifier = Modifier.size(20.dp),
            )
            Spacer(Modifier.width(10.dp))
            Column {
                Text(page.title, style = MaterialTheme.typography.titleSmall, color = ArixOnSurface)
                if (page.subtitle.isNotBlank()) {
                    Text(page.subtitle, style = MaterialTheme.typography.labelSmall, color = ArixOnSurfaceVariant)
                }
            }
        }
        page.sections.forEach { section ->
            ArixExtensionSettingsSection(section, page, controller)
        }
        page.categories.filterNot { it.hidden }.forEach { category ->
            Text(
                category.title,
                style = MaterialTheme.typography.labelMedium,
                color = ArixOnSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
            )
            category.sections.forEach { section ->
                ArixExtensionSettingsSection(section, page, controller)
            }
        }
    }
}

@Composable
private fun ArixExtensionSettingsSection(
    section: JSONObject,
    page: ArixAppExtensionSettingsPage,
    controller: ArixExtensionUiController?,
) {
    val title = section.optString("title")
    if (title.isNotBlank()) {
        Text(
            title,
            style = MaterialTheme.typography.labelMedium,
            color = ArixOnSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
        )
    }
    val settings = section.optJSONArray("settings") ?: JSONArray()
    for (index in 0 until settings.length()) {
        val setting = settings.optJSONObject(index) ?: continue
        ArixExtensionControlRow(setting, page, controller)
    }
}

@Composable
private fun ArixExtensionControlRow(
    setting: JSONObject,
    page: ArixAppExtensionSettingsPage,
    controller: ArixExtensionUiController?,
) {
    val uriHandler = LocalUriHandler.current
    val id = "${page.id}:${setting.optString("id")}"
    val type = setting.optString("type").ifBlank { "text" }
    val label = setting.optString("label").ifBlank { setting.optString("title") }
    val description = setting.optString("description").ifBlank { setting.optString("subtitle") }
    val action = setting.optString("action").ifBlank {
        "settings:${page.localId}:${setting.optString("id")}"
    }

    fun update(value: Any?) {
        controller?.onAction(
            page.extensionId,
            "settings:${page.localId}:${setting.optString("id")}",
            JSONObject().put("setting", setting.optString("id")).put("value", value),
        )
    }

    when (type) {
        "toggle" -> {
            var checked by remember(id, setting.optBoolean("value")) {
                mutableStateOf(setting.optBoolean("value"))
            }
            Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp)) {
                SettingsToggleRow(label, description, checked) {
                    checked = it
                    update(it)
                }
            }
        }

        "select", "dropdown", "segmented", "tab", "tabs" -> {
            val options = setting.optJSONArray("options") ?: JSONArray()
            var selected by remember(id, setting.optString("value")) {
                mutableStateOf(setting.optString("value"))
            }
            if (type == "segmented" || type == "tab" || type == "tabs") {
                Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
                    Text(label, style = MaterialTheme.typography.bodyMedium, color = ArixOnSurface)
                    if (description.isNotBlank()) {
                        Text(description, style = MaterialTheme.typography.bodySmall, color = ArixOnSurfaceVariant)
                    }
                    Spacer(Modifier.height(8.dp))
                    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                        for (optionIndex in 0 until options.length()) {
                            val option = options.optJSONObject(optionIndex) ?: continue
                            val value = option.optString("value")
                            SegmentedButton(
                                selected = selected == value,
                                onClick = { selected = value; update(value) },
                                shape = SegmentedButtonDefaults.itemShape(optionIndex, options.length()),
                            ) { Text(option.optString("label").ifBlank { value }) }
                        }
                    }
                }
            } else {
                val selectedLabel = (0 until options.length())
                    .mapNotNull(options::optJSONObject)
                    .firstOrNull { it.optString("value") == selected }
                    ?.optString("label")
                    .orEmpty()
                SelectionDropdownField(
                    label = label,
                    supportingText = description,
                    selectedLabel = selectedLabel.ifBlank { selected },
                    options = (0 until options.length()).mapNotNull { optionIndex ->
                        val option = options.optJSONObject(optionIndex) ?: return@mapNotNull null
                        val value = option.optString("value")
                        SelectionOption(
                            key = value,
                            title = option.optString("label").ifBlank { value },
                            subtitle = option.optString("description"),
                            selected = selected == value,
                            onClick = { selected = value; update(value) },
                        )
                    },
                )
            }
        }

        "slider" -> {
            val minimum = setting.optDouble("min", 0.0).toFloat()
            val maximum = setting.optDouble("max", 1.0).toFloat().coerceAtLeast(minimum + 0.0001f)
            val step = setting.optDouble("step", 0.01).toFloat().takeIf { it > 0f } ?: 0.01f
            val discreteSteps = (((maximum - minimum) / step).toInt() - 1).coerceAtLeast(0)
            var value by remember(id, setting.optDouble("value", minimum.toDouble())) {
                mutableStateOf(setting.optDouble("value", minimum.toDouble()).toFloat().coerceIn(minimum, maximum))
            }
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
                Text(label, style = MaterialTheme.typography.bodyMedium, color = ArixOnSurface)
                if (description.isNotBlank()) {
                    Text(description, style = MaterialTheme.typography.bodySmall, color = ArixOnSurfaceVariant)
                }
                Slider(
                    value = value,
                    onValueChange = { value = it },
                    onValueChangeFinished = { update(value) },
                    valueRange = minimum..maximum,
                    steps = discreteSteps.takeIf { it in 1..20 } ?: 0,
                )
            }
        }

        "button" -> {
            val buttonIcon = setting.optString("icon")
                .takeIf(String::isNotBlank)
                ?.let(::arixExtensionIcon)
            val buttonModifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
            val onClick: () -> Unit = {
                controller?.onAction(
                    page.extensionId,
                    action,
                    setting.optJSONObject("args") ?: JSONObject(),
                )
            }
            when (setting.optString("tone").lowercase()) {
                "neutral", "secondary", "danger", "error" -> SettingsSubtleActionButton(
                    label = label,
                    onClick = onClick,
                    modifier = buttonModifier,
                    enabled = setting.optBoolean("enabled", true),
                    icon = buttonIcon,
                )
                else -> SettingsActionButton(
                    label = label,
                    onClick = onClick,
                    modifier = buttonModifier,
                    enabled = setting.optBoolean("enabled", true),
                    icon = buttonIcon,
                )
            }
        }

        "link" -> SettingsNavRow(
            icon = Icons.AutoMirrored.Rounded.OpenInNew,
            title = label,
            subtitle = description,
            enabled = setting.optBoolean("enabled", true),
        ) {
            val url = setting.optString("url")
            when {
                url.isNotBlank() -> runCatching { uriHandler.openUri(url) }
                else -> controller?.onAction(
                    page.extensionId,
                    action,
                    setting.optJSONObject("args") ?: JSONObject(),
                )
            }
        }

        "action-row", "chips" -> {
            val actions = setting.optJSONArray("actions") ?: JSONArray()
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                for (actionIndex in 0 until actions.length()) {
                    val item = actions.optJSONObject(actionIndex) ?: continue
                    val itemLabel = item.optString("label")
                    val itemAction = item.optString("action")
                    val itemArgs = item.optJSONObject("args") ?: JSONObject()
                    SettingsSubtleActionButton(
                        label = itemLabel,
                        enabled = item.optBoolean("enabled", true),
                        onClick = {
                            if (itemAction.isNotBlank()) {
                                controller?.onAction(page.extensionId, itemAction, itemArgs)
                            }
                        },
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }

        "detail-line", "key-value" -> {
            val value = setting.optString("value").ifBlank { description }
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                Text(label, style = MaterialTheme.typography.labelSmall, color = ArixOnSurfaceVariant)
                Text(value, style = MaterialTheme.typography.bodySmall, color = ArixOnSurface)
            }
        }

        "pill", "badge" -> {
            Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                ActionPreviewPill(label)
            }
        }

        "result-card", "callout" -> {
            val value = setting.optString("text").ifBlank { setting.optString("value").ifBlank { label } }
            val title = setting.optString("title")
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
                if (title.isNotBlank()) {
                    Text(title, style = MaterialTheme.typography.labelMedium, color = ArixOnSurface)
                    Spacer(Modifier.height(4.dp))
                }
                Text(value, style = MaterialTheme.typography.bodySmall, color = ArixOnSurfaceVariant)
            }
        }

        "divider" -> CardDivider()
        "spacer" -> Spacer(Modifier.height(setting.optInt("size", 8).coerceAtLeast(1).dp))
        "label" -> Text(
            label,
            color = ArixOnSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
        )

        else -> {
            var value by rememberSaveable(
                id,
                stateSaver = TextFieldValue.Saver,
                key = "arix-extension-setting:$id",
            ) {
                mutableStateOf(TextFieldValue(setting.optString("value")))
            }
            ChatGptTextField(
                label = label,
                value = value,
                minLines = if (type == "textarea" || setting.optBoolean("multiline")) 4 else 1,
                isSecret = type == "password" || setting.optBoolean("secret"),
                placeholder = setting.optString("placeholder").ifBlank { label },
                supportingText = description,
                keyboardOptions = if (type == "number") {
                    KeyboardOptions(keyboardType = KeyboardType.Number)
                } else {
                    KeyboardOptions.Default
                },
                onValueChange = {
                    value = it
                    update(it.text)
                },
            )
        }
    }
}
