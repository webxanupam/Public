package com.arix.app.agent

import android.content.Context
import com.arix.app.agent.setup.BuiltinShellManager
import com.arix.app.agent.setup.BuiltinShellRecovery
import com.arix.app.agent.setup.PairingCoordinator
import com.arix.app.agent.setup.PhoneSetupPrompt
import com.arix.app.agent.setup.RecoverySettings
import com.arix.app.agent.shell.BuiltinShellConnection
import com.arix.app.agent.shell.HelperHub
import com.arix.app.agent.shell.SharedShell

/**
 * The phone-control services inside the Arix process; the Application creates one
 * instance and hands it out via [Owner]. Ported from Mika's PhoneServices
 * (Apache-2.0, wangzan101/Mika): the built-in helper's handoff landing point,
 * pairing + watchdog, auto-recovery and permissions, the one shared shell
 * connection used by tasks and startup recovery, the pairing flow, and the
 * "phone control not set up yet" prompt.
 *
 * The helper process (HelperMain, ShellService) runs as the shell user and has no
 * Application object — it never touches anything here.
 */
class ArixPhoneServices(context: Context) {
    private val app = context.applicationContext

    /** Where the helper hands its Binder over; it only ever trusts one landing point per process. */
    val hub = HelperHub(app)

    /** Pairing, launching the helper via adbd, and the watchdog. */
    val shellManager = BuiltinShellManager(app, hub) { recoverySettings.consent.value }

    /** The built-in helper itself (status, pairing, retry, unpair). */
    val shellControl get() = shellManager.engine

    /** Settings for auto-recovery and the permission switches. */
    val recoverySettings: RecoverySettings by lazy { RecoverySettings(RecoverySettings.prefs(app)) }

    /** Auto-recovery and the permission toggles. */
    val recovery: BuiltinShellRecovery by lazy {
        BuiltinShellRecovery(app, shellManager.commandRunner, recoverySettings, shellControl)
    }

    /** The one shell connection shared by tasks and startup recovery. */
    val sharedShell = SharedShell { BuiltinShellConnection(hub) { shellManager.need() } }

    /** One pairing attempt, start to finish. */
    val pairing: PairingCoordinator by lazy { PairingCoordinator(app, shellControl) }

    /** Shown when a task needs the phone but the helper is not running. */
    val setupPrompt = PhoneSetupPrompt(app)

    /** Implemented by the Application to hand out the process-wide instance. */
    interface Owner {
        val phone: ArixPhoneServices
    }

    companion object {
        fun of(context: Context): ArixPhoneServices =
            (context.applicationContext as? Owner)?.phone
                ?: error(
                    "the Application (${context.applicationContext.javaClass.name}) must implement " +
                        "ArixPhoneServices.Owner to give out the phone control's shared services",
                )
    }
}
