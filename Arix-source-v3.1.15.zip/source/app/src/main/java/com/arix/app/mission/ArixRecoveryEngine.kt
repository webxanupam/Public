package com.arix.app.mission

import org.json.JSONObject

object ArixRecoveryEngine {

    object ErrorCategories {
        const val TIMEOUT = "TIMEOUT"
        const val NETWORK_ERROR = "NETWORK_ERROR"
        const val PERMISSION_DENIED = "PERMISSION_DENIED"
        const val INVALID_INPUT = "INVALID_INPUT"
        const val TOOL_UNAVAILABLE = "TOOL_UNAVAILABLE"
        const val EXECUTION_FAILED = "EXECUTION_FAILED"
        const val CANCELLED = "CANCELLED"
        const val VERIFICATION_FAILED = "VERIFICATION_FAILED"
        const val REPEATED_FAILURE = "REPEATED_FAILURE"
        const val AUTH_REQUIRED = "AUTH_REQUIRED"
        const val UNKNOWN = "UNKNOWN"
    }

    enum class Strategy { RETRY, ALTERNATIVE_TOOL, REFINE_INPUT, ESCALATE_USER, ABORT }

    data class RecoveryDecision(
        val strategy: Strategy,
        val reason: String,
        val alternativeTool: String? = null,
        val backoffMillis: Long = 0L,
    )

    fun classify(rawOutput: String): String {
        val parsed = runCatching { JSONObject(rawOutput) }.getOrNull()
            ?: return if (rawOutput.isBlank()) ErrorCategories.UNKNOWN else ErrorCategories.EXECUTION_FAILED
        if (parsed.optBoolean("ok", false)) return ""
        val code = parsed.optString("error_code")
            .ifBlank { parsed.optString("code") }
            .trim()
            .uppercase()
        return when (code) {
            "TIMEOUT" -> ErrorCategories.TIMEOUT
            "NETWORK_ERROR", "NETWORK", "SEARCH_BUDGET" -> ErrorCategories.NETWORK_ERROR
            "PERMISSION_REQUIRED", "PERMISSION_DENIED" -> ErrorCategories.PERMISSION_DENIED
            "AUTH_REQUIRED" -> ErrorCategories.AUTH_REQUIRED
            "INVALID_ARGUMENTS", "INVALID_INPUT" -> ErrorCategories.INVALID_INPUT
            "TOOL_UNAVAILABLE", "TOOL_NOT_FOUND" -> ErrorCategories.TOOL_UNAVAILABLE
            "CANCELLED" -> ErrorCategories.CANCELLED
            "VERIFICATION_FAILED" -> ErrorCategories.VERIFICATION_FAILED
            "REPEATED_FAILURE" -> ErrorCategories.REPEATED_FAILURE
            "ACTION_FAILED", "EXECUTION_FAILED", "TARGET_NOT_FOUND", "TARGET_AMBIGUOUS",
            "TARGET_STALE", "AGENT_NOT_FOUND", "AGENT_UNAVAILABLE" -> ErrorCategories.EXECUTION_FAILED
            "" -> ErrorCategories.EXECUTION_FAILED
            else -> code
        }
    }

    fun decide(
        task: MissionTask,
        errorCategory: String,
        errorMessage: String,
    ): RecoveryDecision {
        if (errorCategory == ErrorCategories.CANCELLED) {
            return RecoveryDecision(
                strategy = Strategy.ABORT,
                reason = "Cancelled — intentional stop, not a failure to recover.",
            )
        }
        if (errorCategory == ErrorCategories.PERMISSION_DENIED ||
            errorCategory == ErrorCategories.AUTH_REQUIRED
        ) {
            return RecoveryDecision(
                strategy = Strategy.ESCALATE_USER,
                reason = "$errorCategory: $errorMessage",
            )
        }
        if (errorCategory == ErrorCategories.REPEATED_FAILURE) {
            return RecoveryDecision(
                strategy = Strategy.ABORT,
                reason = "The identical call keeps failing; repeated retries are refused.",
            )
        }
        val attemptsLeft = task.retryPolicy.canRetry(task.attemptsUsed)
        val transient = errorCategory in TransientCategories
        if (transient && attemptsLeft) {
            return RecoveryDecision(
                strategy = Strategy.RETRY,
                reason = "$errorCategory is transient — retrying with exponential backoff.",
                backoffMillis = task.retryPolicy.delayForRetry(task.attemptsUsed + 1),
            )
        }
        if (errorCategory == ErrorCategories.VERIFICATION_FAILED) {
            if (attemptsLeft) {
                return RecoveryDecision(
                    strategy = Strategy.REFINE_INPUT,
                    reason = "Verification failed — one refined attempt with the failure attached.",
                )
            }
            val alternative = untriedAlternative(task)
            if (alternative != null) {
                return RecoveryDecision(
                    strategy = Strategy.ALTERNATIVE_TOOL,
                    reason = "Verification keeps failing — switching strategy.",
                    alternativeTool = alternative,
                )
            }
            return RecoveryDecision(
                strategy = Strategy.ABORT,
                reason = "Verification failed and no alternative tool exists: $errorMessage",
            )
        }
        if (errorCategory == ErrorCategories.TOOL_UNAVAILABLE ||
            errorCategory == ErrorCategories.NETWORK_ERROR ||
            errorCategory == ErrorCategories.TIMEOUT
        ) {
            val untried = untriedAlternative(task)
            if (untried != null) {
                return RecoveryDecision(
                    strategy = Strategy.ALTERNATIVE_TOOL,
                    reason = "Switching to alternative tool '$untried' after $errorCategory.",
                    alternativeTool = untried,
                )
            }
        }
        if (errorCategory == ErrorCategories.INVALID_INPUT && attemptsLeft) {
            return RecoveryDecision(
                strategy = Strategy.REFINE_INPUT,
                reason = "INVALID_INPUT — refining the instruction with the error attached.",
            )
        }
        return RecoveryDecision(
            strategy = Strategy.ABORT,
            reason = "$errorCategory is not recoverable within the mission budget: $errorMessage",
        )
    }

    private val TransientCategories = setOf(
        ErrorCategories.TIMEOUT,
        ErrorCategories.NETWORK_ERROR,
        ErrorCategories.EXECUTION_FAILED,
        ErrorCategories.UNKNOWN,
    )

    private fun untriedAlternative(task: MissionTask): String? {
        val candidates = task.preferredTool?.let(ArixToolRouter::alternativesFor)
            ?: ArixToolRouter.selectTool(task.requiredCapability)
                ?.let { ArixToolRouter.alternativesFor(it.toolId) }
            .orEmpty()
        return candidates.firstOrNull { it != task.executedWithTool }
    }
}
