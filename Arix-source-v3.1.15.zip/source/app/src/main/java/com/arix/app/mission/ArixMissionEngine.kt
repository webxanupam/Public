package com.arix.app.mission

import com.arix.app.mission.ArixMissionContract as Contract
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject

class ArixMissionEngine(
    private val persistence: ArixMissionPersistence,
    private val executor: MissionTaskExecutor,
    private val modelComplete: MissionModelCompleter = { null },
    private val verificationEngine: ArixVerificationEngine = ArixVerificationEngine(),
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default),
    private val nowMillis: () -> Long = System::currentTimeMillis,
    private val delayMillis: suspend (Long) -> Unit = { kotlinx.coroutines.delay(it) },
) {

    fun interface MissionTaskExecutor {
        suspend fun execute(task: MissionTask, resolvedTool: String, mission: ArixMission): String
    }

    fun interface MissionModelCompleter {
        suspend fun complete(prompt: String): String?
    }

    data class MissionOptions(
        val requireApproval: Boolean = false,
        val maxConcurrency: Int = Contract.DEFAULT_MAX_CONCURRENCY,
        val globalTimeoutMillis: Long = Contract.DEFAULT_GLOBAL_TIMEOUT_MILLIS,
        val stepTimeoutMillis: Long = Contract.DEFAULT_STEP_TIMEOUT_MILLIS,
        val projectId: String = "",
        val sessionId: String = "",
    )

    data class MissionEvent(
        val missionId: String,
        val taskId: String? = null,
        val phase: String,
        val status: String,
        val message: String,
        val atMillis: Long,
    )

    private class MissionPausedException(val reason: String) : Exception(reason)

    private val missionJobs = ConcurrentHashMap<String, Job>()
    private val approvals = ConcurrentHashMap<String, CompletableDeferred<Boolean>>()

    private val _states = MutableStateFlow<List<ArixMission>>(emptyList())
    val states: StateFlow<List<ArixMission>> = _states.asStateFlow()

    private val _events = MutableSharedFlow<MissionEvent>(replay = 64, extraBufferCapacity = 128)
    val events: SharedFlow<MissionEvent> = _events.asSharedFlow()

    private val mutationMutex = Mutex()

    private val missionMutexes = ConcurrentHashMap<String, Mutex>()

    private fun mutexFor(missionId: String): Mutex = missionMutexes.getOrPut(missionId) { Mutex() }

    suspend fun startMission(objective: String, options: MissionOptions = MissionOptions()): JSONObject {
        val trimmed = objective.trim()
        if (trimmed.length < 4) {
            return failure("INVALID_INPUT", "The mission objective is too short.")
        }
        val mission = ArixMission(
            objective = trimmed,
            projectId = options.projectId,
            sessionId = options.sessionId,
            status = MissionStatus.Planning,
            requireApproval = options.requireApproval,
            globalTimeoutMillis = options.globalTimeoutMillis.coerceIn(60_000L, 6L * 60 * 60_000L),
            maxConcurrency = options.maxConcurrency.coerceIn(1, 8),
            startedAtMillis = nowMillis(),
        )
        persistence.upsert(mission)
        refreshStates()
        emit(mission.missionId, phase = "understand", status = "planning", message = "Understanding the objective…")
        launchPipeline(mission.missionId)
        return JSONObject()
            .put("ok", true)
            .put("mission_id", mission.missionId)
            .put("status", mission.status.storageValue)
            .put(
                "hint",
                "Mission started. Poll action=status (mission_id='${mission.missionId}'); the timeline " +
                    "streams live events. Pause/resume/cancel/retry are available at any time.",
            )
    }

    fun status(missionId: String?): JSONObject {
        val missions = persistence.snapshot()
            .sortedByDescending { it.updatedAtMillis }
        val selected = if (missionId.isNullOrBlank()) missions else missions.filter { it.missionId == missionId }
        if (!missionId.isNullOrBlank() && selected.isEmpty()) {
            return failure(Contract.MISSION_NOT_FOUND, "No mission '$missionId'.")
        }
        return JSONObject()
            .put("ok", true)
            .put("missions", JSONArray(selected.map { it.toPublicJson(includePlan = missionId != null) }))
            .put("total", missions.size)
    }

    suspend fun pause(missionId: String): JSONObject {
        val mission = persistence.find(missionId)
            ?: return failure(Contract.MISSION_NOT_FOUND, "No mission '$missionId'.")
        if (mission.status.isTerminal) {
            return failure(Contract.MISSION_INVALID_STATE, "Mission is already ${mission.status.storageValue}.")
        }
        missionJobs.remove(missionId)?.cancel(CancellationException("Paused by user."))
        approvals.remove(missionId)?.cancel()
        if (mission.status == MissionStatus.AwaitingApproval) {
            emit(
                missionId,
                phase = "pause",
                status = "paused",
                message = "Mission paused — still awaiting plan approval.",
            )
        } else {
            transition(missionId, status = MissionStatus.Paused, phase = "pause") { copy(error = "") }
        }
        return JSONObject().put("ok", true).put("mission_id", missionId).put("status", "paused")
    }

    suspend fun resume(missionId: String): JSONObject {
        val mission = persistence.find(missionId)
            ?: return failure(Contract.MISSION_NOT_FOUND, "No mission '$missionId'.")
        if (!mission.status.isResumable && mission.status != MissionStatus.AwaitingApproval) {
            return failure(
                Contract.MISSION_INVALID_STATE,
                "Mission in state '${mission.status.storageValue}' cannot be resumed.",
            )
        }
        if (mission.status == MissionStatus.AwaitingApproval) {
            update(missionId) { copy(startedAtMillis = nowMillis(), updatedAtMillis = nowMillis()) }
            launchPipeline(missionId)
            return JSONObject().put("ok", true).put("mission_id", missionId).put("status", "awaiting_approval")
        }
        transition(missionId, status = MissionStatus.Running, phase = "resume") {
            copy(error = "", startedAtMillis = nowMillis())
        }
        launchPipeline(missionId)
        return JSONObject().put("ok", true).put("mission_id", missionId).put("status", "running")
    }

    suspend fun cancel(missionId: String): JSONObject {
        val mission = persistence.find(missionId)
            ?: return failure(Contract.MISSION_NOT_FOUND, "No mission '$missionId'.")
        if (mission.status.isTerminal) {
            return failure(Contract.MISSION_INVALID_STATE, "Mission is already ${mission.status.storageValue}.")
        }
        missionJobs.remove(missionId)?.cancel(CancellationException("Cancelled by user."))
        approvals.remove(missionId)?.complete(false)
        transition(
            missionId,
            status = MissionStatus.Cancelled,
            phase = "cancel",
            cancelTasks = true,
        ) { copy(error = "Cancelled by user.", errorCategory = ArixRecoveryEngine.ErrorCategories.CANCELLED) }
        return JSONObject().put("ok", true).put("mission_id", missionId).put("status", "cancelled")
    }

    suspend fun retry(missionId: String): JSONObject {
        val mission = persistence.find(missionId)
            ?: return failure(Contract.MISSION_NOT_FOUND, "No mission '$missionId'.")
        if (mission.status != MissionStatus.Failed && mission.status != MissionStatus.Cancelled) {
            return failure(
                Contract.MISSION_INVALID_STATE,
                "Only failed or cancelled missions can be retried (current: ${mission.status.storageValue}).",
            )
        }
        transition(missionId, status = MissionStatus.Running, phase = "retry") {
            copy(
                plan = plan.map { task ->
                    when (task.status) {
                        MissionTaskStatus.Failed, MissionTaskStatus.Skipped, MissionTaskStatus.Cancelled ->
                            task.copy(
                                status = MissionTaskStatus.Pending,
                                attemptsUsed = 0,
                                error = "",
                                errorCategory = "",
                                resultJson = "",
                            )
                        else -> task
                    }
                },
                replanCycles = 0,
                error = "",
                errorCategory = "",
                finalResult = "",
                startedAtMillis = nowMillis(),
            )
        }
        launchPipeline(missionId)
        return JSONObject().put("ok", true).put("mission_id", missionId).put("status", "running")
    }

    suspend fun approve(missionId: String): JSONObject {
        val mission = persistence.find(missionId)
            ?: return failure(Contract.MISSION_NOT_FOUND, "No mission '$missionId'.")
        if (mission.status != MissionStatus.AwaitingApproval) {
            return failure(Contract.MISSION_INVALID_STATE, "Mission is not awaiting approval.")
        }
        approvals.getOrPut(missionId) { CompletableDeferred() }.complete(true)
        return JSONObject().put("ok", true).put("mission_id", missionId).put("status", "approved")
    }

    suspend fun reject(missionId: String): JSONObject {
        val mission = persistence.find(missionId)
            ?: return failure(Contract.MISSION_NOT_FOUND, "No mission '$missionId'.")
        if (mission.status != MissionStatus.AwaitingApproval) {
            return failure(Contract.MISSION_INVALID_STATE, "Mission is not awaiting approval.")
        }
        approvals.getOrPut(missionId) { CompletableDeferred() }.complete(false)
        return JSONObject().put("ok", true).put("mission_id", missionId).put("status", "rejected")
    }

    suspend fun delete(missionId: String): JSONObject {
        val mission = persistence.find(missionId)
            ?: return failure(Contract.MISSION_NOT_FOUND, "No mission '$missionId'.")
        if (!mission.status.isTerminal) {
            missionJobs.remove(missionId)?.cancel(CancellationException("Deleted by user."))
            approvals.remove(missionId)?.complete(false)
        }
        val removed = mutexFor(missionId).withLock {
            persistence.remove(missionId)
        }
        refreshStates()
        return if (removed) {
            JSONObject().put("ok", true).put("mission_id", missionId).put("deleted", true)
        } else {
            failure(Contract.MISSION_NOT_FOUND, "No mission '$missionId'.")
        }
    }

    suspend fun clearFinished(): JSONObject {
        val removed = persistence.clearFinished()
        if (removed > 0) refreshStates()
        return JSONObject()
            .put("ok", true)
            .put("deleted", removed)
            .put("hint", if (removed == 0) "No finished missions to clear." else "$removed finished mission(s) removed.")
    }

    suspend fun recoverInterruptedMissions(): Int {
        var recovered = 0
        persistence.snapshot().forEach { mission ->
            if (!mission.status.isTerminal && mission.status != MissionStatus.Paused) {
                if (mission.status == MissionStatus.AwaitingApproval) return@forEach
                transition(
                    mission.missionId,
                    status = MissionStatus.Interrupted,
                    phase = "recover",
                ) { copy(error = "Interrupted by process death — resumable from checkpoint.") }
                recovered += 1
            }
        }
        return recovered
    }

    fun liveMissions(): List<ArixMission> = persistence.snapshot()
        .filter { !it.status.isTerminal }
        .sortedByDescending { it.updatedAtMillis }

    private fun launchPipeline(missionId: String) {
        missionJobs[missionId]?.cancel()
        val job = scope.launch {
            try {
                runMissionPipeline(missionId)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (throwable: Throwable) {
                transition(
                    missionId,
                    status = MissionStatus.Failed,
                    phase = "pipeline_error",
                ) { copy(error = throwable.message ?: "unknown error", errorCategory = "UNKNOWN") }
            }
        }
        missionJobs[missionId] = job
        job.invokeOnCompletion { missionJobs.remove(missionId, job) }
    }

    private suspend fun runMissionPipeline(missionId: String) {
        var mission = persistence.find(missionId) ?: return
        try {
            checkpoint(mission, "understand", "Analyzing the objective.")

        if (mission.plan.isEmpty()) {
            mission = planMission(mission)
        }
        if (mission.plan.isEmpty()) {
            finishMission(mission.missionId, MissionStatus.Failed, "No executable plan could be produced.", "PLANNING_FAILED")
            return
        }

        if (mission.status == MissionStatus.AwaitingApproval) {
            emit(mission.missionId, phase = "plan", status = "waiting", message = "Awaiting plan approval.")
            val approved = approvals.getOrPut(missionId) { CompletableDeferred() }.await()
            approvals.remove(missionId)
            if (!approved) {
                finishMission(missionId, MissionStatus.Cancelled, "Plan rejected by user.", "CANCELLED")
                return
            }
            mission = update(missionId) { copy(status = MissionStatus.Running) } ?: return
        }

        mission = update(missionId) { copy(status = MissionStatus.Running) } ?: return

        while (true) {
            mission = persistence.find(missionId) ?: return
            if (mission.status == MissionStatus.Paused || mission.status == MissionStatus.Cancelled) return

            if (nowMillis() - mission.startedAtMillis > mission.globalTimeoutMillis) {
                finishMission(
                    missionId,
                    MissionStatus.Failed,
                    "Mission exceeded its global timeout " +
                        "(${mission.globalTimeoutMillis / 60_000} min).",
                    ArixRecoveryEngine.ErrorCategories.TIMEOUT,
                )
                return
            }
            if (mission.allStepsTerminal) break

            val ready = readyTasks(mission)
            if (ready.isEmpty()) {
                val cascade = mission.plan.filter { task ->
                    !task.isTerminal && task.dependsOn.any { dep ->
                        mission.plan.find { it.taskId == dep }?.isFailed == true
                    }
                }
                if (cascade.isEmpty()) break
                mission = update(missionId) {
                    copy(plan = plan.map { task ->
                        if (cascade.any { it.taskId == task.taskId }) {
                            task.copy(
                                status = MissionTaskStatus.Skipped,
                                error = "Skipped: a dependency failed.",
                            )
                        } else task
                    })
                } ?: return
                continue
            }
            executeWave(mission, ready)

            mission = persistence.find(missionId) ?: return
            if (mission.status != MissionStatus.Running) return
            val hasFailures = mission.plan.any { it.isFailed }
            val hasPending = mission.plan.any { !it.isTerminal }
            if (hasFailures && hasPending && mission.replanCycles < Contract.MAX_REPLAN_CYCLES) {
                mission = replan(mission)
            } else if (!hasPending) {
                break
            }
        }

        mission = persistence.find(missionId) ?: return
        if (mission.status.isTerminal) return
        val completedCount = mission.completedSteps.size
        if (completedCount == 0) {
            val firstError = mission.failedSteps.firstOrNull()?.error ?: "unknown failure"
            finishMission(missionId, MissionStatus.Failed, firstError, "EXECUTION_FAILED")
            return
        }
        synthesizeAndComplete(missionId)
        } catch (paused: MissionPausedException) {
            transition(missionId, MissionStatus.Paused, phase = "escalate") {
                copy(error = paused.reason)
            }
        } catch (cancelled: CancellationException) {
            throw cancelled
        }
    }

    private suspend fun planMission(mission: ArixMission): ArixMission {
        emit(mission.missionId, phase = "plan", status = "planning", message = "Creating the plan…")
        var planned = ArixMissionPlanner.planWithModel(mission.objective) { prompt -> modelComplete.complete(prompt) }
        if (planned == null) {
            planned = ArixMissionPlanner.PlanResult(
                steps = listOf(
                    ArixMissionPlanner.PlannedStep(
                        description = "Accomplish the objective autonomously",
                        requiredCapability = "analysis",
                        instruction = "Accomplish this objective with the tools available; verify your " +
                            "work before finishing.\n\nOBJECTIVE: ${mission.objective}",
                        priority = 5,
                    ),
                ),
                understanding = "Direct autonomous execution.",
                planner = "fallback-agent",
            )
        }
        val reIded = planned.steps.take(Contract.MAX_STEPS_HARD_CAP)
            .mapIndexed { index, step -> step.toTask().copy(taskId = "s${index + 1}") }
        val reDeps = reIded.mapIndexed { index, task ->
            task.copy(dependsOn = task.dependsOn.mapNotNull { dep ->
                val depIndex = dep.removePrefix("s").toIntOrNull()
                if (depIndex != null && depIndex in 1..reIded.size && depIndex != index + 1) {
                    "s$depIndex"
                } else null
            })
        }
        val validation = ArixMissionPlanner.PlanValidator.validate(reDeps)
        if (!validation.valid) {
            checkpoint(mission, "plan", "Plan rejected by validator: ${validation.problems.joinToString("; ")}")
            return mission
        }
        val needsApproval = mission.requireApproval ||
            (reDeps.any { it.requiredCapability in DestructiveCapabilities } && reDeps.size >= 2)
        val status = if (needsApproval) MissionStatus.AwaitingApproval else MissionStatus.Running
        val updated = update(mission.missionId) {
            copy(
                plan = reDeps,
                understanding = planned.understanding,
                status = status,
            )
        } ?: return mission
        checkpoint(updated, "plan", "Plan ready (${reDeps.size} steps, planner=${planned.planner}).")
        emit(
            mission.missionId,
            phase = "plan",
            status = if (needsApproval) "waiting" else "queued",
            message = "Plan: ${reDeps.joinToString(" → ") { it.description.take(40) }}",
        )
        return updated
    }

    private suspend fun executeWave(mission: ArixMission, ready: List<MissionTask>) {
        val nonMutating = ready.filter { !it.mutating }.take(mission.maxConcurrency)
        val mutating = ready.filter { it.mutating }
        val wave = nonMutating + mutating
        emit(
            mission.missionId,
            phase = "execute",
            status = "running",
            message = "Executing ${wave.size} step(s)${if (nonMutating.size > 1) " in parallel" else ""}…",
        )
        coroutineScope {
            wave.forEach { task ->
                launch {
                    val updated = executeTaskWithRecovery(mission, task)
                    mergeTask(mission.missionId, updated)
                }
            }
        }
    }

    private suspend fun executeTaskWithRecovery(mission: ArixMission, task: MissionTask): MissionTask {
        var current = task
        update(mission.missionId) {
            copy(
                plan = plan.map { if (it.taskId == task.taskId) it.copy(status = MissionTaskStatus.Running, startedAtMillis = nowMillis()) else it },
                activeTools = activeTools,
            )
        }
        emit(mission.missionId, task.taskId, phase = "execute", status = "running", message = "${task.description}…")

        var attempts = task.attemptsUsed
        val maxAttempts = (task.retryPolicy.maxAttempts + 1).coerceAtMost(4)
        while (true) {
            attempts += 1
            val budgetExceeded = bumpExecutionBudget(mission.missionId)
            if (budgetExceeded) {
                return current.copy(
                    status = MissionTaskStatus.Failed,
                    error = "Mission execution budget exhausted.",
                    errorCategory = ArixRecoveryEngine.ErrorCategories.REPEATED_FAILURE,
                    completedAtMillis = nowMillis(),
                )
            }
            val tool = resolveTool(current)
            update(mission.missionId) {
                copy(plan = plan.map {
                    if (it.taskId == task.taskId) it.copy(attemptsUsed = attempts, executedWithTool = tool) else it
                })
            }
            val rawOutput = try {
                withTimeoutOrNull(current.timeoutMillis) {
                    if (current.mutating) {
                        mutationMutex.withLock { executor.execute(current, tool, mission) }
                    } else {
                        executor.execute(current, tool, mission)
                    }
                } ?: timeoutOutput(current.timeoutMillis)
            } catch (error: CancellationException) {
                throw error
            } catch (error: MissionPausedException) {
                throw error
            } catch (error: Throwable) {
                executionFailedOutput(error)
            }

            val ok = inferOk(rawOutput)
            var errorCategory = ""
            var errorMessage = ""
            if (ok) {
                emit(mission.missionId, task.taskId, phase = "verify", status = "verifying", message = "Verifying result…")
                update(mission.missionId) {
                    copy(plan = plan.map {
                        if (it.taskId == task.taskId) it.copy(status = MissionTaskStatus.Verifying) else it
                    })
                }
                val outcome = verificationEngine.verify(current, rawOutput)
                if (outcome.verified) {
                    emit(mission.missionId, task.taskId, phase = "verify", status = "completed", message = "Verified.")
                    return current.copy(
                        status = MissionTaskStatus.Completed,
                        resultJson = rawOutput,
                        resultSummary = summarize(rawOutput),
                        completedAtMillis = nowMillis(),
                        error = "",
                        errorCategory = "",
                        attemptsUsed = attempts,
                        executedWithTool = tool,
                    )
                }
                errorCategory = ArixRecoveryEngine.ErrorCategories.VERIFICATION_FAILED
                errorMessage = outcome.reason
            } else {
                errorCategory = ArixRecoveryEngine.classify(rawOutput)
                errorMessage = extractMessage(rawOutput)
            }

            if (attempts >= maxAttempts) {
                return current.copy(
                    status = MissionTaskStatus.Failed,
                    error = errorMessage.ifBlank { "Step failed after $attempts attempts." },
                    errorCategory = errorCategory,
                    resultJson = rawOutput,
                    attemptsUsed = attempts,
                    executedWithTool = tool,
                    completedAtMillis = nowMillis(),
                )
            }

            val decision = ArixRecoveryEngine.decide(current, errorCategory, errorMessage)
            when (decision.strategy) {
                ArixRecoveryEngine.Strategy.RETRY -> {
                    emit(
                        mission.missionId, task.taskId, phase = "recover", status = "running",
                        message = "Retrying (attempt $attempts→${attempts + 1}): ${decision.reason}",
                    )
                    if (decision.backoffMillis > 0) delayMillis(decision.backoffMillis)
                    current = current.copy(executedWithTool = tool)
                }
                ArixRecoveryEngine.Strategy.ALTERNATIVE_TOOL -> {
                    emit(
                        mission.missionId, task.taskId, phase = "recover", status = "running",
                        message = "Switching tool → ${decision.alternativeTool}: ${decision.reason}",
                    )
                    current = current.copy(
                        preferredTool = decision.alternativeTool ?: tool,
                        executedWithTool = tool,
                    )
                }
                ArixRecoveryEngine.Strategy.REFINE_INPUT -> {
                    emit(
                        mission.missionId, task.taskId, phase = "recover", status = "running",
                        message = "Refining input after failure: ${decision.reason}",
                    )
                    current = current.copy(
                        instruction = refineInstruction(current.instruction, errorCategory, errorMessage),
                        executedWithTool = tool,
                    )
                }
                ArixRecoveryEngine.Strategy.ESCALATE_USER -> {
                    throw MissionPausedException(
                        "Step '${current.description}' needs a user decision: $errorMessage",
                    )
                }
                ArixRecoveryEngine.Strategy.ABORT -> {
                    return current.copy(
                        status = MissionTaskStatus.Failed,
                        error = decision.reason,
                        errorCategory = errorCategory,
                        resultJson = rawOutput,
                        attemptsUsed = attempts,
                        executedWithTool = tool,
                        completedAtMillis = nowMillis(),
                    )
                }
            }
        }
    }

    private suspend fun replan(mission: ArixMission): ArixMission {
        val failed = mission.failedSteps
        emit(
            mission.missionId,
            phase = "replan",
            status = "planning",
            message = "Replanning after ${failed.size} failed step(s) (cycle ${mission.replanCycles + 1}/" +
                "${Contract.MAX_REPLAN_CYCLES}).",
        )
        val completedSummaries = mission.completedSteps.joinToString("\n") { task ->
            "- ${task.description}: ${task.resultSummary.take(200)}"
        }
        return update(mission.missionId) {
            copy(
                replanCycles = replanCycles + 1,
                plan = plan.map { task ->
                    when {
                        task.isFailed -> task.copy(
                            status = MissionTaskStatus.Pending,
                            attemptsUsed = 0,
                            executedWithTool = "",
                            error = "",
                            errorCategory = "",
                            instruction = refineInstruction(task.instruction, task.errorCategory, task.error) +
                                completedContext(completedSummaries),
                        )
                        task.status == MissionTaskStatus.Skipped -> task.copy(
                            status = MissionTaskStatus.Pending,
                            error = "",
                        )
                        else -> task
                    }
                },
            )
        } ?: mission
    }

    private suspend fun synthesizeAndComplete(missionId: String) {
        val mission = persistence.find(missionId) ?: return
        emit(missionId, phase = "synthesize", status = "verifying", message = "Synthesizing the final result…")
        val prompt = buildString {
            append("Synthesize the FINAL answer for the user's mission from the completed step results. ")
            append("Be concise and complete; include file paths for any artifacts; note any failed steps.\n\n")
            append("OBJECTIVE: ")
            append(mission.objective)
            append("\n\nSTEP RESULTS:\n")
            mission.plan.forEach { task ->
                append("- [${task.status.storageValue}] ${task.description}: ")
                append(task.resultSummary.ifBlank { task.error }.take(600))
                append('\n')
            }
        }
        val synthesisTimeoutMillis = (
            mission.startedAtMillis + mission.globalTimeoutMillis - nowMillis()
            ).coerceIn(1_000L, SynthesisModelTimeoutMillis)
        val modelResult = try {
            withTimeout(synthesisTimeoutMillis) { modelComplete.complete(prompt) }
        } catch (timeout: TimeoutCancellationException) {
            null
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (error: Throwable) {
            null
        }
        val localFallback = buildString {
            append("Mission complete: ")
            append(mission.objective)
            append("\n\n")
            mission.completedSteps.forEach { task ->
                append("• ")
                append(task.description)
                append(": ")
                append(task.resultSummary.take(400))
                append('\n')
            }
            if (mission.failedSteps.isNotEmpty()) {
                append("\nFailed steps: ")
                append(mission.failedSteps.joinToString("; ") { it.description })
            }
        }
        val finalResult = modelResult?.take(8_000)?.ifBlank { null } ?: localFallback
        finishMission(
            missionId,
            MissionStatus.Completed,
            "",
            "",
            finalResult = finalResult,
        )
    }

    private fun readyTasks(mission: ArixMission): List<MissionTask> =
        mission.plan.filter { task ->
            task.status == MissionTaskStatus.Pending &&
                task.dependsOn.all { dep ->
                    mission.plan.find { it.taskId == dep }?.isCompleted == true ||
                        mission.plan.none { it.taskId == dep }
                }
        }.sortedByDescending { it.priority }

    internal fun resolveTool(task: MissionTask): String {
        task.preferredTool?.let { preferred ->
            if (ArixToolRouter.capabilityFor(preferred) != null) return preferred
        }
        if (task.requiredCapability in ArixMissionPlanner.PlanValidator.OpenCapabilities) return "agent_turn"
        return ArixToolRouter.selectTool(task.requiredCapability)?.toolId ?: "agent_turn"
    }

    private suspend fun mergeTask(missionId: String, task: MissionTask) {
        update(missionId) {
            copy(plan = plan.map { if (it.taskId == task.taskId) task else it })
        }
        checkpoint(persistence.find(missionId) ?: return, "execute", "${task.description} → ${task.status.storageValue}")
    }

    private suspend fun bumpExecutionBudget(missionId: String): Boolean {
        var exceeded = false
        update(missionId) {
            val ceiling = plan.size * Contract.MAX_TOTAL_TASK_EXECUTIONS_FACTOR +
                Contract.MAX_TOTAL_TASK_EXECUTIONS_FLOOR
            if (totalTaskExecutions >= ceiling) {
                exceeded = true
                this
            } else {
                copy(totalTaskExecutions = totalTaskExecutions + 1)
            }
        } ?: return true
        return exceeded
    }

    private suspend fun finishMission(
        missionId: String,
        status: MissionStatus,
        error: String,
        errorCategory: String,
        finalResult: String = "",
    ) {
        missionJobs.remove(missionId)?.cancel(CancellationException("Mission finished."))
        update(missionId) {
            copy(
                status = status,
                error = error,
                errorCategory = errorCategory,
                finalResult = finalResult,
                currentStep = status.storageValue,
                updatedAtMillis = nowMillis(),
            )
        }
        persistence.pruneFinished()
        refreshStates()
        emit(
            missionId,
            phase = "complete",
            status = status.storageValue,
            message = when (status) {
                MissionStatus.Completed -> "Mission completed."
                MissionStatus.Failed -> "Mission failed: ${error.take(200)}"
                MissionStatus.Cancelled -> "Mission cancelled."
                else -> status.storageValue
            },
        )
    }

    private suspend fun transition(
        missionId: String,
        status: MissionStatus,
        phase: String,
        cancelTasks: Boolean = false,
        transform: ArixMission.() -> ArixMission = { this },
    ) {
        update(missionId) {
            val transformed = transform(this)
            transformed.copy(
                status = status,
                updatedAtMillis = nowMillis(),
                plan = if (cancelTasks) transformed.plan.map { task ->
                    if (!task.isTerminal) task.copy(status = MissionTaskStatus.Cancelled) else task
                } else transformed.plan,
            )
        }
        emit(
            missionId,
            phase = phase,
            status = status.storageValue,
            message = "Mission ${status.storageValue.replace('_', ' ')}.",
        )
    }

    private suspend fun update(missionId: String, transform: ArixMission.() -> ArixMission): ArixMission? {
        val updated = mutexFor(missionId).withLock {
            val mission = persistence.find(missionId) ?: return@withLock null
            mission.transform()
                .copy(updatedAtMillis = nowMillis())
                .withProgress()
                .also { persistence.upsert(it) }
        }
        if (updated != null) refreshStates()
        return updated
    }

    private suspend fun checkpoint(mission: ArixMission, phase: String, detail: String) {
        val checkpoint = MissionCheckpoint(atMillis = nowMillis(), phase = phase, detail = detail)
        update(mission.missionId) {
            copy(checkpoints = (checkpoints + checkpoint).takeLast(MaxCheckpoints))
        }
    }

    private fun refreshStates() {
        _states.value = persistence.snapshot().sortedByDescending { it.updatedAtMillis }
    }

    private fun emit(
        missionId: String,
        taskId: String? = null,
        phase: String,
        status: String,
        message: String,
    ) {
        _events.tryEmit(
            MissionEvent(
                missionId = missionId,
                taskId = taskId,
                phase = phase,
                status = status,
                message = message,
                atMillis = nowMillis(),
            ),
        )
    }

    private fun inferOk(rawOutput: String): Boolean {
        val parsed = runCatching { JSONObject(rawOutput) }.getOrNull() ?: return false
        return parsed.optBoolean("ok", false)
    }

    private fun summarize(rawOutput: String): String {
        val parsed = runCatching { JSONObject(rawOutput) }.getOrNull() ?: return rawOutput.take(200)
        val result = parsed.optJSONObject("result")
        listOfNotNull(
            result?.optString("summary")?.takeIf { it.isNotBlank() },
            result?.optString("stdout")?.takeIf { it.isNotBlank() },
            parsed.optString("summary")?.takeIf { it.isNotBlank() },
        ).firstOrNull()?.let { return it.take(400) }
        return rawOutput.take(200)
    }

    private fun extractMessage(rawOutput: String): String {
        val parsed = runCatching { JSONObject(rawOutput) }.getOrNull()
            ?: return rawOutput.take(200).ifBlank { "unknown error" }
        return parsed.optString("message").takeIf { it.isNotBlank() }
            ?: parsed.optString("error").takeIf { it.isNotBlank() }
            ?: rawOutput.take(200)
    }

    private fun timeoutOutput(timeoutMillis: Long): String = JSONObject()
        .put("ok", false)
        .put("error_code", ArixRecoveryEngine.ErrorCategories.TIMEOUT)
        .put("message", "Step did not finish within ${timeoutMillis / 1000}s and was cancelled.")
        .toString()

    private fun executionFailedOutput(error: Throwable): String = JSONObject()
        .put("ok", false)
        .put("error_code", ArixRecoveryEngine.ErrorCategories.EXECUTION_FAILED)
        .put("message", error.message ?: "Step execution failed.")
        .toString()

    private fun refineInstruction(instruction: String, category: String, message: String): String =
        buildString {
            append(instruction)
            append("\n\nNOTE: a previous attempt failed with ")
            append(category)
            append(" — ")
            append(message.take(300))
            append(" Adjust your strategy accordingly (different source, different selector, smaller ")
            append("scope, or corrected arguments).")
        }

    private fun completedContext(completedSummaries: String): String =
        if (completedSummaries.isBlank()) "" else "\n\nAlready-completed steps you can build on:\n$completedSummaries"

    private fun failure(code: String, message: String): JSONObject = JSONObject()
        .put("ok", false)
        .put("error_code", code)
        .put("message", message)

    private companion object {
        const val MaxCheckpoints = 24

        const val SynthesisModelTimeoutMillis = 120_000L

        val DestructiveCapabilities = setOf(
            "payment",
        )
    }
}

internal fun ArixMission.toPublicJson(includePlan: Boolean): JSONObject = toJson().apply {
    put("progressPct", (progress * 100).toInt())
    put("pendingSteps", pendingSteps.size)
    put("completedSteps", completedSteps.size)
    put("failedSteps", failedSteps.size)
    if (includePlan) {
        put("steps", JSONArray(plan.map { task ->
            JSONObject()
                .put("taskId", task.taskId)
                .put("description", task.description)
                .put("capability", task.requiredCapability)
                .put("tool", task.executedWithTool)
                .put("status", task.status.storageValue)
                .put("attempts", task.attemptsUsed)
                .put("dependsOn", JSONArray(task.dependsOn))
                .put("resultSummary", task.resultSummary.take(400))
                .put("error", task.error.take(300))
        }))
    }
}
