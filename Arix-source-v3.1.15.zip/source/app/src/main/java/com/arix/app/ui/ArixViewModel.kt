package com.arix.app.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import java.io.FileOutputStream
import com.arix.app.BuildConfig
import com.arix.app.R
import com.arix.app.ArixIncomingRequests
import com.arix.app.arixRuntime
import com.arix.app.data.ActiveSkillContext
import com.arix.app.data.AutomaticModelPurpose
import com.arix.app.data.AgentWorkspaceMode
import com.arix.app.data.TermuxEnvironmentVariable
import com.arix.app.data.AppLanguage
import com.arix.app.data.AppSettings
import com.arix.app.data.normalizeReasoningEffort
import com.arix.app.data.AppThemeMode
import com.arix.app.data.CurrentOnboardingVersion
import com.arix.app.data.DiagnosticRedactor
import com.arix.app.data.InstalledSkill
import com.arix.app.data.PiDiscoveredSkillSource
import com.arix.app.data.ProviderModelCatalogClient
import com.arix.app.data.thinkingCatalogKey
import com.arix.app.data.LlmProviderConfig
import com.arix.app.data.LlmTokenUsage
import com.arix.app.data.ModelCatalogClient
import com.arix.app.data.LocalRuntimeId
import com.arix.app.data.ProviderModelOption
import com.arix.app.data.PersistedChatState
import com.arix.app.data.PersistedChatWriteIntent
import com.arix.app.data.availableModelOptions
import com.arix.app.data.normalizeSelectableModelKey
import com.arix.app.data.normalizeLlmInactivityReconnectTimeoutSeconds
import com.arix.app.data.normalizeLlmUserAgent
import com.arix.app.data.normalizeOldCommandHistoryRetentionHours
import com.arix.app.data.normalizeTavilyBaseUrl
import com.arix.app.data.normalizeWebSearchEngine
import com.arix.app.data.OnboardingStarterPrompt
import com.arix.app.data.ScheduledTask
import com.arix.app.data.ScheduledTaskCreator
import com.arix.app.data.ScheduledTaskSchedule
import com.arix.app.data.normalizeTermuxEnvironmentVariables
import com.arix.app.data.SessionFollowUpMode
import com.arix.app.data.SessionExecutionState
import com.arix.app.data.SessionTurnEvent
import com.arix.app.data.SessionTurnOutcome
import com.arix.app.data.SessionTurnRequest
import com.arix.app.data.parseChatSessions
import com.arix.app.data.parseCustomHeaders
import com.arix.app.data.parseProviderConfigs
import com.arix.app.data.serializeChatSessions
import com.arix.app.data.serializeProviderConfigs
import com.arix.app.data.toJson
import com.arix.app.data.toJsonArray
import com.arix.app.data.ProviderAuthMethod
import com.arix.app.data.pi.PiCompletionClient
import com.arix.app.data.pi.PiKernelBridge
import com.arix.app.data.pi.PiCoreSetupActivity
import com.arix.app.data.pi.PiCoreSetupPhase
import com.arix.app.data.pi.PiCoreSetupState
import com.arix.app.data.pi.PiCoreSetupUpdate
import com.arix.app.data.pi.PiProviderAuthState
import com.arix.app.data.pi.bridgeProviderThinkingResult
import com.arix.app.data.pi.mergeThinkingCatalogResults
import com.arix.app.data.PublicCatalogThinkingResult
import com.arix.app.data.pi.toPiOAuthPrompt
import com.arix.app.data.pi.toPiProviderEnvironmentVariables
import com.arix.app.data.pi.toPiModelConfig
import com.arix.app.data.shouldLaunchOnboarding
import com.arix.app.data.resolveDefaultChatModelKey
import com.arix.app.data.resolveDefaultCompactingModelKey
import com.arix.app.data.resolveModelSettings
import com.arix.app.data.resolveStoredOrAutomaticModelKey
import com.arix.app.runtime.TermuxTerminalLaunchSpec
import com.arix.app.runtime.TermuxSetupActivity
import com.arix.app.runtime.LocalRuntimeIssue
import com.arix.app.runtime.LocalRuntimeSetupState
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.Base64
import java.util.Locale
import java.util.UUID

private const val LogcatReadTimeoutSeconds = 4L
private const val MaxSetupOutputChars = 48_000
private const val SessionTitleSystemPrompt =
    "Generate a concise chat title for this conversation. Return only the title, in the user's language when possible, with no quotes, no emoji, and at most 6 words."
private const val CompactCommand = "/compact"

private val ContinueRequestPattern = Regex(
    pattern = "^(?:continue|go[\\s,-]+on|keep[\\s,-]+going|carry[\\s,-]+on|resume|jari[\\s,-]+rakho|jaari[\\s,-]+rakho|continue[\\s,-]+from[\\s,-]+where[\\s,-]+you[\\s,-]+(?:left[\\s,-]+off|stopped)|continue[\\s,-]+please)[\\s]*[!.,…~]*[\\s]*$",
    options = setOf(RegexOption.IGNORE_CASE),
)

private val FarewellMessagePattern = Regex(
    pattern = "^(?:bye(?:[\\s,-]+for[\\s,-]+now)?|good[\\s-]?bye|see[\\s,-]+you(?:[\\s,-]+(?:later|soon|again))?|see[\\s,-]+ya|take[\\s,-]+care|good[\\s,-]+night|alvida|tata|cya|farewell)[\\s]*[!.,…~*]*[\\s]*$",
    options = setOf(RegexOption.IGNORE_CASE),
)
private const val ContextWindowTokens = 128_000L
private const val AutoCompactionReserveTokens = 16_384L
private const val MaxInlineImageAttachmentBytes = 5 * 1024 * 1024

internal fun shouldAutoCompactContext(
    usage: LlmTokenUsage?,
    tokenUsageSource: String,
    assistantText: String,
    contextWindow: Long = ContextWindowTokens,
    reserveTokens: Long = AutoCompactionReserveTokens,
): Boolean {
    val totalTokens = usage?.withMissingTotalResolved()?.totalTokens ?: return false
    if (contextWindow <= reserveTokens) return false
    val trailingEstimate = if (tokenUsageSource == "estimated") {
        (assistantText.length + 3L) / 4L
    } else {
        0L
    }
    return totalTokens + trailingEstimate > contextWindow - reserveTokens
}

class ArixViewModel(
    application: Application,
) : AndroidViewModel(application) {
    private val runtime = application.arixRuntime
    private val diagnosticLogger = runtime.diagnosticLogger
    private val settingsRepository = runtime.settingsRepository
    private val chatStateStore = runtime.chatStateStore
    private val extensionsRepository = runtime.extensionsRepository
    private val sessionExecutionManager = runtime.sessionExecutionManager
    private val piCompletionClient: PiCompletionClient = runtime.piCompletionClient
    private val piKernelBridge: PiKernelBridge = runtime.piKernelBridge
    private val workspaceFileBridge = runtime.workspaceFileBridge
    private val runtimeWorkspaceFileBridge = runtime.runtimeWorkspaceFileBridge
    private val webViewFetcher by lazy { com.arix.app.data.WebViewFetcher(application) }
    private val skillManager = runtime.skillManager
    private val scheduledTaskManager = runtime.scheduledTaskManager
    private var lastModelCatalogRequestKey: String = ""
    private var didInitializeStartupDraftModel = false
    private var didReceiveInitialChatState = false
    private val _uiState = MutableStateFlow(ArixUiState())
    private val _transientMessages = MutableSharedFlow<UiText>(extraBufferCapacity = 16)
    private val messageIdCounter = java.util.concurrent.atomic.AtomicLong(0)
    private var didEvaluateWorkspaceMode = false
    private var selectSessionJob: Job? = null
    private var providerAuthJob: Job? = null
    private var didRefreshTermuxAfterSettingsLoad = false

    val uiState: StateFlow<ArixUiState> = _uiState.asStateFlow()
    val transientMessages = _transientMessages.asSharedFlow()

    init {
        ensureBuiltInSkillsInstalled()

        viewModelScope.launch {
            ArixIncomingRequests.pendingText.collect { incoming ->
                if (incoming != null) {
                    handleIncomingExternalText(incoming)
                }
            }
        }

        viewModelScope.launch {
            settingsRepository.initializeLanguageIfNeeded()
            settingsRepository.initializeWebSearchEngineMigrationIfNeeded()
            settingsRepository.settings.collect { settings ->
                _uiState.update { current ->
                    if (!current.isStartupRouteResolved) {
                        current.copy(
                            settings = settings,
                            currentScreen = if (settings.shouldLaunchOnboarding()) {
                                AppScreen.Welcome
                            } else {
                                AppScreen.Chat
                            },
                            isStartupRouteResolved = true,
                        )
                    } else {
                        current.copy(settings = settings)
                    }
                }
                initializeStartupDraftModelIfReady()
                runtime.termuxRuntime.setEnvironmentVariables(settings.termuxEnvironmentVariables)
                if (!didRefreshTermuxAfterSettingsLoad) {
                    didRefreshTermuxAfterSettingsLoad = true
                    refreshTermuxSetup(startPiIfReady = false)
                }
                maybeInitializeWorkspaceMode(settings)
            }
        }

        viewModelScope.launch {
            var didReceiveChatState = false
            chatStateStore.state.collect { persisted ->
                if (!didReceiveChatState && persisted.sessions.isEmpty() && persisted.currentSessionId == DraftSessionId) {
                    didReceiveChatState = true
                    didReceiveInitialChatState = true
                    initializeStartupDraftModelIfReady()
                    return@collect
                }
                didReceiveChatState = true
                val hydratedPersisted = hydrateCurrentSessionMessages(persisted)
                _uiState.update { current ->
                    val currentSessionId = hydratedPersisted.currentSessionId.ifBlank { DraftSessionId }
                    val currentExecution = current.sessionExecutionStates[currentSessionId]
                    current.copy(
                        sessions = hydratedPersisted.sessions,
                        currentSessionId = currentSessionId,
                        isSending = currentExecution?.isRunning == true,
                        pendingResponseSessionId = currentExecution?.sessionId,
                        pendingToolInvocations = currentExecution?.pendingToolInvocations.orEmpty(),
                        pendingResponseBlocks = currentExecution?.pendingResponseBlocks.orEmpty(),
                        pendingAssistantText = currentExecution?.pendingAssistantText.orEmpty(),
                        pendingStatusText = currentExecution?.pendingStatusText.orEmpty(),
                        pendingStatusDetail = currentExecution?.pendingStatusDetail.orEmpty(),
                    )
                }
                didReceiveInitialChatState = true
                initializeStartupDraftModelIfReady()
            }
        }

        viewModelScope.launch {
            sessionExecutionManager.executionStates.collect { executionStates ->
                _uiState.update { current ->
                    val currentExecution = executionStates[current.currentSessionId]
                    current.copy(
                        sessionExecutionStates = executionStates,
                        isSending = currentExecution?.isRunning == true,
                        pendingResponseSessionId = currentExecution?.sessionId,
                        pendingToolInvocations = currentExecution?.pendingToolInvocations.orEmpty(),
                        pendingResponseBlocks = currentExecution?.pendingResponseBlocks.orEmpty(),
                        pendingAssistantText = currentExecution?.pendingAssistantText.orEmpty(),
                        pendingStatusText = currentExecution?.pendingStatusText.orEmpty(),
                        pendingStatusDetail = currentExecution?.pendingStatusDetail.orEmpty(),
                    )
                }
            }
        }

        viewModelScope.launch {
            sessionExecutionManager.turnEvents.collect { event ->
                handleTurnEvent(event)
            }
        }

        viewModelScope.launch {
            extensionsRepository.extensionState.collect { extensionState ->
                var didPruneSelections = false
                val enabledSkillIds = extensionState.installedSkills
                    .filter { it.isEnabled }
                    .map { it.id }
                    .toSet()
                _uiState.update { current ->
                    val updatedSessions = current.sessions.map { session ->
                        val updatedSelectedSkillIds = session.selectedSkillIds.filter(enabledSkillIds::contains)
                        val updatedActiveSkills = session.activeSkills.filter { activeSkill ->
                            updatedSelectedSkillIds.contains(activeSkill.skillId)
                        }
                        if (
                            updatedSelectedSkillIds != session.selectedSkillIds ||
                            updatedActiveSkills != session.activeSkills
                        ) {
                            didPruneSelections = true
                            session.copy(
                                selectedSkillIds = updatedSelectedSkillIds,
                                activeSkills = updatedActiveSkills,
                            )
                        } else {
                            session
                        }
                    }
                    val updatedDraftSelectedSkillIds = current.draftSelectedSkillIds.filter(enabledSkillIds::contains)
                    if (updatedDraftSelectedSkillIds != current.draftSelectedSkillIds) {
                        didPruneSelections = true
                    }
                    current.copy(
                        sessions = updatedSessions,
                        draftSelectedSkillIds = updatedDraftSelectedSkillIds,
                        installedSkills = extensionState.installedSkills,
                    )
                }
                if (didPruneSelections) {
                    persistPrunedSessionSelections(
                        enabledSkillIds = enabledSkillIds,
                    )
                }
            }
        }

        viewModelScope.launch {
            settingsRepository.providerConfigs.collect { configs ->
                _uiState.update { current -> current.copy(providerConfigs = configs) }
                initializeStartupDraftModelIfReady()
                refreshModelCatalogInfo(configs)
            }
        }
        viewModelScope.launch {
            scheduledTaskManager.scheduledTasks.collect { tasks ->
                _uiState.update { current -> current.copy(scheduledTasks = tasks) }
            }
        }
    }

    private fun refreshModelCatalogInfo(configs: List<LlmProviderConfig>) {
        val options = configs.availableModelOptions()
        val requestKey = options.joinToString("|") { "${it.key}:${it.fullLabel}" }
        if (requestKey == lastModelCatalogRequestKey) return
        lastModelCatalogRequestKey = requestKey
        if (options.isEmpty()) {
            _uiState.update { current -> current.copy(modelCatalogInfo = emptyMap()) }
            return
        }
        viewModelScope.launch {
            if (_uiState.value.modelCatalogInfo.isEmpty()) {
                val cached = settingsRepository.loadModelCatalogCache()
                    .filterKeys(options.mapTo(mutableSetOf(), ProviderModelOption::key)::contains)
                if (cached.isNotEmpty() && requestKey == lastModelCatalogRequestKey) {
                    _uiState.update { current -> current.copy(modelCatalogInfo = cached) }
                }
            }
            val thinkingCacheKeys = options.mapTo(mutableSetOf()) { option ->
                thinkingCatalogKey(option.piProviderId, option.modelId)
            }
            val cachedThinkingLevels = settingsRepository.loadThinkingCatalogCache()
                .filterKeys(thinkingCacheKeys::contains)
            val cachedThinkingLevelMaps = settingsRepository.loadThinkingLevelMapsCache()
                .filterKeys(thinkingCacheKeys::contains)
            val cachedReasoningModels = settingsRepository.loadReasoningModelsCache()
                .filterTo(mutableSetOf(), thinkingCacheKeys::contains)
            val cachedModelLimits = settingsRepository.loadModelLimitsCache()
                .filterKeys(thinkingCacheKeys::contains)
            if (cachedThinkingLevels.isNotEmpty() && requestKey == lastModelCatalogRequestKey) {
                _uiState.update { current ->
                    current.copy(
                        thinkingLevelsByProviderModel = current.thinkingLevelsByProviderModel + cachedThinkingLevels,
                        thinkingLevelClampsByProviderModel = current.thinkingLevelClampsByProviderModel + cachedThinkingLevelMaps,
                        reasoningModels = current.reasoningModels + cachedReasoningModels,
                        modelLimitsByProviderModel = current.modelLimitsByProviderModel + cachedModelLimits,
                    )
                }
            }
            val modelInfo = ModelCatalogClient.fetchModelInfo(options)
            if (modelInfo.isNotEmpty()) {
                settingsRepository.saveModelCatalogCache(modelInfo)
            }
            if (modelInfo.isNotEmpty() && requestKey == lastModelCatalogRequestKey) {
                _uiState.update { current -> current.copy(modelCatalogInfo = modelInfo) }
            }

            val catalogResult = fetchMergedThinkingCatalog(options)
            if (catalogResult.levelsByProviderModel.isNotEmpty()) {
                settingsRepository.saveThinkingCatalogCache(
                    catalogResult.levelsByProviderModel,
                    catalogResult.levelMapsByProviderModel,
                    catalogResult.reasoningModels,
                    catalogResult.limitsByProviderModel,
                )
                if (requestKey == lastModelCatalogRequestKey) {
                    _uiState.update { state ->
                        state.copy(
                            thinkingLevelsByProviderModel =
                                state.thinkingLevelsByProviderModel + catalogResult.levelsByProviderModel,
                            thinkingLevelClampsByProviderModel =
                                (state.thinkingLevelClampsByProviderModel -
                                    catalogResult.levelsByProviderModel.keys) +
                                    catalogResult.levelMapsByProviderModel,
                            reasoningModels =
                                (state.reasoningModels - catalogResult.levelsByProviderModel.keys) +
                                    catalogResult.reasoningModels,
                            modelLimitsByProviderModel =
                                (state.modelLimitsByProviderModel - catalogResult.levelsByProviderModel.keys) +
                                    catalogResult.limitsByProviderModel,
                        )
                    }
                }
            }
        }
    }

    private suspend fun fetchMergedThinkingCatalog(
        options: List<ProviderModelOption>,
    ): PublicCatalogThinkingResult {
        val publicResult = ProviderModelCatalogClient.fetchPublicThinkingCatalog(options)
        val bridgeResult = fetchBridgeThinkingCatalog(options)
        return mergeThinkingCatalogResults(publicResult, bridgeResult)
    }

    private suspend fun fetchBridgeThinkingCatalog(
        options: List<ProviderModelOption>,
    ): PublicCatalogThinkingResult {
        if (options.isEmpty()) return PublicCatalogThinkingResult()
        val payload = try {
            runtime.piKernelBridge.listProviders(startIfNeeded = false)
        } catch (cancellationException: CancellationException) {
            throw cancellationException
        } catch (throwable: Throwable) {
            null
        } ?: return PublicCatalogThinkingResult()
        return bridgeProviderThinkingResult(payload, options)
    }

    private fun refreshBridgeThinkingCatalog() {
        viewModelScope.launch {
            val current = _uiState.value
            val options = current.providerConfigs.availableModelOptions()
            if (options.isEmpty()) return@launch
            val bridgeResult = fetchBridgeThinkingCatalog(options)
            if (bridgeResult.levelsByProviderModel.isEmpty()) return@launch
            val bridgeKeys = bridgeResult.levelsByProviderModel.keys
            val cachedLevelMaps = settingsRepository.loadThinkingLevelMapsCache()
                .filterKeys(bridgeKeys::contains)
            settingsRepository.saveThinkingCatalogCache(
                bridgeResult.levelsByProviderModel,
                cachedLevelMaps,
                bridgeResult.reasoningModels,
            )
            _uiState.update { state ->
                state.copy(
                    thinkingLevelsByProviderModel =
                        state.thinkingLevelsByProviderModel + bridgeResult.levelsByProviderModel,
                    reasoningModels =
                        (state.reasoningModels - bridgeResult.levelsByProviderModel.keys) +
                            bridgeResult.reasoningModels,
                )
            }
        }
    }

    fun acceptPrivacyPolicy() {
        viewModelScope.launch {
            settingsRepository.updatePrivacyPolicyAccepted(true)
        }
    }

    fun refreshTermuxSetup(startPiIfReady: Boolean = false) {
        viewModelScope.launch {
            val setupState = withContext(Dispatchers.IO) {
                runtime.termuxRuntime.inspectSetup()
            }
            _uiState.update { current ->
                current.copy(
                    termuxSetupState = setupState,
                    piCoreSetupState = if (setupState.isReady) {
                        current.piCoreSetupState.copy(
                            isChecking = false,
                            activity = PiCoreSetupActivity.None,
                            bytesPerSecond = 0L,
                        )
                    } else {
                        current.piCoreSetupState
                    },
                )
            }
            if (setupState.isReady) {
                val storedSettings = _uiState.value.settings
                val settings = storedSettings.copy(
                    termuxSetupCompleted = true,
                    enabledRuntimeIds = storedSettings.enabledRuntimeIds + LocalRuntimeId.Termux,
                )
                if (settings != storedSettings) settingsRepository.updateSettings(settings)
                if (startPiIfReady) {
                    refreshPiCoreSetup()
                } else {
                    viewModelScope.launch { syncPiDiscoveredSkills() }
                }
            } else {
                _uiState.update {
                    it.copy(
                        piCoreSetupState = PiCoreSetupState(
                            detail = "Initialize Termux before starting the agent runtime.",
                        )
                    )
                }
            }
        }
    }

    fun initializeTermuxRuntime(makeDefault: Boolean = true) {
        viewModelScope.launch {
            initializeTermuxRuntimeAfterReset(makeDefault)
        }
    }

    private suspend fun initializeTermuxRuntimeAfterReset(makeDefault: Boolean) {
        _uiState.update { current ->
            current.copy(
                piCoreSetupState = PiCoreSetupState(
                    isChecking = true,
                    phase = PiCoreSetupPhase.CheckingTermux,
                    output = "Starting Termux setup...\n",
                )
            )
        }
        val setupState = withContext(Dispatchers.IO) {
            runCatching {
                runtime.termuxRuntime.initializeForExplicitSetup { progress ->
                    applyPiCoreSetupUpdate(
                        PiCoreSetupUpdate(
                            phase = PiCoreSetupPhase.CheckingTermux,
                            activity = when (progress.activity) {
                                TermuxSetupActivity.Extracting -> PiCoreSetupActivity.Extracting
                                TermuxSetupActivity.Downloading -> PiCoreSetupActivity.Downloading
                                TermuxSetupActivity.Installing -> PiCoreSetupActivity.None
                                TermuxSetupActivity.None -> PiCoreSetupActivity.None
                            },
                            bytesPerSecond = progress.bytesPerSecond,
                            output = progress.output,
                        )
                    )
                }
            }.getOrElse { throwable ->
                if (throwable is CancellationException) throw throwable
                LocalRuntimeSetupState(
                    runtimeId = LocalRuntimeId.Termux,
                    issue = LocalRuntimeIssue.Failed,
                    detail = throwable.message ?: "Termux setup failed.",
                )
            }
        }
        if (setupState.isReady) {
            settingsRepository.updateSettings(
                _uiState.value.settings.withRuntimeEnabled(
                    runtimeId = LocalRuntimeId.Termux,
                    makeDefault = makeDefault,
                )
            )
        }
        _uiState.update { current -> current.copy(termuxSetupState = setupState) }
        if (setupState.isReady) {
            _uiState.update { current ->
                current.copy(
                    piCoreSetupState = current.piCoreSetupState.copy(
                        isChecking = false,
                        activity = PiCoreSetupActivity.None,
                        bytesPerSecond = 0L,
                    ),
                )
            }
            refreshPiCoreSetup()
        } else {
            _uiState.update { current ->
                current.copy(
                    piCoreSetupState = current.piCoreSetupState.copy(
                        isChecking = false,
                        phase = PiCoreSetupPhase.Failed,
                        failedAtPhase = PiCoreSetupPhase.CheckingTermux,
                        detail = setupState.detail,
                        activity = PiCoreSetupActivity.None,
                        bytesPerSecond = 0L,
                        output = appendSetupOutput(
                            current.piCoreSetupState.output,
                            "Setup failed: ${setupState.detail}\n",
                        ),
                    )
                )
            }
        }
        emitTransientMessage(UiText.Raw(setupState.detail.ifBlank { "Termux runtime status refreshed." }))
    }

    private suspend fun refreshPiCoreSetup() {
        if (_uiState.value.piCoreSetupState.isChecking) return
        _uiState.update {
            it.copy(
                piCoreSetupState = PiCoreSetupState(
                    isChecking = true,
                    phase = PiCoreSetupPhase.CheckingTermux,
                    output = it.piCoreSetupState.output.ifBlank { "Starting agent runtime setup...\n" },
                )
            )
        }
        runCatching {
            withContext(Dispatchers.IO) {
                runtime.piKernelBridge.ping(::applyPiCoreSetupUpdate)
            }
        }.fold(
            onSuccess = { payload ->
                if (payload.optBoolean("setup_required", false) && !payload.optBoolean("ok", true)) {
                    _uiState.update { current ->
                        current.copy(
                            piCoreSetupState = PiCoreSetupState(
                                phase = PiCoreSetupPhase.Failed,
                                failedAtPhase = PiCoreSetupPhase.CheckingTermux,
                                detail = payload.optString("error")
                                    .ifBlank { "The Termux environment is not installed yet." },
                                output = appendSetupOutput(
                                    current.piCoreSetupState.output,
                                    "Setup failed: ${payload.optString("error")}\n",
                                ),
                            ),
                        )
                    }
                    return@fold
                }
                _uiState.update {
                    it.copy(
                        piCoreSetupState = PiCoreSetupState(
                            isReady = true,
                            phase = PiCoreSetupPhase.Ready,
                            nodeVersion = payload.optString("node_version"),
                            bridgeVersion = payload.optString("bridge_version"),
                            output = appendSetupOutput(
                                it.piCoreSetupState.output,
                                "AI engine setup complete.\n",
                            ),
                        )
                    )
                }
                syncPiDiscoveredSkills()
                refreshBridgeThinkingCatalog()
            },
            onFailure = { throwable ->
                if (throwable is CancellationException && throwable !is TimeoutCancellationException) throw throwable
                _uiState.update { current ->
                    current.copy(
                        piCoreSetupState = PiCoreSetupState(
                            phase = PiCoreSetupPhase.Failed,
                            failedAtPhase = current.piCoreSetupState.phase,
                            detail = throwable.userFacingMessage(),
                            output = appendSetupOutput(
                                current.piCoreSetupState.output,
                                "Setup failed: ${throwable.userFacingMessage()}\n",
                            ),
                        )
                    )
                }
            },
        )
    }

    private suspend fun syncPiDiscoveredSkills() {
        runCatching {
            val response = piKernelBridge.listDiscoveredSkills()
            val skills = response.optJSONArray("skills") ?: return@runCatching
            val discovered = buildList {
                for (index in 0 until skills.length()) {
                    val item = skills.optJSONObject(index) ?: continue
                    val guestFilePath = item.optString("file_path").trim()
                    val guestBaseDir = item.optString("base_dir").trim()
                    if (guestFilePath.isBlank() || guestBaseDir.isBlank()) continue
                    val hostFile = runtime.termuxRuntime.resolveWorkspaceHostPath(guestFilePath)?.hostFile
                        ?: runtime.termuxRuntime.resolveGuestPath(guestFilePath)
                    val hostRoot = runtime.termuxRuntime.resolveWorkspaceHostPath(guestBaseDir)?.hostFile
                        ?: runtime.termuxRuntime.resolveGuestPath(guestBaseDir)
                    if (!hostFile.isFile || !hostRoot.isDirectory) continue
                    add(
                        PiDiscoveredSkillSource(
                            guestFilePath = guestFilePath,
                            guestBaseDir = guestBaseDir,
                            hostFile = hostFile,
                            hostRoot = hostRoot,
                        )
                    )
                }
            }
            skillManager.syncPiDiscoveredSkills(discovered).getOrThrow()
        }
    }

    fun resetTermuxRuntime() {
        viewModelScope.launch {
            val setupState = withContext(Dispatchers.IO) {
                runtime.termuxRuntime.reset()
            }
            val settings = _uiState.value.settings
            settingsRepository.updateSettings(
                settings.copy(
                    enabledRuntimeIds = settings.enabledRuntimeIds - LocalRuntimeId.Termux,
                    defaultRuntimeId = if (settings.defaultRuntimeId == LocalRuntimeId.Termux) {
                        (settings.enabledRuntimeIds - LocalRuntimeId.Termux).firstOrNull()
                    } else {
                        settings.defaultRuntimeId
                    },
                    termuxSetupCompleted = false,
                )
            )
            _uiState.update { current ->
                current.copy(
                    termuxSetupState = setupState,
                )
            }
        }
    }

    suspend fun createTermuxTerminalLaunchSpec(): Result<TermuxTerminalLaunchSpec> =
        withContext(Dispatchers.IO) {
            runCatching { runtime.termuxRuntime.createTerminalLaunchSpec() }
        }

    fun setDefaultRuntime(runtimeId: LocalRuntimeId) {
        viewModelScope.launch {
            val settings = _uiState.value.settings
            settingsRepository.updateSettings(
                settings.copy(
                    enabledRuntimeIds = settings.enabledRuntimeIds + runtimeId,
                    defaultRuntimeId = runtimeId,
                )
            )
        }
    }

    fun updateDraftInput(value: String) {
        if (isPostSendDraftEcho(value)) return
        _uiState.update { current ->
            current.copy(
                draftInput = value,
                showStarterPromptHint = if (
                    current.showStarterPromptHint && value != current.draftInput
                ) {
                    false
                } else {
                    current.showStarterPromptHint
                },
            )
        }
    }

    private var postSendDraftEchoGuardText: String? = null
    private var postSendDraftEchoGuardAtUptimeMillis: Long = 0L

    private val PostSendDraftEchoWindowMillis = 600L

    private fun armPostSendDraftEchoGuard(submittedText: String) {
        postSendDraftEchoGuardText = submittedText
        postSendDraftEchoGuardAtUptimeMillis = android.os.SystemClock.uptimeMillis()
    }

    private fun isPostSendDraftEcho(value: String): Boolean {
        val guardText = postSendDraftEchoGuardText ?: return false
        val sinceSend = android.os.SystemClock.uptimeMillis() - postSendDraftEchoGuardAtUptimeMillis
        if (sinceSend > PostSendDraftEchoWindowMillis) {
            postSendDraftEchoGuardText = null
            return false
        }
        return value.isNotBlank() && value == guardText
    }

    fun appendDraftSpeech(text: String) {
        if (text.isBlank()) return
        _uiState.update { current ->
            val separator = when {
                current.draftInput.isBlank() -> ""
                current.draftInput.endsWith(' ') || current.draftInput.endsWith('\n') -> ""
                else -> " "
            }
            current.copy(draftInput = current.draftInput + separator + text.trim())
        }
    }

    fun submitVoiceInput(text: String) {
        if (text.isBlank()) return
        appendDraftSpeech(text)
        sendCurrentMessage()
    }

    private suspend fun handleIncomingExternalText(incoming: ArixIncomingRequests.IncomingText) {
        ArixIncomingRequests.pendingText.value = null
        withTimeoutOrNull(5_000L) {
            _uiState.first { it.isStartupRouteResolved }
        }
        val current = _uiState.value
        if (current.currentScreen == AppScreen.Welcome) return

        val currentSession = current.sessions.firstOrNull { it.id == current.currentSessionId }
        val hasVisibleConversation = current.currentSessionId != DraftSessionId ||
            currentSession?.messages?.isNotEmpty() == true
        if (hasVisibleConversation) {
            startNewChat()
        }
        _uiState.update { state ->
            state.copy(
                currentScreen = AppScreen.Chat,
                draftInput = incoming.text,
                showStarterPromptHint = false,
            )
        }
        emitTransientMessage(UiText.Resource(R.string.share_ready_to_send))
    }

    fun completeGetStarted() {
        viewModelScope.launch {
            settingsRepository.updateOnboardingSeenVersion(CurrentOnboardingVersion)
            _uiState.update { current ->
                current.copy(
                    currentScreen = AppScreen.Chat,
                    isStartupRouteResolved = true,
                    currentSessionId = DraftSessionId,
                    draftInput = OnboardingStarterPrompt,
                    showStarterPromptHint = true,
                )
            }
            persistCurrentSessionId(DraftSessionId)
            captureAnalyticsEvent(
                event = "get_started_completed",
                properties = mapOf(
                    "skill_count" to _uiState.value.installedSkills.size,
                    "provider_count" to _uiState.value.providerConfigs.size,
                ),
            )
            if (!_uiState.value.termuxSetupState.isReady) {
                initializeTermuxRuntimeAfterReset(makeDefault = true)
            }
        }
    }

    fun skipGetStarted() {
        viewModelScope.launch {
            settingsRepository.updateOnboardingSeenVersion(CurrentOnboardingVersion)
            _uiState.update { current ->
                current.copy(
                    currentScreen = AppScreen.Chat,
                    isStartupRouteResolved = true,
                )
            }
            if (!_uiState.value.termuxSetupState.isReady) {
                initializeTermuxRuntimeAfterReset(makeDefault = true)
            }
        }
    }

    private fun applyPiCoreSetupUpdate(update: PiCoreSetupUpdate) {
        _uiState.update { current ->
            current.copy(
                piCoreSetupState = current.piCoreSetupState.copy(
                    isChecking = true,
                    phase = update.phase,
                    activity = update.activity,
                    bytesPerSecond = update.bytesPerSecond,
                    output = appendSetupOutput(current.piCoreSetupState.output, update.output),
                )
            )
        }
    }

    private fun appendSetupOutput(
        current: String,
        addition: String,
    ): String {
        if (addition.isEmpty()) return current
        val combined = current + addition
        return if (combined.length <= MaxSetupOutputChars) {
            combined
        } else {
            combined.takeLast(MaxSetupOutputChars)
        }
    }

    fun dismissStarterPromptHint() {
        _uiState.update { current -> current.copy(showStarterPromptHint = false) }
    }

    fun appendDraftAttachments(uris: List<Uri>) {
        if (uris.isEmpty()) return

        val targetSessionId = ensureDraftWorkspaceId()

        viewModelScope.launch {
            val pendingAttachments = withContext(Dispatchers.IO) {
                uris
                    .mapNotNull { uri -> buildPendingDraftAttachment(uri) }
                    .distinctBy { it.uri }
                    .toList()
            }
            if (pendingAttachments.isEmpty()) return@launch

            var attachmentsToImport = emptyList<ChatAttachment>()
            _uiState.update { current ->
                val newAttachments = pendingAttachments.filterNot { candidate ->
                    current.draftAttachments.any { existing -> existing.uri == candidate.uri }
                }
                attachmentsToImport = newAttachments
                if (newAttachments.isEmpty()) {
                    current
                } else {
                    current.copy(
                        draftAttachments = current.draftAttachments + newAttachments
                    )
                }
            }

            attachmentsToImport.forEach { attachment ->
                launch(Dispatchers.IO) {
                    importDraftAttachmentToWorkspace(
                        attachment = attachment,
                        sessionId = targetSessionId,
                    )
                }
            }
        }
    }

    fun removeDraftAttachment(attachmentId: String) {
        _uiState.update { current ->
            current.copy(
                draftAttachments = current.draftAttachments.filterNot { it.id == attachmentId }
            )
        }
    }

    fun pauseGeneration() {
        val snapshot = _uiState.value
        val sessionId = sequenceOf(
            snapshot.currentSessionId,
            snapshot.pendingResponseSessionId,
        )
            .filterNotNull()
            .firstOrNull(sessionExecutionManager::isSessionRunning)
            ?: return
        val finalizedSession = sessionExecutionManager.pauseSession(sessionId) ?: return
        val executionStates = sessionExecutionManager.executionStates.value
        _uiState.update { current -> current.withFinalizedPausedSession(finalizedSession, executionStates) }
    }

    fun openSettings() {
        _uiState.update { it.copy(currentScreen = AppScreen.Settings) }
    }

    fun openMainTab(screen: AppScreen) {
        if (screen != AppScreen.Chat &&
            screen != AppScreen.Terminal && screen != AppScreen.Browser &&
            screen != AppScreen.Files &&
            screen != AppScreen.Settings
        ) {
            return
        }
        _uiState.update { it.copy(currentScreen = screen) }
    }

    fun refreshUsageStatisticsSnapshots() {
        viewModelScope.launch {
            val snapshots = withContext(Dispatchers.IO) {
                runtime.chatRepository.getUsageStatisticsSnapshot()
            }
            _uiState.update { it.copy(usageStatisticsSnapshots = snapshots) }
        }
    }

    fun closeSettings() {
        _uiState.update {
            it.copy(currentScreen = AppScreen.Chat)
        }
    }

    fun startNewChat() {
        val snapshot = _uiState.value
        val defaultSkillIds = enabledDefaultSkillIds(snapshot)
        startNewChatNow(defaultSkillIds)
    }

    private fun startNewChatNow(
        selectedSkillIds: List<String>,
    ) {
        _uiState.update {
            val inheritedModelKey = currentConversationModelKey(it)
            val enabledSkillIds = it.installedSkills
                .filter(InstalledSkill::isEnabled)
                .map(InstalledSkill::id)
                .toSet()
            it.copy(
                currentScreen = AppScreen.Chat,
                currentSessionId = DraftSessionId,
                draftInput = "",
                draftAttachments = emptyList(),
                draftSelectedModelKey = inheritedModelKey,
                draftSelectedSkillIds = selectedSkillIds.filter(enabledSkillIds::contains),
                draftWorkspaceId = null,
                editingSessionId = null,
                editingMessageId = null,
                unviewedCompletedSessionIds = it.unviewedCompletedSessionIds - DraftSessionId,
                showStarterPromptHint = false,
            )
        }
        persistCurrentSessionId(DraftSessionId)
        captureAnalyticsEvent(event = "conversation started")
    }

    private fun initializeStartupDraftModelIfReady() {
        if (didInitializeStartupDraftModel) return
        var sessionToPersist: Pair<String, String>? = null
        _uiState.update { current ->
            val options = current.providerConfigs.availableModelOptions()
            if (
                !current.isStartupRouteResolved ||
                !didReceiveInitialChatState ||
                options.isEmpty()
            ) return@update current
            didInitializeStartupDraftModel = true
            val defaultModelKey = resolveDefaultChatModelKey(current.settings, current.providerConfigs)
            if (current.currentSessionId == DraftSessionId) {
                current.copy(draftSelectedModelKey = defaultModelKey)
            } else {
                val currentSession = current.sessions.firstOrNull { it.id == current.currentSessionId }
                if (currentSession != null && currentSession.selectedModelKey.isBlank()) {
                    sessionToPersist = current.currentSessionId to defaultModelKey
                    current.copy(
                        sessions = current.sessions.map { session ->
                            if (session.id == current.currentSessionId) {
                                session.copy(selectedModelKey = defaultModelKey)
                            } else {
                                session
                            }
                        },
                    )
                } else {
                    current
                }
            }
        }
        sessionToPersist?.let { (sessionId, defaultModelKey) ->
            persistSessionMutation(sessionId) { session ->
                if (session.selectedModelKey == defaultModelKey) null
                else session.copy(selectedModelKey = defaultModelKey)
            }
        }
    }

    private fun currentConversationModelKey(state: ArixUiState): String {
        val options = state.providerConfigs.availableModelOptions()
        val selectedKey = state.sessions
            .firstOrNull { it.id == state.currentSessionId }
            ?.selectedModelKey
            ?: state.draftSelectedModelKey
        return selectedKey.takeIf { key -> options.any { it.key == key } }
            ?: resolveDefaultChatModelKey(state.settings, state.providerConfigs)
    }

    fun selectSession(sessionId: String) {
        selectSessionJob?.cancel()
        _uiState.update { current ->
            current.copy(
                currentScreen = AppScreen.Chat,
                sessions = current.sessions.withMessagesOnlyForSession(sessionId),
                currentSessionId = sessionId,
                draftInput = "",
                draftAttachments = emptyList(),
                draftSelectedModelKey = "",
                draftSelectedSkillIds = emptyList(),
                draftWorkspaceId = null,
                editingSessionId = null,
                editingMessageId = null,
                unviewedCompletedSessionIds = current.unviewedCompletedSessionIds - sessionId,
                showStarterPromptHint = false,
            )
        }
        selectSessionJob = viewModelScope.launch {
            val loadedSession = if (sessionId == DraftSessionId) {
                null
            } else {
                runCatching {
                    withContext(Dispatchers.IO) {
                        runtime.chatRepository.getSessionWithMessages(sessionId)
                    }
                }.getOrElse { throwable ->
                    if (throwable is CancellationException) throw throwable
                    diagnosticLogger.exception(
                        category = "storage",
                        event = "session_selection_hydration_failed",
                        throwable = throwable,
                        level = "warn",
                        sessionId = sessionId,
                    )
                    null
                }
            }
            loadedSession?.let { session ->
                _uiState.update { current ->
                    if (current.currentSessionId != sessionId) {
                        current
                    } else {
                        current.copy(
                            sessions = replaceOrPrependSession(current.sessions, session)
                                .withMessagesOnlyForSession(sessionId),
                        )
                    }
                }
            }
            persistSessionSelection(sessionId, loadedSession)
        }
    }

    fun renameSession(
        sessionId: String,
        title: String,
    ) {
        val trimmedTitle = title.trim()
        if (trimmedTitle.isBlank()) return
        updateSession(sessionId) { session ->
            if (session.title == trimmedTitle && session.hasCustomTitle) {
                null
            } else {
                session.copy(
                    title = trimmedTitle.take(80),
                    hasCustomTitle = true,
                )
            }
        }
    }

    fun clearAllSessions() {
        if (_uiState.value.sessions.any { sessionExecutionManager.isSessionRunning(it.id) }) {
            emitTransientMessage(uiString(R.string.message_pause_before_deleting_session))
            return
        }

        val removedSessionIds = _uiState.value.sessions.map { it.id }
        if (removedSessionIds.isEmpty()) return

        var didUpdate = false
        _uiState.update { current ->
            if (current.sessions.isEmpty()) return@update current
            didUpdate = true
            current.copy(
                sessions = emptyList(),
                currentSessionId = DraftSessionId,
                draftInput = "",
                draftAttachments = emptyList(),
                draftWorkspaceId = null,
                editingSessionId = null,
                editingMessageId = null,
                unviewedCompletedSessionIds = emptySet(),
                showStarterPromptHint = false,
            )
        }
        if (didUpdate) {
            viewModelScope.launch {
                chatStateStore.flush()
                removedSessionIds.forEach { sessionId ->
                    val agentSession = runCatching {
                        runtime.chatRepository.getAgentSessionMetadata(sessionId)
                    }.getOrNull()
                    runCatching {
                        runtime.piKernelBridge.closeSession(
                            sessionId = sessionId,
                            sessionFile = agentSession?.jsonlPath.orEmpty(),
                            deleteFile = true,
                        )
                    }
                }
                chatStateStore.updateAndFlush(
                    writeIntent = PersistedChatWriteIntent.DeleteSession,
                ) { persisted ->
                    persisted.copy(
                        sessions = emptyList(),
                        currentSessionId = DraftSessionId,
                    )
                }
                scheduleSessionRuntimeDataCleanup(
                    sessionIds = removedSessionIds,
                    sharedWorkspaceFilePaths = emptyList(),
                    mode = _uiState.value.settings.agentWorkspaceMode,
                )
                captureAnalyticsEvent(
                    event = "conversations cleared",
                    properties = mapOf("conversation_count" to removedSessionIds.size),
                )
            }
        }
    }

    fun deleteSession(sessionId: String) {
        if (sessionExecutionManager.isSessionRunning(sessionId)) {
            emitTransientMessage(uiString(R.string.message_pause_before_deleting_session))
            return
        }

        var didUpdate = false
        _uiState.update { current ->
            val session = current.sessions.firstOrNull { it.id == sessionId } ?: return@update current
            val updatedSessions = current.sessions.filterNot { it.id == sessionId }
            if (updatedSessions.size == current.sessions.size) return@update current
            didUpdate = true
            current.copy(
                sessions = updatedSessions,
                currentSessionId = if (current.currentSessionId == sessionId) DraftSessionId else current.currentSessionId,
                draftInput = if (current.editingSessionId == sessionId) "" else current.draftInput,
                draftAttachments = if (current.editingSessionId == sessionId) emptyList() else current.draftAttachments,
                draftWorkspaceId = if (current.editingSessionId == sessionId) null else current.draftWorkspaceId,
                editingSessionId = if (current.editingSessionId == sessionId) null else current.editingSessionId,
                editingMessageId = if (current.editingSessionId == sessionId) null else current.editingMessageId,
                unviewedCompletedSessionIds = current.unviewedCompletedSessionIds - sessionId,
                showStarterPromptHint = false,
            )
        }
        if (didUpdate) {
            viewModelScope.launch {
                chatStateStore.flush()
                val sharedWorkspaceFilePaths = withContext(Dispatchers.IO) {
                    runCatching {
                        runtime.chatRepository.getUnreferencedWorkspaceFilePathsForDeletedSession(sessionId)
                    }.getOrElse { throwable ->
                        diagnosticLogger.exception(
                            category = "storage",
                            event = "unreferenced_workspace_lookup_failed",
                            throwable = throwable,
                            level = "warn",
                            sessionId = sessionId,
                            details = mapOf("lookup_scope" to "session"),
                        )
                        emptyList()
                    }
                }
                persistDeleteSession(
                    sessionId = sessionId,
                    sharedWorkspaceFilePaths = sharedWorkspaceFilePaths,
                )
                captureAnalyticsEvent(event = "conversation deleted")
            }
        }
    }

    fun exportSessionToUri(
        sessionId: String,
        destinationUri: Uri,
    ) {
        viewModelScope.launch {
            val didExport = withContext(Dispatchers.IO) {
                val session = runtime.chatRepository.getSessionWithMessages(sessionId) ?: return@withContext false
                val piSession = runCatching { piKernelBridge.exportSessionJsonl(sessionId) }.getOrNull()
                val piPath = piSession?.optString("exported_path").orEmpty()
                val piJsonl = piPath.takeIf(String::isNotBlank)
                    ?.let { path -> runCatching { java.io.File(path).readText(Charsets.UTF_8) }.getOrNull() }
                writeTextToUri(
                    uri = destinationUri,
                    text = JSONObject().apply {
                        put("schemaVersion", 1)
                        put("exportType", "session")
                        put("exportedAtMillis", System.currentTimeMillis())
                        put("session", session.copy(messages = syncActiveBranches(session.messages)).toJson())
                        put("piSession", JSONObject().apply {
                            put("sessionId", sessionId)
                            put("jsonlPath", piPath)
                            put("jsonl", piJsonl ?: "")
                        })
                    }.toString(2),
                )
            }
            emitTransientMessage(uiString(if (didExport) R.string.message_session_exported else R.string.message_session_export_failed))
        }
    }

    fun exportAllDataToUri(destinationUri: Uri) {
        val snapshot = _uiState.value
        viewModelScope.launch {
            val didExport = withContext(Dispatchers.IO) {
                val sessions = runtime.chatRepository.getSessionsWithMessages()
                writeTextToUri(
                    uri = destinationUri,
                    text = buildFullAppExportJson(snapshot, sessions).toString(2),
                )
            }
            emitTransientMessage(uiString(if (didExport) R.string.message_app_data_exported else R.string.message_app_data_export_failed))
        }
    }

    fun exportLogsToUri(destinationUri: Uri) {
        val snapshot = _uiState.value
        viewModelScope.launch {
            diagnosticLogger.event(
                category = "export",
                event = "diagnostic_export_start",
                details = mapOf(
                    "screen" to snapshot.currentScreen.name,
                    "session_count" to snapshot.sessions.size,
                ),
            )
            val didExport = withContext(Dispatchers.IO) {
                writeTextToUri(
                    uri = destinationUri,
                    text = buildDiagnosticLogText(snapshot),
                )
            }
            diagnosticLogger.event(
                category = "export",
                event = if (didExport) "diagnostic_export_end" else "diagnostic_export_failed",
                level = if (didExport) "info" else "warn",
            )
            emitTransientMessage(uiString(if (didExport) R.string.message_logs_exported else R.string.message_logs_export_failed))
        }
    }

    fun importAllDataFromUri(sourceUri: Uri) {
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val rawValue = readTextFromUri(sourceUri)
                    val json = JSONObject(rawValue)
                    val importedSkills = skillManager.importSkillBundles(json.optJSONArray("skillBundles"))
                    parseFullAppImport(json, importedSkills)
                }
            }
            result
                .onSuccess { imported ->
                    imported.piSessions.forEach { (sessionId, jsonl) ->
                        runCatching {
                            val importedPi = piKernelBridge.importSessionJsonl(sessionId, jsonl)
                            val path = importedPi.optString("session_file")
                            runtime.chatRepository.upsertAgentSessionMetadata(
                                chatSessionId = sessionId,
                                piSessionId = sessionId,
                                jsonlPath = path,
                                runtime = imported.settings.defaultRuntimeId?.storageValue.orEmpty(),
                                migrationVersion = 2,
                            )
                        }.onFailure { throwable ->
                            diagnosticLogger.exception(
                                category = "pi_bridge",
                                event = "import_session_jsonl_failed",
                                throwable = throwable,
                                level = "warn",
                                sessionId = sessionId,
                            )
                        }
                    }
                    settingsRepository.replaceImportedSettings(
                        settings = imported.settings,
                        providerConfigs = imported.providerConfigs,
                    )
                    extensionsRepository.updateInstalledSkills(imported.installedSkills)
                    chatStateStore.updateAndFlush(
                        writeIntent = PersistedChatWriteIntent.ReplaceFromImport,
                    ) {
                        it.copy(
                            sessions = imported.sessions,
                            currentSessionId = imported.currentSessionId,
                        )
                    }
                    _uiState.update { current ->
                        current.copy(
                            sessions = imported.sessions,
                            currentSessionId = imported.currentSessionId,
                            draftInput = "",
                            draftAttachments = emptyList(),
                            draftSelectedModelKey = "",
                            draftSelectedSkillIds = emptyList(),
                            draftWorkspaceId = null,
                            editingSessionId = null,
                            editingMessageId = null,
                            unviewedCompletedSessionIds = emptySet(),
                        )
                    }
                    emitTransientMessage(uiString(R.string.message_app_data_imported))
                }
                .onFailure { throwable ->
                    emitTransientMessage(uiString(R.string.message_app_data_import_failed, throwable.userFacingMessage()))
                }
        }
    }

    fun startEditingUserMessage(
        sessionId: String,
        messageId: String,
    ) {
        if (sessionExecutionManager.isSessionRunning(sessionId)) return

        val session = _uiState.value.sessions.firstOrNull { it.id == sessionId } ?: return
        val message = session.messages.firstOrNull {
            it.id == messageId && it.author == MessageAuthor.User
        } ?: return

        _uiState.update {
            it.copy(
                currentScreen = AppScreen.Chat,
                currentSessionId = sessionId,
                draftInput = stripAssistantScreenContext(message.text),
                draftAttachments = message.attachments.map(::normalizeDraftAttachmentForEditing),
                draftSelectedModelKey = if (sessionId == DraftSessionId) {
                    it.draftSelectedModelKey.ifBlank {
                        resolveDefaultChatModelKey(it.settings, it.providerConfigs)
                    }
                } else {
                    it.draftSelectedModelKey
                },
                draftWorkspaceId = sessionId,
                editingSessionId = sessionId,
                editingMessageId = messageId,
                showStarterPromptHint = false,
            )
        }
        persistCurrentSessionId(sessionId)
    }

    fun cancelMessageEdit() {
        _uiState.update {
            it.copy(
                draftInput = "",
                draftAttachments = emptyList(),
                draftSelectedModelKey = if (it.currentSessionId == DraftSessionId) {
                    it.draftSelectedModelKey.ifBlank {
                        resolveDefaultChatModelKey(it.settings, it.providerConfigs)
                    }
                } else {
                    it.draftSelectedModelKey
                },
                draftSelectedSkillIds = emptyList(),
                draftWorkspaceId = null,
                editingSessionId = null,
                editingMessageId = null,
                showStarterPromptHint = false,
            )
        }
    }

    fun deleteMessage(
        sessionId: String,
        messageId: String,
    ) {
        if (sessionExecutionManager.isSessionRunning(sessionId)) return

        var didUpdate = false
        var updatedSessionForPersistence: ChatSession? = null
        var removedSessionForPersistence = false
        var removedMessageIds = emptyList<String>()

        _uiState.update { current ->
            val sessionIndex = current.sessions.indexOfFirst { it.id == sessionId }
            if (sessionIndex < 0) return@update current

            val session = current.sessions[sessionIndex]
            val messageIndex = session.messages.indexOfFirst { it.id == messageId }
            if (messageIndex < 0) return@update current

            val trimFromIndex = session.messages.resolveConversationTrimIndex(messageIndex)
            val trimmedMessages = session.messages.take(trimFromIndex)
            val removedMessages = session.messages.drop(trimFromIndex)
            removedMessageIds = removedMessages.map { it.id }
            val updatedSessions = current.sessions.toMutableList().apply {
                removeAt(sessionIndex)
                if (trimmedMessages.isNotEmpty()) {
                    val updatedSession = session.withMessages(trimmedMessages)
                    updatedSessionForPersistence = updatedSession
                    add(sessionIndex.coerceAtMost(size), updatedSession)
                } else {
                    removedSessionForPersistence = true
                }
            }

            didUpdate = true
            current.copy(
                sessions = updatedSessions,
                currentSessionId = when {
                    trimmedMessages.isEmpty() && current.currentSessionId == sessionId -> DraftSessionId
                    else -> current.currentSessionId
                },
                draftSelectedSkillIds = if (
                    trimmedMessages.isEmpty() && current.currentSessionId == sessionId
                ) {
                    emptyList()
                } else {
                    current.draftSelectedSkillIds
                },
                draftInput = if (current.editingSessionId == sessionId) "" else current.draftInput,
                draftAttachments = if (current.editingSessionId == sessionId) {
                    emptyList()
                } else {
                    current.draftAttachments
                },
                draftWorkspaceId = if (current.editingSessionId == sessionId) null else current.draftWorkspaceId,
                editingSessionId = if (current.editingSessionId == sessionId) null else current.editingSessionId,
                editingMessageId = if (current.editingSessionId == sessionId) null else current.editingMessageId,
                pendingResponseSessionId = if (current.pendingResponseSessionId == sessionId) null else current.pendingResponseSessionId,
                pendingToolInvocations = if (current.pendingResponseSessionId == sessionId) {
                    emptyList()
                } else {
                    current.pendingToolInvocations
                },
            )
        }

        if (didUpdate) {
            viewModelScope.launch {
                chatStateStore.flush()
                val sharedWorkspaceFilePaths = withContext(Dispatchers.IO) {
                    runCatching {
                        runtime.chatRepository.getUnreferencedWorkspaceFilePathsForDeletedMessages(
                            sessionId = sessionId,
                            messageIds = removedMessageIds,
                        )
                    }.getOrElse { throwable ->
                        diagnosticLogger.exception(
                            category = "storage",
                            event = "unreferenced_workspace_lookup_failed",
                            throwable = throwable,
                            level = "warn",
                            sessionId = sessionId,
                            details = mapOf(
                                "lookup_scope" to "messages",
                                "message_count" to removedMessageIds.size,
                            ),
                        )
                        emptyList()
                    }
                }
                if (removedSessionForPersistence) {
                    persistDeleteSession(
                        sessionId = sessionId,
                        sharedWorkspaceFilePaths = sharedWorkspaceFilePaths,
                    )
                } else {
                    updatedSessionForPersistence?.let { persistSessionSnapshotAndFlush(it) }
                    if (sharedWorkspaceFilePaths.isNotEmpty()) {
                        scheduleSessionRuntimeDataCleanup(
                            sessionIds = emptyList(),
                            sharedWorkspaceFilePaths = sharedWorkspaceFilePaths,
                            mode = _uiState.value.settings.agentWorkspaceMode,
                        )
                    }
                }
            }
        }
    }

    fun redoAgentMessage(
        sessionId: String,
        messageId: String,
    ) {
        if (sessionExecutionManager.isSessionRunning(sessionId)) return

        val snapshot = _uiState.value
        var request: SessionTurnRequest? = null
        var updatedSessionForPersistence: ChatSession? = null
        var piBranchMessageId: String? = null

        _uiState.update { current ->
            val sessionIndex = current.sessions.indexOfFirst { it.id == sessionId }
            if (sessionIndex < 0) return@update current

            val session = current.sessions[sessionIndex]
            val messageIndex = session.messages.indexOfFirst {
                it.id == messageId && it.author == MessageAuthor.Agent
            }
            if (messageIndex < 0) return@update current

            val trimFromIndex = session.messages.resolveConversationTrimIndex(messageIndex)
            val trimmedMessages = session.messages.take(trimFromIndex)
            if (trimmedMessages.lastOrNull()?.author != MessageAuthor.User) {
                return@update current
            }
            piBranchMessageId = trimmedMessages.piBranchMessageIdBeforeLastUser()

            request = SessionTurnRequest(
                sessionId = sessionId,
                settings = resolveModelSettings(
                    baseSettings = snapshot.settings,
                    providerConfigs = snapshot.providerConfigs,
                    preferredModelKey = session.selectedModelKey,
                    fallbackModelKey = resolveDefaultChatModelKey(snapshot.settings, snapshot.providerConfigs),
                ),
                requestMessages = trimmedMessages,
                selectedSkillIds = session.selectedSkillIds,
                activeSkills = session.activeSkills,
                providerConfigs = snapshot.providerConfigs,
            )
            val updatedSessions = current.sessions.toMutableList().apply {
                removeAt(sessionIndex)
                val updatedSession = session.withMessages(trimmedMessages)
                updatedSessionForPersistence = updatedSession
                add(0, updatedSession)
            }

            current.copy(
                sessions = updatedSessions,
                currentSessionId = sessionId,
                currentScreen = AppScreen.Chat,
                draftInput = "",
                draftAttachments = emptyList(),
                draftWorkspaceId = null,
                editingSessionId = null,
                editingMessageId = null,
            )
        }

        val turnRequest = request ?: return
        updatedSessionForPersistence?.let { session ->
            persistSessionSnapshot(
                session = session,
                currentSessionId = sessionId,
                moveToFront = true,
            )
        }
        viewModelScope.launch {
            navigatePiBranch(sessionId, piBranchMessageId, resetWhenMissing = true)
            sessionExecutionManager.startTurn(turnRequest)
        }
    }

    fun retryUserMessage(
        sessionId: String,
        messageId: String,
    ) {
        if (sessionExecutionManager.isSessionRunning(sessionId)) return

        val snapshot = _uiState.value
        var request: SessionTurnRequest? = null
        var updatedSessionForPersistence: ChatSession? = null
        var piBranchMessageId: String? = null

        _uiState.update { current ->
            val sessionIndex = current.sessions.indexOfFirst { it.id == sessionId }
            if (sessionIndex < 0) return@update current

            val session = current.sessions[sessionIndex]
            val userMessage = session.messages.firstOrNull {
                it.id == messageId && it.author == MessageAuthor.User
            } ?: return@update current
            val userMessageIndex = session.messages.indexOfFirst { it.id == messageId }
            piBranchMessageId = session.messages.take(userMessageIndex).lastOrNull()?.id

            val retryMessage = userMessage.copy(
                id = "user-${System.currentTimeMillis()}-$messageIdCounter.incrementAndGet()",
                createdAtMillis = System.currentTimeMillis(),
                branchGroup = null,
            )
            val branchedMessages = createEditedMessageBranch(
                messages = session.messages,
                messageId = messageId,
                replacement = retryMessage,
            ) ?: return@update current
            val updatedSession = session.withMessages(branchedMessages)
            updatedSessionForPersistence = updatedSession
            val updatedSessions = current.sessions.toMutableList().apply {
                removeAt(sessionIndex)
                add(0, updatedSession)
            }

            request = SessionTurnRequest(
                sessionId = sessionId,
                settings = resolveModelSettings(
                    baseSettings = snapshot.settings,
                    providerConfigs = snapshot.providerConfigs,
                    preferredModelKey = updatedSession.selectedModelKey,
                    fallbackModelKey = resolveDefaultChatModelKey(snapshot.settings, snapshot.providerConfigs),
                ),
                requestMessages = updatedSession.messages,
                selectedSkillIds = updatedSession.selectedSkillIds,
                activeSkills = updatedSession.activeSkills,
                providerConfigs = snapshot.providerConfigs,
            )

            current.copy(
                sessions = updatedSessions,
                currentSessionId = sessionId,
                currentScreen = AppScreen.Chat,
                draftInput = "",
                draftAttachments = emptyList(),
                draftWorkspaceId = null,
                editingSessionId = null,
                editingMessageId = null,
            )
        }

        val turnRequest = request ?: return
        updatedSessionForPersistence?.let { session ->
            persistSessionSnapshot(
                session = session,
                currentSessionId = sessionId,
                moveToFront = true,
            )
        }
        viewModelScope.launch {
            navigatePiBranch(sessionId, piBranchMessageId, resetWhenMissing = true)
            sessionExecutionManager.startTurn(turnRequest)
        }
    }

    private suspend fun navigatePiBranch(
        sessionId: String,
        arixMessageId: String?,
        resetWhenMissing: Boolean = false,
    ) {
        val settings = _uiState.value.settings
        val workspaceDirectory = workspaceFileBridge.workspaceDirectory(
            sessionId = sessionId,
            mode = settings.agentWorkspaceMode,
        )
        val metadata = runtime.chatRepository.getAgentSessionMetadata(sessionId)
        val entryId = arixMessageId?.let { messageId ->
            runtime.chatRepository.getAgentMessageEntryIds(sessionId, messageId).lastOrNull()
        }
        runCatching {
            piKernelBridge.navigateSession(
                sessionId = sessionId,
                entryId = entryId.orEmpty(),
                reset = entryId == null && resetWhenMissing,
                sessionPayload = JSONObject().apply {
                    put("session_file", metadata?.jsonlPath.orEmpty())
                    put("workspace_directory", workspaceDirectory)
                    put("runtime", metadata?.runtime ?: settings.defaultRuntimeId?.storageValue.orEmpty())
                    put("platform", "android")
                    put("workspace_trusted", true)
                    val modelKey = thinkingCatalogKey(settings.piProviderId, settings.modelId)
                    val thinkingLevelMap = _uiState.value.thinkingLevelClampsByProviderModel[modelKey].orEmpty()
                    val isReasoningModel = modelKey in _uiState.value.reasoningModels
                    put("model_config", settings.toPiModelConfig(thinkingLevelMap, isReasoningModel).toJson())
                    put("system_prompt", "")
                    put("host_tools", JSONArray())
                },
            )
        }.onFailure { throwable ->
            diagnosticLogger.exception(
                category = "pi_bridge",
                event = "navigate_session_branch_failed",
                throwable = throwable,
                level = "warn",
                sessionId = sessionId,
            )
        }
    }

    fun switchUserMessageBranch(
        sessionId: String,
        messageId: String,
        delta: Int,
    ) {
        if (sessionExecutionManager.isSessionRunning(sessionId)) return
        var didUpdate = false
        var updatedSessionForPersistence: ChatSession? = null
        var newBranchLeafId: String? = null

        _uiState.update { current ->
            val sessionIndex = current.sessions.indexOfFirst { it.id == sessionId }
            if (sessionIndex < 0) return@update current
            val session = current.sessions[sessionIndex]
            val updatedMessages = switchMessageBranch(
                messages = session.messages,
                messageId = messageId,
                delta = delta,
            ) ?: return@update current
            didUpdate = true
            val updatedSession = session.withMessages(updatedMessages)
            updatedSessionForPersistence = updatedSession
            val updatedSessions = current.sessions.toMutableList().apply {
                set(sessionIndex, updatedSession)
            }
            current.copy(sessions = updatedSessions)
        }

        if (didUpdate) {
            updatedSessionForPersistence?.let(::persistSessionSnapshot)
            newBranchLeafId = updatedSessionForPersistence
                ?.messages
                ?.lastOrNull { it.author == MessageAuthor.Agent }
                ?.id
                ?: updatedSessionForPersistence?.messages?.lastOrNull()?.id
            val anchorId = newBranchLeafId
            viewModelScope.launch {
                navigatePiBranch(sessionId, anchorId, resetWhenMissing = true)
            }
        }
    }

    fun saveSettings(
        systemPrompt: String,
        tavilyApiKey: String,
        tavilyBaseUrl: String,
        webSearchEngine: String,
        saveResearchToMemory: Boolean,
        unrestrictedMode: Boolean,
        llmInactivityReconnectTimeoutSeconds: Int,
        keepTasksRunningInBackground: Boolean,
        notifyOnTaskCompletion: Boolean,
        agentWorkspaceMode: AgentWorkspaceMode,
        autoCleanOldCommandHistory: Boolean,
        oldCommandHistoryRetentionHours: Int,
        language: AppLanguage,
        themeMode: AppThemeMode,
        defaultChatModelKey: String,
        defaultTitleModelKey: String,
        defaultNamingModelKey: String,
        defaultCompactingModelKey: String,
    ) {
        viewModelScope.launch {
            val currentState = _uiState.value
            val modelOptions = currentState.providerConfigs.availableModelOptions()
            val resolvedDefaultChatModelKey = resolveStoredOrAutomaticModelKey(
                modelKey = defaultChatModelKey,
                options = modelOptions,
                purpose = AutomaticModelPurpose.Chat,
            )
            val selectedModelSettings = resolveModelSettings(
                baseSettings = currentState.settings,
                providerConfigs = currentState.providerConfigs,
                preferredModelKey = resolvedDefaultChatModelKey,
                fallbackModelKey = resolvedDefaultChatModelKey,
            )
            settingsRepository.updateSettings(
                currentState.settings.copy(
                    piProviderId = selectedModelSettings.piProviderId,
                    providerConfigId = selectedModelSettings.providerConfigId,
                    providerAuthMethod = selectedModelSettings.providerAuthMethod,
                    apiKey = selectedModelSettings.apiKey,
                    apiKeys = selectedModelSettings.apiKeys,
                    oauthCredentialJson = selectedModelSettings.oauthCredentialJson,
                    providerEnvironmentVariables =
                        selectedModelSettings.providerEnvironmentVariables,
                    baseUrl = selectedModelSettings.baseUrl,
                    modelId = selectedModelSettings.modelId,
                    userAgent = selectedModelSettings.userAgent,
                    customHeaders = selectedModelSettings.customHeaders,
                    systemPrompt = systemPrompt,
                    tavilyApiKey = tavilyApiKey.trim(),
                    tavilyBaseUrl = normalizeTavilyBaseUrl(tavilyBaseUrl),
                    webSearchEngine = normalizeWebSearchEngine(webSearchEngine),
                    saveResearchToMemory = saveResearchToMemory,
                    unrestrictedMode = unrestrictedMode,
                    llmInactivityReconnectTimeoutSeconds =
                        normalizeLlmInactivityReconnectTimeoutSeconds(
                            llmInactivityReconnectTimeoutSeconds
                    ),
                    keepTasksRunningInBackground = keepTasksRunningInBackground,
                    notifyOnTaskCompletion = notifyOnTaskCompletion,
                    agentWorkspaceMode = agentWorkspaceMode,
                    autoCleanOldCommandHistory = autoCleanOldCommandHistory,
                    oldCommandHistoryRetentionHours = normalizeOldCommandHistoryRetentionHours(
                        oldCommandHistoryRetentionHours
                    ),
                    language = language,
                    themeMode = themeMode,
                    defaultChatModelKey = normalizeSelectableModelKey(defaultChatModelKey, modelOptions),
                    defaultTitleModelKey = normalizeSelectableModelKey(defaultTitleModelKey, modelOptions),
                    defaultNamingModelKey = normalizeSelectableModelKey(defaultNamingModelKey, modelOptions),
                    defaultCompactingModelKey = normalizeSelectableModelKey(defaultCompactingModelKey, modelOptions),
                )
            )
        }
    }

    fun updateAppLanguage(language: AppLanguage) {
        viewModelScope.launch {
            settingsRepository.updateLanguage(language)
        }
    }

    fun upsertProviderConfig(config: LlmProviderConfig) {
        viewModelScope.launch {
            val normalizedConfig = normalizeProviderConfig(config)
            settingsRepository.upsertProviderConfig(normalizedConfig)
            if (
                normalizedConfig.authMethod != ProviderAuthMethod.OAuth ||
                normalizedConfig.oauthCredentialJson.isBlank()
            ) {
                runCatching { runtime.piKernelBridge.clearProviderCredential(normalizedConfig.id) }
            }
            captureAnalyticsEvent(
                event = "provider added",
                properties = mapOf(
                    "provider" to com.arix.app.data.PiProviderCatalog
                        .resolve(config.piProviderId).displayName,
                    "provider_id" to config.id,
                ),
            )
        }
    }

    fun removeProviderConfig(id: String) {
        viewModelScope.launch {
            settingsRepository.removeProviderConfig(id)
            runCatching { runtime.piKernelBridge.clearProviderCredential(id) }
            captureAnalyticsEvent(event = "provider removed")
        }
    }

    fun setProviderEnabled(
        id: String,
        enabled: Boolean,
    ) {
        viewModelScope.launch {
            settingsRepository.setProviderEnabled(id, enabled)
        }
    }

    fun setReasoningEffort(effort: String) {
        viewModelScope.launch {
            settingsRepository.updateSettings(
                _uiState.value.settings.copy(reasoningEffort = normalizeReasoningEffort(effort)),
            )
        }
    }

    fun setCurrentChatModelSelection(modelKey: String) {
        var didUpdate = false
        var sessionIdForPersistence: String? = null
        _uiState.update { current ->
            if (current.currentSessionId == DraftSessionId) {
                if (current.draftSelectedModelKey == modelKey) return@update current
                didUpdate = true
                current.copy(draftSelectedModelKey = modelKey)
            } else {
                val sessionIndex = current.sessions.indexOfFirst { it.id == current.currentSessionId }
                if (sessionIndex < 0) return@update current
                val session = current.sessions[sessionIndex]
                if (session.selectedModelKey == modelKey) return@update current
                val updatedSession = session.copy(selectedModelKey = modelKey)
                val updatedSessions = current.sessions.toMutableList().apply {
                    set(sessionIndex, updatedSession)
                }
                sessionIdForPersistence = current.currentSessionId
                didUpdate = true
                current.copy(sessions = updatedSessions)
            }
        }
        val persistedSessionId = sessionIdForPersistence
        if (didUpdate && persistedSessionId != null) {
            persistSessionMutation(persistedSessionId) { session ->
                if (session.selectedModelKey == modelKey) {
                    null
                } else {
                    session.copy(selectedModelKey = modelKey)
                }
            }
        }
    }

    fun setCurrentChatModelSelectionAndResolveThinkingLevels(
        modelKey: String,
        onResolved: (Boolean) -> Unit,
    ) {
        setCurrentChatModelSelection(modelKey)
        val current = _uiState.value
        val option = current.providerConfigs.availableModelOptions()
            .firstOrNull { it.key == modelKey }
            ?: return onResolved(false)
        val cacheKey = thinkingCatalogKey(option.piProviderId, option.modelId)
        current.thinkingLevelsByProviderModel[cacheKey]?.let { levels ->
            onResolved(levels.isNotEmpty())
            return
        }
        viewModelScope.launch {
            val catalogResult = fetchMergedThinkingCatalog(listOf(option))
            if (catalogResult.levelsByProviderModel.isNotEmpty()) {
                settingsRepository.saveThinkingCatalogCache(
                    catalogResult.levelsByProviderModel,
                    catalogResult.levelMapsByProviderModel,
                    catalogResult.reasoningModels,
                    catalogResult.limitsByProviderModel,
                )
                _uiState.update { state ->
                    state.copy(
                        thinkingLevelsByProviderModel =
                            state.thinkingLevelsByProviderModel + catalogResult.levelsByProviderModel,
                        thinkingLevelClampsByProviderModel =
                            (state.thinkingLevelClampsByProviderModel -
                                catalogResult.levelsByProviderModel.keys) +
                                catalogResult.levelMapsByProviderModel,
                        reasoningModels =
                            (state.reasoningModels - catalogResult.levelsByProviderModel.keys) +
                                catalogResult.reasoningModels,
                        modelLimitsByProviderModel =
                            (state.modelLimitsByProviderModel - catalogResult.levelsByProviderModel.keys) +
                                catalogResult.limitsByProviderModel,
                    )
                }
            }
            onResolved(catalogResult.levelsByProviderModel[cacheKey].orEmpty().isNotEmpty())
        }
    }

    fun refreshCurrentChatThinkingLevels() {
        val current = _uiState.value
        val selectedModelKey = current.sessions
            .firstOrNull { it.id == current.currentSessionId }
            ?.selectedModelKey
            ?.takeIf(String::isNotBlank)
            ?: current.draftSelectedModelKey.takeIf(String::isNotBlank)
            ?: resolveDefaultChatModelKey(current.settings, current.providerConfigs)
        val option = current.providerConfigs.availableModelOptions()
            .firstOrNull { it.key == selectedModelKey }
            ?: return
        viewModelScope.launch {
            val catalogResult = fetchMergedThinkingCatalog(listOf(option))
            if (catalogResult.levelsByProviderModel.isEmpty()) return@launch
            settingsRepository.saveThinkingCatalogCache(
                catalogResult.levelsByProviderModel,
                catalogResult.levelMapsByProviderModel,
                catalogResult.reasoningModels,
                catalogResult.limitsByProviderModel,
            )
            _uiState.update { state ->
                state.copy(
                    thinkingLevelsByProviderModel =
                        state.thinkingLevelsByProviderModel + catalogResult.levelsByProviderModel,
                    thinkingLevelClampsByProviderModel =
                        (state.thinkingLevelClampsByProviderModel -
                            catalogResult.levelsByProviderModel.keys) +
                            catalogResult.levelMapsByProviderModel,
                    reasoningModels =
                        (state.reasoningModels - catalogResult.levelsByProviderModel.keys) +
                            catalogResult.reasoningModels,
                    modelLimitsByProviderModel =
                        (state.modelLimitsByProviderModel - catalogResult.levelsByProviderModel.keys) +
                            catalogResult.limitsByProviderModel,
                )
            }
        }
    }

    fun fetchModels(
        config: LlmProviderConfig,
        onComplete: (List<String>) -> Unit,
    ) {
        _uiState.update { it.copy(isFetchingModels = true) }
        viewModelScope.launch {
            val result = ProviderModelCatalogClient.fetchModels(
                config = config,
            )
            _uiState.update { current ->
                current.copy(
                    isFetchingModels = false,
                )
            }
            onComplete(result.models)
            if (result.error != null) {
                _transientMessages.emit(
                    UiText.Resource(R.string.message_fetch_models_failed, listOf(result.error)),
                )
            }
        }
    }

    fun startProviderLogin(
        providerConfigId: String,
        providerId: String,
        authMethod: ProviderAuthMethod,
        oauthFlow: String = "",
    ) {
        val normalizedProviderId = providerId.trim()
        if (normalizedProviderId.isBlank()) return
        if (authMethod == ProviderAuthMethod.Ambient) return
        providerAuthJob?.cancel()
        _uiState.update {
            it.copy(
                providerAuthState = PiProviderAuthState(
                    providerId = normalizedProviderId,
                    authMethod = authMethod,
                    isRunning = true,
                    statusMessage = if (authMethod == ProviderAuthMethod.OAuth) {
                        "Waiting for authorization."
                    } else {
                        "Waiting for credentials."
                    },
                )
            )
        }
        providerAuthJob = viewModelScope.launch {
            runCatching {
                runtime.piKernelBridge.loginProvider(
                    providerConfigId = providerConfigId,
                    providerId = normalizedProviderId,
                    authMethod = authMethod.storageValue,
                    oauthFlow = oauthFlow,
                ) { event, payload ->
                    _uiState.update { current ->
                        if (
                            current.providerAuthState.providerId != normalizedProviderId ||
                            current.providerAuthState.authMethod != authMethod
                        ) {
                            current
                        } else {
                            val state = current.providerAuthState
                            current.copy(
                                providerAuthState = when (event) {
                                    "auth_url" -> state.copy(
                                        authorizationUrl = payload.optString("url"),
                                        statusMessage = payload.optString("instructions")
                                            .ifBlank { "Complete authorization in your browser." },
                                    )

                                    "auth_device_code" -> state.copy(
                                        deviceCode = payload.optString("user_code"),
                                        verificationUrl = payload.optString("verification_uri"),
                                        statusMessage = "Enter the device code in your browser.",
                                    )

                                    "auth_prompt" -> state.copy(
                                        prompt = payload.toPiOAuthPrompt(),
                                        statusMessage = payload.optString("message"),
                                    )

                                    "auth_progress" -> state.copy(
                                        statusMessage = payload.optString("message"),
                                    )

                                    else -> state
                                }
                            )
                        }
                    }
                }
            }.fold(
                onSuccess = { payload ->
                    _uiState.update { current ->
                        if (
                            current.providerAuthState.providerId != normalizedProviderId ||
                            current.providerAuthState.authMethod != authMethod
                        ) {
                            current
                        } else {
                            current.copy(
                                providerAuthState = current.providerAuthState.copy(
                                    isRunning = false,
                                    prompt = null,
                                    apiKey = payload.optString("api_key"),
                                    oauthCredentialJson = payload.optJSONObject("oauth_credential")
                                        ?.toString()
                                        .orEmpty(),
                                    providerEnvironmentVariables =
                                        payload.toPiProviderEnvironmentVariables(),
                                    statusMessage = if (authMethod == ProviderAuthMethod.OAuth) {
                                        "Connected with OAuth."
                                    } else {
                                        "API key configured."
                                    },
                                    errorMessage = "",
                                )
                            )
                        }
                    }
                },
                onFailure = { throwable ->
                    if (throwable is CancellationException && throwable !is TimeoutCancellationException) return@fold
                    _uiState.update { current ->
                        if (
                            current.providerAuthState.providerId != normalizedProviderId ||
                            current.providerAuthState.authMethod != authMethod
                        ) {
                            current
                        } else {
                            current.copy(
                                providerAuthState = current.providerAuthState.copy(
                                    isRunning = false,
                                    prompt = null,
                                    errorMessage = throwable.userFacingMessage(),
                                    statusMessage = "",
                                )
                            )
                        }
                    }
                },
            )
        }
    }

    fun submitProviderAuthPrompt(
        promptId: String,
        value: String,
        cancelled: Boolean = false,
    ) {
        viewModelScope.launch {
            runCatching {
                runtime.piKernelBridge.submitAuthPrompt(
                    promptId = promptId,
                    value = value,
                    cancelled = cancelled,
                )
            }.fold(
                onSuccess = {
                    _uiState.update { current ->
                        if (current.providerAuthState.prompt?.id != promptId) {
                            current
                        } else {
                            current.copy(
                                providerAuthState = current.providerAuthState.copy(prompt = null)
                            )
                        }
                    }
                },
                onFailure = { throwable ->
                    _uiState.update { current ->
                        if (current.providerAuthState.prompt?.id != promptId) {
                            current
                        } else {
                            current.copy(
                                providerAuthState = current.providerAuthState.copy(
                                    errorMessage = throwable.userFacingMessage(),
                                )
                            )
                        }
                    }
                },
            )
        }
    }

    fun clearProviderAuthState() {
        providerAuthJob?.cancel()
        providerAuthJob = null
        _uiState.update { it.copy(providerAuthState = PiProviderAuthState()) }
    }

    fun installSkillFromDirectory(treeUri: Uri) {
        performSkillInstall {
            skillManager.installSkillFromDirectory(treeUri)
        }
    }

    fun ensureBuiltInSkillsInstalled() {
        viewModelScope.launch {
            skillManager.syncBuiltInSkills()
        }
    }

    fun reinstallBuiltInSkill(builtInId: String) {
        performSkillInstall {
            skillManager.reinstallBuiltInSkill(builtInId)
        }
    }

    fun installSkillFromZip(
        zipUri: Uri,
        onComplete: (Boolean) -> Unit = {},
    ) {
        performSkillInstall(onComplete = onComplete) {
            skillManager.installSkillFromZipUri(zipUri)
        }
    }

    fun installSkillFromRemote(
        url: String,
        onComplete: (Boolean) -> Unit = {},
    ) {
        val trimmedUrl = url.trim()
        if (trimmedUrl.isBlank()) {
            onComplete(false)
            return
        }
        performSkillInstall(onComplete = onComplete) {
            skillManager.installSkillFromRemote(trimmedUrl)
        }
    }

    fun removeSkill(skillId: String) {
        viewModelScope.launch {
            skillManager.uninstallSkill(skillId)
            captureAnalyticsEvent(
                event = "skill removed",
                properties = mapOf("skill_id" to skillId),
            )
        }
    }

    fun setSkillEnabled(
        skillId: String,
        enabled: Boolean,
    ) {
        viewModelScope.launch {
            extensionsRepository.setSkillEnabled(skillId, enabled)
        }
    }

    fun setComposerSkillSelected(
        skillId: String,
        selected: Boolean,
    ) {
        setComposerSkillSelectedNow(skillId, selected)
    }

    private fun setComposerSkillSelectedNow(
        skillId: String,
        selected: Boolean,
    ) {
        var didUpdate = false
        var sessionIdForPersistence: String? = null
        _uiState.update { current ->
            if (current.currentSessionId == DraftSessionId) {
                val updatedDraftSelection = updateOrderedSelection(
                    current.draftSelectedSkillIds,
                    skillId,
                    selected,
                )
                if (updatedDraftSelection == current.draftSelectedSkillIds) {
                    current
                } else {
                    didUpdate = true
                    current.copy(draftSelectedSkillIds = updatedDraftSelection)
                }
            } else {
                val sessionIndex = current.sessions.indexOfFirst { it.id == current.currentSessionId }
                if (sessionIndex < 0) return@update current
                val updatedSessions = current.sessions.toMutableList()
                val session = updatedSessions.removeAt(sessionIndex)
                val updatedSelectedSkillIds = updateOrderedSelection(
                    session.selectedSkillIds,
                    skillId,
                    selected,
                )
                val updatedActiveSkills = session.activeSkills.filter { activeSkill ->
                    updatedSelectedSkillIds.contains(activeSkill.skillId)
                }
                if (
                    updatedSelectedSkillIds == session.selectedSkillIds &&
                    updatedActiveSkills == session.activeSkills
                ) {
                    updatedSessions.add(sessionIndex, session)
                    current
                } else {
                    didUpdate = true
                    val updatedSession = session.copy(
                        selectedSkillIds = updatedSelectedSkillIds,
                        activeSkills = updatedActiveSkills,
                    )
                    sessionIdForPersistence = current.currentSessionId
                    updatedSessions.add(
                        sessionIndex.coerceAtMost(updatedSessions.size),
                        updatedSession,
                    )
                    current.copy(sessions = updatedSessions)
                }
            }
        }
        val persistedSessionId = sessionIdForPersistence
        if (didUpdate && persistedSessionId != null) {
            persistSessionMutation(persistedSessionId) { session ->
                val selectedSkillIds = updateOrderedSelection(
                    session.selectedSkillIds,
                    skillId,
                    selected,
                )
                val activeSkills = session.activeSkills.filter { activeSkill ->
                    selectedSkillIds.contains(activeSkill.skillId)
                }
                if (
                    selectedSkillIds == session.selectedSkillIds &&
                    activeSkills == session.activeSkills
                ) {
                    null
                } else {
                    session.copy(
                        selectedSkillIds = selectedSkillIds,
                        activeSkills = activeSkills,
                    )
                }
            }
        }
    }

    fun saveScheduledTask(
        existingTaskId: String?,
        name: String,
        prompt: String,
        schedule: ScheduledTaskSchedule,
        enabled: Boolean,
    ) {
        viewModelScope.launch {
            val existing = existingTaskId
                ?.takeIf(String::isNotBlank)
                ?.let { scheduledTaskManager.findTask(it) }
            val task = (existing ?: ScheduledTask(
                name = name.trim().ifBlank { "Scheduled task" },
                prompt = prompt.trim(),
                schedule = schedule,
                createdBy = ScheduledTaskCreator.User,
            )).copy(
                name = name.trim().ifBlank { "Scheduled task" },
                prompt = prompt.trim(),
                schedule = schedule,
                isEnabled = enabled,
            )
            if (task.prompt.isBlank()) {
                emitTransientMessage(uiString(R.string.message_scheduled_task_prompt_required))
                return@launch
            }
            scheduledTaskManager.upsertTask(task)
        }
    }

    fun setScheduledTaskEnabled(
        taskId: String,
        enabled: Boolean,
    ) {
        viewModelScope.launch {
            scheduledTaskManager.setTaskEnabled(taskId, enabled)
        }
    }

    fun removeScheduledTask(taskId: String) {
        viewModelScope.launch {
            scheduledTaskManager.removeTask(taskId)
        }
    }

    private fun maybeInitializeWorkspaceMode(settings: AppSettings) {
        if (didEvaluateWorkspaceMode) return
        didEvaluateWorkspaceMode = true
        viewModelScope.launch {
            if (settingsRepository.isWorkspaceModeInitialized()) return@launch
            val mode = if (withContext(Dispatchers.IO) { workspaceFileBridge.hasLegacySessionWorkspaces() }) {
                AgentWorkspaceMode.PerSession
            } else {
                AgentWorkspaceMode.Shared
            }
            settingsRepository.updateSettings(settings.copy(agentWorkspaceMode = mode))
        }
    }

    fun sendCurrentMessage() {
        submitCurrentMessage(SessionFollowUpMode.Queue)
    }

    fun steerCurrentMessage() {
        submitCurrentMessage(SessionFollowUpMode.Steer)
    }

    override fun onCleared() {
        runCatching { webViewFetcher.destroyAll() }
        super.onCleared()
    }

    private fun enabledDefaultSkillIds(
        snapshot: ArixUiState,
    ): List<String> {
        val enabledIds = snapshot.installedSkills
            .filter(InstalledSkill::isEnabled)
            .map(InstalledSkill::id)
            .toSet()
        return snapshot.settings.defaultSelectedSkillIds.filter(enabledIds::contains)
    }

    private fun submitCurrentMessage(
        runningFollowUpMode: SessionFollowUpMode,
    ) {
        submitCurrentMessageNow(runningFollowUpMode)
    }

    private fun submitCurrentMessageNow(
        runningFollowUpMode: SessionFollowUpMode,
    ) {
        val snapshot = _uiState.value
        val content = snapshot.draftInput.trim()
        val attachments = snapshot.draftAttachments

        if (content.isEmpty() && attachments.isEmpty()) return
        if (attachments.any { it.workspaceState != AttachmentWorkspaceState.Ready }) return
        if (isCompactCommand(content)) {
            compactCurrentSession(snapshot)
            return
        }

        val targetSessionId = snapshot.editingSessionId ?: when {
            snapshot.currentSessionId != DraftSessionId -> snapshot.currentSessionId
            !snapshot.draftWorkspaceId.isNullOrBlank() -> snapshot.draftWorkspaceId.orEmpty()
            else -> "session-${System.currentTimeMillis()}-${messageIdCounter.incrementAndGet()}"
        }

        if (attachments.isEmpty() &&
            snapshot.editingSessionId == null &&
            isFarewellMessage(content)
        ) {
            runFarewellTurn(
                content = content,
                snapshot = snapshot,
                targetSessionId = targetSessionId,
            )
            return
        }

        if (attachments.isEmpty() &&
            snapshot.editingSessionId == null &&
            isContinueRequest(content)
        ) {
            val resumeSessionId = targetSessionId
            if (sessionExecutionManager.canContinueFromCheckpoint(resumeSessionId)) {
                viewModelScope.launch {
                    val resumed = sessionExecutionManager
                        .continueSessionFromCheckpoint(resumeSessionId, automatic = false)
                    if (!resumed) {
                        emitTransientMessage(UiText.Raw("Nothing to continue — the last response finished normally."))
                    }
                }
                _uiState.update { it.copy(draftInput = "", draftAttachments = emptyList()) }
                return
            }
        }

        val now = System.currentTimeMillis()
        val userMessage = ChatMessage(
            id = "user-$now-${messageIdCounter.incrementAndGet()}",
            author = MessageAuthor.User,
            text = content,
            createdAtMillis = now,
            attachments = attachments,
        )

        if (snapshot.editingSessionId != null && sessionExecutionManager.isSessionRunning(targetSessionId)) {
            emitTransientMessage(uiString(R.string.message_pause_before_editing_message))
            return
        }

        if (sessionExecutionManager.isSessionRunning(targetSessionId)) {
            if (!sessionExecutionManager.submitFollowUp(targetSessionId, userMessage, runningFollowUpMode)) {
                emitTransientMessage(uiString(R.string.message_session_no_longer_running))
                return
            }
            buildAnalyticsTurnRequest(
                snapshot = snapshot,
                sessionId = targetSessionId,
                userMessage = userMessage,
            )?.let { turnRequest ->
                captureMessageSent(
                    request = turnRequest,
                    attachments = attachments,
                    isEdit = false,
                    submissionType = runningFollowUpMode.name.lowercase(),
                )
            }
            armPostSendDraftEchoGuard(content)
            _uiState.update { current ->
                current.copy(
                    currentScreen = AppScreen.Chat,
                    draftInput = "",
                    draftAttachments = emptyList(),
                    draftWorkspaceId = null,
                    editingSessionId = null,
                    editingMessageId = null,
                    showStarterPromptHint = false,
                )
            }
            return
        }

        var request: SessionTurnRequest? = null
        var requestMessages: List<ChatMessage> = emptyList()
        var requestSelectedSkillIds: List<String> = emptyList()
        var requestActiveSkills: List<ActiveSkillContext> = emptyList()
        var requestModelKey = ""
        var shouldGenerateSessionTitle = false
        var sessionForPersistence: ChatSession? = null
        var editedMessagePredecessorId: String? = null
        var isEditingExistingMessage = false

        armPostSendDraftEchoGuard(content)
        _uiState.update { current ->
            val updatedSessions = current.sessions.toMutableList()
            if (
                current.editingSessionId != null &&
                current.editingMessageId != null
            ) {
                val editingSessionIndex = updatedSessions.indexOfFirst {
                    it.id == current.editingSessionId
                }
                if (editingSessionIndex >= 0) {
                    val editingSession = updatedSessions.removeAt(editingSessionIndex)
                    val editingMessageIndex = editingSession.messages.indexOfFirst {
                        it.id == current.editingMessageId && it.author == MessageAuthor.User
                    }
                    if (editingMessageIndex >= 0) {
                        isEditingExistingMessage = true
                        editedMessagePredecessorId = editingSession.messages
                            .take(editingMessageIndex)
                            .lastOrNull()
                            ?.id
                        val branchedMessages = createEditedMessageBranch(
                            messages = editingSession.messages,
                            messageId = current.editingMessageId,
                            replacement = userMessage,
                        ) ?: (editingSession.messages.take(editingMessageIndex) + userMessage)
                        val updated = editingSession.withMessages(branchedMessages)
                        sessionForPersistence = updated
                        updatedSessions.add(0, updated)
                        requestMessages = updated.messages
                        requestSelectedSkillIds = updated.selectedSkillIds
                        requestActiveSkills = updated.activeSkills
                        requestModelKey = updated.selectedModelKey
                    } else {
                        updatedSessions.add(editingSessionIndex, editingSession)
                    }
                }
            }

            if (requestMessages.isEmpty()) {
                val existingIndex = updatedSessions.indexOfFirst { it.id == targetSessionId }
                if (existingIndex >= 0) {
                    val existing = updatedSessions.removeAt(existingIndex)
                    val updated = existing.withMessages(existing.messages + userMessage)
                    sessionForPersistence = updated
                    updatedSessions.add(0, updated)
                    requestMessages = updated.messages
                    requestSelectedSkillIds = updated.selectedSkillIds
                    requestActiveSkills = updated.activeSkills
                    requestModelKey = updated.selectedModelKey
                } else {
                    val derivedTitle = userMessage.summaryText()
                        .replace('\n', ' ')
                        .trim()
                        .take(36)
                        .ifBlank { "New chat" }
                    val newSession = createSession(
                        id = targetSessionId,
                        messages = listOf(userMessage),
                        title = derivedTitle,
                        hasCustomTitle = false,
                        selectedModelKey = current.draftSelectedModelKey.ifBlank {
                            resolveDefaultChatModelKey(current.settings, current.providerConfigs)
                        },
                        selectedSkillIds = current.draftSelectedSkillIds,
                    )
                    shouldGenerateSessionTitle = true
                    sessionForPersistence = newSession
                    updatedSessions.add(0, newSession)
                    requestMessages = newSession.messages
                    requestSelectedSkillIds = newSession.selectedSkillIds
                    requestActiveSkills = newSession.activeSkills
                    requestModelKey = newSession.selectedModelKey
                }
            }

            request = SessionTurnRequest(
                sessionId = targetSessionId,
                settings = resolveModelSettings(
                    baseSettings = current.settings,
                    providerConfigs = current.providerConfigs,
                    preferredModelKey = requestModelKey,
                    fallbackModelKey = resolveDefaultChatModelKey(current.settings, current.providerConfigs),
                ),
                requestMessages = requestMessages,
                selectedSkillIds = requestSelectedSkillIds,
                activeSkills = requestActiveSkills,
                providerConfigs = current.providerConfigs,
            )

            current.copy(
                sessions = updatedSessions,
                currentSessionId = targetSessionId,
                draftInput = "",
                draftAttachments = emptyList(),
                draftSelectedModelKey = "",
                draftSelectedSkillIds = emptyList(),
                draftWorkspaceId = null,
                editingSessionId = null,
                editingMessageId = null,
                currentScreen = AppScreen.Chat,
                showStarterPromptHint = false,
            )
        }

        val turnRequest = request ?: return
        viewModelScope.launch(Dispatchers.Default) {
            sessionForPersistence?.let { session ->
                persistSessionSnapshot(
                    session = session,
                    currentSessionId = targetSessionId,
                    moveToFront = true,
                )
            }
            captureMessageSent(
                request = turnRequest,
                attachments = attachments,
                isEdit = snapshot.editingSessionId != null,
                submissionType = "new_turn",
            )
        }
        if (shouldGenerateSessionTitle) {
            generateSessionTitle(
                sessionId = targetSessionId,
                seedMessage = userMessage,
                settings = turnRequest.settings,
            )
        }
        if (isEditingExistingMessage) {
            viewModelScope.launch {
                navigatePiBranch(
                    sessionId = targetSessionId,
                    arixMessageId = editedMessagePredecessorId,
                    resetWhenMissing = true,
                )
                sessionExecutionManager.startTurn(turnRequest)
            }
        } else {
            sessionExecutionManager.startTurn(turnRequest)
        }
    }

    private fun handleTurnEvent(
        event: SessionTurnEvent,
    ) {
        captureTurnCompleted(event)
        _uiState.update { current ->
            val unviewedCompletedSessionIds = when {
                event.sessionId == current.currentSessionId -> current.unviewedCompletedSessionIds - event.sessionId
                event.outcome != SessionTurnOutcome.Neutral -> current.unviewedCompletedSessionIds + event.sessionId
                else -> current.unviewedCompletedSessionIds
            }
            current.copy(unviewedCompletedSessionIds = unviewedCompletedSessionIds)
        }
    }

    private suspend fun buildPendingDraftAttachment(
        uri: Uri,
    ): ChatAttachment? {
        val metadata = readAttachmentMetadata(uri) ?: return null
        return ChatAttachment(
            id = "attachment-${System.currentTimeMillis()}-${uri.hashCode()}",
            uri = uri.toString(),
            name = metadata.displayName,
            mimeType = metadata.mimeType,
            sizeBytes = metadata.sizeBytes,
            kind = metadata.kind,
            workspaceState = AttachmentWorkspaceState.Pending,
        )
    }

    private suspend fun importDraftAttachmentToWorkspace(
        attachment: ChatAttachment,
        sessionId: String,
    ) {
        val importResult = runtimeWorkspaceFileBridge.importAttachmentToWorkspace(
            sourceUri = Uri.parse(attachment.uri),
            attachmentId = attachment.id,
            displayName = attachment.name,
            onProgress = { progress ->
                _uiState.update { current ->
                    val attachmentIndex = current.draftAttachments.indexOfFirst { it.id == attachment.id }
                    if (attachmentIndex < 0) return@update current
                    val existingAttachment = current.draftAttachments[attachmentIndex]
                    current.copy(
                        draftAttachments = current.draftAttachments.toMutableList().apply {
                            set(
                                attachmentIndex,
                                existingAttachment.copy(
                                    workspaceBytesCopied = progress.bytesCopied,
                                    workspaceBytesPerSecond = progress.bytesPerSecond,
                                )
                            )
                        }
                    )
                }
            },
        )

        _uiState.update { current ->
            val attachmentIndex = current.draftAttachments.indexOfFirst { it.id == attachment.id }
            if (attachmentIndex < 0) return@update current

            val existingAttachment = current.draftAttachments[attachmentIndex]
            val updatedAttachment = importResult.fold(
                onSuccess = { importedFile ->
                    val resolvedMimeType = existingAttachment.mimeType.ifBlank {
                        workspaceFileBridge.guessMimeType(importedFile.absolutePath)
                    }
                    existingAttachment.copy(
                        mimeType = resolvedMimeType,
                        sizeBytes = existingAttachment.sizeBytes ?: importedFile.bytesCopied,
                        kind = if (resolvedMimeType.startsWith("image/")) {
                            AttachmentKind.Image
                        } else {
                            AttachmentKind.File
                        },
                        workspacePath = importedFile.absolutePath,
                        workspaceState = AttachmentWorkspaceState.Ready,
                        workspaceError = "",
                        workspaceBytesCopied = importedFile.bytesCopied,
                        workspaceBytesPerSecond = 0L,
                        inlineBase64 = if (
                            resolvedMimeType.startsWith("image/") &&
                            importedFile.inlineBytes.isNotEmpty() &&
                            importedFile.inlineBytes.size <= MaxInlineImageAttachmentBytes
                        ) {
                            Base64.getEncoder().encodeToString(importedFile.inlineBytes)
                        } else {
                            existingAttachment.inlineBase64
                        },
                    )
                },
                onFailure = { throwable ->
                    val inlineImageBase64 = readInlineImageAttachment(existingAttachment)
                    if (inlineImageBase64.isNotBlank()) {
                        existingAttachment.copy(
                            workspacePath = "",
                            workspaceState = AttachmentWorkspaceState.Ready,
                            workspaceError = "",
                            workspaceBytesPerSecond = 0L,
                            inlineBase64 = inlineImageBase64,
                        )
                    } else {
                        existingAttachment.copy(
                            workspaceState = AttachmentWorkspaceState.Failed,
                            workspaceError = throwable.message
                                .orEmpty()
                                .ifBlank { "Couldn't copy this attachment into the workspace." },
                            workspaceBytesPerSecond = 0L,
                        )
                    }
                },
            )

            current.copy(
                draftAttachments = current.draftAttachments.toMutableList().apply {
                    set(attachmentIndex, updatedAttachment)
                }
            )
        }
    }

    private fun readInlineImageAttachment(attachment: ChatAttachment): String {
        if (attachment.kind != AttachmentKind.Image || !attachment.mimeType.startsWith("image/")) return ""
        if (attachment.sizeBytes?.let { it > MaxInlineImageAttachmentBytes } == true) return ""
        return runCatching {
            val resolver = getApplication<Application>().contentResolver
            val bytes = resolver.openInputStream(Uri.parse(attachment.uri))?.use { input ->
                val buffer = ByteArray(MaxInlineImageAttachmentBytes + 1)
                var total = 0
                while (total < buffer.size) {
                    val read = input.read(buffer, total, buffer.size - total)
                    if (read <= 0) break
                    total += read
                }
                require(total <= MaxInlineImageAttachmentBytes) { "Image is too large to inline." }
                buffer.copyOf(total)
            } ?: return ""
            Base64.getEncoder().encodeToString(bytes)
        }.getOrDefault("")
    }

    private fun normalizeDraftAttachmentForEditing(
        attachment: ChatAttachment,
    ): ChatAttachment = if (
        attachment.workspacePath.isNotBlank() ||
        (attachment.kind == AttachmentKind.Image && attachment.inlineBase64.isNotBlank())
    ) {
        attachment.copy(
            workspaceState = AttachmentWorkspaceState.Ready,
            workspaceError = "",
            workspaceBytesPerSecond = 0L,
        )
    } else {
        attachment.copy(
            workspaceState = AttachmentWorkspaceState.Failed,
            workspaceError = "This attachment is missing its workspace copy. Re-upload it before sending.",
        )
    }

    private fun readAttachmentMetadata(
        uri: Uri,
    ): AttachmentMetadata? {
        val resolver = getApplication<Application>().contentResolver
        var mimeType = resolver.getType(uri).orEmpty()
        var displayName = uri.lastPathSegment ?: "Attachment"
        var sizeBytes: Long? = null

        resolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
            null,
            null,
            null,
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (nameIndex >= 0) {
                    displayName = cursor.getString(nameIndex) ?: displayName
                }

                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) {
                    sizeBytes = cursor.getLong(sizeIndex)
                }
            }
        }

        if (mimeType.isBlank()) {
            mimeType = workspaceFileBridge.guessMimeType(displayName)
        }

        return AttachmentMetadata(
            displayName = displayName,
            mimeType = mimeType,
            sizeBytes = sizeBytes,
            kind = if (mimeType.startsWith("image/")) AttachmentKind.Image else AttachmentKind.File,
        )
    }

    private fun persistCurrentSessionId(sessionId: String) {
        chatStateStore.update { persisted ->
            persisted.copy(
                sessions = persisted.sessions.withMessagesOnlyForSession(sessionId),
                currentSessionId = sessionId,
            )
        }
    }

    private suspend fun hydrateCurrentSessionMessages(persisted: PersistedChatState): PersistedChatState {
        val currentSessionId = persisted.currentSessionId.ifBlank { DraftSessionId }
        if (currentSessionId == DraftSessionId) return persisted
        val currentSession = persisted.sessions.firstOrNull { it.id == currentSessionId } ?: return persisted
        if (currentSession.messages.isNotEmpty() || currentSession.messageCount <= 0) return persisted
        val loadedSession = runCatching {
            withContext(Dispatchers.IO) {
                runtime.chatRepository.getSessionWithMessages(currentSessionId)
            }
        }.getOrElse { throwable ->
            if (throwable is CancellationException) throw throwable
            diagnosticLogger.exception(
                category = "storage",
                event = "session_hydration_failed",
                throwable = throwable,
                level = "warn",
                sessionId = currentSessionId,
            )
            null
        } ?: return persisted
        return persisted.copy(
            sessions = replaceOrPrependSession(persisted.sessions, loadedSession),
        )
    }

    private fun persistSessionSelection(
        sessionId: String,
        loadedSession: ChatSession?,
    ) {
        if (loadedSession == null) {
            persistCurrentSessionId(sessionId)
            return
        }
        chatStateStore.update { persisted ->
            persisted.copy(
                sessions = replaceOrPrependSession(persisted.sessions, loadedSession)
                    .withMessagesOnlyForSession(sessionId),
                currentSessionId = sessionId,
            )
        }
    }

    private fun replaceOrPrependSession(
        sessions: List<ChatSession>,
        session: ChatSession,
    ): List<ChatSession> = if (sessions.any { it.id == session.id }) {
        sessions.map { existing ->
            if (existing.id == session.id) session else existing
        }
    } else {
        listOf(session) + sessions
    }

    private fun List<ChatSession>.withMessagesOnlyForSession(sessionId: String): List<ChatSession> =
        map { session ->
            if (session.id == sessionId) {
                session
            } else {
                session.copy(messages = emptyList())
            }
        }

    private fun persistSessionSnapshot(
        session: ChatSession,
        currentSessionId: String? = null,
        moveToFront: Boolean = false,
    ) {
        chatStateStore.update { persisted ->
            val currentIndex = persisted.sessions.indexOfFirst { it.id == session.id }
            val updatedSessions = persisted.sessions.toMutableList().apply {
                if (currentIndex >= 0) {
                    removeAt(currentIndex)
                }
                val insertIndex = when {
                    moveToFront -> 0
                    currentIndex >= 0 -> currentIndex.coerceAtMost(size)
                    else -> 0
                }
                add(insertIndex, session)
            }
            persisted.copy(
                sessions = updatedSessions,
                currentSessionId = currentSessionId ?: persisted.currentSessionId,
            )
        }
    }

    private suspend fun persistSessionSnapshotAndFlush(
        session: ChatSession,
        moveToFront: Boolean = false,
        currentSessionId: String? = null,
    ) {
        chatStateStore.updateAndFlush { persisted ->
            val currentIndex = persisted.sessions.indexOfFirst { it.id == session.id }
            val updatedSessions = persisted.sessions.toMutableList().apply {
                if (currentIndex >= 0) {
                    removeAt(currentIndex)
                }
                val insertIndex = when {
                    moveToFront -> 0
                    currentIndex >= 0 -> currentIndex.coerceAtMost(size)
                    else -> 0
                }
                add(insertIndex, session)
            }
            persisted.copy(
                sessions = updatedSessions,
                currentSessionId = currentSessionId ?: persisted.currentSessionId,
            )
        }
    }

    private fun persistSessionMutation(
        sessionId: String,
        transform: (ChatSession) -> ChatSession?,
    ) {
        chatStateStore.update { persisted ->
            val sessionIndex = persisted.sessions.indexOfFirst { it.id == sessionId }
            if (sessionIndex < 0) return@update persisted
            val updatedSession = transform(persisted.sessions[sessionIndex]) ?: return@update persisted
            val updatedSessions = persisted.sessions.toMutableList().apply {
                set(sessionIndex, updatedSession)
            }
            persisted.copy(sessions = updatedSessions)
        }
    }

    private suspend fun persistDeleteSession(
        sessionId: String,
        sharedWorkspaceFilePaths: Collection<String> = emptyList(),
    ) {
        val agentSession = runCatching {
            runtime.chatRepository.getAgentSessionMetadata(sessionId)
        }.getOrNull()
        runCatching {
            runtime.piKernelBridge.closeSession(
                sessionId = sessionId,
                sessionFile = agentSession?.jsonlPath.orEmpty(),
                deleteFile = true,
            )
        }.onFailure { throwable ->
            diagnosticLogger.exception(
                category = "pi_bridge",
                event = "close_deleted_session_failed",
                throwable = throwable,
                level = "warn",
                sessionId = sessionId,
            )
        }
        val unreferencedSharedWorkspaceFilePaths = sharedWorkspaceFilePaths
            .map(String::trim)
            .filter(String::isNotEmpty)
            .distinct()
        chatStateStore.updateAndFlush(
            writeIntent = PersistedChatWriteIntent.DeleteSession,
        ) { persisted ->
            val updatedSessions = persisted.sessions.filterNot { it.id == sessionId }
            persisted.copy(
                sessions = updatedSessions,
                currentSessionId = if (persisted.currentSessionId == sessionId) {
                    DraftSessionId
                } else {
                    persisted.currentSessionId
                },
            )
        }
        scheduleSessionRuntimeDataCleanup(
            sessionIds = listOf(sessionId),
            sharedWorkspaceFilePaths = unreferencedSharedWorkspaceFilePaths,
            mode = _uiState.value.settings.agentWorkspaceMode,
        )
    }

    private fun scheduleSessionRuntimeDataCleanup(
        sessionIds: Collection<String>,
        sharedWorkspaceFilePaths: Collection<String>,
        mode: AgentWorkspaceMode,
    ) {
        val cleanupSessionIds = sessionIds
            .filter { it.isNotBlank() && it != DraftSessionId }
            .distinct()
        val sharedWorkspaceFileCount = sharedWorkspaceFilePaths.distinct().size
        if (cleanupSessionIds.isEmpty() && sharedWorkspaceFileCount == 0) return

        viewModelScope.launch {
            workspaceFileBridge.deleteSessionsRuntimeData(
                sessionIds = cleanupSessionIds,
                sharedWorkspaceFilePaths = sharedWorkspaceFilePaths,
            )
                .onSuccess {
                    diagnosticLogger.event(
                        category = "storage",
                        event = "deleted_session_runtime_cleanup_completed",
                        sessionId = cleanupSessionIds.singleOrNull(),
                        details = mapOf(
                            "session_count" to cleanupSessionIds.size,
                            "shared_workspace_file_count" to sharedWorkspaceFileCount,
                            "settings_workspace_mode" to mode.storageValue,
                        ),
                    )
                }
                .onFailure { throwable ->
                    diagnosticLogger.exception(
                        category = "storage",
                        event = "deleted_session_runtime_cleanup_failed",
                        throwable = throwable,
                        level = "warn",
                        sessionId = cleanupSessionIds.singleOrNull(),
                        details = mapOf(
                            "session_count" to cleanupSessionIds.size,
                            "shared_workspace_file_count" to sharedWorkspaceFileCount,
                            "settings_workspace_mode" to mode.storageValue,
                        ),
                    )
                }
        }
    }

    private fun persistPrunedSessionSelections(
        enabledSkillIds: Set<String>,
    ) {
        chatStateStore.update { persisted ->
            persisted.copy(
                sessions = persisted.sessions.map { session ->
                    val selectedSkillIds = session.selectedSkillIds.filter(enabledSkillIds::contains)
                    val activeSkills = session.activeSkills.filter { activeSkill ->
                        selectedSkillIds.contains(activeSkill.skillId)
                    }
                    if (
                        selectedSkillIds == session.selectedSkillIds &&
                        activeSkills == session.activeSkills
                    ) {
                        session
                    } else {
                        session.copy(
                            selectedSkillIds = selectedSkillIds,
                            activeSkills = activeSkills,
                        )
                    }
                }
            )
        }
    }

    private fun buildAnalyticsTurnRequest(
        snapshot: ArixUiState,
        sessionId: String,
        userMessage: ChatMessage,
    ): SessionTurnRequest? {
        val session = snapshot.sessions.firstOrNull { it.id == sessionId } ?: return null
        return SessionTurnRequest(
            sessionId = sessionId,
            settings = resolveModelSettings(
                baseSettings = snapshot.settings,
                providerConfigs = snapshot.providerConfigs,
                preferredModelKey = session.selectedModelKey,
                fallbackModelKey = resolveDefaultChatModelKey(snapshot.settings, snapshot.providerConfigs),
            ),
            requestMessages = session.messages + userMessage,
            selectedSkillIds = session.selectedSkillIds,
            activeSkills = session.activeSkills,
            providerConfigs = snapshot.providerConfigs,
        )
    }

    private fun captureMessageSent(
        request: SessionTurnRequest,
        attachments: List<ChatAttachment>,
        isEdit: Boolean,
        submissionType: String,
    ) {
        val modelProperties = modelUsageProperties(request, source = "message")
        captureAnalyticsEvent(
            event = "message sent",
            properties = mapOf(
                "has_attachments" to attachments.isNotEmpty(),
                "attachment_count" to attachments.size,
                "skill_count" to request.selectedSkillIds.size,
                "is_edit" to isEdit,
                "submission_type" to submissionType,
            ) + modelProperties,
        )
        captureAnalyticsEvent(
            event = "model used",
            properties = modelProperties + mapOf(
                "has_attachments" to attachments.isNotEmpty(),
                "attachment_count" to attachments.size,
                "is_edit" to isEdit,
                "submission_type" to submissionType,
            ),
        )
    }

    private fun captureTurnCompleted(event: SessionTurnEvent) {
        val tokenProperties = tokenUsageAnalyticsProperties(event)
        captureAnalyticsEvent(
            event = "conversation turn completed",
            properties = mapOf(
                "outcome" to event.outcome.name.lowercase(),
                "tool_call_count" to event.toolCallCount,
                "distinct_tool_count" to event.distinctToolCount,
                "tool_names" to event.toolNames,
                "has_tool_calls" to (event.toolCallCount > 0),
                "duration_millis" to (event.durationMillis ?: 0L),
            ) + tokenProperties,
        )
        if (event.tokenUsage != null) {
            captureAnalyticsEvent(
                event = "tokens used",
                properties = tokenProperties + mapOf(
                    "outcome" to event.outcome.name.lowercase(),
                    "tool_call_count" to event.toolCallCount,
                    "has_tool_calls" to (event.toolCallCount > 0),
                    "duration_millis" to (event.durationMillis ?: 0L),
                ),
            )
        }
    }

    private fun modelUsageProperties(
        request: SessionTurnRequest,
        source: String,
    ): Map<String, Any> = mapOf(
        "model" to request.settings.modelId.trim(),
        "provider" to com.arix.app.data.PiProviderCatalog
            .resolve(request.settings.piProviderId).displayName,
        "provider_type" to request.settings.piProviderId,
        "source" to source,
        "skill_count" to request.selectedSkillIds.size,
    )

    private fun tokenUsageAnalyticsProperties(event: SessionTurnEvent): Map<String, Any> {
        val usage = event.tokenUsage
        val totalTokens = usage?.totalTokens ?: 0L
        val inputTokens = usage?.inputTokens ?: 0L
        val outputTokens = usage?.outputTokens ?: 0L
        val inputMessageCount = event.inputMessageCount.coerceAtLeast(0)
        val userMessageCount = event.userMessageCount.coerceAtLeast(0)
        return buildMap {
            put("token_usage_source", event.tokenUsageSource)
            put("has_token_usage", usage != null)
            put("input_message_count", inputMessageCount)
            put("user_message_count", userMessageCount)
            put("llm_request_count", usage?.requestCount ?: 0)
            put("input_tokens", inputTokens)
            put("output_tokens", outputTokens)
            put("total_tokens", totalTokens)
            usage?.reasoningTokens?.let { put("reasoning_tokens", it) }
            usage?.cachedInputTokens?.let { put("cached_input_tokens", it) }
            put(
                "average_tokens_per_input_message",
                if (inputMessageCount > 0) totalTokens.toDouble() / inputMessageCount else 0.0,
            )
            put(
                "average_input_tokens_per_input_message",
                if (inputMessageCount > 0) inputTokens.toDouble() / inputMessageCount else 0.0,
            )
            put(
                "average_tokens_per_user_message",
                if (userMessageCount > 0) totalTokens.toDouble() / userMessageCount else 0.0,
            )
        }
    }

    private fun captureAnalyticsEvent(
        event: String,
        properties: Map<String, Any> = emptyMap(),
    ) {
    }

    private fun normalizeProviderConfig(
        config: LlmProviderConfig,
    ): LlmProviderConfig {
        val definition = com.arix.app.data.PiProviderCatalog.resolve(
            config.piProviderId,
        )
        val manualModels = (config.manualModelIds.ifEmpty { listOf(config.modelId) })
            .map(String::trim)
            .filter(String::isNotEmpty)
            .distinct()
        val cachedModels = config.cachedModels
            .map(String::trim)
            .filter(String::isNotEmpty)
            .distinct()
        val availableModels = (cachedModels + manualModels)
            .map(String::trim)
            .filter(String::isNotEmpty)
            .distinct()
        val normalizedModelId = config.modelId.trim()
            .takeIf { it.isNotBlank() && availableModels.contains(it) }
            ?: manualModels.firstOrNull()
            ?: cachedModels.firstOrNull()
            ?: definition.defaultModelId
        val normalizedEnabledModels = config.enabledModelIds
            .map(String::trim)
            .filter { it.isNotEmpty() && availableModels.contains(it) }
            .distinct()
        return config.copy(
            providerId = config.providerId.trim(),
            name = config.name.trim().ifBlank { definition.displayName },
            piProviderId = definition.id,
            baseUrl = config.baseUrl.trim(),
            modelId = normalizedModelId,
            manualModelIds = manualModels,
            userAgent = normalizeLlmUserAgent(config.userAgent),
            customHeaders = config.customHeaders
                .map { header -> header.copy(name = header.name.trim()) }
                .filter { header ->
                    header.name.isNotBlank() &&
                        !header.name.equals("User-Agent", ignoreCase = true)
                }
                .distinctBy { header -> header.name.lowercase() },
            providerEnvironmentVariables = config.providerEnvironmentVariables
                .map { variable -> variable.copy(name = variable.name.trim()) }
                .filter { variable -> variable.name.isNotBlank() }
                .distinctBy { variable -> variable.name.uppercase() },
            cachedModels = cachedModels,
            enabledModelIds = normalizedEnabledModels,
        )
    }

    private fun createSession(
        id: String,
        messages: List<ChatMessage>,
        title: String? = null,
        hasCustomTitle: Boolean = false,
        selectedModelKey: String = "",
        selectedSkillIds: List<String> = emptyList(),
        activeSkills: List<ActiveSkillContext> = emptyList(),
    ): ChatSession {
        val metadata = deriveSessionMetadata(messages)
        return ChatSession(
            id = id,
            title = title ?: metadata.title,
            preview = metadata.preview,
            hasCustomTitle = hasCustomTitle,
            messages = messages,
            selectedModelKey = selectedModelKey,
            selectedSkillIds = selectedSkillIds,
            activeSkills = activeSkills,
        )
    }

    private fun ChatSession.withMessages(messages: List<ChatMessage>): ChatSession {
        val syncedMessages = syncActiveBranches(messages)
        val metadata = deriveSessionMetadata(syncedMessages)
        return copy(
            title = if (hasCustomTitle) title else metadata.title,
            preview = metadata.preview,
            messages = syncedMessages,
            messageCount = syncedMessages.size,
            lastMessageAtMillis = syncedMessages.maxOfOrNull { it.createdAtMillis },
        )
    }

    private fun setSessionSelectedSkillIds(
        sessionId: String,
        selectedSkillIds: List<String>,
    ) {
        updateSession(sessionId) { session ->
            val activeSkills = session.activeSkills.filter { activeSkill ->
                selectedSkillIds.contains(activeSkill.skillId)
            }
            if (
                session.selectedSkillIds == selectedSkillIds &&
                session.activeSkills == activeSkills
            ) {
                null
            } else {
                session.copy(
                    selectedSkillIds = selectedSkillIds,
                    activeSkills = activeSkills,
                )
            }
        }
    }

    private fun updateSession(
        sessionId: String,
        transform: (ChatSession) -> ChatSession?,
    ) {
        var didUpdate = false
        _uiState.update { current ->
            val sessionIndex = current.sessions.indexOfFirst { it.id == sessionId }
            if (sessionIndex < 0) return@update current
            val updatedSessions = current.sessions.toMutableList()
            val session = updatedSessions.removeAt(sessionIndex)
            val updatedSession = transform(session)
            if (updatedSession == null) {
                updatedSessions.add(sessionIndex, session)
                current
            } else {
                didUpdate = true
                updatedSessions.add(
                    sessionIndex.coerceAtMost(updatedSessions.size),
                    updatedSession,
                )
                current.copy(sessions = updatedSessions)
            }
        }
        if (didUpdate) {
            persistSessionMutation(sessionId, transform)
        }
    }

    private fun updateOrderedSelection(
        currentSelection: List<String>,
        id: String,
        selected: Boolean,
    ): List<String> = when {
        selected && currentSelection.contains(id) -> currentSelection
        selected -> currentSelection + id
        else -> currentSelection.filterNot { it == id }
    }

    private fun deriveSessionMetadata(messages: List<ChatMessage>): SessionMetadata {
        val visibleMessages = messages.filter { it.displayKind != MessageDisplayKind.HiddenContext }
        val title = messages
            .firstOrNull { it.author == MessageAuthor.User && it.displayKind == MessageDisplayKind.Standard }
            ?.summaryText()
            .orEmpty()
            .ifBlank { "New chat" }
            .take(36)

        val preview = visibleMessages
            .lastOrNull()
            ?.summaryText()
            .orEmpty()
            .ifBlank { "No messages yet." }
            .take(96)

        return SessionMetadata(title = title, preview = preview)
    }

    private val sessionTitleController by lazy {
        ArixSessionTitleController(
            scope = viewModelScope,
            completionClient = piCompletionClient,
            chatRepository = { runtime.chatRepository },
            providerConfigs = { _uiState.value.providerConfigs },
            thinkingLevelClamps = { _uiState.value.thinkingLevelClampsByProviderModel },
            reasoningModels = { _uiState.value.reasoningModels },
            updateSession = { sessionId, transform ->
                updateSession(sessionId) { session -> transform(session) }
            },
        )
    }

    private fun generateSessionTitle(
        sessionId: String,
        seedMessage: ChatMessage,
        settings: AppSettings,
    ) {
        sessionTitleController.generateSessionTitle(sessionId, seedMessage, settings)
    }

    private fun isCompactCommand(content: String): Boolean =
        content.trim().equals(CompactCommand, ignoreCase = true)

    private fun isContinueRequest(content: String): Boolean =
        ContinueRequestPattern.matches(content.trim())

    fun continueFromCheckpoint() {
        val sessionId = _uiState.value.currentSessionId
        if (sessionId == DraftSessionId) return
        if (!sessionExecutionManager.canContinueFromCheckpoint(sessionId)) return
        viewModelScope.launch {
            sessionExecutionManager.continueSessionFromCheckpoint(sessionId, automatic = false)
        }
    }

    fun canContinueCurrentSession(): Boolean {
        val sessionId = _uiState.value.currentSessionId
        if (sessionId == DraftSessionId) return false
        return sessionExecutionManager.canContinueFromCheckpoint(sessionId)
    }

    private fun isFarewellMessage(content: String): Boolean =
        FarewellMessagePattern.matches(content.trim())

    private fun runFarewellTurn(
        content: String,
        snapshot: ArixUiState,
        targetSessionId: String,
    ) {
        if (sessionExecutionManager.isSessionRunning(targetSessionId)) {
            pauseGeneration()
        }
        val now = System.currentTimeMillis()
        val userMessage = ChatMessage(
            id = "user-$now-${messageIdCounter.incrementAndGet()}",
            author = MessageAuthor.User,
            text = content,
            createdAtMillis = now,
        )
        val farewellText = uiString(R.string.chat_farewell_reply)
        val assistantMessage = ChatMessage(
            id = "agent-farewell-$now",
            author = MessageAuthor.Agent,
            text = farewellText.resolve(getApplication()),
            createdAtMillis = now + 1,
        )
        var sessionForPersistence: ChatSession? = null
        armPostSendDraftEchoGuard(content)
        _uiState.update { current ->
            val updatedSessions = current.sessions.toMutableList()
            val existingIndex = updatedSessions.indexOfFirst { it.id == targetSessionId }
            val updated: ChatSession
            if (existingIndex >= 0) {
                val existing = updatedSessions.removeAt(existingIndex)
                updated = existing.withMessages(existing.messages + userMessage + assistantMessage)
            } else {
                val farewellDerivedTitle = userMessage.summaryText()
                    .replace('\n', ' ')
                    .trim()
                    .take(36)
                    .ifBlank { "New chat" }
                updated = createSession(
                    id = targetSessionId,
                    messages = listOf(userMessage, assistantMessage),
                    title = farewellDerivedTitle,
                    hasCustomTitle = false,
                    selectedModelKey = current.draftSelectedModelKey.ifBlank {
                        resolveDefaultChatModelKey(current.settings, current.providerConfigs)
                    },
                    selectedSkillIds = emptyList(),
                )
            }
            sessionForPersistence = updated
            updatedSessions.add(0, updated)
            current.copy(
                sessions = updatedSessions,
                currentSessionId = targetSessionId,
                draftInput = "",
                draftAttachments = emptyList(),
                draftSelectedModelKey = "",
                draftSelectedSkillIds = emptyList(),
                draftWorkspaceId = null,
                editingSessionId = null,
                editingMessageId = null,
                currentScreen = AppScreen.Chat,
                showStarterPromptHint = false,
                exitRequestSerial = current.exitRequestSerial + 1,
            )
        }
        sessionForPersistence?.let { session ->
            persistSessionSnapshot(
                session = session,
                currentSessionId = targetSessionId,
                moveToFront = true,
            )
        }
    }

    private fun compactCurrentSession(snapshot: ArixUiState) {
        compactSession(snapshot.currentSessionId, manual = true, snapshot = snapshot)
    }

    private fun compactSession(
        sessionId: String,
        manual: Boolean,
        snapshot: ArixUiState = _uiState.value,
    ) {
        if ((manual && snapshot.editingSessionId != null) || snapshot.editingSessionId == sessionId) {
            if (!manual) return
            emitTransientMessage(uiString(R.string.message_finish_editing_before_compacting))
            return
        }
        if (sessionId == DraftSessionId) {
            if (!manual) return
            emitTransientMessage(uiString(R.string.message_no_conversation_to_compact))
            return
        }
        if (sessionExecutionManager.isSessionRunning(sessionId)) {
            if (!manual) return
            emitTransientMessage(uiString(R.string.message_pause_before_compacting))
            return
        }
        if (snapshot.compactingSessionId != null) return
        val session = snapshot.sessions.firstOrNull { it.id == sessionId }
        if (session == null || session.messages.size < 2) {
            if (!manual) return
            emitTransientMessage(uiString(R.string.message_not_enough_conversation_to_compact))
            return
        }
        _uiState.update { current ->
            if (manual) {
                armPostSendDraftEchoGuard(current.draftInput)
                current.copy(
                    draftInput = "",
                    draftAttachments = emptyList(),
                    draftWorkspaceId = null,
                    editingSessionId = null,
                    editingMessageId = null,
                    showStarterPromptHint = false,
                    compactingSessionId = sessionId,
                )
            } else {
                current.copy(compactingSessionId = sessionId)
            }
        }

        viewModelScope.launch {
            try {
                val metadata = runtime.chatRepository.getAgentSessionMetadata(sessionId)
                val compactionSettings = resolveModelSettings(
                    baseSettings = snapshot.settings,
                    providerConfigs = snapshot.providerConfigs,
                    preferredModelKey = resolveDefaultCompactingModelKey(
                        snapshot.settings,
                        snapshot.providerConfigs,
                    ),
                    fallbackModelKey = session.selectedModelKey.ifBlank {
                        resolveDefaultChatModelKey(snapshot.settings, snapshot.providerConfigs)
                    },
                )
                piKernelBridge.compactSession(
                    sessionId = sessionId,
                    sessionPayload = JSONObject().apply {
                        put("session_file", metadata?.jsonlPath.orEmpty())
                        put("workspace_directory", workspaceFileBridge.workspaceDirectory(sessionId, compactionSettings.agentWorkspaceMode))
                        put("runtime", metadata?.runtime ?: compactionSettings.defaultRuntimeId?.storageValue.orEmpty())
                        put("platform", "android")
                        val modelKey = thinkingCatalogKey(compactionSettings.piProviderId, compactionSettings.modelId)
                        val thinkingLevelMap = _uiState.value.thinkingLevelClampsByProviderModel[modelKey].orEmpty()
                        val isReasoningModel = modelKey in _uiState.value.reasoningModels
                        put("model_config", compactionSettings.toPiModelConfig(thinkingLevelMap, isReasoningModel).toJson())
                        put("system_prompt", "")
                        put("host_tools", JSONArray())
                    },
                )
                val now = System.currentTimeMillis()
                val compactedMessages = session.messages + ChatMessage(
                    id = "compact-status-$now",
                    author = MessageAuthor.Agent,
                    text = "Context compacted",
                    createdAtMillis = now,
                    assistantActionsHidden = true,
                    displayKind = MessageDisplayKind.CompactStatus,
                )
                val updatedSession = session.withMessages(compactedMessages)
                _uiState.update { current ->
                    val sessionIndex = current.sessions.indexOfFirst { it.id == sessionId }
                    if (sessionIndex < 0) return@update current
                    val updatedSessions = current.sessions.toMutableList().apply {
                        set(sessionIndex, updatedSession)
                    }
                    current.copy(sessions = updatedSessions)
                }
                persistSessionSnapshot(updatedSession, currentSessionId = sessionId)
            } catch (throwable: Throwable) {
                if (throwable is CancellationException) throw throwable
                emitTransientMessage(uiString(R.string.message_compaction_failed, throwable.userFacingMessage()))
            } finally {
                _uiState.update { current ->
                    if (current.compactingSessionId == sessionId) {
                        current.copy(compactingSessionId = null)
                    } else {
                        current
                    }
                }
            }
        }
    }

    private fun ensureDraftWorkspaceId(): String {
        val snapshot = _uiState.value
        return snapshot.editingSessionId ?: when {
            snapshot.currentSessionId != DraftSessionId -> snapshot.currentSessionId
            !snapshot.draftWorkspaceId.isNullOrBlank() -> snapshot.draftWorkspaceId.orEmpty()
            else -> {
                val generatedId = "session-${System.currentTimeMillis()}-${messageIdCounter.incrementAndGet()}"
                _uiState.update { current ->
                    if (current.currentSessionId == DraftSessionId && current.draftWorkspaceId.isNullOrBlank()) {
                        current.copy(draftWorkspaceId = generatedId)
                    } else {
                        current
                    }
                }
                _uiState.value.draftWorkspaceId ?: generatedId
            }
        }
    }

    private fun ChatMessage.summaryText(): String {
        if (displayKind == MessageDisplayKind.CompactStatus) return text.ifBlank { "Context compacted" }
        val textSummary = text.trim()
        if (textSummary.isNotBlank()) return textSummary
        reasoningTrace?.let { trace ->
            trace.chunks.lastOrNull { it.detail.isNotBlank() || it.title.isNotBlank() }?.let { chunk ->
                return chunk.detail.ifBlank { chunk.title }
            }
            return if (trace.toolInvocations.isNotEmpty()) {
                "Thought and used ${trace.toolInvocations.size} tools"
            } else {
                "Thought"
            }
        }
        if (toolInvocations.isNotEmpty()) {
            return if (toolInvocations.size == 1) {
                when (toolInvocations.first().toolName.lowercase()) {
                    "bash" -> "Ran bash command"
                    else -> "Used ${toolInvocations.first().toolName}"
                }
            } else {
                "Used ${toolInvocations.size} tools"
            }
        }
        if (attachments.isEmpty()) return "Empty message"
        if (attachments.size == 1) return attachments.first().name
        return "${attachments.size} attachments"
    }

    private fun List<ChatMessage>.resolveConversationTrimIndex(
        targetIndex: Int,
    ): Int {
        val targetMessage = getOrNull(targetIndex) ?: return targetIndex
        val responseGroupId = targetMessage.responseGroupId
        if (targetMessage.author != MessageAuthor.Agent) {
            return targetIndex
        }
        if (responseGroupId.isNullOrBlank()) {
            return resolveLegacyAssistantGroupStartIndex(targetIndex)
        }
        val groupStartIndex = indexOfFirst { message ->
            message.author == MessageAuthor.Agent && message.responseGroupId == responseGroupId
        }
        return if (groupStartIndex >= 0) groupStartIndex else targetIndex
    }

    private fun List<ChatMessage>.resolveLegacyAssistantGroupStartIndex(
        targetIndex: Int,
    ): Int {
        val targetMessage = getOrNull(targetIndex) ?: return targetIndex
        if (targetMessage.author != MessageAuthor.Agent) return targetIndex
        var groupStartIndex = targetIndex
        var expectedCreatedAtMillis = targetMessage.createdAtMillis
        while (groupStartIndex > 0) {
            val previous = this[groupStartIndex - 1]
            if (
                previous.author != MessageAuthor.Agent ||
                !previous.responseGroupId.isNullOrBlank() ||
                previous.createdAtMillis != expectedCreatedAtMillis - 1
            ) {
                break
            }
            groupStartIndex -= 1
            expectedCreatedAtMillis = previous.createdAtMillis
        }
        return groupStartIndex
    }

    private fun parseNonBlankLines(rawValue: String): List<String> =
        com.arix.app.ui.parseNonBlankLines(rawValue)

    private fun performSkillInstall(
        onComplete: (Boolean) -> Unit = {},
        installBlock: suspend () -> Result<InstalledSkill>,
    ) {
        viewModelScope.launch {
            val result = installBlock()
            result
                .onSuccess { installedSkill ->
                    emitTransientMessage(uiString(R.string.message_installed_skill, installedSkill.name))
                    captureAnalyticsEvent(
                        event = "skill installed",
                        properties = mapOf(
                            "skill_id" to installedSkill.id,
                            "skill_name" to installedSkill.name,
                        ),
                    )
                }
                .onFailure { throwable ->
                    emitTransientMessage(
                        uiString(R.string.message_install_skill_failed, throwable.userFacingMessage())
                    )
                }
            onComplete(result.isSuccess)
        }
    }

    private fun writeTextToUri(
        uri: Uri,
        text: String,
    ): Boolean = runCatching {
        val resolver = getApplication<Application>().contentResolver
        resolver.openOutputStream(uri, "rwt")?.use { output ->
            output.write(text.toByteArray(Charsets.UTF_8))
            output.flush()
            (output as? FileOutputStream)?.fd?.sync()
        } ?: return false
        true
    }.getOrDefault(false)

    private fun readTextFromUri(uri: Uri): String =
        getApplication<Application>().contentResolver.openInputStream(uri)?.use { input ->
            input.readBytes().toString(Charsets.UTF_8)
        } ?: error("Unable to read the selected file.")

    private fun buildDiagnosticLogText(snapshot: ArixUiState): String = buildString {
        val logcat = readLogcatDump()
        val diagnosticEvents = diagnosticLogger.readEventsText()
        val lastCrash = diagnosticLogger.readLastCrashText()
        appendLine("Arix diagnostic log")
        appendLine("generatedAtMillis=${System.currentTimeMillis()}")
        appendLine("versionName=${BuildConfig.VERSION_NAME}")
        appendLine("versionCode=${BuildConfig.VERSION_CODE}")
        appendLine("debug=${BuildConfig.DEBUG}")
        appendLine("screen=${snapshot.currentScreen}")
        appendLine("currentSessionId=${snapshot.currentSessionId}")
        appendLine("sessionCount=${snapshot.sessions.size}")
        appendLine("runningSessionCount=${snapshot.sessionExecutionStates.values.count { it.isRunning }}")
        appendLine("piProviderId=${snapshot.settings.piProviderId}")
        appendLine("providerConfigCount=${snapshot.providerConfigs.size}")
        appendLine("skillCount=${snapshot.installedSkills.size}")
        appendLine()
        appendLine("settingsSummary:")
        appendLine(buildSettingsDiagnosticSummary(snapshot).toString(2))
        appendLine()
        appendLine("providerConfigsSummary:")
        appendLine(buildProviderConfigsDiagnosticSummary(snapshot).toString(2))
        appendLine()
        appendLine("sessionsSummary:")
        appendLine(buildSessionsDiagnosticSummary(snapshot).toString(2))
        appendLine()
        appendLine("lastCrash:")
        appendLine(lastCrash.ifBlank { "No crash breadcrumb recorded." })
        appendLine()
        appendLine("diagnosticEventsJsonl:")
        appendLine(diagnosticEvents.ifBlank { "No diagnostic events recorded." })
        appendLine()
        appendLine("logcatReadStatus:")
        appendLine(logcat.toJson().toString(2))
        appendLine()
        appendLine("logcat:")
        append(logcat.output.ifBlank { logcat.message.ifBlank { "No logcat output." } })
    }

    private fun buildSettingsDiagnosticSummary(snapshot: ArixUiState): JSONObject =
        JSONObject().apply {
            put("piProviderId", snapshot.settings.piProviderId)
            put("modelId", snapshot.settings.modelId)
            put("baseUrl", DiagnosticRedactor.sanitizedBaseUrl(snapshot.settings.baseUrl))
            put("defaultChatModelKey", snapshot.settings.defaultChatModelKey)
            put("defaultTitleModelKey", snapshot.settings.defaultTitleModelKey)
            put("defaultNamingModelKey", snapshot.settings.defaultNamingModelKey)
            put("llmInactivityReconnectTimeoutSeconds", snapshot.settings.llmInactivityReconnectTimeoutSeconds)
            put("keepTasksRunningInBackground", snapshot.settings.keepTasksRunningInBackground)
            put("notifyOnTaskCompletion", snapshot.settings.notifyOnTaskCompletion)
            put("privacyPolicyAccepted", snapshot.settings.privacyPolicyAccepted)
        }

    private fun buildProviderConfigsDiagnosticSummary(snapshot: ArixUiState): JSONArray =
        JSONArray().apply {
            snapshot.providerConfigs.forEach { config ->
                put(
                    JSONObject().apply {
                        put("id", config.id)
                        put("name", config.name)
                        put("piProviderId", config.piProviderId)
                        put("baseUrl", DiagnosticRedactor.sanitizedBaseUrl(config.baseUrl))
                        put("modelId", config.modelId)
                        put("cachedModelCount", config.cachedModels.size)
                        put("enabledModelCount", config.enabledModelIds.size)
                        put("isEnabled", config.isEnabled)
                    }
                )
            }
        }

    private fun buildSessionsDiagnosticSummary(snapshot: ArixUiState): JSONObject =
        JSONObject().apply {
            put("currentSessionId", snapshot.currentSessionId)
            put("sessionCount", snapshot.sessions.size)
            put(
                "runningSessions",
                JSONArray().apply {
                    snapshot.sessionExecutionStates.values
                        .filter { it.isRunning }
                        .forEach { state ->
                            put(
                                JSONObject().apply {
                                    put("sessionId", state.sessionId)
                                    put("pendingToolCount", state.pendingToolInvocations.size)
                                    put("pendingInputCount", state.pendingInputs.size)
                                    put("activeTurnStartedAtMillis", state.activeTurnStartedAtMillis ?: JSONObject.NULL)
                                    put("pendingStatusText", state.pendingStatusText)
                                    put("pendingStatusDetail", state.pendingStatusDetail)
                                }
                            )
                        }
                },
            )
            put(
                "recentSessions",
                JSONArray().apply {
                    snapshot.sessions
                        .sortedByDescending { session -> session.lastMessageAtMillis ?: 0L }
                        .take(12)
                        .forEach { session ->
                            put(
                                JSONObject().apply {
                                    put("id", session.id)
                                    put("title", session.title)
                                    put("messageCount", session.messageCount)
                                    put("lastMessageAtMillis", session.lastMessageAtMillis ?: 0L)
                                    put("selectedModelKey", session.selectedModelKey)
                                    put("selectedSkillCount", session.selectedSkillIds.size)
                                }
                            )
                        }
                },
            )
        }

    private fun readLogcatDump(): LogcatDump {
        val pid = android.os.Process.myPid().toString()
        val commands = listOf(
            listOf("logcat", "-d", "-v", "threadtime", "-t", "4000", "--pid", pid),
            listOf("logcat", "-d", "-v", "threadtime", "-t", "8000"),
        )

        commands.forEach { command ->
            val dump = runCatching { runLogcatCommand(command) }.getOrElse { throwable ->
                LogcatDump(
                    command = command,
                    success = false,
                    exitCode = null,
                    output = "",
                    message = throwable.message ?: "Unable to run logcat command.",
                )
            }
            if (dump.success && dump.output.isNotBlank()) {
                return dump
            }
        }

        return LogcatDump(
            command = emptyList(),
            success = false,
            exitCode = null,
            output = "",
            message = "Unable to read logcat output.",
        )
    }

    private fun runLogcatCommand(command: List<String>): LogcatDump {
        val process = ProcessBuilder(command)
            .redirectErrorStream(true)
            .start()
        val executor = Executors.newSingleThreadExecutor()
        val outputFuture = executor.submit<String> {
            process.inputStream.bufferedReader(Charsets.UTF_8).use { reader ->
                reader.readText()
            }
        }
        return try {
            if (!process.waitFor(LogcatReadTimeoutSeconds, TimeUnit.SECONDS)) {
                process.destroy()
                LogcatDump(
                    command = command,
                    success = false,
                    exitCode = null,
                    output = runCatching { outputFuture.get(500, TimeUnit.MILLISECONDS) }.getOrDefault(""),
                    message = "Logcat command timed out.",
                )
            } else {
                val output = outputFuture.get(1, TimeUnit.SECONDS)
                val exitCode = process.exitValue()
                LogcatDump(
                    command = command,
                    success = exitCode == 0 && output.isNotBlank(),
                    exitCode = exitCode,
                    output = output,
                    message = when {
                        exitCode != 0 -> "Logcat command exited with code $exitCode."
                        output.isBlank() -> "Logcat command returned no output."
                        else -> ""
                    },
                )
            }
        } finally {
            executor.shutdownNow()
        }
    }

    private suspend fun buildFullAppExportJson(
        snapshot: ArixUiState,
        sessions: List<ChatSession>,
    ): JSONObject {
        val piSessions = JSONArray()
        sessions.forEach { session ->
            runCatching { piKernelBridge.exportSessionJsonl(session.id) }
                .getOrNull()
                ?.let { exported ->
                    val path = exported.optString("exported_path")
                    val jsonl = path.takeIf(String::isNotBlank)
                        ?.let { filePath -> runCatching { java.io.File(filePath).readText(Charsets.UTF_8) }.getOrNull() }
                    piSessions.put(JSONObject().apply {
                        put("sessionId", session.id)
                        put("jsonlPath", path)
                        put("jsonl", jsonl ?: "")
                    })
                }
        }
        return JSONObject().apply {
            put("schemaVersion", 3)
            put("exportType", "app")
            put("exportedAtMillis", System.currentTimeMillis())
            put("settings", snapshot.settings.toJson())
            put("providerConfigs", JSONArray(serializeProviderConfigs(snapshot.providerConfigs)))
            put("sessions", JSONArray(serializeChatSessions(sessions.map { it.copy(activeSkills = emptyList()) })))
            put("currentSessionId", snapshot.currentSessionId)
            put("skillBundles", skillManager.exportSkillBundles(snapshot.installedSkills))
            put("piSessions", piSessions)
        }
    }

    private fun parseFullAppImport(
        json: JSONObject,
        installedSkills: List<InstalledSkill>,
    ): ImportedAppData {
        val sessions = sanitizeImportedSessions(
            sessions = parseChatSessions(json.optJSONArray("sessions")?.toString().orEmpty()),
            installedSkillIds = installedSkills.map { it.id }.toSet(),
        )
        val piSessions = buildMap {
            val entries = json.optJSONArray("piSessions") ?: JSONArray()
            for (index in 0 until entries.length()) {
                val item = entries.optJSONObject(index) ?: continue
                val id = item.optString("sessionId").trim()
                val jsonl = item.optString("jsonl")
                if (id.isNotBlank() && jsonl.isNotBlank()) put(id, jsonl)
            }
        }
        return ImportedAppData(
            settings = parseImportedSettings(json.optJSONObject("settings")),
            providerConfigs = parseProviderConfigs(json.optJSONArray("providerConfigs")?.toString().orEmpty()),
            sessions = sessions,
            currentSessionId = json.optString("currentSessionId")
                .takeIf { id -> id == DraftSessionId || sessions.any { it.id == id } }
                ?: DraftSessionId,
            installedSkills = installedSkills,
            piSessions = piSessions,
        )
    }

    private fun sanitizeImportedSessions(
        sessions: List<ChatSession>,
        installedSkillIds: Set<String>,
    ): List<ChatSession> =
        sessions.map { session ->
            session.copy(
                selectedSkillIds = session.selectedSkillIds.filter(installedSkillIds::contains),
                activeSkills = emptyList(),
            )
        }

    private fun AppSettings.toJson(): JSONObject = JSONObject().apply {
        put("piProviderId", piProviderId)
        put("providerConfigId", providerConfigId)
        put("providerAuthMethod", providerAuthMethod.storageValue)
        put("apiKey", apiKey)
        put("apiKeys", JSONArray(apiKeys))
        put("oauthCredentialJson", oauthCredentialJson)
        put(
            "providerEnvironmentVariables",
            JSONArray().apply {
                providerEnvironmentVariables.forEach { variable ->
                    put(
                        JSONObject()
                            .put("name", variable.name)
                            .put("value", variable.value)
                    )
                }
            },
        )
        put("baseUrl", baseUrl)
        put("modelId", modelId)
        put("serviceTier", serviceTier.trim())
        put("userAgent", normalizeLlmUserAgent(userAgent))
        put("customHeaders", customHeaders.toJsonArray())
        put("reasoningEffort", reasoningEffort)
        put("systemPrompt", systemPrompt)
        put("developerRoleUnsupported", developerRoleUnsupported)
        put("compatibilityMode", compatibilityMode)
        put("tavilyApiKey", tavilyApiKey)
        put("tavilyBaseUrl", tavilyBaseUrl)
        put("webSearchEngine", webSearchEngine)
        put("saveResearchToMemory", saveResearchToMemory)
        put("unrestrictedMode", unrestrictedMode)
        put("llmInactivityReconnectTimeoutSeconds", llmInactivityReconnectTimeoutSeconds)
        put("keepTasksRunningInBackground", keepTasksRunningInBackground)
        put("notifyOnTaskCompletion", notifyOnTaskCompletion)
        put("agentWorkspaceMode", agentWorkspaceMode.storageValue)
        put("enabledRuntimeIds", JSONArray().apply { enabledRuntimeIds.forEach { put(it.storageValue) } })
        put("defaultRuntimeId", defaultRuntimeId?.storageValue ?: JSONObject.NULL)
        put("termuxSetupCompleted", termuxSetupCompleted)
        put(
            "termuxEnvironmentVariables",
            JSONArray().apply {
                termuxEnvironmentVariables.forEach { variable ->
                    put(JSONObject().put("name", variable.name).put("value", variable.value))
                }
            },
        )
        put("autoCleanOldCommandHistory", autoCleanOldCommandHistory)
        put("oldCommandHistoryRetentionHours", oldCommandHistoryRetentionHours)
        put("language", language.storageValue)
        put("themeMode", themeMode.storageValue)
        put("defaultChatModelKey", defaultChatModelKey)
        put("defaultTitleModelKey", defaultTitleModelKey)
        put("defaultNamingModelKey", defaultNamingModelKey)
        put("defaultCompactingModelKey", defaultCompactingModelKey)
        put("defaultSelectedSkillIds", JSONArray(defaultSelectedSkillIds))
        put("onboardingSeenVersion", onboardingSeenVersion)
        put("onboardingCompletedVersion", onboardingCompletedVersion)
        put("privacyPolicyAccepted", privacyPolicyAccepted)
        put("lastUpdateCheckAtMillis", lastUpdateCheckAtMillis)
    }

    private fun parseImportedSettings(json: JSONObject?): AppSettings {
        if (json == null) return AppSettings()
        val defaults = AppSettings()
        val importedBaseUrl = json.optString("baseUrl", defaults.baseUrl)
        val importedPiProviderId = json.optString("piProviderId").trim().ifBlank {
            com.arix.app.data.inferLegacyPiProviderId(
                json.optString("provider"),
                importedBaseUrl,
            )
        }
        return AppSettings(
            piProviderId = importedPiProviderId,
            providerConfigId = json.optString("providerConfigId"),
            providerAuthMethod = com.arix.app.data.ProviderAuthMethod.fromStorage(
                json.optString("providerAuthMethod"),
            ),
            apiKey = json.optString("apiKey", defaults.apiKey),
            apiKeys = json.optJSONArray("apiKeys")
                ?.let { array ->
                    (0 until array.length()).mapNotNull { index ->
                        array.optString(index).trim().takeIf(String::isNotEmpty)
                    }
                }
                ?: defaults.apiKeys,
            oauthCredentialJson = json.optString(
                "oauthCredentialJson",
                defaults.oauthCredentialJson,
            ),
            providerEnvironmentVariables = com.arix.app.data
                .parseProviderEnvironmentVariables(
                    json.optJSONArray("providerEnvironmentVariables"),
                ),
            baseUrl = importedBaseUrl,
            modelId = json.optString("modelId", defaults.modelId),
            userAgent = normalizeLlmUserAgent(json.optString("userAgent", defaults.userAgent)),
            serviceTier = json.optString("serviceTier").trim(),
            customHeaders = parseCustomHeaders(json.optJSONArray("customHeaders")),
            reasoningEffort = normalizeReasoningEffort(
                json.optString("reasoningEffort", defaults.reasoningEffort),
            ),
            systemPrompt = json.optString("systemPrompt", defaults.systemPrompt),
            developerRoleUnsupported = json.optBoolean(
                "developerRoleUnsupported",
                defaults.developerRoleUnsupported,
            ),
            compatibilityMode = json.optBoolean(
                "compatibilityMode",
                defaults.compatibilityMode,
            ),
            tavilyApiKey = json.optString("tavilyApiKey", defaults.tavilyApiKey),
            tavilyBaseUrl = normalizeTavilyBaseUrl(
                json.optString("tavilyBaseUrl", defaults.tavilyBaseUrl),
            ),
            webSearchEngine = normalizeWebSearchEngine(
                json.optString("webSearchEngine", defaults.webSearchEngine),
            ),
            saveResearchToMemory = json.optBoolean(
                "saveResearchToMemory",
                defaults.saveResearchToMemory,
            ),
            unrestrictedMode = json.optBoolean(
                "unrestrictedMode",
                defaults.unrestrictedMode,
            ),
            llmInactivityReconnectTimeoutSeconds = normalizeLlmInactivityReconnectTimeoutSeconds(
                json.optInt(
                    "llmInactivityReconnectTimeoutSeconds",
                    defaults.llmInactivityReconnectTimeoutSeconds,
                )
            ),
            keepTasksRunningInBackground = json.optBoolean(
                "keepTasksRunningInBackground",
                defaults.keepTasksRunningInBackground,
            ),
            notifyOnTaskCompletion = json.optBoolean(
                "notifyOnTaskCompletion",
                defaults.notifyOnTaskCompletion,
            ),
            agentWorkspaceMode = AgentWorkspaceMode.fromStorage(
                json.optString("agentWorkspaceMode", defaults.agentWorkspaceMode.storageValue),
            ),
            autoCleanOldCommandHistory = json.optBoolean(
                "autoCleanOldCommandHistory",
                defaults.autoCleanOldCommandHistory,
            ),
            oldCommandHistoryRetentionHours = normalizeOldCommandHistoryRetentionHours(
                json.optInt(
                    "oldCommandHistoryRetentionHours",
                    defaults.oldCommandHistoryRetentionHours,
                )
            ),
            enabledRuntimeIds = parseImportedRuntimeIds(json.optJSONArray("enabledRuntimeIds")),
            defaultRuntimeId = LocalRuntimeId.fromStorage(json.optString("defaultRuntimeId")),
            termuxSetupCompleted = json.optBoolean(
                "termuxSetupCompleted",
                defaults.termuxSetupCompleted,
            ),
            termuxEnvironmentVariables = parseImportedTermuxEnvironmentVariables(
                json.optJSONArray("termuxEnvironmentVariables")
            ),
            language = AppLanguage.fromStorage(
                json.optString("language"),
                defaults.language,
            ),
            themeMode = AppThemeMode.fromStorage(json.optString("themeMode")),
            defaultChatModelKey = json.optString("defaultChatModelKey", defaults.defaultChatModelKey),
            defaultTitleModelKey = json.optString("defaultTitleModelKey", defaults.defaultTitleModelKey),
            defaultNamingModelKey = json.optString("defaultNamingModelKey", defaults.defaultNamingModelKey),
            defaultCompactingModelKey = json.optString(
                "defaultCompactingModelKey",
                defaults.defaultCompactingModelKey,
            ),
            defaultSelectedSkillIds = json.optJSONArray("defaultSelectedSkillIds").toStringList(),
            onboardingSeenVersion = json.optInt("onboardingSeenVersion", defaults.onboardingSeenVersion),
            onboardingCompletedVersion = json.optInt(
                "onboardingCompletedVersion",
                defaults.onboardingCompletedVersion,
            ),
            privacyPolicyAccepted = json.optBoolean(
                "privacyPolicyAccepted",
                defaults.privacyPolicyAccepted,
            ),
            lastUpdateCheckAtMillis = json.optLong(
                "lastUpdateCheckAtMillis",
                defaults.lastUpdateCheckAtMillis,
            ),
        )
    }

    private fun parseImportedTermuxEnvironmentVariables(
        array: JSONArray?,
    ): List<TermuxEnvironmentVariable> {
        if (array == null) return emptyList()
        return normalizeTermuxEnvironmentVariables(
            buildList {
                for (index in 0 until array.length()) {
                    val item = array.optJSONObject(index) ?: continue
                    add(
                        TermuxEnvironmentVariable(
                            name = item.optString("name"),
                            value = item.optString("value"),
                        )
                    )
                }
            }
        )
    }

    private fun parseImportedRuntimeIds(array: JSONArray?): Set<LocalRuntimeId> {
        if (array == null) return emptySet()
        return buildSet {
            for (index in 0 until array.length()) {
                LocalRuntimeId.fromStorage(array.optString(index))?.let(::add)
            }
        }
    }

    private fun emitTransientMessage(message: UiText) {
        _transientMessages.tryEmit(message)
    }

    private fun uiString(resId: Int, vararg formatArgs: Any): UiText =
        UiText.Resource(resId, formatArgs.toList())

    private fun Throwable.userFacingMessage(): String =
        message?.trim().takeUnless { it.isNullOrBlank() } ?: javaClass.simpleName

    private data class SessionMetadata(
        val title: String,
        val preview: String,
    )

    private data class AttachmentMetadata(
        val displayName: String,
        val mimeType: String,
        val sizeBytes: Long?,
        val kind: AttachmentKind,
    )

    private data class LogcatDump(
        val command: List<String>,
        val success: Boolean,
        val exitCode: Int?,
        val output: String,
        val message: String,
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("command", command.joinToString(" "))
            put("success", success)
            put("exitCode", exitCode ?: JSONObject.NULL)
            put("lineCount", output.lineSequence().count())
            put("message", message)
        }
    }

    private data class ImportedAppData(
        val settings: AppSettings,
        val providerConfigs: List<LlmProviderConfig>,
        val sessions: List<ChatSession>,
        val currentSessionId: String,
        val installedSkills: List<InstalledSkill>,
        val piSessions: Map<String, String> = emptyMap(),
    )
}

internal fun ArixUiState.withFinalizedPausedSession(
    finalizedSession: ChatSession,
    executionStates: Map<String, SessionExecutionState>,
): ArixUiState {
    val currentExecution = executionStates[currentSessionId]
    val updatedSessions = if (sessions.any { it.id == finalizedSession.id }) {
        sessions.map { if (it.id == finalizedSession.id) finalizedSession else it }
    } else {
        listOf(finalizedSession) + sessions
    }
    return copy(
        sessions = updatedSessions,
        sessionExecutionStates = executionStates,
        isSending = currentExecution?.isRunning == true,
        pendingResponseSessionId = currentExecution?.sessionId,
        pendingToolInvocations = currentExecution?.pendingToolInvocations.orEmpty(),
        pendingResponseBlocks = currentExecution?.pendingResponseBlocks.orEmpty(),
        pendingAssistantText = currentExecution?.pendingAssistantText.orEmpty(),
        pendingStatusText = currentExecution?.pendingStatusText.orEmpty(),
        pendingStatusDetail = currentExecution?.pendingStatusDetail.orEmpty(),
    )
}

private fun AppSettings.withRuntimeEnabled(
    runtimeId: LocalRuntimeId,
    makeDefault: Boolean = defaultRuntimeId == null,
): AppSettings {
    val enabled = enabledRuntimeIds + runtimeId
    return copy(
        termuxSetupCompleted = termuxSetupCompleted || runtimeId == LocalRuntimeId.Termux,
        enabledRuntimeIds = enabled,
        defaultRuntimeId = if (makeDefault) runtimeId else defaultRuntimeId,
    )
}

private fun JSONArray?.toStringList(): List<String> {
    if (this == null) return emptyList()
    return buildList {
        for (index in 0 until length()) {
            optString(index).trim().takeIf(String::isNotBlank)?.let(::add)
        }
    }.distinct()
}
