package com.arix.app.mcp

import android.content.Context
import kotlinx.coroutines.flow.first
import org.json.JSONObject

enum class ArixConnectorAuthKind {
    NONE,

    OAUTH,

    OAUTH_CLIENT_ID,

    KEY_HEADER,

    KEY_QUERY,

    KEY_ENV,
}

data class ArixConnectorAuth(
    val kind: String = "none",
    val clientIdRequired: Boolean = false,
    val secretRequired: Boolean = false,
    val developer: String? = null,
    val header: String? = null,
    val prefix: String? = null,
    val query: String? = null,
    val where: String? = null,
    val envKey: String? = null,
    val redirect: String? = null,
)

data class ArixConnector(
    val id: String,
    val name: String,
    val category: String,
    val url: String,
    val auth: ArixConnectorAuth = ArixConnectorAuth(),
    val docs: String? = null,
    val color: String = "#5B5BD6",
    val aboutEn: String = "",
    val aboutZh: String = "",
    val command: String? = null,
    val args: List<String> = emptyList(),
) {
    val isStdio: Boolean get() = !command.isNullOrBlank()

    val authKind: ArixConnectorAuthKind
        get() = when {
            auth.kind == "key" && !auth.envKey.isNullOrBlank() -> ArixConnectorAuthKind.KEY_ENV
            auth.kind == "oauth" && auth.clientIdRequired -> ArixConnectorAuthKind.OAUTH_CLIENT_ID
            auth.kind == "oauth" -> ArixConnectorAuthKind.OAUTH
            auth.kind == "key" && !auth.query.isNullOrBlank() -> ArixConnectorAuthKind.KEY_QUERY
            auth.kind == "key" -> ArixConnectorAuthKind.KEY_HEADER
            auth.kind == "none" -> ArixConnectorAuthKind.NONE
            else -> ArixConnectorAuthKind.OAUTH
        }

    val initial: String get() = name.take(1).uppercase()

    val preferredRedirect: String
        get() = when (auth.redirect) {
            "scheme" -> ArixMcpOAuth.CustomSchemeRedirect
            "loopback" -> ArixMcpOAuth.LoopbackRedirect
            "loopback-localhost" -> ArixMcpOAuth.LoopbackLocalhostRedirect
            else -> if (authKind == ArixConnectorAuthKind.OAUTH_CLIENT_ID) {
                ArixMcpOAuth.CustomSchemeRedirect
            } else {
                ArixMcpOAuth.LoopbackRedirect
            }
        }
}

object ArixConnectorLibrary {

    val categoryOrder = listOf(
        "agent", "tools", "ai", "work", "talk", "files", "dev", "data", "design", "money",
    )

    @Volatile
    private var cached: List<ArixConnector>? = null

    fun load(context: Context): List<ArixConnector> {
        cached?.let { return it }
        synchronized(this) {
            cached?.let { return it }
            val loaded = runCatching {
                val raw = context.assets.open("connectors.json")
                    .bufferedReader().use { it.readText() }
                val root = JSONObject(raw)
                val array = root.getJSONArray("connectors")
                buildList {
                    for (index in 0 until array.length()) {
                        val entry = array.getJSONObject(index)
                        val authJson = entry.optJSONObject("auth") ?: JSONObject()
                        val about = entry.optJSONObject("about") ?: JSONObject()
                        val stdioJson = entry.optJSONObject("stdio")
                        val argsJson = stdioJson?.optJSONArray("args")
                        val stdioArgs = mutableListOf<String>()
                        argsJson?.let { array2 ->
                            for (argIndex in 0 until array2.length()) {
                                array2.optString(argIndex)
                                    .takeIf { it.isNotEmpty() }?.let(stdioArgs::add)
                            }
                        }
                        add(
                            ArixConnector(
                                id = entry.optString("id"),
                                name = entry.optString("name"),
                                category = entry.optString("category"),
                                url = entry.optString("url"),
                                auth = ArixConnectorAuth(
                                    kind = authJson.optString("kind", "none"),
                                    clientIdRequired = authJson.optBoolean("clientIdRequired"),
                                    secretRequired = authJson.optBoolean("secretRequired"),
                                    developer = authJson.optString("developer")
                                        .takeIf { it.isNotBlank() },
                                    header = authJson.optString("header").takeIf { it.isNotBlank() },
                                    prefix = authJson.optString("prefix").takeIf { it.isNotBlank() },
                                    query = authJson.optString("query").takeIf { it.isNotBlank() },
                                    where = authJson.optString("where").takeIf { it.isNotBlank() },
                                    envKey = authJson.optString("envKey").takeIf { it.isNotBlank() },
                                    redirect = authJson.optString("redirect").takeIf { it.isNotBlank() },
                                ),
                                docs = entry.optString("docs").takeIf { it.isNotBlank() },
                                color = entry.optString("color").takeIf { it.isNotBlank() }
                                    ?: "#5B5BD6",
                                aboutEn = about.optString("en"),
                                aboutZh = about.optString("zh"),
                                command = stdioJson?.optString("command")
                                    ?.takeIf { it.isNotBlank() },
                                args = stdioArgs,
                            ),
                        )
                    }
                }
            }.getOrNull()
            if (loaded != null) {
                cached = loaded
                return loaded
            }
            return emptyList()
        }
    }
}

class ArixConnectorInstaller(
    private val repository: ArixMcpRepository,
    private val manager: ArixMcpManager,
) {

    suspend fun installOpen(connector: ArixConnector) {
        upsert(
            connector,
            if (connector.isStdio) {
                ArixMcpServerConfig(
                    name = connector.id,
                    command = connector.command,
                    args = connector.args,
                )
            } else {
                ArixMcpServerConfig(
                    name = connector.id,
                    url = connector.url,
                )
            },
        )
    }

    suspend fun installWithKey(connector: ArixConnector, key: String): ArixMcpServerConfig {
        val trimmedKey = key.trim()
        val config = when (connector.authKind) {
            ArixConnectorAuthKind.KEY_QUERY -> {
                val param = connector.auth.query?.takeIf { it.isNotBlank() } ?: "key"
                val separator = if (connector.url.contains('?')) '&' else '?'
                ArixMcpServerConfig(
                    name = connector.id,
                    url = "$connector.url$separator$param=${android.net.Uri.encode(trimmedKey)}",
                )
            }
            ArixConnectorAuthKind.KEY_ENV -> {
                val envName = connector.auth.envKey?.takeIf { it.isNotBlank() }
                    ?: connector.id.uppercase() + "_API_KEY"
                ArixMcpServerConfig(
                    name = connector.id,
                    command = connector.command,
                    args = connector.args,
                    env = mapOf(envName to trimmedKey),
                )
            }
            else -> {
                val header = connector.auth.header?.takeIf { it.isNotBlank() } ?: "Authorization"
                val prefix = connector.auth.prefix.orEmpty()
                ArixMcpServerConfig(
                    name = connector.id,
                    url = connector.url,
                    headers = mapOf(header to "$prefix$trimmedKey"),
                )
            }
        }
        return upsert(connector, config)
    }

    suspend fun prepareOAuth(connector: ArixConnector) {
        upsert(
            connector,
            ArixMcpServerConfig(
                name = connector.id,
                url = connector.url,
                oauth = ArixMcpOAuthConfig(),
            ),
        )
    }

    private suspend fun upsert(
        connector: ArixConnector,
        config: ArixMcpServerConfig,
    ): ArixMcpServerConfig {
        val existing = repository.servers.first().firstOrNull { it.name == connector.id }
        val merged = if (existing == null) {
            config
        } else {
            config.copy(
                enabled = existing.enabled,
                disabledTools = existing.disabledTools,
                env = if (config.env.isNotEmpty()) config.env else existing.env,
                headers = if (config.isStdio) emptyMap() else config.headers.ifEmpty { existing.headers },
                oauth = when {
                    config.oauth?.hasTokens == true -> config.oauth
                    existing.oauth?.hasTokens == true -> existing.oauth
                    else -> config.oauth ?: existing.oauth
                },
            )
        }
        repository.upsertServer(merged)
        manager.reloadServer(connector.id)
        return merged
    }

    suspend fun remove(connector: ArixConnector) {
        manager.removeServer(connector.id)
    }
}
