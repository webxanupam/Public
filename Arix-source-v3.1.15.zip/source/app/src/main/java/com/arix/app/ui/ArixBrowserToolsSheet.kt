package com.arix.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Article
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DesktopWindows
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.FileDownload
import androidx.compose.material.icons.rounded.Http
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.SmartToy
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material.icons.rounded.Audiotrack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.arix.app.browser.ArixBrowserDownloads
import com.arix.app.browser.ArixBrowserNetworkLog
import com.arix.app.browser.ArixBrowserSnapshot
import com.arix.app.browser.ArixBrowserTab
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.Locale

internal enum class BrowserToolsPage {
    Menu, Network, Media, Downloads
}

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
internal fun ArixBrowserToolsSheet(
    chrome: ArixChromeColors,
    onDismiss: () -> Unit,
    page: BrowserToolsPage,
    onPageChange: (BrowserToolsPage) -> Unit,
    snapshot: ArixBrowserSnapshot,
    activeTab: ArixBrowserTab?,
    desktopMode: Boolean,
    onReader: () -> Unit,
    onScreenshot: () -> Unit,
    onDesktopMode: (Boolean) -> Unit,
    onReset: () -> Unit,
) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = chrome.window,
        scrimColor = Color.Black.copy(alpha = 0.55f),
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        dragHandle = null,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 20.dp),
        ) {
            when (page) {
                BrowserToolsPage.Menu -> ToolsMenuPage(
                    chrome = chrome,
                    snapshot = snapshot,
                    desktopMode = desktopMode,
                    onReader = onReader,
                    onScreenshot = onScreenshot,
                    onDesktopMode = onDesktopMode,
                    onNetwork = { onPageChange(BrowserToolsPage.Network) },
                    onMedia = { onPageChange(BrowserToolsPage.Media) },
                    onDownloads = { onPageChange(BrowserToolsPage.Downloads) },
                    onReset = onReset,
                )
                BrowserToolsPage.Network -> NetworkPage(
                    chrome = chrome,
                    activeTab = activeTab,
                    onBack = { onPageChange(BrowserToolsPage.Menu) },
                )
                BrowserToolsPage.Media -> MediaPage(
                    chrome = chrome,
                    activeTab = activeTab,
                    referer = snapshot.url,
                    onBack = { onPageChange(BrowserToolsPage.Menu) },
                )
                BrowserToolsPage.Downloads -> DownloadsPage(
                    chrome = chrome,
                    context = context,
                    onBack = { onPageChange(BrowserToolsPage.Menu) },
                )
            }
        }
    }
}

@Composable
private fun ToolsMenuPage(
    chrome: ArixChromeColors,
    snapshot: ArixBrowserSnapshot,
    desktopMode: Boolean,
    onReader: () -> Unit,
    onScreenshot: () -> Unit,
    onDesktopMode: (Boolean) -> Unit,
    onNetwork: () -> Unit,
    onMedia: () -> Unit,
    onDownloads: () -> Unit,
    onReset: () -> Unit,
) {
    SheetHeader(chrome = chrome, snapshot = snapshot)

    SectionLabel("PAGE")
    ToolRow(
        chrome = chrome,
        icon = Icons.Rounded.Article,
        tint = chrome.accent,
        title = "Reader mode",
        subtitle = "Clean text of this page, as markdown",
        onClick = onReader,
    )
    ToolRow(
        chrome = chrome,
        icon = Icons.Rounded.PhotoCamera,
        tint = chrome.accent,
        title = "Screenshot",
        subtitle = "Capture, save or share the viewport",
        onClick = onScreenshot,
    )
    ToolRow(
        chrome = chrome,
        icon = Icons.Rounded.DesktopWindows,
        tint = chrome.accent,
        title = "Desktop site",
        subtitle = if (desktopMode) "Full desktop layout is on" else "Request the full desktop layout",
        onClick = { onDesktopMode(!desktopMode) },
        trailing = {
            Switch(
                checked = desktopMode,
                onCheckedChange = onDesktopMode,
                colors = SwitchDefaults.colors(
                    checkedTrackColor = chrome.accent,
                    uncheckedTrackColor = chrome.fieldBorder,
                ),
            )
        },
    )

    SectionLabel("DEVELOPER TOOLS")
    ToolRow(
        chrome = chrome,
        icon = Icons.Rounded.Http,
        tint = Color(0xFFFDD663),
        title = "API & network",
        subtitle = "Endpoints the page calls, with responses",
        onClick = onNetwork,
        trailing = { Chevron(chrome) },
    )
    ToolRow(
        chrome = chrome,
        icon = Icons.Rounded.PhotoLibrary,
        tint = Color(0xFFF28B82),
        title = "Media extractor",
        subtitle = "Every image, video and audio on the page",
        onClick = onMedia,
        trailing = { Chevron(chrome) },
    )

    SectionLabel("DOWNLOADS")
    ToolRow(
        chrome = chrome,
        icon = Icons.Rounded.FileDownload,
        tint = Color(0xFF81C995),
        title = "Downloads",
        subtitle = "Files this browser downloaded",
        onClick = onDownloads,
        trailing = { Chevron(chrome) },
    )

    SectionLabel("SESSION")
    ToolRow(
        chrome = chrome,
        icon = Icons.Rounded.Delete,
        tint = Color(0xFFF28B82),
        title = "Reset browser session",
        subtitle = "Close the page, clear cookies and storage",
        onClick = onReset,
    )

    Spacer(Modifier.height(6.dp))
    Text(
        text = "Arix Agent Browser",
        style = MaterialTheme.typography.labelSmall,
        color = chrome.textSecondary.copy(alpha = 0.7f),
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 4.dp),
        textAlign = TextAlign.Center,
    )
}

@Composable
private fun SheetHeader(chrome: ArixChromeColors, snapshot: ArixBrowserSnapshot) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 14.dp),
    ) {
        Box(
            modifier = Modifier
                .size(width = 44.dp, height = 4.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(chrome.textSecondary.copy(alpha = 0.4f))
                .align(Alignment.CenterHorizontally),
        )
        Spacer(Modifier.height(14.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(chrome.accent.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = Icons.Rounded.SmartToy,
                    contentDescription = null,
                    tint = chrome.accent,
                    modifier = Modifier.size(22.dp),
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    text = "Browser tools",
                    style = MaterialTheme.typography.titleMedium,
                    color = chrome.text,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (snapshot.url.startsWith("https://")) {
                        Icon(
                            imageVector = Icons.Rounded.Lock,
                            contentDescription = null,
                            tint = chrome.accent,
                            modifier = Modifier.size(12.dp),
                        )
                        Spacer(Modifier.width(4.dp))
                    }
                    Text(
                        text = snapshot.host.ifBlank { "No page open" },
                        style = MaterialTheme.typography.bodySmall,
                        color = chrome.textSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(chrome.divider),
        )
    }
}

@Composable
private fun SectionLabel(label: String) {
    Text(
        text = label,
        style = MaterialTheme.typography.labelSmall.copy(
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 1.2.sp,
        ),
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 20.dp, top = 14.dp, bottom = 4.dp),
    )
}

@Composable
private fun ToolRow(
    chrome: ArixChromeColors,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    trailing: (@Composable () -> Unit)? = null,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(13.dp))
                .background(tint.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = tint,
                modifier = Modifier.size(22.dp),
            )
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                color = chrome.text,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = chrome.textSecondary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
        trailing?.invoke()
    }
}

@Composable
private fun Chevron(chrome: ArixChromeColors) {
    Icon(
        imageVector = Icons.Rounded.ChevronRight,
        contentDescription = null,
        tint = chrome.textSecondary.copy(alpha = 0.6f),
        modifier = Modifier.size(20.dp),
    )
}

@Composable
private fun PanelHeader(
    chrome: ArixChromeColors,
    title: String,
    subtitle: String,
    onBack: () -> Unit,
    actions: (@Composable RowScope.() -> Unit)? = null,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButtonThin(chrome = chrome, onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = "Back",
                    tint = chrome.text,
                    modifier = Modifier.size(22.dp),
                )
            }
            Column(Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = chrome.text,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = chrome.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            actions?.invoke(this)
            Spacer(Modifier.width(8.dp))
        }
        Box(
            Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(chrome.divider),
        )
    }
}

@Composable
private fun IconButtonThin(
    chrome: ArixChromeColors,
    onClick: () -> Unit,
    content: @Composable () -> Unit,
) {
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(chrome.omnibox)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        content()
    }
}

@Composable
private fun NetworkPage(
    chrome: ArixChromeColors,
    activeTab: ArixBrowserTab?,
    onBack: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    var loading by remember { mutableStateOf(true) }
    var entries by remember { mutableStateOf<List<ArixBrowserNetworkLog.Entry>>(emptyList()) }
    var onlyApi by remember { mutableStateOf(true) }
    var detail by remember { mutableStateOf<ArixBrowserNetworkLog.Entry?>(null) }

    fun reload() {
        loading = true
        scope.launch {
            entries = withContext(Dispatchers.IO) {
                if (activeTab == null) {
                    com.arix.app.browser.ArixBrowserSession.networkLogForUser(onlyApi, null)
                } else {
                    com.arix.app.browser.ArixBrowserTabs.networkLog(activeTab, onlyApi, null)
                }
            }
            loading = false
        }
    }

    LaunchedEffect(onlyApi, activeTab?.id) { reload() }

    PanelHeader(
        chrome = chrome,
        title = "API & network",
        subtitle = if (onlyApi) "JSON / XHR / fetch endpoints" else "Every request the page made",
        onBack = onBack,
    ) {
        TextButton(onClick = { onlyApi = !onlyApi }) {
            Text(
                if (onlyApi) "Show all" else "APIs only",
                color = chrome.accent,
                style = MaterialTheme.typography.labelLarge,
            )
        }
        IconButtonThin(chrome = chrome, onClick = { reload() }) {
            Icon(
                imageVector = Icons.Rounded.Refresh,
                contentDescription = "Refresh",
                tint = chrome.text,
                modifier = Modifier.size(20.dp),
            )
        }
    }

    Box(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
    ) {
        if (loading) {
            CircularProgressIndicator(
                color = chrome.accent,
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(vertical = 42.dp)
                    .size(30.dp),
            )
        } else if (entries.isEmpty()) {
            PanelEmptyState(
                chrome = chrome,
                text = "No captured requests yet.\nInteract with the page, then refresh — API calls appear here.",
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(420.dp),
            ) {
                items(entries) { entry ->
                    NetworkEntryRow(chrome = chrome, entry = entry, onClick = { detail = entry })
                }
            }
        }
    }

    detail?.let { entry ->
        NetworkDetailDialog(chrome = chrome, entry = entry, onDismiss = { detail = null })
    }
}

@Composable
private fun NetworkEntryRow(
    chrome: ArixChromeColors,
    entry: ArixBrowserNetworkLog.Entry,
    onClick: () -> Unit,
) {
    val statusColor = when {
        entry.status == null -> chrome.textSecondary
        entry.status in 200..299 -> Color(0xFF81C995)
        entry.status in 300..399 -> Color(0xFFFDD663)
        entry.status >= 400 -> Color(0xFFF28B82)
        else -> chrome.textSecondary
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 7.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = entry.method,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = statusColor,
            modifier = Modifier.width(44.dp),
        )
        Column(Modifier.weight(1f)) {
            Text(
                text = entry.url.substringBefore('?').takeLast(80),
                style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                color = chrome.text,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = buildString {
                    entry.via?.let { append(it.uppercase(Locale.ROOT)); append("  ") }
                    entry.status?.let { append(it); append("  ") }
                    entry.contentType?.take(40)?.let { append(it) }
                }.trim(),
                style = MaterialTheme.typography.labelSmall,
                color = chrome.textSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Icon(
            imageVector = Icons.Rounded.ChevronRight,
            contentDescription = null,
            tint = chrome.textSecondary.copy(alpha = 0.5f),
            modifier = Modifier.size(18.dp),
        )
    }
}

@Composable
private fun NetworkDetailDialog(
    chrome: ArixChromeColors,
    entry: ArixBrowserNetworkLog.Entry,
    onDismiss: () -> Unit,
) {
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = chrome.toolbar,
        titleContentColor = chrome.text,
        textContentColor = chrome.text,
        title = { Text("${entry.method} request", style = MaterialTheme.typography.titleSmall) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                DetailLabel("URL")
                DetailMono(entry.url, chrome)
                DetailLabel("Type")
                DetailMono(
                    buildString {
                        append(entry.kind)
                        entry.via?.let { append(" via "); append(it) }
                    },
                    chrome,
                )
                entry.status?.let {
                    DetailLabel("Status")
                    DetailMono(it.toString(), chrome)
                }
                entry.contentType?.let {
                    DetailLabel("Content type")
                    DetailMono(it, chrome)
                }
                entry.durationMs?.let {
                    DetailLabel("Duration")
                    DetailMono("${it}ms", chrome)
                }
                entry.requestBody?.let {
                    DetailLabel("Request body")
                    DetailMono(it, chrome)
                }
                entry.responsePreview?.let {
                    DetailLabel("Response preview")
                    DetailMono(it, chrome)
                }
                if (entry.responsePreview == null && entry.requestBody == null) {
                    Text(
                        "No body captured for this call (made before capture, or non-text content).",
                        style = MaterialTheme.typography.bodySmall,
                        color = chrome.textSecondary,
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { copyToClipboard(context, entry.url, "URL copied"); onDismiss() }) {
                Text("Copy URL", color = chrome.accent)
            }
        },
        dismissButton = {
            Row {
                entry.responsePreview?.let {
                    TextButton(onClick = { copyToClipboard(context, it, "Response copied") }) {
                        Text("Copy response", color = chrome.textSecondary)
                    }
                }
                TextButton(onClick = onDismiss) { Text("Close", color = chrome.textSecondary) }
            }
        },
    )
}

@Composable
private fun DetailLabel(text: String) {
    Text(
        text = text.uppercase(Locale.ROOT),
        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 10.dp, bottom = 2.dp),
    )
}

@Composable
private fun DetailMono(text: String, chrome: ArixChromeColors) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodySmall.copy(
            fontFamily = FontFamily.Monospace,
            lineHeight = 17.sp,
        ),
        color = chrome.text,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(chrome.omnibox)
            .padding(8.dp),
    )
}

private data class MediaItem(
    val kind: String,
    val url: String,
    val alt: String?,
    val width: Int?,
    val height: Int?,
    val source: String?,
)

@Composable
private fun MediaPage(
    chrome: ArixChromeColors,
    activeTab: ArixBrowserTab?,
    referer: String,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var loading by remember { mutableStateOf(true) }
    var items by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var kindFilter by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(activeTab?.id) {
        loading = true
        items = withContext(Dispatchers.IO) {
            val value: JSONObject? = if (activeTab == null) {
                runCatching {
                    val result = com.arix.app.browser.ArixBrowserSession.extractMediaFromUser()
                    runCatching { JSONObject(result.content) }.getOrNull()
                }.getOrNull()
            } else {
                com.arix.app.browser.ArixBrowserTabs.extractMedia(activeTab)
            }
            val media = value?.optJSONArray("media") ?: return@withContext emptyList()
            (0 until media.length()).mapNotNull { index ->
                media.optJSONObject(index)?.let { item ->
                    MediaItem(
                        kind = item.optString("kind"),
                        url = item.optString("url"),
                        alt = item.optString("alt").takeIf { it.isNotBlank() },
                        width = if (item.isNull("width")) null else item.optInt("width"),
                        height = if (item.isNull("height")) null else item.optInt("height"),
                        source = item.optString("source").takeIf { it.isNotBlank() },
                    )
                }
            }
        }
        loading = false
    }

    val kinds = remember(items) { items.map { it.kind }.distinct().sorted() }
    val filtered = remember(items, kindFilter) {
        if (kindFilter == null) items else items.filter { it.kind == kindFilter }
    }

    PanelHeader(
        chrome = chrome,
        title = "Media extractor",
        subtitle = "${items.size} item${if (items.size == 1) "" else "s"} on this page",
        onBack = onBack,
    )

    if (kinds.size > 1) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            FilterChip(
                chrome = chrome,
                label = "All (${items.size})",
                selected = kindFilter == null,
                onClick = { kindFilter = null },
            )
            kinds.forEach { kind ->
                FilterChip(
                    chrome = chrome,
                    label = "${kind.replaceFirstChar { it.uppercase(Locale.ROOT) }} (${items.count { it.kind == kind }})",
                    selected = kindFilter == kind,
                    onClick = { kindFilter = kind },
                )
            }
        }
    }

    Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
        when {
            loading -> CircularProgressIndicator(
                color = chrome.accent,
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(vertical = 42.dp)
                    .size(30.dp),
            )
            filtered.isEmpty() -> PanelEmptyState(
                chrome = chrome,
                text = "No media found on this page.",
            )
            else -> LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(420.dp),
            ) {
                items(filtered) { item ->
                    MediaRow(chrome = chrome, item = item) {
                        scope.launch(Dispatchers.IO) {
                            ArixBrowserDownloads.enqueue(
                                context = context,
                                url = item.url,
                                userAgent = com.arix.app.browser.ArixBrowserTabs.DESKTOP_USER_AGENT,
                                contentDisposition = null,
                                mimeType = null,
                                referer = referer.takeIf { it.isNotBlank() },
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FilterChip(
    chrome: ArixChromeColors,
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
) {
    Text(
        text = label,
        style = MaterialTheme.typography.labelMedium,
        color = if (selected) chrome.window else chrome.text,
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) chrome.accent else chrome.omnibox)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
    )
}

@Composable
private fun MediaRow(
    chrome: ArixChromeColors,
    item: MediaItem,
    onDownload: () -> Unit,
) {
    val (kindIcon, kindTint) = when (item.kind) {
        "video" -> Icons.Rounded.Videocam to Color(0xFFF28B82)
        "audio" -> Icons.Rounded.Audiotrack to Color(0xFFFDD663)
        else -> Icons.Rounded.Image to chrome.accent
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 7.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(11.dp))
                .background(kindTint.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = kindIcon,
                contentDescription = null,
                tint = kindTint,
                modifier = Modifier.size(20.dp),
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = item.alt
                    ?: item.url.substringBefore('?').substringAfterLast('/').ifBlank { item.url },
                style = MaterialTheme.typography.bodySmall,
                color = chrome.text,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = buildString {
                    append(item.kind)
                    item.width?.takeIf { it > 0 }?.let {
                        append("  ·  ${it}×${item.height ?: 0}")
                    }
                    item.source?.let { append("  ·  $it") }
                },
                style = MaterialTheme.typography.labelSmall,
                color = chrome.textSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(11.dp))
                .background(chrome.accent.copy(alpha = 0.14f))
                .clickable(onClick = onDownload),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = Icons.Rounded.Download,
                contentDescription = "Download",
                tint = chrome.accent,
                modifier = Modifier.size(18.dp),
            )
        }
    }
}

@Composable
private fun PanelEmptyState(chrome: ArixChromeColors, text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodyMedium,
        color = chrome.textSecondary,
        textAlign = TextAlign.Center,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 42.dp, horizontal = 24.dp),
    )
}

@Composable
private fun DownloadsPage(
    chrome: ArixChromeColors,
    context: Context,
    onBack: () -> Unit,
) {
    var loading by remember { mutableStateOf(true) }
    var rows by remember { mutableStateOf<List<ArixBrowserDownloads.DownloadRow>>(emptyList()) }

    LaunchedEffect(Unit) {
        rows = withContext(Dispatchers.IO) { ArixBrowserDownloads.queryRecent(context) }
        loading = false
    }

    PanelHeader(
        chrome = chrome,
        title = "Downloads",
        subtitle = "Files in the Termux workspace downloads folder",
        onBack = onBack,
    )

    Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
        when {
            loading -> CircularProgressIndicator(
                color = chrome.accent,
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(vertical = 42.dp)
                    .size(30.dp),
            )
            rows.isEmpty() -> PanelEmptyState(
                chrome = chrome,
                text = "No downloads yet.\nFiles you download from pages appear here.",
            )
            else -> LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(420.dp),
            ) {
                items(rows) { row ->
                    DownloadRow(chrome = chrome, row = row) {
                        ArixBrowserDownloads.open(context, row)
                    }
                }
            }
        }
    }
}

@Composable
private fun DownloadRow(
    chrome: ArixChromeColors,
    row: ArixBrowserDownloads.DownloadRow,
    onOpen: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen)
            .padding(vertical = 7.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        val statusTint = when {
            row.isComplete -> Color(0xFF81C995)
            row.isFailed -> Color(0xFFF28B82)
            else -> chrome.accent
        }
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(11.dp))
                .background(statusTint.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = if (row.isComplete) Icons.Rounded.OpenInNew else Icons.Rounded.Download,
                contentDescription = null,
                tint = statusTint,
                modifier = Modifier.size(19.dp),
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = row.fileName,
                style = MaterialTheme.typography.bodySmall,
                color = chrome.text,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = buildString {
                    append(row.statusLabel)
                    if (row.totalBytes > 0) {
                        append("  ·  ${formatBytes(row.downloadedBytes)} / ${formatBytes(row.totalBytes)}")
                    }
                },
                style = MaterialTheme.typography.labelSmall,
                color = chrome.textSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

private fun formatBytes(bytes: Long): String = when {
    bytes >= 1_048_576 -> String.format(Locale.US, "%.1f MB", bytes / 1_048_576.0)
    bytes >= 1_024 -> String.format(Locale.US, "%.0f KB", bytes / 1_024.0)
    else -> "$bytes B"
}

private fun copyToClipboard(context: Context, text: String, toast: String) {
    if (text.isBlank()) return
    runCatching {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("arix-browser", text))
        Toast.makeText(context, toast, Toast.LENGTH_SHORT).show()
    }
}
