package com.arix.app.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.view.ViewGroup
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.FullscreenExit
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Replay10
import androidx.compose.material.icons.rounded.Forward10
import androidx.compose.material.icons.rounded.Replay
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.changedToUp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.arix.app.R
import com.arix.app.media.ArixMediaItem
import com.arix.app.media.ArixMediaKind
import com.arix.app.media.ArixPlaybackController
import com.arix.app.media.formatDurationSeconds
import com.arix.app.ui.theme.ArixOnSurface
import com.arix.app.ui.theme.ArixOnSurfaceVariant
import com.arix.app.ui.theme.ArixOutline
import com.arix.app.ui.theme.ArixPrimary
import com.arix.app.ui.theme.ArixSurfaceHigh
import com.arix.app.ui.theme.ArixSurfaceHigher
import com.arix.app.ui.theme.ArixTertiary

private val PlayerAccentGradient = listOf(Color(0xFFC3AFFF), Color(0xFFD1C2FF), Color(0xFF9A7DF8))
private val PlayerScrimGradient = listOf(Color(0xF2060709), Color(0xE60B0D17), Color(0xF2060709))
private val PlayerErrorRed = Color(0xFFE5757A)

private fun Modifier.premiumCardBorder(shape: RoundedCornerShape): Modifier = composed {
    border(
        width = 1.dp,
        brush = Brush.linearGradient(
            colors = listOf(
                ArixPrimary.copy(alpha = 0.22f),
                ArixOutline.copy(alpha = 0.32f),
                ArixTertiary.copy(alpha = 0.18f),
            ),
        ),
        shape = shape,
    )
}

private fun Modifier.playButtonGlow(): Modifier = composed {
    val gradient = Brush.radialGradient(
        colors = listOf(ArixPrimary.copy(alpha = 0.45f), Color.Transparent),
    )
    drawBehind {
        drawCircle(brush = gradient, radius = size.minDimension * 0.9f)
    }
}

@Composable
private fun ArixEqualizerBars(
    playing: Boolean,
    modifier: Modifier = Modifier,
    barColor: Color = ArixPrimary,
    barCount: Int = 4,
) {
    val transition = rememberInfiniteTransition(label = "equalizer")
    val phases = (0 until barCount).map { index ->
        transition.animateFloat(
            initialValue = 0.25f + (index % 3) * 0.12f,
            targetValue = 1f - (index % 2) * 0.25f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 340 + index * 110, easing = LinearEasing),
                repeatMode = RepeatMode.Reverse,
            ),
            label = "eq-$index",
        )
    }
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        phases.forEachIndexed { index, phase ->
            val baseHeightDp = 14f + index * 2f
            val barHeightDp = if (playing) baseHeightDp * phase.value else baseHeightDp * 0.3f
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height(barHeightDp.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(if (playing) barColor else barColor.copy(alpha = 0.4f)),
            )
        }
    }
}

@Composable
private fun ArixBufferRing(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "buffer-ring")
    val sweep by transition.animateFloat(
        initialValue = 30f,
        targetValue = 330f,
        animationSpec = infiniteRepeatable(tween(1200, easing = LinearEasing)),
        label = "sweep",
    )
    Box(
        modifier = modifier.drawBehind {
            drawArc(
                color = ArixPrimary,
                startAngle = -90f,
                sweepAngle = sweep,
                useCenter = false,
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round),
            )
        },
        contentAlignment = Alignment.Center,
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(ArixPrimary),
        )
    }
}

@Composable
internal fun MediaResultsWidget(
    model: ArixMediaResultsModel,
    modifier: Modifier = Modifier,
) {
    val controller = ArixPlaybackController
    val playbackState by controller.state.collectAsState()
    val nowPlayingId = playbackState.nowPlaying?.id
    var listExpanded by remember { mutableStateOf(true) }
    val playingHere = nowPlayingId != null && model.items.any { it.id == nowPlayingId }
    val showResultsList = !playingHere || listExpanded
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        ArixSurfaceHigh,
                        ArixSurfaceHigher.copy(alpha = 0.65f),
                    ),
                ),
            )
            .premiumCardBorder(RoundedCornerShape(22.dp))
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        androidx.compose.animation.AnimatedVisibility(
            visible = showResultsList,
            enter = androidx.compose.animation.expandVertically(
                androidx.compose.animation.core.tween(260)
            ) + androidx.compose.animation.fadeIn(
                androidx.compose.animation.core.tween(200)
            ),
            exit = androidx.compose.animation.shrinkVertically(
                androidx.compose.animation.core.tween(220)
            ) + androidx.compose.animation.fadeOut(
                androidx.compose.animation.core.tween(140)
            ),
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .size(30.dp)
                            .clip(RoundedCornerShape(9.dp))
                            .background(Brush.linearGradient(PlayerAccentGradient)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Headphones,
                            contentDescription = null,
                            tint = Color(0xFF221240),
                            modifier = Modifier.size(16.dp),
                        )
                    }
                    Text(
                        text = stringResource(R.string.media_results_header),
                        style = MaterialTheme.typography.titleSmall,
                        color = ArixOnSurface,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f),
                    )
                    Text(
                        text = stringResource(R.string.media_results_count, model.items.size),
                        style = MaterialTheme.typography.labelMedium,
                        color = ArixOnSurfaceVariant,
                        modifier = Modifier
                            .clip(RoundedCornerShape(999.dp))
                            .background(ArixSurfaceHigher)
                            .padding(horizontal = 9.dp, vertical = 3.dp),
                    )
                    if (model.items.size > 1) {
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(999.dp))
                                .background(Brush.linearGradient(PlayerAccentGradient))
                                .widgetNoRippleClickable { controller.startQueue(model.items, 0) }
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.PlayArrow,
                                contentDescription = null,
                                tint = Color(0xFF221240),
                                modifier = Modifier.size(14.dp),
                            )
                            Text(
                                text = stringResource(R.string.media_play_all),
                                style = MaterialTheme.typography.labelMedium,
                                color = Color(0xFF221240),
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    }
                }
                model.items.forEach { item ->
                    MediaResultCard(
                        item = item,
                        isPlaying = item.id == nowPlayingId,
                        isPaused = item.id == nowPlayingId && !playbackState.isPlaying,
                        onPlay = {
                            listExpanded = false
                            controller.playNow(item, model.items)
                        },
                        onQueue = {
                            val current = controller.state.value.queue
                            controller.startQueue(current + item, current.size.coerceAtLeast(0))
                        },
                    )
                }
            }
        }
        if (nowPlayingId != null && model.items.any { it.id == nowPlayingId }) {
            Spacer(Modifier.height(4.dp))
            ArixNativePlayerCard(
                embedded = true,
                showQueue = false,
                onToggleResultsList = { listExpanded = !listExpanded },
                resultsListExpanded = listExpanded,
                resultsListCount = model.items.size,
            )
        }
    }
}

@Composable
private fun MediaResultCard(
    item: ArixMediaItem,
    isPlaying: Boolean,
    isPaused: Boolean,
    onPlay: () -> Unit,
    onQueue: () -> Unit,
) {
    val artwork = rememberRemoteImage(item.posterUrl)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(
                if (isPlaying) {
                    Brush.linearGradient(
                        listOf(
                            ArixPrimary.copy(alpha = 0.16f),
                            ArixSurfaceHigher.copy(alpha = 0.4f),
                        ),
                    )
                } else {
                    Brush.linearGradient(
                        listOf(ArixSurfaceHigher, ArixSurfaceHigher.copy(alpha = 0.55f)),
                    )
                },
            )
            .then(if (isPlaying) Modifier.border(1.dp, ArixPrimary.copy(alpha = 0.45f), RoundedCornerShape(16.dp)) else Modifier)
            .clickable(onClick = onPlay)
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(11.dp),
    ) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(
                    Brush.linearGradient(
                        listOf(ArixPrimary.copy(alpha = 0.30f), ArixTertiary.copy(alpha = 0.16f)),
                    ),
                ),
            contentAlignment = Alignment.Center,
        ) {
            if (artwork != null) {
                androidx.compose.foundation.Image(
                    bitmap = artwork,
                    contentDescription = item.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                )
            } else {
                Icon(
                    imageVector = when (item.kind) {
                        ArixMediaKind.Music, ArixMediaKind.Audio -> Icons.Rounded.MusicNote
                        ArixMediaKind.Video -> Icons.Rounded.PlayArrow
                        ArixMediaKind.Movie -> Icons.Rounded.Movie
                    },
                    contentDescription = null,
                    tint = ArixOnSurfaceVariant,
                    modifier = Modifier.size(22.dp),
                )
            }
            if (isPlaying) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0x66000000)),
                    contentAlignment = Alignment.Center,
                ) {
                    if (isPaused) {
                        Icon(
                            imageVector = Icons.Rounded.PlayArrow,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp),
                        )
                    } else {
                        ArixEqualizerBars(playing = true, barColor = Color.White)
                    }
                }
            }
        }
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(3.dp),
        ) {
            Text(
                text = item.title,
                style = MaterialTheme.typography.labelLarge,
                color = if (isPlaying) ArixPrimary else ArixOnSurface,
                fontWeight = if (isPlaying) FontWeight.Bold else FontWeight.SemiBold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                val subtitle = listOfNotNull(
                    item.artist.takeIf { it.isNotBlank() },
                    item.sourceName.takeIf { it.isNotBlank() },
                ).joinToString(" • ")
                if (subtitle.isNotBlank()) {
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.labelSmall,
                        color = ArixOnSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false),
                    )
                }
                formatDurationSeconds(item.durationSeconds).takeIf { it.isNotBlank() }?.let { duration ->
                    Text(
                        text = duration,
                        style = MaterialTheme.typography.labelSmall,
                        color = ArixOnSurfaceVariant,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(ArixSurfaceHigh.copy(alpha = 0.8f))
                            .padding(horizontal = 6.dp, vertical = 1.dp),
                    )
                }
            }
        }
        Icon(
            imageVector = Icons.Rounded.Add,
            contentDescription = stringResource(R.string.media_add_to_queue),
            tint = ArixOnSurfaceVariant.copy(alpha = 0.85f),
            modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .widgetNoRippleClickable(onClick = onQueue)
                .padding(4.dp),
        )
        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(
                    if (isPlaying) {
                        Brush.linearGradient(PlayerAccentGradient)
                    } else {
                        Brush.linearGradient(
                            listOf(ArixPrimary.copy(alpha = 0.18f), ArixTertiary.copy(alpha = 0.12f)),
                        )
                    },
                ),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = Icons.Rounded.PlayArrow,
                contentDescription = stringResource(R.string.media_play),
                tint = if (isPlaying) Color(0xFF221240) else ArixPrimary,
                modifier = Modifier.size(20.dp),
            )
        }
    }
}

@Composable
internal fun ArixNativePlayerCard(
    modifier: Modifier = Modifier,
    showQueue: Boolean = true,
    autoExpandVideo: Boolean = true,
    embedded: Boolean = false,
    onToggleResultsList: (() -> Unit)? = null,
    resultsListExpanded: Boolean = false,
    resultsListCount: Int = 0,
) {
    val state by ArixPlaybackController.state.collectAsState()
    val nowPlaying = state.nowPlaying ?: return
    var queueExpanded by remember { mutableStateOf(false) }
    var fullscreenVideo by remember { mutableStateOf(false) }

    if (fullscreenVideo) {
        val activity = LocalContext.current.findArixActivityCompat()
        DisposableEffect(fullscreenVideo, activity) {
            val window = activity?.window
            if (window != null) {
                activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                val controller = androidx.core.view.WindowCompat.getInsetsController(window, window.decorView)
                controller.systemBarsBehavior =
                    androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                controller.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            }
            onDispose {
                activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                window?.let {
                    androidx.core.view.WindowCompat.getInsetsController(it, it.decorView)
                        .show(androidx.core.view.WindowInsetsCompat.Type.systemBars())
                }
            }
        }
        androidx.compose.runtime.key(fullscreenVideo) {
            androidx.compose.ui.window.Dialog(
                onDismissRequest = { fullscreenVideo = false },
                properties = androidx.compose.ui.window.DialogProperties(
                    usePlatformDefaultWidth = false,
                    decorFitsSystemWindows = false,
                    dismissOnBackPress = true,
                ),
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black),
                ) {
                    ArixSharedVideoSurface(
                        modifier = Modifier.fillMaxSize(),
                        onFullscreenToggle = { fullscreenVideo = false },
                        fillBounds = true,
                    )
                }
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .then(
                if (embedded) {
                    Modifier
                        .padding(top = 4.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(ArixSurfaceHigher.copy(alpha = 0.55f))
                } else {
                    Modifier
                        .clip(RoundedCornerShape(22.dp))
                        .background(
                            Brush.verticalGradient(
                                listOf(ArixSurfaceHigh, ArixSurfaceHigher.copy(alpha = 0.6f)),
                            ),
                        )
                        .premiumCardBorder(RoundedCornerShape(22.dp))
                }
            )
            .animateContentSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        if (nowPlaying.isVideo) {
            Box {
                ArixSharedVideoSurface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp)
                        .padding(top = 10.dp),
                    onFullscreenToggle = { fullscreenVideo = true },
                )
            }
        } else {
            AudioNowPlayingHeader(item = nowPlaying, state = state)
        }

        ArixPlaybackControls(
            state = state,
            onToggle = ArixPlaybackController::togglePlayPause,
            onNext = ArixPlaybackController::next,
            onPrevious = ArixPlaybackController::previous,
            onSeek = ArixPlaybackController::seekTo,
            showNext = state.hasNext,
            showPrevious = state.hasPrevious,
        )

        if (onToggleResultsList != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 2.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .widgetNoRippleClickable { onToggleResultsList() }
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Icon(
                    imageVector = Icons.Rounded.QueueMusic,
                    contentDescription = null,
                    tint = ArixOnSurfaceVariant,
                    modifier = Modifier.size(18.dp),
                )
                Text(
                    text = stringResource(R.string.media_results_list_toggle) +
                        " • ${resultsListCount.coerceAtLeast(0)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = ArixOnSurfaceVariant,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.weight(1f),
                )
                Icon(
                    imageVector = if (resultsListExpanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                    contentDescription = null,
                    tint = ArixOnSurfaceVariant,
                    modifier = Modifier.size(20.dp),
                )
            }
        }

        if (showQueue && state.queue.size > 1) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 2.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .widgetNoRippleClickable { queueExpanded = !queueExpanded }
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                ArixEqualizerBars(playing = state.isPlaying, modifier = Modifier.width(18.dp))
                Text(
                    text = stringResource(R.string.media_player_queue) +
                        " • ${state.currentIndex + 1}/${state.queue.size}",
                    style = MaterialTheme.typography.labelMedium,
                    color = ArixOnSurfaceVariant,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.weight(1f),
                )
                Icon(
                    imageVector = if (queueExpanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                    contentDescription = null,
                    tint = ArixOnSurfaceVariant,
                    modifier = Modifier.size(20.dp),
                )
            }
            if (queueExpanded) {
                ArixQueueList(state = state)
            }
        }
    }
}

@Composable
private fun AudioNowPlayingHeader(
    item: ArixMediaItem,
    state: ArixPlaybackController.PlaybackState,
) {
    val artwork = rememberRemoteImage(item.posterUrl)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(13.dp),
    ) {
        Box(
            modifier = Modifier
                .size(68.dp)
                .shadow(10.dp, RoundedCornerShape(16.dp), clip = false)
                .clip(RoundedCornerShape(16.dp))
                .background(
                    Brush.linearGradient(
                        listOf(ArixPrimary.copy(alpha = 0.34f), ArixTertiary.copy(alpha = 0.18f)),
                    ),
                ),
            contentAlignment = Alignment.Center,
        ) {
            if (artwork != null) {
                androidx.compose.foundation.Image(
                    bitmap = artwork,
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                )
            } else {
                Icon(
                    imageVector = Icons.Rounded.Album,
                    contentDescription = null,
                    tint = ArixOnSurfaceVariant,
                    modifier = Modifier.size(30.dp),
                )
            }
            if (state.isBuffering && !state.isPlaying) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0x88000000)),
                    contentAlignment = Alignment.Center,
                ) {
                    ArixBufferRing()
                }
            }
        }
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Text(
                    text = stringResource(R.string.media_now_playing_badge),
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF221240),
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .background(Brush.linearGradient(PlayerAccentGradient))
                        .padding(horizontal = 8.dp, vertical = 2.dp),
                )
                if (state.isPlaying) {
                    ArixEqualizerBars(playing = true)
                }
            }
            Text(
                text = item.title,
                style = MaterialTheme.typography.titleSmall.copy(
                    lineHeight = 18.sp,
                ),
                color = ArixOnSurface,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            val subtitle = item.artist.takeIf { it.isNotBlank() } ?: item.sourceName
            if (subtitle.isNotBlank()) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelMedium,
                    color = ArixOnSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
internal fun ArixSharedVideoSurface(
    modifier: Modifier = Modifier,
    useController: Boolean = true,
    onFullscreenToggle: (() -> Unit)? = null,
    fillBounds: Boolean = false,
) {
    val playbackState by ArixPlaybackController.state.collectAsState()
    AndroidView(
        factory = { viewContext ->
            PlayerView(viewContext).apply {
                this.useController = useController
                setShowSubtitleButton(true)
                setShutterBackgroundColor(android.graphics.Color.BLACK)
                setControllerShowTimeoutMs(3_500)
                keepScreenOn = true
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT,
                )
                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                if (onFullscreenToggle != null) {
                    setFullscreenButtonClickListener { onFullscreenToggle() }
                }
            }
        },
        update = { view ->
            view.player = ArixPlaybackController.player
            view.keepScreenOn = playbackState.isPlaying
        },
        onRelease = { view ->
            view.player = null
        },
        modifier = modifier
            .fillMaxWidth()
            .then(
                if (fillBounds) {
                    Modifier.fillMaxSize()
                } else {
                    Modifier.aspectRatio(playbackState.videoAspectRatio)
                }
            )
            .clip(RoundedCornerShape(16.dp)),
    )
}

@Composable
private fun ArixPremiumProgressBar(
    positionMs: Long,
    durationMs: Long,
    bufferedMs: Long,
    onSeek: (Long) -> Unit,
    modifier: Modifier = Modifier,
) {
    var dragging by remember { mutableStateOf(false) }
    var dragFraction by remember { mutableStateOf(0f) }
    var barWidthPx by remember { mutableStateOf(0) }
    val duration = durationMs.coerceAtLeast(0L)
    val seekable = duration > 0L
    val currentDurationMs by rememberUpdatedState(duration)
    val fraction = when {
        !seekable -> 0f
        dragging -> dragFraction.coerceIn(0f, 1f)
        else -> (positionMs.coerceIn(0L, duration)).toFloat() / duration
    }
    val bufferedFraction = if (seekable) {
        (bufferedMs.coerceIn(0L, duration)).toFloat() / duration
    } else {
        0f
    }
    val thumbScale by animateDpAsState(
        targetValue = if (dragging) 16.dp else 11.dp,
        animationSpec = tween(140),
        label = "thumb-scale",
    )
    val textMeasurer = rememberTextMeasurer()
    val density = LocalDensity.current

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(if (dragging) 44.dp else 32.dp)
            .onSizeChanged { barWidthPx = it.width }
            .pointerInput(seekable) {
                if (!seekable) return@pointerInput
                awaitPointerEventScope {
                    while (true) {
                        val down = awaitPointerEvent()
                        val x = down.changes.firstOrNull()?.position?.x ?: continue
                        dragging = true
                        dragFraction = (x / (barWidthPx.coerceAtLeast(1))).coerceIn(0f, 1f)
                        down.changes.forEach { it.consume() }
                        while (true) {
                            val event = awaitPointerEvent()
                            val dragX = event.changes.firstOrNull()?.position?.x ?: break
                            if (event.changes.any { it.changedToUp() }) {
                                val liveDuration = currentDurationMs
                                onSeek((dragFraction * liveDuration).toLong().coerceIn(0L, liveDuration))
                                dragging = false
                                break
                            }
                            dragFraction = (dragX / (barWidthPx.coerceAtLeast(1))).coerceIn(0f, 1f)
                            event.changes.forEach { it.consume() }
                        }
                    }
                }
            },
        contentAlignment = Alignment.CenterStart,
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(999.dp))
                .background(ArixOutline.copy(alpha = 0.30f)),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(bufferedFraction.coerceIn(0f, 1f))
                    .height(6.dp)
                    .clip(RoundedCornerShape(999.dp))
                    .background(ArixOnSurfaceVariant.copy(alpha = 0.18f)),
            )
            Box(
                modifier = Modifier
                    .fillMaxWidth(fraction.coerceIn(0f, 1f))
                    .height(6.dp)
                    .clip(RoundedCornerShape(999.dp))
                    .background(Brush.linearGradient(PlayerAccentGradient)),
            )
        }
        Box(
            modifier = Modifier
                .offset(x = with(density) {
                    ((fraction.coerceIn(0f, 1f)) * barWidthPx).toInt().toDp() - thumbScale / 2
                })
                .size(thumbScale)
                .clip(CircleShape)
                .background(Brush.linearGradient(PlayerAccentGradient))
                .border(2.dp, Color.White, CircleShape)
                .then(
                    if (dragging) {
                        Modifier.drawBehind {
                            drawCircle(
                                brush = Brush.radialGradient(
                                    colors = listOf(
                                        ArixPrimary.copy(alpha = 0.35f),
                                        Color.Transparent,
                                    ),
                                ),
                                radius = size.minDimension * 1.6f,
                            )
                        }
                    } else {
                        Modifier
                    }
                ),
        )
        if (dragging) {
            val scrubSeconds = ((dragFraction.coerceIn(0f, 1f)) * duration / 1000f).toLong()
            val scrubLabel = formatDurationSeconds(scrubSeconds)
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .drawBehind {
                        val textResult = textMeasurer.measure(
                            text = scrubLabel,
                            style = TextStyle(
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                            ),
                        )
                        val bubbleX = (fraction.coerceIn(0f, 1f) * size.width)
                            .coerceIn(
                                textResult.size.width / 2f + 4f,
                                size.width - textResult.size.width / 2f - 4f,
                            )
                        val bubbleTop = size.height * 0.02f
                        val corner = 7.dp.toPx()
                        drawRoundRect(
                            color = Color(0xE6141B2E),
                            topLeft = Offset(
                                bubbleX - textResult.size.width / 2f - 6.dp.toPx(),
                                bubbleTop,
                            ),
                            size = Size(
                                textResult.size.width + 12.dp.toPx(),
                                textResult.size.height + 7.dp.toPx(),
                            ),
                            cornerRadius = CornerRadius(corner, corner),
                        )
                        drawRoundRect(
                            color = Color.White.copy(alpha = 0.22f),
                            topLeft = Offset(
                                bubbleX - textResult.size.width / 2f - 6.dp.toPx(),
                                bubbleTop,
                            ),
                            size = Size(
                                textResult.size.width + 12.dp.toPx(),
                                textResult.size.height + 7.dp.toPx(),
                            ),
                            cornerRadius = CornerRadius(corner, corner),
                            style = Stroke(width = 1.dp.toPx()),
                        )
                        drawText(
                            textLayoutResult = textResult,
                            topLeft = Offset(
                                bubbleX - textResult.size.width / 2f,
                                bubbleTop + 3.5.dp.toPx(),
                            ),
                        )
                    },
            )
        }
    }
}

@Composable
internal fun ArixPlaybackControls(
    state: ArixPlaybackController.PlaybackState,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSeek: (Long) -> Unit,
    showNext: Boolean = true,
    showPrevious: Boolean = true,
) {
    val durationMs = state.durationMs.coerceAtLeast(0L)
    val positionMs = state.positionMs.coerceIn(0L, durationMs)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        ArixPremiumProgressBar(
            positionMs = positionMs,
            durationMs = durationMs,
            bufferedMs = state.bufferedMs,
            onSeek = onSeek,
        )
        if (durationMs > 0L) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    text = formatDurationSeconds(positionMs / 1000L),
                    style = MaterialTheme.typography.labelSmall,
                    color = ArixOnSurfaceVariant,
                    fontWeight = FontWeight.Medium,
                )
                Text(
                    text = formatDurationSeconds(durationMs / 1000L),
                    style = MaterialTheme.typography.labelSmall,
                    color = ArixOnSurfaceVariant,
                )
            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.Start,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (showPrevious) {
                    ArixTransportIconButton(
                        icon = Icons.Rounded.SkipPrevious,
                        contentDescription = stringResource(R.string.media_player_previous),
                        onClick = onPrevious,
                        enabled = state.hasPrevious,
                        iconSize = 26.dp,
                    )
                }
                if (durationMs > 0L) {
                    ArixTransportIconButton(
                        icon = Icons.Rounded.Replay10,
                        contentDescription = stringResource(R.string.media_seek_back),
                        onClick = { ArixPlaybackController.seekBy(-10_000L) },
                        iconSize = 22.dp,
                        tint = ArixOnSurfaceVariant,
                    )
                }
            }
            ArixPlayOrbButton(
                playing = state.isPlaying,
                buffering = state.isBuffering && !state.isPlaying,
                onClick = onToggle,
            )
            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (durationMs > 0L) {
                    ArixTransportIconButton(
                        icon = Icons.Rounded.Forward10,
                        contentDescription = stringResource(R.string.media_seek_forward),
                        onClick = { ArixPlaybackController.seekBy(10_000L) },
                        iconSize = 22.dp,
                        tint = ArixOnSurfaceVariant,
                    )
                }
                if (showNext) {
                    ArixTransportIconButton(
                        icon = Icons.Rounded.SkipNext,
                        contentDescription = stringResource(R.string.media_player_next),
                        onClick = onNext,
                        enabled = state.hasNext,
                        iconSize = 26.dp,
                    )
                }
            }
        }
        state.statusMessage?.let { status ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp),
                horizontalArrangement = Arrangement.Center,
            ) {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .background(ArixPrimary.copy(alpha = 0.14f))
                        .border(1.dp, ArixPrimary.copy(alpha = 0.35f), RoundedCornerShape(999.dp))
                        .padding(horizontal = 12.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(7.dp),
                ) {
                    CircularProgressIndicator(
                        strokeWidth = 2.dp,
                        color = ArixPrimary,
                        modifier = Modifier.size(12.dp),
                    )
                    Text(
                        text = status,
                        style = MaterialTheme.typography.labelSmall,
                        color = ArixPrimary,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
            }
        }
        state.errorMessage?.let { message ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(PlayerErrorRed.copy(alpha = 0.12f))
                    .border(1.dp, PlayerErrorRed.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 12.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(9.dp),
            ) {
                Icon(
                    imageVector = Icons.Rounded.GraphicEq,
                    contentDescription = null,
                    tint = PlayerErrorRed,
                    modifier = Modifier.size(16.dp),
                )
                Text(
                    text = message,
                    style = MaterialTheme.typography.labelSmall,
                    color = PlayerErrorRed,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                Icon(
                    imageVector = Icons.Rounded.Replay,
                    contentDescription = stringResource(R.string.media_player_retry),
                    tint = PlayerErrorRed,
                    modifier = Modifier
                        .size(22.dp)
                        .clip(CircleShape)
                        .widgetNoRippleClickable {
                            ArixPlaybackController.playAt(
                                ArixPlaybackController.state.value.currentIndex,
                            )
                        }
                        .padding(3.dp),
                )
                if (state.hasNext) {
                    Icon(
                        imageVector = Icons.Rounded.SkipNext,
                        contentDescription = stringResource(R.string.media_player_skip_next_error),
                        tint = PlayerErrorRed,
                        modifier = Modifier
                            .size(22.dp)
                            .clip(CircleShape)
                            .widgetNoRippleClickable(onClick = onNext)
                            .padding(3.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun ArixTransportIconButton(
    icon: ImageVector,
    contentDescription: String?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    iconSize: Dp = 24.dp,
    boxSize: Dp = 46.dp,
    tint: Color = ArixOnSurface,
    enabled: Boolean = true,
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.86f else 1f,
        animationSpec = spring(dampingRatio = 0.7f, stiffness = 900f),
        label = "transport_press",
    )
    Box(
        modifier = modifier
            .size(boxSize)
            .graphicsLayerScale(scale)
            .clip(CircleShape)
            .background(if (pressed) ArixPrimary.copy(alpha = 0.10f) else Color.Transparent)
            .clickable(
                interactionSource = interaction,
                indication = null,
                enabled = enabled,
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = if (enabled) tint else tint.copy(alpha = 0.35f),
            modifier = Modifier.size(iconSize),
        )
    }
}

private fun Modifier.graphicsLayerScale(scale: Float): Modifier =
    this.graphicsLayer(
        scaleX = scale,
        scaleY = scale,
    )

@Composable
private fun ArixPlayOrbButton(
    playing: Boolean,
    buffering: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.92f else 1f,
        animationSpec = spring(dampingRatio = 0.65f, stiffness = 700f),
        label = "play_press",
    )
    Box(
        modifier = modifier
            .size(62.dp)
            .playButtonGlow()
            .graphicsLayerScale(scale)
            .clip(CircleShape)
            .background(Brush.linearGradient(PlayerAccentGradient))
            .border(1.5.dp, Color.White.copy(alpha = 0.35f), CircleShape)
            .clickable(
                interactionSource = interaction,
                indication = null,
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        if (buffering) {
            CircularProgressIndicator(
                color = Color(0xFF221240),
                strokeWidth = 2.5.dp,
                modifier = Modifier.size(26.dp),
            )
        } else {
            AnimatedContent(
                targetState = playing,
                transitionSpec = {
                    (scaleIn(
                        initialScale = 0.55f,
                        animationSpec = spring(dampingRatio = 0.6f, stiffness = 500f),
                    ) + fadeIn(tween(120))) togetherWith
                        (scaleOut(targetScale = 0.55f, animationSpec = tween(110)) + fadeOut(tween(110)))
                },
                label = "play_pause_morph",
            ) { isPlaying ->
                Icon(
                    imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = if (isPlaying) {
                        stringResource(R.string.media_player_pause)
                    } else {
                        stringResource(R.string.media_player_play)
                    },
                    tint = Color(0xFF221240),
                    modifier = Modifier.size(34.dp),
                )
            }
        }
    }
}

@Composable
private fun ArixQueueList(state: ArixPlaybackController.PlaybackState) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp)
            .heightIn(max = 320.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        state.queue.forEachIndexed { index, item ->
            val isCurrent = index == state.currentIndex
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        if (isCurrent) {
                            Brush.linearGradient(
                                listOf(
                                    ArixPrimary.copy(alpha = 0.16f),
                                    ArixPrimary.copy(alpha = 0.05f),
                                ),
                            )
                        } else {
                            Brush.linearGradient(
                                listOf(ArixSurfaceHigher, ArixSurfaceHigher.copy(alpha = 0.5f)),
                            )
                        },
                    )
                    .then(
                        if (isCurrent) {
                            Modifier.border(1.dp, ArixPrimary.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                        } else {
                            Modifier
                        },
                    )
                    .widgetNoRippleClickable { ArixPlaybackController.playAt(index) }
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(9.dp),
            ) {
                if (isCurrent) {
                    ArixEqualizerBars(playing = state.isPlaying, modifier = Modifier.width(18.dp))
                } else {
                    Icon(
                        imageVector = when (item.kind) {
                            ArixMediaKind.Music, ArixMediaKind.Audio -> Icons.Rounded.MusicNote
                            ArixMediaKind.Video -> Icons.Rounded.PlayArrow
                            ArixMediaKind.Movie -> Icons.Rounded.Movie
                        },
                        contentDescription = null,
                        tint = ArixOnSurfaceVariant,
                        modifier = Modifier.size(16.dp),
                    )
                }
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.labelMedium,
                    color = if (isCurrent) ArixPrimary else ArixOnSurface,
                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    text = formatDurationSeconds(item.durationSeconds),
                    style = MaterialTheme.typography.labelSmall,
                    color = ArixOnSurfaceVariant,
                )
                if (!isCurrent) {
                    Icon(
                        imageVector = Icons.Rounded.Close,
                        contentDescription = null,
                        tint = ArixOnSurfaceVariant.copy(alpha = 0.7f),
                        modifier = Modifier
                            .size(17.dp)
                            .clip(CircleShape)
                            .widgetNoRippleClickable { ArixPlaybackController.removeFromQueue(index) }
                            .padding(2.dp),
                    )
                }
            }
        }
    }
}

@Composable
internal fun ArixMiniPlayer(
    modifier: Modifier = Modifier,
    onExpand: () -> Unit,
) {
    val state by ArixPlaybackController.state.collectAsState()
    if (!state.hasMedia) return
    val nowPlaying = state.nowPlaying ?: return
    val artwork = rememberRemoteImage(nowPlaying.posterUrl)
    val durationMs = state.durationMs.coerceAtLeast(0L)
    val progressFraction = if (durationMs > 0L) {
        (state.positionMs.coerceIn(0L, durationMs)).toFloat() / durationMs
    } else {
        0f
    }

    androidx.compose.material3.Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp)
            .shadow(14.dp, RoundedCornerShape(18.dp), clip = false),
        shape = RoundedCornerShape(18.dp),
        color = ArixSurfaceHigher,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            Brush.linearGradient(
                listOf(ArixPrimary.copy(alpha = 0.35f), ArixOutline.copy(alpha = 0.25f)),
            ),
        ),
    ) {
        Column {
            if (durationMs > 0L) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 22.dp)
                        .height(2.5.dp)
                        .clip(RoundedCornerShape(999.dp))
                        .background(ArixOutline.copy(alpha = 0.25f)),
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(progressFraction.coerceIn(0.002f, 1f))
                            .height(2.5.dp)
                            .clip(RoundedCornerShape(999.dp))
                            .background(Brush.linearGradient(PlayerAccentGradient)),
                    )
                }
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .widgetNoRippleClickable(onClick = onExpand),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(11.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(
                                        ArixPrimary.copy(alpha = 0.32f),
                                        ArixTertiary.copy(alpha = 0.16f),
                                    ),
                                ),
                            ),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (artwork != null) {
                            androidx.compose.foundation.Image(
                                bitmap = artwork,
                                contentDescription = null,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop,
                            )
                        } else {
                            Icon(
                                imageVector = if (nowPlaying.isVideo) {
                                    Icons.Rounded.Movie
                                } else {
                                    Icons.Rounded.MusicNote
                                },
                                contentDescription = null,
                                tint = ArixOnSurfaceVariant,
                                modifier = Modifier.size(19.dp),
                            )
                        }
                        if (state.isBuffering && !state.isPlaying) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color(0x88000000)),
                                contentAlignment = Alignment.Center,
                            ) {
                                CircularProgressIndicator(
                                    strokeWidth = 2.dp,
                                    color = Color.White,
                                    modifier = Modifier.size(16.dp),
                                )
                            }
                        }
                    }
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(2.dp),
                    ) {
                        Text(
                            text = nowPlaying.title,
                            style = MaterialTheme.typography.labelLarge,
                            color = ArixOnSurface,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            if (state.isPlaying) {
                                ArixEqualizerBars(playing = true, modifier = Modifier.width(16.dp))
                            }
                            Text(
                                text = nowPlaying.artist.takeIf { it.isNotBlank() }
                                    ?: nowPlaying.sourceName,
                                style = MaterialTheme.typography.labelSmall,
                                color = ArixOnSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(PlayerAccentGradient))
                        .widgetNoRippleClickable(onClick = ArixPlaybackController::togglePlayPause),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = if (state.isPlaying) {
                            stringResource(R.string.media_player_pause)
                        } else {
                            stringResource(R.string.media_player_play)
                        },
                        tint = Color(0xFF221240),
                        modifier = Modifier.size(22.dp),
                    )
                }
                if (state.hasNext) {
                    Icon(
                        imageVector = Icons.Rounded.SkipNext,
                        contentDescription = stringResource(R.string.media_player_next),
                        tint = ArixOnSurface,
                        modifier = Modifier
                            .size(30.dp)
                            .clip(CircleShape)
                            .widgetNoRippleClickable(onClick = ArixPlaybackController::next)
                            .padding(4.dp),
                    )
                }
                Icon(
                    imageVector = Icons.Rounded.Close,
                    contentDescription = stringResource(R.string.media_mini_player_close),
                    tint = ArixOnSurfaceVariant,
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .widgetNoRippleClickable(onClick = ArixPlaybackController::stop)
                        .padding(4.dp),
                )
            }
        }
    }
}

@Composable
internal fun ArixPlayerSheet(
    onDismiss: () -> Unit,
) {
    val state by ArixPlaybackController.state.collectAsState()
    LaunchedEffect(state.nowPlaying) {
        if (state.nowPlaying == null) onDismiss()
    }
    val nowPlaying = state.nowPlaying ?: return
    var fullscreenVideo by remember { mutableStateOf(false) }
    val activity = LocalContext.current.findArixActivityCompat()

    DisposableEffect(fullscreenVideo, activity) {
        val window = activity?.window
        if (fullscreenVideo && window != null) {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            val controller = androidx.core.view.WindowCompat.getInsetsController(window, window.decorView)
            controller.systemBarsBehavior =
                androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            onDispose {
                activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                controller.show(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            }
        } else {
            onDispose { }
        }
    }

    androidx.compose.runtime.key(fullscreenVideo) {
        androidx.compose.ui.window.Dialog(
            onDismissRequest = onDismiss,
            properties = androidx.compose.ui.window.DialogProperties(
                usePlatformDefaultWidth = !fullscreenVideo,
                decorFitsSystemWindows = false,
                dismissOnBackPress = true,
            ),
        ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xF2060709)),
        ) {
            if (!fullscreenVideo) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Brush.verticalGradient(PlayerScrimGradient)),
                )
            }
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.safeDrawing),
            ) {
                val isWide = maxWidth > 640.dp
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .then(
                            if (fullscreenVideo) {
                                Modifier
                            } else {
                                Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                            },
                        ),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    if (!fullscreenVideo) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(42.dp)
                                    .height(4.dp)
                                    .clip(RoundedCornerShape(999.dp))
                                    .background(Color.White.copy(alpha = 0.22f)),
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(30.dp)
                                        .clip(RoundedCornerShape(9.dp))
                                        .background(Brush.linearGradient(PlayerAccentGradient)),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.GraphicEq,
                                        contentDescription = null,
                                        tint = Color(0xFF221240),
                                        modifier = Modifier.size(16.dp),
                                    )
                                }
                                Text(
                                    text = stringResource(R.string.media_queue_now_playing),
                                    style = MaterialTheme.typography.labelLarge,
                                    color = Color.White.copy(alpha = 0.85f),
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.weight(1f),
                                )
                                Icon(
                                    imageVector = Icons.Rounded.Close,
                                    contentDescription = stringResource(R.string.media_player_close),
                                    tint = Color.White,
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .widgetNoRippleClickable(onClick = onDismiss)
                                        .padding(4.dp),
                                )
                            }
                        }
                    }
                    if (fullscreenVideo) {
                        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                            ArixSharedVideoSurface(
                                modifier = Modifier.fillMaxSize(),
                                onFullscreenToggle = { fullscreenVideo = !fullscreenVideo },
                                fillBounds = true,
                            )
                        }
                    } else if (isWide) {
                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(22.dp),
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight(0.42f)
                                    .fillMaxHeight(),
                                contentAlignment = Alignment.Center,
                            ) {
                                PlayerSheetMedia(
                                    nowPlaying = nowPlaying,
                                    isVideo = nowPlaying.isVideo,
                                    onFullscreenToggle = { fullscreenVideo = true },
                                    matchHeightFirst = true,
                                    buffering = state.isBuffering && !state.isPlaying,
                                )
                            }
                            Column(
                                modifier = Modifier
                                    .weight(0.58f)
                                    .fillMaxHeight()
                                    .verticalScroll(rememberScrollState()),
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                PlayerSheetMediaInfo(nowPlaying = nowPlaying, state = state)
                                ArixPlaybackControls(
                                    state = state,
                                    onToggle = ArixPlaybackController::togglePlayPause,
                                    onNext = ArixPlaybackController::next,
                                    onPrevious = ArixPlaybackController::previous,
                                    onSeek = ArixPlaybackController::seekTo,
                                )
                                if (state.queue.size > 1) {
                                    PlayerSheetQueueHeader(state = state)
                                    ArixQueueList(state = state)
                                }
                            }
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                            contentAlignment = Alignment.Center,
                        ) {
                            PlayerSheetMedia(
                                nowPlaying = nowPlaying,
                                isVideo = nowPlaying.isVideo,
                                onFullscreenToggle = { fullscreenVideo = true },
                                matchHeightFirst = true,
                                buffering = state.isBuffering && !state.isPlaying,
                            )
                        }
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            PlayerSheetMediaInfo(nowPlaying = nowPlaying, state = state)
                            ArixPlaybackControls(
                                state = state,
                                onToggle = ArixPlaybackController::togglePlayPause,
                                onNext = ArixPlaybackController::next,
                                onPrevious = ArixPlaybackController::previous,
                                onSeek = ArixPlaybackController::seekTo,
                            )
                            if (state.queue.size > 1) {
                                PlayerSheetQueueHeader(state = state)
                                ArixQueueList(state = state)
                            }
                        }
                    }
                }
            }
            if (fullscreenVideo) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(14.dp)
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(Color(0x66000000))
                        .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape)
                        .widgetNoRippleClickable { fullscreenVideo = false },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = Icons.Rounded.FullscreenExit,
                        contentDescription = stringResource(R.string.media_player_exit_fullscreen),
                        tint = Color.White,
                        modifier = Modifier.size(20.dp),
                    )
                }
            }
        }
        }
    }
}

@Composable
private fun PlayerSheetMedia(
    nowPlaying: ArixMediaItem,
    isVideo: Boolean,
    onFullscreenToggle: () -> Unit,
    matchHeightFirst: Boolean,
    buffering: Boolean = false,
) {
    if (isVideo) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(18.dp))
                .background(Color.Black),
        ) {
            ArixSharedVideoSurface(
                modifier = Modifier.fillMaxSize(),
                onFullscreenToggle = onFullscreenToggle,
                fillBounds = true,
            )
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(10.dp)
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(Color(0x66000000))
                    .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape)
                    .widgetNoRippleClickable(onClick = onFullscreenToggle),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = Icons.Rounded.Fullscreen,
                    contentDescription = stringResource(R.string.media_player_fullscreen),
                    tint = Color.White,
                    modifier = Modifier.size(18.dp),
                )
            }
        }
    } else {
        val artwork = rememberRemoteImage(nowPlaying.posterUrl)
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center,
        ) {
            Box(
                modifier = Modifier
                    .aspectRatio(1f, matchHeightConstraintsFirst = matchHeightFirst)
                    .fillMaxSize()
                    .shadow(24.dp, RoundedCornerShape(28.dp), clip = false)
                    .clip(RoundedCornerShape(28.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(
                                ArixPrimary.copy(alpha = 0.30f),
                                ArixTertiary.copy(alpha = 0.14f),
                            ),
                        ),
                    )
                    .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(28.dp)),
                contentAlignment = Alignment.Center,
            ) {
                if (artwork != null) {
                    androidx.compose.foundation.Image(
                        bitmap = artwork,
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop,
                    )
                } else {
                    Icon(
                        imageVector = Icons.Rounded.Album,
                        contentDescription = null,
                        tint = Color.White.copy(alpha = 0.5f),
                        modifier = Modifier.size(84.dp),
                    )
                }
                if (buffering) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color(0x66000000)),
                        contentAlignment = Alignment.Center,
                    ) {
                        ArixBufferRing()
                    }
                }
            }
        }
    }
}

@Composable
private fun PlayerSheetMediaInfo(
    nowPlaying: ArixMediaItem,
    state: ArixPlaybackController.PlaybackState,
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (state.isPlaying) {
                ArixEqualizerBars(playing = true, barColor = Color(0xFFD1C2FF))
            }
            Text(
                text = nowPlaying.title,
                style = MaterialTheme.typography.titleLarge,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
        }
        Text(
            text = nowPlaying.artist.takeIf { it.isNotBlank() }
                ?: nowPlaying.sourceName,
            style = MaterialTheme.typography.bodyMedium,
            color = Color.White.copy(alpha = 0.7f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun PlayerSheetQueueHeader(state: ArixPlaybackController.PlaybackState) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(
            text = stringResource(R.string.media_queue_title),
            style = MaterialTheme.typography.labelLarge,
            color = Color.White.copy(alpha = 0.85f),
            fontWeight = FontWeight.SemiBold,
        )
        Text(
            text = "${state.currentIndex + 1}/${state.queue.size}",
            style = MaterialTheme.typography.labelMedium,
            color = Color.White.copy(alpha = 0.55f),
        )
    }
}

private fun Modifier.widgetNoRippleClickable(onClick: () -> Unit): Modifier =
    composed {
        clickable(
            enabled = true,
            indication = null,
            interactionSource = remember {
                MutableInteractionSource()
            },
            onClick = onClick,
        )
    }

private tailrec fun Context.findArixActivityCompat(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findArixActivityCompat()
    else -> null
}
