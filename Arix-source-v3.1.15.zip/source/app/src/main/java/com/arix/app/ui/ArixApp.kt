package com.arix.app.ui

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ContextWrapper
import android.content.Intent
import android.content.Context
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import android.util.Patterns
import android.widget.Toast
import androidx.activity.compose.BackHandler
import com.arix.app.ArixLocaleManager
import com.arix.app.R
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.arix.app.ArixApplication
import com.arix.app.data.ArixPrivacyPolicyUrl
import com.arix.app.data.ArixWebsiteUrl
import com.arix.app.data.AppLanguage
import com.arix.app.data.AutomaticModelPurpose
import com.arix.app.data.ProviderModelOption
import com.arix.app.data.availableModelOptions
import com.arix.app.data.resolveAutomaticModelKey
import com.arix.app.platform.LocalReduceMotion
import com.arix.app.runtime.AndroidTermuxFileManagerRuntime
import com.arix.app.voice.ArixSpeechRecognitionController
import com.arix.app.ui.theme.ArixBackground
import com.arix.app.ui.theme.ArixOnSurface
import com.arix.app.ui.theme.ArixOnSurfaceVariant
import com.arix.app.ui.theme.ArixPrimary
import com.arix.app.ui.theme.ArixScrim
import com.arix.app.ui.theme.ArixSurface
import com.arix.app.ui.theme.ArixSurfaceHigher
import com.arix.app.ui.theme.ArixTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

private sealed interface PendingSaveTarget {
    data class Attachment(val attachment: ChatAttachment) : PendingSaveTarget
    data class WorkspaceFile(val rawLink: String) : PendingSaveTarget
}

private const val ScreenTransitionDuration = 320
private val ScreenTransitionEasing = CubicBezierEasing(0.22f, 0.84f, 0.18f, 1f)
private const val PrivacyPolicyAnnotationTag = "privacy_policy"

private fun AppScreen.depth(): Int = when (this) {
    AppScreen.Welcome -> 0
    AppScreen.Chat -> 1
    AppScreen.Terminal -> 1
    AppScreen.Browser -> 2
    AppScreen.Files -> 1
    AppScreen.Settings -> 2
}

private val AppScreen.isMainTab: Boolean
    get() = this == AppScreen.Chat ||
        this == AppScreen.Terminal || this == AppScreen.Files

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun ArixApp(
    viewModel: ArixViewModel = rememberSharedArixViewModel(),
    onNotificationPermissionRequested: () -> Unit = {},
) {
    val uiState = viewModel.uiState.collectAsStateWithLifecycle().value
    val context = LocalContext.current
    val applicationLanguage = ArixLocaleManager.currentApplicationLanguage()
    val effectiveLanguage = applicationLanguage ?: uiState.settings.language
    val appRuntime = remember(context) {
        (context.applicationContext as ArixApplication).runtime
    }

    // v3.1.14 — Arix Script Extensions: start the runtime bridge loop,
    // expose the snapshot to the whole UI tree, surface notifications and
    // answer interactive extension prompts.
    val extensionManager = appRuntime.appExtensionManager
    val extensionState = extensionManager.state.collectAsStateWithLifecycle().value
    val extensionNotification = remember { mutableStateOf<String?>(null) }
    LaunchedEffect(extensionManager) {
        extensionManager.start()
    }
    LaunchedEffect(extensionManager) {
        extensionManager.notifications.collect { notification ->
            extensionNotification.value = notification.message
        }
    }
    LaunchedEffect(extensionNotification.value) {
        val message = extensionNotification.value ?: return@LaunchedEffect
        kotlinx.coroutines.delay(3200L)
        if (extensionNotification.value == message) extensionNotification.value = null
    }
    val extensionUiRequest = extensionManager.uiRequest.collectAsStateWithLifecycle().value
    val extensionScope = rememberCoroutineScope()
    val extensionController = remember(extensionState, extensionManager) {
        ArixExtensionUiController(
            snapshot = extensionState.snapshot,
            runtimeError = extensionState.error,
            onHostCall = { method, args ->
                org.json.JSONObject().put("error", "The Arix host does not expose '$method'.")
            },
            onAction = { extensionId, action, args ->
                extensionManager.invokeAction(extensionId, action, args)
            },
        )
    }

    LaunchedEffect(uiState.settings.language, applicationLanguage) {
        if (applicationLanguage == null) {
            ArixLocaleManager.applyIfChanged(uiState.settings.language)
        } else if (applicationLanguage != uiState.settings.language) {
            viewModel.updateAppLanguage(applicationLanguage)
        }
    }

    ArixAgentRunKeepAwake(
        running = uiState.sessionExecutionStates.values.any { it.isRunning },
    )

    LaunchedEffect(uiState.currentScreen) {
        if (uiState.currentScreen == AppScreen.Settings) {
            viewModel.refreshUsageStatisticsSnapshots()
        }
    }

    ArixTheme(
        themeMode = uiState.settings.themeMode,
        language = effectiveLanguage,
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background,
        ) {
            CompositionLocalProvider(LocalArixExtensionUiController provides extensionController) {
                Box(modifier = Modifier.fillMaxSize()) {
                    ArixAppContent(
                        viewModel = viewModel,
                        uiState = uiState,
                        language = effectiveLanguage,
                        onNotificationPermissionRequested = onNotificationPermissionRequested,
                    )

                    // Extension notification toast.
                    extensionNotification.value?.let { message ->
                        androidx.compose.animation.AnimatedVisibility(
                            visible = true,
                            modifier = Modifier.align(Alignment.TopCenter),
                            enter = androidx.compose.animation.fadeIn(),
                            exit = androidx.compose.animation.fadeOut(),
                        ) {
                            Surface(
                                color = ArixSurfaceHigher,
                                shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .statusBarsPadding()
                                    .padding(top = 8.dp)
                                    .fillMaxWidth(0.9f),
                            ) {
                                Text(
                                    text = message,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = ArixOnSurface,
                                    maxLines = 3,
                                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                )
                            }
                        }
                    }

                    // Overlay surfaces pinned above the whole app.
                    ArixExtensionOverlaySlot(modifier = Modifier.fillMaxSize())
                }
            }
        }
    }

    // Interactive extension prompts (select / confirm / input).
    extensionUiRequest?.let { request ->
        ArixExtensionUiRequestDialog(
            request = request,
            onRespond = { value ->
                extensionManager.respondToExtensionUiRequest(request.callId, value)
            },
        )
    }
}

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
private fun ArixAppContent(
    viewModel: ArixViewModel,
    uiState: ArixUiState,
    language: AppLanguage,
    onNotificationPermissionRequested: () -> Unit,
) {
    val reduceMotion = LocalReduceMotion.current
    val drawerState = rememberDrawerState(initialValue = androidx.compose.material3.DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    val clipboardManager = LocalClipboardManager.current
    val appRuntime = remember(context) {
        (context.applicationContext as ArixApplication).runtime
    }
    val workspaceFileBridge = appRuntime.workspaceFileBridge
    val termuxFileManagerRuntime = remember(appRuntime.termuxRuntime) {
        AndroidTermuxFileManagerRuntime(appRuntime.termuxRuntime)
    }
    val runtimeWorkspaceFileBridge = appRuntime.runtimeWorkspaceFileBridge
    val activeSession = uiState.sessions.firstOrNull { it.id == uiState.currentSessionId }
    val currentSessionExecution = uiState.sessionExecutionStates[uiState.currentSessionId]
    val activeStreamingResponseGroupId = currentSessionExecution
        ?.takeIf { it.isRunning }
        ?.activeResponseGroupId
    val sessionMessages = activeSession?.messages.orEmpty()
    val currentMessages = remember(sessionMessages, activeStreamingResponseGroupId) {
        if (activeStreamingResponseGroupId == null) {
            sessionMessages
        } else {
            sessionMessages.filterNot { message ->
                message.isIncomplete && message.responseGroupId == activeStreamingResponseGroupId
            }
        }
    }
    val selectedSkillIds = activeSession?.selectedSkillIds ?: uiState.draftSelectedSkillIds
    val conversationModelOptions = remember(uiState.providerConfigs) {
        uiState.providerConfigs.availableModelOptions()
    }
    val selectedConversationModelKey = remember(
        activeSession?.selectedModelKey,
        uiState.draftSelectedModelKey,
        uiState.settings.defaultChatModelKey,
        conversationModelOptions,
    ) {
        resolveConversationModelKey(
            session = activeSession,
            draftSelectedModelKey = uiState.draftSelectedModelKey,
            defaultChatModelKey = uiState.settings.defaultChatModelKey,
            options = conversationModelOptions,
        )
    }
    val pendingToolInvocations = currentSessionExecution?.pendingToolInvocations.orEmpty()
    val pendingResponseBlocks = currentSessionExecution?.pendingResponseBlocks.orEmpty()
    val pendingAssistantText = currentSessionExecution?.pendingAssistantText.orEmpty()
    val pendingInputs = currentSessionExecution?.pendingInputs.orEmpty()
    val isCurrentSessionRunning = currentSessionExecution?.isRunning == true
    val canContinueCheckpoint = remember(
        uiState.currentSessionId,
        currentMessages,
        isCurrentSessionRunning,
    ) {
        !isCurrentSessionRunning && viewModel.canContinueCurrentSession()
    }
    val currentRuntimeWorkspaceDirectory = appRuntime.runtimeRouter.runtimeWorkspaceDirectory(
        settings = uiState.settings,
    )

    LaunchedEffect(viewModel, context) {
        viewModel.transientMessages.collectLatest { message ->
            Toast.makeText(context, message.resolve(context), Toast.LENGTH_SHORT).show()
        }
    }

    LaunchedEffect(uiState.settings.privacyPolicyAccepted) {
        if (uiState.settings.privacyPolicyAccepted) {
            onNotificationPermissionRequested()
        }
    }

    var pendingSaveTarget by remember { mutableStateOf<PendingSaveTarget?>(null) }
    var pendingSessionExportId by remember { mutableStateOf<String?>(null) }
    var pendingSkillZipCompletion by remember { mutableStateOf<((Boolean) -> Unit)?>(null) }
    var showAppDataExportWarning by remember { mutableStateOf(false) }
    val onPickedDocuments: (List<Uri>) -> Unit = { uris ->
        uris.forEach { uri ->
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION,
                )
            }
        }
        viewModel.appendDraftAttachments(uris)
    }
    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(),
        onResult = onPickedDocuments,
    )
    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents(),
        onResult = onPickedDocuments,
    )
    var voiceListeningActive by remember { mutableStateOf(false) }
    var showVoicePermissionExplainer by remember { mutableStateOf(false) }
    var voicePermissionPreviouslyDenied by rememberSaveable { mutableStateOf(false) }
    val recordAudioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { granted ->
            if (granted) {
                voiceListeningActive = true
                com.arix.app.ui.ArixMusicPulse.onRecordAudioPermissionGranted()
            } else {
                voicePermissionPreviouslyDenied = true
                Toast.makeText(
                    context,
                    context.getString(R.string.voice_input_unavailable),
                    Toast.LENGTH_SHORT,
                ).show()
            }
        },
    )
    val onStartVoiceInput: () -> Unit = {
        if (ArixSpeechRecognitionController.hasMicrophonePermission(context)) {
            voiceListeningActive = true
        } else {
            val activity = context.findActivity()
            val canShowSystemDialog = activity == null ||
                androidx.core.app.ActivityCompat.shouldShowRequestPermissionRationale(
                    activity,
                    ArixSpeechRecognitionController.microphonePermission(),
                ) || !voicePermissionPreviouslyDenied
            if (canShowSystemDialog) {
                recordAudioPermissionLauncher.launch(
                    ArixSpeechRecognitionController.microphonePermission()
                )
            } else {
                showVoicePermissionExplainer = true
            }
        }
    }

    var musicDancePermissionRequested by rememberSaveable { mutableStateOf(false) }
    val musicDancePermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { granted ->
            if (granted) {
                com.arix.app.ui.ArixMusicPulse.onRecordAudioPermissionGranted()
            }
        },
    )
    val playbackStateForPermission by com.arix.app.media.ArixPlaybackController.state
        .collectAsStateWithLifecycle()
    LaunchedEffect(playbackStateForPermission.isPlaying) {
        val playing = playbackStateForPermission.isPlaying
        if (!playing || musicDancePermissionRequested) return@LaunchedEffect
        if (ArixSpeechRecognitionController.hasMicrophonePermission(context)) return@LaunchedEffect
        musicDancePermissionRequested = true
        musicDancePermissionLauncher.launch(
            ArixSpeechRecognitionController.microphonePermission()
        )
    }
    val skillFolderPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree(),
        onResult = { treeUri ->
            if (treeUri != null) {
                runCatching {
                    context.contentResolver.takePersistableUriPermission(
                        treeUri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION,
                    )
                }
                viewModel.installSkillFromDirectory(treeUri)
            }
        },
    )

    val skillZipPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
        onResult = { zipUri ->
            val completion = pendingSkillZipCompletion
            pendingSkillZipCompletion = null
            if (zipUri != null) {
                runCatching {
                    context.contentResolver.takePersistableUriPermission(
                        zipUri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION,
                    )
                }
                viewModel.installSkillFromZip(zipUri) { success ->
                    completion?.invoke(success)
                }
            } else {
                completion?.invoke(false)
            }
        },
    )
    val saveAttachmentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("*/*"),
        onResult = { destinationUri ->
            val saveTarget = pendingSaveTarget
            pendingSaveTarget = null

            if (saveTarget == null || destinationUri == null) {
                return@rememberLauncherForActivityResult
            }

            scope.launch {
                val didSave = withContext(Dispatchers.IO) {
                    when (saveTarget) {
                        is PendingSaveTarget.Attachment -> saveAttachmentToDocument(
                            context = context,
                            attachment = saveTarget.attachment,
                            destinationUri = destinationUri,
                        )

                        is PendingSaveTarget.WorkspaceFile -> runtimeWorkspaceFileBridge.saveWorkspaceFileToDocument(
                            settings = uiState.settings,
                            path = saveTarget.rawLink,
                            workingDirectory = currentRuntimeWorkspaceDirectory,
                            destinationUri = destinationUri,
                        )
                    }
                }
                Toast.makeText(
                    context,
                    context.getString(if (didSave) R.string.file_saved else R.string.file_could_not_save),
                    Toast.LENGTH_SHORT,
                ).show()
            }
        },
    )
    val sessionExportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json"),
        onResult = { destinationUri ->
            val sessionId = pendingSessionExportId
            pendingSessionExportId = null
            if (sessionId != null && destinationUri != null) {
                viewModel.exportSessionToUri(sessionId, destinationUri)
            }
        },
    )
    val appDataExportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json"),
        onResult = { destinationUri ->
            if (destinationUri != null) {
                viewModel.exportAllDataToUri(destinationUri)
            }
        },
    )
    val logExportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/plain"),
        onResult = { destinationUri ->
            if (destinationUri != null) {
                viewModel.exportLogsToUri(destinationUri)
            }
        },
    )
    val appDataImportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
        onResult = { sourceUri ->
            if (sourceUri != null) {
                runCatching {
                    context.contentResolver.takePersistableUriPermission(
                        sourceUri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION,
                    )
                }
                viewModel.importAllDataFromUri(sourceUri)
            }
        },
    )
    if (drawerState.isOpen) {
        BackHandler {
            scope.launch { drawerState.close() }
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = uiState.currentScreen == AppScreen.Chat,
        scrimColor = ArixScrim,
        drawerContent = {
            ConversationDrawer(
                sessions = uiState.sessions,
                selectedSessionId = uiState.currentSessionId,
                sessionExecutionStates = uiState.sessionExecutionStates,
                unviewedCompletedSessionIds = uiState.unviewedCompletedSessionIds,
                onClearAll = {
                    viewModel.clearAllSessions()
                },
                onSessionSelected = { sessionId ->
                    viewModel.selectSession(sessionId)
                    scope.launch { drawerState.close() }
                },
                onRenameSession = viewModel::renameSession,
                onExportSession = { session ->
                    pendingSessionExportId = session.id
                    sessionExportLauncher.launch("${session.title.ifBlank { "arix-session" }}.json")
                },
                onDeleteSession = viewModel::deleteSession,
            )
        },
    ) {
        if (!uiState.isStartupRouteResolved) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(ArixBackground)
            )
        } else {
            Box(modifier = Modifier.fillMaxSize()) {
            AnimatedContent(
                targetState = uiState.currentScreen,
                transitionSpec = {
                    if (reduceMotion) {
                        return@AnimatedContent fadeIn(tween(80)) togetherWith fadeOut(tween(60))
                    }
                    val isForward = targetState.depth() > initialState.depth()
                    val enterSlide = slideInHorizontally(
                        animationSpec = tween(ScreenTransitionDuration, easing = ScreenTransitionEasing),
                        initialOffsetX = { if (isForward) it / 3 else -it / 3 },
                    ) + fadeIn(tween(ScreenTransitionDuration, easing = ScreenTransitionEasing))
                    val exitSlide = slideOutHorizontally(
                        animationSpec = tween(ScreenTransitionDuration, easing = ScreenTransitionEasing),
                        targetOffsetX = { if (isForward) -it / 3 else it / 3 },
                    ) + fadeOut(tween(ScreenTransitionDuration, easing = ScreenTransitionEasing))
                    enterSlide togetherWith exitSlide
                },
                label = "app_screen_transition",
            ) { currentScreen ->
                when (currentScreen) {
                    AppScreen.Welcome -> GetStartedScreen(
                        onGetStarted = viewModel::completeGetStarted,
                        onSkip = viewModel::skipGetStarted,
                    )

                    AppScreen.Chat -> ConversationScreen(
                    conversationStateKey = uiState.currentSessionId,
                    messages = currentMessages,
                    workspaceDirectory = currentRuntimeWorkspaceDirectory,
                    pendingToolInvocations = pendingToolInvocations,
                    pendingToolInvocationStateKey = "pending-tools-${uiState.currentSessionId}",
                    pendingResponseBlocks = pendingResponseBlocks,
                    pendingAssistantText = pendingAssistantText,
                    pendingStatusText = currentSessionExecution?.pendingStatusText.orEmpty(),
                    pendingStatusDetail = currentSessionExecution?.pendingStatusDetail.orEmpty(),
                    activeTurnStartedAtMillis = currentSessionExecution?.activeTurnStartedAtMillis,
                    reasoningPhase = currentSessionExecution?.reasoningPhase
                        ?: com.arix.app.data.ArixReasoningPhase.IDLE,
                    isCompacting = uiState.compactingSessionId == uiState.currentSessionId,
                    pendingInputs = pendingInputs,
                    inputValue = uiState.draftInput,
                    draftAttachments = uiState.draftAttachments,
                    modelOptions = conversationModelOptions,
                    modelCatalogInfo = uiState.modelCatalogInfo,
                    selectedModelKey = selectedConversationModelKey,
                    reasoningEffort = uiState.settings.reasoningEffort,
                    thinkingLevelsByProviderModel = uiState.thinkingLevelsByProviderModel,
                    thinkingLevelClampsByProviderModel = uiState.thinkingLevelClampsByProviderModel,
                    modelLimitsByProviderModel = uiState.modelLimitsByProviderModel,
                    availableSkills = uiState.installedSkills.filter { it.isEnabled },
                    selectedSkillIds = selectedSkillIds,
                    isEditing = uiState.editingMessageId != null,
                    showStarterPromptHint = uiState.showStarterPromptHint,
                    recentSessions = uiState.sessions
                        .filter { it.id != uiState.currentSessionId && it.messages.isNotEmpty() }
                        .take(3),
                    onOpenSession = { sessionId -> viewModel.selectSession(sessionId) },
                    onOpenScreen = { screen -> viewModel.openMainTab(screen) },
                    onInputChanged = viewModel::updateDraftInput,
                    onModelSelected = viewModel::setCurrentChatModelSelectionAndResolveThinkingLevels,
                    onModelSelectorOpened = viewModel::refreshCurrentChatThinkingLevels,
                    onReasoningEffortSelected = viewModel::setReasoningEffort,
                    onRemoveDraftAttachment = viewModel::removeDraftAttachment,
                    onSetSkillSelected = viewModel::setComposerSkillSelected,
                    onCancelEdit = viewModel::cancelMessageEdit,
                    onSend = viewModel::sendCurrentMessage,
                    onQueueFollowUp = viewModel::sendCurrentMessage,
                    onSteerFollowUp = viewModel::steerCurrentMessage,
                    onMenu = { scope.launch { drawerState.open() } },
                    onNewChat = viewModel::startNewChat,
                    onPickImages = {
                        imagePicker.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    onPickFiles = { filePicker.launch("*/*") },
                    onStartVoiceInput = onStartVoiceInput,
                    voiceListening = voiceListeningActive,
                    onVoiceListeningSettled = { recognized ->
                        voiceListeningActive = false
                        viewModel.submitVoiceInput(recognized)
                    },
                    onVoiceListeningCancelled = {
                        ArixSpeechRecognitionController.cancel()
                        voiceListeningActive = false
                    },
                    onSaveAttachment = { attachment ->
                        pendingSaveTarget = PendingSaveTarget.Attachment(attachment)
                        saveAttachmentLauncher.launch(attachment.name)
                    },
                    onOpenLink = { rawLink ->
                        scope.launch {
                            handleAssistantLink(
                                context = context,
                                rawLink = rawLink,
                                onSaveWorkspaceFile = { fileLink ->
                                    pendingSaveTarget = PendingSaveTarget.WorkspaceFile(fileLink)
                                    saveAttachmentLauncher.launch(
                                        workspaceFileBridge.resolveWorkspaceDownloadName(fileLink)
                                    )
                                },
                            )
                        }
                    },
                    onEditMessage = { messageId ->
                        activeSession?.let { viewModel.startEditingUserMessage(it.id, messageId) }
                    },
                    onDeleteMessage = { messageId ->
                        activeSession?.let { viewModel.deleteMessage(it.id, messageId) }
                    },
                    onRedoAgentMessage = { messageId ->
                        activeSession?.let { viewModel.redoAgentMessage(it.id, messageId) }
                    },
                    onRetryUserMessage = { messageId ->
                        activeSession?.let { viewModel.retryUserMessage(it.id, messageId) }
                    },
                    onSwitchUserMessageBranch = { messageId, delta ->
                        activeSession?.let { viewModel.switchUserMessageBranch(it.id, messageId, delta) }
                    },
                    onCopyMessage = { message ->
                        clipboardManager.setText(AnnotatedString(stripAssistantScreenContext(message.text)))
                        Toast.makeText(context, context.getString(R.string.file_reply_copied), Toast.LENGTH_SHORT).show()
                    },
                    onPauseGeneration = viewModel::pauseGeneration,
                    onDismissStarterPromptHint = viewModel::dismissStarterPromptHint,
                    canContinueFromCheckpoint = canContinueCheckpoint,
                    onContinueFromCheckpoint = viewModel::continueFromCheckpoint,
                            isSending = isCurrentSessionRunning,
                            bottomBarReserve = if (uiState.currentScreen.isMainTab) {
                                ArixBottomNavBarFootprint
                            } else {
                                0.dp
                            },
                        )


                    AppScreen.Terminal -> Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(bottom = ArixBottomNavBarHeight + 16.dp),
                    ) {
                        TermuxTerminalScreen(
                            createLaunchSpec = viewModel::createTermuxTerminalLaunchSpec,
                            onBack = { viewModel.openMainTab(AppScreen.Chat) },
                        )
                    }

                    AppScreen.Browser -> Box(
                        modifier = Modifier
                            .fillMaxSize(),
                    ) {
                        ArixBrowserScreen(
                            onBack = { viewModel.openMainTab(AppScreen.Chat) },
                            onOpenChat = { viewModel.openMainTab(AppScreen.Chat) },
                            onCancelGeneration = { viewModel.pauseGeneration() },
                        )
                    }

                    AppScreen.Files -> Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(bottom = ArixBottomNavBarHeight + 16.dp),
                    ) {
                        if (uiState.termuxSetupState.isReady) {
                            AndroidTermuxFileManagerScreen(
                                runtime = termuxFileManagerRuntime,
                                initialPath = TermuxFilesTabInitialPath,
                                onBack = { viewModel.openMainTab(AppScreen.Chat) },
                            )
                        } else {
                            TermuxFilesSetupPrompt(
                                detail = uiState.termuxSetupState.detail,
                                onInitialize = { viewModel.initializeTermuxRuntime() },
                            )
                        }
                    }

                    AppScreen.Settings -> SettingsScreen(
                    systemPrompt = uiState.settings.systemPrompt,
                    tavilyApiKey = uiState.settings.tavilyApiKey,
                    tavilyBaseUrl = uiState.settings.tavilyBaseUrl,
                    webSearchEngine = uiState.settings.webSearchEngine,
                    saveResearchToMemory = uiState.settings.saveResearchToMemory,
                    unrestrictedMode = uiState.settings.unrestrictedMode,
                    llmInactivityReconnectTimeoutSeconds = uiState.settings.llmInactivityReconnectTimeoutSeconds,
                    keepTasksRunningInBackground = uiState.settings.keepTasksRunningInBackground,
                    notifyOnTaskCompletion = uiState.settings.notifyOnTaskCompletion,
                    agentWorkspaceMode = uiState.settings.agentWorkspaceMode,
                    autoCleanOldCommandHistory =
                        uiState.settings.autoCleanOldCommandHistory,
                    oldCommandHistoryRetentionHours =
                        uiState.settings.oldCommandHistoryRetentionHours,
                    language = language,
                    themeMode = uiState.settings.themeMode,
                    defaultChatModelKey = uiState.settings.defaultChatModelKey,
                    defaultTitleModelKey = uiState.settings.defaultTitleModelKey,
                    defaultNamingModelKey = uiState.settings.defaultNamingModelKey,
                    defaultCompactingModelKey = uiState.settings.defaultCompactingModelKey,
                    providerConfigs = uiState.providerConfigs,
                    usageStatisticsSnapshots = uiState.usageStatisticsSnapshots,
                    scheduledTasks = uiState.scheduledTasks,
                    termuxSetupState = uiState.termuxSetupState,
                    enabledRuntimeIds = uiState.settings.enabledRuntimeIds,
                    defaultRuntimeId = uiState.settings.defaultRuntimeId,
                    termuxFileManagerRuntime = termuxFileManagerRuntime,
                    installedSkills = uiState.installedSkills,
                    isFetchingModels = uiState.isFetchingModels,
                    providerAuthState = uiState.providerAuthState,
                    onSave = viewModel::saveSettings,
                    onUpsertProviderConfig = viewModel::upsertProviderConfig,
                    onRemoveProviderConfig = viewModel::removeProviderConfig,
                    onSetProviderEnabled = viewModel::setProviderEnabled,
                    onFetchModels = viewModel::fetchModels,
                    onStartProviderLogin = viewModel::startProviderLogin,
                    onSubmitProviderAuthPrompt = viewModel::submitProviderAuthPrompt,
                    onClearProviderAuthState = viewModel::clearProviderAuthState,
                    onImportSkillFolder = { skillFolderPicker.launch(null) },
                    onImportSkillZip = { onComplete ->
                        pendingSkillZipCompletion = onComplete
                        skillZipPicker.launch(arrayOf("application/zip", "application/octet-stream", "*/*"))
                    },
                    onInstallSkillUrl = { url, onComplete ->
                        viewModel.installSkillFromRemote(url, onComplete)
                    },
                    onToggleSkillEnabled = viewModel::setSkillEnabled,
                    onRemoveSkill = viewModel::removeSkill,
                    onReinstallBuiltInSkill = viewModel::reinstallBuiltInSkill,
                    onSaveScheduledTask = viewModel::saveScheduledTask,
                    onToggleScheduledTaskEnabled = viewModel::setScheduledTaskEnabled,
                    onRemoveScheduledTask = viewModel::removeScheduledTask,
                    onImportAppData = {
                        appDataImportLauncher.launch(arrayOf("application/json", "text/*", "*/*"))
                    },
                    onExportAppData = {
                        showAppDataExportWarning = true
                    },
                    onExportLogs = {
                        logExportLauncher.launch("arix-logs.txt")
                    },
                    onInitializeTermuxRuntime = { viewModel.initializeTermuxRuntime(makeDefault = false) },
                    onResetTermuxRuntime = viewModel::resetTermuxRuntime,
                    onRefreshTermuxSetup = { viewModel.refreshTermuxSetup(startPiIfReady = true) },
                    onSetDefaultRuntime = viewModel::setDefaultRuntime,
                    onOpenWebsite = { openExternalUrl(context, ArixWebsiteUrl) },
                    onOpenPrivacyPolicy = { openExternalUrl(context, ArixPrivacyPolicyUrl) },
                            onBack = viewModel::closeSettings,
                        )

        }
            }

            if (uiState.currentScreen.isMainTab) {
                val density = LocalDensity.current
                val imeInsets = WindowInsets.ime
                val imeVisibleNow by remember(imeInsets, density) {
                    derivedStateOf { imeInsets.getBottom(density) > 0 }
                }
                ArixBottomNavBar(
                    currentScreen = uiState.currentScreen,
                    imeVisible = imeVisibleNow,
                    onSelect = viewModel::openMainTab,
                    modifier = Modifier.align(Alignment.BottomCenter),
                )
            }
            }
        }

        if (uiState.isStartupRouteResolved && !uiState.settings.privacyPolicyAccepted) {
            PrivacyPolicyConsentDialog(
                onOpenPolicy = { openPrivacyPolicy(context) },
                onAccept = viewModel::acceptPrivacyPolicy,
                onDecline = { context.findActivity()?.finishAffinity() },
            )
        }

        LaunchedEffect(uiState.exitRequestSerial) {
            if (uiState.exitRequestSerial > 0) {
                kotlinx.coroutines.delay(1_400L)
                runCatching { ArixSpeechRecognitionController.cancel() }
                context.findActivity()?.finishAffinity()
            }
        }
        if (showVoicePermissionExplainer) {
            AlertDialog(
                onDismissRequest = { showVoicePermissionExplainer = false },
                containerColor = ArixSurface,
                titleContentColor = ArixOnSurface,
                textContentColor = ArixOnSurfaceVariant,
                title = {
                    Text(stringResource(R.string.voice_permission_needed_title))
                },
                text = {
                    Text(stringResource(R.string.voice_permission_needed_message))
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            showVoicePermissionExplainer = false
                            runCatching {
                                context.startActivity(
                                    Intent(
                                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                        Uri.fromParts("package", context.packageName, null),
                                    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            }
                        }
                    ) {
                        Text(stringResource(R.string.voice_permission_open_settings))
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showVoicePermissionExplainer = false }) {
                        Text(stringResource(R.string.common_cancel))
                    }
                },
            )
        }
        if (showAppDataExportWarning) {
            AlertDialog(
                onDismissRequest = { showAppDataExportWarning = false },
                containerColor = ArixSurface,
                titleContentColor = ArixOnSurface,
                textContentColor = ArixOnSurfaceVariant,
                title = {
                    Text(stringResource(R.string.settings_export_app_data_warning_title))
                },
                text = {
                    Text(stringResource(R.string.settings_export_app_data_warning_message))
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            showAppDataExportWarning = false
                            appDataExportLauncher.launch("arix-data.json")
                        },
                    ) {
                        Text(stringResource(R.string.common_export))
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAppDataExportWarning = false }) {
                        Text(stringResource(R.string.common_cancel))
                    }
                },
            )
        }
    }
}

@Composable
private fun PrivacyPolicyConsentDialog(
    onOpenPolicy: () -> Unit,
    onAccept: () -> Unit,
    onDecline: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = {},
        containerColor = ArixSurface,
        titleContentColor = ArixOnSurface,
        textContentColor = ArixOnSurfaceVariant,
        title = {
            Text(
                text = stringResource(R.string.app_privacy_policy_title),
                style = MaterialTheme.typography.titleLarge,
            )
        },
        text = {
            val policyText = stringResource(R.string.app_privacy_policy_title)
            val messagePrefix = stringResource(R.string.app_privacy_policy_message_prefix)
            val messageSuffix = stringResource(R.string.app_privacy_policy_message_suffix)
            val annotatedText = buildAnnotatedString {
                append(messagePrefix)
                pushStringAnnotation(
                    tag = PrivacyPolicyAnnotationTag,
                    annotation = ArixPrivacyPolicyUrl,
                )
                withStyle(SpanStyle(color = Color(0xFF3B82F6))) {
                    append(policyText)
                }
                pop()
                append(messageSuffix)
            }
            ClickableText(
                text = annotatedText,
                style = MaterialTheme.typography.bodyMedium.copy(color = ArixOnSurfaceVariant),
                onClick = { offset ->
                    annotatedText
                        .getStringAnnotations(PrivacyPolicyAnnotationTag, offset, offset)
                        .firstOrNull()
                        ?.let { onOpenPolicy() }
                },
            )
        },
        confirmButton = {
            Button(
                onClick = onAccept,
                colors = ButtonDefaults.buttonColors(
                    containerColor = ArixPrimary,
                    contentColor = Color.White,
                ),
            ) {
                Text(text = stringResource(R.string.common_agree))
            }
        },
        dismissButton = {
            TextButton(onClick = onDecline) {
                Text(
                    text = stringResource(R.string.common_decline),
                    color = ArixOnSurfaceVariant,
                )
            }
        },
    )
}

private fun saveAttachmentToDocument(
    context: android.content.Context,
    attachment: ChatAttachment,
    destinationUri: Uri,
): Boolean = runCatching {
    val resolver = context.contentResolver
    val sourceUri = Uri.parse(attachment.uri)
    val expectedSize = resolver.openAssetFileDescriptor(sourceUri, "r")?.use { descriptor ->
        descriptor.length.takeIf { it >= 0L }
    }
    var copiedBytes = 0L
    resolver.openInputStream(sourceUri)?.use { input ->
        resolver.openOutputStream(destinationUri, "w")?.use { output ->
            copiedBytes = input.copyTo(output)
            output.flush()
        }
    } != null && (expectedSize == null || expectedSize == copiedBytes)
}.getOrDefault(false)

private suspend fun handleAssistantLink(
    context: android.content.Context,
    rawLink: String,
    onSaveWorkspaceFile: (String) -> Unit,
) {
    parseAssistantLocalFileLink(rawLink)?.let { localPath ->
        onSaveWorkspaceFile(localPath)
        return
    }

    val normalizedLink = normalizeAssistantLink(rawLink)
    if (looksLikeWorkspaceFileLink(normalizedLink)) {
        onSaveWorkspaceFile(normalizedLink)
        return
    }

    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(normalizedLink)).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    launchIntentSafely(context, intent) {
        Toast.makeText(context, context.getString(R.string.app_unable_to_open_link), Toast.LENGTH_SHORT).show()
    }
}

private fun normalizeAssistantLink(rawLink: String): String {
    val trimmed = rawLink.trim().removeSurrounding("<", ">")
    if (trimmed.isBlank()) return trimmed
    if (looksLikeWorkspaceFileLink(trimmed)) return trimmed
    if (trimmed.contains("://")) return trimmed
    if (trimmed.startsWith("www.", ignoreCase = true)) {
        return "https://$trimmed"
    }
    return if (Patterns.WEB_URL.matcher(trimmed).matches() && !trimmed.startsWith("/")) {
        "https://$trimmed"
    } else {
        trimmed
    }
}

private fun looksLikeWorkspaceFileLink(rawLink: String): Boolean {
    val trimmed = rawLink.trim()
    if (trimmed.isBlank()) return false
    if (trimmed.startsWith("file://", ignoreCase = true)) return true
    if (trimmed.startsWith("~/")) return true
    if (trimmed.startsWith("/")) return true
    return false
}

private fun resolveConversationModelKey(
    session: ChatSession?,
    draftSelectedModelKey: String,
    defaultChatModelKey: String,
    options: List<ProviderModelOption>,
): String {
    val preferredKey = session?.selectedModelKey
        ?.takeIf { key -> options.any { it.key == key } }
        ?: draftSelectedModelKey.takeIf { key -> options.any { it.key == key } }
        ?: defaultChatModelKey.takeIf { key -> options.any { it.key == key } }
    return preferredKey ?: options.resolveAutomaticModelKey(AutomaticModelPurpose.Chat)
}

private fun openPrivacyPolicy(
    context: android.content.Context,
) {
    openExternalUrl(context, ArixPrivacyPolicyUrl)
}

private fun openExternalUrl(
    context: android.content.Context,
    url: String,
) {
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    launchIntentSafely(context, intent) {
        Toast.makeText(context, context.getString(R.string.app_unable_to_open_link), Toast.LENGTH_SHORT).show()
    }
}

private fun launchIntentSafely(
    context: android.content.Context,
    intent: Intent,
    fallback: (() -> Unit)? = null,
) {
    val launchResult = runCatching {
        context.startActivity(intent)
    }
    if (launchResult.isSuccess) {
        return
    }

    val failure = launchResult.exceptionOrNull()
    if (failure is ActivityNotFoundException || failure is SecurityException) {
        if (fallback != null) {
            fallback()
        } else {
            Toast.makeText(context, context.getString(R.string.app_unable_to_open_screen), Toast.LENGTH_SHORT).show()
        }
    } else if (fallback != null) {
        fallback()
    } else {
        Toast.makeText(context, context.getString(R.string.app_unable_to_open_screen), Toast.LENGTH_SHORT).show()
    }
}

private const val AgentRunWakeLockTimeoutMillis = 30L * 60L * 1000L

@Composable
private fun ArixAgentRunKeepAwake(running: Boolean) {
    val view = LocalView.current
    val context = LocalContext.current
    DisposableEffect(running, view) {
        view.keepScreenOn = running
        val wakeLock = if (running) {
            runCatching {
                val power = context.applicationContext.getSystemService(Context.POWER_SERVICE) as PowerManager
                power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "arix:agent-run").apply {
                    setReferenceCounted(false)
                    acquire(AgentRunWakeLockTimeoutMillis)
                }
            }.getOrNull()
        } else {
            null
        }
        onDispose {
            view.keepScreenOn = false
            runCatching {
                if (wakeLock != null && wakeLock.isHeld) wakeLock.release()
            }
        }
    }
}
