package com.arix.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import com.arix.app.R
import com.arix.app.arixRuntime
import com.arix.app.im.ArixTelegramPairingStore
import com.arix.app.im.ArixTelegramService
import com.arix.app.im.ArixTelegramState
import com.arix.app.ui.theme.ArixError
import com.arix.app.ui.theme.ArixOnSurface
import com.arix.app.ui.theme.ArixOnSurfaceVariant
import kotlinx.coroutines.launch

@Composable
fun ArixTelegramBotPage(onBack: () -> Unit) {
    val context = LocalContext.current
    val runtime = context.arixRuntime
    val scope = rememberCoroutineScope()
    val settingsRepository = runtime.telegramSettings
    val pairing = runtime.telegramPairing

    val settings by settingsRepository.settings.collectAsState(
        initial = com.arix.app.im.ArixTelegramSettings(),
    )
    val connectionState by ArixTelegramService.connectionState.collectAsState()
    val connectionDetail by ArixTelegramService.connectionDetail.collectAsState()
    val status = when {
        !settings.enabled -> ArixTelegramState.STOPPED
        settings.botToken.isBlank() -> ArixTelegramState.STOPPED
        else -> connectionState
    }

    var pendingPairings by remember { mutableStateOf(listOf<com.arix.app.im.ArixTelegramPendingPairing>()) }
    var pairedChats by remember { mutableStateOf(listOf<com.arix.app.im.ArixTelegramPairedChat>()) }

    LaunchedEffect(pairing) {
        pairing.changes.collect {
            pendingPairings = pairing.pendingPairings()
            pairedChats = pairing.pairedChats()
        }
    }
    LaunchedEffect(settings.enabled, settings.botToken) {
        if (settings.enabled && settings.botToken.isNotBlank() &&
            ArixTelegramService.connectionState.value == ArixTelegramState.STOPPED
        ) {
            ArixTelegramService.start(context)
        }
    }

    var tokenField by remember { mutableStateOf(TextFieldValue(settings.botToken)) }
    LaunchedEffect(settings.botToken) {
        if (settings.botToken != tokenField.text) tokenField = TextFieldValue(settings.botToken)
    }
    val savedBaseUrl = settings.baseUrl.takeIf { it != com.arix.app.im.ArixTelegramClient.DEFAULT_BASE_URL } ?: ""
    var baseUrlField by remember { mutableStateOf(TextFieldValue(savedBaseUrl)) }
    LaunchedEffect(savedBaseUrl) {
        if (savedBaseUrl != baseUrlField.text) baseUrlField = TextFieldValue(savedBaseUrl)
    }
    var proxyField by remember { mutableStateOf(TextFieldValue(settings.proxy)) }
    LaunchedEffect(settings.proxy) {
        if (settings.proxy != proxyField.text) proxyField = TextFieldValue(settings.proxy)
    }

    SubPageScaffold(
        title = stringResource(R.string.settings_telegram_bot),
        onBack = onBack,
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            SettingsCardGroup {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                text = stringResource(R.string.telegram_enable),
                                style = MaterialTheme.typography.bodyLarge,
                                color = ArixOnSurface,
                            )
                            Text(
                                text = stringResource(R.string.telegram_enable_subtitle),
                                style = MaterialTheme.typography.bodySmall,
                                color = ArixOnSurfaceVariant,
                            )
                        }
                        Switch(
                            checked = settings.enabled,
                            onCheckedChange = { enabled ->
                                scope.launch {
                                    settingsRepository.setEnabled(enabled)
                                    if (enabled) {
                                        ArixTelegramService.start(context)
                                    } else {
                                        ArixTelegramService.stop(context)
                                    }
                                }
                            },
                        )
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(top = 8.dp),
                    ) {
                        if (status == ArixTelegramState.CONNECTING) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.size(8.dp))
                        }
                        Text(
                            text = when (status) {
                                ArixTelegramState.STOPPED ->
                                    stringResource(R.string.telegram_status_stopped)
                                ArixTelegramState.CONNECTING ->
                                    stringResource(R.string.telegram_status_connecting)
                                ArixTelegramState.CONNECTED ->
                                    stringResource(
                                        R.string.telegram_status_connected,
                                        connectionDetail.orEmpty(),
                                    )
                                ArixTelegramState.ERROR ->
                                    stringResource(
                                        R.string.telegram_status_error,
                                        connectionDetail.orEmpty(),
                                    )
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = if (status == ArixTelegramState.ERROR) {
                                ArixError
                            } else {
                                ArixOnSurfaceVariant
                            },
                        )
                    }
                }
                CardDivider()
                ChatGptTextField(
                    label = stringResource(R.string.telegram_token),
                    value = tokenField,
                    onValueChange = { field ->
                        tokenField = field
                        scope.launch { settingsRepository.setBotToken(field.text) }
                    },
                    isSecret = true,
                    supportingText = "Get one from @BotFather",
                )
                ChatGptTextField(
                    label = stringResource(R.string.telegram_base_url),
                    value = baseUrlField,
                    onValueChange = { field ->
                        baseUrlField = field
                        scope.launch {
                            settingsRepository.setBaseUrl(
                                field.text.ifBlank { com.arix.app.im.ArixTelegramClient.DEFAULT_BASE_URL },
                            )
                        }
                    },
                    placeholder = "https://api.telegram.org",
                )
                CardDivider()
                ChatGptTextField(
                    label = stringResource(R.string.telegram_proxy),
                    value = proxyField,
                    onValueChange = { field ->
                        proxyField = field
                        scope.launch { settingsRepository.setProxy(field.text) }
                    },
                    placeholder = "http:// or socks5://",
                )
            }

            Text(
                text = stringResource(R.string.telegram_pending_header),
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.SemiBold,
                color = ArixOnSurfaceVariant,
                modifier = Modifier.padding(horizontal = 4.dp),
            )
            SettingsCardGroup {
                if (pendingPairings.isEmpty()) {
                    Text(
                        text = stringResource(R.string.telegram_pending_empty),
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                        modifier = Modifier.padding(16.dp),
                    )
                } else {
                    pendingPairings.forEach { entry ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    text = stringResource(
                                        R.string.telegram_pairing_code,
                                        entry.code,
                                    ),
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = ArixOnSurface,
                                )
                                Text(
                                    text = entry.senderName,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = ArixOnSurfaceVariant,
                                )
                            }
                            IconButton(
                                onClick = {
                                    scope.launch {
                                        pairing.approve(entry.code)
                                    }
                                },
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Check,
                                    contentDescription = stringResource(R.string.telegram_approve),
                                    tint = ArixOnSurface,
                                )
                            }
                            IconButton(
                                onClick = {
                                    scope.launch {
                                        pairing.deny(entry.code)
                                    }
                                },
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Close,
                                    contentDescription = stringResource(R.string.telegram_deny),
                                    tint = ArixError,
                                )
                            }
                        }
                    }
                }
            }

            Text(
                text = stringResource(R.string.telegram_paired_header),
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.SemiBold,
                color = ArixOnSurfaceVariant,
                modifier = Modifier.padding(horizontal = 4.dp),
            )
            SettingsCardGroup {
                if (pairedChats.isEmpty()) {
                    Text(
                        text = stringResource(R.string.telegram_paired_empty),
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                        modifier = Modifier.padding(16.dp),
                    )
                } else {
                    pairedChats.forEach { entry ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    text = entry.senderName.ifBlank { "#${entry.senderId}" },
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = ArixOnSurface,
                                )
                            }
                            IconButton(
                                onClick = {
                                    scope.launch {
                                        pairing.remove(entry.senderId)
                                    }
                                },
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Close,
                                    contentDescription = stringResource(R.string.telegram_remove),
                                    tint = ArixError,
                                )
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}
