package com.arix.app.ui

import com.arix.app.data.WorkspaceFileBridge
internal fun defaultMarkdownImageLayout(): MarkdownMediaLayout = MarkdownMediaLayout(
    minHeightDp = 1,
    maxHeightDp = DefaultImageMaxHeightDp,
    fit = MarkdownMediaFit.Contain,
)

internal fun defaultMarkdownMermaidLayout(): MarkdownMediaLayout = MarkdownMediaLayout(
    minHeightDp = DefaultMermaidMinHeightDp,
    maxHeightDp = DefaultMermaidMaxHeightDp,
    scroll = true,
)

internal fun buildMarkdownImageOriginalLinkTarget(
    rawUrl: String,
    workspaceFileBridge: WorkspaceFileBridge,
    workspaceDirectory: String?,
): String? {
    val normalizedUrl = normalizeMarkdownImageUrl(rawUrl) ?: return null
    return when {
        normalizedUrl.startsWith("http://", ignoreCase = true) ||
            normalizedUrl.startsWith("https://", ignoreCase = true) -> normalizedUrl

        normalizedUrl.startsWith("data:", ignoreCase = true) ||
            normalizedUrl.startsWith("content://", ignoreCase = true) -> null

        else -> {
            val workingDirectory = workspaceDirectory?.trim().orEmpty()
            val resolvedPath = if (normalizedUrl.startsWith("file://", ignoreCase = true)) {
                workspaceFileBridge.resolveLinkPath(normalizedUrl)
            } else {
                workspaceFileBridge.resolveWorkspacePath(
                    path = normalizedUrl,
                    workingDirectory = workingDirectory,
                )
            }
            buildAssistantLocalFileLink(resolvedPath)
        }
    }
}

private val markdownImagePattern = Regex("^!\\[(.*?)]\\((.+)\\)(?:\\{(.*)\\})?$")
private val markdownCodeFenceHeaderPattern = Regex("^```\\s*([^\\s{]+)?\\s*(?:\\{(.*)\\})?\\s*$")
private val markdownAttributePattern =
    Regex("""([A-Za-z][A-Za-z0-9_-]*)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^,\s]+)))?""")

internal sealed interface MarkdownLocalMediaSegment {
    data class Text(val text: String, val start: Int) : MarkdownLocalMediaSegment

    data class MediaPath(val path: String, val rawToken: String) : MarkdownLocalMediaSegment
}

private val localMediaImageExtensions = setOf(
    "png", "jpg", "jpeg", "gif", "webp", "bmp", "svg", "avif", "heic",
)

private val localMediaFileExtensions = setOf(
    "png", "jpg", "jpeg", "gif", "webp", "bmp", "svg", "avif", "heic",
    "mp4", "webm", "mkv", "mov", "avi", "m4v",
    "mp3", "wav", "ogg", "m4a", "flac", "aac",
    "pdf", "zip", "apk",
)

private val bareLocalMediaTokenPattern = Regex("`?[^\\s`]+`?")

internal fun isLocalImageMediaPath(path: String): Boolean {
    val extension = path.substringAfterLast('.', "").lowercase()
    return extension in localMediaImageExtensions
}

internal fun parseBareLocalMediaToken(token: String): String? {
    var path = token.trim()
    if (path.length >= 2 && path.startsWith("`") && path.endsWith("`")) {
        path = path.removeSurrounding("`").trim()
    }
    if (path.length >= 2 && path.startsWith("<") && path.endsWith(">")) {
        path = path.removeSurrounding("<").trim()
    }
    path = path.trimEnd('.', ',', ';', '!', '?', ')', '"', '\'')
    if (path.isBlank()) return null
    val isLocal = path.startsWith("file://", ignoreCase = true) ||
        path.startsWith("/") ||
        path.startsWith("~/") ||
        path.startsWith("workspace/", ignoreCase = true)
    if (!isLocal) return null
    val extension = path.substringAfterLast('.', "").lowercase()
    if (extension !in localMediaFileExtensions) return null
    if (path.startsWith("file://", ignoreCase = true)) {
        path = path.removePrefix("file://").removePrefix("file://")
    }
    return path.takeIf { it.length > 1 }
}

internal fun splitMarkdownLineByLocalMedia(text: String): List<MarkdownLocalMediaSegment> {
    if (!text.contains('/') && !text.contains("~")) {
        return listOf(MarkdownLocalMediaSegment.Text(text, 0))
    }
    val segments = mutableListOf<MarkdownLocalMediaSegment>()
    var cursor = 0
    val matches = bareLocalMediaTokenPattern.findAll(text).toList()
    for (match in matches) {
        val rawToken = match.value
        if (rawToken.isBlank()) continue
        val path = parseBareLocalMediaToken(rawToken) ?: continue
        if (match.range.first > cursor) {
            segments += MarkdownLocalMediaSegment.Text(
                text = text.substring(cursor, match.range.first),
                start = cursor,
            )
        }
        segments += MarkdownLocalMediaSegment.MediaPath(path = path, rawToken = rawToken)
        cursor = match.range.last + 1
    }
    if (segments.isEmpty()) return listOf(MarkdownLocalMediaSegment.Text(text, 0))
    if (cursor < text.length) {
        segments += MarkdownLocalMediaSegment.Text(text = text.substring(cursor), start = cursor)
    }
    return segments
}

private val remoteFileUrlExtensions = setOf(
    "png", "jpg", "jpeg", "gif", "webp", "bmp", "svg", "avif", "heic",
    "mp4", "webm", "mkv", "mov", "avi", "m4v",
    "mp3", "wav", "ogg", "m4a", "flac", "aac",
    "pdf", "zip", "apk", "rar", "7z", "tar", "gz", "tgz",
    "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "csv", "json", "epub",
    "iso", "img", "exe", "msi", "dmg", "deb", "rpm", "jar",
    "xapk", "apks", "obb", "bz2", "xz", "zst", "7zip",
    "md", "log", "xml", "yml", "yaml", "toml", "ini", "conf", "properties",
    "db", "sqlite", "sqlite3", "vcf", "ics", "pem", "crt", "key",
    "ttf", "otf", "woff", "woff2", "psd", "fig", "blend", "obj", "stl",
    "jar", "war", "apk", "aab", "sql", "bak", "sav", "pkg", "appimage", "sh",
)

private val singleMarkdownLinkPattern = Regex(
    "^\\[([^\\]]{0,200})\\]\\((https?://[^\\s)]+)\\)$",
    RegexOption.IGNORE_CASE,
)

private val bareHttpUrlPattern = Regex("^https?://\\S+$", RegexOption.IGNORE_CASE)

internal fun parseRemoteFileUrl(text: String): String? {
    val trimmed = text.trim()
    if (trimmed.isBlank() || !trimmed.startsWith("http", ignoreCase = true)) return null
    if (trimmed.length > 2048) return null

    val url = singleMarkdownLinkPattern.find(trimmed)?.groupValues?.get(2)
        ?: if (bareHttpUrlPattern.matches(trimmed)) trimmed else return null

    val cleaned = url.trimEnd('.', ',', ';', '!', '?', ')', '"', '\'')
    if (!cleaned.startsWith("http", ignoreCase = true)) return null

    val pathOnly = cleaned.substringBefore('#').substringBefore('?')
    val extension = pathOnly.substringAfterLast('.', "").lowercase()
    if (extension !in remoteFileUrlExtensions) return null
    return cleaned
}

private val bracketedBareUrlLinePattern = Regex(
    "^\\[\\s*(https?://[^\\s\\]]+|www\\.[^\\s\\]]+)\\s*\\][.,;:!?]?",
    RegexOption.IGNORE_CASE,
)

internal fun parseWebLinkCardUrl(text: String): String? {
    val trimmed = text.trim()
    if (trimmed.isBlank() || trimmed.length > 2048) return null

    val bracketed = bracketedBareUrlLinePattern.find(trimmed)?.groupValues?.get(1)
    val url = when {
        bracketed != null -> bracketed
        else -> singleMarkdownLinkPattern.find(trimmed)?.groupValues?.get(2)
            ?: if (bareHttpUrlPattern.matches(trimmed)) trimmed else return null
    }

    val cleaned = url.trimEnd('.', ',', ';', '!', '?', '"', '\'')
    if (parseRemoteFileUrl(cleaned) != null) return null
    if (cleaned.startsWith("http://", ignoreCase = true) ||
        cleaned.startsWith("https://", ignoreCase = true)
    ) {
        return cleaned
    }
    if (cleaned.startsWith("www.", ignoreCase = true)) {
        return "https://$cleaned"
    }
    return null
}

internal fun parseMagnetLink(text: String): String? {
    val trimmed = text.trim()
    if (trimmed.isBlank() || trimmed.length > 2048) return null
    if (!trimmed.startsWith("magnet:", ignoreCase = true)) return null
    if (!trimmed.contains("xt=urn:", ignoreCase = true)) return null
    return trimmed
}

internal fun remoteFileDisplayName(url: String): String {
    val pathOnly = url.substringBefore('#').substringBefore('?')
    val name = pathOnly.substringAfterLast('/')
        .trimEnd('.', ',', ';', '!', '?', ')', '"', '\'')
    return name.ifBlank { "download" }
}

internal enum class MarkdownMediaLinkKind {
    Video,

    Audio,

    YouTube,
}

internal data class MarkdownMediaLinkSpec(
    val url: String,
    val kind: MarkdownMediaLinkKind,
    val label: String,
)

private val directVideoExtensions = setOf(
    "mp4", "webm", "mkv", "mov", "avi", "m4v", "ts", "m3u8", "mpd",
    "flv", "wmv", "3gp", "ogv", "mpg", "mpeg", "m2ts",
)

private val directAudioExtensions = setOf(
    "mp3", "wav", "ogg", "m4a", "flac", "aac", "opus", "mid", "aiff",
    "wma", "amr", "mka", "ape", "dsf", "aif", "m3u", "opus",
)

private val remoteImageLinkExtensions = setOf(
    "png", "jpg", "jpeg", "gif", "webp", "bmp", "svg", "avif", "heic",
)

internal fun parseYouTubeVideoId(url: String): String? {
    val cleaned = url.trim().substringBefore('#')
    val host = runCatching {
        android.net.Uri.parse(cleaned).host?.lowercase()
    }.getOrNull() ?: ""
    val isYouTube = host == "youtube.com" || host == "www.youtube.com" ||
        host == "m.youtube.com" || host == "youtu.be" ||
        host == "www.youtu.be" || host == "music.youtube.com"
    if (!isYouTube) return null
    return when {
        host.endsWith("youtu.be") ->
            cleaned.substringAfter("youtu.be/").substringBefore('?').takeIf { it.isNotBlank() }

        cleaned.contains("/shorts/") ->
            cleaned.substringAfter("/shorts/").substringBefore('?').takeIf { it.isNotBlank() }

        else -> {
            val vParam = cleaned.substringAfter("?v=", "").substringBefore('&')
            if (vParam.isNotBlank() && vParam.length <= 16) vParam else null
        }
    }
}

internal fun youTubeEmbedUrl(videoId: String): String =
    "https://www.youtube-nocookie.com/embed/$videoId"

internal fun parseMediaLinkUrl(text: String): MarkdownMediaLinkSpec? {
    val trimmed = text.trim()
    if (trimmed.isBlank() || trimmed.length > 2048) return null

    val url = singleMarkdownLinkPattern.find(trimmed)?.groupValues?.get(2)
        ?: bracketedBareUrlLinePattern.find(trimmed)?.groupValues?.get(1)
        ?: if (bareHttpUrlPattern.matches(trimmed)) trimmed else return null
    val cleaned = url.trimEnd('.', ',', ';', '!', '?', '"', '\'')
    if (!cleaned.startsWith("http", ignoreCase = true)) return null

    parseYouTubeVideoId(cleaned)?.let { videoId ->
        return MarkdownMediaLinkSpec(
            url = cleaned,
            kind = MarkdownMediaLinkKind.YouTube,
            label = "YouTube · $videoId",
        )
    }

    val pathOnly = cleaned.substringBefore('#').substringBefore('?')
    val extension = pathOnly.substringAfterLast('.', "").lowercase()
    val displayName = remoteFileDisplayName(cleaned)
    return when {
        extension in directVideoExtensions -> MarkdownMediaLinkSpec(
            url = cleaned,
            kind = MarkdownMediaLinkKind.Video,
            label = displayName,
        )

        extension in directAudioExtensions -> MarkdownMediaLinkSpec(
            url = cleaned,
            kind = MarkdownMediaLinkKind.Audio,
            label = displayName,
        )

        else -> null
    }
}

internal fun parseRemoteImageLinkUrl(text: String): String? {
    val trimmed = text.trim()
    if (trimmed.isBlank() || trimmed.length > 2048) return null
    val url = singleMarkdownLinkPattern.find(trimmed)?.groupValues?.get(2)
        ?: bracketedBareUrlLinePattern.find(trimmed)?.groupValues?.get(1)
        ?: if (bareHttpUrlPattern.matches(trimmed)) trimmed else return null
    val cleaned = url.trimEnd('.', ',', ';', '!', '?', '"', '\'')
    if (!cleaned.startsWith("http", ignoreCase = true)) return null
    val pathOnly = cleaned.substringBefore('#').substringBefore('?')
    val extension = pathOnly.substringAfterLast('.', "").lowercase()
    if (extension !in remoteImageLinkExtensions) return null
    return cleaned
}

internal data class MarkdownEmbedFrameSpec(
    val url: String,
    val title: String,
)

private val iframeSrcPattern = Regex(
    """<iframe\b[^>]*\bsrc\s*=\s*["']([^"']+)["']""",
    RegexOption.IGNORE_CASE,
)

private val embedSrcPattern = Regex(
    """<embed\b[^>]*\bsrc\s*=\s*["']([^"']+)["']""",
    RegexOption.IGNORE_CASE,
)

private val embedTitlePattern = Regex(
    """\btitle\s*=\s*["']([^"']+)["']""",
    RegexOption.IGNORE_CASE,
)

private val embedAltTextPattern = Regex(
    """\balt\s*=\s*["']([^"']+)["']""",
    RegexOption.IGNORE_CASE,
)

internal fun parseEmbedFrameSpec(text: String): MarkdownEmbedFrameSpec? {
    val trimmed = text.trim()
    if (!trimmed.startsWith("<iframe", ignoreCase = true) &&
        !trimmed.startsWith("<embed", ignoreCase = true)
    ) {
        return null
    }
    if (trimmed.length > 4096) return null
    val srcMatch = iframeSrcPattern.find(trimmed)
        ?: embedSrcPattern.find(trimmed)
        ?: return null
    val url = srcMatch.groupValues[1].trim()
    if (!url.startsWith("http://", ignoreCase = true) &&
        !url.startsWith("https://", ignoreCase = true)
    ) {
        return null
    }
    val title = embedTitlePattern.find(trimmed)?.groupValues?.get(1)?.trim().orEmpty()
        .ifBlank { embedAltTextPattern.find(trimmed)?.groupValues?.get(1)?.trim().orEmpty() }
    return MarkdownEmbedFrameSpec(url = url, title = title)
}

internal fun parseMarkdownImage(text: String): MarkdownImageSpec? {
    val match = markdownImagePattern.matchEntire(text) ?: return null
    val normalizedUrl = normalizeMarkdownImageUrl(match.groupValues[2]) ?: return null
    val attributes = parseMarkdownAttributes(match.groupValues.getOrNull(3).orEmpty())
    return MarkdownImageSpec(
        altText = match.groupValues[1].trim(),
        url = normalizedUrl,
        layout = parseMarkdownMediaLayout(
            attributes = attributes,
            defaults = defaultMarkdownImageLayout(),
        ),
    )
}

internal fun parseMarkdownImageSequence(text: String): List<MarkdownImageSpec>? {
    val images = mutableListOf<MarkdownImageSpec>()
    var index = 0

    while (index < text.length) {
        while (index < text.length && text[index].isWhitespace()) index++
        if (index >= text.length) break

        val token = parseMarkdownImageToken(text, index) ?: return null
        images += token.image
        index = token.endExclusive
    }

    return images.takeIf(List<MarkdownImageSpec>::isNotEmpty)
}

private data class MarkdownImageToken(
    val image: MarkdownImageSpec,
    val endExclusive: Int,
)

private fun parseMarkdownImageToken(
    text: String,
    startIndex: Int,
): MarkdownImageToken? {
    if (text.startsWith("[![", startIndex)) {
        val inner = parseDirectMarkdownImageToken(text, startIndex + 1) ?: return null
        if (inner.endExclusive >= text.length || text[inner.endExclusive] != ']') return null
        val destinationStart = inner.endExclusive + 1
        if (destinationStart >= text.length || text[destinationStart] != '(') return null
        val outerEnd = findMarkdownDestinationEnd(text, destinationStart) ?: return null
        return MarkdownImageToken(inner.image, outerEnd + 1)
    }

    return parseDirectMarkdownImageToken(text, startIndex)
}

private fun parseDirectMarkdownImageToken(
    text: String,
    startIndex: Int,
): MarkdownImageToken? {
    if (!text.startsWith("![", startIndex)) return null
    val destinationMarker = text.indexOf("](", startIndex + 2)
    if (destinationMarker < 0) return null
    val destinationStart = destinationMarker + 1
    val destinationEnd = findMarkdownDestinationEnd(text, destinationStart) ?: return null

    var endExclusive = destinationEnd + 1
    if (endExclusive < text.length && text[endExclusive] == '{') {
        val attributesEnd = text.indexOf('}', endExclusive + 1)
        if (attributesEnd < 0) return null
        endExclusive = attributesEnd + 1
    }

    val image = parseMarkdownImage(text.substring(startIndex, endExclusive)) ?: return null
    return MarkdownImageToken(image, endExclusive)
}

private fun findMarkdownDestinationEnd(
    text: String,
    openingParenthesis: Int,
): Int? {
    if (openingParenthesis !in text.indices || text[openingParenthesis] != '(') return null

    var nestedParentheses = 0
    var index = openingParenthesis + 1
    while (index < text.length) {
        val character = text[index]
        if (character == '\\' && index + 1 < text.length) {
            index += 2
            continue
        }
        when (character) {
            '(' -> nestedParentheses++
            ')' -> {
                if (nestedParentheses == 0) return index
                nestedParentheses--
            }
        }
        index++
    }
    return null
}

internal fun parseMarkdownCodeFenceHeader(
    line: String,
): MarkdownCodeFenceHeader {
    val match = markdownCodeFenceHeaderPattern.matchEntire(line.trim())
    val language = match?.groupValues?.getOrNull(1).orEmpty().trim()
    val attributes = parseMarkdownAttributes(match?.groupValues?.getOrNull(2).orEmpty())
    return MarkdownCodeFenceHeader(language = language, attributes = attributes)
}

internal fun parseMarkdownAttributes(
    rawAttributes: String,
): Map<String, String> {
    val trimmed = rawAttributes.trim()
        .removePrefix("{")
        .removeSuffix("}")
        .trim()
    if (trimmed.isBlank()) return emptyMap()

    val attributes = linkedMapOf<String, String>()
    markdownAttributePattern.findAll(trimmed).forEach { match ->
        val key = match.groupValues[1].trim().lowercase()
        if (key.isBlank()) return@forEach
        val rawValue = listOf(
            match.groupValues[2],
            match.groupValues[3],
            match.groupValues[4],
        ).firstOrNull { it.isNotEmpty() } ?: "true"
        attributes[key] = rawValue.trim()
    }
    return attributes
}

internal fun parseMarkdownMediaLayout(
    attributes: Map<String, String>,
    defaults: MarkdownMediaLayout,
): MarkdownMediaLayout {
    if (attributes.isEmpty()) return defaults

    fun attributeValue(vararg keys: String): String? =
        keys.firstNotNullOfOrNull { attributes[it.lowercase()]?.trim()?.takeIf(String::isNotBlank) }

    val hasExplicitMaxHeight = attributeValue("max-height", "max_height", "maxheight") != null
    val showAll = attributeValue("show-all", "show_all", "showall", "full")
        ?.let(::parseMarkdownBoolean)
        ?: defaults.showAll
    val scroll = attributeValue("scroll")
        ?.let(::parseMarkdownBoolean)
        ?: defaults.scroll

    return MarkdownMediaLayout(
        width = attributeValue("width", "w")?.let(::parseMarkdownMediaWidth) ?: defaults.width,
        heightDp = attributeValue("height", "h")?.let(::parseMarkdownDp) ?: defaults.heightDp,
        minHeightDp = attributeValue("min-height", "min_height", "minheight")
            ?.let(::parseMarkdownDp)
            ?: defaults.minHeightDp,
        maxHeightDp = when {
            showAll && !hasExplicitMaxHeight -> null
            else -> attributeValue("max-height", "max_height", "maxheight")
                ?.let(::parseMarkdownDp)
                ?: defaults.maxHeightDp
        },
        fit = attributeValue("fit")?.let(::parseMarkdownMediaFit) ?: defaults.fit,
        scroll = if (showAll) false else scroll,
        showAll = showAll,
    )
}

internal fun normalizeMarkdownImageUrl(rawUrl: String): String? {
    val trimmed = rawUrl.trim()
    if (trimmed.isBlank()) return null

    val withoutTitle = extractMarkdownLinkDestination(trimmed).orEmpty()
    val normalized = withoutTitle
        .removeSurrounding("<", ">")
        .replace("&amp;", "&")
        .trim()
    return normalized.ifBlank { null }
}

internal fun extractMarkdownLinkDestination(rawDestination: String): String? {
    val trimmed = rawDestination.trim()
    if (trimmed.isBlank()) return null

    if (trimmed.startsWith("<")) {
        val endIndex = trimmed.indexOf('>')
        if (endIndex > 1) {
            return trimmed.substring(1, endIndex).trim().ifBlank { null }
        }
    }

    val destination = StringBuilder()
    var nestedParentheses = 0
    var index = 0

    while (index < trimmed.length) {
        val character = trimmed[index]
        if (character == '\\' && index + 1 < trimmed.length) {
            destination.append(trimmed[index + 1])
            index += 2
            continue
        }
        if (character.isWhitespace() && nestedParentheses == 0) {
            break
        }
        when (character) {
            '(' -> nestedParentheses++
            ')' -> if (nestedParentheses > 0) {
                nestedParentheses--
            }
        }
        destination.append(character)
        index++
    }

    return destination.toString().trim().ifBlank { null }
}

private fun parseMarkdownMediaWidth(
    rawValue: String,
): MarkdownMediaWidth? {
    val trimmed = rawValue.trim().lowercase()
    if (trimmed.isBlank()) return null
    return when {
        trimmed == "full" -> null
        trimmed.endsWith("%") -> {
            val fraction = trimmed.removeSuffix("%").toFloatOrNull()?.div(100f) ?: return null
            MarkdownMediaWidth.Fraction(fraction.coerceIn(0.1f, 1f))
        }

        else -> parseMarkdownDp(trimmed)?.let(MarkdownMediaWidth::DpValue)
    }
}

private fun parseMarkdownDp(
    rawValue: String,
): Int? {
    val normalized = rawValue.trim().lowercase()
        .removeSuffix("dp")
        .removeSuffix("px")
        .trim()
    return normalized.toIntOrNull()?.takeIf { it > 0 }
}

private fun parseMarkdownBoolean(
    rawValue: String,
): Boolean? = when (rawValue.trim().lowercase()) {
    "1", "true", "yes", "on" -> true
    "0", "false", "no", "off" -> false
    else -> null
}

private fun parseMarkdownMediaFit(
    rawValue: String,
): MarkdownMediaFit = when (rawValue.trim().lowercase()) {
    "cover" -> MarkdownMediaFit.Cover
    else -> MarkdownMediaFit.Contain
}
