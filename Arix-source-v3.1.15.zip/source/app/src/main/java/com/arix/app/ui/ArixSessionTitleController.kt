package com.arix.app.ui

import com.arix.app.data.AppSettings
import com.arix.app.data.LlmMessage
import com.arix.app.data.LlmTextPart
import com.arix.app.data.thinkingCatalogKey
import com.arix.app.data.resolveDefaultChatModelKey
import com.arix.app.data.resolveDefaultTitleModelKey
import com.arix.app.data.resolveModelSettings
import com.arix.app.data.isProviderSetupValid
import com.arix.app.data.pi.PiCompletionClient
import com.arix.app.data.ChatRepository
import com.arix.app.data.LlmProviderConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

internal class ArixSessionTitleController(
    private val scope: CoroutineScope,
    private val completionClient: PiCompletionClient,
    private val chatRepository: () -> ChatRepository?,
    private val providerConfigs: () -> List<LlmProviderConfig>,
    private val thinkingLevelClamps: () -> Map<String, Map<String, String>>,
    private val reasoningModels: () -> Set<String>,
    private val updateSession: (String, (ChatSession) -> ChatSession?) -> Unit,
) {

    fun generateSessionTitle(
        sessionId: String,
        seedMessage: ChatMessage,
        settings: AppSettings,
    ) {
        if (!settings.isProviderSetupValid()) {
            return
        }

        val titleInput = buildTitleGenerationInput(seedMessage)
        if (titleInput.isBlank()) return

        scope.launch {
            val configs = providerConfigs()
            val titleSettings = resolveModelSettings(
                baseSettings = settings,
                providerConfigs = configs,
                preferredModelKey = resolveDefaultTitleModelKey(settings, configs),
                fallbackModelKey = resolveDefaultChatModelKey(settings, configs),
            )
            val modelKey = thinkingCatalogKey(titleSettings.piProviderId, titleSettings.modelId)
            val levelMap = thinkingLevelClamps()[modelKey].orEmpty()
            val isReasoningModel = modelKey in reasoningModels()
            val title = completionClient.completeOnce(
                settings = titleSettings,
                systemPrompt = SessionTitleSystemPrompt,
                messages = listOf(
                    LlmMessage(
                        role = "user",
                        contentParts = listOf(LlmTextPart(titleInput)),
                    )
                ),
                disableReasoning = true,
                thinkingLevelMap = levelMap,
                isReasoningModel = isReasoningModel,
            ).getOrNull()
                ?.assistantText
                ?.sanitizeGeneratedSessionTitle()
                .orEmpty()

            if (title.isBlank()) return@launch

            val seedStillFirstUserMessage = runCatching {
                chatRepository()
                    ?.getSessionWithMessages(sessionId)
                    ?.messages
                    ?.firstOrNull { it.author == MessageAuthor.User }
                    ?.id == seedMessage.id
            }.getOrDefault(false)
            if (!seedStillFirstUserMessage) return@launch

            updateSession(sessionId) { session ->
                if (session.hasCustomTitle) {
                    null
                } else {
                    session.copy(
                        title = title,
                        hasCustomTitle = true,
                    )
                }
            }
        }
    }

    internal fun buildTitleGenerationInput(
        message: ChatMessage,
    ): String = buildString {
        val text = message.text.trim()
        if (text.isNotBlank()) {
            appendLine("First user message:")
            appendLine(text)
        }
        if (message.attachments.isNotEmpty()) {
            if (isNotEmpty()) appendLine()
            appendLine("Attachments:")
            message.attachments.forEach { attachment ->
                appendLine("- ${attachment.name}")
            }
        }
    }.trim()

    internal fun String.sanitizeGeneratedSessionTitle(): String =
        lineSequence()
            .map { line ->
                line.trim()
                    .removePrefix("Title:")
                    .removePrefix("title:")
                    .trim()
                    .trim('"', '\'', '`')
            }
            .firstOrNull { it.isNotBlank() }
            .orEmpty()
            .trimEnd('.', '!', '?')
            .take(36)

    private companion object {
        const val SessionTitleSystemPrompt =
            "Generate a concise chat title for this conversation. Return only the title, in the user's language when possible, with no quotes, no emoji, and at most 6 words."
    }
}
