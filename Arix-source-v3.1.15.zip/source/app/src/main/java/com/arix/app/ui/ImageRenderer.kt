package com.arix.app.ui

import android.content.Context
import android.util.LruCache
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.CompletableDeferred
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.GestureDetector
import android.view.MotionEvent
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.view.ViewCompat
import com.arix.app.ArixApplication
import com.arix.app.R
import com.arix.app.data.LocalRuntimeId
import com.arix.app.data.RuntimeWorkspaceFileBridge
import com.arix.app.data.WorkspaceFileBridge
import com.arix.app.ui.theme.ArixBackground
import com.arix.app.ui.theme.ArixOnSurface
import com.arix.app.ui.theme.ArixOnSurfaceVariant
import com.arix.app.ui.theme.ArixOutline
import com.arix.app.ui.theme.ArixOutlineSoft
import com.arix.app.ui.theme.ArixPrimary
import com.arix.app.ui.theme.ArixSecondary
import com.arix.app.ui.theme.ArixSurface
import com.arix.app.ui.theme.ArixSurfaceHigh
import com.arix.app.ui.theme.ArixSurfaceVariant
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.URLDecoder
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.util.Base64
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

private const val MaxMarkdownImageBytes = 8 * 1024 * 1024

internal const val DefaultImageMaxHeightDp = 420

private val MarkdownImageHttpClient: OkHttpClient by lazy {
    OkHttpClient.Builder()
        .followRedirects(true)
        .followSslRedirects(true)
        .callTimeout(20, TimeUnit.SECONDS)
        .build()
}

private data class MarkdownImageLoadResult(
    val bitmap: ImageBitmap? = null,
    val html: String? = null,
    val error: String? = null,
    val localBinary: MarkdownImageBinary? = null,
)

internal data class MarkdownImageBinary(
    val bytes: ByteArray,
    val mimeType: String? = null,
)

@Composable
internal fun MarkdownImageBlock(
    image: MarkdownImageSpec,
    workspaceDirectory: String?,
    allowRootImageRead: Boolean,
    onLinkClick: (String) -> Unit,
) {
    val context = LocalContext.current
    val appRuntime = remember(context) {
        (context.applicationContext as? ArixApplication)?.runtime
    }
    val workspaceFileBridge = remember(context, appRuntime) {
        appRuntime?.workspaceFileBridge
            ?: WorkspaceFileBridge(
                context = context,
                termuxRuntime = com.arix.app.runtime.TermuxRuntime(context),
            )
    }
    val runtimeWorkspaceFileBridge = appRuntime?.runtimeWorkspaceFileBridge
    val resolvedUrl = remember(image.url) { normalizeMarkdownImageUrl(image.url).orEmpty() }
    val originalLinkTarget = remember(resolvedUrl, workspaceDirectory) {
        buildMarkdownImageOriginalLinkTarget(
            rawUrl = resolvedUrl,
            workspaceFileBridge = workspaceFileBridge,
            workspaceDirectory = workspaceDirectory,
        )
    }
    val imageState by produceState(
        initialValue = MarkdownImageLoadResult(),
        key1 = resolvedUrl,
        key2 = workspaceDirectory,
        key3 = allowRootImageRead,
    ) {
        value = withContext(Dispatchers.IO) {
            loadMarkdownImageCached(
                context = context,
                workspaceFileBridge = workspaceFileBridge,
                runtimeWorkspaceFileBridge = runtimeWorkspaceFileBridge,
                rawUrl = resolvedUrl,
                workspaceDirectory = workspaceDirectory,
                allowRootImageRead = allowRootImageRead,
            )
        }
    }
    var showPreview by remember(resolvedUrl) { mutableStateOf(false) }
    val canPreview = imageState.bitmap != null || imageState.html != null
    val localBinary = imageState.localBinary

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        MarkdownMediaWidthContainer(layout = image.layout) { widthModifier ->
            when {
                imageState.html != null -> MarkdownHtmlBlock(
                    html = imageState.html!!,
                    layout = image.layout,
                    defaultMinHeightDp = 1,
                    defaultMaxHeightDp = DefaultImageMaxHeightDp,
                    modifier = widthModifier
                        .clip(RoundedCornerShape(8.dp)),
                    backgroundColor = Color.Transparent,
                    onTap = if (canPreview) {
                        { showPreview = true }
                    } else {
                        null
                    },
                )

                imageState.bitmap != null -> MarkdownBitmapImageBlock(
                    bitmap = imageState.bitmap!!,
                    altText = image.altText,
                    layout = image.layout,
                    modifier = widthModifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { showPreview = true },
                )

                else -> Box(
                    modifier = widthModifier
                        .heightIn(
                            min = 72.dp,
                            max = (image.layout.maxHeightDp ?: DefaultImageMaxHeightDp).dp,
                        )
                        .clip(RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center,
                ) {
                    if (imageState.error != null) {
                        Text(
                            text = imageState.error.orEmpty(),
                            style = MaterialTheme.typography.bodyMedium,
                            color = ArixOnSurfaceVariant,
                        )
                    } else {
                        CircularProgressIndicator()
                    }
                }
            }
        }
        if (image.altText.isNotBlank()) {
            Text(
                text = image.altText,
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
            )
        }
        val isRemoteImage = resolvedUrl.startsWith("http://", ignoreCase = true) ||
            resolvedUrl.startsWith("https://", ignoreCase = true)
        when {
            isRemoteImage -> MarkdownRemoteMediaActions(
                url = resolvedUrl,
                fileName = resolvedUrl.substringAfterLast('/').ifBlank { image.altText },
                mimeType = localBinary?.mimeType,
                bytes = localBinary?.bytes,
                onOpenOriginal = originalLinkTarget,
                onOpenLink = onLinkClick,
            )

            localBinary != null -> MarkdownLocalMediaActions(
                fileName = resolvedUrl.substringAfterLast('/').ifBlank { image.altText },
                mimeType = localBinary.mimeType,
                bytes = localBinary.bytes,
            )

            else -> if (!originalLinkTarget.isNullOrBlank() && !originalLinkTarget.startsWith("arix-local-file")) {
                Text(
                    text = stringResource(R.string.markdown_open_original),
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixPrimary,
                    modifier = Modifier.clickable { onLinkClick(originalLinkTarget) },
                )
            }
        }
    }

    if (showPreview && canPreview) {
        val bitmap = imageState.bitmap
        if (bitmap != null) {
            ArixMediaViewerDialog(
                onDismiss = { showPreview = false },
                bitmap = bitmap,
                imageBytes = localBinary?.bytes,
                imageMimeType = localBinary?.mimeType.orEmpty(),
                remoteUrl = resolvedUrl.takeIf { url ->
                    url.startsWith("http://", ignoreCase = true) || url.startsWith("https://", ignoreCase = true)
                },
                title = image.altText.ifBlank { resolvedUrl.substringAfterLast('/') },
                detail = listOfNotNull(
                    "${bitmap.width}x${bitmap.height}",
                    localBinary?.bytes?.let { bytes -> ArixMediaActions.formatFileSize(bytes.size.toLong()) },
                ).joinToString(" · "),
                fileName = resolvedUrl.substringAfterLast('/').ifBlank { "arix-image.jpg" },
            )
        } else {
            MarkdownImagePreviewDialog(
                altText = image.altText,
                imageState = imageState,
                originalLinkTarget = originalLinkTarget,
                onDismiss = { showPreview = false },
                onOpenLink = onLinkClick,
            )
        }
    }
}

@Composable
internal fun MarkdownImageGroup(
    images: List<MarkdownImageSpec>,
) {
    MarkdownHtmlBlock(
        html = remember(images) { buildMarkdownBadgeGroupHtml(images) },
        layout = MarkdownMediaLayout(
            minHeightDp = 1,
            maxHeightDp = 120,
            showAll = true,
        ),
        defaultMinHeightDp = 1,
        defaultMaxHeightDp = 120,
        modifier = Modifier.fillMaxWidth(),
        backgroundColor = Color.Transparent,
    )
}

@Composable
private fun MarkdownLocalMediaActions(
    fileName: String,
    mimeType: String?,
    bytes: ByteArray,
) {
    val context = LocalContext.current
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var working by remember(fileName) { mutableStateOf(false) }
    var message by remember(fileName) { mutableStateOf("") }
    val safeMime = mimeType ?: "application/octet-stream"

    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        MarkdownMediaActionPill(
            label = stringResource(R.string.common_save),
            icon = Icons.Rounded.Download,
            enabled = !working,
        ) {
            working = true
            message = ""
            scope.launch {
                val outcome = withContext(Dispatchers.IO) {
                    runCatching {
                        ArixMediaActions.downloadToDownloads(
                            context = context,
                            fileName = fileName,
                            mimeType = safeMime,
                            bytes = bytes,
                        )
                    }
                }
                working = false
                message = if (outcome.isSuccess) {
                    context.getString(R.string.markdown_media_saved_downloads)
                } else {
                    outcome.exceptionOrNull()?.message
                        ?: context.getString(R.string.markdown_image_error_read_workspace)
                }
            }
        }
        MarkdownMediaActionPill(
            label = stringResource(R.string.common_share),
            icon = Icons.Rounded.Share,
            enabled = !working,
        ) {
            working = true
            message = ""
            scope.launch {
                val staged = withContext(Dispatchers.IO) {
                    runCatching {
                        ArixMediaActions.stageShareFile(context, fileName, bytes)
                    }.getOrNull()
                }
                working = false
                if (staged == null || !ArixMediaActions.shareStagedFile(context, staged, safeMime)) {
                    message = context.getString(R.string.markdown_image_error_read_workspace)
                }
            }
        }
    }
    if (message.isNotBlank()) {
        Text(
            text = message,
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
        )
    }
}

@Composable
private fun MarkdownRemoteMediaActions(
    url: String,
    fileName: String,
    mimeType: String?,
    bytes: ByteArray?,
    onOpenOriginal: String?,
    onOpenLink: (String) -> Unit,
) {
    val context = LocalContext.current
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var working by remember(url) { mutableStateOf(false) }
    var message by remember(url) { mutableStateOf("") }
    val safeMime = mimeType ?: "image/jpeg"
    val safeName = fileName.ifBlank { "arix-image.jpg" }

    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        MarkdownMediaActionPill(
            label = stringResource(R.string.common_save),
            icon = Icons.Rounded.Download,
            enabled = !working,
        ) {
            working = true
            message = ""
            scope.launch {
                val outcome = withContext(Dispatchers.IO) {
                    runCatching {
                        if (bytes != null) {
                            ArixMediaActions.downloadToDownloads(
                                context = context,
                                fileName = safeName,
                                mimeType = safeMime,
                                bytes = bytes,
                            )
                            0L
                        } else {
                            ArixMediaActions.downloadUrlToDownloads(
                                context = context,
                                url = url,
                                fileName = safeName,
                                mimeType = safeMime,
                            )
                        }
                    }
                }
                working = false
                message = if (outcome.isSuccess) {
                    context.getString(R.string.markdown_media_saved_downloads)
                } else {
                    outcome.exceptionOrNull()?.message
                        ?: context.getString(R.string.markdown_image_error_read_workspace)
                }
            }
        }
        MarkdownMediaActionPill(
            label = stringResource(R.string.common_share),
            icon = Icons.Rounded.Share,
            enabled = !working,
        ) {
            working = true
            message = ""
            scope.launch {
                val shared = withContext(Dispatchers.IO) {
                    runCatching {
                        if (bytes != null) {
                            ArixMediaActions.shareBytes(context, safeName, safeMime, bytes)
                        } else {
                            val staged = ArixMediaActions.stageShareUrlFile(
                                context = context,
                                url = url,
                                fileName = safeName,
                            )
                            ArixMediaActions.shareStagedFile(context, staged, safeMime)
                        }
                    }.getOrDefault(false)
                }
                working = false
                if (!shared) {
                    message = context.getString(R.string.markdown_image_error_read_workspace)
                }
            }
        }
    }
    Row(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.padding(top = 2.dp),
    ) {
        if (!onOpenOriginal.isNullOrBlank() && !onOpenOriginal.startsWith("arix-local-file")) {
            Text(
                text = stringResource(R.string.markdown_open_original),
                style = MaterialTheme.typography.bodySmall,
                color = ArixPrimary,
                modifier = Modifier.clickable { onOpenLink(onOpenOriginal) },
            )
        }
    }
    if (message.isNotBlank()) {
        Text(
            text = message,
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
        )
    }
}

@Composable
private fun MarkdownMediaActionPill(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    enabled: Boolean,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(ArixSurfaceHigh)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        androidx.compose.material3.Icon(
            imageVector = icon,
            contentDescription = null,
            tint = ArixPrimary,
            modifier = Modifier.size(14.dp),
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = ArixPrimary,
        )
    }
}

@Composable
private fun MarkdownBitmapImageBlock(
    bitmap: ImageBitmap,
    altText: String,
    layout: MarkdownMediaLayout,
    modifier: Modifier = Modifier,
) {
    val contentScale = if (layout.fit == MarkdownMediaFit.Cover) {
        ContentScale.Crop
    } else {
        ContentScale.Fit
    }
    BoxWithConstraints(modifier = modifier) {
        val resolvedMaxHeight = (layout.maxHeightDp ?: DefaultImageMaxHeightDp).dp
        val explicitHeight = layout.heightDp?.dp
        val naturalWidth = if (bitmap.width > 0) {
            bitmap.width.dp.coerceAtMost(maxWidth)
        } else {
            maxWidth
        }
        val renderWidth = if (layout.width == null) naturalWidth else maxWidth
        val naturalHeight = if (bitmap.width > 0 && bitmap.height > 0) {
            renderWidth * (bitmap.height.toFloat() / bitmap.width.toFloat())
        } else {
            resolvedMaxHeight
        }
        val containerHeight = when {
            layout.showAll -> naturalHeight.coerceAtLeast(1.dp)
            explicitHeight != null -> explicitHeight
            else -> naturalHeight.coerceAtMost(resolvedMaxHeight).coerceAtLeast(1.dp)
        }
        val needsVerticalScroll = !layout.showAll && layout.scroll && naturalHeight > containerHeight

        Box(
            modifier = Modifier
                .width(renderWidth)
                .height(containerHeight),
            contentAlignment = if (needsVerticalScroll) Alignment.TopCenter else Alignment.Center,
        ) {
            when {
                needsVerticalScroll -> Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState()),
                ) {
                    Image(
                        bitmap = bitmap,
                        contentDescription = altText.takeIf { it.isNotBlank() },
                        modifier = Modifier.fillMaxWidth(),
                        contentScale = contentScale,
                    )
                }

                explicitHeight != null || (!layout.showAll && naturalHeight > containerHeight) -> Image(
                    bitmap = bitmap,
                    contentDescription = altText.takeIf { it.isNotBlank() },
                    modifier = Modifier.fillMaxSize(),
                    contentScale = contentScale,
                )

                else -> Image(
                    bitmap = bitmap,
                    contentDescription = altText.takeIf { it.isNotBlank() },
                    modifier = Modifier.fillMaxWidth(),
                    contentScale = contentScale,
                )
            }
        }
    }
}

@Composable
internal fun MarkdownMediaWidthContainer(
    layout: MarkdownMediaLayout,
    content: @Composable (Modifier) -> Unit,
) {
    val outerModifier = if (layout.width is MarkdownMediaWidth.DpValue) {
        Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
    } else {
        Modifier.fillMaxWidth()
    }

    Box(modifier = outerModifier) {
        content(Modifier.markdownMediaWidth(layout.width))
    }
}

private fun Modifier.markdownMediaWidth(
    mediaWidth: MarkdownMediaWidth?,
): Modifier = when (mediaWidth) {
    null -> fillMaxWidth()
    is MarkdownMediaWidth.Fraction -> fillMaxWidth(mediaWidth.value.coerceIn(0.1f, 1f))
    is MarkdownMediaWidth.DpValue -> width(mediaWidth.value.dp)
}

@Composable
private fun MarkdownImagePreviewDialog(
    altText: String,
    imageState: MarkdownImageLoadResult,
    originalLinkTarget: String?,
    onDismiss: () -> Unit,
    onOpenLink: (String) -> Unit,
) {
    val fallbackTitle = stringResource(R.string.markdown_image_preview_title)
    MarkdownPreviewDialogFrame(
        title = altText.ifBlank { fallbackTitle },
        onDismiss = onDismiss,
    ) {
        when {
            imageState.bitmap != null -> MarkdownBitmapPreviewBlock(
                bitmap = imageState.bitmap,
                altText = altText,
                maxHeightDp = PreviewDialogMaxHeightDp,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(ArixSurfaceHigh),
            )

            imageState.html != null -> MarkdownHtmlBlock(
                html = imageState.html,
                layout = MarkdownMediaLayout(
                    maxHeightDp = PreviewDialogMaxHeightDp,
                    scroll = true,
                    showAll = false,
                ),
                defaultMinHeightDp = 1,
                defaultMaxHeightDp = PreviewDialogMaxHeightDp,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(ArixSurfaceHigh),
                backgroundColor = ArixSurfaceHigh,
            )

            else -> Text(
                text = imageState.error ?: stringResource(R.string.markdown_preview_unavailable),
                style = MaterialTheme.typography.bodyMedium,
                color = ArixOnSurfaceVariant,
            )
        }

        if (!originalLinkTarget.isNullOrBlank()) {
            Text(
                text = stringResource(R.string.markdown_open_original),
                style = MaterialTheme.typography.bodyMedium,
                color = ArixPrimary,
                modifier = Modifier.clickable { onOpenLink(originalLinkTarget) },
            )
        }
    }
}

@Composable
private fun MarkdownBitmapPreviewBlock(
    bitmap: ImageBitmap,
    altText: String,
    maxHeightDp: Int,
    modifier: Modifier = Modifier,
) {
    BoxWithConstraints(modifier = modifier) {
        val maxHeight = maxHeightDp.dp
        val naturalHeight = if (bitmap.width > 0 && bitmap.height > 0) {
            maxWidth * (bitmap.height.toFloat() / bitmap.width.toFloat())
        } else {
            maxHeight
        }
        val containerHeight = naturalHeight.coerceAtMost(maxHeight).coerceAtLeast(1.dp)
        val needsVerticalScroll = naturalHeight > containerHeight

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(containerHeight)
                .padding(12.dp),
            contentAlignment = if (needsVerticalScroll) Alignment.TopCenter else Alignment.Center,
        ) {
            if (needsVerticalScroll) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .horizontalScroll(rememberScrollState()),
                    contentAlignment = Alignment.TopCenter,
                ) {
                    Image(
                        bitmap = bitmap,
                        contentDescription = altText.takeIf { it.isNotBlank() },
                        modifier = Modifier.fillMaxWidth(),
                        contentScale = ContentScale.Fit,
                    )
                }
            } else {
                Image(
                    bitmap = bitmap,
                    contentDescription = altText.takeIf { it.isNotBlank() },
                    modifier = Modifier.fillMaxWidth(),
                    contentScale = ContentScale.Fit,
                )
            }
        }
    }
}

private val MarkdownImageMemoryCache = object : LruCache<String, MarkdownImageLoadResult>(24 * 1024 * 1024) {
    override fun sizeOf(key: String, value: MarkdownImageLoadResult): Int =
        value.bitmap?.let { bitmap -> bitmap.width * bitmap.height * 4 }
            ?: (value.html?.length ?: 4096).coerceAtMost(1 shl 20)
}

private val MarkdownImageInflight = ConcurrentHashMap<String, CompletableDeferred<MarkdownImageLoadResult>>()

private suspend fun loadMarkdownImageCached(
    context: Context,
    workspaceFileBridge: WorkspaceFileBridge,
    runtimeWorkspaceFileBridge: RuntimeWorkspaceFileBridge?,
    rawUrl: String,
    workspaceDirectory: String?,
    allowRootImageRead: Boolean,
): MarkdownImageLoadResult {
    val cacheKey = "$rawUrl|${workspaceDirectory.orEmpty()}|$allowRootImageRead"
    MarkdownImageMemoryCache.get(cacheKey)?.let { return it }
    val existing = MarkdownImageInflight[cacheKey]
    if (existing != null) return existing.await()
    val deferred = CompletableDeferred<MarkdownImageLoadResult>()
    val winner = MarkdownImageInflight.putIfAbsent(cacheKey, deferred)
    if (winner != null) return winner.await()
    try {
        val result = loadMarkdownImage(
            context = context,
            workspaceFileBridge = workspaceFileBridge,
            runtimeWorkspaceFileBridge = runtimeWorkspaceFileBridge,
            rawUrl = rawUrl,
            workspaceDirectory = workspaceDirectory,
            allowRootImageRead = allowRootImageRead,
        )
        if (result.bitmap != null || result.html != null) {
            MarkdownImageMemoryCache.put(cacheKey, result)
        }
        deferred.complete(result)
        return result
    } finally {
        MarkdownImageInflight.remove(cacheKey, deferred)
    }
}

private suspend fun loadMarkdownImage(
    context: Context,
    workspaceFileBridge: WorkspaceFileBridge,
    runtimeWorkspaceFileBridge: RuntimeWorkspaceFileBridge?,
    rawUrl: String,
    workspaceDirectory: String?,
    allowRootImageRead: Boolean,
): MarkdownImageLoadResult = runCatching {
    val loadPreviewError = context.getString(R.string.markdown_image_error_load_preview)
    val readDataError = context.getString(R.string.markdown_image_error_read_data)
    val readWorkspaceError = context.getString(R.string.markdown_image_error_read_workspace)
    val normalizedUrl = normalizeMarkdownImageUrl(rawUrl)
        ?: error(loadPreviewError)
    var localBinary: MarkdownImageBinary? = null
    val imageBinary = when {
        normalizedUrl.startsWith("http://", ignoreCase = true) ||
            normalizedUrl.startsWith("https://", ignoreCase = true) -> {
            fetchRemoteMarkdownImage(context, normalizedUrl)
        }

        normalizedUrl.startsWith("data:", ignoreCase = true) -> {
            decodeDataUrl(context, normalizedUrl)
        }

        normalizedUrl.startsWith("content://", ignoreCase = true) -> {
            readContentMarkdownImage(context, normalizedUrl)
        }

        else -> {
            val localFilePath = parseAssistantLocalFileLink(normalizedUrl)
            val binary = loadWorkspaceImageBinary(
                context = context,
                workspaceFileBridge = workspaceFileBridge,
                runtimeWorkspaceFileBridge = runtimeWorkspaceFileBridge,
                rawPath = localFilePath ?: normalizedUrl,
                workingDirectory = workspaceDirectory?.trim().orEmpty(),
                allowRootImageRead = allowRootImageRead,
                readDataError = readDataError,
                readWorkspaceError = readWorkspaceError,
            ) ?: readLocalMarkdownImage(context, normalizedUrl)
            localBinary = binary
            binary
        }
    } ?: error(loadPreviewError)

    decodeMarkdownImageResult(
        context = context,
        imageBinary = imageBinary,
        rawUrl = normalizedUrl,
    ).let { result ->
        if (localBinary != null) result.copy(localBinary = localBinary) else result
    }
}.getOrElse { throwable ->
    MarkdownImageLoadResult(
        error = throwable.message ?: context.getString(R.string.markdown_image_error_load_preview),
    )
}

private suspend fun loadWorkspaceImageBinary(
    context: Context,
    workspaceFileBridge: WorkspaceFileBridge,
    runtimeWorkspaceFileBridge: RuntimeWorkspaceFileBridge?,
    rawPath: String,
    workingDirectory: String,
    allowRootImageRead: Boolean,
    readDataError: String,
    readWorkspaceError: String,
) : MarkdownImageBinary? {
    val resolvedPath = if (rawPath.startsWith("file://", ignoreCase = true)) {
        workspaceFileBridge.resolveLinkPath(rawPath)
    } else {
        workspaceFileBridge.resolveWorkspacePath(
            path = rawPath,
            workingDirectory = workingDirectory,
        )
    }
    val workspaceResult = runtimeWorkspaceFileBridge?.readWorkspaceFile(
        path = resolvedPath,
        workingDirectory = workingDirectory,
        defaultRuntimeId = LocalRuntimeId.Termux,
        byteLimit = MaxMarkdownImageBytes,
    ) ?: workspaceFileBridge.readWorkspaceFile(
        path = resolvedPath,
        workingDirectory = workingDirectory,
        byteLimit = MaxMarkdownImageBytes,
    )
    val payload = workspaceResult.getOrElse { workspaceThrowable ->
        error(workspaceThrowable.message ?: readWorkspaceError)
    }
    return MarkdownImageBinary(
        bytes = payload.bytes,
        mimeType = workspaceFileBridge.guessMimeType(resolvedPath).ifBlank { null },
    )
}

private fun readLocalMarkdownImage(
    context: Context,
    rawPath: String,
): MarkdownImageBinary? {
    val file = File(rawPath)
    if (!file.exists() || !file.isFile) return null
    val byteLimit = MaxMarkdownImageBytes + 1
    val bytes = file.inputStream().use { readBytesWithLimit(context, it, byteLimit) }
    ensureMarkdownImageWithinLimit(context, bytes.size)
    return MarkdownImageBinary(
        bytes = bytes,
        mimeType = inferMarkdownImageMimeType(
            reportedMimeType = guessMimeTypeFromPath(file.name),
            rawUrl = rawPath,
            bytes = bytes,
        ),
    )
}

private fun readContentMarkdownImage(
    context: Context,
    rawUrl: String,
): MarkdownImageBinary? {
    val uri = Uri.parse(rawUrl)
    val bytes = context.contentResolver.openInputStream(uri)?.use { input ->
        readBytesWithLimit(context, input, MaxMarkdownImageBytes + 1)
    } ?: return null
    ensureMarkdownImageWithinLimit(context, bytes.size)
    return MarkdownImageBinary(
        bytes = bytes,
        mimeType = inferMarkdownImageMimeType(
            reportedMimeType = context.contentResolver.getType(uri),
            rawUrl = rawUrl,
            bytes = bytes,
        ),
    )
}

private fun fetchRemoteMarkdownImage(
    context: Context,
    url: String,
): MarkdownImageBinary {
    val request = Request.Builder()
        .url(url)
        .header("Accept", "image/*,*/*;q=0.8")
        .header("User-Agent", "Arix/0.1")
        .build()
    return MarkdownImageHttpClient.newCall(request).execute().use { response ->
        if (!response.isSuccessful) {
            error(context.getString(R.string.markdown_image_error_load_preview_http, response.code))
        }
        val body = response.body ?: error(context.getString(R.string.markdown_image_error_load_preview))
        val bytes = body.byteStream().use { readBytesWithLimit(context, it, MaxMarkdownImageBytes + 1) }
        ensureMarkdownImageWithinLimit(context, bytes.size)
        MarkdownImageBinary(
            bytes = bytes,
            mimeType = inferMarkdownImageMimeType(
                reportedMimeType = body.contentType()?.toString(),
                rawUrl = url,
                bytes = bytes,
            ),
        )
    }
}

internal fun decodeDataUrl(
    context: Context,
    dataUrl: String,
): MarkdownImageBinary {
    val commaIndex = dataUrl.indexOf(',')
    require(commaIndex > "data:".length) { context.getString(R.string.markdown_image_error_load_preview) }

    val metadata = dataUrl.substring("data:".length, commaIndex)
    val payload = dataUrl.substring(commaIndex + 1)
    val metadataParts = metadata.split(';')
    val reportedMimeType = metadataParts.firstOrNull().orEmpty().ifBlank { null }
    val isBase64 = metadataParts.any { it.equals("base64", ignoreCase = true) }
    val bytes = if (isBase64) {
        Base64.getDecoder().decode(payload)
    } else {
        URLDecoder.decode(payload, Charsets.UTF_8.name()).toByteArray(Charsets.UTF_8)
    }
    ensureMarkdownImageWithinLimit(context, bytes.size)
    return MarkdownImageBinary(
        bytes = bytes,
        mimeType = inferMarkdownImageMimeType(
            reportedMimeType = reportedMimeType,
            rawUrl = dataUrl,
            bytes = bytes,
        ),
    )
}

private fun decodeMarkdownImageResult(
    context: Context,
    imageBinary: MarkdownImageBinary,
    rawUrl: String,
): MarkdownImageLoadResult {
    val bitmap = decodeMarkdownBitmap(imageBinary.bytes)
    if (bitmap != null) {
        return MarkdownImageLoadResult(bitmap = bitmap)
    }

    val mimeType = inferMarkdownImageMimeType(
        reportedMimeType = imageBinary.mimeType,
        rawUrl = rawUrl,
        bytes = imageBinary.bytes,
    )
    if (mimeType != null) {
        if (isSvgMarkdownImage(mimeType)) {
            val svg = decodeMarkdownSvgText(imageBinary.bytes)
            if (svg.isNotBlank()) {
                return MarkdownImageLoadResult(html = buildMarkdownInlineSvgHtml(svg))
            }
        }
        val imageUrl = writeMarkdownImageCacheFile(
            context = context,
            bytes = imageBinary.bytes,
            rawUrl = rawUrl,
            mimeType = mimeType,
        ) ?: buildImageDataUrl(imageBinary.bytes, mimeType)
        return MarkdownImageLoadResult(
            html = buildMarkdownImageHtml(
                imageUrl = imageUrl,
                loadErrorMessage = context.getString(R.string.markdown_image_error_load_preview),
            ),
        )
    }

    error(context.getString(R.string.markdown_image_error_load_preview))
}

internal fun inferMarkdownImageMimeType(
    reportedMimeType: String?,
    rawUrl: String,
    bytes: ByteArray,
): String? {
    val normalizedMimeType = reportedMimeType
        ?.substringBefore(';')
        ?.trim()
        ?.lowercase()
        ?.ifBlank { null }
    if (looksLikeSvgDocument(bytes) || normalizedMimeType?.contains("svg") == true) return "image/svg+xml"
    if (bytes.startsWith(byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47))) return "image/png"
    if (bytes.startsWith(byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte()))) return "image/jpeg"
    if (bytes.startsWith("GIF87a".toByteArray()) || bytes.startsWith("GIF89a".toByteArray())) return "image/gif"
    if (bytes.size >= 12 &&
        bytes.copyOfRange(0, 4).contentEquals("RIFF".toByteArray()) &&
        bytes.copyOfRange(8, 12).contentEquals("WEBP".toByteArray())
    ) {
        return "image/webp"
    }

    if (normalizedMimeType?.startsWith("image/") == true) {
        return normalizedMimeType
    }

    return guessMimeTypeFromPath(rawUrl)
}

internal fun ByteArray.startsWith(prefix: ByteArray): Boolean =
    size >= prefix.size && copyOfRange(0, prefix.size).contentEquals(prefix)

private fun decodeMarkdownBitmap(bytes: ByteArray): ImageBitmap? {
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.let { return it.asImageBitmap() }
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return null
    return runCatching {
        ImageDecoder.decodeBitmap(ImageDecoder.createSource(ByteBuffer.wrap(bytes))).asImageBitmap()
    }.getOrNull()
}

private fun looksLikeSvgDocument(bytes: ByteArray): Boolean {
    val preview = bytes.toString(Charsets.UTF_8).trimStart()
    return preview.startsWith("<svg", ignoreCase = true) ||
        preview.startsWith("<?xml", ignoreCase = true) && preview.contains("<svg", ignoreCase = true)
}

private fun buildImageDataUrl(
    bytes: ByteArray,
    mimeType: String,
): String = "data:$mimeType;base64,${Base64.getEncoder().encodeToString(bytes)}"

private fun isSvgMarkdownImage(mimeType: String): Boolean =
    mimeType.substringBefore(';').trim().lowercase().contains("svg")

private fun writeMarkdownImageCacheFile(
    context: Context,
    bytes: ByteArray,
    rawUrl: String,
    mimeType: String,
): String? = runCatching {
    val directory = File(context.cacheDir, "markdown-images").apply { mkdirs() }
    val extension = markdownImageCacheExtension(mimeType, rawUrl)
    val file = File(directory, "${markdownImageCacheKey(rawUrl, bytes)}.$extension")
    if (!file.exists() || file.length() != bytes.size.toLong()) {
        file.outputStream().use { output ->
            output.write(bytes)
            output.flush()
        }
    }
    Uri.fromFile(file).toString()
}.getOrNull()

private fun markdownImageCacheExtension(
    mimeType: String,
    rawUrl: String,
): String = when (mimeType.substringBefore(';').trim().lowercase()) {
    "image/png" -> "png"
    "image/jpeg", "image/jpg" -> "jpg"
    "image/gif" -> "gif"
    "image/webp" -> "webp"
    "image/avif" -> "avif"
    "image/heic", "image/heif" -> "heic"
    "image/bmp", "image/x-bmp" -> "bmp"
    else -> rawUrl
        .substringBefore('?')
        .substringBefore('#')
        .substringAfterLast('.', "")
        .lowercase()
        .takeIf { it.matches(Regex("[a-z0-9]{1,8}")) }
        ?: "img"
}

private fun markdownImageCacheKey(
    rawUrl: String,
    bytes: ByteArray,
): String {
    val digest = MessageDigest.getInstance("SHA-256")
    digest.update(rawUrl.toByteArray(Charsets.UTF_8))
    digest.update(0.toByte())
    digest.update(bytes)
    return digest.digest().joinToString("") { "%02x".format(it) }
}

private fun guessMimeTypeFromPath(rawUrl: String): String? {
    val candidatePath = rawUrl
        .substringAfterLast('/')
        .substringBefore('?')
        .substringBefore('#')
    val extension = candidatePath.substringAfterLast('.', "").lowercase()
    return when (extension) {
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "gif" -> "image/gif"
        "webp" -> "image/webp"
        "svg", "svgz" -> "image/svg+xml"
        "bmp" -> "image/bmp"
        "avif" -> "image/avif"
        else -> null
    }
}

private fun readBytesWithLimit(
    context: Context,
    inputStream: java.io.InputStream,
    byteLimit: Int,
): ByteArray {
    val output = ByteArrayOutputStream()
    val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
    var totalRead = 0

    while (true) {
        val read = inputStream.read(buffer)
        if (read <= 0) break
        totalRead += read
        if (totalRead > byteLimit) {
            error(context.getString(R.string.markdown_image_error_too_large))
        }
        output.write(buffer, 0, read)
    }

    return output.toByteArray()
}

private fun ensureMarkdownImageWithinLimit(context: Context, sizeBytes: Int) {
    if (sizeBytes > MaxMarkdownImageBytes) {
        error(context.getString(R.string.markdown_image_error_too_large))
    }
}
