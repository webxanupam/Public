package com.arix.app.ui

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.arix.app.arixRuntime
import com.arix.app.ui.theme.ArixError
import com.arix.app.ui.theme.ArixOnSurface
import com.arix.app.ui.theme.ArixOnSurfaceVariant
import com.arix.app.ui.theme.ArixOutline
import com.arix.app.ui.theme.ArixPrimary
import com.arix.app.ui.theme.ArixSurface
import com.arix.app.ui.theme.ArixSurfaceHigher
import com.arix.app.ui.theme.ArixSurfaceVariant
import com.arix.app.ui.theme.ArixTertiary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject

internal class TerminalBackgroundRun(
    val runId: String,
    val command: String,
    val startedAtMillis: Long,
) {
    var status: String by mutableStateOf("running")
    var exitCode: String by mutableStateOf("")
    var stdoutTail: String by mutableStateOf("")
    var stderrTail: String by mutableStateOf("")
    var expanded: Boolean by mutableStateOf(false)

    val isRunning: Boolean get() = status == "running"
}

internal class TerminalBackgroundCommandsState(
    private val scope: kotlinx.coroutines.CoroutineScope,
) {
    val runs = mutableStateListOf<TerminalBackgroundRun>()

    fun launch(command: String, onStarted: (Boolean) -> Unit) {
        if (command.isBlank()) {
            onStarted(false)
            return
        }
        scope.launch {
            val started = runCatching {
                val context = ArixTerminalContextRef.current
                val runtime = context?.arixRuntime?.termuxRuntime ?: return@runCatching false
                val arguments = JSONObject()
                    .put("command", command)
                    .put("working_directory", runtime.homeDirectory)
                val result = runtime.execute(arguments.toString())
                val parsed = runCatching { JSONObject(result) }.getOrNull()
                val runId = parsed?.optString("run_id").orEmpty()
                if (parsed != null && runId.isNotBlank()) {
                    val newRun = TerminalBackgroundRun(runId, command, System.currentTimeMillis())
                    runs.add(0, newRun)
                    refreshRun(newRun)
                    true
                } else {
                    false
                }
            }.getOrDefault(false)
            onStarted(started)
        }
    }

    fun stop(run: TerminalBackgroundRun) {
        scope.launch {
            runCatching {
                val context = ArixTerminalContextRef.current ?: return@launch
                val runtime = context.arixRuntime.termuxRuntime
                runtime.killExecution(JSONObject().put("run_id", run.runId).toString())
            }
            refreshRun(run)
        }
    }

    fun refreshAll() {
        val snapshot = runs.toList()
        if (snapshot.isEmpty()) return
        scope.launch {
            snapshot.forEach { refreshRun(it) }
        }
    }

    private suspend fun refreshRun(run: TerminalBackgroundRun) {
        runCatching {
            val context = ArixTerminalContextRef.current ?: return
            val runtime = context.arixRuntime.termuxRuntime
            val result = runtime.fetchExecution(
                JSONObject().put("run_id", run.runId).put("tail_bytes", 16 * 1024).toString()
            )
            val parsed = runCatching { JSONObject(result) }.getOrNull() ?: return
            if (parsed.optString("run_id") == run.runId) {
                run.status = parsed.optString("status", "running")
                run.exitCode = if (parsed.isNull("exit_code")) "" else "exit ${parsed.optInt("exit_code")}"
                run.stdoutTail = parsed.optString("stdout")
                run.stderrTail = parsed.optString("stderr")
            }
        }
    }

    fun remove(run: TerminalBackgroundRun) {
        if (run.isRunning) stop(run)
        runs.remove(run)
    }
}

internal object ArixTerminalContextRef {
    var current: android.content.Context? = null
}

@Composable
internal fun TerminalBackgroundCommandsSheet(
    state: TerminalBackgroundCommandsState,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    ArixTerminalContextRef.current = context.applicationContext
    var input by remember { mutableStateOf("") }
    var launching by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        state.refreshAll()
        while (true) {
            delay(if (state.runs.any { it.isRunning }) 2_500L else 60_000L)
            state.refreshAll()
        }
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .imePadding()
            .animateContentSize(),
        shape = RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp),
        color = ArixSurface,
        tonalElevation = 2.dp,
        shadowElevation = 16.dp,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 10.dp),
        ) {
            Box(
                modifier = Modifier
                    .width(44.dp)
                    .height(5.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(ArixOutline.copy(alpha = 0.55f))
                    .align(Alignment.CenterHorizontally),
            )
            Spacer(Modifier.height(14.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .background(
                            androidx.compose.ui.graphics.Brush.linearGradient(
                                listOf(
                                    ArixTertiary.copy(alpha = 0.30f),
                                    ArixPrimary.copy(alpha = 0.14f),
                                ),
                            ),
                            CircleShape,
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Terminal,
                        contentDescription = null,
                        tint = ArixTertiary,
                        modifier = Modifier.size(18.dp),
                    )
                }
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Background commands",
                        style = MaterialTheme.typography.titleMedium,
                        color = ArixOnSurface,
                    )
                    Text(
                        text = "Run long or daemon commands outside the terminal",
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                    )
                }
            }
            Spacer(Modifier.height(14.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = {
                        Text("python server.py", fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                    },
                    textStyle = MaterialTheme.typography.bodyMedium.copy(
                        fontFamily = FontFamily.Monospace,
                    ),
                    singleLine = true,
                    enabled = !launching,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            val command = input.trim()
                            if (command.isNotBlank() && !launching) {
                                launching = true
                                state.launch(command) { started ->
                                    launching = false
                                    if (started) input = ""
                                }
                            }
                        },
                    ),
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ArixPrimary.copy(alpha = 0.6f),
                        unfocusedBorderColor = ArixOutline.copy(alpha = 0.5f),
                    ),
                )
                Spacer(Modifier.width(10.dp))
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .background(
                            if (input.isBlank() || launching) ArixSurfaceVariant else ArixPrimary,
                            CircleShape,
                        )
                        .clickable(enabled = input.isNotBlank() && !launching) {
                            val command = input.trim()
                            launching = true
                            state.launch(command) { started ->
                                launching = false
                                if (started) input = ""
                            }
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Add,
                        contentDescription = "Run in background",
                        tint = if (input.isBlank() || launching) ArixOnSurfaceVariant else Color.White,
                        modifier = Modifier.size(20.dp),
                    )
                }
            }
            Spacer(Modifier.height(12.dp))

            if (state.runs.isEmpty()) {
                Text(
                    text = "No background commands yet. Launch one above — it keeps running when you leave the Terminal, with its log here.",
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 380.dp)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                state.runs.forEach { run ->
                    BackgroundRunRow(run = run, onStop = { state.stop(run) }, onRemove = { state.remove(run) })
                }
                if (state.runs.isNotEmpty()) {
                    Spacer(Modifier.height(16.dp))
                }
            }
            Spacer(Modifier.height(20.dp))
        }
    }
}

@Composable
private fun BackgroundRunRow(
    run: TerminalBackgroundRun,
    onStop: () -> Unit,
    onRemove: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(ArixSurfaceHigher.copy(alpha = 0.7f))
            .clickable { run.expanded = !run.expanded }
            .padding(horizontal = 14.dp, vertical = 10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(
                        color = if (run.isRunning) ArixPrimary else ArixOnSurfaceVariant.copy(alpha = 0.4f),
                        shape = CircleShape,
                    ),
            )
            Spacer(Modifier.width(10.dp))
            Text(
                text = run.command,
                style = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
                color = ArixOnSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = if (run.isRunning) "running" else (run.exitCode.ifBlank { run.status }),
                style = MaterialTheme.typography.labelMedium,
                color = if (run.isRunning) ArixPrimary else ArixOnSurfaceVariant,
            )
            Spacer(Modifier.width(8.dp))
            if (run.isRunning) {
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .background(ArixError.copy(alpha = 0.16f), CircleShape)
                        .clickable(onClick = onStop),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Stop,
                        contentDescription = "Stop command",
                        tint = ArixError,
                        modifier = Modifier.size(15.dp),
                    )
                }
            } else {
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clickable(onClick = onRemove),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                        contentDescription = "Dismiss",
                        tint = ArixOnSurfaceVariant,
                        modifier = Modifier.size(16.dp),
                    )
                }
            }
        }
        if (run.expanded) {
            Spacer(Modifier.height(8.dp))
            val log = buildString {
                if (run.stdoutTail.isNotBlank()) append(run.stdoutTail)
                if (run.stderrTail.isNotBlank()) {
                    if (isNotEmpty()) append("\n")
                    append(run.stderrTail)
                }
                if (isBlank()) append("(no output yet)")
            }
            Text(
                text = log.takeLast(6_000),
                style = MaterialTheme.typography.bodySmall.copy(
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    lineHeight = 15.sp,
                ),
                color = ArixOnSurfaceVariant,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(ArixSurfaceVariant.copy(alpha = 0.35f))
                    .padding(10.dp),
            )
        }
    }
}
