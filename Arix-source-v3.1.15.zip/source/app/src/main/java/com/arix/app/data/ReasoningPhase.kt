package com.arix.app.data

enum class ArixReasoningPhase {
    IDLE,
    THINKING,
    USING_TOOL,
    VERIFYING,
    FINALIZING,
    COMPLETE,
    ERROR,
    CANCELLED,
}

internal val ArixReasoningPhase.isTerminal: Boolean
    get() = this == ArixReasoningPhase.COMPLETE ||
        this == ArixReasoningPhase.ERROR ||
        this == ArixReasoningPhase.CANCELLED

internal val ArixReasoningPhase.progressLabel: String?
    get() = when (this) {
        ArixReasoningPhase.THINKING -> "Thinking…"
        ArixReasoningPhase.USING_TOOL -> "Working…"
        ArixReasoningPhase.VERIFYING -> "Checking results…"
        ArixReasoningPhase.FINALIZING -> "Preparing answer…"
        else -> null
    }

internal fun toolAwarePhaseLabel(toolName: String): String = when {
    toolName in setOf("browser", "web_search", "fetch_url", "web_scrape") -> "Searching…"
    toolName in setOf("bash", "arix_runtime_manage", "arix_ensure_package", "read", "ls", "grep", "find") ->
        "Running command…"
    toolName == "media_search" -> "Searching media…"
    toolName == "arix_swarm" -> "Running agent…"
    toolName == "arix_file_share" -> "Uploading file…"
    else -> "Working…"
}

internal val ArixReasoningPhase.mochiReaction: com.arix.app.companion.ArixMochiState
    get() = when (this) {
        ArixReasoningPhase.USING_TOOL,
        ArixReasoningPhase.VERIFYING,
        -> com.arix.app.companion.ArixMochiState.Working
        ArixReasoningPhase.FINALIZING -> com.arix.app.companion.ArixMochiState.Generating
        ArixReasoningPhase.COMPLETE -> com.arix.app.companion.ArixMochiState.Finished
        ArixReasoningPhase.ERROR -> com.arix.app.companion.ArixMochiState.Error
        else -> com.arix.app.companion.ArixMochiState.Thinking
    }
