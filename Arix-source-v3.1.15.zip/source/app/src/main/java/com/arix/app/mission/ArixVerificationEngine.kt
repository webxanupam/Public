package com.arix.app.mission

import org.json.JSONObject

class ArixVerificationEngine(
    private val fileInspector: (path: String) -> Pair<Boolean, Long> = { path ->
        val file = java.io.File(path)
        (file.isFile && file.exists()) to (if (file.isFile) file.length() else 0L)
    },
) {

    data class VerificationOutcome(
        val verified: Boolean,
        val reason: String,
    ) {
        companion object {
            val Verified = VerificationOutcome(true, "verified")
        }
    }

    fun verify(task: MissionTask, rawOutput: String): VerificationOutcome {
        val parsed = runCatching { JSONObject(rawOutput) }.getOrNull()
            ?: return VerificationOutcome(
                verified = false,
                reason = "Output was not structured JSON — cannot confirm the claimed result.",
            )
        if (!parsed.optBoolean("ok", false)) {
            return VerificationOutcome(
                verified = false,
                reason = parsed.optString("message")
                    .ifBlank { "Tool reported ok=false." },
            )
        }

        val capability = task.requiredCapability
        val result = parsed.optJSONObject("result")

        if (capability in FileArtifactCapabilities) {
            val path = listOfNotNull(
                result?.optString("path")?.takeIf { it.isNotBlank() },
                result?.optString("file_path")?.takeIf { it.isNotBlank() },
                result?.optString("output_path")?.takeIf { it.isNotBlank() },
                parsed.optString("path")?.takeIf { it.isNotBlank() },
            ).firstOrNull()
                ?: return VerificationOutcome(
                    verified = false,
                    reason = "No artifact path in the result — cannot verify the file was created.",
                )
            val (exists, size) = fileInspector(path)
            if (!exists) {
                return VerificationOutcome(
                    verified = false,
                    reason = "Artifact '$path' does not exist.",
                )
            }
            if (size <= 0L) {
                return VerificationOutcome(
                    verified = false,
                    reason = "Artifact '$path' is empty (0 bytes).",
                )
            }
        }

        if (capability == "web_research" || capability == "web_search") {
            val sources = result?.optJSONArray("sources") ?: parsed.optJSONArray("sources")
            if (sources == null || sources.length() == 0) {
                return VerificationOutcome(
                    verified = false,
                    reason = "Research result carries no sources.",
                )
            }
        }

        if (capability == "web_interact") {
            if (!parsed.has("url") && !parsed.has("selector_found") && result?.has("url") != true) {
                return VerificationOutcome(
                    verified = false,
                    reason = "Browser result lacks post-action state (url/selector) — unverified.",
                )
            }
        }

        return VerificationOutcome.Verified
    }

    companion object {
        private val FileArtifactCapabilities = setOf(
            "file_write",
            "file_edit",
            "document_composition",
        )
    }
}
