package com.arix.app.data

import org.json.JSONObject

object ArixToolContract {
    const val TOOL_NOT_FOUND = "TOOL_NOT_FOUND"
    const val TOOL_UNAVAILABLE = "TOOL_UNAVAILABLE"
    const val INVALID_ARGUMENTS = "INVALID_ARGUMENTS"
    const val PERMISSION_REQUIRED = "PERMISSION_REQUIRED"
    const val TARGET_NOT_FOUND = "TARGET_NOT_FOUND"
    const val TARGET_AMBIGUOUS = "TARGET_AMBIGUOUS"
    const val TARGET_STALE = "TARGET_STALE"
    const val ACTION_FAILED = "ACTION_FAILED"
    const val VERIFICATION_FAILED = "VERIFICATION_FAILED"
    const val TIMEOUT = "TIMEOUT"
    const val NETWORK_ERROR = "NETWORK_ERROR"
    const val AUTH_REQUIRED = "AUTH_REQUIRED"
    const val AGENT_NOT_FOUND = "AGENT_NOT_FOUND"
    const val AGENT_UNAVAILABLE = "AGENT_UNAVAILABLE"
    const val REPEATED_FAILURE = "REPEATED_FAILURE"

    fun success(result: JSONObject, verified: Boolean): JSONObject = JSONObject()
        .put("ok", true)
        .put("result", result)
        .put("verified", verified)

    fun failure(errorCode: String, message: String, extra: JSONObject? = null): JSONObject =
        JSONObject()
            .put("ok", false)
            .put("error_code", errorCode)
            .put("message", message)
            .also { payload -> extra?.let { it.keys().forEach { key -> payload.put(key, it.get(key)) } } }

    fun withTool(payload: JSONObject, toolName: String): JSONObject {
        if (!payload.has("tool")) payload.put("tool", toolName)
        return payload
    }
}
