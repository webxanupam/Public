package com.arix.app.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.isActive
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import java.util.concurrent.TimeUnit

internal object ArixLinkPreviewStore {

    data class LinkMetadata(
        val title: String?,
        val description: String?,
    )

    private data class Favicon(val bitmap: Bitmap?)

    private val metadataCache = LruCache<String, LinkMetadata>(48)
    private val faviconCache = LruCache<String, Favicon>(48)
    private val inFlightMetadata = HashMap<String, Deferred<LinkMetadata>>()
    private val inFlightFavicon = HashMap<String, Deferred<Favicon>>()
    private val gate = Any()

    private val storeScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(6, TimeUnit.SECONDS)
            .readTimeout(8, TimeUnit.SECONDS)
            .followRedirects(true)
            .build()
    }

    fun cachedMetadata(url: String): LinkMetadata? = synchronized(gate) {
        metadataCache.get(url)
    }

    fun cachedFavicon(domain: String): Bitmap? = synchronized(gate) {
        faviconCache.get(domain)?.bitmap
    }

    suspend fun metadata(url: String): LinkMetadata {
        cachedMetadata(url)?.let { return it }
        val deferred: Deferred<LinkMetadata> = synchronized(gate) {
            val cached = metadataCache.get(url)
            if (cached != null) return cached
            inFlightMetadata.getOrPut(url) {
                storeScope.async {
                    val fetched = fetchMetadata(url)
                    synchronized(gate) {
                        if (isActive) {
                            metadataCache.put(url, fetched)
                        }
                        inFlightMetadata.remove(url)
                    }
                    fetched
                }
            }
        }
        return runCatching { deferred.await() }.getOrDefault(LinkMetadata(null, null))
    }

    suspend fun favicon(domain: String): Bitmap? {
        cachedFavicon(domain)?.let { return it }
        val deferred: Deferred<Favicon> = synchronized(gate) {
            val cached = faviconCache.get(domain)
            if (cached != null) return cached.bitmap
            inFlightFavicon.getOrPut(domain) {
                storeScope.async {
                    val fetched = Favicon(fetchFavicon(domain))
                    synchronized(gate) {
                        if (isActive) {
                            faviconCache.put(domain, fetched)
                        }
                        inFlightFavicon.remove(domain)
                    }
                    fetched
                }
            }
        }
        return runCatching { deferred.await() }.getOrDefault(Favicon(null)).bitmap
    }

    private fun fetchMetadata(url: String): LinkMetadata = runCatching {
        val document = Jsoup.connect(url)
            .userAgent(BrowserUserAgent)
            .referrer("https://www.google.com/")
            .timeout(8000)
            .maxBodySize(512 * 1024)
            .followRedirects(true)
            .get()
        val title = document.selectFirst("meta[property=\"og:title\"]")?.attr("content")
            ?: document.selectFirst("meta[name=\"twitter:title\"]")?.attr("content")
            ?: document.title()
            ?: ""
        val description = document.selectFirst("meta[property=\"og:description\"]")?.attr("content")
            ?: document.selectFirst("meta[name=\"twitter:description\"]")?.attr("content")
            ?: document.selectFirst("meta[name=\"description\"]")?.attr("content")
            ?: ""
        LinkMetadata(
            title = title.trim().take(160).ifBlank { null },
            description = description.trim().take(280).ifBlank { null },
        )
    }.getOrDefault(LinkMetadata(null, null))

    private fun fetchFavicon(domain: String): Bitmap? = runCatching {
        val url = "https://icons.duckduckgo.com/ip3/$domain.ico"
        val request = Request.Builder()
            .url(url)
            .header("Accept", "image/*,*/*;q=0.8")
            .header("User-Agent", BrowserUserAgent)
            .get()
            .build()
        httpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return@runCatching null
            val bytes = response.body?.bytes() ?: return@runCatching null
            if (bytes.isEmpty() || bytes.size > 256 * 1024) return@runCatching null
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        }
    }.getOrNull()

    private val BrowserUserAgent =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36"
}

internal fun linkCardSourceLabel(url: String): String {
    val cleaned = url.substringBefore('#').substringBefore('?')
    val schemeIndex = cleaned.indexOf("://")
    if (schemeIndex < 0) return url
    val rest = cleaned.substring(schemeIndex + 3)
    val pathStart = rest.indexOf('/')
    val domain = (if (pathStart < 0) rest else rest.substring(0, pathStart))
        .removePrefix("www.")
    if (domain.isBlank()) return url
    val path = if (pathStart < 0) "" else rest.substring(pathStart).trimEnd('/')
    if (path.isBlank()) return domain
    val prettyPath = path.takeIf { it.length <= 42 } ?: path.take(24) + "…" + path.takeLast(14)
    return "$domain · $prettyPath"
}
