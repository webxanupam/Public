package com.arix.app.data

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.arix.app.ScheduledTaskAlarmReceiver
import java.util.zip.CRC32
import kotlin.math.max

class ScheduledTaskScheduler(
    private val context: Context,
    private val diagnosticLogger: ArixDiagnosticLogger = ArixDiagnosticLogger.NoOp,
    requestCodeAllocator: ScheduledTaskRequestCodeAllocator? = null,
) {
    private val alarmManager: AlarmManager =
        context.getSystemService(AlarmManager::class.java)

    private val requestCodes = requestCodeAllocator
        ?: ScheduledTaskRequestCodeAllocator.from(context)

    fun sync(tasks: List<ScheduledTask>) {
        tasks.forEach(::schedule)
    }

    fun schedule(task: ScheduledTask) {
        cancel(task.id)
        val triggerAtMillis = task.nextRunAtMillis ?: return
        if (!task.isEnabled) return
        val pendingIntent = taskPendingIntent(task.id, PendingIntent.FLAG_UPDATE_CURRENT) ?: return
        try {
            val scheduleMode = scheduleAlarm(triggerAtMillis, pendingIntent)
            diagnosticLogger.event(
                category = "scheduled_task",
                event = "alarm_scheduled",
                details = mapOf(
                    "task_id" to task.id,
                    "trigger_at_millis" to triggerAtMillis,
                    "schedule_mode" to scheduleMode,
                    "can_schedule_exact" to canScheduleExactAlarms(),
                ),
            )
        } catch (throwable: Throwable) {
            diagnosticLogger.exception(
                category = "scheduled_task",
                event = "alarm_schedule_failed",
                throwable = throwable,
                details = mapOf("task_id" to task.id),
            )
        }
    }

    fun cancel(taskId: String) {
        requestCodes.peekRequestCode(taskId)?.let { code ->
            alarmManager.cancel(broadcastPendingIntent(code, taskId, PendingIntent.FLAG_NO_CREATE))
        }
        alarmManager.cancel(
            broadcastPendingIntent(legacyCrcRequestCode(taskId), taskId, PendingIntent.FLAG_NO_CREATE),
        )
    }

    fun releaseRequestCode(taskId: String) {
        cancel(taskId)
        requestCodes.forget(taskId)
    }

    fun canScheduleExactAlarms(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarmManager.canScheduleExactAlarms()

    fun exactAlarmSettingsIntent(): Intent? =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            Intent(
                android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                android.net.Uri.parse("package:${context.packageName}"),
            )
        } else {
            null
        }

    private fun scheduleAlarm(
        triggerAtMillis: Long,
        pendingIntent: PendingIntent,
    ): String {
        val normalizedTriggerAtMillis = max(triggerAtMillis, System.currentTimeMillis() + 1_000L)
        if (canScheduleExactAlarms()) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        normalizedTriggerAtMillis,
                        pendingIntent,
                    )
                } else {
                    alarmManager.setExact(
                        AlarmManager.RTC_WAKEUP,
                        normalizedTriggerAtMillis,
                        pendingIntent,
                    )
                }
                return "exact"
            } catch (securityException: SecurityException) {
                diagnosticLogger.exception(
                    category = "scheduled_task",
                    event = "exact_alarm_denied",
                    throwable = securityException,
                )
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarmManager.setAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                normalizedTriggerAtMillis,
                pendingIntent,
            )
        } else {
            alarmManager.set(
                AlarmManager.RTC_WAKEUP,
                normalizedTriggerAtMillis,
                pendingIntent,
            )
        }
        return "allow_while_idle"
    }

    private fun broadcastPendingIntent(
        requestCode: Int,
        taskId: String,
        updateFlag: Int,
    ): PendingIntent = PendingIntent.getBroadcast(
        context,
        requestCode,
        Intent(context, ScheduledTaskAlarmReceiver::class.java).apply {
            action = ActionRunScheduledTask
            putExtra(ExtraTaskId, taskId)
        },
        PendingIntent.FLAG_IMMUTABLE or updateFlag,
    )

    private fun taskPendingIntent(
        taskId: String,
        updateFlag: Int,
    ): PendingIntent = broadcastPendingIntent(
        requestCode = requestCodes.requestCodeFor(taskId),
        taskId = taskId,
        updateFlag = updateFlag,
    )

    private fun legacyCrcRequestCode(taskId: String): Int {
        val crc = CRC32()
        crc.update(taskId.toByteArray(Charsets.UTF_8))
        return (crc.value and 0x7FFFFFFF).toInt()
    }

    companion object {
        const val ActionRunScheduledTask = "com.arix.app.action.RUN_SCHEDULED_TASK"
        const val ExtraTaskId = "task_id"
    }
}
