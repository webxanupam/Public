package com.arix.app.mcp

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.net.URI
import java.net.URLEncoder

class ArixMcpOAuthClient(private val serverName: String) {

    private val http by lazy { ArixMcpClient.mcpOkHttpClient() }

    class Ongoing(
        val authorizationUrl: String,
        val state: String,
        val verifier: String,
        val config: ArixMcpOAuthConfig,
    )

    suspend fun beginAuthorization(
        mcpUrl: String,
        config: ArixMcpOAuthConfig,
        onUpdate: suspend (ArixMcpOAuthConfig) -> Unit = {},
    ): Ongoing {
        var working = config
        if (working.authorizationEndpoint.isBlank() || working.tokenEndpoint.isBlank() ||
            working.scope.isBlank() || working.tokenEndpointAuthMethods.isEmpty()
        ) {
            working = discover(mcpUrl, working)
            onUpdate(working)
        }
        working = working.copy(resource = working.resource.ifBlank { mcpUrl.trimEnd('/') })
        var registrationFailure: Throwable? = null
        if (working.clientId.isBlank() && working.registrationEndpoint.isNotBlank()) {
            runCatching { register(working) }.fold(
                onSuccess = { registered -> working = registered },
                onFailure = { failure -> registrationFailure = failure },
            )
        }
        if (working.clientId.isBlank()) {
            val cause = registrationFailure?.message
            throw IllegalStateException(
                "No OAuth client id for \"$serverName\" — the server does " +
                    "not support dynamic client registration" +
                    (cause?.let { " (registration failed: $it)" } ?: "") +
                    ". Create an OAuth app in the service's developer console " +
                    "and enter its Client ID" +
                    (if (!working.acceptsPublicClients) " and Client Secret" else "") +
                    " in Arix, then try again",
                registrationFailure,
            )
        }
        if (working.authorizationEndpoint.isBlank()) {
            throw IllegalStateException(
                "No OAuth authorization endpoint discovered for \"$serverName\"",
            )
        }
        if (working.clientSecret.isBlank() && !working.acceptsPublicClients) {
            throw IllegalStateException(
                "This authorization server requires a Client Secret for the " +
                    "token exchange (it does not accept public PKCE-only apps). " +
                    "Create an OAuth app in the \"$serverName\" developer console, " +
                    "register the callback URL shown in Arix, and paste BOTH the " +
                    "Client ID and the Client Secret",
            )
        }
        val (verifier, challenge) = ArixMcpOAuth.makePkce()
        val state = ArixMcpOAuth.makeState()
        val url = buildString {
            append(working.authorizationEndpoint)
            append(if (working.authorizationEndpoint.contains('?')) '&' else '?')
            append("response_type=code")
            append("&client_id=").append(urlEncode(working.clientId))
            append("&redirect_uri=").append(urlEncode(working.redirectUri))
            append("&code_challenge=").append(urlEncode(challenge))
            append("&code_challenge_method=S256")
            append("&state=").append(urlEncode(state))
            if (working.scope.isNotBlank()) {
                append("&scope=").append(urlEncode(working.scope))
            }
            if (working.resource.isNotBlank()) {
                append("&resource=").append(urlEncode(working.resource))
            }
        }
        onUpdate(working)
        return Ongoing(
            authorizationUrl = url,
            state = state,
            verifier = verifier,
            config = working,
        )
    }

    suspend fun completeAuthorization(
        redirectUri: String,
        ongoing: Ongoing,
    ): ArixMcpOAuthConfig {
        val query = parseQuery(redirectUri)
        val error = query["error"]
        if (error != null) {
            val description = query["error_description"].orEmpty()
            throw IllegalStateException(
                "Authorization denied: $error" +
                    (description.takeIf { it.isNotBlank() }?.let { " — $it" } ?: ""),
            )
        }
        if (query["state"].orEmpty() != ongoing.state) {
            throw IllegalStateException("Authorization state mismatch")
        }
        val code = query["code"].orEmpty()
        if (code.isBlank()) {
            throw IllegalStateException("Authorization redirect is missing the code")
        }
        return exchangeCode(code, ongoing)
    }

    private suspend fun exchangeCode(code: String, ongoing: Ongoing): ArixMcpOAuthConfig {
        val config = ongoing.config
        val body = FormBody.Builder()
            .add("grant_type", "authorization_code")
            .add("code", code)
            .add("redirect_uri", config.redirectUri)
            .add("client_id", config.clientId)
            .add("code_verifier", ongoing.verifier)
        if (config.clientSecret.isNotBlank()) body.add("client_secret", config.clientSecret)
        if (config.resource.isNotBlank()) body.add("resource", config.resource)
        return tokensFrom(postForm(config.tokenEndpoint, body.build()), config)
    }

    suspend fun forceRefresh(config: ArixMcpOAuthConfig): ArixMcpOAuthConfig? {
        if (config.refreshToken.isBlank() || config.tokenEndpoint.isBlank()) return null
        val body = FormBody.Builder()
            .add("grant_type", "refresh_token")
            .add("refresh_token", config.refreshToken)
            .add("client_id", config.clientId)
        if (config.clientSecret.isNotBlank()) body.add("client_secret", config.clientSecret)
        if (config.resource.isNotBlank()) body.add("resource", config.resource)
        return runCatching {
            tokensFrom(postForm(config.tokenEndpoint, body.build()), config)
        }.getOrNull()
    }

    private suspend fun discover(
        mcpUrl: String,
        config: ArixMcpOAuthConfig,
    ): ArixMcpOAuthConfig {
        var working = config
        val endpoint = runCatching { URI(mcpUrl) }.getOrNull()
            ?: return working
        val base = buildString {
            append(endpoint.scheme).append("://").append(endpoint.host)
            if (endpoint.port != -1) append(":").append(endpoint.port)
        }
        val resourcePath = endpoint.path.orEmpty().takeIf { it.isNotBlank() && it != "/" }.orEmpty()
        val protected = runCatching {
            getJson("$base/.well-known/oauth-protected-resource$resourcePath")
        }.getOrNull()
        val authServer = protected?.optJSONArray("authorization_servers")
            ?.optString(0)?.takeIf { it.isNotBlank() }
            ?: base
        val resourceScopes = protected?.optJSONArray("scopes_supported")?.let { scopes ->
            buildList {
                for (index in 0 until scopes.length()) {
                    scopes.optString(index).takeIf { it.isNotBlank() }?.let(::add)
                }
            }
        }.orEmpty()
        working = working.copy(authorizationServer = authServer)
        val authServerUri = runCatching { URI(authServer) }.getOrNull()
        val authServerBase = authServerUri?.let { uri ->
            buildString {
                append(uri.scheme).append("://").append(uri.host)
                if (uri.port != -1) append(":").append(uri.port)
            }
        } ?: authServer.trimEnd('/')
        val authServerPath = authServerUri?.path.orEmpty()
            .takeIf { it.isNotBlank() && it != "/" }.orEmpty()
        val candidates = buildList {
            if (authServerPath.isNotBlank()) {
                add("$authServerBase/.well-known/oauth-authorization-server$authServerPath")
            }
            if (resourcePath.isNotBlank()) {
                add("$authServerBase/.well-known/oauth-authorization-server$resourcePath")
            }
            add("$authServerBase/.well-known/oauth-authorization-server")
            add("$authServerBase/.well-known/openid-configuration")
        }
        var metadata: JSONObject? = null
        for (candidate in candidates) {
            metadata = runCatching { getJson(candidate) }.getOrNull()
            if (metadata != null) break
        }
        if (metadata != null) {
            val authMethods = metadata.optJSONArray("token_endpoint_auth_methods_supported")
                ?.let { methods ->
                    buildList {
                        for (index in 0 until methods.length()) {
                            methods.optString(index).takeIf { it.isNotBlank() }?.let(::add)
                        }
                    }
                }.orEmpty()
            val asScopes = metadata.optJSONArray("scopes_supported")?.let { scopes ->
                buildList {
                    for (index in 0 until scopes.length()) {
                        scopes.optString(index).takeIf { it.isNotBlank() }?.let(::add)
                    }
                }
            }.orEmpty()
            val mergedScope = working.scope.ifBlank {
                buildList {
                    addAll(resourceScopes)
                    if ("offline_access" !in resourceScopes && "offline_access" in asScopes) {
                        add("offline_access")
                    }
                }.joinToString(" ")
            }
            working = working.copy(
                authorizationEndpoint = metadata.optString("authorization_endpoint")
                    .takeIf { it.isNotBlank() } ?: working.authorizationEndpoint,
                tokenEndpoint = metadata.optString("token_endpoint")
                    .takeIf { it.isNotBlank() } ?: working.tokenEndpoint,
                registrationEndpoint = metadata.optString("registration_endpoint")
                    .takeIf { it.isNotBlank() } ?: working.registrationEndpoint,
                scope = mergedScope,
                tokenEndpointAuthMethods = authMethods,
            )
        }
        return working
    }

    private suspend fun register(config: ArixMcpOAuthConfig): ArixMcpOAuthConfig {
        val redirectUris = buildList {
            add(config.redirectUri)
            if (config.redirectUri != ArixMcpOAuth.LoopbackRedirect) {
                add(ArixMcpOAuth.LoopbackRedirect)
            }
            if (config.redirectUri != ArixMcpOAuth.CustomSchemeRedirect) {
                add(ArixMcpOAuth.CustomSchemeRedirect)
            }
        }
        val firstFailure = try {
            return registerWith(config, redirectUris)
        } catch (first: IllegalStateException) {
            if (redirectUris.size <= 1) throw first
            first
        }
        return try {
            registerWith(config, listOf(config.redirectUri))
        } catch (_: IllegalStateException) {
            throw firstFailure
        }
    }

    private suspend fun registerWith(
        config: ArixMcpOAuthConfig,
        redirectUris: List<String>,
    ): ArixMcpOAuthConfig {
        val body = JSONObject().apply {
            put("client_name", "Arix")
            put("application_type", "native")
            put("redirect_uris", JSONArray(redirectUris))
            put("grant_types", JSONArray().apply { put("authorization_code"); put("refresh_token") })
            put("response_types", JSONArray().apply { put("code") })
            put("token_endpoint_auth_method", "none")
        }
        val request = Request.Builder()
            .url(config.registrationEndpoint)
            .header("Accept", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        val json = withContext(Dispatchers.IO) {
            http.newCall(request).execute().use { response ->
                val text = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val detail = runCatching { parsePayloadBody(text) }
                        .getOrNull()?.let(::oauthErrorDescription)
                        ?: text.take(160).replace('\n', ' ').trim()
                        .takeIf { it.isNotBlank() }
                    throw IllegalStateException(
                        "HTTP ${response.code}" + (detail?.let { " — $it" } ?: ""),
                    )
                }
                parsePayloadBody(text)
            }
        }
        if (!json.has("client_id")) {
            throw IllegalStateException(
                "registration response had no client_id: ${json.toString().take(160)}",
            )
        }
        return config.copy(
            clientId = json.optString("client_id").takeIf { it.isNotBlank() } ?: config.clientId,
            clientSecret = json.optString("client_secret").takeIf { it.isNotBlank() }.orEmpty(),
        )
    }

    private suspend fun getJson(url: String): JSONObject = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url(url)
            .header("Accept", "application/json")
            .get()
            .build()
        http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IllegalStateException("HTTP ${response.code} for $url")
            parsePayloadBody(response.body?.string().orEmpty())
        }
    }

    private suspend fun postForm(url: String, body: FormBody): JSONObject = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url(url)
            .header("Accept", "application/json")
            .post(body)
            .build()
        http.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val parsed = runCatching { parsePayloadBody(text) }.getOrNull()
                val detail = parsed?.let(::oauthErrorDescription)
                    ?: text.take(160).replace('\n', ' ').trim().takeIf { it.isNotBlank() }
                throw IllegalStateException(
                    "Token endpoint returned HTTP ${response.code}" +
                        (detail?.let { " — $it" } ?: ""),
                )
            }
            parsePayloadBody(text)
        }
    }

    private fun parsePayloadBody(text: String): JSONObject {
        val trimmed = text.trim()
        if (trimmed.startsWith("{")) {
            try {
                return JSONObject(trimmed)
            } catch (failure: JSONException) {
                throw IllegalStateException(
                    "malformed JSON response: ${trimmed.take(160).replace('\n', ' ')}",
                )
            }
        }
        if (trimmed.contains("=")) {
            val converted = JSONObject()
            trimmed.split('&').forEach { pair ->
                val index = pair.indexOf('=')
                if (index > 0) {
                    runCatching {
                        converted.put(
                            urlDecode(pair.substring(0, index)),
                            urlDecode(pair.substring(index + 1)),
                        )
                    }
                }
            }
            if (converted.length() > 0) return converted
        }
        throw IllegalStateException(
            "unexpected response: ${trimmed.take(160).ifBlank { "(empty body)" }.replace('\n', ' ')}",
        )
    }

    private fun oauthErrorDescription(json: JSONObject): String? {
        val error = json.optString("error").takeIf { it.isNotBlank() } ?: return null
        val description = json.optString("error_description").takeIf { it.isNotBlank() }
        return if (description != null) "$error — $description" else error
    }

    private fun tokensFrom(json: JSONObject, base: ArixMcpOAuthConfig): ArixMcpOAuthConfig {
        oauthErrorDescription(json)?.let { detail ->
            throw IllegalStateException("Token endpoint error: $detail")
        }
        if (json.optString("access_token").isBlank()) {
            throw IllegalStateException(
                "Token endpoint response has no access_token: ${json.toString().take(160)}",
            )
        }
        val expiresIn = json.optLong("expires_in", 3600L)
        return base.copy(
            accessToken = json.optString("access_token").takeIf { it.isNotBlank() } ?: base.accessToken,
            refreshToken = json.optString("refresh_token").takeIf { it.isNotBlank() } ?: base.refreshToken,
            tokenType = json.optString("token_type").takeIf { it.isNotBlank() } ?: "Bearer",
            expiresAt = System.currentTimeMillis() + expiresIn * 1000L,
        )
    }

    private fun parseQuery(uri: String): Map<String, String> {
        val raw = runCatching { URI(uri).rawQuery }.getOrNull() ?: return emptyMap()
        return raw.split("&").mapNotNull { pair ->
            val index = pair.indexOf('=')
            if (index <= 0) return@mapNotNull null
            urlDecode(pair.substring(0, index)) to urlDecode(pair.substring(index + 1))
        }.toMap()
    }

    private fun urlEncode(value: String): String = URLEncoder.encode(value, Charsets.UTF_8.name())
    private fun urlDecode(value: String): String =
        java.net.URLDecoder.decode(value, Charsets.UTF_8.name())
}
