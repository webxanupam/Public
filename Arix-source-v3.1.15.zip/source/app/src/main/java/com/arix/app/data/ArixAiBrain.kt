package com.arix.app.data

import org.json.JSONArray
import org.json.JSONObject

class ArixAiBrain(
    private val skillManager: AgentSkillManager,
    private val diagnosticLogger: ArixDiagnosticLogger = ArixDiagnosticLogger.NoOp,
) {

    suspend fun routeSkillsForTurn(
        @Suppress("UNUSED_PARAMETER") settings: AppSettings,
        userText: String,
        enabledSkills: List<InstalledSkill>,
    ): List<ActiveSkillContext> {
        val message = userText.trim()
        if (message.isBlank() || enabledSkills.isEmpty()) return emptyList()

        val selection = selectLocally(message, enabledSkills)
        diagnosticLogger.event(
            category = "ai_brain",
            event = "skill_route",
            details = mapOf(
                "skill_count" to enabledSkills.size,
                "selected" to selection.joinToString(","),
                "router" to "local",
            ),
        )
        return resolveActiveSkills(selection, enabledSkills)
    }

    internal fun selectLocally(message: String, enabledSkills: List<InstalledSkill>): List<String> =
        ArixSkillScoring.select(message, enabledSkills)

    internal fun tokenize(text: String): Set<String> = ArixSkillScoring.tokenize(text)

    private suspend fun resolveActiveSkills(
        selection: List<String>,
        enabledSkills: List<InstalledSkill>,
    ): List<ActiveSkillContext> {
        if (selection.isEmpty()) return emptyList()
        val byId = enabledSkills.associateBy { it.id }
        return selection.mapNotNull { skillId ->
            val installed = byId[skillId] ?: return@mapNotNull null
            skillManager.buildActiveSkillContext(installed).getOrNull()
        }
    }
}

internal object ArixSkillScoring {
    const val MaxSkillsPerTurn = 2
    const val MinTokenLength = 3

    const val NameTokenWeight = 3

    const val VerbatimNameHitScore = 6

    const val StrongKeywordWeight = 3

    const val KeywordWeight = 2

    const val DescriptionTokenWeight = 1

    const val NegativeKeywordPenalty = 4

    const val ActivationScoreThreshold = 3

    data class Scored(val id: String, val score: Int)

    fun select(message: String, enabledSkills: List<InstalledSkill>): List<String> =
        score(message, enabledSkills)
            .filter { it.score >= ActivationScoreThreshold }
            .sortedByDescending { it.score }
            .take(MaxSkillsPerTurn)
            .map { it.id }

    fun score(message: String, enabledSkills: List<InstalledSkill>): List<Scored> {
        val messageTokens = tokenize(message)
        if (messageTokens.isEmpty()) return emptyList()
        val messageText = message.lowercase()
        return enabledSkills.mapNotNull { skill ->
            val name = skill.name.trim().lowercase()
            if (name.isEmpty()) return@mapNotNull null
            val nameTokens = tokenize(name)
            val descriptionTokens = tokenize(skill.description)
            val strongTokens = metadataTokens(skill.metadataJson, "strong-keywords")
            val keywordTokens = metadataTokens(skill.metadataJson, "keywords")
            val negativeTokens = metadataTokens(skill.metadataJson, "negative-keywords")

            val verbatim = name.length >= 4 && messageText.contains(name)
            var score = if (verbatim) VerbatimNameHitScore else 0
            // v3.1.13 — one token counts once, at its strongest category. The
            // per-category sums used to stack for the same token (a keyword hit
            // also matched the description), so a lone common word could reach
            // the activation threshold on its own — "give me a short answer
            // please" routed to Video Studio once "shorts" became a strong
            // keyword and the stemmer collapsed it to "short".
            for (token in messageTokens) {
                score += when {
                    token in nameTokens -> NameTokenWeight
                    token in strongTokens -> StrongKeywordWeight
                    token in keywordTokens -> KeywordWeight
                    token in descriptionTokens -> DescriptionTokenWeight
                    else -> 0
                }
            }
            if (!verbatim) {
                score -= NegativeKeywordPenalty * messageTokens.count(negativeTokens::contains)
            }
            Scored(skill.id, score)
        }
    }

    fun tokenize(text: String): Set<String> =
        text.lowercase()
            .split(TokenSplitter)
            .filter { token -> token.length >= MinTokenLength && token !in RouterStopwords }
            .mapTo(LinkedHashSet()) { stem(it) }

    fun stem(token: String): String {
        if (token.length <= 3 || !token.all { it in 'a'..'z' }) return token
        var t = token
        if (t.length > 5 && t.endsWith("ing")) {
            t = t.dropLast(3)
        } else if (t.length > 5 && t.endsWith("ed")) {
            t = t.dropLast(2)
        }
        if (t.length > 3 && t.endsWith("s") && !t.endsWith("ss")) t = t.dropLast(1)
        if (t.length > 3 && t.endsWith("e")) t = t.dropLast(1)
        if (t.length > 3 && t.endsWith("y")) t = t.dropLast(1) + "i"
        return t
    }

    private fun metadataTokens(metadataJson: String, key: String): Set<String> =
        runCatching {
            val value = JSONObject(metadataJson).opt(key)
            val text = when (value) {
                null, JSONObject.NULL -> ""
                is JSONArray -> (0 until value.length()).joinToString(" ") { value.optString(it) }
                else -> value.toString()
            }
            tokenize(text)
        }.getOrDefault(emptySet())

    private val TokenSplitter = Regex("[^\\p{L}\\p{M}\\p{N}]+")

    val RouterStopwords = setOf(
        "the", "and", "for", "you", "your", "with", "that", "this", "from",
        "have", "has", "are", "was", "were", "will", "would", "could",
        "can", "get", "got", "use", "using", "used", "make", "made",
        "how", "what", "when", "where", "which", "who", "why", "into",
        "about", "please", "just", "like", "want", "need", "help", "run",
        "open", "new", "all", "out", "not", "but", "his", "her", "its",
        "our", "their", "there", "here", "then", "than", "them", "they",
        "some", "any", "one", "two", "may", "might", "must", "should",
        "also", "very", "much", "more", "most", "less", "least", "over",
        "under", "again", "each", "other", "such", "only", "same", "does",
        "did", "been", "being", "because", "while", "during", "before",
        "after", "above", "below", "between", "both", "few", "own",
    )
}
