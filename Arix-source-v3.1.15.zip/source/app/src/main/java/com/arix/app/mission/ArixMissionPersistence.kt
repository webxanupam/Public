package com.arix.app.mission

import java.io.File
import org.json.JSONArray
class ArixMissionPersistence(
    private val storeFile: File?,
) {

    private val stateLock = Any()
    private var loaded = false
    private val missions = linkedMapOf<String, ArixMission>()

    fun snapshot(): List<ArixMission> = synchronized(stateLock) {
        ensureLoadedLocked()
        missions.values.toList()
    }

    fun find(missionId: String): ArixMission? = synchronized(stateLock) {
        ensureLoadedLocked()
        missions[missionId]
    }

    fun upsert(mission: ArixMission): Unit = synchronized(stateLock) {
        ensureLoadedLocked()
        missions[mission.missionId] = mission.withProgress()
        persistLocked()
    }

    fun remove(missionId: String): Boolean = synchronized(stateLock) {
        ensureLoadedLocked()
        val removed = missions.remove(missionId) != null
        if (removed) persistLocked()
        removed
    }

    fun pruneFinished(keep: Int = MaxFinishedMissions): Int = synchronized(stateLock) {
        ensureLoadedLocked()
        val finished = missions.values.filter { it.status.isTerminal }
        if (finished.size <= keep) return 0
        val excess = finished
            .sortedBy { it.updatedAtMillis }
            .take(finished.size - keep)
        excess.forEach { missions.remove(it.missionId) }
        persistLocked()
        excess.size
    }

    fun clearFinished(): Int = synchronized(stateLock) {
        ensureLoadedLocked()
        val iterator = missions.values.iterator()
        var removed = 0
        while (iterator.hasNext()) {
            if (iterator.next().status.isTerminal) {
                iterator.remove()
                removed += 1
            }
        }
        if (removed > 0) persistLocked()
        removed
    }

    private fun ensureLoadedLocked() {
        if (loaded) return
        loaded = true
        val file = storeFile ?: return
        if (!file.isFile) return
        val raw = runCatching { file.readText(Charsets.UTF_8) }.getOrNull()
        if (raw.isNullOrBlank()) return
        val parsed = runCatching { JSONArray(raw) }.getOrNull()
        if (parsed == null) {
            quarantine(file, "unparseable-json")
            return
        }
        var salvaged = 0
        for (index in 0 until parsed.length()) {
            val json = parsed.optJSONObject(index) ?: continue
            if (runCatching { parseArixMission(json) }.getOrNull()?.let { missions[it.missionId] = it } != null) {
                salvaged += 1
            }
        }
        if (salvaged == 0 && parsed.length() > 0) {
            quarantine(file, "no-valid-mission-entries")
        }
    }

    private fun quarantine(file: File, reason: String) {
        runCatching {
            file.renameTo(File(file.parentFile, file.name + ".corrupt-$reason"))
        }
    }

    private fun persistLocked() {
        val file = storeFile ?: return
        runCatching {
            file.parentFile?.takeIf { !it.isDirectory }?.mkdirs()
            val payload = JSONArray().apply {
                missions.values.forEach { put(it.toJson()) }
            }
            val tmp = File(file.parentFile, file.name + ".tmp")
            tmp.writeText(payload.toString(), Charsets.UTF_8)
            if (!tmp.renameTo(file)) {
                file.writeText(payload.toString(), Charsets.UTF_8)
                runCatching { tmp.delete() }
            }
        }
    }

    companion object {
        const val SchemaVersion = 1
        const val StoreFileName = "arix_missions.json"

        const val MaxFinishedMissions = 40

        fun defaultStoreFile(filesDir: File): File = File(filesDir, StoreFileName)
    }
}
