package com.arix.app.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.BackHandler
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.DriveFileMove
import androidx.compose.material.icons.rounded.DriveFolderUpload
import androidx.compose.material.icons.rounded.DoneAll
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.FileUpload
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Sort
import androidx.compose.material.icons.rounded.ViewList
import androidx.compose.material.icons.rounded.WrapText
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.documentfile.provider.DocumentFile
import com.arix.app.runtime.AndroidFilePermissions
import com.arix.app.runtime.AndroidTermuxFileEntry
import com.arix.app.runtime.AndroidTermuxFileManagerRuntime
import com.arix.app.runtime.ArixDeviceStorage
import com.arix.app.runtime.ArixFileOperationBus
import com.arix.app.runtime.ArixFileOperationKind
import com.arix.app.ui.theme.ArixOnPrimary
import com.arix.app.ui.theme.ArixOnSurface
import com.arix.app.ui.theme.ArixOnSurfaceVariant
import com.arix.app.ui.theme.ArixOutline
import com.arix.app.ui.theme.ArixPrimary
import com.arix.app.ui.theme.ArixSettingsBackground
import com.arix.app.ui.theme.ArixSurface
import com.arix.app.ui.theme.ArixSurfaceHigh
import io.github.rosemoe.sora.widget.CodeEditor
import io.github.rosemoe.sora.widget.schemes.SchemeDarcula
import java.text.DateFormat
import java.util.Date
import kotlinx.coroutines.launch

private enum class AndroidFileDialog { None, NewFile, NewFolder, Rename, Delete }

private data class AndroidFilePermissionsState(
    val entry: AndroidTermuxFileEntry,
    val initial: AndroidFilePermissions?,
    val current: AndroidFilePermissions,
)
private enum class AndroidFileSort { Name, Date, Size }

private enum class AndroidFileBatchMode { Copy, Cut }

private data class AndroidFileBatch(
    val entries: List<AndroidTermuxFileEntry>,
    val mode: AndroidFileBatchMode,
)

internal const val TermuxFilesTabInitialPath = "/workspace"

private val AndroidFileEntryDateFormatter: DateFormat =
    DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)

@Composable
internal fun AndroidTermuxFileManagerScreen(
    runtime: AndroidTermuxFileManagerRuntime,
    onBack: () -> Unit,
    initialPath: String = "/",
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var path by rememberSaveable { mutableStateOf(initialPath) }
    var entries by remember { mutableStateOf<List<AndroidTermuxFileEntry>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var query by rememberSaveable { mutableStateOf("") }
    var showSearch by remember { mutableStateOf(false) }
    var grid by rememberSaveable { mutableStateOf(false) }
    var sort by rememberSaveable { mutableStateOf(AndroidFileSort.Name) }
    var optionsExpanded by remember { mutableStateOf(false) }
    var createExpanded by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<AndroidTermuxFileEntry?>(null) }
    var dialog by remember { mutableStateOf(AndroidFileDialog.None) }
    var draftName by remember { mutableStateOf("") }
    var editorFile by remember { mutableStateOf<AndroidTermuxFileEntry?>(null) }
    var editorContent by remember { mutableStateOf("") }
    var imagePreview by remember { mutableStateOf<Pair<ByteArray, String>?>(null) }
    var viewerEntry by remember { mutableStateOf<AndroidTermuxFileEntry?>(null) }
    var environmentSetupPending by remember { mutableStateOf(false) }
    var showHidden by rememberSaveable { mutableStateOf(true) }
    var permissionsState by remember { mutableStateOf<AndroidFilePermissionsState?>(null) }

    val activeFileOperation by ArixFileOperationBus.activeOperation.collectAsState()
    val fileOperationError by ArixFileOperationBus.lastError.collectAsState()

    var selectionMode by remember { mutableStateOf(false) }
    val selectedPaths = remember { mutableStateListOf<String>() }
    fun exitSelectionMode() {
        selectionMode = false
        selectedPaths.clear()
    }

    fun toggleSelected(entry: AndroidTermuxFileEntry) {
        if (entry.path in selectedPaths) {
            selectedPaths.remove(entry.path)
        } else {
            selectedPaths.add(entry.path)
        }
    }

    var storagePermissionDenied by remember { mutableStateOf(false) }
    val storageAccessGranted = ArixDeviceStorage.hasAccess(context)
    val browsingDeviceStorage = runtime.isDeviceStoragePath(path)
    val storagePermissionNeeded = browsingDeviceStorage && !storageAccessGranted
    val storageWriteGranted = ArixDeviceStorage.canWrite(context)

    var clipboardEntry by remember { mutableStateOf<AndroidTermuxFileEntry?>(null) }

    var batchClipboard by remember { mutableStateOf<AndroidFileBatch?>(null) }

    fun refresh() {
        val requestedPath = path
        loading = true
        scope.launch {
            val setupReady = if (runtime.isBootstrapIndependentPath(requestedPath)) {
                true
            } else {
                runCatching { runtime.isReady() }.getOrDefault(true)
            }
            if (!setupReady) {
                if (path == requestedPath) {
                    environmentSetupPending = true
                    entries = emptyList()
                    loading = false
                }
                return@launch
            }
            environmentSetupPending = false
            if (runtime.isDeviceStoragePath(requestedPath) && !ArixDeviceStorage.hasAccess(context)) {
                if (path == requestedPath) {
                    entries = emptyList()
                    loading = false
                }
                return@launch
            }
            runCatching { runtime.listDirectory(requestedPath) }
                .onSuccess { if (path == requestedPath) entries = it }
                .onFailure { error = it.message ?: "Unable to load directory." }
            if (path == requestedPath) loading = false
        }
    }

    val storagePermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions(),
        onResult = { grants ->
            storagePermissionDenied = grants.values.any { !it }
            if (grants.values.any { it }) {
                refresh()
            }
        },
    )

    LaunchedEffect(Unit) {
        ArixFileOperationBus.completions.collect { refresh() }
    }

    fun importDocuments(uris: List<Uri>, folders: Boolean) {
        if (uris.isEmpty()) return
        val targetPath = path
        loading = true
        ArixFileOperationBus.launch(ArixFileOperationKind.Import, totalCount = uris.size) {
            uris.forEachIndexed { index, uri ->
                ArixFileOperationBus.reportProgress(index + 1)
                runCatching {
                    context.contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION,
                    )
                }
                val document = if (folders) {
                    DocumentFile.fromTreeUri(context, uri)
                } else {
                    DocumentFile.fromSingleUri(context, uri)
                } ?: error("Unable to open the selected item.")
                importAndroidDocument(context, runtime, targetPath, document)
            }
        }
    }

    fun pasteClipboard() {
        val clip = clipboardEntry ?: return
        val targetPath = path
        val currentEntries = entries
        clipboardEntry = null
        ArixFileOperationBus.launch(ArixFileOperationKind.Copy) {
            require(clip.path != targetPath && !targetPath.startsWith("${clip.path}/")) {
                "A folder cannot be pasted into itself."
            }
            val targetName = uniqueAndroidCopyName(currentEntries, clip.name)
            runtime.copy(clip.path, joinAndroidFilePath(targetPath, targetName))
        }
    }

    fun pasteBatch() {
        val batch = batchClipboard ?: return
        val targetPath = path
        val currentEntries = entries
        batchClipboard = null
        exitSelectionMode()
        val batchKind = if (batch.mode == AndroidFileBatchMode.Copy) {
            ArixFileOperationKind.Copy
        } else {
            ArixFileOperationKind.Move
        }
        ArixFileOperationBus.launch(batchKind, totalCount = batch.entries.size) {
            val usedNames = currentEntries.map { it.name }.toMutableSet()
            batch.entries.forEachIndexed { index, entry ->
                ArixFileOperationBus.reportProgress(index + 1)
                require(targetPath != entry.path && !targetPath.startsWith("${entry.path}/")) {
                    "A folder cannot be pasted into itself."
                }
                val targetName = when (batch.mode) {
                    AndroidFileBatchMode.Copy -> {
                        val unique = uniqueAndroidBatchCopyName(usedNames, entry.name)
                        usedNames += unique
                        unique
                    }
                    AndroidFileBatchMode.Cut -> entry.name
                }
                val target = joinAndroidFilePath(targetPath, targetName)
                when (batch.mode) {
                    AndroidFileBatchMode.Copy -> runtime.copy(entry.path, target)
                    AndroidFileBatchMode.Cut -> {
                        if (entry.path != target) {
                            runtime.move(entry.path, target)
                        }
                    }
                }
            }
        }
    }

    fun deleteBatch() {
        val targets = entries.filter { it.path in selectedPaths }
        if (targets.isEmpty()) return
        ArixFileOperationBus.launch(ArixFileOperationKind.Delete, totalCount = targets.size) {
            targets.forEachIndexed { index, entry ->
                ArixFileOperationBus.reportProgress(index + 1)
                runtime.fileSystem.remove(entry.path, recursive = entry.isDirectory)
            }
        }
        exitSelectionMode()
    }

    val fileImportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments(),
        onResult = { importDocuments(it, folders = false) },
    )
    val folderImportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree(),
        onResult = { uri -> importDocuments(listOfNotNull(uri), folders = true) },
    )

    val safGrantLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree(),
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION,
                )
            }
            refresh()
        }
    }

    val isRestrictedAndroidFolder = remember(path) {
        path == "/device/Android/data" || path.startsWith("/device/Android/data/") ||
            path == "/device/Android/obb" || path.startsWith("/device/Android/obb/")
    }

    fun launchSafGrant() {
        val initialUri = if (isRestrictedAndroidFolder) {
            com.arix.app.runtime.AndroidSafStorageBridge.initialUriForGuestDevicePath(path)
        } else {
            null
        }
        runCatching { safGrantLauncher.launch(initialUri) }
            .onFailure { runCatching { safGrantLauncher.launch(null) } }
    }

    fun open(entry: AndroidTermuxFileEntry) {
        selected = null
        if (entry.isDirectory) {
            path = entry.path
            query = ""
            return
        }
        viewerEntry = entry
    }

    fun openInEditor(entry: AndroidTermuxFileEntry) {
        scope.launch {
            runCatching { runtime.fileSystem.read(entry.path, 8L * 1024 * 1024) }
                .onSuccess { bytes ->
                    if (entry.name.substringAfterLast('.', "").lowercase() in androidImageExtensions) {
                        imagePreview = bytes to entry.name
                    } else if (bytes.indexOfFirst { it == 0.toByte() } >= 0) {
                        // v3.1.14 — binary guard: editing a binary file as text
                        // would silently corrupt it on save.
                        error = "This file contains binary content and can't be edited as text."
                    } else {
                        editorContent = bytes.decodeToString()
                        editorFile = entry
                    }
                }
                .onFailure { error = it.message ?: "Unable to open file." }
        }
    }

    fun extractZip(entry: AndroidTermuxFileEntry, destinationName: String) {
        viewerEntry = null
        ArixFileOperationBus.launch(ArixFileOperationKind.Extract) {
            val zipHostFile = runtime.hostFile(entry.path)
            val zipFile = zipHostFile?.takeIf { it.isFile && it.canRead() }
                ?: error("Unable to read ${entry.name}.")
            val baseName = destinationName.ifBlank {
                entry.name.substringBeforeLast('.')
            }.replace(Regex("[^A-Za-z0-9._ ()-]+"), "_").trim().ifBlank { "extracted" }
            val parent = entry.path.substringBeforeLast('/', "")
            val parentPath = if (parent.isBlank()) "/" else parent
            var targetDir = joinAndroidFilePath(parentPath, baseName)
            var suffix = 1
            while (runtime.fileSystem.exists(targetDir)) {
                suffix += 1
                targetDir = joinAndroidFilePath(parentPath, "$baseName ($suffix)")
            }
            java.util.zip.ZipFile(zipFile).use { zip ->
                val entries = zip.entries()
                while (entries.hasMoreElements()) {
                    val zipEntry = entries.nextElement()
                    // Zip-slip guard: no absolute paths, no parent traversal.
                    val segments = zipEntry.name.replace("\\", "/").split('/')
                    require(!zipEntry.name.startsWith("/") && segments.none { it == ".." }) {
                        "Unsafe path in archive: ${zipEntry.name}"
                    }
                    val destination = joinAndroidFilePath(targetDir, zipEntry.name.replace("\\", "/").trimEnd('/'))
                    if (zipEntry.isDirectory) {
                        runtime.fileSystem.createDirectories(destination)
                    } else {
                        runtime.fileSystem.createDirectories(destination.substringBeforeLast('/'))
                        zip.getInputStream(zipEntry).use { input ->
                            runtime.importFile(destination, input)
                        }
                    }
                }
            }
        }
    }

    fun navigateBack(): Boolean {
        if (editorFile != null) {
            editorFile = null
            return true
        }
        if (selectionMode) {
            exitSelectionMode()
            return true
        }
        if (path != "/") {
            path = if (runtime.isTopLevelRoot(path)) "/" else path.substringBeforeLast('/', "").ifBlank { "/" }
            query = ""
            return true
        }
        return false
    }

    BackHandler { if (!navigateBack()) onBack() }
    LaunchedEffect(path) { refresh() }
    LaunchedEffect(environmentSetupPending) {
        while (environmentSetupPending) {
            kotlinx.coroutines.delay(5_000L)
            if (runCatching { runtime.isReady() }.getOrDefault(true)) {
                refresh()
            }
        }
    }

    if (editorFile != null) {
        SoraEditorScreen(
            entry = editorFile!!,
            initialContent = editorContent,
            onSave = { content ->
                val target = editorFile ?: return@SoraEditorScreen
                ArixFileOperationBus.launch(ArixFileOperationKind.Save) {
                    runtime.fileSystem.write(target.path, content.encodeToByteArray())
                }
            },
            onBack = { editorFile = null },
        )
        return
    }

    val visibleEntries = remember(entries, query, sort, showHidden) {
        entries
            .asSequence()
            .filter { showHidden || !it.name.startsWith(".") }
            .filter { query.isBlank() || it.name.contains(query, ignoreCase = true) }
            .sortedWith(compareByDescending<AndroidTermuxFileEntry> { it.isDirectory }.thenComparator { left, right ->
                when (sort) {
                    AndroidFileSort.Name -> left.name.compareTo(right.name, ignoreCase = true)
                    AndroidFileSort.Date -> right.modifiedAtMillis.compareTo(left.modifiedAtMillis)
                    AndroidFileSort.Size -> right.size.compareTo(left.size)
                }
            })
            .toList()
    }

    val actionsAvailable = path != "/"

    val browsingReadOnlyDeviceStorage = browsingDeviceStorage && !storageWriteGranted

    Scaffold(
        containerColor = ArixSettingsBackground,
        topBar = {
            Column(
                Modifier.fillMaxWidth().background(ArixSurface).statusBarsPadding()
                    .padding(horizontal = 8.dp, vertical = 8.dp),
            ) {
                if (selectionMode) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { exitSelectionMode() }) {
                            Icon(Icons.Rounded.Close, "Exit selection")
                        }
                        Column(Modifier.weight(1f)) {
                            Text(
                                "${selectedPaths.size} selected",
                                style = MaterialTheme.typography.titleMedium,
                                color = ArixOnSurface,
                            )
                            Text(
                                path,
                                style = MaterialTheme.typography.labelSmall,
                                color = ArixOnSurfaceVariant,
                                maxLines = 1,
                            )
                        }
                        IconButton(onClick = {
                            if (selectedPaths.size == visibleEntries.size) {
                                selectedPaths.clear()
                            } else {
                                selectedPaths.clear()
                                selectedPaths.addAll(visibleEntries.map { it.path })
                            }
                        }) {
                            Icon(
                                if (selectedPaths.size == visibleEntries.size && visibleEntries.isNotEmpty()) {
                                    Icons.Rounded.Check
                                } else {
                                    Icons.Rounded.DoneAll
                                },
                                "Select all",
                            )
                        }
                        IconButton(onClick = { deleteBatch() }) {
                            Icon(
                                Icons.Rounded.Delete,
                                "Delete selection",
                                tint = MaterialTheme.colorScheme.error,
                            )
                        }
                    }
                } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back")
                    }
                    Column(Modifier.weight(1f)) {
                        Text("Termux Files", style = MaterialTheme.typography.titleMedium, color = ArixOnSurface)
                        Text(path, style = MaterialTheme.typography.labelSmall, color = ArixOnSurfaceVariant, maxLines = 1)
                    }
                    IconButton(
                        onClick = {
                            if (path != "/") {
                                path = if (runtime.isTopLevelRoot(path)) "/" else path.substringBeforeLast('/', "").ifBlank { "/" }
                            }
                        },
                        enabled = path != "/",
                    ) { Icon(Icons.Rounded.ArrowUpward, "Parent folder") }
                    IconButton(onClick = { showSearch = !showSearch; if (!showSearch) query = "" }) {
                        Icon(if (showSearch) Icons.Rounded.Close else Icons.Rounded.Search, "Search")
                    }
                    if (loading) {
                        Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                        }
                    } else {
                        IconButton(onClick = ::refresh) { Icon(Icons.Rounded.Refresh, "Refresh") }
                    }
                    Box {
                        IconButton(onClick = { optionsExpanded = true }) {
                            Icon(Icons.Rounded.MoreVert, "View options")
                        }
                        DropdownMenu(expanded = optionsExpanded, onDismissRequest = { optionsExpanded = false }) {
                            DropdownMenuItem(
                                text = { Text(if (grid) "List view" else "Grid view") },
                                onClick = { grid = !grid; optionsExpanded = false },
                                leadingIcon = { Icon(if (grid) Icons.Rounded.ViewList else Icons.Rounded.GridView, null) },
                            )
                            DropdownMenuItem(
                                text = { Text(if (showHidden) "Hide hidden files" else "Show hidden files") },
                                onClick = { showHidden = !showHidden; optionsExpanded = false },
                                leadingIcon = {
                                    Icon(
                                        if (showHidden) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                        null,
                                    )
                                },
                            )
                            AndroidFileSort.entries.forEach { option ->
                                DropdownMenuItem(
                                    text = { Text("Sort by ${option.name.lowercase()}") },
                                    onClick = { sort = option; optionsExpanded = false },
                                    leadingIcon = { Icon(Icons.Rounded.Sort, null) },
                                )
                            }
                        }
                    }
                }
                }
                if (showSearch && !selectionMode) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                        placeholder = { Text("Search this folder") },
                        singleLine = true,
                    )
                }
            }
        },
        floatingActionButton = {
            if (actionsAvailable) {
                val fabWorkflowBusy = selectionMode || batchClipboard != null || clipboardEntry != null
                var fabHiddenUntilSettle by remember { mutableStateOf(false) }
                LaunchedEffect(activeFileOperation, fabWorkflowBusy) {
                    if (activeFileOperation != null || fabWorkflowBusy) {
                        fabHiddenUntilSettle = true
                    } else if (fabHiddenUntilSettle) {
                        kotlinx.coroutines.delay(ArixFileOperationBus.minimumHiddenWindowMillis)
                        fabHiddenUntilSettle = false
                    }
                }
                val operation = activeFileOperation
                val fabBusy = operation != null || fabWorkflowBusy
                if (fabBusy || !fabHiddenUntilSettle) {
                    AnimatedVisibility(
                        visible = !fabBusy,
                        enter = fadeIn(tween(160, easing = FastOutSlowInEasing)) +
                            scaleIn(initialScale = 0.72f, animationSpec = tween(180, easing = FastOutSlowInEasing)),
                        exit = fadeOut(tween(120, easing = FastOutSlowInEasing)) +
                            scaleOut(targetScale = 0.72f, animationSpec = tween(140, easing = FastOutSlowInEasing)),
                    ) {
                        Box {
                            FloatingActionButton(onClick = { createExpanded = true }, containerColor = ArixPrimary) {
                                Icon(Icons.Rounded.Add, "Create", tint = Color.White)
                            }
                            DropdownMenu(expanded = createExpanded, onDismissRequest = { createExpanded = false }) {
                            DropdownMenuItem(
                                text = { Text("New file") },
                                onClick = { draftName = ""; dialog = AndroidFileDialog.NewFile; createExpanded = false },
                                leadingIcon = { Icon(Icons.Rounded.Description, null) },
                            )
                            DropdownMenuItem(
                                text = { Text("New folder") },
                                onClick = { draftName = ""; dialog = AndroidFileDialog.NewFolder; createExpanded = false },
                                leadingIcon = { Icon(Icons.Rounded.CreateNewFolder, null) },
                            )
                            DropdownMenuItem(
                                text = { Text("Import files") },
                                onClick = { createExpanded = false; fileImportLauncher.launch(arrayOf("*/*")) },
                                leadingIcon = { Icon(Icons.Rounded.FileUpload, null) },
                            )
                            DropdownMenuItem(
                                text = { Text("Import folder") },
                                onClick = { createExpanded = false; folderImportLauncher.launch(null) },
                                leadingIcon = { Icon(Icons.Rounded.DriveFolderUpload, null) },
                            )
                            }
                        }
                    }
                }
                if (operation != null) {
                    AndroidFileOperationProgressPill(operation)
                }
            }
        },
    ) { contentPadding ->
        Box(
            Modifier.fillMaxSize().padding(contentPadding).navigationBarsPadding(),
            contentAlignment = Alignment.Center,
        ) {
            when {
                environmentSetupPending -> Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(32.dp),
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(28.dp))
                    Text(
                        "Setting up the Termux environment…",
                        style = MaterialTheme.typography.titleSmall,
                        color = ArixOnSurface,
                        modifier = Modifier.padding(top = 16.dp),
                    )
                    Text(
                        "The first launch installs the bundled Termux environment " +
                            "(no download needed). This screen fills in automatically.",
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        modifier = Modifier.padding(top = 8.dp),
                    )
                }
                storagePermissionNeeded -> Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(32.dp),
                ) {
                    Icon(
                        Icons.Rounded.Folder,
                        null,
                        tint = ArixPrimary,
                        modifier = Modifier.size(40.dp),
                    )
                    Text(
                        "Device storage access",
                        style = MaterialTheme.typography.titleSmall,
                        color = ArixOnSurface,
                        modifier = Modifier.padding(top = 14.dp),
                    )
                    Text(
                        if (storagePermissionDenied) {
                            "Storage access was denied. Allow it from Android Settings " +
                                "> Apps > Arix > Permissions, then come back."
                        } else {
                            "Allow storage access once to browse the device's shared storage " +
                                "(Download, DCIM, Pictures, …). Arix only reads and changes " +
                                "files you pick in the file manager."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        modifier = Modifier.padding(top = 8.dp),
                    )
                    if (!storagePermissionDenied) {
                        Button(
                            onClick = {
                                storagePermissionLauncher.launch(
                                    ArixDeviceStorage.runtimePermissions(),
                                )
                            },
                            colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                                containerColor = ArixPrimary,
                            ),
                            modifier = Modifier.padding(top = 16.dp),
                        ) {
                            Text(
                                "Allow storage access",
                                color = Color.White,
                            )
                        }
                    }
                    ArixDeviceStorage.allFilesAccessIntent(context)?.let { intent ->
                        TextButton(
                            onClick = { runCatching { context.startActivity(intent) } },
                            modifier = Modifier.padding(top = 4.dp),
                        ) {
                            Text("Allow full access (read + write)", color = ArixPrimary)
                        }
                    }
                }
                loading && entries.isEmpty() -> CircularProgressIndicator(modifier = Modifier.size(28.dp))
                isRestrictedAndroidFolder && visibleEntries.isEmpty() && query.isBlank() -> Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(32.dp),
                ) {
                    Icon(
                        Icons.Rounded.Lock,
                        null,
                        tint = ArixPrimary,
                        modifier = Modifier.size(40.dp),
                    )
                    Text(
                        "Android protects this folder",
                        style = MaterialTheme.typography.titleSmall,
                        color = ArixOnSurface,
                        modifier = Modifier.padding(top = 14.dp),
                    )
                    Text(
                        "On Android 11+ only the system can freely read Android/data and " +
                            "Android/obb. Grant access once — tap below, confirm \"Use this " +
                            "folder\" in the system picker (the data folder itself, or any " +
                            "specific app folder inside it), and Arix will list and open " +
                            "everything you granted. Arix's own app data is always visible.",
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        modifier = Modifier.padding(top = 8.dp),
                    )
                    Button(
                        onClick = { launchSafGrant() },
                        colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                            containerColor = ArixPrimary,
                        ),
                        modifier = Modifier.padding(top = 16.dp),
                    ) {
                        Text("Grant access", color = Color.White)
                    }
                    TextButton(
                        onClick = { refresh() },
                        modifier = Modifier.padding(top = 4.dp),
                    ) {
                        Text("Refresh", color = ArixPrimary)
                    }
                }
                visibleEntries.isEmpty() -> Text(
                    if (query.isBlank()) {
                        if (path == "/") "Choose a location to browse" else "This folder is empty"
                    } else {
                        "No matching files"
                    },
                    color = ArixOnSurfaceVariant,
                )
                grid -> LazyVerticalGrid(
                    columns = GridCells.Adaptive(140.dp),
                    modifier = Modifier.fillMaxSize().padding(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    gridItems(visibleEntries, key = { it.path }) { entry ->
                        AndroidFileGridItem(
                            entry = entry,
                            selectionMode = selectionMode,
                            isSelected = entry.path in selectedPaths,
                            onOpen = { if (selectionMode) toggleSelected(entry) else open(entry) },
                            onLongPress = {
                                if (!selectionMode) {
                                    selectionMode = true
                                    selectedPaths.clear()
                                }
                                toggleSelected(entry)
                            },
                            onMore = { selected = entry },
                        )
                    }
                }
                else -> LazyColumn(Modifier.fillMaxSize()) {
                    items(visibleEntries, key = { it.path }) { entry ->
                        AndroidFileListItem(
                            entry = entry,
                            selectionMode = selectionMode,
                            isSelected = entry.path in selectedPaths,
                            onOpen = { if (selectionMode) toggleSelected(entry) else open(entry) },
                            onLongPress = {
                                if (!selectionMode) {
                                    selectionMode = true
                                    selectedPaths.clear()
                                }
                                toggleSelected(entry)
                            },
                            onMore = { selected = entry },
                        )
                    }
                }
            }

            if (browsingReadOnlyDeviceStorage && !selectionMode && batchClipboard == null && clipboardEntry == null) {
                Surface(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 8.dp)
                        .fillMaxWidth(0.94f),
                    shape = RoundedCornerShape(14.dp),
                    color = ArixSurfaceHigh,
                    border = androidx.compose.foundation.BorderStroke(
                        width = 1.dp,
                        color = MaterialTheme.colorScheme.error.copy(alpha = 0.4f),
                    ),
                    shadowElevation = 6.dp,
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            Icons.Rounded.Lock,
                            null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(15.dp),
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "Read-only — allow full access to edit, move or copy files here",
                            style = MaterialTheme.typography.labelMedium,
                            color = ArixOnSurface,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f),
                        )
                        ArixDeviceStorage.allFilesAccessIntent(context)?.let { intent ->
                            TextButton(onClick = { runCatching { context.startActivity(intent) } }) {
                                Text("Unlock", color = ArixPrimary, style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }
                }
            }

            if (
                isRestrictedAndroidFolder && visibleEntries.isNotEmpty() &&
                !selectionMode && batchClipboard == null && clipboardEntry == null
            ) {
                Surface(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(
                            top = if (browsingReadOnlyDeviceStorage &&
                                !selectionMode && batchClipboard == null && clipboardEntry == null
                            ) {
                                52.dp
                            } else {
                                8.dp
                            },
                        )
                        .fillMaxWidth(0.94f),
                    shape = RoundedCornerShape(14.dp),
                    color = ArixSurfaceHigh,
                    border = androidx.compose.foundation.BorderStroke(
                        width = 1.dp,
                        color = ArixPrimary.copy(alpha = 0.35f),
                    ),
                    shadowElevation = 6.dp,
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            Icons.Rounded.Lock,
                            null,
                            tint = ArixPrimary,
                            modifier = Modifier.size(15.dp),
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "Android protects this folder — grant access to see more apps",
                            style = MaterialTheme.typography.labelMedium,
                            color = ArixOnSurface,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f),
                        )
                        TextButton(onClick = { launchSafGrant() }) {
                            Text("Grant", color = ArixPrimary, style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }

            if (selectionMode) {
                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 14.dp)
                        .fillMaxWidth(0.94f),
                    shape = RoundedCornerShape(18.dp),
                    color = ArixSurfaceHigh,
                    border = androidx.compose.foundation.BorderStroke(
                        width = 1.dp,
                        color = ArixPrimary.copy(alpha = 0.35f),
                    ),
                    shadowElevation = 10.dp,
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Button(
                            onClick = {
                                batchClipboard = AndroidFileBatch(
                                    entries = entries.filter { it.path in selectedPaths },
                                    mode = AndroidFileBatchMode.Copy,
                                )
                                exitSelectionMode()
                            },
                            enabled = selectedPaths.isNotEmpty(),
                            colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                                containerColor = ArixPrimary.copy(alpha = 0.16f),
                                contentColor = ArixPrimary,
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 4.dp),
                        ) {
                            Icon(Icons.Rounded.ContentCopy, null, modifier = Modifier.size(15.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Copy", style = MaterialTheme.typography.labelMedium, maxLines = 1)
                        }
                        Button(
                            onClick = {
                                batchClipboard = AndroidFileBatch(
                                    entries = entries.filter { it.path in selectedPaths },
                                    mode = AndroidFileBatchMode.Cut,
                                )
                                exitSelectionMode()
                            },
                            enabled = selectedPaths.isNotEmpty(),
                            colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                                containerColor = ArixPrimary.copy(alpha = 0.16f),
                                contentColor = ArixPrimary,
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 4.dp),
                        ) {
                            Icon(Icons.Rounded.DriveFileMove, null, modifier = Modifier.size(15.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Move", style = MaterialTheme.typography.labelMedium, maxLines = 1)
                        }
                        Button(
                            onClick = { deleteBatch() },
                            enabled = selectedPaths.isNotEmpty(),
                            colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.14f),
                                contentColor = MaterialTheme.colorScheme.error,
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 4.dp),
                        ) {
                            Icon(Icons.Rounded.Delete, null, modifier = Modifier.size(15.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Delete", style = MaterialTheme.typography.labelMedium, maxLines = 1)
                        }
                    }
                }
            }

            batchClipboard?.let { batch ->
                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 14.dp)
                        .fillMaxWidth(0.94f),
                    shape = RoundedCornerShape(16.dp),
                    color = ArixSurface,
                    border = androidx.compose.foundation.BorderStroke(
                        width = 1.dp,
                        color = ArixOutline.copy(alpha = 0.4f),
                    ),
                    shadowElevation = 10.dp,
                ) {
                    Row(
                        modifier = Modifier.padding(start = 14.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            if (batch.mode == AndroidFileBatchMode.Cut) Icons.Rounded.DriveFileMove else Icons.Rounded.ContentCopy,
                            null,
                            tint = ArixPrimary,
                            modifier = Modifier.size(16.dp),
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            text = "${batch.entries.size} item(s) ${if (batch.mode == AndroidFileBatchMode.Cut) "to move" else "to copy"}",
                            style = MaterialTheme.typography.labelMedium,
                            color = ArixOnSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f),
                        )
                        TextButton(onClick = ::pasteBatch) {
                            Text("Paste here", color = ArixPrimary)
                        }
                        IconButton(
                            onClick = { batchClipboard = null },
                            modifier = Modifier.size(32.dp),
                        ) {
                            Icon(
                                Icons.Rounded.Close,
                                null,
                                tint = ArixOnSurfaceVariant,
                                modifier = Modifier.size(15.dp),
                            )
                        }
                    }
                }
            }

            if (batchClipboard == null) {
                clipboardEntry?.let { clip ->
                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 14.dp)
                        .fillMaxWidth(0.94f),
                    shape = RoundedCornerShape(16.dp),
                    color = ArixSurface,
                    border = androidx.compose.foundation.BorderStroke(
                        width = 1.dp,
                        color = ArixOutline.copy(alpha = 0.4f),
                    ),
                    shadowElevation = 10.dp,
                ) {
                    Row(
                        modifier = Modifier.padding(start = 14.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            Icons.Rounded.ContentCopy,
                            null,
                            tint = ArixPrimary,
                            modifier = Modifier.size(16.dp),
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            text = clip.name,
                            style = MaterialTheme.typography.labelMedium,
                            color = ArixOnSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f),
                        )
                        TextButton(onClick = ::pasteClipboard) {
                            Text("Paste here", color = ArixPrimary)
                        }
                        IconButton(
                            onClick = { clipboardEntry = null },
                            modifier = Modifier.size(32.dp),
                        ) {
                            Icon(
                                Icons.Rounded.Close,
                                null,
                                tint = ArixOnSurfaceVariant,
                                modifier = Modifier.size(15.dp),
                            )
                        }
                    }
                }
                }
            }
        }
    }

    selected?.let { entry ->
        Dialog(onDismissRequest = { selected = null }) {
            androidx.compose.material3.Surface(shape = RoundedCornerShape(8.dp), color = ArixSurface) {
                Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                    Text(entry.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(16.dp))
                    DropdownMenuItem(
                        text = { Text("Open") },
                        onClick = { open(entry) },
                        leadingIcon = { Icon(if (entry.isDirectory) Icons.Rounded.Folder else Icons.Rounded.Description, null) },
                    )
                    DropdownMenuItem(
                        text = { Text("Rename") },
                        onClick = { draftName = entry.name; dialog = AndroidFileDialog.Rename },
                        leadingIcon = { Icon(Icons.Rounded.Edit, null) },
                    )
                    DropdownMenuItem(
                        text = { Text("Copy") },
                        onClick = { clipboardEntry = entry; selected = null },
                        leadingIcon = { Icon(Icons.Rounded.ContentCopy, null) },
                    )
                    DropdownMenuItem(
                        text = { Text("Move") },
                        onClick = {
                            batchClipboard = AndroidFileBatch(
                                entries = listOf(entry),
                                mode = AndroidFileBatchMode.Cut,
                            )
                            selected = null
                        },
                        leadingIcon = { Icon(Icons.Rounded.DriveFileMove, null) },
                    )
                    DropdownMenuItem(
                        text = { Text("Permissions") },
                        onClick = {
                            scope.launch {
                                val snapshot = runCatching { runtime.statPermissions(entry.path) }.getOrNull()
                                permissionsState = AndroidFilePermissionsState(
                                    entry = entry,
                                    initial = snapshot,
                                    current = snapshot ?: AndroidFilePermissions(
                                        ownerRead = true, ownerWrite = true, ownerExecute = false,
                                        groupRead = true, groupWrite = false, groupExecute = false,
                                        otherRead = true, otherWrite = false, otherExecute = false,
                                    ),
                                )
                            }
                            selected = null
                        },
                        leadingIcon = { Icon(Icons.Rounded.Lock, null) },
                    )
                    DropdownMenuItem(
                        text = { Text("Delete", color = MaterialTheme.colorScheme.error) },
                        onClick = { dialog = AndroidFileDialog.Delete },
                        leadingIcon = { Icon(Icons.Rounded.Delete, null, tint = MaterialTheme.colorScheme.error) },
                    )
                }
            }
        }
    }

    if (dialog != AndroidFileDialog.None) {
        AlertDialog(
            onDismissRequest = { dialog = AndroidFileDialog.None; selected = null },
            title = {
                Text(when (dialog) {
                    AndroidFileDialog.NewFile -> "New file"
                    AndroidFileDialog.NewFolder -> "New folder"
                    AndroidFileDialog.Rename -> "Rename"
                    AndroidFileDialog.Delete -> "Delete ${selected?.name.orEmpty()}?"
                    AndroidFileDialog.None -> ""
                })
            },
            text = {
                if (dialog == AndroidFileDialog.Delete) {
                    Text(if (selected?.isDirectory == true) "The folder and all of its contents will be permanently deleted." else "This item will be permanently deleted.")
                } else {
                    OutlinedTextField(value = draftName, onValueChange = { draftName = it }, label = { Text("Name") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(
                    enabled = (dialog == AndroidFileDialog.Delete || validAndroidFileName(draftName)) &&
                        (dialog !in setOf(AndroidFileDialog.Rename, AndroidFileDialog.Delete) || selected != null),
                    onClick = {
                        val operation = dialog
                        val item = selected
                        val name = draftName.trim()
                        dialog = AndroidFileDialog.None
                        val targetPath = path
                        val kind = when (operation) {
                            AndroidFileDialog.NewFile, AndroidFileDialog.NewFolder -> ArixFileOperationKind.Create
                            AndroidFileDialog.Rename -> ArixFileOperationKind.Rename
                            AndroidFileDialog.Delete -> ArixFileOperationKind.Delete
                            AndroidFileDialog.None -> ArixFileOperationKind.Create
                        }
                        ArixFileOperationBus.launch(kind) {
                            when (operation) {
                                AndroidFileDialog.NewFile -> {
                                    val target = joinAndroidFilePath(targetPath, name)
                                    require(!runtime.fileSystem.exists(target)) { "An item named $name already exists." }
                                    runtime.fileSystem.write(target, ByteArray(0))
                                }
                                AndroidFileDialog.NewFolder -> {
                                    val target = joinAndroidFilePath(targetPath, name)
                                    require(!runtime.fileSystem.exists(target)) { "An item named $name already exists." }
                                    runtime.fileSystem.createDirectories(target)
                                }
                                AndroidFileDialog.Rename -> {
                                    val target = joinAndroidFilePath(targetPath, name)
                                    val renameItem = item ?: return@launch
                                    if (renameItem.path != target) runtime.move(renameItem.path, target)
                                }
                                AndroidFileDialog.Delete -> {
                                    val deleteItem = item ?: return@launch
                                    runtime.fileSystem.remove(deleteItem.path, recursive = deleteItem.isDirectory)
                                }
                                AndroidFileDialog.None -> Unit
                            }
                        }
                        selected = null
                    },
                ) { Text(if (dialog == AndroidFileDialog.Delete) "Delete" else "Confirm") }
            },
            dismissButton = { TextButton(onClick = { dialog = AndroidFileDialog.None; selected = null }) { Text("Cancel") } },
        )
    }

    permissionsState?.let { state ->
        val loaded = state.initial
        AlertDialog(
            onDismissRequest = { permissionsState = null },
            title = { Text("Permissions") },
            text = {
                Column {
                    Text(
                        state.entry.name,
                        style = MaterialTheme.typography.labelMedium,
                        color = ArixOnSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        state.entry.path,
                        style = MaterialTheme.typography.labelSmall,
                        color = ArixOnSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 2.dp, bottom = 10.dp),
                    )
                    Row(Modifier.fillMaxWidth()) {
                        Spacer(Modifier.weight(1f))
                        Text("Read", style = MaterialTheme.typography.labelSmall, color = ArixOnSurfaceVariant, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        Text("Write", style = MaterialTheme.typography.labelSmall, color = ArixOnSurfaceVariant, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        Text("Exec", style = MaterialTheme.typography.labelSmall, color = ArixOnSurfaceVariant, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    }
                    @androidx.compose.runtime.Composable
                    fun permissionRow(
                        label: String,
                        read: Boolean, write: Boolean, execute: Boolean,
                        onRead: (Boolean) -> Unit, onWrite: (Boolean) -> Unit, onExecute: (Boolean) -> Unit,
                    ) {
                        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(label, style = MaterialTheme.typography.bodyMedium, color = ArixOnSurface, modifier = Modifier.weight(1f))
                            androidx.compose.material3.Checkbox(checked = read, onCheckedChange = onRead, modifier = Modifier.weight(1f))
                            androidx.compose.material3.Checkbox(checked = write, onCheckedChange = onWrite, modifier = Modifier.weight(1f))
                            androidx.compose.material3.Checkbox(checked = execute, onCheckedChange = onExecute, modifier = Modifier.weight(1f))
                        }
                    }
                    permissionRow(
                        "Owner",
                        state.current.ownerRead, state.current.ownerWrite, state.current.ownerExecute,
                        onRead = { permissionsState = state.copy(current = state.current.copy(ownerRead = it)) },
                        onWrite = { permissionsState = state.copy(current = state.current.copy(ownerWrite = it)) },
                        onExecute = { permissionsState = state.copy(current = state.current.copy(ownerExecute = it)) },
                    )
                    permissionRow(
                        "Group",
                        state.current.groupRead, state.current.groupWrite, state.current.groupExecute,
                        onRead = { permissionsState = state.copy(current = state.current.copy(groupRead = it)) },
                        onWrite = { permissionsState = state.copy(current = state.current.copy(groupWrite = it)) },
                        onExecute = { permissionsState = state.copy(current = state.current.copy(groupExecute = it)) },
                    )
                    permissionRow(
                        "Other",
                        state.current.otherRead, state.current.otherWrite, state.current.otherExecute,
                        onRead = { permissionsState = state.copy(current = state.current.copy(otherRead = it)) },
                        onWrite = { permissionsState = state.copy(current = state.current.copy(otherWrite = it)) },
                        onExecute = { permissionsState = state.copy(current = state.current.copy(otherExecute = it)) },
                    )
                    Text(
                        "${state.current.symbolic}  (${state.current.octal})",
                        style = MaterialTheme.typography.labelMedium,
                        color = ArixPrimary,
                        modifier = Modifier.padding(top = 8.dp),
                    )
                    if (loaded == null) {
                        Text(
                            "This filesystem does not report POSIX permissions — the editor shows a best-effort default. Shared storage (the /device root) may ignore permission changes.",
                            style = MaterialTheme.typography.labelSmall,
                            color = ArixOnSurfaceVariant,
                            modifier = Modifier.padding(top = 6.dp),
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val target = state.entry
                        val requested = state.current
                        permissionsState = null
                        ArixFileOperationBus.launch(ArixFileOperationKind.Save) {
                            runtime.updatePermissions(target.path, requested)
                        }
                    },
                ) { Text("Apply") }
            },
            dismissButton = {
                TextButton(onClick = { permissionsState = null }) { Text("Cancel") }
            },
        )
    }

    viewerEntry?.let { entry ->
        ArixFileViewer(
            name = entry.name,
            size = entry.size,
            modifiedAtMillis = entry.modifiedAtMillis,
            hostFile = { runtime.hostFile(entry.path) },
            readPrefix = { maximumBytes -> runtime.fileSystem.readPrefix(entry.path, maximumBytes) },
            onEdit = if (arixFileViewerIsText(entry.name)) {
                { viewerEntry = null; openInEditor(entry) }
            } else {
                null
            },
            onDismiss = { viewerEntry = null },
            onExtract = { destinationName -> extractZip(entry, destinationName) },
        )
    }

    imagePreview?.let { (bytes, previewName) ->
        ArixMediaViewerDialog(
            onDismiss = { imagePreview = null },
            imageBytes = bytes,
            imageMimeType = "image/jpeg",
            title = previewName,
            fileName = previewName.ifBlank { "arix-file-image.jpg" },
        )
    }

    error?.let { message ->
        AlertDialog(
            onDismissRequest = { error = null },
            title = { Text("File operation failed") },
            text = { Text(message) },
            confirmButton = { TextButton(onClick = { error = null }) { Text("OK") } },
        )
    }

    fileOperationError?.let { message ->
        AlertDialog(
            onDismissRequest = { ArixFileOperationBus.clearError() },
            title = { Text("File operation failed") },
            text = { Text(message) },
            confirmButton = {
                TextButton(onClick = { ArixFileOperationBus.clearError() }) { Text("OK") }
            },
        )
    }
}

@Composable
private fun AndroidFileOperationProgressPill(operation: com.arix.app.runtime.ArixFileOperation) {
    Surface(
        shape = RoundedCornerShape(50),
        color = ArixSurfaceHigh,
        border = androidx.compose.foundation.BorderStroke(1.dp, ArixPrimary.copy(alpha = 0.35f)),
        shadowElevation = 6.dp,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(start = 14.dp, end = 18.dp, top = 8.dp, bottom = 8.dp),
        ) {
            CircularProgressIndicator(
                modifier = Modifier.size(14.dp),
                strokeWidth = 2.dp,
                color = ArixPrimary,
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = operation.progressLabel + "…",
                style = MaterialTheme.typography.labelMedium,
                color = ArixOnSurface,
                maxLines = 1,
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AndroidFileListItem(
    entry: AndroidTermuxFileEntry,
    selectionMode: Boolean,
    isSelected: Boolean,
    onOpen: () -> Unit,
    onLongPress: () -> Unit,
    onMore: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(
                if (isSelected) ArixPrimary.copy(alpha = 0.12f) else androidx.compose.ui.graphics.Color.Transparent,
            )
            .combinedClickable(onClick = onOpen, onLongClick = onLongPress)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (selectionMode) {
            Box(
                modifier = Modifier
                    .size(22.dp)
                    .clip(CircleShape)
                    .background(
                        if (isSelected) ArixPrimary else androidx.compose.ui.graphics.Color.Transparent,
                    )
                    .border(
                        width = 1.5.dp,
                        color = if (isSelected) ArixPrimary else ArixOutline,
                        shape = CircleShape,
                    ),
                contentAlignment = Alignment.Center,
            ) {
                if (isSelected) {
                    Icon(
                        Icons.Rounded.Check,
                        contentDescription = "Selected",
                        tint = ArixOnPrimary,
                        modifier = Modifier.size(14.dp),
                    )
                }
            }
            Spacer(Modifier.size(12.dp))
        }
        Icon(if (entry.isDirectory) Icons.Rounded.Folder else Icons.Rounded.Description, null, tint = if (entry.isDirectory) ArixPrimary else ArixOnSurfaceVariant, modifier = Modifier.size(28.dp))
        Spacer(Modifier.size(12.dp))
        Column(Modifier.weight(1f)) {
            Text(entry.name, color = if (isSelected) ArixPrimary else ArixOnSurface, maxLines = 1)
            Text(if (entry.isDirectory) AndroidFileEntryDateFormatter.format(Date(entry.modifiedAtMillis)) else formatAndroidFileSize(entry.size), color = ArixOnSurfaceVariant, style = MaterialTheme.typography.labelSmall)
        }
        if (!selectionMode) {
            IconButton(onClick = onMore) { Icon(Icons.Rounded.MoreVert, "More") }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AndroidFileGridItem(
    entry: AndroidTermuxFileEntry,
    selectionMode: Boolean,
    isSelected: Boolean,
    onOpen: () -> Unit,
    onLongPress: () -> Unit,
    onMore: () -> Unit,
) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(
                if (isSelected) ArixPrimary.copy(alpha = 0.12f) else ArixSurface,
                RoundedCornerShape(8.dp),
            )
            .combinedClickable(onClick = onOpen, onLongClick = onLongPress)
            .padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            if (selectionMode) {
                Box(
                    modifier = Modifier
                        .size(20.dp)
                        .clip(CircleShape)
                        .background(
                            if (isSelected) ArixPrimary else androidx.compose.ui.graphics.Color.Transparent,
                        )
                        .border(
                            width = 1.5.dp,
                            color = if (isSelected) ArixPrimary else ArixOutline,
                            shape = CircleShape,
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    if (isSelected) {
                        Icon(
                            Icons.Rounded.Check,
                            contentDescription = "Selected",
                            tint = ArixOnPrimary,
                            modifier = Modifier.size(12.dp),
                        )
                    }
                }
            } else {
                Spacer(Modifier.size(20.dp))
            }
            if (!selectionMode) {
                IconButton(onClick = onMore, modifier = Modifier.size(32.dp)) { Icon(Icons.Rounded.MoreVert, "More") }
            } else {
                Spacer(Modifier.size(32.dp))
            }
        }
        Icon(if (entry.isDirectory) Icons.Rounded.Folder else Icons.Rounded.Description, null, tint = if (entry.isDirectory) ArixPrimary else ArixOnSurfaceVariant, modifier = Modifier.size(40.dp))
        Spacer(Modifier.size(8.dp))
        Text(
            entry.name,
            maxLines = 2,
            style = MaterialTheme.typography.bodySmall,
            color = if (isSelected) ArixPrimary else ArixOnSurface,
        )
    }
}

@Composable
private fun SoraEditorScreen(
    entry: AndroidTermuxFileEntry,
    initialContent: String,
    onSave: (String) -> Unit,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    var editor by remember(entry.path) { mutableStateOf<CodeEditor?>(null) }
    var wrapsLines by remember(entry.path) { mutableStateOf(false) }

    Scaffold(
        containerColor = ArixSettingsBackground,
        topBar = {
            Row(
                Modifier.fillMaxWidth().background(ArixSurface).statusBarsPadding().padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") }
                Column(Modifier.weight(1f)) {
                    Text(entry.name, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                    Text(entry.path, style = MaterialTheme.typography.labelSmall, color = ArixOnSurfaceVariant, maxLines = 1)
                }
                IconButton(onClick = { wrapsLines = !wrapsLines; editor?.setWordwrap(wrapsLines) }) {
                    Icon(Icons.Rounded.WrapText, "Toggle line wrapping", tint = if (wrapsLines) ArixPrimary else ArixOnSurfaceVariant)
                }
                IconButton(onClick = {
                    val content = editor?.text?.toString() ?: initialContent
                    onSave(content)
                }) { Icon(Icons.Rounded.Save, "Save") }
            }
        },
    ) { padding ->
        AndroidView(
            factory = {
                CodeEditor(context).apply {
                    setText(initialContent)
                    setLineNumberEnabled(true)
                    setWordwrap(wrapsLines)
                    setColorScheme(ArixDarkEditorColorScheme())
                    editor = this
                }
            },
            update = { it.setWordwrap(wrapsLines) },
            onRelease = { released ->
                if (editor === released) editor = null
                released.release()
            },
            modifier = Modifier.fillMaxSize().padding(padding).navigationBarsPadding(),
        )
    }
}

private class ArixDarkEditorColorScheme : SchemeDarcula() {
    override fun applyDefault() {
        super.applyDefault()
        setColor(WHOLE_BACKGROUND, 0xFF0B0D17.toInt())
        setColor(LINE_NUMBER_BACKGROUND, 0xFF191D2A.toInt())
        setColor(LINE_NUMBER, 0xFF8A8794.toInt())
        setColor(LINE_NUMBER_CURRENT, 0xFFF4F2EE.toInt())
        setColor(LINE_DIVIDER, 0xFF3A3F48.toInt())
        setColor(CURRENT_LINE, 0xFF12141F.toInt())
        setColor(SELECTED_TEXT_BACKGROUND, 0xFF36265C.toInt())
        setColor(SELECTION_INSERT, 0xFFC3AFFF.toInt())
        setColor(SELECTION_HANDLE, 0xFFC3AFFF.toInt())
        setColor(TEXT_SELECTED, 0xFFF4F2EE.toInt())
        setColor(TEXT_NORMAL, 0xFFF4F2EE.toInt())
        setColor(BLOCK_LINE, 0xFF4A5058.toInt())
        setColor(BLOCK_LINE_CURRENT, 0xFF6C7380.toInt())
        setColor(SCROLL_BAR_THUMB, 0xFF6C7380.toInt())
        setColor(SCROLL_BAR_THUMB_PRESSED, 0xFF9AA0A6.toInt())
        setColor(SCROLL_BAR_TRACK, 0xFF20242F.toInt())
        setColor(MATCHED_TEXT_BACKGROUND, 0xFF2F2455.toInt())
        setColor(NON_PRINTABLE_CHAR, 0xFF777F89.toInt())
        setColor(COMPLETION_WND_BACKGROUND, 0xFF191D2A.toInt())
        setColor(COMPLETION_WND_CORNER, 0xFF4A5058.toInt())
    }
}

private val androidImageExtensions = setOf("png", "jpg", "jpeg", "gif", "webp", "bmp")

private suspend fun importAndroidDocument(
    context: Context,
    runtime: AndroidTermuxFileManagerRuntime,
    parentPath: String,
    document: DocumentFile,
) {
    val name = document.name?.trim().orEmpty()
    require(validAndroidFileName(name)) { "The selected item has an invalid name." }
    val target = joinAndroidFilePath(parentPath, name)
    require(!runtime.fileSystem.exists(target)) { "An item named $name already exists." }

    if (!document.isDirectory) {
        val input = context.contentResolver.openInputStream(document.uri)
            ?: error("Unable to read $name.")
        input.use { runtime.importFile(target, it) }
        return
    }

    runtime.fileSystem.createDirectories(target)
    try {
        document.listFiles().forEach { child ->
            importAndroidDocument(context, runtime, target, child)
        }
    } catch (error: Throwable) {
        runCatching { runtime.fileSystem.remove(target, recursive = true) }
        throw error
    }
}

private fun validAndroidFileName(name: String): Boolean =
    name.trim().let { it.isNotEmpty() && it != "." && it != ".." && '/' !in it }

private fun joinAndroidFilePath(parent: String, name: String): String =
    if (parent == "/") "/$name" else "${parent.trimEnd('/')}/$name"

private fun uniqueAndroidCopyName(entries: List<AndroidTermuxFileEntry>, name: String): String {
    if (entries.none { it.name == name }) return name
    val dot = name.lastIndexOf('.')
    val stem = if (dot > 0) name.substring(0, dot) else name
    val extension = if (dot > 0) name.substring(dot) else ""
    var index = 1
    while (true) {
        val candidate = "$stem ($index)$extension"
        if (entries.none { it.name == candidate }) return candidate
        index++
    }
}

private fun uniqueAndroidBatchCopyName(usedNames: Set<String>, name: String): String {
    if (name !in usedNames) return name
    val dot = name.lastIndexOf('.')
    val stem = if (dot > 0) name.substring(0, dot) else name
    val extension = if (dot > 0) name.substring(dot) else ""
    var index = 1
    while (true) {
        val candidate = "$stem ($index)$extension"
        if (candidate !in usedNames) return candidate
        index++
    }
}

private fun formatAndroidFileSize(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var value = bytes.toDouble()
    var unit = -1
    while (value >= 1024 && unit < units.lastIndex) {
        value /= 1024
        unit++
    }
    return "%.1f %s".format(value, units[unit])
}

@Composable
internal fun TermuxFilesSetupPrompt(
    detail: String,
    onInitialize: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ArixSettingsBackground)
            .statusBarsPadding()
            .padding(horizontal = 24.dp, vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(ArixPrimary.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = Icons.Rounded.Folder,
                contentDescription = null,
                tint = ArixPrimary,
                modifier = Modifier.size(34.dp),
            )
        }
        Spacer(Modifier.height(18.dp))
        Text(
            text = "Termux Files",
            style = MaterialTheme.typography.titleLarge,
            color = ArixOnSurface,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = "The file manager needs the Termux runtime. Initialize it once and your workspace files will appear here.",
            style = MaterialTheme.typography.bodyMedium,
            color = ArixOnSurfaceVariant,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
        if (detail.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(
                text = detail,
                style = MaterialTheme.typography.labelSmall,
                color = ArixOnSurfaceVariant,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                maxLines = 3,
            )
        }
        Spacer(Modifier.height(22.dp))
        Button(
            onClick = onInitialize,
            shape = RoundedCornerShape(18.dp),
        ) {
            Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("Initialize Termux")
        }
    }
}
