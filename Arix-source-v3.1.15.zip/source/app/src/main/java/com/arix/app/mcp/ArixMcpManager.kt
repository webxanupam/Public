package com.arix.app.mcp

import com.arix.app.runtime.TermuxRuntime
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

class ArixMcpManager(
    private val repository: ArixMcpRepository,
    private val termuxRuntime: TermuxRuntime?,
    private val onLog: (String) -> Unit = {},
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val reloadMutex = Mutex()
    private val statusMutex = Mutex()
    private val httpClient = ArixMcpClient.mcpOkHttpClient()

    private data class Connection(
        val config: ArixMcpServerConfig,
        val client: ArixMcpClient,
        val tools: List<ArixMcpToolDescriptor>,
    )

    private val connections = ConcurrentHashMap<String, Connection>()
    private var configJob: Job? = null

    private val reconnectDelays = ConcurrentHashMap<String, Long>()

    private val _statuses = MutableStateFlow<List<ArixMcpServerStatus>>(emptyList())
    val statuses: StateFlow<List<ArixMcpServerStatus>> = _statuses.asStateFlow()

    private val _reloading = MutableStateFlow(false)
    val reloading: StateFlow<Boolean> = _reloading.asStateFlow()

    fun start() {
        if (configJob?.isActive == true) return
        configJob = scope.launch {
            repository.servers.collect { servers ->
                reload(servers)
            }
        }
    }

    fun stop() {
        configJob?.cancel()
        configJob = null
        connections.values.toList().forEach { connection ->
            runCatching { connection.client.close() }
        }
        connections.clear()
    }

    suspend fun reload() {
        val servers = repository.servers.first()
        reload(servers)
    }

    suspend fun reloadServer(name: String) {
        val all = repository.servers.first()
        if (all.none { it.name == name }) return
        disconnect(name)
        reload(all)
    }

    suspend fun removeServer(name: String) {
        disconnect(name)
        repository.removeServer(name)
        statusMutex.withLock {
            _statuses.value = _statuses.value.filter { it.name != name }
        }
        runCatching { termuxRuntime?.releaseMcpOwner(name) }
    }

    private suspend fun reload(servers: List<ArixMcpServerConfig>) {
        reloadMutex.withLock {
            _reloading.value = true
            try {
                connections.values.toList().forEach { connection ->
                    val current = servers.firstOrNull { it.name == connection.config.name }
                    if (current == null || current != connection.config) {
                        disconnect(connection.config.name)
                    }
                }
                servers.filter { it.enabled && !connections.containsKey(it.name) }.map { server ->
                    scope.async { connectOne(server) }
                }.awaitAll()
                publishStatuses(servers)
                servers.filter { !it.enabled && it.isStdio }.forEach { off ->
                    runCatching { termuxRuntime?.releaseMcpOwner(off.name) }
                }
            } finally {
                _reloading.value = false
            }
        }
    }

    private fun disconnect(name: String) {
        connections.remove(name)?.let { connection ->
            runCatching { connection.client.close() }
        }
    }

    private suspend fun connectOne(server: ArixMcpServerConfig) {
        upsertStatus(
            ArixMcpServerStatus(name = server.name, state = ArixMcpServerStatus.State.CONNECTING),
        )
        var client: ArixMcpClient? = null
        try {
            if (server.isStdio) {
                termuxRuntime?.let { runtime ->
                    val pyFailure = runCatching {
                        runtime.ensurePythonRuntime(installWhenMissing = true)
                    }.getOrNull()
                    if (pyFailure != null) {
                        throw IllegalStateException(
                            "Local MCP servers need the embedded runtime's Python " +
                                "($pyFailure). Open Tools ▸ Terminal once to finish setup, then reload.",
                        )
                    }
                    val base = server.command.orEmpty().trim().substringAfterLast('/')
                    val bundled = server.args.any { it.startsWith("@modelcontextprotocol/server-memory") ||
                        it.startsWith("@modelcontextprotocol/server-sequential-thinking") }
                    val needsNode = !bundled && base in setOf("npx", "npm", "node", "nodejs", "pnpm", "bunx", "pnpx")
                    if (needsNode) {
                        val failure = runCatching {
                            runtime.ensureNodeRuntime(installWhenMissing = true)
                        }.getOrNull()
                        if (failure != null) {
                            throw IllegalStateException(
                                "This MCP server is a Node.js package ($failure). " +
                                    "Open Tools ▸ Terminal once to finish setup, then reload.",
                            )
                        }
                    }
                } ?: throw IllegalStateException(
                    "Local MCP servers need the embedded runtime — open Tools ▸ Terminal once to finish setup",
                )
            }
            val newClient = ArixMcpClient(
                config = server,
                httpClient = httpClient,
                termuxRuntime = termuxRuntime,
                onLog = onLog,
                onClosed = { unexpected ->
                    connections.remove(server.name)
                    if (unexpected) {
                        scope.launch {
                            upsertStatus(
                                ArixMcpServerStatus(
                                    name = server.name,
                                    state = ArixMcpServerStatus.State.FAILED,
                                    error = "connection lost",
                                ),
                            )
                            val backoff = reconnectDelays.merge(
                                server.name,
                                RECONNECT_BASE_DELAY_MS,
                            ) { old, _ -> (old * 2).coerceAtMost(RECONNECT_MAX_DELAY_MS) } ?: RECONNECT_BASE_DELAY_MS
                            delay(backoff)
                            val stillConfigured = repository.servers.first()
                                .any { it.name == server.name && it.enabled }
                            if (stillConfigured && !connections.containsKey(server.name)) {
                                connectOne(server)
                            }
                        }
                    }
                },
                onOAuthUpdated = { oauth ->
                    scope.launch { repository.updateOAuth(server.name, oauth) }
                },
            )
            client = newClient
            newClient.connect()
            val tools = newClient.listTools()
            connections[server.name] = Connection(server, newClient, tools)
            reconnectDelays.remove(server.name)
            upsertStatus(
                ArixMcpServerStatus(
                    name = server.name,
                    state = ArixMcpServerStatus.State.CONNECTED,
                    toolCount = tools.size,
                ),
            )
        } catch (error: Exception) {
            runCatching { client?.close() }
            upsertStatus(
                ArixMcpServerStatus(
                    name = server.name,
                    state = ArixMcpServerStatus.State.FAILED,
                    error = error.message ?: error.javaClass.simpleName,
                ),
            )
        }
    }

    private suspend fun upsertStatus(status: ArixMcpServerStatus) {
        statusMutex.withLock {
            _statuses.value = _statuses.value.filter { it.name != status.name } + status
        }
    }

    private suspend fun publishStatuses(servers: List<ArixMcpServerConfig>) {
        statusMutex.withLock {
            _statuses.value = servers.map { server ->
                val existing = _statuses.value.firstOrNull { it.name == server.name }
                when {
                    !server.enabled -> ArixMcpServerStatus(
                        name = server.name,
                        state = ArixMcpServerStatus.State.DISABLED,
                    )
                    existing != null -> existing
                    else -> ArixMcpServerStatus(
                        name = server.name,
                        state = ArixMcpServerStatus.State.CONNECTING,
                    )
                }
            }
        }
    }

    fun toolDefinitions(): JSONArray {
        val definitions = JSONArray()
        connections.values.toList().forEach { connection ->
            connection.tools
                .filter { it.name !in connection.config.disabledTools }
                .forEach { tool ->
                    definitions.put(toolHostDefinition(connection.config.name, tool))
                }
        }
        return definitions
    }

    private fun toolHostDefinition(
        serverName: String,
        tool: ArixMcpToolDescriptor,
    ): JSONObject {
        val namespaced = namespacedToolName(serverName, tool.name)
        return JSONObject().apply {
            put("name", namespaced)
            put(
                "description",
                tool.description?.takeIf { it.isNotBlank() }
                    ?: "MCP tool ${tool.name} on server $serverName",
            )
            put(
                "parameters",
                tool.inputSchema ?: JSONObject().apply {
                    put("type", "object")
                    put("properties", JSONObject())
                },
            )
        }
    }

    suspend fun executeTool(namespacedName: String, arguments: JSONObject): ArixMcpCallResult {
        val (serverName, toolName) = parseNamespacedToolName(namespacedName)
        val connection = connections[serverName]
            ?: return ArixMcpCallResult(
                text = "MCP server \"$serverName\" is not connected. Open Settings ▸ MCP Servers " +
                    "and check its status (reload if needed).",
                isError = true,
            )
        return connection.client.callTool(toolName, arguments)
    }

    companion object {
        fun namespacedToolName(serverName: String, toolName: String): String {
            val safeTool = sanitizeToolPart(toolName)
            val maxServer = (64 - 5 - 2 - safeTool.length).coerceAtLeast(1)
            val safeServer = sanitizeToolPart(serverName)
                .replace(Regex("_+"), "_")
                .take(maxServer)
                .ifEmpty { "x" }
            return "mcp__${safeServer}__${safeTool}"
        }

        fun parseNamespacedToolName(name: String): Pair<String, String> {
            val parts = name.removePrefix("mcp__").split("__", limit = 2)
            return (parts.getOrNull(0).orEmpty()) to (parts.getOrNull(1).orEmpty())
        }

        private fun sanitizeToolPart(part: String): String {
            val cleaned = part.replace(Regex("[^a-zA-Z0-9_-]"), "_")
                .take(32)
                .takeIf { it.isNotEmpty() } ?: "x"
            return if (cleaned[0].isDigit()) "_$cleaned" else cleaned
        }

        private const val RECONNECT_BASE_DELAY_MS = 2_000L
        private const val RECONNECT_MAX_DELAY_MS = 300_000L
    }
}
