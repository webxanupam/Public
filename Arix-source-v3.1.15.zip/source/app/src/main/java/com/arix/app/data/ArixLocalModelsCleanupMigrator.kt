package com.arix.app.data

import android.content.Context
import java.io.File

object ArixLocalModelsCleanupMigrator {

    private const val MarkerPreferencesName = "arix_maintenance_migration"
    private const val MarkerKey = "local_models_cleanup_done"

    private const val LocalModelsDirectoryName = "local-models"

    private val ObsoleteFileExtensions = setOf("task", "litertlm", "part")

    data class Result(
        val ran: Boolean,
        val deletedFiles: Int,
        val freedBytes: Long,
        val keptUnknownFiles: Int,
        val failedFiles: Int,
        val removedDirectory: Boolean,
    )

    fun migrate(
        context: Context,
        onDiagnostic: ((event: String, details: Map<String, Any?>) -> Unit)? = null,
    ): Result {
        val appContext = context.applicationContext
        val marker = appContext.getSharedPreferences(MarkerPreferencesName, Context.MODE_PRIVATE)
        if (marker.getBoolean(MarkerKey, false)) {
            return Result(ran = false, 0, 0, 0, 0, removedDirectory = false)
        }
        val directory = File(appContext.filesDir, LocalModelsDirectoryName)
        if (!directory.isDirectory) {
            marker.edit().putBoolean(MarkerKey, true).apply()
            return Result(ran = true, 0, 0, 0, 0, removedDirectory = false)
        }

        var deleted = 0
        var freedBytes = 0L
        var keptUnknown = 0
        var failed = 0

        val entries = runCatching { directory.listFiles()?.toList() }.getOrNull().orEmpty()
        for (entry in entries) {
            if (!entry.isFile) {
                keptUnknown++
                continue
            }
            val extension = entry.extension.lowercase()
            if (extension !in ObsoleteFileExtensions) {
                keptUnknown++
                continue
            }
            val size = runCatching { entry.length() }.getOrDefault(0L)
            val deletedOk = runCatching { entry.delete() }.getOrDefault(false)
            if (deletedOk) {
                deleted++
                freedBytes += size
            } else {
                failed++
            }
        }

        var removedDirectory = false
        if (failed == 0) {
            val remaining = runCatching { directory.listFiles()?.isEmpty() }.getOrDefault(false) == true
            if (remaining) {
                removedDirectory = runCatching { directory.delete() }.getOrDefault(false)
            }
        }

        if (failed == 0) {
            marker.edit().putBoolean(MarkerKey, true).apply()
        }
        onDiagnostic?.invoke(
            "obsolete_local_models_cleanup",
            mapOf(
                "deleted_files" to deleted,
                "freed_bytes" to freedBytes,
                "kept_unknown_files" to keptUnknown,
                "failed_files" to failed,
                "removed_directory" to removedDirectory,
            ),
        )
        return Result(
            ran = true,
            deletedFiles = deleted,
            freedBytes = freedBytes,
            keptUnknownFiles = keptUnknown,
            failedFiles = failed,
            removedDirectory = removedDirectory,
        )
    }
}
