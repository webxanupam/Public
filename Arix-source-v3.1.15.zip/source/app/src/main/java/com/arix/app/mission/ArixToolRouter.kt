package com.arix.app.mission

import org.json.JSONObject

object ArixToolRouter {

    enum class Latency(val estMillis: Long) {
        Instant(200L),
        Fast(2_000L),
        Medium(10_000L),
        Slow(60_000L),
        VerySlow(300_000L),
    }

    enum class Cost(val weight: Int) {
        Free(0),
        Cheap(1),
        Moderate(3),
        Expensive(8),
    }

    data class ToolCapability(
        val toolId: String,
        val description: String,
        val capability: String,
        val latency: Latency,
        val cost: Cost,
        val permissions: List<String> = emptyList(),
        val destructive: Boolean = false,
        val readOnly: Boolean = true,
        val supportsCancellation: Boolean = true,
        val supportsParallel: Boolean = true,
        val alternatives: List<String> = emptyList(),
    )

    val registry: List<ToolCapability> = listOf(
        ToolCapability(
            toolId = "web_search",
            description = "Web search with per-turn budget.",
            capability = "web_search",
            latency = Latency.Medium,
            cost = Cost.Cheap,
        ),
        ToolCapability(
            toolId = "fetch_url",
            description = "Fetch a single URL and extract readable content.",
            capability = "web_fetch",
            latency = Latency.Medium,
            cost = Cost.Cheap,
        ),
        ToolCapability(
            toolId = "browser",
            description = "Full WebView browser agent: navigate, click, type, read.",
            capability = "web_interact",
            latency = Latency.Slow,
            cost = Cost.Moderate,
            alternatives = listOf("web_search", "fetch_url"),
        ),
        ToolCapability(
            toolId = "arix_swarm",
            description = "Parallel named sub-agents for independent research parts.",
            capability = "parallel_agents",
            latency = Latency.VerySlow,
            cost = Cost.Expensive,
        ),
        ToolCapability(
            toolId = "upi_pay",
            description = "UPI payment sheet (user confirms in-app).",
            capability = "payment",
            latency = Latency.Medium,
            cost = Cost.Cheap,
            destructive = true,
            readOnly = false,
            supportsParallel = false,
            permissions = listOf("payment"),
        ),
        ToolCapability(
            toolId = "arix_memory",
            description = "Indexed persistent memory (remember/search/forget).",
            capability = "memory",
            latency = Latency.Instant,
            cost = Cost.Free,
        ),
        ToolCapability(
            toolId = "arix_projects",
            description = "Project workspaces: conversations, files, memories, missions.",
            capability = "project_management",
            latency = Latency.Instant,
            cost = Cost.Free,
        ),
        ToolCapability(
            toolId = "arix_diagnostics",
            description = "System health report.",
            capability = "diagnostics",
            latency = Latency.Instant,
            cost = Cost.Free,
        ),
        ToolCapability(
            toolId = "bash",
            description = "Shell in the embedded Termux runtime (kernel-side).",
            capability = "shell",
            latency = Latency.Medium,
            cost = Cost.Cheap,
            readOnly = false,
            supportsParallel = false,
        ),
        ToolCapability(
            toolId = "read",
            description = "Read a file (kernel-side).",
            capability = "file_read",
            latency = Latency.Instant,
            cost = Cost.Free,
        ),
        ToolCapability(
            toolId = "write",
            description = "Write a file (kernel-side).",
            capability = "file_write",
            latency = Latency.Instant,
            cost = Cost.Free,
            readOnly = false,
            supportsParallel = false,
        ),
        ToolCapability(
            toolId = "edit",
            description = "Edit a file (kernel-side).",
            capability = "file_edit",
            latency = Latency.Instant,
            cost = Cost.Free,
            readOnly = false,
            supportsParallel = false,
        ),
    )

    private val byId: Map<String, ToolCapability> = registry.associateBy { it.toolId }

    fun capabilityFor(toolId: String): ToolCapability? = byId[toolId]

    fun selectTool(capability: String): ToolCapability? =
        registry
            .filter { it.capability == capability }
            .sortedBy { it.latency.estMillis + it.cost.weight * 500L }
            .firstOrNull()

    fun alternativesFor(toolId: String): List<String> {
        val direct = byId[toolId]?.alternatives.orEmpty()
        val capability = byId[toolId]?.capability
        val sameCapability = registry
            .filter { it.capability == capability && it.toolId != toolId }
            .sortedBy { it.latency.estMillis + it.cost.weight * 500L }
            .map { it.toolId }
        return (direct + sameCapability).distinct()
    }

    fun parallelSafe(toolA: String, toolB: String): Boolean {
        val a = byId[toolA] ?: return false
        val b = byId[toolB] ?: return false
        return a.readOnly && b.readOnly && a.supportsParallel && b.supportsParallel
    }

    fun parallelSafeGroup(toolIds: Collection<String>): Boolean {
        val allReadOnly = toolIds.all { id -> byId[id]?.readOnly == true }
        val allSupportParallel = toolIds.all { id -> byId[id]?.supportsParallel == true }
        return toolIds.size <= 1 || (allReadOnly && allSupportParallel)
    }

    fun describeTools(): JSONObject = JSONObject().apply {
        put("ok", true)
        put("tools", org.json.JSONArray().apply {
            registry.forEach { tool ->
                put(
                    JSONObject()
                        .put("toolId", tool.toolId)
                        .put("capability", tool.capability)
                        .put("description", tool.description)
                        .put("estLatencyMs", tool.latency.estMillis)
                        .put("cost", tool.cost.name.lowercase())
                        .put("readOnly", tool.readOnly)
                        .put("destructive", tool.destructive)
                        .put("permissions", org.json.JSONArray(tool.permissions))
                        .put("supportsCancellation", tool.supportsCancellation)
                        .put("supportsParallel", tool.supportsParallel)
                        .put("alternatives", org.json.JSONArray(tool.alternatives)),
                )
            }
        })
    }
}
