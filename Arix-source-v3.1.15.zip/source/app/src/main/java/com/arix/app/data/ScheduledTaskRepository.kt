package com.arix.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.scheduledTaskDataStore by preferencesDataStore(name = "arix_scheduled_tasks")

class ScheduledTaskRepository(
    private val context: Context,
    private val diagnosticLogger: ArixDiagnosticLogger = ArixDiagnosticLogger.NoOp,
) {
    val scheduledTasks: Flow<List<ScheduledTask>> = context.scheduledTaskDataStore.data.map { preferences ->
        parseForStorage(preferences[TASKS_JSON].orEmpty()).tasks
    }

    suspend fun snapshot(): List<ScheduledTask> {
        val raw = context.scheduledTaskDataStore.data.first()[TASKS_JSON].orEmpty()
        val read = parseForStorage(raw)
        if (read.corrupted) {
            repairCorruptedStorage(read.tasks)
        }
        return read.tasks
    }

    suspend fun findTask(taskId: String): ScheduledTask? =
        snapshot().firstOrNull { it.id == taskId }

    suspend fun upsertTask(task: ScheduledTask): ScheduledTask {
        var saved = task
        context.scheduledTaskDataStore.edit { preferences ->
            val current = parseForStorage(preferences[TASKS_JSON].orEmpty()).tasks.toMutableList()
            val existingIndex = current.indexOfFirst { it.id == task.id }
            val now = System.currentTimeMillis()
            saved = task.copy(
                updatedAtMillis = now,
            ).withNextRunAfter(now)
            if (existingIndex >= 0) {
                current[existingIndex] = saved
            } else {
                current.add(saved)
            }
            preferences[TASKS_JSON] = serializeScheduledTasks(current)
        }
        return saved
    }

    suspend fun refreshNextRuns(
        afterMillis: Long = System.currentTimeMillis(),
        keepDueTasks: Boolean = true,
    ): List<ScheduledTask> {
        var refreshedTasks = emptyList<ScheduledTask>()
        context.scheduledTaskDataStore.edit { preferences ->
            val read = parseForStorage(preferences[TASKS_JSON].orEmpty())
            refreshedTasks = refreshScheduledTaskNextRuns(
                tasks = read.tasks,
                afterMillis = afterMillis,
                keepDueTasks = keepDueTasks,
            )
            preferences[TASKS_JSON] = serializeScheduledTasks(refreshedTasks)
        }
        return refreshedTasks
    }

    suspend fun updateTask(
        taskId: String,
        transform: (ScheduledTask) -> ScheduledTask,
    ): ScheduledTask? {
        var updatedTask: ScheduledTask? = null
        context.scheduledTaskDataStore.edit { preferences ->
            val current = parseForStorage(preferences[TASKS_JSON].orEmpty()).tasks
            val updated = current.map { task ->
                if (task.id == taskId) {
                    transform(task).also { updatedTask = it }
                } else {
                    task
                }
            }
            preferences[TASKS_JSON] = serializeScheduledTasks(updated)
        }
        return updatedTask
    }

    suspend fun removeTask(taskId: String) {
        context.scheduledTaskDataStore.edit { preferences ->
            val current = parseForStorage(preferences[TASKS_JSON].orEmpty()).tasks
            preferences[TASKS_JSON] = serializeScheduledTasks(current.filterNot { it.id == taskId })
        }
    }

    private suspend fun repairCorruptedStorage(recoveredTasks: List<ScheduledTask>) {
        context.scheduledTaskDataStore.edit { preferences ->
            val read = parseForStorage(preferences[TASKS_JSON].orEmpty())
            if (read.corrupted) {
                preferences[TASKS_JSON] = serializeScheduledTasks(recoveredTasks)
            }
        }
    }

    private fun parseForStorage(rawValue: String): StorageRead {
        val result = parseScheduledTasksDetailed(rawValue)
        return when (result) {
            is ScheduledTaskParseResult.NoData -> StorageRead(emptyList(), corrupted = false)
            is ScheduledTaskParseResult.Parsed -> {
                if (result.droppedEntries > 0) {
                    diagnosticLogger.event(
                        category = "scheduled_task",
                        event = "storage_dropped_invalid_entries",
                        level = "warn",
                        details = mapOf("dropped_entries" to result.droppedEntries),
                    )
                }
                StorageRead(result.tasks, corrupted = false)
            }
            is ScheduledTaskParseResult.Corrupted -> {
                diagnosticLogger.event(
                    category = "scheduled_task",
                    event = "storage_corrupted_recovered",
                    level = "warn",
                    details = mapOf(
                        "recovered_tasks" to result.recovered.size,
                        "dropped_fragments" to result.droppedEntries,
                    ),
                )
                StorageRead(result.recovered, corrupted = true)
            }
        }
    }

    private data class StorageRead(
        val tasks: List<ScheduledTask>,
        val corrupted: Boolean,
    )

    private companion object {
        val TASKS_JSON = stringPreferencesKey("tasks_json")
    }
}
