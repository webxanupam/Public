package com.arix.app.agent

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Display
import android.view.KeyEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.arix.app.agent.a11y.ScreenAccessibility
import com.arix.app.agent.display.AgentDisplay
import com.arix.app.agent.shell.AccessibilityRepair
import com.arix.app.agent.shell.IArixShell
import com.arix.app.agent.shell.ShellService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import android.view.accessibility.AccessibilityWindowInfo
import kotlin.coroutines.resume
import kotlin.math.abs

/** The small live view's on-screen state (same model as Mika's PipUi). */
enum class ArixPipMode { Running, NeedsYou, Done }

data class ArixPipUi(
    val visible: Boolean = false,
    val mode: ArixPipMode = ArixPipMode.Running,
    val expanded: Boolean = false,
    val closed: Boolean = false,
)

/** One readable element the agent found on the screen. */
data class ArixScreenElement(
    val ref: Int,
    val text: String,
    val className: String?,
    val clickable: Boolean,
    val editable: Boolean,
    val scrollable: Boolean,
    val bounds: Rect,
)

/** What the screen currently shows: text lines + interactive elements. */
data class ArixScreenSnapshot(
    val snapshotId: String,
    val width: Int,
    val height: Int,
    val hasWindow: Boolean,
    val packageName: String?,
    val textLines: List<String>,
    val elements: List<ArixScreenElement>,
)

/** One OCR line with its on-screen box (background-screen pixel coordinates). */
data class ArixArcOcrLine(
    val text: String,
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int,
)

/** Result of one phone action. */
sealed interface ArixActionResult {
    data class Ok(val detail: String? = null) : ArixActionResult
    data class Failed(val code: String, val detail: String? = null) : ArixActionResult
}

/**
 * Arix's phone agent (ported from Mika's phone stack — Apache-2.0, wangzan101/Mika).
 * Owns the background virtual display, injects input on it, reads it back, and
 * publishes the live frames + small-live-view (pip) state for the chat UI.
 *
 * Everything runs on the user's phone but on a SEPARATE background screen, so the
 * user keeps using their phone as usual; the chat shows a small live view (tap to
 * enlarge). One agent instance at a time (Arix tool calls are sequential).
 */
class ArixPhoneAgent(private val context: Context) {
    private val app = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val lock = Mutex()

    private var connection: com.arix.app.agent.shell.ShellBinding? = null
    private var shell: IArixShell? = null
    private var shellDeath: IBinder.DeathRecipient? = null
    private var display: AgentDisplay? = null
    private var displayJob: Job? = null
    private var mutedPackage: String? = null
    private var nextRef = 1

    private val _frames = MutableStateFlow<Bitmap?>(null)
    /** Live preview frames of the background screen (≤10 fps, ≤360 px wide). */
    val frames: StateFlow<Bitmap?> = _frames.asStateFlow()

    private val _pip = MutableStateFlow(ArixPipUi())
    /** The small live view state the chat renders. */
    val pip: StateFlow<ArixPipUi> = _pip.asStateFlow()

    private val _displayId = MutableStateFlow(-1)
    val displayId: StateFlow<Int> = _displayId.asStateFlow()

    val acquired: Boolean get() = shell != null

    // ---------- lifecycle ----------

    /**
     * Connect the phone stack: the shared shell binding, the helper's Binder, the
     * accessibility service, and the (lazy) virtual display. Throws
     * [ArixPhoneUnavailable] with a user-actionable hint when a piece is missing.
     */
    suspend fun connect(): IArixShell = lock.withLock {
        shell?.let { return it }
        val services = ArixPhoneServices.of(app)
        val conn = connection ?: services.sharedShell.acquire().also { connection = it }
        val bound = withTimeoutOrNull(SHELL_WAIT_MS) { conn.shell.filterNotNull().first() }
            ?: run {
                services.setupPrompt.request()
                throw ArixPhoneUnavailable("Phone control is not set up yet — open Settings › Phone control and pair wireless debugging once.")
            }
        val a11y = withTimeoutOrNull(A11Y_WAIT_MS) {
            AccessibilityRepair.awaitService(ScreenAccessibility.instance, services.recovery.accessibilityRepair.phase, A11Y_WAIT_MS)
        } ?: throw ArixPhoneUnavailable("The Arix accessibility service is off — open Settings › Phone control to turn it on.")
        // Follow the shell's lifetime: when it dies the virtual display and its apps go too.
        val recipient = IBinder.DeathRecipient { releaseInternal() }
        bound.asBinder().linkToDeath(recipient, 0)
        shellDeath = recipient
        shell = bound
        bound
    }

    private fun ensureDisplay(): AgentDisplay = display ?: run {
        val sh = shell ?: throw ArixPhoneUnavailable("Phone control is not connected.")
        val m = mainScreenMetrics()
        val d = AgentDisplay(sh, m.widthPixels, m.heightPixels, m.densityDpi)
        display = d
        _displayId.value = d.displayId
        displayJob?.cancel()
        displayJob = scope.launch { d.frames.collect { _frames.value = it } }
        d
    }

    @Suppress("DEPRECATION")
    private fun mainScreenMetrics(): DisplayMetrics = DisplayMetrics().also {
        app.getSystemService(DisplayManager::class.java)
            .getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(it)
    }

    /** Release everything this agent created (display, mute, shell binding). */
    suspend fun release() = lock.withLock { releaseInternal() }

    private fun releaseInternal() {
        runCatching { display?.release() }
        display = null
        _displayId.value = -1
        _frames.value = null
        displayJob?.cancel()
        displayJob = null
        mutedPackage?.let { pkg -> runCatching { shell?.setAudioMuted(pkg, false) } }
        mutedPackage = null
        shellDeath?.let { r -> runCatching { shell?.asBinder()?.unlinkToDeath(r, 0) } }
        shellDeath = null
        shell = null
        connection?.let { runCatching { ArixPhoneServices.of(app).sharedShell.release() } }
        connection = null
    }

    // ---------- pip ----------

    fun pipExpand() { _pip.value = _pip.value.copy(expanded = true, closed = false) }
    fun pipCollapse() { _pip.value = _pip.value.copy(expanded = false) }
    fun pipClose() { _pip.value = _pip.value.copy(closed = true, expanded = false) }
    fun pipReopen() { _pip.value = _pip.value.copy(closed = false, expanded = true) }
    fun pipAttend() { _pip.value = _pip.value.copy(closed = false, expanded = false) }

    private fun pipRunning() {
        _pip.value = ArixPipUi(visible = true, mode = ArixPipMode.Running)
    }

    private fun pipNeedsYou(why: String) {
        _pip.value = _pip.value.copy(visible = true, mode = ArixPipMode.NeedsYou, expanded = true)
    }

    /** Public entry for the phone tool's needs_user action. */
    fun pipNeedsYouPublic(reason: String) = pipNeedsYou(reason)

    /** The task finished: hold the last frame a few seconds with the done look, then hide. */
    fun pipDone() {
        if (!_pip.value.visible) return
        _pip.value = _pip.value.copy(mode = ArixPipMode.Done, expanded = false, closed = false)
        scope.launch {
            delay(DONE_HOLD_MS)
            if (_pip.value.mode == ArixPipMode.Done) _pip.value = ArixPipUi()
        }
    }

    // ---------- actions ----------

    suspend fun openApp(packageName: String, cold: Boolean = false): ArixActionResult {
        val sh = connect()
        pipRunning()
        val d = ensureDisplay()
        // Quiet first (the app may start playing sound on its own screen).
        runCatching { sh.setAudioMuted(packageName, true) }.onSuccess { mutedPackage = packageName }
        val code = if (cold) {
            val restarted = runCatching { sh.restartApp(d.displayId, packageName) }.getOrNull()
            if (restarted == 4) runCatching { sh.startApp(d.displayId, packageName) }.getOrNull() ?: restarted else restarted
        } else {
            runCatching { sh.startApp(d.displayId, packageName) }.getOrNull()
        }
        return when (code) {
            0 -> waitStableThen { ArixActionResult.Ok("opened $packageName on the background screen") }
            1 -> {
                pipNeedsYou("app-in-use")
                ArixActionResult.Failed("app_in_use", "You are using $packageName on the main screen right now — Arix will not take it over. Close it or try another app.")
            }
            2 -> ArixActionResult.Failed("no_launcher", "$packageName has no launchable entry.")
            else -> ArixActionResult.Failed("open_failed", "startApp returned $code")
        }
    }

    suspend fun tap(x: Int, y: Int): ArixActionResult = onDisplay { d ->
        val node = nodeAt(x, y)
        if (node != null && runCatching { node.performAction(AccessibilityNodeInfo.ACTION_CLICK) }.getOrDefault(false)) {
            node.recycle()
            waitStableThen { ArixActionResult.Ok("tapped ($x, $y)") }
        } else {
            node?.recycle()
            if (runCatching { shell!!.injectTap(d.displayId, x, y) }.getOrDefault(false)) {
                waitStableThen { ArixActionResult.Ok("tapped ($x, $y)") }
            } else {
                ArixActionResult.Failed("tap_failed", "could not inject a tap at ($x, $y)")
            }
        }
    }

    suspend fun doubleTap(x: Int, y: Int): ArixActionResult = onDisplay { d ->
        val service = ScreenAccessibility.instance.value
            ?: return@onDisplay ArixActionResult.Failed("no_accessibility", "the accessibility service is off")
        if (service.taps(d.displayId, x.toFloat(), y.toFloat(), 2, holdMs = 90, gapMs = 70)) {
            waitStableThen { ArixActionResult.Ok("double-tapped ($x, $y)") }
        } else {
            ArixActionResult.Failed("tap_failed", "could not double-tap at ($x, $y)")
        }
    }

    suspend fun swipe(x1: Int, y1: Int, x2: Int, y2: Int, durationMs: Long = 300): ArixActionResult = onDisplay { d ->
        val service = ScreenAccessibility.instance.value
            ?: return@onDisplay ArixActionResult.Failed("no_accessibility", "the accessibility service is off")
        val path = Path().apply { moveTo(x1.toFloat(), y1.toFloat()); lineTo(x2.toFloat(), y2.toFloat()) }
        if (service.gesture(d.displayId, path, durationMs.coerceIn(50, 3000))) {
            waitStableThen { ArixActionResult.Ok("swiped ($x1,$y1) → ($x2,$y2)") }
        } else {
            ArixActionResult.Failed("swipe_failed", "the gesture was cancelled")
        }
    }

    suspend fun scroll(down: Boolean): ArixActionResult {
        val d = ensureDisplay()
        val h = d.height
        val w = d.width
        return if (down) swipe(w / 2, h * 2 / 3, w / 2, h / 3)
        else swipe(w / 2, h / 3, w / 2, h * 2 / 3)
    }

    suspend fun back(): ArixActionResult = key(KeyEvent.KEYCODE_BACK)
    suspend fun home(): ArixActionResult = key(KeyEvent.KEYCODE_HOME)

    suspend fun key(keyCode: Int): ArixActionResult = onDisplay { d ->
        if (runCatching { shell!!.injectKey(d.displayId, keyCode) }.getOrDefault(false)) {
            waitStableThen { ArixActionResult.Ok("key $keyCode") }
        } else {
            ArixActionResult.Failed("key_failed", "could not inject key $keyCode")
        }
    }

    /**
     * Type [text] into the focused field. Accessibility SET_TEXT first (instant,
     * verifiable), then the shell clipboard + Ctrl+V pipeline for editors that only
     * accept real input (same approach as Mika).
     */
    suspend fun typeText(text: String, x: Int? = null, y: Int? = null): ArixActionResult {
        val sh = connect()
        val d = ensureDisplay()
        pipRunning()
        if (x != null && y != null) tap(x, y)
        val focused = focusedNode(d.displayId)
        if (focused != null) {
            val args = android.os.Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            }
            if (runCatching { focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args) }.getOrDefault(false)) {
                focused.recycle()
                return waitStableThen { ArixActionResult.Ok("typed ${text.length} chars (accessibility)") }
            }
            focused.recycle()
        }
        // Clipboard + Ctrl+V fallback (editors that ignore SET_TEXT).
        val clip = runCatching { sh.setClipText(text) }.getOrDefault(ShellService.CLIP_FAILED)
        if (clip == ShellService.CLIP_SET) {
            runCatching { sh.setAudioMuted(mutedPackage ?: "", true) }
            val pasted = runCatching { sh.injectCtrlKey(d.displayId, KeyEvent.KEYCODE_V) }.getOrDefault(false)
            runCatching { sh.restoreClip() }
            if (pasted) return waitStableThen { ArixActionResult.Ok("typed ${text.length} chars (paste)") }
        }
        return ArixActionResult.Failed("type_failed", "no focused editable field found — tap a field first, then type")
    }

    suspend fun clearText(x: Int? = null, y: Int? = null): ArixActionResult {
        val d = ensureDisplay()
        if (x != null && y != null) tap(x, y)
        val focused = focusedNode(d.displayId) ?: return ArixActionResult.Failed("no_field", "no focused editable field")
        val args = android.os.Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "")
        }
        val ok = runCatching { focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args) }.getOrDefault(false)
        focused.recycle()
        return if (ok) ArixActionResult.Ok("cleared") else ArixActionResult.Failed("clear_failed", "could not clear the field")
    }

    suspend fun screenshotPng(): ByteArray? {
        val d = display ?: return null
        return d.latestFramePng()
    }

    /** Read the background screen through the accessibility tree (like a person reads it). */
    suspend fun readScreen(): ArixScreenSnapshot {
        val d = display ?: return emptySnapshot()
        val service = ScreenAccessibility.instance.value ?: return emptySnapshot()
        val windows = service.windowsOn(d.displayId)
        val appWindow = windows.firstOrNull { it.type == AccessibilityWindowInfo.TYPE_APPLICATION && it.root != null }
            ?: windows.firstOrNull { it.root != null }
        val root = appWindow?.root
        if (root == null) return emptySnapshot()
        val texts = ArrayList<String>()
        val elements = ArrayList<ArixScreenElement>()
        walk(root, texts, elements, depth = 0)
        val bounds = android.graphics.Rect()
        runCatching { root.getBoundsInScreen(bounds) }
        return ArixScreenSnapshot(
            snapshotId = "s${System.nanoTime()}",
            width = d.width,
            height = d.height,
            hasWindow = true,
            packageName = root.packageName?.toString(),
            textLines = texts.take(MAX_TEXT_LINES),
            elements = elements.take(MAX_ELEMENTS),
        )
    }

    private fun emptySnapshot() = ArixScreenSnapshot("s0", 0, 0, hasWindow = false, packageName = null, textLines = emptyList(), elements = emptyList())

    /**
     * Read the background screen with on-device OCR (bundled Latin + Chinese text
     * recognition — same approach as Mika): the way the agent "sees" custom-drawn
     * UIs whose controls the accessibility tree cannot read.
     */
    suspend fun readScreenOcr(): List<ArixArcOcrLine> {
        val d = display ?: return emptyList()
        val bitmap = d.latestFrameBitmap() ?: return emptyList()
        return try {
            val image = com.google.mlkit.vision.common.InputImage.fromBitmap(bitmap, 0)
            val text: com.google.mlkit.vision.text.Text? =
                kotlinx.coroutines.suspendCancellableCoroutine { cont ->
                    ocrRecognizer().process(image)
                        .addOnSuccessListener { result -> if (cont.isActive) cont.resume(result) }
                        .addOnFailureListener { if (cont.isActive) cont.resume(null) }
                }
            text ?: return emptyList()
            text.textBlocks.flatMap { block -> block.lines }.map { line ->
                val box = line.boundingBox
                ArixArcOcrLine(
                    text = line.text,
                    left = box?.left ?: 0,
                    top = box?.top ?: 0,
                    right = box?.right ?: 0,
                    bottom = box?.bottom ?: 0,
                )
            }
        } finally {
            bitmap.recycle()
        }
    }

    @Volatile private var latinOcr: com.google.mlkit.vision.text.TextRecognizer? = null
    @Volatile private var chineseOcr: com.google.mlkit.vision.text.TextRecognizer? = null

    /** Chinese recognizer when the system locale is Chinese (same rule as Mika), Latin otherwise. */
    private fun ocrRecognizer(): com.google.mlkit.vision.text.TextRecognizer {
        val useChinese = android.preference.PreferenceManager.getDefaultSharedPreferences(app)
            .getString("app_language", null)?.startsWith("zh") == true
        if (useChinese) {
            return chineseOcr ?: com.google.mlkit.vision.text.TextRecognition.getClient(
                com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions.Builder().build(),
            ).also { chineseOcr = it }
        }
        return latinOcr ?: com.google.mlkit.vision.text.TextRecognition.getClient(
            com.google.mlkit.vision.text.latin.TextRecognizerOptions.DEFAULT_OPTIONS,
        ).also { latinOcr = it }
    }

    private fun walk(
        node: AccessibilityNodeInfo,
        texts: MutableList<String>,
        elements: MutableList<ArixScreenElement>,
        depth: Int,
    ) {
        if (depth > MAX_DEPTH) return
        val rect = Rect()
        runCatching { node.getBoundsInScreen(rect) }
        val visible = rect.width() > 2 && rect.height() > 2
        val text = listOfNotNull(
            node.text?.toString()?.trim(),
            node.contentDescription?.toString()?.trim(),
        ).firstOrNull { it.isNotEmpty() }
        val className = runCatching { node.className?.toString() }.getOrNull()
        val editable = runCatching { node.isEditable }.getOrDefault(false)
        val clickable = runCatching { node.isClickable }.getOrDefault(false)
        val scrollable = runCatching { node.isScrollable }.getOrDefault(false)
        if (visible && (text != null || clickable || editable || scrollable)) {
            text?.let { texts.add(it) }
            elements.add(
                ArixScreenElement(
                    ref = nextRef++,
                    text = text ?: "",
                    className = className,
                    clickable = clickable,
                    editable = editable,
                    scrollable = scrollable,
                    bounds = rect,
                ),
            )
        }
        for (i in 0 until runCatching { node.childCount }.getOrDefault(0)) {
            runCatching { node.getChild(i) }.getOrNull()?.let { walk(it, texts, elements, depth + 1) }
        }
    }

    private fun nodeAt(x: Int, y: Int): AccessibilityNodeInfo? {
        val d = display ?: return null
        val service = ScreenAccessibility.instance.value ?: return null
        val root = service.rootOn(d.displayId) ?: return null
        return findClickableAt(root, x, y, depth = 0)
    }

    private fun findClickableAt(node: AccessibilityNodeInfo, x: Int, y: Int, depth: Int): AccessibilityNodeInfo? {
        if (depth > MAX_DEPTH) return null
        val rect = Rect()
        runCatching { node.getBoundsInScreen(rect) }
        val hit = rect.contains(x, y)
        val clickable = runCatching { node.isClickable }.getOrDefault(false)
        if (hit && clickable) return node
        for (i in 0 until runCatching { node.childCount }.getOrDefault(0)) {
            val child = runCatching { node.getChild(i) }.getOrNull() ?: continue
            val found = findClickableAt(child, x, y, depth + 1)
            if (found != null) {
                if (found !== node) return found
            }
        }
        if (hit && depth <= 2) return node
        return null
    }

    private fun focusedNode(displayId: Int): AccessibilityNodeInfo? {
        val service = ScreenAccessibility.instance.value ?: return null
        val windows = service.windowsOn(displayId)
        for (w in windows) {
            val root = runCatching { w.root }.getOrNull() ?: continue
            val focused = runCatching { root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) }.getOrNull()
            if (focused != null) return focused
        }
        return null
    }

    /** Wait until the screen settles (windows stop changing), capped at [timeoutMs]. */
    suspend fun waitStable(timeoutMs: Long = 4000): Boolean {
        val startGen = ScreenAccessibility.windowGeneration()
        var last = startGen
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            delay(120)
            val gen = ScreenAccessibility.windowGeneration()
            if (gen != last) {
                last = gen
                continue
            }
            // one quiet interval: give in-flight animations a moment, then re-check
            delay(240)
            if (ScreenAccessibility.windowGeneration() == last) return true
        }
        return false
    }

    private suspend fun <T> waitStableThen(block: suspend () -> T): T {
        waitStable()
        return block()
    }

    /** Launchable apps on the device (no phone connection needed). */
    fun listApps(): List<Pair<String, String>> {
        val pm = app.packageManager
        val intent = android.content.Intent(android.content.Intent.ACTION_MAIN, null)
            .addCategory(android.content.Intent.CATEGORY_LAUNCHER)
        val label = { pkg: String ->
            runCatching {
                pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
            }.getOrDefault(pkg)
        }
        return pm.queryIntentActivities(intent, 0)
            .map { it.activityInfo.packageName to label(it.activityInfo.packageName) }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
    }

    /**
     * End the phone session: keep the apps the model marked, close the rest, release
     * the display and the shell (same end-of-task handling as Mika).
     */
    suspend fun finish(keep: List<String>, close: List<String>): ArixActionResult {
        val d = display
        val sh = shell
        var note = ""
        if (d != null && sh != null) {
            runCatching { sh.finishDisplay(d.displayId, keep.toTypedArray(), close.toTypedArray()) }
                .getOrNull()?.let { bundle ->
                    note = bundle.getString("note").orEmpty()
                }
        }
        release()
        pipDone()
        return ArixActionResult.Ok(note.ifEmpty { "phone session finished" })
    }

    private suspend fun <T> onDisplay(block: suspend (AgentDisplay) -> T): T {
        val sh = connect()
        pipRunning()
        val d = ensureDisplay()
        @Suppress("UNUSED_EXPRESSION") sh
        return block(d)
    }

    companion object {
        private const val SHELL_WAIT_MS = 10_000L
        private const val A11Y_WAIT_MS = 6_000L
        private const val DONE_HOLD_MS = 4_000L
        private const val MAX_TEXT_LINES = 220
        private const val MAX_ELEMENTS = 90
        private const val MAX_DEPTH = 34

        @Volatile private var instance: ArixPhoneAgent? = null

        /** The process-wide agent instance (the phone tool and the chat UI share it). */
        fun of(context: Context): ArixPhoneAgent =
            instance ?: synchronized(this) {
                instance ?: ArixPhoneAgent(context.applicationContext).also { instance = it }
            }
    }
}

/** The phone stack is not usable right now; [hint] tells the user (and the model) how to fix it. */
class ArixPhoneUnavailable(val hint: String) : Exception(hint)
