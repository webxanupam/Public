package com.arix.app.runtime

import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream

internal enum class TarEntryType {
    File,
    Directory,
    SymbolicLink,
    HardLink,
    Other,
}

internal class TarEntryData(
    val name: String,
    val linkName: String,
    val size: Long,
    val mode: Int,
    val type: TarEntryType,
)

private const val BlockSize = 512

internal object TermuxTar {

    fun forEachEntry(
        input: InputStream,
        handle: (TarEntryData, InputStream) -> Unit,
    ) {
        var pendingPax: Map<String, String> = emptyMap()
        var globalPax: Map<String, String> = emptyMap()
        var pendingLongName: String? = null
        var pendingLongLink: String? = null
        while (true) {
            val header = readHeader(input) ?: break
            when (header.metaType) {
                MetaType.PaxPerEntry -> {
                    pendingPax = parsePaxRecords(BoundedInputStream(input, header.size).readBytesOrThrow())
                    skipPadding(input, header.size)
                    continue
                }
                MetaType.PaxGlobal -> {
                    globalPax = globalPax + parsePaxRecords(
                        BoundedInputStream(input, header.size).readBytesOrThrow(),
                    )
                    skipPadding(input, header.size)
                    continue
                }
                MetaType.GnuLongName -> {
                    pendingLongName = readPayloadName(input, header.size)
                    skipPadding(input, header.size)
                    continue
                }
                MetaType.GnuLongLink -> {
                    pendingLongLink = readPayloadName(input, header.size)
                    skipPadding(input, header.size)
                    continue
                }
                MetaType.None -> Unit
            }
            val name = pendingPax["path"]
                ?: pendingLongName
                ?: header.name
            val linkName = pendingPax["linkpath"]
                ?: pendingLongLink
                ?: header.linkName
            val size = pendingPax["size"]?.toLongOrNull() ?: header.size
            val entry = TarEntryData(
                name = name,
                linkName = linkName,
                size = size,
                mode = header.mode,
                type = header.type,
            )
            val bounded = BoundedInputStream(input, size)
            handle(entry, bounded)
            bounded.drainRemaining()
            skipPadding(input, size)
            pendingPax = emptyMap()
            pendingLongName = null
            pendingLongLink = null
        }
    }

    private enum class MetaType {
        None,
        PaxPerEntry,
        PaxGlobal,
        GnuLongName,
        GnuLongLink,
    }

    private class Header(
        val name: String,
        val linkName: String,
        val size: Long,
        val mode: Int,
        val type: TarEntryType,
        val metaType: MetaType,
    )

    private fun readHeader(input: InputStream): Header? {
        val block = readBlock(input) ?: return null
        if (block.all { it == 0.toByte() }) {
            runCatching { readBlock(input) }
            return null
        }
        verifyChecksum(block)
        val name = string(block, 0, 100)
        val mode = octal(block, 100, 8).toInt()
        val size = octal(block, 124, 12)
        val linkName = string(block, 157, 100)
        val prefix = string(block, 345, 155)
        val typeFlag = block[156]
        val magic = string(block, 257, 6)
        if (magic.isNotBlank() && !magic.startsWith("ustar")) {
            throw IOException("Unsupported tar format (magic='$magic').")
        }
        val metaType = when (typeFlag) {
            'x'.code.toByte() -> MetaType.PaxPerEntry
            'g'.code.toByte() -> MetaType.PaxGlobal
            'L'.code.toByte() -> MetaType.GnuLongName
            'K'.code.toByte() -> MetaType.GnuLongLink
            else -> MetaType.None
        }
        val type = when (typeFlag) {
            '0'.code.toByte(), 0.toByte(), '7'.code.toByte() -> TarEntryType.File
            '5'.code.toByte() -> TarEntryType.Directory
            '2'.code.toByte() -> TarEntryType.SymbolicLink
            '1'.code.toByte() -> TarEntryType.HardLink
            else -> TarEntryType.Other
        }
        val fullName = if (prefix.isBlank()) name else "$prefix/$name"
        return Header(fullName, linkName, size, mode, type, metaType)
    }

    private fun readBlock(input: InputStream): ByteArray? {
        val block = ByteArray(BlockSize)
        var offset = 0
        while (offset < BlockSize) {
            val read = input.read(block, offset, BlockSize - offset)
            if (read == -1) {
                if (offset == 0) return null
                throw IOException("Truncated tar header ($offset of $BlockSize bytes).")
            }
            offset += read
        }
        return block
    }

    private fun verifyChecksum(block: ByteArray) {
        val stored = octal(block, 148, 8)
        var unsigned = 0L
        var signed = 0L
        for (index in block.indices) {
            val value = block[index].toInt()
            if (index in 148 until 156) {
unsigned += 32L
                signed += 32L
            } else {
                unsigned += value.toLong() and 0xffL
                signed += value.toLong()
            }
        }
        if (stored != unsigned && stored != signed) {
            throw IOException("Tar header checksum mismatch (stored $stored, computed $unsigned/$signed).")
        }
    }

    private fun skipPadding(input: InputStream, entrySize: Long) {
        val padding = ((BlockSize - (entrySize % BlockSize)) % BlockSize).toInt()
        if (padding == 0) return
        var skipped = 0
        val drain = ByteArray(padding)
        while (skipped < padding) {
            val read = input.read(drain, 0, padding - skipped)
            if (read == -1) throw IOException("Truncated tar padding.")
            skipped += read
        }
    }

    private fun readPayloadName(input: InputStream, size: Long): String {
        val bytes = BoundedInputStream(input, size).readBytesOrThrow()
        var terminator = -1
        for (index in bytes.indices) {
            if (bytes[index] == 0.toByte()) {
                terminator = index
                break
            }
        }
        return String(
            if (terminator >= 0) bytes.copyOf(terminator) else bytes,
            Charsets.UTF_8,
        )
    }

    private fun parsePaxRecords(data: ByteArray): Map<String, String> {
        val records = mutableMapOf<String, String>()
        var offset = 0
        while (offset < data.size) {
            var space = -1
            for (index in offset until data.size) {
                if (data[index] == ' '.code.toByte()) {
                    space = index
                    break
                }
            }
            if (space < 0) throw IOException("Malformed PAX record.")
            val length = String(data, offset, space - offset, Charsets.US_ASCII).trim().toIntOrNull()
                ?: throw IOException("Malformed PAX record length.")
            val recordEnd = offset + length
            if (recordEnd > data.size || recordEnd <= space + 1) {
                throw IOException("Malformed PAX record bounds.")
            }
            var equals = -1
            for (index in space + 1 until recordEnd) {
                if (data[index] == '='.code.toByte()) {
                    equals = index
                    break
                }
            }
            if (equals > space) {
                val key = String(data, space + 1, equals - space - 1, Charsets.UTF_8)
                val value = String(data, equals + 1, recordEnd - 1 - (equals + 1), Charsets.UTF_8)
                records[key] = value
            }
            offset = recordEnd
        }
        return records
    }

    private fun string(block: ByteArray, offset: Int, length: Int): String {
        var end = offset
        while (end < offset + length && block[end] != 0.toByte()) end++
        return String(block, offset, end - offset, Charsets.UTF_8).trim()
    }

    private fun octal(block: ByteArray, offset: Int, length: Int): Long {
        val text = string(block, offset, length)
        if (text.isEmpty()) return 0L
        if ((block[offset].toInt() and 0x80) != 0) {
            throw IOException("Unsupported tar numeric encoding (base-256).")
        }
        return text.toLongOrNull(radix = 8) ?: throw IOException("Malformed tar octal field: '$text'.")
    }
}

internal class BoundedInputStream(
    delegate: InputStream,
    private val limit: Long,
) : FilterInputStream(delegate) {
    private var remaining = limit

    override fun read(): Int {
        if (remaining <= 0) return -1
        val value = super.read()
        if (value >= 0) remaining -= 1
        return value
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (remaining <= 0) return -1
        val allowed = minOf(length.toLong(), remaining).toInt()
        val read = super.read(buffer, offset, allowed)
        if (read > 0) remaining -= read
        return read
    }

    override fun available(): Int = minOf(super.available().toLong(), remaining).toInt()

    internal fun drainRemaining() {
        val buffer = ByteArray(16 * 1024)
        while (true) {
            val read = read(buffer)
            if (read == -1) break
        }
    }

    internal fun readBytesOrThrow(): ByteArray {
        val output = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(16 * 1024)
        while (true) {
            val read = read(buffer)
            if (read == -1) break
            output.write(buffer, 0, read)
        }
        return output.toByteArray()
    }
}
