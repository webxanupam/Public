package com.arix.app.agent.a11y

/** The system looks the service up by this full name (manifest + system settings). */
class ArixAccessibilityService : ScreenAccessibility()
