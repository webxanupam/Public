package com.arix.app.agent.shell

/** The manifest entry point where the shell-uid helper hands its Binder over. */
class HelperHandoffProvider : HandoffProvider()
