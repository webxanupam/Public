package com.arix.app.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.security.SecureRandom
import java.util.concurrent.TimeUnit

object ArixFileShareClient {

    const val ServerFilebin = "filebin"
    const val ServerTmpFiles = "tmpfiles"
    const val ServerGoFile = "gofile"
    const val ServerQuAx = "quax"
    const val ServerX0 = "x0"

    data class UploadResult(
        val url: String,
        val server: String,
        val fileName: String,
        val sizeBytes: Long,
    )

    fun interface UploadProgressListener {
        fun onProgress(bytesWritten: Long, totalBytes: Long, bytesPerSecond: Long)
    }

    private val random = SecureRandom()

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.MINUTES)
        .writeTimeout(10, TimeUnit.MINUTES)
        .followRedirects(true)
        .build()

    fun serverLabel(serverId: String): String = when (serverId) {
        ServerFilebin -> "Server 1"
        ServerTmpFiles -> "Server 2"
        ServerGoFile -> "Server 3"
        ServerQuAx -> "Server 4"
        ServerX0 -> "Server 5"
        else -> "Server"
    }

    fun serverHint(serverId: String): String = when (serverId) {
        ServerFilebin -> "Filebin.net · 6-day availability"
        ServerTmpFiles -> "tmpfiles.org · up to 100 MB, 60 days"
        ServerGoFile -> "GoFile.io · generous limits, no signup"
        ServerQuAx -> "qu.ax · 30-day retention"
        ServerX0 -> "x0.at · up to 200 MB, 30+ days"
        else -> ""
    }

    fun normalizeServerId(requested: String?): String = when (requested?.trim()?.lowercase()) {
        ServerFilebin, "filebin.net", "1", "server1" -> ServerFilebin
        ServerTmpFiles, "tmpfiles.org", "tmpfiles", "2", "server2" -> ServerTmpFiles
        ServerGoFile, "gofile.io", "gofile", "3", "server3" -> ServerGoFile
        ServerQuAx, "qu.ax", "quax", "4", "server4" -> ServerQuAx
        ServerX0, "x0.at", "x0", "5", "server5" -> ServerX0
        else -> ServerFilebin
    }

    fun serverSizeLimit(serverId: String): Long = when (serverId) {
        ServerTmpFiles -> 100L * 1024 * 1024
        ServerX0 -> 200L * 1024 * 1024
        else -> -1L
    }

    fun uploadFile(
        file: File,
        server: String,
        onProgress: UploadProgressListener? = null,
    ): UploadResult {
        require(file.isFile) { "The file does not exist: ${file.name}" }
        val size = file.length()
        val limit = serverSizeLimit(server)
        if (limit in 1..size) {
            throw IOException(
                "${serverLabel(server)} accepts up to ${formatBytes(limit)} — this file is ${formatBytes(size)}. " +
                    "Pick another server (e.g. ${ServerGoFile} or ${ServerFilebin}).",
            )
        }
        val fileName = file.name
        val contentType = contentTypeFor(fileName)
        val progressBody = object : okhttp3.RequestBody() {
            override fun contentType() = contentType
            override fun contentLength(): Long = size
            override fun writeTo(sink: okio.BufferedSink) {
                val startedAt = System.nanoTime()
                var written = 0L
                var lastReported = 0L
                FileInputStream(file).use { input ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        val read = input.read(buffer)
                        if (read < 0) break
                        sink.write(buffer, 0, read)
                        written += read
                        if (onProgress != null && written - lastReported >= 256 * 1024) {
                            lastReported = written
                            val elapsedSeconds = (System.nanoTime() - startedAt) / 1_000_000_000.0
                            val speed = if (elapsedSeconds > 0.05) {
                                (written / elapsedSeconds).toLong()
                            } else {
                                0L
                            }
                            runCatching { onProgress.onProgress(written, size, speed) }
                        }
                    }
                }
                onProgress?.let { listener ->
                    runCatching { listener.onProgress(size, size, 0L) }
                }
            }
        }
        return when (server) {
            ServerFilebin -> uploadToFilebin(progressBody, fileName, size)
            ServerTmpFiles -> uploadToTmpFiles(progressBody, fileName, size)
            ServerGoFile -> uploadToGoFile(progressBody, fileName, size)
            ServerQuAx -> uploadToQuAx(progressBody, fileName, size)
            ServerX0 -> uploadToX0(progressBody, fileName, size)
            else -> error("Unknown upload server.")
        }
    }

    fun upload(context: Context, uri: Uri, server: String): UploadResult {
        val appContext = context.applicationContext
        val resolver = appContext.contentResolver
        val displayName = queryDisplayName(resolver, uri)
        val size = querySize(resolver, uri)
        val contentType = resolver.getType(uri) ?: "application/octet-stream"
        val mediaType = contentType.toMediaType()
        val body = object : okhttp3.RequestBody() {
            override fun contentType() = mediaType
            override fun contentLength(): Long = size
            override fun writeTo(sink: okio.BufferedSink) {
                resolver.openInputStream(uri)?.use { input ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        val read = input.read(buffer)
                        if (read < 0) break
                        sink.write(buffer, 0, read)
                    }
                } ?: throw IOException("The selected file could not be opened.")
            }
        }
        return when (server) {
            ServerFilebin -> uploadToFilebin(body, displayName, size)
            ServerTmpFiles -> uploadToTmpFiles(body, displayName, size)
            ServerGoFile -> uploadToGoFile(body, displayName, size)
            ServerQuAx -> uploadToQuAx(body, displayName, size)
            ServerX0 -> uploadToX0(body, displayName, size)
            else -> error("Unknown upload server.")
        }
    }

    private fun uploadToFilebin(body: okhttp3.RequestBody, fileName: String, size: Long): UploadResult {
        val bin = randomBinId()
        val createRequest = Request.Builder()
            .url("https://filebin.net/$bin")
            .header("User-Agent", ArixMediaApi.BrowserUserAgent)
            .header("Accept", "application/json")
            .post(ByteArray(0).toRequestBody(null))
            .build()
        runCatching {
            client.newCall(createRequest).execute().use { response ->
                response.body?.string()
            }
        }
        val putRequest = Request.Builder()
            .url("https://filebin.net/$bin/${urlSafe(fileName)}")
            .header("User-Agent", ArixMediaApi.BrowserUserAgent)
            .header("Accept", applicationJson)
            .header("Content-Type", "application/octet-stream")
            .put(body)
            .build()
        client.newCall(putRequest).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw IOException("Filebin upload failed (HTTP ${response.code}). Try another server.")
            }
            val filename = runCatching {
                JSONObject(text).optJSONObject("file")?.optString("filename").orEmpty()
            }.getOrDefault("")
            val finalName = filename.takeIf { it.isNotBlank() } ?: fileName
            return UploadResult(
                url = "https://filebin.net/$bin/${urlSafe(finalName)}",
                server = ServerFilebin,
                fileName = finalName,
                sizeBytes = size,
            )
        }
    }

    private fun uploadToTmpFiles(body: okhttp3.RequestBody, fileName: String, size: Long): UploadResult {
        val multipart = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("file", fileName, body)
            .build()
        val request = Request.Builder()
            .url("https://tmpfiles.org/api/v1/upload")
            .header("User-Agent", ArixMediaApi.BrowserUserAgent)
            .post(multipart)
            .build()
        client.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw IOException("tmpfiles.org upload failed (HTTP ${response.code}). Try another server.")
            }
            val pageUrl = runCatching {
                JSONObject(text).optJSONObject("data")?.optString("url").orEmpty()
            }.getOrDefault("")
            if (pageUrl.isBlank()) {
                throw IOException("tmpfiles.org did not return a link. Try another server.")
            }
            val directUrl = if (pageUrl.contains("/dl/")) pageUrl else pageUrl.replaceFirst("/([^/]+)/([^/]+)$".toRegex(), "/dl/$1/$2")
            return UploadResult(
                url = directUrl,
                server = ServerTmpFiles,
                fileName = fileName,
                sizeBytes = size,
            )
        }
    }

    private fun uploadToGoFile(body: okhttp3.RequestBody, fileName: String, size: Long): UploadResult {
        val serverRequest = Request.Builder()
            .url("https://api.gofile.io/servers")
            .header("User-Agent", ArixMediaApi.BrowserUserAgent)
            .get()
            .build()
        val serverName = client.newCall(serverRequest).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw IOException("GoFile is not reachable right now (HTTP ${response.code}). Try another server.")
            }
            runCatching {
                JSONObject(text)
                    .optJSONObject("data")
                    ?.optJSONArray("servers")
                    ?.optJSONObject(0)
                    ?.optString("name")
                    .orEmpty()
            }.getOrDefault("")
        }
        if (serverName.isBlank()) {
            throw IOException("GoFile did not provide an upload server. Try another server.")
        }
        val multipart = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("file", fileName, body)
            .build()
        val uploadRequest = Request.Builder()
            .url("https://$serverName.gofile.io/contents/uploadfile")
            .header("User-Agent", ArixMediaApi.BrowserUserAgent)
            .post(multipart)
            .build()
        client.newCall(uploadRequest).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw IOException("GoFile upload failed (HTTP ${response.code}). Try another server.")
            }
            val downloadPage = runCatching {
                JSONObject(text).optJSONObject("data")?.optString("downloadPage").orEmpty()
            }.getOrDefault("")
            if (downloadPage.isBlank()) {
                throw IOException("GoFile did not return a link. Try another server.")
            }
            return UploadResult(
                url = downloadPage,
                server = ServerGoFile,
                fileName = fileName,
                sizeBytes = size,
            )
        }
    }

    private fun uploadToQuAx(body: okhttp3.RequestBody, fileName: String, size: Long): UploadResult {
        val multipart = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("files[]", fileName, body)
            .build()
        val request = Request.Builder()
            .url("https://qu.ax/upload")
            .header("User-Agent", ArixMediaApi.BrowserUserAgent)
            .post(multipart)
            .build()
        client.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw IOException("qu.ax upload failed (HTTP ${response.code}). Try another server.")
            }
            val url = runCatching {
                JSONObject(text)
                    .optJSONArray("files")
                    ?.optJSONObject(0)
                    ?.optString("url")
                    .orEmpty()
            }.getOrDefault("")
            if (url.isBlank()) {
                throw IOException("qu.ax did not return a link. Try another server.")
            }
            return UploadResult(
                url = url,
                server = ServerQuAx,
                fileName = fileName,
                sizeBytes = size,
            )
        }
    }

    private fun uploadToX0(body: okhttp3.RequestBody, fileName: String, size: Long): UploadResult {
        val multipart = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("file", fileName, body)
            .build()
        val request = Request.Builder()
            .url("https://x0.at/")
            .header("User-Agent", "ArixFileShare/2.4 (Android; file sharing tool)")
            .post(multipart)
            .build()
        client.newCall(request).execute().use { response ->
            val text = response.body?.string()?.trim().orEmpty()
            if (!response.isSuccessful || !text.startsWith("http")) {
                throw IOException("x0.at is not reachable from this network (HTTP ${response.code}). Try another server.")
            }
            return UploadResult(
                url = text.substringBefore('\n'),
                server = ServerX0,
                fileName = fileName,
                sizeBytes = size,
            )
        }
    }

    private const val applicationJson = "application/json"
    private val BinChars = "abcdefghjkmnpqrstuvwxyz23456789"

    internal fun contentTypeFor(fileName: String): okhttp3.MediaType? {
        val extension = fileName.substringAfterLast('.', "").lowercase()
        val raw = when (extension) {
            "png" -> "image/png"
            "jpg", "jpeg" -> "image/jpeg"
            "gif" -> "image/gif"
            "webp" -> "image/webp"
            "svg" -> "image/svg+xml"
            "mp4", "m4v" -> "video/mp4"
            "webm" -> "video/webm"
            "mkv" -> "video/x-matroska"
            "mov" -> "video/quicktime"
            "mp3" -> "audio/mpeg"
            "m4a" -> "audio/mp4"
            "wav" -> "audio/x-wav"
            "ogg", "opus" -> "audio/ogg"
            "flac" -> "audio/flac"
            "pdf" -> "application/pdf"
            "zip" -> "application/zip"
            "apk" -> "application/vnd.android.package-archive"
            "json" -> "application/json"
            "txt", "md" -> "text/plain"
            "html", "htm" -> "text/html"
            "css" -> "text/css"
            "js" -> "text/javascript"
            "ts" -> "text/typescript"
            "csv" -> "text/csv"
            "tar", "gz", "tgz", "xz", "zst" -> "application/octet-stream"
            "doc" -> "application/msword"
            "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            "xls" -> "application/vnd.ms-excel"
            "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            "ppt" -> "application/vnd.ms-powerpoint"
            "pptx" -> "application/vnd.openxmlformats-officedocument.presentationml.presentation"
            "epub" -> "application/epub+zip"
            else -> "application/octet-stream"
        }
        return raw.toMediaType()
    }

    private fun randomBinId(): String {
        val sb = StringBuilder("arix")
        repeat(14) {
            sb.append(BinChars[random.nextInt(BinChars.length)])
        }
        return sb.toString()
    }

    private fun urlSafe(name: String): String =
        name.replace(Regex("[^A-Za-z0-9._ ()-]"), "_").take(120).ifBlank { "file.bin" }

    private fun queryDisplayName(
        resolver: android.content.ContentResolver,
        uri: Uri,
    ): String = runCatching {
        resolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) cursor.getString(index) else null
            } else {
                null
            }
        }
    }.getOrNull()
        ?: uri.lastPathSegment?.substringAfterLast('/')?.substringAfter(':')
        ?: "arix-${System.currentTimeMillis()}.bin"

    private fun querySize(
        resolver: android.content.ContentResolver,
        uri: Uri,
    ): Long = runCatching {
        resolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (index >= 0) cursor.getLong(index).takeIf { it > 0 } else null
            } else {
                null
            }
        }
    }.getOrNull() ?: -1L

    fun formatBytes(bytes: Long): String {
        if (bytes <= 0) return "unknown size"
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0
        return when {
            gb >= 1 -> "%.2f GB".format(gb)
            mb >= 1 -> "%.1f MB".format(mb)
            kb >= 1 -> "%.0f KB".format(kb)
            else -> "$bytes B"
        }
    }
}
