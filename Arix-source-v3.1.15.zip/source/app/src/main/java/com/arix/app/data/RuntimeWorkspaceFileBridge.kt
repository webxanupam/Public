package com.arix.app.data

import android.content.Context
import android.net.Uri
import com.arix.app.runtime.TermuxRuntime
import java.io.ByteArrayOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private const val RuntimeWorkspaceInlineBytesLimit = 5 * 1024 * 1024
private const val RuntimeWorkspaceProgressIntervalMillis = 500L

class RuntimeWorkspaceFileBridge(
    context: Context,
    private val termuxRuntime: TermuxRuntime,
) {
    private val appContext = context.applicationContext

    suspend fun importAttachmentToWorkspace(
        sourceUri: Uri,
        attachmentId: String,
        displayName: String,
        onProgress: (WorkspaceImportProgress) -> Unit = {},
    ): Result<ImportedWorkspaceFile> = withContext(Dispatchers.IO) {
        runCatching {
            require(termuxRuntime.inspectSetup().isReady) { "Termux runtime is not ready." }
            val safeFileName = buildRuntimeWorkspaceFileName(attachmentId, displayName)
            val destinationPath = "${termuxRuntime.workspaceRoot}/uploads/$safeFileName"
            val resolved = termuxRuntime.resolveWorkspaceHostPath(destinationPath)
                ?: error("Unable to resolve the Termux workspace path.")
            resolved.hostFile.parentFile?.mkdirs()

            val input = appContext.contentResolver.openInputStream(sourceUri)
                ?: error("Couldn't read the selected file.")
            val inlineBuffer = ByteArrayOutputStream()
            val startedAtMillis = System.currentTimeMillis()
            var lastProgressAtMillis = 0L
            var bytesCopied = 0L

            fun emitProgress(force: Boolean = false) {
                val now = System.currentTimeMillis()
                if (!force && now - lastProgressAtMillis < RuntimeWorkspaceProgressIntervalMillis) return
                onProgress(
                    WorkspaceImportProgress(
                        bytesCopied = bytesCopied,
                        bytesPerSecond = bytesCopied * 1_000L / (now - startedAtMillis).coerceAtLeast(1L),
                    )
                )
                lastProgressAtMillis = now
            }

            input.use { source ->
                resolved.hostFile.outputStream().buffered().use { destination ->
                    val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                    while (true) {
                        val read = source.read(buffer)
                        if (read <= 0) break
                        destination.write(buffer, 0, read)
                        if (inlineBuffer.size() < RuntimeWorkspaceInlineBytesLimit) {
                            val remaining = RuntimeWorkspaceInlineBytesLimit - inlineBuffer.size()
                            inlineBuffer.write(buffer, 0, minOf(read, remaining))
                        }
                        bytesCopied += read
                        emitProgress()
                    }
                    destination.flush()
                }
            }
            emitProgress(force = true)

            ImportedWorkspaceFile(
                absolutePath = destinationPath,
                bytesCopied = bytesCopied,
                inlineBytes = if (bytesCopied <= RuntimeWorkspaceInlineBytesLimit) {
                    inlineBuffer.toByteArray()
                } else {
                    ByteArray(0)
                },
            )
        }
    }

    suspend fun readWorkspaceFile(
        settings: AppSettings,
        path: String,
        workingDirectory: String = "",
        byteLimit: Int,
    ): Result<WorkspaceFilePayload> {
        val resolvedWorkingDirectory = workingDirectory.ifBlank { termuxRuntime.workspaceRoot }
        return readWorkspaceFile(
            path = path,
            workingDirectory = resolvedWorkingDirectory,
            byteLimit = byteLimit,
        )
    }

    suspend fun readWorkspaceFile(
        path: String,
        workingDirectory: String,
        @Suppress("UNUSED_PARAMETER") defaultRuntimeId: LocalRuntimeId,
        byteLimit: Int,
    ): Result<WorkspaceFilePayload> = readWorkspaceFile(
        path = path,
        workingDirectory = workingDirectory,
        byteLimit = byteLimit,
    )

    private suspend fun readWorkspaceFile(
        path: String,
        workingDirectory: String,
        byteLimit: Int,
    ): Result<WorkspaceFilePayload> = WorkspaceFileIo.readWorkspaceFile(
        termuxRuntime = termuxRuntime,
        path = normalizeWorkspaceFileLink(path),
        workingDirectory = workingDirectory,
        byteLimit = byteLimit,
    )

    suspend fun writeWorkspaceBytes(
        settings: AppSettings,
        absolutePath: String,
        bytes: ByteArray,
    ): Result<Long> = WorkspaceFileIo.writeWorkspaceBytes(
        termuxRuntime = termuxRuntime,
        absolutePath = normalizeWorkspaceFileLink(absolutePath),
        bytes = bytes,
    )

    suspend fun saveWorkspaceFileToDocument(
        settings: AppSettings,
        path: String,
        destinationUri: Uri,
        workingDirectory: String = termuxRuntime.workspaceRoot,
        byteLimit: Int = 256 * 1024 * 1024,
    ): Boolean = WorkspaceFileIo.saveWorkspaceFileToDocument(
        appContext = appContext,
        termuxRuntime = termuxRuntime,
        path = normalizeWorkspaceFileLink(path),
        destinationUri = destinationUri,
        workingDirectory = workingDirectory,
        byteLimit = byteLimit,
    )

    fun guessMimeType(path: String): String = WorkspaceFileIo.guessMimeType(path)
}

private fun buildRuntimeWorkspaceFileName(
    attachmentId: String,
    displayName: String,
): String {
    val trimmedName = displayName.trim().ifBlank { "attachment" }
    val dotIndex = trimmedName.lastIndexOf('.')
    val stem = if (dotIndex > 0) trimmedName.substring(0, dotIndex) else trimmedName
    val extension = if (dotIndex > 0 && dotIndex < trimmedName.lastIndex) {
        trimmedName.substring(dotIndex)
    } else {
        ""
    }
    val safeStem = stem.replace(Regex("[^a-zA-Z0-9._-]"), "_")
        .replace(Regex("_+"), "_")
        .trim('_')
        .take(80)
        .ifBlank { "attachment" }
    val safeExtension = extension.takeIf { it.startsWith('.') }
        ?.drop(1)
        ?.replace(Regex("[^a-zA-Z0-9]"), "")
        ?.take(12)
        ?.takeIf(String::isNotBlank)
        ?.let { ".$it" }
        .orEmpty()
    val suffix = attachmentId.substringAfter("attachment-", attachmentId)
        .replace(Regex("[^a-zA-Z0-9_-]"), "")
        .takeLast(12)
        .ifBlank { System.currentTimeMillis().toString() }
    return "${safeStem}_$suffix$safeExtension"
}
