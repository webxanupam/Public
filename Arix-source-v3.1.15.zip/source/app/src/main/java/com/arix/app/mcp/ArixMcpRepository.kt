package com.arix.app.mcp

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONObject

private val Context.mcpDataStore by preferencesDataStore(name = "arix_mcp")

class ArixMcpRepository(private val context: Context) {

    private val serversKey = stringPreferencesKey("mcp_servers_json")

    val servers: Flow<List<ArixMcpServerConfig>> = context.mcpDataStore.data.map { prefs ->
        parseServers(prefs[serversKey].orEmpty())
    }

    private fun parseServers(raw: String): List<ArixMcpServerConfig> {
        if (raw.isBlank()) return emptyList()
        return runCatching {
            val root = JSONObject(raw)
            val serversObject = root.optJSONObject("mcpServers") ?: return emptyList()
            buildList {
                serversObject.keys().forEach { name ->
                    serversObject.optJSONObject(name)?.let { entry ->
                        add(ArixMcpServerConfig.fromJson(name, entry))
                    }
                }
            }.sortedBy { it.name.lowercase() }
        }.getOrDefault(emptyList())
    }

    private fun serialize(servers: List<ArixMcpServerConfig>): String {
        val root = JSONObject()
        val serversObject = JSONObject()
        servers.forEach { config ->
            serversObject.put(config.name, config.toJson())
        }
        root.put("mcpServers", serversObject)
        return root.toString(2)
    }

    suspend fun upsertServer(config: ArixMcpServerConfig) {
        context.mcpDataStore.edit { prefs ->
            val current = parseServers(prefs[serversKey].orEmpty())
                .filterNot { it.name == config.name } + config
            prefs[serversKey] = serialize(current.sortedBy { it.name.lowercase() })
        }
    }

    suspend fun removeServer(name: String) {
        context.mcpDataStore.edit { prefs ->
            val current = parseServers(prefs[serversKey].orEmpty())
                .filterNot { it.name == name }
            prefs[serversKey] = serialize(current)
        }
    }

    suspend fun setEnabled(name: String, enabled: Boolean) {
        context.mcpDataStore.edit { prefs ->
            val current = parseServers(prefs[serversKey].orEmpty()).map {
                if (it.name == name) it.copy(enabled = enabled) else it
            }
            prefs[serversKey] = serialize(current)
        }
    }

    suspend fun setDisabledTools(name: String, disabledTools: Set<String>) {
        context.mcpDataStore.edit { prefs ->
            val current = parseServers(prefs[serversKey].orEmpty()).map {
                if (it.name == name) it.copy(disabledTools = disabledTools) else it
            }
            prefs[serversKey] = serialize(current)
        }
    }

    suspend fun updateOAuth(name: String, oauth: ArixMcpOAuthConfig?) {
        context.mcpDataStore.edit { prefs ->
            val current = parseServers(prefs[serversKey].orEmpty()).map {
                if (it.name == name) it.copy(oauth = oauth) else it
            }
            prefs[serversKey] = serialize(current)
        }
    }

    suspend fun replaceServers(servers: List<ArixMcpServerConfig>) {
        context.mcpDataStore.edit { prefs ->
            prefs[serversKey] = serialize(servers.sortedBy { it.name.lowercase() })
        }
    }
}
