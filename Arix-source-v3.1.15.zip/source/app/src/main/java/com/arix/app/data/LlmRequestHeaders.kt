package com.arix.app.data

import java.net.HttpURLConnection

internal fun HttpURLConnection.applyArixLlmHeaders(
    userAgent: String,
    customHeaders: List<LlmCustomHeader>,
) {
    setRequestProperty("User-Agent", normalizeLlmUserAgent(userAgent))
    customHeaders.normalizedLlmHeaders().forEach { header ->
        setRequestProperty(header.name, header.value)
    }
}
