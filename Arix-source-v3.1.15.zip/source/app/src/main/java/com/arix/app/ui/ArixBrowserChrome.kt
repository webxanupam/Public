package com.arix.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

internal data class ArixChromeColors(
    val window: Color,
    val toolbar: Color,
    val tabActive: Color,
    val tabInactive: Color,
    val omnibox: Color,
    val omniboxFocused: Color,
    val text: Color,
    val textSecondary: Color,
    val accent: Color,
    val divider: Color,
    val fieldBorder: Color,
)

internal val ArixChromeDark = ArixChromeColors(
    window = Color(0xFF17181C),
    toolbar = Color(0xFF232429),
    tabActive = Color(0xFF2E3036),
    tabInactive = Color(0xFF1B1C20),
    omnibox = Color(0xFF2E3036),
    omniboxFocused = Color(0xFF232429),
    text = Color(0xFFE8EAED),
    textSecondary = Color(0xFF9AA0A6),
    accent = Color(0xFF8AB4F8),
    divider = Color(0xFF34363B),
    fieldBorder = Color(0xFF5F6368),
)

internal val ArixChromeLight = ArixChromeColors(
    window = Color(0xFFF3F4F8),
    toolbar = Color(0xFFFFFFFF),
    tabActive = Color(0xFFFFFFFF),
    tabInactive = Color(0xFFE8EAEE),
    omnibox = Color(0xFFEDF0F4),
    omniboxFocused = Color(0xFFFFFFFF),
    text = Color(0xFF1F2024),
    textSecondary = Color(0xFF5B6169),
    accent = Color(0xFF1A73E8),
    divider = Color(0xFFE1E3E8),
    fieldBorder = Color(0xFFC4C8CE),
)


@Composable
internal fun arixChromeColors(): ArixChromeColors =
    if (MaterialTheme.colorScheme.background.luminance() < 0.5f) ArixChromeDark else ArixChromeLight

private fun Color.luminance(): Float = 0.2126f * red + 0.7152f * green + 0.0722f * blue
