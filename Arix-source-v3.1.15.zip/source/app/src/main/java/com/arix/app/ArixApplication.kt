package com.arix.app

import android.app.Application
import android.content.Context
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import com.arix.app.data.ArixMissionAgentBridge
import com.arix.app.data.ArixPersonaRepository
import com.arix.app.data.ArixProjectRepository
import com.arix.app.data.memory.ArixIndexedMemoryStore
import com.arix.app.data.AgentExtensionsRepository
import com.arix.app.data.AgentSkillManager
import com.arix.app.data.ArixDiagnosticsService
import com.arix.app.data.ArixMemoryManager
import com.arix.app.data.ArixSwarmManager
import com.arix.app.data.ArixToolExecutor
import com.arix.app.data.ArixSessionContextTracker
import com.arix.app.data.ArixDiagnosticLogger
import com.arix.app.data.ArixUpiPaymentController
import com.arix.app.data.ChatRepository
import com.arix.app.data.RuntimeWorkspaceFileBridge
import com.arix.app.data.ChatStateStore
import com.arix.app.data.ScheduledTask
import com.arix.app.data.ScheduledTaskManager
import com.arix.app.data.ScheduledTaskRepository
import com.arix.app.data.ScheduledTaskScheduler
import com.arix.app.data.SessionExecutionManager
import com.arix.app.data.SettingsRepository
import com.arix.app.data.WorkspaceFileBridge
import com.arix.app.data.pi.PiCompletionClient
import com.arix.app.data.pi.PiAgentRunner
import com.arix.app.data.pi.PiKernelBridge
import com.arix.app.runtime.TermuxRuntime
import com.arix.app.runtime.RuntimeRouter
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

open class ArixApplication : Application(), com.arix.app.agent.ArixPhoneServices.Owner {
    val runtime: ArixAppRuntime by lazy(LazyThreadSafetyMode.NONE) {
        ArixAppRuntime(this)
    }

    /** v3.1.15 — phone control services (Mika port): helper handoff, pairing,
     * watchdog, the shared shell connection. Created eagerly: the helper's
     * handoff provider call can arrive before/with Application.onCreate. */
    override val phone: com.arix.app.agent.ArixPhoneServices by lazy(LazyThreadSafetyMode.NONE) {
        com.arix.app.agent.ArixPhoneServices(this)
    }

    private val migrationScope = CoroutineScope(
        SupervisorJob() + Dispatchers.Default,
    )

    override fun onCreate() {
        super.onCreate()
        // Phone control: touch the services early so the helper's handoff
        // (which may race Application.onCreate) always finds the hub ready.
        runCatching { phone }
        runCatching {
            com.arix.app.companion.ArixMochiMood.attach(this)
        }
        runCatching {
            com.arix.app.data.LegacyAetherStoreMigrator.migrate(this)
        }.onFailure { throwable ->
            android.util.Log.e("ArixApplication", "Legacy store migration failed", throwable)
        }
        runCatching {
            val result = com.arix.app.data.ArixLocalModelsCleanupMigrator.migrate(this)
            if (result.ran) {
                runtime.diagnosticLogger.event(
                    category = "maintenance",
                    event = "obsolete_local_models_cleanup",
                    level = if (result.failedFiles == 0) "info" else "warn",
                    details = mapOf(
                        "deleted_files" to result.deletedFiles,
                        "freed_bytes" to result.freedBytes,
                        "kept_unknown_files" to result.keptUnknownFiles,
                        "failed_files" to result.failedFiles,
                        "removed_directory" to result.removedDirectory,
                    ),
                )
            }
        }.onFailure { throwable ->
            android.util.Log.e("ArixApplication", "Local-models cleanup failed", throwable)
        }
        runCatching {
            com.arix.app.data.ArixMediaApi.initializePosterCache(this)
        }.onFailure { throwable ->
            android.util.Log.e("ArixApplication", "Media backend init failed", throwable)
        }
        runCatching { runtime.initialize() }.onFailure { throwable ->
            android.util.Log.e("ArixApplication", "Runtime init failed", throwable)
        }
        migrationScope.launch {
            kotlinx.coroutines.delay(1_500L)
            runCatching {
                com.arix.app.voice.ArixSpeechRecognitionController.prewarm(this@ArixApplication)
            }
        }
        runCatching { com.arix.app.ui.ArixMusicPulse.start(this) }
        runCatching { archiveLegacyOverlaySession() }
    }

    private fun archiveLegacyOverlaySession() {
        val appRuntime = runtime
        migrationScope.launch {
            runCatching {
                appRuntime.chatStateStore.flush()
                val sessionId = "assistant-overlay"
                val state = appRuntime.chatStateStore.state.first()
                val existing = state.sessions.firstOrNull { it.id == sessionId } ?: return@runCatching
                if (existing.messages.isEmpty()) {
                    appRuntime.chatStateStore.updateAndFlush { s ->
                        s.copy(sessions = s.sessions.filterNot { it.id == sessionId })
                    }
                } else {
                    val now = System.currentTimeMillis()
                    val firstUserText = existing.messages
                        .firstOrNull { it.author == com.arix.app.ui.MessageAuthor.User }
                        ?.text?.take(60)?.ifBlank { null }
                    val archived = existing.copy(
                        id = "overlay-legacy-$now",
                        title = firstUserText ?: "Arix Assistant \u00b7 " +
                            java.text.SimpleDateFormat(
                                "MMM d, HH:mm",
                                java.util.Locale.getDefault(),
                            ).format(java.util.Date(now)),
                        hasCustomTitle = true,
                    )
                    appRuntime.chatStateStore.updateAndFlush { s ->
                        s.copy(
                            sessions = listOf(archived) +
                                s.sessions.filterNot { it.id == sessionId },
                        )
                    }
                }
            }.onFailure { throwable ->
                appRuntime.diagnosticLogger.exception(
                    category = "maintenance",
                    event = "legacy_overlay_session_archive_failed",
                    throwable = throwable,
                )
            }
        }
    }

    override fun onTerminate() {
        super.onTerminate()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        runCatching { com.arix.app.browser.ArixBrowserMemory.onTrimMemory(level) }
    }
}

class ArixAppRuntime(
    private val application: ArixApplication,
) {
    val diagnosticLogger = ArixDiagnosticLogger(application)
    private val appScope = CoroutineScope(
        SupervisorJob() +
            Dispatchers.Default +
            CoroutineExceptionHandler { _, throwable ->
                diagnosticLogger.exception(
                    category = "coroutine",
                    event = "uncaught_exception",
                    throwable = throwable,
                )
            }
    )

    val settingsRepository = SettingsRepository(application)
    val chatRepository = ChatRepository(application)
    val extensionsRepository = AgentExtensionsRepository(application)
    val scheduledTaskRepository = ScheduledTaskRepository(
        context = application,
        diagnosticLogger = diagnosticLogger,
    )
    val termuxRuntime = TermuxRuntime(
        context = application,
        diagnosticLogger = diagnosticLogger,
    )
    val piKernelBridge = PiKernelBridge(
        termuxRuntime = termuxRuntime,
        diagnosticLogger = diagnosticLogger,
    )
    val acpClient = com.arix.app.data.acp.ArixAcpClient(
        bridge = piKernelBridge,
    )
    val piCompletionClient = PiCompletionClient(
        bridge = piKernelBridge,
        settingsRepository = settingsRepository,
    )
    val runtimeRouter = RuntimeRouter(
        termuxRuntime = termuxRuntime,
    )

    val workspaceFileBridge = WorkspaceFileBridge(
        context = application,
        termuxRuntime = termuxRuntime,
    )
    val runtimeWorkspaceFileBridge = RuntimeWorkspaceFileBridge(
        context = application,
        termuxRuntime = termuxRuntime,
    )
    val memoryManager = ArixMemoryManager(
        storageDirectory = application.filesDir,
        indexedStore = ArixIndexedMemoryStore(application),
    )
    val sessionContextTracker = ArixSessionContextTracker()

    val missionPersistence = com.arix.app.mission.ArixMissionPersistence(
        com.arix.app.mission.ArixMissionPersistence.defaultStoreFile(application.filesDir),
    )

    @Volatile
    private var missionExecutorBridge: com.arix.app.mission.ArixMissionEngine.MissionTaskExecutor? = null

    @Volatile
    private var missionCompleterBridge: com.arix.app.mission.ArixMissionEngine.MissionModelCompleter? = null

    val missionEngine = com.arix.app.mission.ArixMissionEngine(
        persistence = missionPersistence,
        executor = { task, tool, mission ->
            missionExecutorBridge?.execute(task, tool, mission)
                ?: com.arix.app.data.ArixMissionFallbacks.unavailableExecutorOutput()
        },
        modelComplete = { prompt -> missionCompleterBridge?.complete(prompt) },
        scope = appScope,
    )
    val projectRepository = ArixProjectRepository(application)
    val personaRepository = ArixPersonaRepository(application)

    @Volatile
    private var cachedSettings: com.arix.app.data.AppSettings? = null

    val diagnosticsService = ArixDiagnosticsService(
        versionName = BuildConfig.VERSION_NAME,
        bridgeProcessAlive = piKernelBridge::isProcessAlive,
        termuxSetupState = { runtimeRouter.runtimeById(com.arix.app.data.LocalRuntimeId.Termux).inspectSetup() },
        memoryStats = memoryManager::stats,
        memoryStoreHealthy = { application.filesDir.isDirectory && application.filesDir.canWrite() },
        providerConfigured = {
            val settings = cachedSettings
            settings != null && settings.piProviderId.isNotBlank() &&
                (settings.apiKey.isNotBlank() || settings.oauthCredentialJson.isNotBlank())
        },
        scheduledTaskCount = { scheduledTaskManager.snapshot().size },
    )
    val upiPaymentController = ArixUpiPaymentController(
        context = application,
    )
    val skillManager = AgentSkillManager(
        context = application,
        extensionsRepository = extensionsRepository,
    )
    val swarmManager = ArixSwarmManager(
        settingsRepository = settingsRepository,
        runtimeRouter = runtimeRouter,
        diagnosticLogger = diagnosticLogger,
    )
    val mcpRepository = com.arix.app.mcp.ArixMcpRepository(application)
    val mcpManager = com.arix.app.mcp.ArixMcpManager(
        repository = mcpRepository,
        termuxRuntime = termuxRuntime,
        onLog = { line ->
            runCatching {
                diagnosticLogger.event(
                    category = "mcp",
                    event = "stdio_log",
                    details = mapOf("line" to line.take(500)),
                )
            }
        },
    )

    // ------------------------------------------------------------------ //
    // v3.1.14 — Arix Script Extensions (ported from Aether).            //
    // Replaces the removed Claude-plugin marketplace system.            //
    // ------------------------------------------------------------------ //
    val extensionStateRepository = com.arix.app.data.ArixExtensionStateRepository(
        context = application,
    )
    val extensionPackageManager = com.arix.app.data.ArixExtensionPackageManager(
        context = application,
        termuxRuntime = termuxRuntime,
        piKernelBridge = piKernelBridge,
        stateRepository = extensionStateRepository,
    )
    val appExtensionManager = com.arix.app.data.ArixAppExtensionManager(
        bridge = piKernelBridge,
        scope = appScope,
        diagnosticLogger = diagnosticLogger,
        loadOptionsProvider = { extensionStateRepository.loadOptions() },
    )

    init {
        mcpManager.start()
    }

    val telegramSettings = com.arix.app.im.ArixTelegramSettingsRepository(application)
    val telegramPairing = com.arix.app.im.ArixTelegramPairingStore(application)

    val toolExecutor = ArixToolExecutor(
        runtimeRouter = runtimeRouter,
        upiPaymentController = upiPaymentController,
        memoryManager = memoryManager,
        diagnosticsService = diagnosticsService,
        sessionContextTracker = sessionContextTracker,
        termuxRuntime = termuxRuntime,
        appContext = application,
        swarmManager = swarmManager,
        projectRepository = projectRepository,
        mcpManager = mcpManager,
    )

    val piAgentRunner = PiAgentRunner(
        bridge = piKernelBridge,
        settingsRepository = settingsRepository,
        termuxRuntime = termuxRuntime,
        diagnosticLogger = diagnosticLogger,
        memoryManager = memoryManager,
        sessionContextTracker = sessionContextTracker,
        toolExecutor = toolExecutor,
    )

    init {
        swarmManager.bindRunner(piAgentRunner)
        missionExecutorBridge = ArixMissionAgentBridge(
            settingsRepository = settingsRepository,
            runtimeRouter = runtimeRouter,
            runner = piAgentRunner,
            toolExecutor = toolExecutor,
            completionClient = piCompletionClient,
            diagnosticLogger = diagnosticLogger,
        )
        missionCompleterBridge = ArixMissionAgentBridge.Completer(
            completionClient = piCompletionClient,
            settingsRepository = settingsRepository,
        )
        appScope.launch {
            var musicActive = false
            com.arix.app.media.ArixPlaybackController.state.collect { playback ->
                val active = playback.hasMedia &&
                    (playback.isPlaying || playback.isBuffering)
                if (active != musicActive) {
                    musicActive = active
                    if (active) {
                        com.arix.app.companion.ArixMochiBus.noteMusicStarted()
                    } else {
                        com.arix.app.companion.ArixMochiBus.noteMusicEnded()
                    }
                }
            }
        }
        appScope.launch {
            com.arix.app.ui.ArixMusicPulse.bassEnv.collect { bass ->
                com.arix.app.companion.ArixMochiBus.noteMusicPulse(bass)
            }
        }
    }
    val appForegroundTracker = AppForegroundTracker()
    val notificationController = ArixNotificationController(application)
    val scheduledTaskScheduler = ScheduledTaskScheduler(
        context = application,
        diagnosticLogger = diagnosticLogger,
    )
    val scheduledTaskManager = ScheduledTaskManager(
        repository = scheduledTaskRepository,
        scheduler = scheduledTaskScheduler,
    )
    val chatStateStore = ChatStateStore(
        scope = appScope,
        chatRepository = chatRepository,
    )
    val sessionExecutionManager = SessionExecutionManager(
        application = application,
        scope = appScope,
        settingsRepository = settingsRepository,
        extensionsRepository = extensionsRepository,
        chatStateStore = chatStateStore,
        chatRepository = chatRepository,
        runtimeRouter = runtimeRouter,
        workspaceFileBridge = workspaceFileBridge,
        skillManager = skillManager,
        scheduledTaskManager = scheduledTaskManager,
        notificationController = notificationController,
        appForegroundTracker = appForegroundTracker,
        diagnosticLogger = diagnosticLogger,
        piCompletionClient = piCompletionClient,
        piKernelBridge = piKernelBridge,
        piAgentRunner = piAgentRunner,
        missionEngine = missionEngine,
        swarmManager = swarmManager,
    )
    val automationManager = ArixAutomationManager(
        context = application,
        repository = scheduledTaskRepository,
        scheduler = scheduledTaskScheduler,
    )

    fun initialize() {
        diagnosticLogger.installUncaughtExceptionHandler()
        diagnosticLogger.event(
            category = "app",
            event = "startup",
            details = mapOf(
                "version_name" to BuildConfig.VERSION_NAME,
                "version_code" to BuildConfig.VERSION_CODE,
                "debug" to BuildConfig.DEBUG,
            ),
        )
        appScope.launch {
            var retryDelayMillis = 1_000L
            while (true) {
                val failure = runCatching {
                    settingsRepository.settings.collect { cachedSettings = it }
                }.exceptionOrNull()
                if (failure == null) break
                diagnosticLogger.exception(
                    category = "app",
                    event = "settings_collector_failed",
                    throwable = failure,
                )
                kotlinx.coroutines.delay(retryDelayMillis)
                retryDelayMillis = (retryDelayMillis * 2).coerceAtMost(60_000L)
            }
        }
        runCatching { com.arix.app.media.ArixPlaybackController.initialize(application) }
            .onFailure { throwable ->
                android.util.Log.e("ArixApplication", "Playback controller init failed", throwable)
            }
        notificationController.ensureChannels()
        ProcessLifecycleOwner.get().lifecycle.addObserver(appForegroundTracker)
        appScope.launch {
            termuxRuntime.refreshAptSourcesForCurrentNetwork()
        }
        appScope.launch {
            val setupState = runCatching { termuxRuntime.initializeForAutomaticSelfHeal() }
                .onFailure { throwable ->
                    diagnosticLogger.exception(
                        category = "termux",
                        event = "startup_selfheal_failed",
                        throwable = throwable,
                    )
                }
                .getOrNull()
            diagnosticLogger.event(
                category = "termux",
                event = "startup_selfheal_finished",
                level = if (setupState?.isReady == true) "info" else "warn",
                details = mapOf(
                    "issue" to (setupState?.issue?.name ?: "unknown"),
                    "detail" to (setupState?.detail.orEmpty()),
                ),
            )
        }
        appScope.launch {
            settingsRepository.migrateLegacyProvidersToPi()
        }
        appScope.launch {
            runCatching {
                val imported = memoryManager.activateIndexedStore()
                val swept = memoryManager.sweepIndexed()
                if (imported > 0 || swept > 0) {
                    diagnosticLogger.event(
                        category = "memory",
                        event = "indexed_store_migrated",
                        details = mapOf("imported" to imported, "swept" to swept),
                    )
                }
            }
        }
        appScope.launch {
            runCatching {
                val recovered = missionEngine.recoverInterruptedMissions()
                if (recovered > 0) {
                    diagnosticLogger.event(
                        category = "mission",
                        event = "interrupted_missions_recovered",
                        details = mapOf("count" to recovered),
                    )
                }
            }
        }
        appScope.launch {
            scheduledTaskManager.rescheduleAll()
        }
        appScope.launch {
            runCatching {
                missionEngine.events.collect { event ->
                    if (event.phase == "complete") {
                        notificationController.notifyCompletion(
                            sessionId = "mission-${event.missionId}",
                            sessionTitle = "Arix Mission",
                            summary = event.message,
                            failed = event.status == "failed",
                        )
                    }
                }
            }
        }
    }

    private val lastAlarmStartMillis = java.util.concurrent.ConcurrentHashMap<String, Long>()

    fun handleScheduledTaskAlarm(
        taskId: String,
        pendingResult: android.content.BroadcastReceiver.PendingResult,
    ) {
        diagnosticLogger.event(
            category = "scheduled_task",
            event = "alarm_received",
            details = mapOf("task_id" to taskId),
        )
        appScope.launch {
            try {
                val now = System.currentTimeMillis()
                val lastStart = lastAlarmStartMillis[taskId] ?: 0L
                if (now - lastStart < DuplicateDeliveryWindowMillis) {
                    diagnosticLogger.event(
                        category = "scheduled_task",
                        event = "duplicate_delivery_skipped",
                        level = "warn",
                        details = mapOf(
                            "task_id" to taskId,
                            "since_last_start_millis" to (now - lastStart),
                        ),
                    )
                    return@launch
                }
                lastAlarmStartMillis[taskId] = now
                val task = scheduledTaskManager.markTriggeredAndScheduleNext(taskId)
                if (task == null) {
                    diagnosticLogger.event(
                        category = "scheduled_task",
                        event = "trigger_missing_task",
                        level = "warn",
                        details = mapOf("task_id" to taskId),
                    )
                    return@launch
                }
                val started = startScheduledTaskFromAlarm(task)
                diagnosticLogger.event(
                    category = "scheduled_task",
                    event = if (started) "trigger_started" else "trigger_skipped",
                    level = if (started) "info" else "warn",
                    details = mapOf("task_id" to taskId),
                )
            } finally {
                pendingResult.finish()
            }
        }
    }

    private suspend fun startScheduledTaskFromAlarm(task: ScheduledTask): Boolean {
        return try {
            if (settingsRepository.settings.first().keepTasksRunningInBackground) {
                runCatching {
                    ArixForegroundService.ensureRunning(application)
                }.onFailure { throwable ->
                    diagnosticLogger.exception(
                        category = "scheduled_task",
                        event = "foreground_service_start_failed",
                        throwable = throwable,
                        details = mapOf("task_id" to task.id),
                    )
                }
            }
            sessionExecutionManager.startScheduledTask(task)
        } catch (throwable: Throwable) {
            diagnosticLogger.exception(
                category = "scheduled_task",
                event = "trigger_start_failed",
                throwable = throwable,
                details = mapOf("task_id" to task.id),
            )
            false
        }
    }

    private companion object {
        const val DuplicateDeliveryWindowMillis = 30_000L
    }

    fun rescheduleScheduledTasks(
        pendingResult: android.content.BroadcastReceiver.PendingResult,
    ) {
        appScope.launch {
            try {
                scheduledTaskManager.rescheduleAll()
            } finally {
                pendingResult.finish()
            }
        }
    }
}

class AppForegroundTracker : DefaultLifecycleObserver {
    private val _isForeground = MutableStateFlow(false)

    val isForeground: StateFlow<Boolean> = _isForeground.asStateFlow()

    override fun onStart(owner: LifecycleOwner) {
        _isForeground.value = true
    }

    override fun onStop(owner: LifecycleOwner) {
        _isForeground.value = false
    }
}

val Context.arixRuntime: ArixAppRuntime
    get() = (applicationContext as ArixApplication).runtime
