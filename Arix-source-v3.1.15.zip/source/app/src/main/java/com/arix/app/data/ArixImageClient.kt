package com.arix.app.data

import com.arix.app.media.ArixMediaHttp

object ArixImageClient {

    private val SearchPlumbingHosts = listOf(
        "google.com", "gstatic.com", "googleusercontent.com", "ggpht.com",
        "bing.com", "bing.net", "microsoft.com", "msn.com",
        "duckduckgo.com", "w3.org", "schema.org",
    )

    suspend fun researchBestSites(
        query: String,
        allowAdult: Boolean,
        maxSites: Int = 6,
    ): List<Pair<String, String>> {
        val found = LinkedHashMap<String, String>()

        val googleUrl = "https://www.google.com/search?q=${urlEncode(query)}" +
            "&num=20&hl=en&safe=${if (allowAdult) "off" else "active"}"
        fetchHtmlThroughProxies(googleUrl)?.let { html ->
            val pattern = Regex("""href="(https?://(?!www\.google\.|accounts\.google\.|support\.google\.|policies\.google\.|maps\.google\.)[^"]+)"""")
            for (match in pattern.findAll(html)) {
                val link = match.groupValues[1].substringBefore('&').takeIf { it.startsWith("http") }
                    ?: continue
                if (link.startsWith("https://www.google.com/search")) continue
                if (isSearchPlumbing(link)) continue
                val host = link.toHost()
                if (host.isBlank()) continue
                if (found.size < maxSites && found.none { it.key.toHost() == host }) {
                    found[link] = host
                }
                if (found.size >= maxSites) break
            }
        }
        if (found.isNotEmpty()) return found.map { it.key to it.value }

        val bingUrl = "https://www.bing.com/search?q=${urlEncode(query)}" +
            "&count=20&adlt=${if (allowAdult) "off" else "strict"}"
        val bingHtml = fetchHtmlThroughProxies(bingUrl) ?: return emptyList()
        val algoBlocks = Regex("""<li class="b_algo".*?</li>""", RegexOption.DOT_MATCHES_ALL)
            .findAll(bingHtml)
        for (block in algoBlocks) {
            val blockText = block.value
            val linkMatch = Regex("""href="(https?://[^"]+)"""").find(blockText)
                ?: continue
            val rawLink = linkMatch.groupValues[1]
                .replace("&amp;", "&")
            val link = decodeBingRedirect(rawLink)
            if (!link.startsWith("http") || isSearchPlumbing(link)) continue
            val host = link.toHost()
            if (host.isBlank()) continue
            if (found.size < maxSites && found.none { it.key.toHost() == host }) {
                val titleMatch = Regex(">([^<]{4,90})</a>").find(blockText)
                found[link] = titleMatch?.groupValues?.get(1)?.trim() ?: host
            }
            if (found.size >= maxSites) break
        }
        return found.map { it.key to it.value }
    }

    private fun decodeBingRedirect(link: String): String {
        if (!link.contains("bing.com/ck/a")) return link
        return runCatching {
            val uParam = link.substringAfter("u=").substringBefore('&')
            val base64 = uParam.removePrefix("a1")
                .replace("-", "+")
                .replace("_", "/")
            val padded = base64 + "=".repeat((4 - base64.length % 4) % 4)
            String(java.util.Base64.getDecoder().decode(padded))
        }.getOrNull() ?: link
    }

    private suspend fun fetchHtmlThroughProxies(url: String): String? {
        val (html, _) = ArixMediaHttp.fetchBody(
            url = url,
            accept = "text/html,application/xhtml+xml,*/*;q=0.8",
            readTimeoutSeconds = 20L,
            minBytes = 512,
        ) ?: return null
        return html.takeIf { it.contains("<") }
    }

    private fun isSearchPlumbing(url: String): Boolean {
        val host = url.toHost()
        if (host.isBlank()) return true
        return SearchPlumbingHosts.any { host == it || host.endsWith(".$it") }
    }

    private fun urlEncode(value: String): String =
        java.net.URLEncoder.encode(value, "UTF-8")
}

internal fun String.toHost(): String = runCatching {
    val noScheme = substringAfter("://", this)
    noScheme.substringBefore('/').substringBefore(':').lowercase()
}.getOrDefault("")
