package com.arix.app.ui

import android.net.Uri
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.SmartDisplay
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.foundation.clickable
import com.arix.app.media.ArixMediaItem
import com.arix.app.media.ArixMediaKind
import com.arix.app.media.ArixPlaybackController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
internal fun MarkdownMediaLinkBlock(
    spec: MarkdownMediaLinkSpec,
    onLinkClick: (String) -> Unit,
) {
    when (spec.kind) {
        MarkdownMediaLinkKind.Video -> MarkdownVideoLinkCard(spec, onLinkClick)
        MarkdownMediaLinkKind.YouTube -> MarkdownYouTubeLinkCard(spec, onLinkClick)
        MarkdownMediaLinkKind.Audio -> MarkdownAudioLinkCard(spec, onLinkClick)
    }
}

@Composable
private fun MediaLinkCardShell(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconTint: Color,
    title: String,
    domain: String,
    badge: String,
    content: @Composable () -> Unit,
    actions: @Composable () -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    val darkCard = scheme.background.luminanceForCard() < 0.5f
    val cardShape = RoundedCornerShape(18.dp)
    val cardBackground = Brush.verticalGradient(
        listOf(
            scheme.primaryContainer.copy(alpha = if (darkCard) 0.30f else 0.50f),
            scheme.surface.copy(alpha = if (darkCard) 0.90f else 0.96f),
        ),
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(cardShape)
            .background(cardBackground)
            .border(1.dp, scheme.outline, cardShape)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(3.dp)
                .clip(RoundedCornerShape(999.dp))
                .background(Brush.horizontalGradient(listOf(scheme.primary, scheme.tertiary))),
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(scheme.primary.copy(alpha = 0.24f), scheme.tertiary.copy(alpha = 0.30f)),
                        ),
                    ),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(21.dp),
                )
            }
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium,
                    color = scheme.onSurface,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = domain,
                    style = MaterialTheme.typography.labelSmall,
                    color = scheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Text(
                text = badge,
                style = MaterialTheme.typography.labelMedium,
                color = scheme.onSurfaceVariant,
                modifier = Modifier
                    .clip(RoundedCornerShape(999.dp))
                    .background(scheme.surfaceVariant.copy(alpha = 0.4f))
                    .padding(horizontal = 9.dp, vertical = 3.dp),
                maxLines = 1,
            )
        }
        content()
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(scheme.outlineVariant.copy(alpha = 0.4f)),
        )
        actions()
    }
}

private fun androidx.compose.ui.graphics.Color.luminanceForCard(): Float {
    val red = red * 0.2126f
    val green = green * 0.7152f
    val blue = blue * 0.0722f
    return red + green + blue
}

@Composable
private fun MarkdownVideoLinkCard(
    spec: MarkdownMediaLinkSpec,
    onLinkClick: (String) -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var working by remember(spec.url) { mutableStateOf(false) }
    var message by remember(spec.url) { mutableStateOf("") }
    val domain = remember(spec.url) { linkDomain(spec.url) }

    MediaLinkCardShell(
        icon = Icons.Rounded.Movie,
        iconTint = MaterialTheme.colorScheme.primary,
        title = spec.label,
        domain = domain,
        badge = "VIDEO",
        content = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.Black),
            ) {
                ArixVideoPlayer(streamUrl = spec.url)
            }
        },
        actions = {
            MediaLinkActionsRow(
                url = spec.url,
                onOpen = { onLinkClick(spec.url) },
                showDownload = true,
                downloadFileName = spec.label,
                downloadMime = "video/mp4",
                working = working,
                message = message,
                onWorkingChange = { working = it },
                onMessageChange = { message = it },
                context = context,
                scope = scope,
            )
        },
    )
}

@Composable
private fun MarkdownYouTubeLinkCard(
    spec: MarkdownMediaLinkSpec,
    onLinkClick: (String) -> Unit,
) {
    val context = LocalContext.current
    val videoId = remember(spec.url) { parseYouTubeVideoId(spec.url) }
    val embedUrl = remember(videoId) { videoId?.let { youTubeEmbedUrl(it) } }

    MediaLinkCardShell(
        icon = Icons.Rounded.SmartDisplay,
        iconTint = Color(0xFFFF6D6D),
        title = spec.label,
        domain = "youtube.com",
        badge = "YOUTUBE",
        content = {
            if (embedUrl != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 9f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.Black),
                ) {
                    AndroidView(
                        factory = { viewContext ->
                            WebView(viewContext).apply {
                                settings.javaScriptEnabled = true
                                settings.mediaPlaybackRequiresUserGesture = true
                                settings.cacheMode = WebSettings.LOAD_DEFAULT
                                settings.mixedContentMode =
                                    android.webkit.WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                                webViewClient = WebViewClient()
                                webChromeClient = WebChromeClient()
                                loadUrl(embedUrl)
                            }
                        },
                        onRelease = { view -> view.destroy() },
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            }
        },
        actions = {
            MediaLinkActionsRow(
                url = spec.url,
                onOpen = { onLinkClick(spec.url) },
                showDownload = false,
                downloadFileName = "",
                downloadMime = "",
                working = false,
                message = "",
                onWorkingChange = {},
                onMessageChange = {},
                context = context,
                scope = rememberCoroutineScope(),
            )
        },
    )
}

@Composable
private fun MarkdownAudioLinkCard(
    spec: MarkdownMediaLinkSpec,
    onLinkClick: (String) -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var working by remember(spec.url) { mutableStateOf(false) }
    var message by remember(spec.url) { mutableStateOf("") }
    val domain = remember(spec.url) { linkDomain(spec.url) }
    val playbackState by ArixPlaybackController.state.collectAsState()
    val isNowPlaying = playbackState.nowPlaying?.streamUrl == spec.url
    val isPlayingThis = isNowPlaying && playbackState.isPlaying

    val item = remember(spec.url, spec.label) {
        ArixMediaItem(
            id = "chat-audio:${spec.url}",
            title = spec.label,
            kind = ArixMediaKind.Audio,
            streamUrl = spec.url,
            sourceName = linkDomain(spec.url),
        )
    }

    MediaLinkCardShell(
        icon = Icons.Rounded.GraphicEq,
        iconTint = MaterialTheme.colorScheme.tertiary,
        title = spec.label,
        domain = domain,
        badge = "AUDIO",
        content = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    listOf(
                                        MaterialTheme.colorScheme.primary,
                                        MaterialTheme.colorScheme.tertiary,
                                    ),
                                ),
                            )
                            .clickable {
                                if (isNowPlaying) {
                                    ArixPlaybackController.togglePlayPause()
                                } else {
                                    ArixPlaybackController.playNow(item)
                                }
                            },
                        contentAlignment = Alignment.Center,
                    ) {
                        if (isNowPlaying && playbackState.isBuffering) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp,
                                color = Color.White,
                            )
                        } else {
                            Icon(
                                imageVector = if (isPlayingThis) {
                                    Icons.Rounded.Pause
                                } else {
                                    Icons.Rounded.PlayArrow
                                },
                                contentDescription = if (isPlayingThis) "Pause" else "Play",
                                tint = Color.White,
                                modifier = Modifier.size(26.dp),
                            )
                        }
                    }
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        val position = if (isNowPlaying) playbackState.positionMs else 0L
                        val duration = if (isNowPlaying) playbackState.durationMs else 0L
                        Text(
                            text = "${formatMediaTime(position)} / ${formatMediaTime(duration)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Slider(
                            value = if (duration > 0) {
                                (position.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
                            } else {
                                0f
                            },
                            onValueChange = { fraction ->
                                if (isNowPlaying && duration > 0) {
                                    ArixPlaybackController.seekTo((fraction * duration).toLong())
                                }
                            },
                            colors = SliderDefaults.colors(
                                thumbColor = MaterialTheme.colorScheme.primary,
                                activeTrackColor = MaterialTheme.colorScheme.primary,
                                inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant,
                            ),
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
                if (isNowPlaying) {
                    playbackState.errorMessage?.let { error ->
                        Text(
                            text = error,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.error,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
        },
        actions = {
            MediaLinkActionsRow(
                url = spec.url,
                onOpen = { onLinkClick(spec.url) },
                showDownload = true,
                downloadFileName = spec.label,
                downloadMime = "audio/mpeg",
                working = working,
                message = message,
                onWorkingChange = { working = it },
                onMessageChange = { message = it },
                context = context,
                scope = scope,
            )
        },
    )
}

@Composable
private fun MediaLinkActionsRow(
    url: String,
    onOpen: () -> Unit,
    showDownload: Boolean,
    downloadFileName: String,
    downloadMime: String,
    working: Boolean,
    message: String,
    onWorkingChange: (Boolean) -> Unit,
    onMessageChange: (String) -> Unit,
    context: android.content.Context,
    scope: kotlinx.coroutines.CoroutineScope,
) {
    val clipboard = androidx.compose.ui.platform.LocalClipboardManager.current
    var copied by remember(url) { mutableStateOf(false) }
    val copiedLabel = "Copied"

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (message.isNotBlank()) {
            Text(
                text = message,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            ArixWidgetActionButton(
                label = "Open",
                icon = Icons.Rounded.OpenInNew,
                primary = true,
                modifier = Modifier.weight(1f),
                onClick = onOpen,
            )
            ArixWidgetActionButton(
                label = if (copied) copiedLabel else "Copy",
                icon = if (copied) {
                    Icons.Rounded.CheckCircle
                } else {
                    Icons.Rounded.ContentCopy
                },
                primary = false,
                enabled = !copied,
                modifier = Modifier.weight(1f),
                onClick = {
                    clipboard.setText(androidx.compose.ui.text.AnnotatedString(url))
                    copied = true
                },
            )
            ArixWidgetActionButton(
                label = "Share",
                icon = Icons.Rounded.Share,
                primary = false,
                modifier = Modifier.weight(1f),
                onClick = { ArixMediaActions.shareText(context, url) },
            )
            if (showDownload) {
                ArixWidgetActionButton(
                    label = "Save",
                    icon = Icons.Rounded.Download,
                    primary = false,
                    enabled = !working,
                    modifier = Modifier.weight(1f),
                ) {
                    onWorkingChange(true)
                    onMessageChange("")
                    scope.launch {
                        val outcome = withContext(Dispatchers.IO) {
                            runCatching {
                                ArixMediaActions.downloadUrlToDownloads(
                                    context = context,
                                    url = url,
                                    fileName = downloadFileName,
                                    mimeType = downloadMime,
                                )
                            }
                        }
                        onWorkingChange(false)
                        onMessageChange(
                            outcome.fold(
                                onSuccess = { bytes ->
                                    "Saved · ${ArixMediaActions.formatFileSize(bytes)}"
                                },
                                onFailure = { it.message ?: "Could not save" },
                            ),
                        )
                    }
                }
            }
        }
    }
}

private fun linkDomain(url: String): String =
    runCatching { Uri.parse(url).host ?: url }.getOrDefault(url)

private fun formatMediaTime(milliseconds: Long): String {
    if (milliseconds <= 0) return "0:00"
    val totalSeconds = milliseconds / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return if (minutes >= 60) {
        val hours = minutes / 60
        "${hours}:${(minutes % 60).toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}"
    } else {
        "$minutes:${seconds.toString().padStart(2, '0')}"
    }
}
