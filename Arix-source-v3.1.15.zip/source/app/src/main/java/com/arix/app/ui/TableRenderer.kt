package com.arix.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.arix.app.ui.theme.ArixOnSurface
import com.arix.app.ui.theme.ArixSurface
import com.arix.app.ui.theme.ArixSurfaceHigh

private val MarkdownTableMinColumnWidth = 128.dp

private val MarkdownTableDescriptionMinColumnWidth = 160.dp

private val MarkdownTableScrollableColumnWidth = 148.dp

@Composable
internal fun MarkdownTable(
    headers: List<MarkdownSourceText>,
    rows: List<List<MarkdownSourceText>>,
    onLinkClick: (String) -> Unit,
) {
    val columnCount = remember(headers, rows) {
        maxOf(headers.size, rows.maxOfOrNull { it.size } ?: 0).coerceAtLeast(1)
    }

    BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
        val columnWidths = remember(columnCount, maxWidth) {
            markdownTableColumnWidths(columnCount, maxWidth)
        }
        val tableWidth = columnWidths.fold(0.dp) { width, columnWidth -> width + columnWidth }
            .coerceAtLeast(maxWidth)

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .clip(RoundedCornerShape(18.dp))
                .background(ArixSurface.copy(alpha = 0.92f)),
        ) {
            MarkdownTableRow(
                cells = headers,
                columnWidths = columnWidths,
                tableWidth = tableWidth,
                onLinkClick = onLinkClick,
                isHeader = true,
            )
            rows.forEachIndexed { index, row ->
                MarkdownTableRow(
                    cells = row,
                    columnWidths = columnWidths,
                    tableWidth = tableWidth,
                    onLinkClick = onLinkClick,
                    isHeader = false,
                    shaded = index % 2 == 1,
                )
            }
        }
    }
}

internal fun markdownTableColumnWidths(
    columnCount: Int,
    viewportWidth: Dp,
): List<Dp> {
    val normalizedColumnCount = columnCount.coerceAtLeast(1)
    return when {
        normalizedColumnCount == 1 -> listOf(viewportWidth.coerceAtLeast(MarkdownTableMinColumnWidth))
        normalizedColumnCount == 2 -> {
            val firstColumn = (viewportWidth * 0.42f).coerceAtLeast(MarkdownTableMinColumnWidth)
            val secondColumn = (viewportWidth - firstColumn)
                .coerceAtLeast(MarkdownTableDescriptionMinColumnWidth)
            listOf(firstColumn, secondColumn)
        }
        normalizedColumnCount == 3 -> {
            val columnWidth = (viewportWidth / normalizedColumnCount)
                .coerceAtLeast(MarkdownTableMinColumnWidth)
            List(normalizedColumnCount) { columnWidth }
        }
        else -> List(normalizedColumnCount) { MarkdownTableScrollableColumnWidth }
    }
}

@Composable
private fun MarkdownTableRow(
    cells: List<MarkdownSourceText>,
    columnWidths: List<Dp>,
    tableWidth: Dp,
    onLinkClick: (String) -> Unit,
    isHeader: Boolean,
    shaded: Boolean = false,
) {
    Row(
        modifier = Modifier
            .width(tableWidth)
            .background(
                when {
                    isHeader -> ArixSurfaceHigh
                    shaded -> ArixSurface.copy(alpha = 0.68f)
                    else -> Color.Transparent
                }
            )
    ) {
        columnWidths.forEachIndexed { index, columnWidth ->
            val cell = cells.getOrNull(index) ?: MarkdownSourceText("", 0)
            Box(
                modifier = Modifier
                    .width(columnWidth)
                    .padding(horizontal = 12.dp, vertical = 10.dp)
            ) {
                MarkdownRichTextBlock(
                    text = cell,
                    style = if (isHeader) {
                        MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold)
                    } else {
                        MaterialTheme.typography.bodyMedium
                    },
                    color = ArixOnSurface,
                    modifier = Modifier.heightIn(min = 20.dp),
                    onLinkClick = onLinkClick,
                    variant = MarkdownHtmlTextVariant.TableCell(isHeader = isHeader),
                )
            }
        }
    }
}
