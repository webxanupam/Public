package com.arix.app.data

import com.arix.app.data.pi.PiAgentRunner
import com.arix.app.runtime.RuntimeRouter
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject

data class ArixSubAgentActivity(
    val parentSessionId: String,
    val swarmId: String,
    val agentId: String,
    val agentName: String,
    val toolName: String,
    val argumentsJson: String,
    val outputJson: String?,
    val isRunning: Boolean,
)

class ArixSwarmManager(
    private val settingsRepository: SettingsRepository,
    private val runtimeRouter: RuntimeRouter,
    private val diagnosticLogger: ArixDiagnosticLogger = ArixDiagnosticLogger.NoOp,
) {

    @Volatile
    private var runner: PiAgentRunner? = null

    fun bindRunner(value: PiAgentRunner) {
        runner = value
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val agentCounter = AtomicLong(0L)
    private val swarms = ConcurrentHashMap<String, Swarm>()

    private val _subAgentActivity = MutableSharedFlow<ArixSubAgentActivity>(extraBufferCapacity = 256)
    val subAgentActivity: SharedFlow<ArixSubAgentActivity> = _subAgentActivity.asSharedFlow()

    class SubAgentSpec(
        val name: String,
        val role: String,
        val prompt: String,
    )

    class SubAgentResult(
        val name: String,
        val agentId: String,
        val outcome: String,
        val text: String,
        val toolCalls: Int,
    )

    class Swarm(
        val id: String,
        val parentSessionId: String,
        val agents: List<SubAgentHandle>,
        val createdAtMillis: Long,
        val completion: CompletableDeferred<Unit> = CompletableDeferred(),
        @Volatile var stopRequested: Boolean = false,
        @Volatile var collected: Boolean = false,
        @Volatile var parentCancelled: Boolean = false,
    )

    class SubAgentHandle(
        val agentId: String,
        val name: String,
        val spec: SubAgentSpec,
        @Volatile var status: String = "running",
        @Volatile var resultText: String = "",
        @Volatile var toolCalls: Int = 0,
    ) {
        val isTerminal: Boolean get() = status != "running"
    }

    suspend fun spawn(
        parentSessionId: String,
        agents: List<SubAgentSpec>,
        timeoutMillis: Long = DefaultAgentTimeoutMillis,
        maxToolCalls: Int = DefaultAgentToolBudget,
        onProgress: (suspend (String) -> Unit)?,
    ): JSONObject = coroutineScope {
        if (agents.isEmpty()) {
            return@coroutineScope failure("INVALID_ARGUMENT", "agents must not be empty")
        }
        val deduped = agents.distinctBy { "${it.role.trim().lowercase()}|${it.prompt.trim()}" }
        if (deduped.size < agents.size) {
            onProgress?.invoke(
                "Swarm deduplication: ${agents.size - deduped.size} duplicate agent(s) collapsed " +
                    "(identical role+prompt).",
            )
        }
        val bounded = deduped.take(MaxConcurrentAgents)
        if (bounded.size < deduped.size) {
            onProgress?.invoke(
                "Swarm capped at $MaxConcurrentAgents concurrent agents " +
                    "(${deduped.size} requested; ${deduped.size - bounded.size} dropped).",
            )
        }

        val runner = runner
            ?: return@coroutineScope failure("TOOL_UNAVAILABLE", "The agent runtime is not available.")
        val settings = settingsRepository.settings.first()
        val providerConfigs = settingsRepository.providerConfigs.first()
        val resolved = resolveModelSettings(
            baseSettings = settings,
            providerConfigs = providerConfigs,
            preferredModelKey = settings.defaultChatModelKey,
            fallbackModelKey = settings.defaultChatModelKey,
        )
        val workspaceDirectory = runtimeRouter.runtimeWorkspaceDirectory(settings = resolved)

        val swarmId = "swarm-${agentCounter.incrementAndGet()}"
        val boundedTimeout = timeoutMillis.coerceIn(30_000L, MaxAgentTimeoutMillis)
        val boundedToolBudget = maxToolCalls.coerceIn(5, MaxAgentToolBudget)
        onProgress?.invoke("Launching agent swarm (${bounded.joinToString { it.name }})…")

        val swarm = Swarm(
            id = swarmId,
            parentSessionId = parentSessionId,
            agents = bounded.map { spec ->
                SubAgentHandle(
                    agentId = "swarm-agent-${agentCounter.incrementAndGet()}-${spec.name}",
                    name = spec.name,
                    spec = spec,
                )
            },
            createdAtMillis = System.currentTimeMillis(),
        )
        swarms[swarmId] = swarm

        swarm.agents.forEach { handle ->
            val job = scope.launch {
                try {
                    runSubAgent(
                        runner = runner,
                        handle = handle,
                        swarm = swarm,
                        settings = resolved,
                        workspaceDirectory = workspaceDirectory,
                        timeoutMillis = boundedTimeout,
                        maxToolCalls = boundedToolBudget,
                        onProgress = onProgress,
                    )
                } finally {
                    if (swarm.agents.all { it.isTerminal }) {
                        swarm.completion.complete(Unit)
                        scope.launch {
                            delay(CompletedSwarmRetentionMillis)
                            swarms.remove(swarm.id, swarm)
                        }
                    }
                }
            }
            agentJobs[handle.agentId] = job
            job.invokeOnCompletion { agentJobs.remove(handle.agentId) }
        }

        val parentJob = coroutineContext[Job]
        parentJob?.invokeOnCompletion { cause ->
            if (cause != null) {
                swarm.parentCancelled = true
                swarm.stopRequested = true
                swarm.agents.forEach { handle ->
                    agentJobs[handle.agentId]?.cancel()
                }
            }
        }

        JSONObject()
            .put("ok", true)
            .put("swarm_id", swarmId)
            .put("agents", JSONArray(swarm.agents.map { handle ->
                JSONObject()
                    .put("name", handle.name)
                    .put("agent_id", handle.agentId)
                    .put("status", handle.status)
            }))
            .put(
                "hint",
                "Swarm launched. Poll progress with action=status (swarm_id='$swarmId'); " +
                    "retrieve results with action=collect (blocks until finished or timeout).",
            )
    }

    private val agentJobs = ConcurrentHashMap<String, Job>()

    fun status(swarmId: String?): JSONObject {
        val live = if (swarmId.isNullOrBlank()) swarms.values.toList() else listOfNotNull(swarms[swarmId])
        return JSONObject()
            .put("ok", true)
            .put("swarms", JSONArray(live.map { swarm ->
                JSONObject()
                    .put("id", swarm.id)
                    .put("stop_requested", swarm.stopRequested)
                    .put("elapsed_ms", System.currentTimeMillis() - swarm.createdAtMillis)
                    .put("agents", JSONArray(swarm.agents.map { agent ->
                        JSONObject()
                            .put("name", agent.name)
                            .put("agent_id", agent.agentId)
                            .put("status", agent.status)
                            .put("tool_calls", agent.toolCalls)
                            .apply {
                                if (agent.resultText.isNotBlank()) {
                                    put("result_preview", agent.resultText.take(200))
                                }
                            }
                    }))
            }))
    }

    suspend fun collect(
        swarmId: String,
        timeoutMillis: Long = DefaultCollectTimeoutMillis,
    ): JSONObject {
        val swarm = swarms[swarmId]
            ?: return failure("SWARM_NOT_FOUND", "No live swarm '$swarmId'.")
        val boundedTimeout = timeoutMillis.coerceIn(1_000L, MaxAgentTimeoutMillis)
        if (!swarm.completion.isCompleted) {
            withTimeoutOrNull(boundedTimeout) {
                swarm.completion.await()
            }
        }
        val finished = swarm.agents.filter { it.isTerminal }
        val allDone = finished.size == swarm.agents.size
        val payload = JSONObject()
            .put("ok", true)
            .put("swarm_id", swarm.id)
            .put("completed", finished.size)
            .put("total", swarm.agents.size)
            .put(
                "result",
                swarmResultText(
                    finished.map { handle ->
                        SubAgentResult(
                            name = handle.name,
                            agentId = handle.agentId,
                            outcome = handle.status,
                            text = handle.resultText.ifBlank {
                                "The sub-agent produced no output."
                            },
                            toolCalls = handle.toolCalls,
                        )
                    },
                ),
            )
            .put("agents", JSONArray(finished.map { handle ->
                resultJson(
                    SubAgentResult(
                        name = handle.name,
                        agentId = handle.agentId,
                        outcome = handle.status,
                        text = handle.resultText,
                        toolCalls = handle.toolCalls,
                    ),
                )
            }))
        if (!allDone) {
            payload.put(
                "hint",
                "${swarm.agents.size - finished.size} agent(s) still running — " +
                    "call collect again with a longer timeout to wait, or status for progress.",
            )
        } else {
            swarm.collected = true
            swarms.remove(swarm.id)
        }
        return payload
    }

    suspend fun stop(swarmId: String): JSONObject {
        val swarm = swarms[swarmId]
            ?: return failure("SWARM_NOT_FOUND", "No live swarm '$swarmId'.")
        swarm.stopRequested = true
        swarm.agents
            .filter { !it.isTerminal }
            .forEach { handle ->
                handle.status = "cancelled"
                agentJobs[handle.agentId]?.cancel()
            }
        withTimeoutOrNull(2_000L) { swarm.completion.await() }
        val finished = swarm.agents.filter { it.isTerminal }
        if (swarm.agents.all { it.isTerminal }) {
            swarms.remove(swarm.id)
        }
        return JSONObject()
            .put("ok", true)
            .put("swarm_id", swarm.id)
            .put("stopped", true)
            .put("completed", finished.size)
            .put("total", swarm.agents.size)
    }

    fun stopForSession(sessionId: String) {
        if (sessionId.isBlank()) return
        swarms.values
            .filter { it.parentSessionId == sessionId }
            .forEach { swarm ->
                swarm.parentCancelled = true
                swarm.stopRequested = true
                swarm.agents
                    .filter { !it.isTerminal }
                    .forEach { handle ->
                        handle.status = "cancelled"
                        agentJobs[handle.agentId]?.cancel()
                    }
                swarms.remove(swarm.id, swarm)
            }
    }

    suspend fun runMicroAgent(
        parentSessionId: String,
        spec: SubAgentSpec,
        timeoutMillis: Long = MicroAgentTimeoutMillis,
        maxToolCalls: Int = MicroAgentToolBudget,
        onProgress: (suspend (String) -> Unit)?,
    ): JSONObject {
        val spawned = spawn(
            parentSessionId = parentSessionId,
            agents = listOf(spec),
            timeoutMillis = timeoutMillis,
            maxToolCalls = maxToolCalls,
            onProgress = onProgress,
        )
        if (!spawned.optBoolean("ok")) return spawned
        val swarmId = spawned.optString("swarm_id")
        if (swarmId.isBlank()) return spawned
        val collected = collect(
            swarmId = swarmId,
            timeoutMillis = timeoutMillis + 10_000L,
        )
        return collected.put("micro_agent", true)
    }

    private suspend fun runSubAgent(
        runner: PiAgentRunner,
        handle: SubAgentHandle,
        swarm: Swarm,
        settings: AppSettings,
        workspaceDirectory: String,
        timeoutMillis: Long,
        maxToolCalls: Int,
        onProgress: (suspend (String) -> Unit)?,
    ) {
        val task = buildString {
            append("You are \"").append(handle.name).append("\", a focused sub-agent of the Arix assistant.\n")
            append("Role: ").append(handle.spec.role).append('\n')
            append("\nTASK\n").append(handle.spec.prompt.trim()).append('\n')
            append(
                "\nWork autonomously with the tools available (browser research, web_search, " +
                    "fetch_url, device control, bash). When finished, reply with ONLY your " +
                    "final result: concise, factual, with source URLs when relevant. If you cannot " +
                    "complete the task, say exactly what blocked you.",
            )
        }
        val messages = listOf(
            LlmMessage(role = "user", contentParts = listOf(LlmTextPart(task))),
        )
        fun statusJson(label: String, detail: String, target: String = ""): String = JSONObject()
            .put("agent", handle.name)
            .put("swarm_id", swarm.id)
            .put("state", label)
            .put("detail", detail.take(300))
            .put("target", target)
            .put("tool_calls", handle.toolCalls)
            .toString()

        fun emitActivity(toolLabel: String, running: Boolean, status: String, detail: String, argumentsJson: String = "") {
            _subAgentActivity.tryEmit(
                ArixSubAgentActivity(
                    parentSessionId = swarm.parentSessionId,
                    swarmId = swarm.id,
                    agentId = handle.agentId,
                    agentName = handle.name,
                    toolName = toolLabel,
                    argumentsJson = argumentsJson,
                    outputJson = status,
                    isRunning = running,
                )
            )
        }
        try {
            onProgress?.invoke("${handle.name}: started")
            emitActivity("starting", true, statusJson("starting", "Sub-agent launched."), "")
            val result = kotlinx.coroutines.withTimeout(timeoutMillis) {
                runner.runTurn(
                    settings = settings,
                    messages = messages,
                    workspaceDirectory = workspaceDirectory,
                    sessionId = handle.agentId,
                    sessionFile = "",
                    allowSwarmTool = false,
                    onToolEvent = { event ->
                        handle.toolCalls += 1
                        onProgress?.invoke("${handle.name}: ${event.name}")
                        emitActivity(
                            toolLabel = event.name,
                            running = true,
                            status = statusJson(
                                "working",
                                "Running ${event.name} (call #${handle.toolCalls}).",
                                com.arix.app.ui.workTargetOf(event.argumentsJson),
                            ),
                            detail = "",
                            argumentsJson = event.argumentsJson,
                        )
                        if (handle.toolCalls > maxToolCalls) {
                            handle.status = "budget_exceeded"
                            agentJobs[handle.agentId]?.cancel()
                        }
                    },
                )
            }
            val text = result.getOrNull()?.assistantText?.trim().orEmpty()
            handle.resultText = text
            handle.status = if (result.isSuccess && text.isNotBlank()) "completed" else "failed"
            onProgress?.invoke("${handle.name}: ${handle.status}")
            emitActivity(
                toolLabel = "finished",
                running = false,
                status = statusJson(
                    handle.status,
                    text.ifBlank { "The sub-agent produced no output." },
                ),
                detail = "",
            )
        } catch (error: kotlinx.coroutines.CancellationException) {
            handle.status = when {
                handle.status == "budget_exceeded" -> "budget_exceeded"
                else -> "cancelled"
            }
            emitActivity(
                toolLabel = "stopped",
                running = false,
                status = statusJson(handle.status, "Sub-agent stopped before finishing."),
                detail = "",
            )
        } catch (error: Throwable) {
            handle.status = "failed"
            diagnosticLogger.exception(
                category = "swarm",
                event = "subagent_failed",
                throwable = error,
            )
            handle.resultText = "Sub-agent failed: ${error.message ?: "unknown error"}"
            emitActivity(
                toolLabel = "failed",
                running = false,
                status = statusJson("failed", handle.resultText),
                detail = "",
            )
        }
    }

    private fun resultJson(result: SubAgentResult): JSONObject = JSONObject()
        .put("name", result.name)
        .put("agent_id", result.agentId)
        .put("outcome", result.outcome)
        .put("tool_calls", result.toolCalls)
        .put("result", result.text.take(800))

    private fun swarmResultText(results: List<SubAgentResult>): String = buildString {
        append("<agent_swarm_result>\n")
        append("<summary>")
        append(
            results.joinToString("; ") { result ->
                "${result.name}: ${result.outcome}" +
                    result.text.take(160).replace('\n', ' ').let { text ->
                        if (text.isNotBlank()) " — $text" else ""
                    }
            },
        )
        append("</summary>\n")
        results.forEach { result ->
            append("<subagent outcome=\"").append(result.outcome)
            append("\" name=\"").append(result.name)
            append("\" agent_id=\"").append(result.agentId)
            append("\">\n").append(result.text.take(1200)).append("\n</subagent>\n")
        }
        append("</agent_swarm_result>")
    }

    private fun failure(code: String, message: String): JSONObject = JSONObject()
        .put("ok", false)
        .put("code", code)
        .put("message", message)

    private companion object {
        const val MaxConcurrentAgents = 4

        const val DefaultAgentTimeoutMillis = 300_000L

        const val MaxAgentTimeoutMillis = 600_000L

        const val DefaultAgentToolBudget = 40

        const val MaxAgentToolBudget = 80

        const val DefaultCollectTimeoutMillis = 120_000L

        const val CompletedSwarmRetentionMillis = 10 * 60_000L

        const val MicroAgentTimeoutMillis = 180_000L

        const val MicroAgentToolBudget = 12
    }
}
