package com.arix.app.data.pi

import com.arix.app.data.ArixDiagnosticLogger
import com.arix.app.data.ArixExtensionLoadOptions
import com.arix.app.data.DiagnosticRedactor
import com.arix.app.runtime.TermuxRuntime
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import org.json.JSONObject
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

private const val PiBridgeAssetPath = "pi-bridge/bridge.mjs"
private const val PiBridgeGuestPath = "/root/.arix/pi-bridge/bridge.mjs"
private const val PiBridgeWorkingDirectory = "/root/.arix/pi-bridge"
private const val PiBridgeNodeMinVersion = "22.19.0"
private const val PiBridgeVersion = "2.0.0-alpha.0"
private const val PiAiVersion = "0.99.2"
private const val PiAgentCoreVersion = "0.99.2"
private const val PiCodingAgentVersion = "0.99.2"
private const val PiBridgeWorkerAssetPath = "pi-bridge/image-resize-worker.js"
private const val PiBridgeWorkerGuestPath = "/root/.arix/pi-bridge/image-resize-worker.js"
private const val PiBridgeWasmAssetPath = "pi-bridge/photon_rs_bg.wasm"
private const val PiBridgeWasmGuestPath = "/root/.arix/pi-bridge/photon_rs_bg.wasm"
private const val PiBridgeNodeCompileCacheDir = "/root/.arix/pi-bridge/node-compile-cache"
private const val PiBridgeRequestTimeoutMillis = 10 * 60 * 1000L
private const val PiBridgeOAuthTimeoutMillis = 15 * 60 * 1000L
private const val PiBridgePingTimeoutMillis = 15_000L

private const val PiBridgeWatchdogIntervalMillis = 15_000L

private const val PiBridgeNoFrameTimeoutMillis = 3 * 60 * 1000L

private const val PiBridgeAgentIdleFallbackTimeoutMillis = 6 * 60 * 1000L
private const val CancelledRequestRetentionMillis = 5 * 60 * 1000L

internal const val PiBridgeErrorCodeTermuxNotReady = "xt0"

internal const val PiBridgeErrorCodeNodeInstallFailed = "xt1"

private val PiBridgeSetupInfrastructureErrorCodes = setOf(
    PiBridgeErrorCodeTermuxNotReady,
    PiBridgeErrorCodeNodeInstallFailed,
    "node_version_too_old",
    "pi_search_tools_install_failed",
    "bootstrap_download_failed",
)

internal fun isSetupInfrastructureError(throwable: Throwable): Boolean =
    throwable is PiBridgeException && throwable.code in PiBridgeSetupInfrastructureErrorCodes

internal fun piBridgeSetupErrorResponse(throwable: PiBridgeException): JSONObject = JSONObject()
    .put("ok", false)
    .put("error_code", throwable.code)
    .put("error", throwable.message.orEmpty())
    .put("message", throwable.message.orEmpty())
    .put("setup_required", true)

internal fun throwIfPiBridgeSetupError(response: JSONObject) {
    if (response.optBoolean("setup_required", false) && !response.optBoolean("ok", true)) {
        throw PiBridgeException(
            message = response.optString("error")
                .ifBlank { "The Termux environment is not installed yet." },
            code = response.optString("error_code").ifBlank { PiBridgeErrorCodeTermuxNotReady },
        )
    }
}

private data class PendingPiBridgeRequest(
    val response: CompletableDeferred<PiBridgeFrame>,
    val processGeneration: Long,
    val eventChannel: Channel<PiBridgeFrame>? = null,
    val eventJob: Job? = null,
    @Volatile var lastFrameAtMillis: Long = System.currentTimeMillis(),
    @Volatile var lastAgentActivityAtMillis: Long = 0L,
    @Volatile var activeToolCount: Int = 0,
    @Volatile var streaming: Boolean = false,
    @Volatile var compacting: Boolean = false,
    var inactivityTimeoutMillis: Long = 0L,
    var agentIdleTimeoutMillis: Long = 0L,
    var watchdogJob: Job? = null,
)

private data class ActivePiBridgeProcess(
    val process: Process,
    val writer: BufferedWriter,
    val generation: Long,
    private val firstRequestPending: AtomicBoolean = AtomicBoolean(true),
) {
    fun claimFirstRequest(): Boolean = firstRequestPending.compareAndSet(true, false)
}

class PiKernelBridge(
    private val termuxRuntime: TermuxRuntime,
    private val diagnosticLogger: ArixDiagnosticLogger = ArixDiagnosticLogger.NoOp,
) {
    private val mutex = Mutex()
    private val pendingRequests = ConcurrentHashMap<String, PendingPiBridgeRequest>()
    private val cancelledRequestIds = ConcurrentHashMap<String, Long>()
    private val eventScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val processStateLock = Any()
    private val nextProcessGeneration = AtomicLong(0L)
    @Volatile
    private var activeProcess: ActivePiBridgeProcess? = null

    fun isProcessAlive(): Boolean = synchronized(processStateLock) {
        activeProcess?.process?.isAlive ?: false
    }

    private val acpPending = ConcurrentHashMap<String, CompletableDeferred<JSONObject>>()
    private val acpInbound = MutableSharedFlow<JSONObject>(extraBufferCapacity = 64)

    val acpEvents: SharedFlow<JSONObject> = acpInbound.asSharedFlow()

    private val acpIdCounter = AtomicLong(0L)

    suspend fun acpRequest(
        method: String,
        params: JSONObject = JSONObject(),
        timeoutMillis: Long = 60_000L,
        onSetupProgress: (PiCoreSetupUpdate) -> Unit = {},
    ): JSONObject = withContext(Dispatchers.IO) {
        val id = "acp-${acpIdCounter.incrementAndGet()}"
        val deferred = CompletableDeferred<JSONObject>()
        acpPending[id] = deferred
        try {
            val process = ensureStartedLocked(onSetupProgress)
            val frame = JSONObject()
                .put("jsonrpc", "2.0")
                .put("id", id)
                .put("method", method)
                .put("params", params)
            synchronized(process.writer) {
                process.writer.write(frame.toString())
                process.writer.write("\n")
                process.writer.flush()
            }
            withTimeout(timeoutMillis) { deferred.await() }
        } catch (error: Throwable) {
            acpPending.remove(id)
            throw error
        } finally {
            acpPending.remove(id)
        }
    }

    suspend fun acpRespond(
        requestId: Any,
        result: JSONObject,
        onSetupProgress: (PiCoreSetupUpdate) -> Unit = {},
    ) = withContext(Dispatchers.IO) {
        val process = ensureStartedLocked(onSetupProgress)
        val frame = JSONObject()
            .put("jsonrpc", "2.0")
            .put("id", requestId)
            .put("result", result)
        synchronized(process.writer) {
            process.writer.write(frame.toString())
            process.writer.write("\n")
            process.writer.flush()
        }
    }

    private fun handleAcpLineFromReader(line: String, processGeneration: Long) {
        val frame = runCatching { JSONObject(line) }.getOrNull() ?: return
        val id = frame.opt("id")
        val hasMethod = frame.has("method")
        if (hasMethod) {
            acpInbound.tryEmit(frame)
            return
        }
        if (id != null) {
            val key = id.toString()
            acpPending.remove(key)?.let { pending ->
                pending.complete(frame)
            }
        }
    }

    suspend fun ping(
        onSetupProgress: (PiCoreSetupUpdate) -> Unit = {},
    ): JSONObject =
        request(
            type = "ping",
            timeoutMillis = PiBridgePingTimeoutMillis,
            onSetupProgress = onSetupProgress,
        )

    suspend fun listProviders(startIfNeeded: Boolean = true): JSONObject =
        request(
            type = "list_providers",
            timeoutMillis = PiBridgePingTimeoutMillis,
            startIfNeeded = startIfNeeded,
        )

    suspend fun loginProvider(
        providerConfigId: String,
        providerId: String,
        authMethod: String,
        oauthFlow: String = "",
        onEvent: suspend (String, JSONObject) -> Unit,
    ): JSONObject =
        request(
            type = "login_provider",
            payload = JSONObject()
                .put("provider_config_id", providerConfigId)
                .put("provider_id", providerId)
                .put("auth_method", authMethod)
                .put("oauth_flow", oauthFlow),
            timeoutMillis = PiBridgeOAuthTimeoutMillis,
            onEvent = onEvent,
            abortOnCancellation = true,
        )

    suspend fun clearProviderCredential(providerConfigId: String): JSONObject =
        request(
            type = "clear_provider_credential",
            payload = JSONObject().put("provider_config_id", providerConfigId),
            timeoutMillis = PiBridgePingTimeoutMillis,
            startIfNeeded = false,
        )

    suspend fun submitAuthPrompt(
        promptId: String,
        value: String,
        cancelled: Boolean = false,
    ): JSONObject =
        request(
            type = "auth_prompt_result",
            payload = JSONObject()
                .put("prompt_id", promptId)
                .put("value", value)
                .put("cancelled", cancelled),
            timeoutMillis = PiBridgePingTimeoutMillis,
            abortOnCancellation = false,
        )

    suspend fun completeOnce(
        payload: JSONObject,
        onEvent: (suspend (String, JSONObject) -> Unit)? = null,
    ): JSONObject =
        request(
            type = "complete_once",
            payload = payload,
            timeoutMillis = PiBridgeRequestTimeoutMillis,
            onEvent = onEvent,
        )

    suspend fun runTurn(
        payload: JSONObject,
        onEvent: suspend (String, JSONObject) -> Unit,
        onSetupProgress: (PiCoreSetupUpdate) -> Unit = {},
    ): JSONObject =
        request(
            type = "run_turn",
            payload = payload,
            timeoutMillis = null,
            onEvent = onEvent,
            onSetupProgress = onSetupProgress,
            inactivityTimeoutMillis = PiBridgeNoFrameTimeoutMillis,
            agentIdleTimeoutMillis = agentIdleTimeoutMillisFor(payload),
        )

    suspend fun steer(
        sessionId: String,
        message: JSONObject,
    ): JSONObject =
        request(
            type = "steer",
            payload = JSONObject()
                .put("session_id", sessionId)
                .put("message", message),
            timeoutMillis = PiBridgePingTimeoutMillis,
        )

    suspend fun followUp(
        sessionId: String,
        message: JSONObject,
        onEvent: suspend (String, JSONObject) -> Unit,
    ): JSONObject =
        request(
            type = "follow_up",
            payload = JSONObject()
                .put("session_id", sessionId)
                .put("message", message),
            timeoutMillis = null,
            onEvent = onEvent,
            inactivityTimeoutMillis = PiBridgeNoFrameTimeoutMillis,
            agentIdleTimeoutMillis = PiBridgeAgentIdleFallbackTimeoutMillis,
        )

    suspend fun getSessionState(sessionId: String): JSONObject =
        request(
            type = "get_session_state",
            payload = JSONObject().put("session_id", sessionId),
            timeoutMillis = PiBridgePingTimeoutMillis,
            abortOnCancellation = false,
        )

    suspend fun compactSession(
        sessionId: String,
        customInstructions: String = "",
        sessionPayload: JSONObject = JSONObject(),
    ): JSONObject = request(
        type = "compact_session",
        payload = JSONObject(sessionPayload.toString()).apply {
            put("session_id", sessionId)
            if (customInstructions.isNotBlank()) put("custom_instructions", customInstructions)
        },
        timeoutMillis = null,
        abortOnCancellation = false,
        inactivityTimeoutMillis = PiBridgeNoFrameTimeoutMillis,
    )

    suspend fun navigateSession(
        sessionId: String,
        entryId: String,
        reset: Boolean = false,
        summarize: Boolean = false,
        customInstructions: String = "",
        sessionPayload: JSONObject = JSONObject(),
    ): JSONObject = request(
        type = "navigate_session",
        payload = JSONObject(sessionPayload.toString()).apply {
            put("session_id", sessionId)
            put("entry_id", entryId)
            put("reset", reset)
            put("summarize", summarize)
            if (customInstructions.isNotBlank()) put("custom_instructions", customInstructions)
        },
        timeoutMillis = null,
        abortOnCancellation = false,
        inactivityTimeoutMillis = PiBridgeNoFrameTimeoutMillis,
    )

    suspend fun reloadSession(sessionId: String): JSONObject = request(
        type = "reload_session",
        payload = JSONObject().put("session_id", sessionId),
        timeoutMillis = PiBridgePingTimeoutMillis,
        abortOnCancellation = false,
    )

    suspend fun exportSessionJsonl(sessionId: String): JSONObject = request(
        type = "export_session_jsonl",
        payload = JSONObject().put("session_id", sessionId),
        timeoutMillis = PiBridgePingTimeoutMillis,
        abortOnCancellation = false,
    )

    suspend fun importSessionJsonl(sessionId: String, jsonl: String): JSONObject = request(
        type = "import_session_jsonl",
        payload = JSONObject().put("session_id", sessionId).put("jsonl", jsonl),
        timeoutMillis = PiBridgePingTimeoutMillis,
        abortOnCancellation = false,
    )

    suspend fun closeSession(
        sessionId: String,
        sessionFile: String = "",
        deleteFile: Boolean = false,
    ): JSONObject =
        request(
            type = "close_session",
            payload = JSONObject()
                .put("session_id", sessionId)
                .put("session_file", sessionFile)
                .put("delete_file", deleteFile),
            timeoutMillis = PiBridgePingTimeoutMillis,
            abortOnCancellation = false,
            startIfNeeded = deleteFile,
        )

    suspend fun listDiscoveredSkills(
        workspaceDirectory: String = termuxRuntime.workspaceRoot,
    ): JSONObject = request(
        type = "list_discovered_skills",
        payload = JSONObject()
            .put("workspace_directory", workspaceDirectory)
            .put("workspace_trusted", true),
        timeoutMillis = PiBridgeRequestTimeoutMillis,
        abortOnCancellation = false,
    )

    // ------------------------------------------------------------------ //
    // v3.1.14 — Arix Script Extensions (ported from Aether).            //
    // ------------------------------------------------------------------ //

    suspend fun listExtensionPackages(): JSONObject =
        request(
            type = "list_extension_packages",
            timeoutMillis = PiBridgeRequestTimeoutMillis,
            abortOnCancellation = false,
        )

    suspend fun installExtensionPackage(
        source: String,
        loadOptions: ArixExtensionLoadOptions = ArixExtensionLoadOptions(),
        onProgress: suspend (String) -> Unit = {},
    ): JSONObject =
        request(
            type = "install_extension_package",
            payload = extensionLoadOptionsPayload(loadOptions).put("source", source),
            timeoutMillis = PiBridgeRequestTimeoutMillis,
            abortOnCancellation = false,
            onEvent = { event, payload ->
                if (event == "extension_package_progress") onProgress(payload.optString("phase"))
            },
        )

    suspend fun removeExtensionPackage(
        source: String,
        loadOptions: ArixExtensionLoadOptions = ArixExtensionLoadOptions(),
    ): JSONObject =
        request(
            type = "remove_extension_package",
            payload = extensionLoadOptionsPayload(loadOptions).put("source", source),
            timeoutMillis = PiBridgeRequestTimeoutMillis,
            abortOnCancellation = false,
        )

    suspend fun updateExtensionPackage(
        source: String,
        loadOptions: ArixExtensionLoadOptions = ArixExtensionLoadOptions(),
        onProgress: suspend (String) -> Unit = {},
    ): JSONObject =
        request(
            type = "update_extension_package",
            payload = extensionLoadOptionsPayload(loadOptions).put("source", source),
            timeoutMillis = PiBridgeRequestTimeoutMillis,
            abortOnCancellation = false,
            onEvent = { event, payload ->
                if (event == "extension_package_progress") onProgress(payload.optString("phase"))
            },
        )

    suspend fun reloadAllExtensions(
        loadOptions: ArixExtensionLoadOptions = ArixExtensionLoadOptions(),
    ): JSONObject =
        request(
            type = "reload_all_extensions",
            payload = extensionLoadOptionsPayload(loadOptions),
            timeoutMillis = PiBridgeRequestTimeoutMillis,
            abortOnCancellation = false,
        )

    suspend fun reloadArixExtensions(
        context: JSONObject,
        loadOptions: ArixExtensionLoadOptions = ArixExtensionLoadOptions(),
        onEvent: suspend (String, JSONObject) -> Unit,
    ): JSONObject =
        request(
            type = "reload_arix_extensions",
            payload = extensionLoadOptionsPayload(loadOptions).put("context", context),
            timeoutMillis = PiBridgeRequestTimeoutMillis,
            onEvent = onEvent,
            abortOnCancellation = false,
        )

    suspend fun getArixExtensions(
        context: JSONObject,
        loadOptions: ArixExtensionLoadOptions = ArixExtensionLoadOptions(),
        onEvent: suspend (String, JSONObject) -> Unit,
    ): JSONObject =
        request(
            type = "get_arix_extensions",
            payload = extensionLoadOptionsPayload(loadOptions).put("context", context),
            timeoutMillis = PiBridgeRequestTimeoutMillis,
            onEvent = onEvent,
            abortOnCancellation = false,
        )

    suspend fun invokeArixExtensionAction(
        extensionId: String,
        action: String,
        args: JSONObject,
        context: JSONObject,
        onEvent: suspend (String, JSONObject) -> Unit,
    ): JSONObject =
        request(
            type = "invoke_arix_extension_action",
            payload = JSONObject()
                .put("extension_id", extensionId)
                .put("action", action)
                .put("args", args)
                .put("context", context),
            timeoutMillis = PiBridgeRequestTimeoutMillis,
            onEvent = onEvent,
            abortOnCancellation = false,
        )

    suspend fun dispatchArixExtensionEvent(
        event: String,
        data: JSONObject,
        context: JSONObject,
        onEvent: suspend (String, JSONObject) -> Unit,
    ): JSONObject =
        request(
            type = "dispatch_arix_extension_event",
            payload = JSONObject()
                .put("event", event)
                .put("data", data)
                .put("context", context),
            timeoutMillis = PiBridgeRequestTimeoutMillis,
            onEvent = onEvent,
            abortOnCancellation = false,
        )

    suspend fun subscribeArixExtensions(
        onEvent: suspend (String, JSONObject) -> Unit,
    ) {
        request(
            type = "subscribe_arix_extensions",
            timeoutMillis = null,
            onEvent = onEvent,
            abortOnCancellation = false,
        )
    }

    suspend fun sendArixHostResult(
        callId: String,
        result: JSONObject = JSONObject(),
        error: String = "",
    ): JSONObject =
        request(
            type = "arix_host_result",
            payload = JSONObject()
                .put("call_id", callId)
                .put("ok", error.isBlank())
                .put("result", result)
                .put("error", error),
            timeoutMillis = PiBridgePingTimeoutMillis,
            abortOnCancellation = false,
        )

    private fun extensionLoadOptionsPayload(
        loadOptions: ArixExtensionLoadOptions,
    ): JSONObject = JSONObject().apply {
        put("disabled_extension_paths", org.json.JSONArray(loadOptions.disabledExtensionPaths.toList()))
        put("disabled_package_sources", org.json.JSONArray(loadOptions.disabledPackageSources.toList()))
    }

    suspend fun sendHostToolResult(payload: JSONObject) {
        request(
            type = "host_tool_result",
            payload = payload,
            timeoutMillis = PiBridgePingTimeoutMillis,
            abortOnCancellation = false,
        )
    }

    suspend fun sendHostToolProgress(payload: JSONObject) {
        request(
            type = "host_tool_progress",
            payload = payload,
            timeoutMillis = PiBridgePingTimeoutMillis,
            abortOnCancellation = false,
        )
    }

    suspend fun sendRuntimeOperationChunk(payload: JSONObject) {
        request(
            type = "runtime_op_chunk",
            payload = payload,
            timeoutMillis = PiBridgePingTimeoutMillis,
            abortOnCancellation = false,
        )
    }

    suspend fun sendRuntimeOperationResult(payload: JSONObject) {
        request(
            type = "runtime_op_result",
            payload = payload,
            timeoutMillis = PiBridgePingTimeoutMillis,
            abortOnCancellation = false,
        )
    }

    suspend fun sendRuntimeOperationCancel(payload: JSONObject) {
        request(
            type = "runtime_op_cancel",
            payload = payload,
            timeoutMillis = PiBridgePingTimeoutMillis,
            abortOnCancellation = false,
        )
    }

    suspend fun stop() = withContext(Dispatchers.IO) {
        mutex.withLock {
            eventScope.coroutineContext.cancelChildren()
            pendingRequests.values.forEach { pending ->
                pending.response.completeExceptionally(PiBridgeException("Pi bridge stopped."))
                pending.eventChannel?.close()
            }
            pendingRequests.clear()
            cancelledRequestIds.clear()
            val stoppedProcess = synchronized(processStateLock) {
                activeProcess.also { activeProcess = null }
            }
            runCatching { stoppedProcess?.writer?.close() }
            runCatching { stoppedProcess?.process?.destroy() }
        }
    }

    private suspend fun request(
        type: String,
        payload: JSONObject = JSONObject(),
        timeoutMillis: Long?,
        onEvent: (suspend (String, JSONObject) -> Unit)? = null,
        abortOnCancellation: Boolean = type == "run_turn" || type == "complete_once" || type == "follow_up",
        onSetupProgress: (PiCoreSetupUpdate) -> Unit = {},
        startIfNeeded: Boolean = true,
        inactivityTimeoutMillis: Long = 0L,
        agentIdleTimeoutMillis: Long = 0L,
    ): JSONObject = withContext(Dispatchers.IO) {
        val id = nextRequestId(type)
        diagnosticLogger.event(
            category = "pi_bridge",
            event = "request_queued",
            requestId = id,
            details = requestDiagnosticDetails(type, payload) + mapOf(
                "timeout_millis" to timeoutMillis,
                "start_if_needed" to startIfNeeded,
            ),
        )
        val response = CompletableDeferred<PiBridgeFrame>()
        val eventChannel = onEvent?.let { Channel<PiBridgeFrame>(Channel.UNLIMITED) }
        val eventJob = if (onEvent != null && eventChannel != null) {
            eventScope.launch {
                for (frame in eventChannel) {
                    if (frame.type == "event") {
                        try {
                            onEvent(frame.event, frame.payload)
                        } catch (throwable: Throwable) {
                            if (throwable is CancellationException) throw throwable
                            diagnosticLogger.exception(
                                category = "pi_bridge",
                                event = "event_handler_failed",
                                throwable = throwable,
                                details = mapOf(
                                    "request_id" to frame.id,
                                    "event" to frame.event,
                                ),
                            )
                            response.completeExceptionally(throwable)
                            break
                        }
                    } else {
                        response.complete(frame)
                        break
                    }
                }
            }
        } else {
            null
        }
        val diagnosticDetails = requestDiagnosticDetails(type, payload)
        try {
            diagnosticLogger.event(
                category = "pi_bridge",
                event = "request_start",
                requestId = id,
                details = diagnosticDetails,
            )
            val requestProcess = if (startIfNeeded) {
                diagnosticLogger.event(
                    category = "pi_bridge",
                    event = "ensure_started_begin",
                    requestId = id,
                )
                val process = ensureStartedLocked(onSetupProgress)
                diagnosticLogger.event(
                    category = "pi_bridge",
                    event = "ensure_started_end",
                    requestId = id,
                    details = mapOf(
                        "process_generation" to process.generation,
                        "process_alive" to process.process.isAlive,
                    ),
                )
                process
            } else {
                currentLiveProcess() ?: return@withContext JSONObject().put("closed", false)
            }
            val pending = PendingPiBridgeRequest(
                response = response,
                processGeneration = requestProcess.generation,
                eventChannel = eventChannel,
                eventJob = eventJob,
                inactivityTimeoutMillis = inactivityTimeoutMillis,
                agentIdleTimeoutMillis = agentIdleTimeoutMillis,
            )
            pendingRequests[id] = pending
            if (requestProcess.claimFirstRequest()) {
                onSetupProgress(PiCoreSetupUpdate(PiCoreSetupPhase.VerifyingBridge))
            }
            val request = PiBridgeRequest(id = id, type = type, payload = payload)
            diagnosticLogger.event(
                category = "pi_bridge",
                event = "request_write_start",
                requestId = id,
                details = mapOf(
                    "process_generation" to requestProcess.generation,
                ),
            )
            synchronized(requestProcess.writer) {
                request.writeJsonLine(requestProcess.writer)
                requestProcess.writer.flush()
            }
            diagnosticLogger.event(
                category = "pi_bridge",
                event = "request_write_end",
                requestId = id,
            )
            pending.watchdogJob = if (inactivityTimeoutMillis > 0L) {
                startInactivityWatchdog(id, pending)
            } else {
                null
            }
            val frame = if (timeoutMillis == null) {
                diagnosticLogger.event(
                    category = "pi_bridge",
                    event = "request_await_start",
                    requestId = id,
                    details = mapOf("timeout" to "none"),
                )
                response.await()
            } else {
                diagnosticLogger.event(
                    category = "pi_bridge",
                    event = "request_await_start",
                    requestId = id,
                    details = mapOf("timeout_millis" to timeoutMillis),
                )
                withTimeout(timeoutMillis) { response.await() }
            }
            diagnosticLogger.event(
                category = "pi_bridge",
                event = "request_response_received",
                requestId = id,
                details = mapOf(
                    "frame_type" to frame.type,
                    "frame_ok" to frame.ok,
                ),
            )
            if (!frame.ok || frame.type == "error") {
                val error = frame.error
                throw PiBridgeException(
                    message = error?.message?.ifBlank { "Pi bridge request failed." }
                        ?: "Pi bridge request failed.",
                    code = error?.code?.ifBlank { "pi_bridge_error" } ?: "pi_bridge_error",
                )
            }
            diagnosticLogger.event(
                category = "pi_bridge",
                event = "request_end",
                requestId = id,
                details = diagnosticDetails + mapOf("frame_type" to frame.type),
            )
            frame.payload
        } catch (cancellationException: CancellationException) {
            diagnosticLogger.event(
                category = "pi_bridge",
                event = "request_cancelled",
                level = "warn",
                requestId = id,
                details = diagnosticDetails,
            )
            if (abortOnCancellation) {
                markRequestCancelled(id)
                withContext(NonCancellable) {
                    runCatching {
                        request(
                            type = "abort",
                            payload = JSONObject()
                                .put("request_id", id)
                                .put("session_id", payload.optString("session_id")),
                            timeoutMillis = PiBridgePingTimeoutMillis,
                            abortOnCancellation = false,
                            startIfNeeded = false,
                        )
                    }
                }
            }
            throw cancellationException
        } catch (throwable: Throwable) {
            diagnosticLogger.exception(
                category = "pi_bridge",
                event = "request_failed",
                throwable = throwable,
                requestId = id,
                details = diagnosticDetails,
            )
            if (isSetupInfrastructureError(throwable)) {
                return@withContext piBridgeSetupErrorResponse(throwable as PiBridgeException)
            }
            throw throwable
        } finally {
            pendingRequests.remove(id)?.watchdogJob?.let { job ->
                job.cancel()
            }
            eventChannel?.close()
            eventJob?.cancelAndJoin()
        }
    }

    private fun agentIdleTimeoutMillisFor(payload: JSONObject): Long {
        val providerTimeoutMillis = payload.optJSONObject("model_config")
            ?.optLong("timeout_ms", 0L) ?: 0L
        val base = if (providerTimeoutMillis > 0L) providerTimeoutMillis else 360_000L
        return (base + 90_000L).coerceAtLeast(PiBridgeAgentIdleFallbackTimeoutMillis)
    }

    private fun startInactivityWatchdog(
        requestId: String,
        pending: PendingPiBridgeRequest,
    ): Job = eventScope.launch {
        val noFrameTimeout = pending.inactivityTimeoutMillis
        val agentIdleTimeout = pending.agentIdleTimeoutMillis
        while (isActive) {
            delay(PiBridgeWatchdogIntervalMillis)
            if (!pendingRequests.containsKey(requestId)) return@launch
            val now = System.currentTimeMillis()
            val silentFor = now - pending.lastFrameAtMillis
            if (silentFor > noFrameTimeout) {
                failPendingWithBridgeException(
                    requestId = requestId,
                    code = "bridge_unresponsive",
                    message = "The agent engine stopped responding for " +
                        "${silentFor / 1000}s. The turn was cancelled. " +
                        "Check the Termux runtime status in Settings, then try again.",
                )
                return@launch
            }
            if (
                pending.streaming &&
                pending.activeToolCount == 0 &&
                !pending.compacting &&
                pending.lastAgentActivityAtMillis > 0L &&
                now - pending.lastAgentActivityAtMillis > agentIdleTimeout
            ) {
                failPendingWithBridgeException(
                    requestId = requestId,
                    code = "agent_request_stalled",
                    message = "The model request made no progress for " +
                        "${(now - pending.lastAgentActivityAtMillis) / 1000}s " +
                        "(provider or network stall). The turn was cancelled — " +
                        "check your provider connection and try again.",
                )
                return@launch
            }
        }
    }

    private fun failPendingWithBridgeException(
        requestId: String,
        code: String,
        message: String,
    ) {
        val pending = pendingRequests[requestId] ?: return
        if (!pendingRequests.remove(requestId, pending)) return
        diagnosticLogger.event(
            category = "pi_bridge",
            event = "inactivity_watchdog_triggered",
            level = "error",
            requestId = requestId,
            details = mapOf(
                "code" to code,
                "last_frame_age_ms" to (System.currentTimeMillis() - pending.lastFrameAtMillis),
            ),
        )
        pending.response.completeExceptionally(PiBridgeException(message, code = code))
        pending.watchdogJob?.cancel()
    }

    private suspend fun ensureStartedLocked(
        onSetupProgress: (PiCoreSetupUpdate) -> Unit = {},
    ): ActivePiBridgeProcess {
        mutex.withLock {
            diagnosticLogger.event(
                category = "pi_bridge",
                event = "ensure_started_locked_enter",
                details = mapOf(
                    "current_process_alive" to (currentLiveProcess() != null),
                ),
            )
            currentLiveProcess()?.let {
                diagnosticLogger.event(
                    category = "pi_bridge",
                    event = "ensure_started_locked_reuse",
                    details = mapOf("process_generation" to it.generation),
                )
                return it
            }
            val staleProcess = synchronized(processStateLock) {
                activeProcess.also { activeProcess = null }
            }
            runCatching { staleProcess?.writer?.close() }
            runCatching { staleProcess?.process?.destroy() }

            diagnosticLogger.event(
                category = "pi_bridge",
                event = "ensure_node_available_start",
            )
            ensureNodeAvailable(onSetupProgress)
            diagnosticLogger.event(
                category = "pi_bridge",
                event = "ensure_node_available_end",
            )
            onSetupProgress(PiCoreSetupUpdate(PiCoreSetupPhase.PreparingBridge))
            termuxRuntime.installAsset(
                assetPath = PiBridgeAssetPath,
                guestPath = PiBridgeGuestPath,
                executable = false,
                contentVersion = bridgeAssetContentVersion(),
            )
            termuxRuntime.installAsset(
                assetPath = PiBridgeWorkerAssetPath,
                guestPath = PiBridgeWorkerGuestPath,
                executable = false,
                contentVersion = bridgeAssetContentVersion(),
            )
            termuxRuntime.installAsset(
                assetPath = PiBridgeWasmAssetPath,
                guestPath = PiBridgeWasmGuestPath,
                executable = false,
                contentVersion = bridgeAssetContentVersion(),
            )
            onSetupProgress(PiCoreSetupUpdate(PiCoreSetupPhase.StartingBridge))
            diagnosticLogger.event(
                category = "pi_bridge",
                event = "start_managed_process_begin",
                details = mapOf(
                    "command" to "node ${shellQuote(PiBridgeGuestPath)}",
                    "working_directory" to PiBridgeWorkingDirectory,
                ),
            )
            val started = termuxRuntime.startManagedProcess(
                command = "node ${shellQuote(PiBridgeGuestPath)}",
                workingDirectory = PiBridgeWorkingDirectory,
                environment = mapOf("NODE_COMPILE_CACHE" to PiBridgeNodeCompileCacheDir),
            )
            diagnosticLogger.event(
                category = "pi_bridge",
                event = "start_managed_process_end",
                details = mapOf(
                    "process_alive" to started.isAlive,
                ),
            )
            val startedProcess = ActivePiBridgeProcess(
                process = started,
                writer = BufferedWriter(OutputStreamWriter(started.outputStream, Charsets.UTF_8)),
                generation = nextProcessGeneration.incrementAndGet(),
            )
            synchronized(processStateLock) {
                activeProcess = startedProcess
            }
            startStdoutReader(startedProcess)
            startStderrReader(startedProcess)
            diagnosticLogger.event(
                category = "pi_bridge",
                event = "process_started",
                details = mapOf(
                    "guest_path" to PiBridgeGuestPath,
                    "bridge_version" to PiBridgeVersion,
                    "pi_ai_version" to PiAiVersion,
                    "pi_agent_core_version" to PiAgentCoreVersion,
                    "pi_coding_agent_version" to PiCodingAgentVersion,
                    "node_version" to (readNodeVersionCached() ?: "unknown"),
                    "process_generation" to startedProcess.generation,
                ),
            )
            return startedProcess
        }
    }

    private fun bridgeAssetContentVersion(): String {
        val appVersion = runCatching {
            termuxRuntime.appVersionName()
        }.getOrNull() ?: "?"
        return "arix-bridge-$PiBridgeVersion-$appVersion"
    }

    private fun currentLiveProcess(): ActivePiBridgeProcess? =
        synchronized(processStateLock) {
            activeProcess?.takeIf { it.process.isAlive }
        }

    private suspend fun ensureNodeAvailable(
        onSetupProgress: (PiCoreSetupUpdate) -> Unit,
    ) {
        onSetupProgress(PiCoreSetupUpdate(PiCoreSetupPhase.CheckingTermux))
        var setup = termuxRuntime.inspectSetup()
        diagnosticLogger.event(
            category = "pi_bridge",
            event = "termux_setup_inspected",
            details = mapOf(
                "is_ready" to setup.isReady,
                "detail" to setup.detail,
            ),
        )
        if (!setup.isReady) {
            diagnosticLogger.event(
                category = "pi_bridge",
                event = "termux_selfheal_start",
                level = "warn",
                details = mapOf(
                    "issue" to setup.issue.name,
                    "detail" to setup.detail,
                ),
            )
            val repaired = runCatching {
                termuxRuntime.initializeForAutomaticSelfHeal()
            }.onFailure { throwable ->
                diagnosticLogger.exception(
                    category = "pi_bridge",
                    event = "termux_selfheal_failed",
                    throwable = throwable,
                )
            }.isSuccess
            setup = termuxRuntime.inspectSetup()
            diagnosticLogger.event(
                category = "pi_bridge",
                event = "termux_selfheal_finished",
                level = if (setup.isReady) "info" else "error",
                details = mapOf(
                    "repair_attempted" to repaired,
                    "is_ready" to setup.isReady,
                    "detail" to setup.detail,
                ),
            )
            if (!setup.isReady) {
                throw PiBridgeException(
                    setup.detail.ifBlank {
                        "Initialize Termux before starting the agent runtime."
                    },
                    code = PiBridgeErrorCodeTermuxNotReady,
                )
            }
        }
        onSetupProgress(PiCoreSetupUpdate(PiCoreSetupPhase.CheckingNode))
        val version = readNodeVersionCached()
        diagnosticLogger.event(
            category = "pi_bridge",
            event = "node_version_checked",
            details = mapOf(
                "version" to version.orEmpty(),
                "min_version" to PiBridgeNodeMinVersion,
            ),
        )
        if (version == null || compareSemver(version, PiBridgeNodeMinVersion) < 0) {
            onSetupProgress(PiCoreSetupUpdate(PiCoreSetupPhase.InstallingNode))
            diagnosticLogger.event(
                category = "pi_bridge",
                event = "node_package_install_start",
                level = "warn",
                details = mapOf(
                    "current_version" to version.orEmpty(),
                    "required_version" to PiBridgeNodeMinVersion,
                ),
            )
            val nodeError = termuxRuntime.ensureNodeRuntime(
                onProgress = { progress ->
                    onSetupProgress(
                        PiCoreSetupUpdate(
                            phase = PiCoreSetupPhase.InstallingNode,
                            activity = PiCoreSetupActivity.Downloading,
                            bytesPerSecond = progress.bytesPerSecond,
                            output = progress.output,
                        )
                    )
                },
            )
            if (nodeError != null) {
                throw PiBridgeException(
                    nodeError,
                    code = PiBridgeErrorCodeNodeInstallFailed,
                )
            }
            val installedVersion = readNodeVersion()
            if (installedVersion == null || compareSemver(installedVersion, PiBridgeNodeMinVersion) < 0) {
                throw PiBridgeException(
                    "Pi bridge requires Termux node >= $PiBridgeNodeMinVersion, found ${installedVersion ?: "none"}.",
                    code = "node_version_too_old",
                )
            }
        }

        runCatching {
            val toolStatuses = areCommandsAvailableCached(listOf("git", "rg", "fd"))
            val missing = toolStatuses.filterNot { it.installed }
            if (missing.isNotEmpty()) {
                val packageFor = mapOf(
                    "git" to "git",
                    "rg" to "ripgrep",
                    "fd" to "fd",
                )
                val packages = missing.mapNotNull { packageFor[it.command] }.distinct()
                if (packages.isNotEmpty()) {
                    diagnosticLogger.event(
                        category = "pi_bridge",
                        event = "agent_tool_packages_install_start",
                        level = "warn",
                        details = mapOf("packages" to packages.joinToString(" ")),
                    )
                    val installState = termuxRuntime.installPackages(
                        packages = packages,
                        label = "agent tools",
                        verifyCommands = missing.map { it.command },
                        onProgress = { progress ->
                            onSetupProgress(
                                PiCoreSetupUpdate(
                                    phase = PiCoreSetupPhase.InstallingNode,
                                    activity = PiCoreSetupActivity.Downloading,
                                    bytesPerSecond = progress.bytesPerSecond,
                                    output = progress.output,
                                )
                            )
                        },
                    )
                    if (!installState.isReady) {
                        diagnosticLogger.event(
                            category = "pi_bridge",
                            event = "agent_tool_packages_install_skipped",
                            level = "warn",
                            details = mapOf("detail" to installState.detail),
                        )
                    }
                }
            }
        }
    }

    @Volatile private var probeStamp = -1L
    @Volatile private var cachedNodeVersion: String? = null
    @Volatile private var cachedNodeVersionChecked = false
    @Volatile private var cachedCommandStatuses: List<com.arix.app.runtime.TermuxCommandStatus>? = null
    @Volatile private var cachedCommandStatusesChecked = false

    private suspend fun readNodeVersion(): String? {
        val raw = JSONObject(
            termuxRuntime.executeCommand(
                command = "node --version",
                workingDirectory = termuxRuntime.homeDirectory,
                awaitTimeoutMillis = 30_000L,
            )
        )
        if (!raw.optBoolean("ok")) return null
        return raw.optString("stdout")
            .lineSequence()
            .firstOrNull { it.trim().isNotBlank() }
            ?.trim()
            ?.removePrefix("v")
    }

    private suspend fun readNodeVersionCached(): String? {
        if (probeStamp != termuxRuntime.packageStateStamp() || !cachedNodeVersionChecked) {
            refreshEnvironmentProbeCache()
        }
        return cachedNodeVersion
    }

    private suspend fun refreshEnvironmentProbeCache() {
        probeStamp = termuxRuntime.packageStateStamp()
        cachedNodeVersion = readNodeVersion()
        cachedNodeVersionChecked = true
        cachedCommandStatuses = runCatching {
            termuxRuntime.areCommandsAvailable(listOf("git", "rg", "fd"))
        }.getOrNull()
        cachedCommandStatusesChecked = true
    }

    private suspend fun areCommandsAvailableCached(commands: List<String>): List<com.arix.app.runtime.TermuxCommandStatus> {
        if (probeStamp != termuxRuntime.packageStateStamp() || !cachedCommandStatusesChecked) {
            refreshEnvironmentProbeCache()
        }
        val cached = cachedCommandStatuses
        if (commands == listOf("git", "rg", "fd") && cached != null) {
            return cached
        }
        return termuxRuntime.areCommandsAvailable(commands)
    }

    private fun startStdoutReader(startedProcess: ActivePiBridgeProcess) {
        Thread(
            {
                diagnosticLogger.event(
                    category = "pi_bridge",
                    event = "stdout_reader_started",
                    details = mapOf("process_generation" to startedProcess.generation),
                )
                val parser = PiJsonlParser(
                    onFrame = { frame ->
                        handleFrameFromReader(frame, startedProcess.generation)
                    },
                    onInvalidLine = { line, throwable ->
                        diagnosticLogger.exception(
                            category = "pi_bridge",
                            event = "invalid_stdout_json",
                            throwable = throwable,
                            details = mapOf(
                                "line" to DiagnosticRedactor.sanitizeString(line.take(700)),
                            ),
                        )
                    },
                )
                runCatching {
                    BufferedReader(
                        InputStreamReader(startedProcess.process.inputStream, Charsets.UTF_8)
                    ).useLines { lines ->
                        lines.forEach { line ->
                            if (line.startsWith("{\"jsonrpc\"")) {
                                handleAcpLineFromReader(line, startedProcess.generation)
                            } else {
                                parser.accept(line + "\n")
                            }
                        }
                    }
                    parser.flush()
                }.onFailure { throwable ->
                    diagnosticLogger.exception(
                        category = "pi_bridge",
                        event = "stdout_reader_failed",
                        throwable = throwable,
                        details = mapOf("process_generation" to startedProcess.generation),
                    )
                }
                diagnosticLogger.event(
                    category = "pi_bridge",
                    event = "stdout_reader_exiting",
                    level = "warn",
                    details = mapOf("process_generation" to startedProcess.generation),
                )
                eventScope.launch {
                    failPendingRequests(
                        exitedProcess = startedProcess,
                        message = "Pi bridge process exited.",
                    )
                }
            },
            "arix-pi-bridge-stdout-${startedProcess.generation}",
        ).apply {
            isDaemon = true
            start()
        }
    }

    private fun startStderrReader(startedProcess: ActivePiBridgeProcess) {
        Thread(
            {
                runCatching {
                    BufferedReader(
                        InputStreamReader(startedProcess.process.errorStream, Charsets.UTF_8)
                    ).useLines { lines ->
                        lines.forEach { line ->
                            diagnosticLogger.event(
                                category = "pi_bridge",
                                event = "stderr",
                                level = "warn",
                                details = mapOf(
                                    "line" to DiagnosticRedactor.sanitizeString(line),
                                    "process_generation" to startedProcess.generation,
                                ),
                            )
                        }
                    }
                }
            },
            "arix-pi-bridge-stderr-${startedProcess.generation}",
        ).apply {
            isDaemon = true
            start()
        }
    }

    private val eventFramesReceived = java.util.concurrent.atomic.AtomicLong(0L)

    private fun handleFrameFromReader(
        frame: PiBridgeFrame,
        processGeneration: Long,
    ) {
        if (frame.type == "event") {
            eventFramesReceived.incrementAndGet()
        } else {
            diagnosticLogger.event(
                category = "pi_bridge",
                event = "frame_received",
                requestId = frame.id,
                details = mapOf(
                    "frame_type" to frame.type,
                    "frame_event" to frame.event,
                    "process_generation" to processGeneration,
                    "has_pending_request" to (pendingRequests[frame.id] != null),
                    "event_frames_counted" to eventFramesReceived.get(),
                ),
            )
        }
        val pending = pendingRequests[frame.id]
        if (pending != null && pending.processGeneration != processGeneration) {
            diagnosticLogger.event(
                category = "pi_bridge",
                event = "frame_generation_mismatch",
                level = "warn",
                requestId = frame.id,
                details = mapOf(
                    "frame_generation" to processGeneration,
                    "request_generation" to pending.processGeneration,
                ),
            )
            return
        }
        if (pending != null) {
            val now = System.currentTimeMillis()
            pending.lastFrameAtMillis = now
            if (frame.type == "event" && frame.event == "bridge_heartbeat") {
                val agentIdleMillis = frame.payload.optLong("agent_idle_ms", 0L)
                if (agentIdleMillis > 0L) {
                    pending.lastAgentActivityAtMillis = now - agentIdleMillis
                }
                pending.activeToolCount = frame.payload.optInt("active_tool_count", 0)
                pending.streaming = frame.payload.optBoolean("streaming", false)
                pending.compacting = frame.payload.optBoolean("compacting", false)
            }
        }
        when {
            pending != null && pending.eventChannel != null -> {
                if (pending.eventChannel.trySend(frame).isFailure) {
                    diagnosticLogger.event(
                        category = "pi_bridge",
                        event = "event_channel_send_failed",
                        level = "warn",
                        requestId = frame.id,
                        details = mapOf(
                            "frame_type" to frame.type,
                            "frame_event" to frame.event,
                        ),
                    )
                    pending.response.completeExceptionally(
                        PiBridgeException("Pi bridge event queue was closed.", code = "event_queue_closed")
                    )
                }
            }

            pending != null && (frame.type == "response" || frame.type == "error") ->
                pending.response.complete(frame)

            pending != null && frame.type == "event" -> Unit

            pending == null && isRecentlyCancelledRequest(frame.id) -> Unit

            else -> diagnosticLogger.event(
                category = "pi_bridge",
                event = "unknown_frame",
                level = "warn",
                details = mapOf(
                    "frame_type" to frame.type,
                    "request_id" to frame.id,
                ),
            )
        }
    }

    private fun markRequestCancelled(requestId: String) {
        val now = System.currentTimeMillis()
        cancelledRequestIds[requestId] = now
        cancelledRequestIds.forEach { (candidateId, cancelledAt) ->
            if (now - cancelledAt > CancelledRequestRetentionMillis) {
                cancelledRequestIds.remove(candidateId, cancelledAt)
            }
        }
    }

    private fun isRecentlyCancelledRequest(requestId: String): Boolean {
        val cancelledAt = cancelledRequestIds[requestId] ?: return false
        if (System.currentTimeMillis() - cancelledAt <= CancelledRequestRetentionMillis) {
            return true
        }
        cancelledRequestIds.remove(requestId, cancelledAt)
        return false
    }

    private suspend fun failPendingRequests(
        exitedProcess: ActivePiBridgeProcess,
        message: String,
    ) {
        diagnosticLogger.event(
            category = "pi_bridge",
            event = "fail_pending_requests_start",
            level = "warn",
            details = mapOf(
                "message" to message,
                "exited_process_generation" to exitedProcess.generation,
                "pending_count" to pendingRequests.size,
            ),
        )
        mutex.withLock {
            val isCurrentProcess = synchronized(processStateLock) {
                activeProcess?.process === exitedProcess.process
            }
            if (!isCurrentProcess) {
                diagnosticLogger.event(
                    category = "pi_bridge",
                    event = "fail_pending_requests_replaced",
                    level = "warn",
                    details = mapOf(
                        "reason" to "not_current_process",
                        "exited_process_generation" to exitedProcess.generation,
                    ),
                )
            }
            pendingRequests.forEach { (requestId, pending) ->
                if (pending.processGeneration != exitedProcess.generation) return@forEach
                if (!pendingRequests.remove(requestId, pending)) return@forEach
                pending.response.completeExceptionally(PiBridgeException(message, code = "bridge_exited"))
                pending.eventChannel?.close()
            }
            val acpIterator = acpPending.entries.iterator()
            while (acpIterator.hasNext()) {
                val (requestId, deferred) = acpIterator.next()
                acpIterator.remove()
                deferred.completeExceptionally(
                    PiBridgeException(message, code = "bridge_exited"),
                )
            }
            if (isCurrentProcess) {
                synchronized(processStateLock) {
                    activeProcess = null
                }
            }
        }
    }

    private fun nextRequestId(type: String): String =
        "${type}-${System.currentTimeMillis()}-${UUID.randomUUID().toString().take(8)}"

    private fun requestDiagnosticDetails(
        type: String,
        payload: JSONObject,
    ): Map<String, Any?> {
        val modelConfig = payload.optJSONObject("model_config")
        return mapOf(
            "request_type" to type,
            "session_id" to payload.optString("session_id"),
            "provider" to modelConfig?.optString("pi_provider_id").orEmpty(),
            "model" to modelConfig?.optString("model_id").orEmpty(),
        ).filterValues(String::isNotBlank)
    }
}

private fun shellQuote(value: String): String =
    "'" + value.replace("'", "'\"'\"'") + "'"

private fun compareSemver(left: String, right: String): Int {
    val leftCore = left.substringBefore('-')
    val rightCore = right.substringBefore('-')
    val leftParts = leftCore.split('.').mapNotNull { it.toIntOrNull() }
    val rightParts = rightCore.split('.').mapNotNull { it.toIntOrNull() }
    val maxSize = maxOf(leftParts.size, rightParts.size, 3)
    for (index in 0 until maxSize) {
        val leftValue = leftParts.getOrNull(index) ?: 0
        val rightValue = rightParts.getOrNull(index) ?: 0
        if (leftValue != rightValue) return leftValue.compareTo(rightValue)
    }
    val leftIsPreRelease = left.contains('-')
    val rightIsPreRelease = right.contains('-')
    if (leftIsPreRelease != rightIsPreRelease) {
        return if (leftIsPreRelease) -1 else 1
    }
    return 0
}
