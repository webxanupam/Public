package com.arix.app.data

import org.json.JSONObject

object ArixMissionFallbacks {
    fun unavailableExecutorOutput(): String = JSONObject()
        .put("ok", false)
        .put("error_code", "TOOL_UNAVAILABLE")
        .put("message", "The mission execution bridge is not available in this build.")
        .toString()
}
