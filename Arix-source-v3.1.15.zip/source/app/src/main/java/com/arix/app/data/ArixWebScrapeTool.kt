package com.arix.app.data

import android.content.Context
import com.arix.app.browser.ArixBrowserResearch
import java.io.File
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

object ArixWebScrapeTool {

    const val ToolName = "web_scrape"

    suspend fun execute(
        context: Context,
        argumentsJson: String,
        workspaceDirectory: String?,
        onProgress: (suspend (String) -> Unit)?,
    ): JSONObject {
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            ?: return failure("INVALID_ARGUMENTS", "Arguments were not valid JSON.")

        val mode = arguments.optString("mode").ifBlank { "scrape" }
        return when (mode) {
            "download" -> executeDownload(arguments, workspaceDirectory, onProgress)
            else -> executeScrape(context, arguments, onProgress)
        }
    }

    private suspend fun executeScrape(
        context: Context,
        arguments: JSONObject,
        onProgress: (suspend (String) -> Unit)?,
    ): JSONObject = withContext(Dispatchers.IO) {
        val url = arguments.optString("url").trim()
        if (url.isEmpty()) return@withContext failure("INVALID_ARGUMENTS", "url is required.")

        val selector = arguments.optString("selector").trim()
        val includeMarkdown = arguments.optBoolean("markdown", false)
        val includeAssets = arguments.optBoolean("assets", true)
        val maxChars = arguments.optInt("max_chars", 12_000).coerceIn(500, 24_000)
        val maxAssetsPerType = arguments.optInt("max_assets", 40).coerceIn(1, 200)
        val raw = arguments.optBoolean("raw", false)

        onProgress?.invoke("Fetching $url")
        val fetched = fetchWithLadder(context, url, onProgress)
            ?: return@withContext failure(
                "FETCH_BLOCKED",
                "All fetch strategies were blocked (direct, profile rotation, reader proxies, real " +
                    "browser). The site may require login, an interactive captcha, or be offline.",
            )

        if (raw) {
            return@withContext JSONObject()
                .put("ok", true)
                .put("tool", ToolName)
                .put("url", url)
                .put("final_url", fetched.finalUrl)
                .put("strategy", fetched.strategy)
                .put("content_type", fetched.contentType)
                .put("raw", fetched.body.take(maxChars))
                .put("raw_truncated", fetched.body.length > maxChars)
        }

        onProgress?.invoke("Extracting content")
        val doc = runCatching { Jsoup.parse(fetched.body) }.getOrNull()
            ?: return@withContext failure(
                "PARSE_FAILED",
                "The response at $url is not HTML (${fetched.contentType}); use raw=true to inspect the bytes.",
            )
        doc.setBaseUri(fetched.finalUrl)

        val scope: Element = if (selector.isNotBlank()) {
            runCatching { doc.selectFirst(selector) }.getOrNull()
                ?: return@withContext failure(
                    "SELECTOR_NOT_FOUND",
                    "No element matches selector '$selector' on $url.",
                )
        } else {
            doc
        }

        val text = extractReadableText(doc, scope)
        val result = JSONObject()
            .put("ok", true)
            .put("tool", ToolName)
            .put("url", url)
            .put("final_url", fetched.finalUrl)
            .put("strategy", fetched.strategy)
            .put("title", doc.title().trim())
            .put("description", metaContent(doc, "description"))
            .put("canonical", canonicalUrl(doc) ?: "")
            .put("text", text.take(maxChars))
            .put("text_truncated", text.length > maxChars)
            .put("text_chars", text.length)

        if (includeMarkdown) {
            val markdown = runCatching {
                val options = com.vladsch.flexmark.util.data.MutableDataSet()
                    .set(com.vladsch.flexmark.html2md.converter.FlexmarkHtmlConverter.UNORDERED_LIST_DELIMITER, '-')
                com.vladsch.flexmark.html2md.converter.FlexmarkHtmlConverter
                    .builder(options).build().convert(scope.outerHtml())
            }.getOrNull().orEmpty().trim()
            result
                .put("markdown", markdown.take(maxChars * 2))
                .put("markdown_truncated", markdown.length > maxChars * 2)
        }

        if (includeAssets) {
            onProgress?.invoke("Inventorying assets")
            result
                .put("images", assetList(doc, scope, AssetKind.Image, maxAssetsPerType))
                .put("videos", assetList(doc, scope, AssetKind.Video, maxAssetsPerType))
                .put("audio", assetList(doc, scope, AssetKind.Audio, maxAssetsPerType))
                .put("files", assetList(doc, scope, AssetKind.File, maxAssetsPerType))
                .put("links", assetList(doc, scope, AssetKind.Link, maxAssetsPerType))
                .put("json_ld", jsonLd(doc))
        }

        result
    }

    private suspend fun executeDownload(
        arguments: JSONObject,
        workspaceDirectory: String?,
        onProgress: (suspend (String) -> Unit)?,
    ): JSONObject = withContext(Dispatchers.IO) {
        val urls = arguments.optJSONArray("urls")
            ?.let { array -> (0 until array.length()).mapNotNull { array.optString(it).takeIf(String::isNotBlank) } }
            .orEmpty()
        if (urls.isEmpty()) return@withContext failure("INVALID_ARGUMENTS", "mode=download needs urls[] (asset URLs).")
        val targetDir = workspaceDirectory?.takeIf { it.isNotBlank() }
            ?: return@withContext failure(
                "NO_WORKSPACE",
                "The runtime workspace is not initialized; open the app once and retry.",
            )

        val client = buildClient()
        val saved = JSONArray()
        val errors = JSONArray()
        for ((index, assetUrl) in urls.withIndex()) {
            onProgress?.invoke("Downloading ${index + 1}/${urls.size}")
            runCatching {
                val request = baseRequest(assetUrl).build()
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        errors.put(JSONObject().put("url", assetUrl).put("status", response.code))
                        return@use
                    }
                    val dir = File(targetDir, "downloads").apply { mkdirs() }
                    val name = fileNameFromUrl(assetUrl, response.header("Content-Disposition"))
                    val file = uniqueFile(dir, name)
                    response.body?.byteStream()?.use { input ->
                        file.outputStream().use { output -> input.copyTo(output) }
                    }
                    saved.put(
                        JSONObject()
                            .put("url", assetUrl)
                            .put("path", file.absolutePath)
                            .put("bytes", file.length()),
                    )
                }
            }.onFailure { error ->
                errors.put(JSONObject().put("url", assetUrl).put("error", error.message ?: "download failed"))
            }
        }

        JSONObject()
            .put("ok", saved.length() > 0)
            .put("tool", ToolName)
            .put("saved", saved)
            .put("errors", errors)
    }

    private data class Fetched(
        val body: String,
        val finalUrl: String,
        val contentType: String,
        val strategy: String,
    )

    private suspend fun fetchWithLadder(
        context: Context,
        url: String,
        onProgress: (suspend (String) -> Unit)?,
    ): Fetched? {
        BrowserProfiles.forEachIndexed { index, profile ->
            runCatching {
                onProgress?.invoke("Direct fetch (profile ${index + 1}/${BrowserProfiles.size})")
                val fetched = fetchDirect(url, profile)
                if (fetched != null) return fetched
            }
        }

        for (proxy in ReaderProxies) {
            runCatching {
                onProgress?.invoke("Reader proxy: ${proxy.name}")
                val fetched = fetchDirect(proxy.build(url), BrowserProfiles[0], referer = null)
                if (fetched != null && fetched.body.isNotBlank()) {
                    return Fetched(
                        body = fetched.body,
                        finalUrl = url,
                        contentType = "text/markdown",
                        strategy = "proxy:${proxy.name}",
                    )
                }
            }
        }

        runCatching {
            onProgress?.invoke("Real browser fallback")
            val browserResult = ArixBrowserResearch.fetchUrl(
                context = context,
                url = url,
                topicId = null,
                offset = 0,
                maxChars = 24_000,
            )
            if (browserResult.optBoolean("ok", false)) {
                val passages = browserResult.optJSONArray("passages") ?: JSONArray()
                val text = buildString {
                    for (i in 0 until passages.length()) {
                        append(passages.optJSONObject(i)?.optString("text").orEmpty()).append("\n\n")
                    }
                }
                if (text.isNotBlank()) {
                    return Fetched(
                        body = text,
                        finalUrl = browserResult.optString("url").ifBlank { url },
                        contentType = "text/plain",
                        strategy = "real-browser",
                    )
                }
            }
        }
        return null
    }

    private fun fetchDirect(
        url: String,
        profile: BrowserProfile,
        referer: String? = "https://www.google.com/",
    ): Fetched? {
        val client = buildClient()
        val requestBuilder = baseRequest(url, referer)
        profile.headers.forEach { (name, value) -> requestBuilder.header(name, value) }
        val response = runCatching {
            client.newCall(requestBuilder.build()).execute()
        }.getOrNull() ?: return null

        response.use {
            val body = runCatching { it.body?.string() }.getOrNull().orEmpty()
            if (isBlocked(it.code, body, it.headers["cf-mitigated"])) return null
            if (body.isBlank()) return null
            return Fetched(
                body = body,
                finalUrl = it.request.url.toString(),
                contentType = it.header("Content-Type").orEmpty(),
                strategy = "direct:${profile.name}",
            )
        }
    }

    private fun buildClient(): OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .cookieJar(SharedCookieJar)
        .build()

    private fun baseRequest(url: String, referer: String? = null): Request.Builder {
        val builder = Request.Builder()
            .url(url)
            .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8")
            .header("Accept-Language", "en-US,en;q=0.9")
            .header("Upgrade-Insecure-Requests", "1")
            .header("Sec-Fetch-Dest", "document")
            .header("Sec-Fetch-Mode", "navigate")
            .header("Sec-Fetch-Site", if (referer != null) "cross-site" else "none")
            .header("Sec-Fetch-User", "?1")
            .header("Cache-Control", "no-cache")
        if (referer != null) builder.header("Referer", referer)
        return builder
    }

    private fun isBlocked(code: Int, body: String, cfMitigated: String?): Boolean {
        if (code == 403 || code == 429 || code >= 500) return true
        if (cfMitigated != null) return true
        if (body.length > 40_000) return false
        val head = body.take(4_000).lowercase()
        return head.contains("just a moment") ||
            head.contains("checking your browser") ||
            head.contains("enable javascript and cookies") ||
            head.contains("attention required! | cloudflare") ||
            head.contains("cf-browser-verification") ||
            head.contains("verify you are human") ||
            head.contains("request you submitted could not be processed")
    }

    private enum class AssetKind(val extensions: Set<String>) {
        Image(emptySet()),
        Video(setOf("mp4", "webm", "mkv", "mov", "avi", "m3u8", "m4v")),
        Audio(setOf("mp3", "m4a", "aac", "wav", "ogg", "flac", "opus")),
        File(setOf("pdf", "zip", "rar", "7z", "tar", "gz", "apk", "iso", "exe", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "csv", "epub", "torrent")),
        Link(emptySet()),
    }

    private fun assetList(doc: Document, scope: Element, kind: AssetKind, cap: Int): JSONArray {
        val out = JSONArray()
        val seen = HashSet<String>()
        val baseUri = scope.baseUri().ifBlank { doc.baseUri() }

        fun push(rawUrl: String?, label: String = "") {
            val value = rawUrl?.takeIf { it.isNotBlank() } ?: return
            val absolute = resolveUrl(value, baseUri) ?: return
            if (absolute.startsWith("data:") || absolute.startsWith("javascript:")) return
            if (!seen.add(absolute)) return
            if (out.length() >= cap) return
            out.put(JSONObject().put("url", absolute).put("label", label))
        }

        when (kind) {
            AssetKind.Image -> {
                scope.select("img[src], img[data-src], source[srcset]").forEach { element ->
                    push(element.attr("src"), element.attr("alt"))
                    push(element.attr("data-src"), element.attr("alt"))
                    element.attr("srcset").split(",").forEach { part ->
                        push(part.trim().split(" ").firstOrNull(), element.attr("alt"))
                    }
                }
                push(metaContent(doc, "og:image"), "og:image")
                push(metaContent(doc, "twitter:image"), "twitter:image")
            }
            AssetKind.Video -> {
                scope.select("video[src], video source[src], video[data-src], iframe[src]").forEach { element ->
                    push(element.attr("src"))
                    push(element.attr("data-src"))
                }
                push(metaContent(doc, "og:video"), "og:video")
            }
            AssetKind.Audio -> {
                scope.select("audio[src], audio source[src]").forEach { element -> push(element.attr("src")) }
            }
            AssetKind.File -> {
                scope.select("a[href]").forEach { element ->
                    val href = element.attr("href")
                    val ext = href.substringBeforeLast('#').substringAfterLast('.', "").lowercase()
                    if (ext in kind.extensions) push(href, element.text().take(80))
                }
            }
            AssetKind.Link -> {
                scope.select("a[href]").forEach { element ->
                    val href = element.attr("href")
                    if (href.startsWith("http") || href.startsWith("/") || href.startsWith("#")) {
                        push(href, element.text().take(80))
                    }
                }
            }
        }
        return out
    }

    private fun extractReadableText(doc: Document, scope: Element): String {
        val work = scope.clone()
        work.select("script, style, noscript, nav, header, footer, aside, form, button, iframe, svg").remove()
        work.select("[aria-hidden=true], .ad, .ads, .advert, .cookie, .popup, .modal").remove()
        val paragraphs = work.select("p, h1, h2, h3, h4, h5, h6, li, td, th, blockquote, pre, figcaption")
            .map { it.text().trim() }
            .filter { it.length > 1 }
        val joined = paragraphs.joinToString("\n") { line ->
            when {
                line.length > 120 -> line
                line.endsWith('.') || line.endsWith('!') || line.endsWith('?') -> line
                else -> "$line"
            }
        }
        return joined.replace(Regex("\n{3,}"), "\n\n").trim()
    }

    private fun metaContent(doc: Document, property: String): String =
        doc.selectFirst("meta[property=$property], meta[name=$property]")?.attr("content")?.trim().orEmpty()

    private fun canonicalUrl(doc: Document): String? =
        doc.selectFirst("link[rel=canonical]")?.attr("abs:href")?.takeIf { it.isNotBlank() }

    private fun jsonLd(doc: Document): JSONArray {
        val out = JSONArray()
        doc.select("script[type=application/ld+json]").forEach { script ->
            runCatching {
                val content = script.data().trim()
                if (content.startsWith("[")) {
                    val array = JSONArray(content)
                    for (i in 0 until array.length()) out.put(array.get(i))
                } else {
                    out.put(JSONObject(content))
                }
            }
        }
        return out
    }

    private fun resolveUrl(value: String, baseUri: String): String? = runCatching {
        when {
            value.startsWith("http://") || value.startsWith("https://") -> value
            baseUri.isBlank() -> return null
            else -> java.net.URI(baseUri).resolve(value.replace(" ".toRegex(), "%20")).toString()
        }
    }.getOrNull()

    private fun fileNameFromUrl(url: String, contentDisposition: String?): String {
        contentDisposition?.let { header ->
            Regex("filename\\*?=\"?([^\";]+)\"?").find(header)?.groupValues?.get(1)?.let { return it }
        }
        val path = runCatching { url.toHttpUrl().encodedPath }.getOrNull().orEmpty()
        val name = path.substringAfterLast('/').takeIf { it.isNotBlank() } ?: "download"
        return name.take(120)
    }

    private fun uniqueFile(dir: File, name: String): File {
        val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
        var candidate = File(dir, safe)
        var counter = 1
        val base = candidate.nameWithoutExtension
        val ext = candidate.extension
        while (candidate.exists()) {
            candidate = File(dir, if (ext.isBlank()) "${base}_${counter}" else "${base}_${counter}.$ext")
            counter++
        }
        return candidate
    }

    private data class BrowserProfile(val name: String, val headers: List<Pair<String, String>>)

    private val BrowserProfiles = listOf(
        BrowserProfile(
            "chrome-android",
            listOf(
                "User-Agent" to "Mozilla/5.0 (Linux; Android 15; Pixel 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36",
                "sec-ch-ua" to "\"Chromium\";v=\"131\", \"Not_A Brand\";v=\"24\"",
                "sec-ch-ua-mobile" to "?1",
                "sec-ch-ua-platform" to "\"Android\"",
            ),
        ),
        BrowserProfile(
            "safari-macos",
            listOf(
                "User-Agent" to "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Safari/605.1.15",
            ),
        ),
        BrowserProfile(
            "firefox-linux",
            listOf(
                "User-Agent" to "Mozilla/5.0 (X11; Linux x86_64; rv:133.0) Gecko/20100101 Firefox/133.0",
            ),
        ),
        BrowserProfile(
            "chrome-desktop",
            listOf(
                "User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
                "sec-ch-ua" to "\"Chromium\";v=\"131\", \"Not_A Brand\";v=\"24\"",
                "sec-ch-ua-mobile" to "?0",
                "sec-ch-ua-platform" to "\"Windows\"",
            ),
        ),
    )

    private data class ReaderProxy(val name: String, val build: (String) -> String)

    private val ReaderProxies = listOf(
        ReaderProxy("r.jina.ai") { url -> "https://r.jina.ai/$url" },
        ReaderProxy("allorigins") { url -> "https://api.allorigins.win/raw?url=${java.net.URLEncoder.encode(url, "UTF-8")}" },
        ReaderProxy("codetabs") { url -> "https://api.codetabs.com/v1/proxy?quest=${java.net.URLEncoder.encode(url, "UTF-8")}" },
    )

    private object SharedCookieJar : CookieJar {
        private val store = HashMap<String, List<Cookie>>()
        @Synchronized
        override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
            store[url.host] = (store[url.host].orEmpty() + cookies)
                .distinctBy { it.name }
                .filter { it.expiresAt > System.currentTimeMillis() }
        }
        @Synchronized
        override fun loadForRequest(url: HttpUrl): List<Cookie> =
            store[url.host].orEmpty().filter { it.matches(url) }
    }

    private fun failure(code: String, message: String): JSONObject = JSONObject()
        .put("ok", false)
        .put("tool", ToolName)
        .put("code", code)
        .put("message", message)

    fun toolDefinition(): JSONObject = JSONObject().apply {
        put("name", ToolName)
        put(
            "description",
            "UNIVERSAL web scraper: fetch ANY url and extract EVERYTHING — readable text, markdown, " +
                "images, videos, audio, downloadable files (pdf/zip/apk/…), links and JSON-LD metadata. " +
                "Runs a 4-level fetch ladder: direct server-side fetch with real browser headers " +
                "(no CORS applies — that is a browser-only restriction), rotating browser profiles " +
                "(beats most Cloudflare bot rules), reader proxies, and finally Arix's REAL embedded " +
                "browser with full JavaScript (executes interactive challenges). Use for reading pages, " +
                "listing media, grabbing file links, or inspecting raw responses (raw=true). When the " +
                "inventory lists the assets you want, call again with mode=download and urls[] to save " +
                "them into the workspace. selector= scopes extraction to a CSS region.",
        )
        put("parameters", JSONObject().apply {
            put("type", "object")
            put("properties", JSONObject().apply {
                put("url", JSONObject().put("type", "string").put(
                    "description", "The full http(s) URL to scrape.",
                ))
                put("selector", JSONObject().put("type", "string").put(
                    "description", "Optional CSS selector scoping text extraction (e.g. \"article\", \"#content\").",
                ))
                put("markdown", JSONObject().put("type", "boolean").put(
                    "description", "Also return the region as clean Markdown (default false).",
                ))
                put("assets", JSONObject().put("type", "boolean").put(
                    "description", "Inventory images/videos/audio/files/links (default true).",
                ))
                put("max_assets", JSONObject().put("type", "integer").put(
                    "description", "Max entries per asset category (1-200, default 40).",
                ))
                put("max_chars", JSONObject().put("type", "integer").put(
                    "description", "Max text characters (500-24000, default 12000).",
                ))
                put("raw", JSONObject().put("type", "boolean").put(
                    "description", "Return the raw response body (first max_chars) without parsing.",
                ))
                put("mode", JSONObject().put("type", "string").put(
                    "description", "\"scrape\" (default) or \"download\" (save urls[] into the workspace).",
                ))
                put("urls", JSONObject().put("type", "array").put(
                    "items", JSONObject().put("type", "string"),
                ).put(
                    "description", "For mode=download: the asset URLs to save (from a previous scrape's inventory).",
                ))
            })
            put("required", JSONArray().put("url"))
            put("additionalProperties", false)
        })
        put("execution_mode", "sequential")
    }
}
