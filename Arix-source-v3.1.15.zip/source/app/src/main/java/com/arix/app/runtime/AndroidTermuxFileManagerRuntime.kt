package com.arix.app.runtime

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Environment
import android.provider.DocumentsContract
import java.io.File
import java.io.InputStream
import java.nio.file.Files
import java.nio.file.Files.setPosixFilePermissions
import java.nio.file.StandardCopyOption
import java.nio.file.attribute.PosixFilePermission
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object ArixDeviceStorage {

    val managesAllFiles: Boolean
        get() = android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R &&
            Environment.isExternalStorageManager()

    fun hasAccess(context: Context): Boolean {
        val applicationContext = context.applicationContext
        val readGranted = androidx.core.content.ContextCompat.checkSelfPermission(
            applicationContext,
            Manifest.permission.READ_EXTERNAL_STORAGE,
        ) == PackageManager.PERMISSION_GRANTED
        return when {
            managesAllFiles -> true
            android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R -> readGranted
            else -> readGranted
        }
    }

    fun canWrite(context: Context): Boolean {
        if (managesAllFiles) return true
        val applicationContext = context.applicationContext
        fun granted(permission: String) =
            androidx.core.content.ContextCompat.checkSelfPermission(
                applicationContext,
                permission,
            ) == PackageManager.PERMISSION_GRANTED
        return granted(Manifest.permission.WRITE_EXTERNAL_STORAGE)
    }

    fun runtimePermissions(): Array<String> = when {
        android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q ->
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        else -> arrayOf(
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
        )
    }

    fun allFilesAccessIntent(context: Context): Intent? {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.R) return null
        return runCatching {
            Intent(
                android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                android.net.Uri.parse("package:${context.packageName}"),
            )
        }.getOrElse {
            Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
        }
    }
}

data class AndroidFilePermissions(
    val ownerRead: Boolean,
    val ownerWrite: Boolean,
    val ownerExecute: Boolean,
    val groupRead: Boolean,
    val groupWrite: Boolean,
    val groupExecute: Boolean,
    val otherRead: Boolean,
    val otherWrite: Boolean,
    val otherExecute: Boolean,
) {
    val octal: String
        get() = buildString {
            append(octalDigit(ownerRead, ownerWrite, ownerExecute))
            append(octalDigit(groupRead, groupWrite, groupExecute))
            append(octalDigit(otherRead, otherWrite, otherExecute))
        }

    val symbolic: String
        get() = buildString {
            append(if (ownerRead) "r" else "-")
            append(if (ownerWrite) "w" else "-")
            append(if (ownerExecute) "x" else "-")
            append(if (groupRead) "r" else "-")
            append(if (groupWrite) "w" else "-")
            append(if (groupExecute) "x" else "-")
            append(if (otherRead) "r" else "-")
            append(if (otherWrite) "w" else "-")
            append(if (otherExecute) "x" else "-")
        }

    private fun octalDigit(read: Boolean, write: Boolean, execute: Boolean): Int =
        (if (read) 4 else 0) + (if (write) 2 else 0) + (if (execute) 1 else 0)

    companion object {
        fun fromPosix(permissions: Set<PosixFilePermission>): AndroidFilePermissions =
            AndroidFilePermissions(
                ownerRead = PosixFilePermission.OWNER_READ in permissions,
                ownerWrite = PosixFilePermission.OWNER_WRITE in permissions,
                ownerExecute = PosixFilePermission.OWNER_EXECUTE in permissions,
                groupRead = PosixFilePermission.GROUP_READ in permissions,
                groupWrite = PosixFilePermission.GROUP_WRITE in permissions,
                groupExecute = PosixFilePermission.GROUP_EXECUTE in permissions,
                otherRead = PosixFilePermission.OTHERS_READ in permissions,
                otherWrite = PosixFilePermission.OTHERS_WRITE in permissions,
                otherExecute = PosixFilePermission.OTHERS_EXECUTE in permissions,
            )

        fun toPosix(permissions: AndroidFilePermissions): Set<PosixFilePermission> = buildSet {
            if (permissions.ownerRead) add(PosixFilePermission.OWNER_READ)
            if (permissions.ownerWrite) add(PosixFilePermission.OWNER_WRITE)
            if (permissions.ownerExecute) add(PosixFilePermission.OWNER_EXECUTE)
            if (permissions.groupRead) add(PosixFilePermission.GROUP_READ)
            if (permissions.groupWrite) add(PosixFilePermission.GROUP_WRITE)
            if (permissions.groupExecute) add(PosixFilePermission.GROUP_EXECUTE)
            if (permissions.otherRead) add(PosixFilePermission.OTHERS_READ)
            if (permissions.otherWrite) add(PosixFilePermission.OTHERS_WRITE)
            if (permissions.otherExecute) add(PosixFilePermission.OTHERS_EXECUTE)
        }
    }
}

class AndroidTermuxFileManagerRuntime(
    private val termux: TermuxRuntime,
) : MultiplatformLocalRuntime {
    override val homeDirectory: String = termux.homeDirectory
    override val workspaceRoot: String = "/"
    override val fileSystem: RuntimeFileSystem = AndroidTermuxFileSystem(termux)

    override suspend fun isReady(): Boolean = termux.inspectSetup().isReady

    override suspend fun initialize(onProgress: (RuntimeSetupProgress) -> Unit) {
        check(termux.initialize().isReady) { "Termux runtime is not ready." }
    }

    override suspend fun reset() {
        termux.reset()
    }

    internal suspend fun hostFile(path: String): File? =
        runCatching { termux.resolveGuestPath(path) }.getOrNull()

    internal suspend fun listDirectory(path: String): List<AndroidTermuxFileEntry> = withContext(Dispatchers.IO) {
        if (normalizeVirtualRootPath(path) == "/") {
            return@withContext virtualRootEntries()
        }
        val directory = termux.resolveGuestPath(path)
        require(directory.isDirectory) { "Not a directory: $path" }
        val directEntries = directory.listFiles().orEmpty()
            .sortedWith(compareByDescending<File> { it.isDirectory }.thenBy { it.name.lowercase() })
            .map { file ->
                val isSymbolicLink = Files.isSymbolicLink(file.toPath())
                AndroidTermuxFileEntry(
                    name = file.name,
                    path = if (path == "/") "/${file.name}" else "${path.trimEnd('/')}/${file.name}",
                    isDirectory = file.isDirectory && !isSymbolicLink,
                    isSymbolicLink = isSymbolicLink,
                    size = file.length(),
                    modifiedAtMillis = file.lastModified(),
                )
            }
        if (AndroidSafStorageBridge.isRestrictedAndroidPath(directory)) {
            return@withContext restrictedFallbackEntries(
                guestDirectory = path,
                hostDirectory = directory,
                directEntries = directEntries,
            )
        }
        directEntries
    }

    private fun restrictedFallbackEntries(
        guestDirectory: String,
        hostDirectory: File,
        directEntries: List<AndroidTermuxFileEntry>,
    ): List<AndroidTermuxFileEntry> {
        val guestPrefix = guestDirectory.trimEnd('/')
        val merged = LinkedHashMap<String, AndroidTermuxFileEntry>()
        directEntries.forEach { entry -> merged[entry.name] = entry }
        runCatching {
            val grant = AndroidSafStorageBridge.coveringTreeGrant(
                resolver = termux.contentResolver,
                hostFile = hostDirectory,
            )
            if (grant != null) {
                val (treeUri, relative) = grant
                AndroidSafStorageBridge.listSafDirectory(
                    resolver = termux.contentResolver,
                    treeUri = treeUri,
                    relative = relative,
                )?.forEach { entry ->
                    merged[entry.name] = AndroidTermuxFileEntry(
                        name = entry.name,
                        path = "$guestPrefix/${entry.name}",
                        isDirectory = entry.isDirectory,
                        isSymbolicLink = false,
                        size = entry.sizeBytes,
                        modifiedAtMillis = entry.modifiedAtMillis,
                    )
                }
            }
        }
        for (ownDir in ownExternalAndroidDirs(hostDirectory)) {
            if (ownDir.parentFile?.canonicalPath != hostDirectory.canonicalPath) continue
            merged.putIfAbsent(
                ownDir.name,
                AndroidTermuxFileEntry(
                    name = ownDir.name,
                    path = "$guestPrefix/${ownDir.name}",
                    isDirectory = true,
                    isSymbolicLink = false,
                    size = 0L,
                    modifiedAtMillis = ownDir.lastModified(),
                ),
            )
        }
        return merged.values
            .sortedWith(compareByDescending<AndroidTermuxFileEntry> { it.isDirectory }.thenBy { it.name.lowercase() })
    }

    private fun ownExternalAndroidDirs(@Suppress("UNUSED_PARAMETER") restrictedRoot: File): List<File> = runCatching {
        val externalRoot = android.os.Environment.getExternalStorageDirectory()
        val candidates = listOf(
            File(externalRoot, "Android/data/com.arix.app"),
            File(externalRoot, "Android/obb/com.arix.app"),
        )
        candidates.filter { file -> file.isDirectory }
    }.getOrDefault(emptyList())

    internal suspend fun move(source: String, destination: String) = withContext(Dispatchers.IO) {
        requireProtectedRoot(source, "move")
        val sourceFile = termux.resolveGuestPath(source)
        val destinationFile = termux.resolveGuestPath(destination)
        require(!destinationFile.exists()) { "An item already exists at $destination" }
        destinationFile.parentFile?.mkdirs()
        runCatching {
            Files.move(sourceFile.toPath(), destinationFile.toPath(), StandardCopyOption.ATOMIC_MOVE)
        }.getOrElse {
            Files.move(sourceFile.toPath(), destinationFile.toPath())
        }
        Unit
    }

    internal suspend fun copy(source: String, destination: String) = withContext(Dispatchers.IO) {
        requireProtectedRoot(source, "copy")
        val sourceFile = termux.resolveGuestPath(source)
        val destinationFile = termux.resolveGuestPath(destination)
        require(!destinationFile.exists()) { "An item already exists at $destination" }
        require(sourceFile != destinationFile) { "The source and destination are the same." }
        destinationFile.parentFile?.mkdirs()
        if (sourceFile.isDirectory) {
            sourceFile.copyRecursively(destinationFile, overwrite = false)
        } else {
            sourceFile.copyTo(destinationFile, overwrite = false)
        }
        Unit
    }

    internal suspend fun importFile(destination: String, input: InputStream) = withContext(Dispatchers.IO) {
        val destinationFile = termux.resolveGuestPath(destination)
        require(!destinationFile.exists()) { "An item already exists at $destination" }
        destinationFile.parentFile?.mkdirs()
        try {
            destinationFile.outputStream().use(input::copyTo)
        } catch (error: Throwable) {
            destinationFile.delete()
            throw error
        }
        Unit
    }

    internal suspend fun statPermissions(path: String): AndroidFilePermissions? =
        withContext(Dispatchers.IO) {
            val file = termux.resolveGuestPath(path)
            runCatching { Files.getPosixFilePermissions(file.toPath()) }.getOrNull()
                ?.let(AndroidFilePermissions::fromPosix)
        }

    internal suspend fun updatePermissions(
        path: String,
        permissions: AndroidFilePermissions,
    ) = withContext(Dispatchers.IO) {
        val file = termux.resolveGuestPath(path)
        val posix = AndroidFilePermissions.toPosix(permissions)
        runCatching { setPosixFilePermissions(file.toPath(), posix) }
            .getOrElse {
                file.setReadable(permissions.ownerRead, false)
                file.setWritable(permissions.ownerWrite, false)
                file.setExecutable(permissions.ownerExecute, false)
            }
        Unit
    }

    private suspend fun virtualRootEntries(): List<AndroidTermuxFileEntry> {
        val now = System.currentTimeMillis()
        val candidates = listOf(
            Triple(termux.workspaceRoot, "workspace", "Agent workspace — uploads and generated files"),
            Triple(termux.homeDirectory, "home", "Termux home — configs, skills"),
            Triple(TermuxGuestPrefix, "termux", "Termux system prefix ($TermuxGuestPrefix)"),
            Triple(DeviceStorageGuestRoot, "device", "Device storage — shared storage (Download, DCIM, …)"),
            Triple(SystemRootGuestRoot, "system", "Android system root — the device filesystem (/)"),
        )
        return candidates
            .mapNotNull { (guestPath, name, _) ->
                val resolved = when (guestPath) {
                    DeviceStorageGuestRoot -> runCatching {
                        Environment.getExternalStorageDirectory()
                    }.getOrNull()
                    SystemRootGuestRoot -> File("/")
                    else -> runCatching { termux.resolveGuestPath(guestPath) }.getOrNull()
                }
                if (resolved?.isDirectory != true) return@mapNotNull null
                AndroidTermuxFileEntry(
                    name = name,
                    path = normalizeVirtualRootPath(guestPath),
                    isDirectory = true,
                    isSymbolicLink = false,
                    size = 0L,
                    modifiedAtMillis = resolved.lastModified().takeIf { it > 0L } ?: now,
                )
            }
    }

    internal fun isDeviceStoragePath(path: String): Boolean {
        val normalized = normalizeVirtualRootPath(path)
        return normalized == DeviceStorageGuestRoot || normalized.startsWith("$DeviceStorageGuestRoot/")
    }

    internal fun isSystemRootPath(path: String): Boolean {
        val normalized = normalizeVirtualRootPath(path)
        return normalized == SystemRootGuestRoot || normalized.startsWith("$SystemRootGuestRoot/")
    }

    internal fun isBootstrapIndependentPath(path: String): Boolean =
        isDeviceStoragePath(path) || isSystemRootPath(path)

    internal fun isTopLevelRoot(path: String): Boolean {
        val normalized = normalizeVirtualRootPath(path)
        return normalized == normalizeVirtualRootPath(termux.workspaceRoot) ||
            normalized == normalizeVirtualRootPath(termux.homeDirectory) ||
            normalized == normalizeVirtualRootPath(TermuxGuestHome) ||
            normalized == normalizeVirtualRootPath(TermuxGuestPrefix) ||
            normalized == DeviceStorageGuestRoot ||
            normalized == SystemRootGuestRoot
    }

    private fun requireProtectedRoot(candidate: String, operation: String) {
        if (isTopLevelRoot(candidate)) {
            error("'$candidate' is a top-level directory of the Termux environment and cannot be $operation'd.")
        }
    }
}

private fun normalizeVirtualRootPath(path: String): String {
    var normalized = path.trim().replace('\\', '/')
    while (normalized.length > 1 && normalized.endsWith("/")) {
        normalized = normalized.dropLast(1)
    }
    return normalized.ifBlank { "/" }
}

internal data class AndroidTermuxFileEntry(
    val name: String,
    val path: String,
    val isDirectory: Boolean,
    val isSymbolicLink: Boolean,
    val size: Long,
    val modifiedAtMillis: Long,
)

private class AndroidTermuxFileSystem(
    private val termux: TermuxRuntime,
) : RuntimeFileSystem {
    private suspend fun resolve(path: String): File = termux.resolveGuestPath(path)

    private fun safReadBytes(hostFile: File, maximumBytes: Long = -1L): ByteArray? {
        if (!AndroidSafStorageBridge.isRestrictedAndroidPath(hostFile)) return null
        val resolver = termux.contentResolver
        val grant = AndroidSafStorageBridge.coveringTreeGrant(resolver, hostFile)
            ?: return null
        val (treeUri, relative) = grant
        val documentId = DocumentsContract.getTreeDocumentId(treeUri).trimEnd('/') +
            (if (relative.isBlank()) "" else "/$relative")
        val documentUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, documentId)
        return runCatching {
            resolver.openInputStream(documentUri)?.use { input ->
                if (maximumBytes >= 0) {
                    input.readNBytes(maximumBytes.coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
                } else {
                    input.readBytes()
                }
            }
        }.getOrNull()
    }

    override suspend fun exists(path: String): Boolean = withContext(Dispatchers.IO) {
        if (normalizeVirtualRootPath(path) == "/") true else resolve(path).exists()
    }

    override suspend fun createDirectories(path: String) {
        withContext(Dispatchers.IO) { resolve(path).apply { check(mkdirs() || isDirectory) { "Unable to create directory: $path" } } }
    }

    override suspend fun read(path: String): ByteArray = withContext(Dispatchers.IO) {
        val file = resolve(path)
        safReadBytes(file) ?: file.readBytes()
    }

    override suspend fun read(path: String, maximumBytes: Long): ByteArray = withContext(Dispatchers.IO) {
        require(maximumBytes >= 0)
        val file = resolve(path)
        val safBytes = safReadBytes(file)
        if (safBytes != null) {
            require(safBytes.size.toLong() <= maximumBytes) { "File exceeds the allowed size." }
            safBytes
        } else {
            require(file.length() <= maximumBytes) { "File exceeds the allowed size." }
            file.readBytes()
        }
    }

    override suspend fun readPrefix(path: String, maximumBytes: Long): ByteArray = withContext(Dispatchers.IO) {
        require(maximumBytes >= 0)
        val file = resolve(path)
        val prefixBytes = safReadBytes(file, maximumBytes = maximumBytes)
        if (prefixBytes != null) {
            prefixBytes
        } else {
            resolve(path).inputStream().use { it.readNBytes(maximumBytes.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()) }
        }
    }

    override suspend fun write(path: String, content: ByteArray, executable: Boolean) = withContext(Dispatchers.IO) {
        resolve(path).apply {
            parentFile?.mkdirs()
            writeBytes(content)
            setExecutable(executable)
        }
        Unit
    }

    override suspend fun remove(path: String, recursive: Boolean) = withContext(Dispatchers.IO) {
        require(path.trimEnd('/').isNotEmpty()) { "Refusing to remove the Termux root." }
        val protectedRoots = buildSet {
            add(normalizeVirtualRootPath(termux.workspaceRoot))
            add(normalizeVirtualRootPath(termux.homeDirectory))
            add(normalizeVirtualRootPath(TermuxGuestHome))
            add(normalizeVirtualRootPath(TermuxGuestPrefix))
            add(DeviceStorageGuestRoot)
            add(SystemRootGuestRoot)
        }
        require(normalizeVirtualRootPath(path) !in protectedRoots) {
            "'${path.trim()}' is a top-level directory of the Termux environment and cannot be deleted."
        }
        val file = resolve(path)
        check(if (recursive) file.deleteRecursively() else file.delete()) { "Unable to remove $path" }
    }

    override suspend fun bindHostDirectory(hostPath: String, guestPath: String, readOnly: Boolean) {
        throw UnsupportedOperationException("Android file manager does not create bind mounts.")
    }
}

private fun shellQuote(value: String): String = RuntimeShellQuoting.shellQuote(value)
