package com.arix.app.data.pi

import com.arix.app.data.ModelsDevModelLimits
import com.arix.app.data.ProviderModelOption
import com.arix.app.data.PublicCatalogThinkingResult
import com.arix.app.data.thinkingCatalogKey
import org.json.JSONObject

internal fun bridgeProviderThinkingResult(
    payload: JSONObject,
    options: List<ProviderModelOption>,
): PublicCatalogThinkingResult {
    if (payload.has("closed") && payload.optJSONArray("providers") == null) {
        return PublicCatalogThinkingResult()
    }
    val providers = payload.optJSONArray("providers") ?: return PublicCatalogThinkingResult()
    val providerById = HashMap<String, JSONObject>()
    for (providerIndex in 0 until providers.length()) {
        val provider = providers.optJSONObject(providerIndex) ?: continue
        val providerId = provider.optString("id").trim()
        if (providerId.isNotEmpty()) providerById[providerId] = provider
    }
    val levelsMap = mutableMapOf<String, List<String>>()
    val reasoningModels = mutableSetOf<String>()
    val seenKeys = HashSet<String>()
    options.forEach { option ->
        val provider = providerById[option.piProviderId.trim()] ?: return@forEach
        val models = provider.optJSONArray("models") ?: return@forEach
        for (modelIndex in 0 until models.length()) {
            val model = models.optJSONObject(modelIndex) ?: continue
            val modelId = model.optString("id").trim()
            if (modelId.isEmpty()) continue
            val key = thinkingCatalogKey(option.piProviderId, modelId)
            if (!seenKeys.add(key)) continue
            val levels = model.optJSONArray("thinking_levels")
                ?.let { array ->
                    buildList {
                        for (levelIndex in 0 until array.length()) {
                            val level = array.optString(levelIndex).trim()
                            if (level.isNotEmpty()) add(level)
                        }
                    }
                }.orEmpty()
            if (model.optBoolean("reasoning")) reasoningModels += key
            levelsMap[key] = if (levels.isNotEmpty() && levels[0] != "off") {
                listOf("off") + levels
            } else {
                levels
            }
        }
    }
    return PublicCatalogThinkingResult(
        levelsByProviderModel = levelsMap,
        levelMapsByProviderModel = emptyMap(),
        reasoningModels = reasoningModels,
    )
}

internal fun mergeThinkingCatalogResults(
    vararg results: PublicCatalogThinkingResult,
): PublicCatalogThinkingResult {
    if (results.isEmpty()) return PublicCatalogThinkingResult()
    val levels = mutableMapOf<String, List<String>>()
    val levelMaps = mutableMapOf<String, Map<String, String>>()
    val reasoningModels = mutableSetOf<String>()
    val limits = mutableMapOf<String, ModelsDevModelLimits>()
    for (result in results) {
        result.levelsByProviderModel.forEach { (key, value) ->
            reasoningModels.remove(key)
            levels[key] = value
        }
        result.reasoningModels.forEach { key ->
            if (key in levels) reasoningModels += key
        }
        result.levelMapsByProviderModel.forEach { (key, value) ->
            val existing = levelMaps[key] ?: run {
                levelMaps[key] = value
                return@forEach
            }
            levelMaps[key] = buildMap {
                putAll(value)
                existing.forEach { (name, translated) -> put(name, translated) }
            }
        }
        result.limitsByProviderModel.forEach { (key, value) ->
            limits[key] = value
        }
    }
    return PublicCatalogThinkingResult(
        levelsByProviderModel = levels,
        levelMapsByProviderModel = levelMaps,
        reasoningModels = reasoningModels,
        limitsByProviderModel = limits,
    )
}
