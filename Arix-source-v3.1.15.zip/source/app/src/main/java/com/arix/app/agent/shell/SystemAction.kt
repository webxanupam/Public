package com.arix.app.agent.shell

/**
 * System actions done through Android's standard intent interfaces (Mika port):
 * setting alarms/timers, opening the alarm list, opening a pre-filled calendar
 * event. The installed clock/calendar app handles them; when nothing handles
 * an action, the caller reports not_supported and the model falls back to
 * operating the UI like any other app.
 */
sealed interface SystemAction {
    /** [days] repeats per java.util.Calendar numbering (1 = Sunday … 7 = Saturday); empty = one-shot. */
    data class SetAlarm(
        val hour: Int,
        val minute: Int,
        val label: String? = null,
        val days: List<Int> = emptyList(),
        val vibrate: Boolean? = null,
    ) : SystemAction

    data class SetTimer(val seconds: Int, val label: String? = null) : SystemAction

    data object ShowAlarms : SystemAction

    /** begin/end are epoch millis; [allDay] compares dates only. */
    data class AddCalendarEvent(
        val title: String,
        val beginMs: Long,
        val endMs: Long? = null,
        val allDay: Boolean = false,
        val location: String? = null,
        val description: String? = null,
    ) : SystemAction

    /** Handled without leaving an interface (alarm/timer); the rest open the app's page on Arix's screen. */
    val silent: Boolean get() = this is SetAlarm || this is SetTimer
}
