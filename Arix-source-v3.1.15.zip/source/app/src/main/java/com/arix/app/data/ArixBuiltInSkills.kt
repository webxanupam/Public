package com.arix.app.data

const val VideoStudioSkillId = "video-studio"

const val BuiltInSkillContentRevision = "3.1.13-1"

object ArixBuiltInSkills {

    data class BuiltInSkill(
        val id: String,
        val name: String,
        val description: String,
        val skillMd: String,
        val assetDir: String? = null,
    )

    val all: List<BuiltInSkill> = listOf(
        BuiltInSkill(
            id = "web-research",
            name = "Web Research",
            description = "Research any topic across the live web with layered searches, " +
                "source fetching, cross-checking and a cited synthesis — for questions, " +
                "comparisons, fact-checking, market/tech/product research and study help.",
            skillMd = """
                ---
                name: Web Research
                description: Research any topic across the live web with layered searches, source fetching, cross-checking and a cited synthesis. Use for questions needing current or verifiable information, comparisons, fact-checking, and market/tech/product research.
                compatibility: Arix 3.x
                metadata:
                  short-description: Layered web research with citations
                ---

                # Web Research

                Answer questions that need CURRENT, VERIFIABLE information — not from memory. Run layered searches, fetch the best sources, cross-check claims, then synthesize with citations.

                ## The workflow

                1. **Plan the queries.** Decompose the question into 2–4 specific search angles (e.g. for "best phone under 30k in 2025": one query for current rankings, one for known issues, one for prices in the user's market).
                2. **Search.** Call `web_search` once per angle. Vary the wording between searches; add the year or region when it matters.
                3. **Select sources.** From the results, pick 3–6 links that (a) come from different domains, (b) look primary/authoritative for the question (official docs, standards bodies, reputable outlets, primary data), and (c) together cover all angles. Prefer primary sources over aggregators that summarize them.
                4. **Fetch.** Call `fetch_url` on each selected link to read the actual content. Never cite a claim you only saw in a search snippet — snippets truncate and paraphrase.
                5. **Cross-check.** Any load-bearing number, date, or factual claim must appear in at least two independent sources. When sources disagree, keep the disagreement and say so — do not silently pick one.
                6. **Synthesize.** Write the answer in the user's language: a direct answer first, then the reasoning/evidence organized by the question's angles, ending with a short source list (title + domain). Mark uncertain or contested points explicitly.

                ## Rules

                - If a fetch fails or returns junk, fall back to the next-best link — do not cite it.
                - Never invent sources, URLs, quotes, or statistics. Every citation must come from a page actually fetched.
                - For money/medical/legal topics, add a one-line caution and prefer official sources.
                - Keep the final answer proportional: a quick factual question deserves a short answer with 1–2 sources, not a report.
            """.trimIndent(),
        ),
        BuiltInSkill(
            id = "media-finder",
            name = "Find & Play Media",
            description = "Find and play music, songs, movies, videos and adult content through " +
                "Arix's media search — kind selection, latest-movies discovery, per-site " +
                "scraping and image search, so media requests land on playable results.",
            skillMd = """
                ---
                name: Find & Play Media
                description: Find and play music, songs, movies and videos through Arix's native media search — kind selection, latest-movies discovery, per-site scraping and image search. Use whenever the user asks to play, watch or listen to anything.
                compatibility: Arix 3.x
                metadata:
                  short-description: Playable media for any request
                ---

                # Find & Play Media

                Turn any "play / watch / listen" request into tappable media cards that play in Arix's native player. The `media_search` tool does the discovery — your job is to call it with the RIGHT parameters.

                ## Choosing the parameters

                1. **Set `kind` accurately — this is the #1 mistake:**
                   - `movie` for films ("watch Interstellar", "latest movies"). Movie requests are served from the free-movie streaming site with full films; 'latest movies' (and opening the movie site itself) returns the site's HOMEPAGE MOVIE LIST. When a movie is not found, the tool says NOT FOUND — YOU answer the user from your own knowledge (suggest the exact title, a similar movie, or offer the 'latest movies' list); never look for other websites.
                   - `music` for songs/tracks/albums.
                   - `audio` for podcasts, audiobooks, soundtracks.
                   - `video` for clips, episodes, trailers.
                2. **"Latest / new / trending movies"** → `media_search` with `query="latest movies"`, `kind="movie"`. It returns the sites' newest releases as play cards.
                3. **A specific website** ("find a video on this site") → pass `site` (domain or URL). Any public site is scraped generically.
                4. **A direct link** the user pasted → pass it as `url`.
                5. **Adult (18+)** requests → set `allow_adult=true` (only when the user clearly asked for adult content); the search then uses real adult tube sites.
                6. **Images / wallpapers / memes** → media kinds cover video thumbnails; for plain image requests use `web_search` and cite what you find.

                ## Behavior

                - ALWAYS call `media_search` yourself when media is requested — do not answer with links you made up from memory.
                - If the result is `ok:false` or the message says nothing playable was found, retry ONCE with a cleaned-up query (exact title, or `kind` corrected) before reporting failure.
                - For MOVIES specifically: a NOT_FOUND result means the movie site does not carry it — answer the user YOURSELF from your own knowledge (you are the AI provider): suggest the exact title spelling, a similar movie, or offer the "latest movies" list (`query="latest movies"`, `kind="movie"` → the site's movie list). Do NOT search for, scrape, or suggest other websites (no news/blog sites, no invented links).
                - Present the results as they render: the cards are already tappable — just add one short line about what you found.
                - If the user says a card doesn't play, offer: another title spelling, another kind (music vs video), or naming a different site.
            """.trimIndent(),
        ),
        BuiltInSkill(
            id = "file-organizer",
            name = "File Organizer",
            description = "Organize, clean up and batch-process files in the workspace or device " +
                "storage — sort into folders, bulk rename, find duplicates, compress and " +
                "generate file inventories.",
            skillMd = """
                ---
                name: File Organizer
                description: Organize, clean up and batch-process files in the workspace or device storage — sort into folders, bulk rename, find duplicates, archive, and produce inventories. Use when the user asks to tidy, sort, rename, deduplicate or summarize files.
                compatibility: Arix 3.x
                metadata:
                  short-description: Sort, rename, dedupe, archive
                ---

                # File Organizer

                Batch-process files safely with shell commands in the runtime. The workflow is always: **survey → propose → (confirm) → execute → verify → report.**

                ## Workflow

                1. **Survey first.** `ls -la` the target directory; for big trees use `find . -type f | head -50` plus a count. NEVER run a batch change before you know what's there.
                2. **Propose the plan.** Tell the user what will move/rename/delete and how many items. For anything DESTRUCTIVE (delete, overwrite), state exactly what will be removed and ask for confirmation first.
                3. **Execute with dry-run-able logic.**
                   - Bulk rename: generate the mapping with a loop or `rename` when available; echo the mapping BEFORE applying (`for f in *.JPG; do echo "${'$'}f -> ${'$'}{f%.JPG}.jpg"; done`), then apply.
                   - Sort into folders: `mkdir -p` the target folders, then `find ... -exec mv {} dir/ \;` grouped by extension/date (`find . -maxdepth 1 -iname '*.pdf' -exec mv {} PDFs/ \;`).
                   - Duplicates: hash first (`find . -type f -exec md5sum {} + | sort`), group identical hashes, list them, delete only after confirmation.
                   - Archive: `tar -czf backup-$(date +%F).tar.gz <paths>` or `zip -r` when available.
                4. **Verify.** Re-list the directory and show the after-state (counts per folder work well: `find . -type f | sed 's/.*\.//' | sort | uniq -c`).
                5. **Report.** One line per action class: "moved 34 photos into Photos/, renamed 12 files, deleted 3 duplicates (freed 21 MB)".

                ## Safety rules

                - Never delete outside the folder the user named. Never touch dotfiles or `.arix/` internals.
                - Quoting: always double-quote variables in paths ("${'$'}f") — filenames with spaces break unquoted commands.
                - Prefer moving to a `_trash/` folder over `rm` for cleanups the user approved.
                - For device storage (DCIM, Download, ...) work under the mapped `/device` root the same way.
            """.trimIndent(),
        ),
        BuiltInSkill(
            id = "file-transfer",
            name = "File Transfer",
            description = "Share any workspace or device file — upload it to a direct download " +
                "link through Arix's five transfer servers (filebin, tmpfiles, gofile, qu.ax, " +
                "x0) with live upload progress in the chat, then present the link card with " +
                "copy/share/open actions.",
            skillMd = """
                ---
                name: File Transfer
                description: Upload any workspace or device file to a direct download link through Arix's arix_file_share tool (servers: filebin, tmpfiles, gofile, quax, x0). Use whenever the user asks to share, send, upload, host or link a file.
                compatibility: Arix 3.x
                metadata:
                  short-description: Upload files to shareable links
                ---

                # File Transfer

                Turn any "share / send / upload this file" request into a DIRECT DOWNLOAD LINK with one call — the user sees a live upload-progress widget and gets a tappable link card with copy/share/open actions. Never paste links you invented; always produce them through the tool.

                ## The tool

                Call `arix_file_share` with:
                - `file` (required): the file to share. Absolute guest paths work everywhere:
                  - `/workspace/<name>` — agent-generated files (reports, exports, archives…)
                  - `/workspace/uploads/<name>` — files the user attached to the chat
                  - `/device/<name>` — device shared storage (`/device/Download/clip.mp4`, `/device/DCIM/...`, …)
                  - a bare name (`report.pdf`) resolves against the workspace root, then the uploads directory.
                - `server` (optional): `filebin` (default, 6-day availability), `tmpfiles` (up to 100 MB, 60 days), `gofile` (large files, no signup), `quax` (30-day retention), `x0` (up to 200 MB).

                ## Workflow

                1. **Locate the file.** If the user named something vague, `ls` the likely directories first (`ls /workspace`, `ls /workspace/uploads`, `ls /device/Download`). Pick the exact file.
                2. **Choose the server.** Default `filebin`. If the file is larger than 100 MB use `gofile` or `filebin` (NOT tmpfiles/x0 — they reject the size). If one server errors, retry ONCE with a different server before reporting failure.
                3. **Call the tool once.** The chat shows the live percentage while it streams — you do NOT need to narrate progress.
                4. **Present the result.** The tool's link card already renders with copy/share/open. Add ONE short line: what was uploaded, where the link lives, and when it expires (the card shows it too).

                ## Rules

                - NEVER upload secrets the user did not ask to share (API keys, keystores, `.env` files with credentials) — ask first.
                - NEVER claim a link exists without a successful tool result.
                - If the file does not exist, tell the user the exact path you tried and what IS there (from your `ls`), then ask which file they meant.
                - Archiving several files into one share is welcome: `zip -r /workspace/bundle.zip <paths>` first, then share the archive.
            """.trimIndent(),
        ),
        BuiltInSkill(
            id = "document-creator",
            name = "Document Creator",
            description = "Produce polished documents in the workspace — reports, letters, " +
                "resumes, study notes, invoices — as Markdown, styled HTML or PDF via the " +
                "runtime, ready to preview, share or download.",
            skillMd = """
                ---
                name: Document Creator
                description: Create polished documents in the workspace — reports, letters, resumes, study notes, invoices, cheatsheets — as Markdown, styled HTML or PDF via the runtime, ready to preview, share or download. Use when the user asks to write, draft or generate a document/file deliverable.
                compatibility: Arix 3.x
                metadata:
                  short-description: Reports, letters, resumes, PDFs
                ---

                # Document Creator

                Turn "write me a X" into a real FILE the user can open, share or download — not just chat text.

                ## Workflow

                1. **Clarify the shape** (infer when obvious): document type, audience, tone, length. If the user gave a resume/job-posting or letter context, collect the key facts first.
                2. **Draft as Markdown first** — write the full content to `<slug>.md` in the workspace. This is the editable source of truth.
                3. **Choose the output format:**
                   - Notes, READMEs, study guides → Markdown is the deliverable.
                   - Anything meant to LOOK designed (resume, invoice, report, letter) → styled HTML: a single self-contained `.html` with inline CSS (clean typography, A4-friendly margins, print CSS). The chat renders it and the user can open/share/download it.
                   - When the user explicitly wants PDF and a converter is available in the runtime, convert the HTML (headless chromium / wkhtmltopdf / weasyprint) — otherwise deliver the HTML and say it is print-ready (browser → Print → Save as PDF works perfectly).
                4. **Content quality:** concrete specifics over filler; consistent headings; tables for comparisons; bullet lists kept short. Resumes: one page, quantified achievements. Letters: correct salutation/sign-off. Invoices: line items, totals, dates.
                5. **Deliver:** name the file, state where it was saved, and offer next iterations ("want it shorter / as PDF / different tone?").

                ## Rules

                - The file must exist in the workspace before you claim success — verify with `ls` after writing.
                - No lorem ipsum, no placeholder fields the user must fill for things they already told you.
                - One topic per document; split when the user asks for a pack (e.g. "3 cover letters" → 3 files).
            """.trimIndent(),
        ),
        BuiltInSkill(
            id = "daily-briefing",
            name = "Daily Briefing",
            description = "Assemble a personal morning/evening briefing — weather, top news, " +
                "calendar-style reminders and a chosen interest digest — from the live web, " +
                "summarized in the user's language.",
            skillMd = """
                ---
                name: Daily Briefing
                description: Assemble a personal morning/evening briefing — weather, top news, and a digest of the user's interests — from live web data, summarized in the user's language. Use for "good morning brief", "what's happening today", "catch me up", or scheduled briefings.
                compatibility: Arix 3.x
                metadata:
                  short-description: Weather + news + interests digest
                ---

                # Daily Briefing

                Compose a compact, scannable briefing from LIVE data. Never from memory — today's weather and news cannot be recalled.

                ## Sections (in order)

                1. **Weather.** Use `web_search` for the current weather in the user's location (ask once; remember it afterwards via `arix_memory` if the user agrees); `fetch_url` a forecast page when the search snippet is thin. Report: now, the day's range, and anything actionable (rain, heat, wind).
                2. **Top news.** `web_search` for the day's top headlines in the user's country/language + their stated interests (tech, sports, markets, gaming…). Fetch 1–2 of the strongest stories with `fetch_url` when a headline deserves two more sentences; otherwise headline+one-line summary is enough.
                3. **Interest digest.** One or two `web_search` calls scoped to what the user actually follows ("Premier League results today", "AI news this week"). Keep it to 3–5 bullets per interest.
                4. **On this day / suggestion (optional).** Skip unless it fits naturally.

                ## Style

                - Start with a one-line "Here's your briefing" summary of the single most important item.
                - Emoji-free headers, tight bullets, numbers over adjectives ("34°C, feels 38°" not "quite hot").
                - Total length: fits on one screen. The briefing is a digest, not a report.
                - End with one offer: "want the full story on any of these?"

                ## Scheduling

                If the user wants this daily at a set time, set up a scheduled task (Automation in Settings) that asks for the briefing, and keep the location/interests in memory so future briefings need zero setup.
            """.trimIndent(),
        ),
        BuiltInSkill(
            id = VideoStudioSkillId,
            name = "Video Studio",
            description = "Make a finished explainer video from a prompt - YouTube Shorts, reels, explainers, " +
                "slideshows - with graphics drawn live from the script, the user's own talking presenter " +
                "with lip-sync, voiceover and word-synced captions. Researches the topic first. Use for any " +
                "request to make, create, generate or edit a video, short, reel, clip or voiceover.",
            assetDir = "skills/video-studio",
            skillMd = """
                ---
                name: Video Studio
                description: Make a finished explainer video from a prompt - YouTube Shorts, reels, explainers, slideshows - with graphics DRAWN LIVE from the script (the agent writes the shapes for every scene), the user's own talking presenter with phoneme lip-sync, voiceover and word-synced captions. Researches the topic first. Use for any request to make, create, generate or edit a video, short, reel, clip or voiceover.
                compatibility: Arix 3.x
                metadata:
                  short-description: Researched explainer video with live-drawn graphics and a talking presenter
                  strong-keywords: tiktok reel reels voiceover subtitle subtitles slideshow explainer vlog
                  keywords: video movie animation narration captions presenter character lipsync footage clip short youtube
                  negative-keywords: play watch listen stream song music trailer download
                ---

                # Video Studio

                The Video Studio scripts could not be unpacked from the app. Reinstall this built-in skill from Settings, Skills, Built-in skills, then ask again.
            """.trimIndent(),
        ),
    )

    fun byId(id: String): BuiltInSkill? = all.firstOrNull { it.id == id }
}
