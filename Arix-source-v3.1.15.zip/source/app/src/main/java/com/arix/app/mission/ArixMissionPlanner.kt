package com.arix.app.mission

import org.json.JSONArray
import org.json.JSONObject

object ArixMissionPlanner {

    data class PlannedStep(
        val description: String,
        val requiredCapability: String,
        val instruction: String = "",
        val dependsOn: List<String> = emptyList(),
        val priority: Int = 5,
        val mutating: Boolean = false,
        val requiresVerification: Boolean = true,
    ) {
        fun toTask(): MissionTask = MissionTask(
            description = description,
            requiredCapability = requiredCapability,
            instruction = instruction,
            dependsOn = dependsOn,
            priority = priority,
            mutating = mutating,
            requiresVerification = requiresVerification,
        )
    }

    data class PlanResult(
        val steps: List<PlannedStep>,
        val understanding: String,
        val planner: String,
    )

    internal fun planningPrompt(objective: String): String = buildString {
        append("You are the Arix mission planner. Break the user objective into an executable task graph.\n")
        append("Reply with ONLY a JSON object: {\"understanding\": string, \"steps\": [{\"description\": string, ")
        append("\"capability\": string, \"instruction\": string, \"depends_on\": string[], \"mutating\": bool}]}\n")
        append("Rules:\n")
        append("- 1-8 steps; each step is independently checkable.\n")
        append("- Steps with no shared dependency run in PARALLEL — split independent research parts.\n")
        append("- depends_on uses step keys you assign implicitly by order: s1, s2, ...\n")
        append("- capability MUST be one of: ")
        append(
            (ArixToolRouter.registry.map { it.capability }.distinct() +
                PlanValidator.OpenCapabilities).distinct().sorted().joinToString(", "),
        )
        append(".\n")
        append("- mutating=true only for steps that change state (files, device, payments).\n")
        append("- The LAST step must produce the final answer/artifact for the user.\n\n")
        append("OBJECTIVE: ")
        append(objective)
    }

    suspend fun planWithModel(
        objective: String,
        modelComplete: suspend (String) -> String?,
    ): PlanResult? {
        val raw = runCatching {
            modelComplete(planningPrompt(objective))
        }.getOrNull() ?: return null
        val cleaned = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val json = runCatching { JSONObject(cleaned) }.getOrNull() ?: return null
        val stepsArray = json.optJSONArray("steps") ?: return null
        data class AcceptedStep(val arrayIndex: Int, val step: PlannedStep)
        val accepted = mutableListOf<AcceptedStep>()
        for (index in 0 until stepsArray.length()) {
            val step = stepsArray.optJSONObject(index) ?: continue
            val capability = step.optString("capability").trim().lowercase()
            if (ArixToolRouter.registry.none { it.capability == capability } &&
                capability !in PlanValidator.OpenCapabilities
            ) continue
            accepted.add(
                AcceptedStep(
                    arrayIndex = index,
                    step = PlannedStep(
                        description = step.optString("description").trim().ifBlank { "Step s${index + 1}" },
                        requiredCapability = capability,
                        instruction = step.optString("instruction").trim(),
                        mutating = step.optBoolean("mutating", false),
                    ),
                ),
            )
        }
        if (accepted.isEmpty()) return null
        val originalKeyToNewKey = accepted
            .mapIndexed { newIndex, rawStep -> "s${rawStep.arrayIndex + 1}" to "s${newIndex + 1}" }
            .toMap()
        val resolved = accepted.mapIndexed { newIndex, rawStep ->
            val depsArray = stepsArray.optJSONObject(rawStep.arrayIndex)?.optJSONArray("depends_on") ?: JSONArray()
            val deps = buildList {
                for (depIndex in 0 until depsArray.length()) {
                    val depKey = depsArray.optString(depIndex).trim().lowercase()
                    val newKey = originalKeyToNewKey[depKey]
                    if (newKey != null && newKey != "s${newIndex + 1}") add(newKey)
                }
            }
            rawStep.step.copy(dependsOn = deps)
        }
        val understanding = json.optString("understanding").trim().ifBlank { objective.take(200) }
        val result = PlanResult(steps = resolved, understanding = understanding, planner = "model")
        val tasks = resolved.mapIndexed { index, step -> step.toTask().copy(taskId = "s${index + 1}") }
        return if (PlanValidator.validate(tasks).valid) result else null
    }

    object PlanValidator {

        data class Validation(
            val valid: Boolean,
            val problems: List<String> = emptyList(),
        )

        fun validate(tasks: List<MissionTask>): Validation {
            val problems = mutableListOf<String>()
            if (tasks.isEmpty()) {
                return Validation(valid = false, problems = listOf("Plan is empty."))
            }
            if (tasks.size > ArixMissionContract.MAX_STEPS_HARD_CAP) {
                problems.add("Plan exceeds the ${ArixMissionContract.MAX_STEPS_HARD_CAP}-step hard cap.")
            }
            val ids = tasks.map { it.taskId }.toSet()
            tasks.forEach { task ->
                task.dependsOn.forEach { dep ->
                    if (dep !in ids) problems.add("Task '${task.taskId}' depends on unknown task '$dep'.")
                }
                if (task.taskId in task.dependsOn) {
                    problems.add("Task '${task.taskId}' depends on itself.")
                }
                if (ArixToolRouter.registry.none { it.capability == task.requiredCapability } &&
                    task.requiredCapability !in OpenCapabilities
                ) {
                    problems.add("Capability '${task.requiredCapability}' is not provided by any tool.")
                }
            }
            if (topologicalOrder(tasks) == null) {
                problems.add("Dependency graph contains a cycle.")
            }
            return Validation(valid = problems.isEmpty(), problems = problems)
        }

        fun topologicalOrder(tasks: List<MissionTask>): List<String>? {
            val byId = tasks.associateBy { it.taskId }
            val indegree = tasks.associate { it.taskId to it.dependsOn.count { dep -> byId.containsKey(dep) } }
                .toMutableMap()
            val dependents = HashMap<String, MutableList<String>>()
            tasks.forEach { task ->
                task.dependsOn.forEach { dep ->
                    dependents.getOrPut(dep) { mutableListOf() }.add(task.taskId)
                }
            }
            val queue = ArrayDeque(tasks.filter { (indegree[it.taskId] ?: 0) == 0 }.map { it.taskId })
            val order = mutableListOf<String>()
            while (queue.isNotEmpty()) {
                val id = queue.removeFirst()
                order.add(id)
                dependents[id]?.forEach { next ->
                    val remaining = (indegree[next] ?: 0) - 1
                    indegree[next] = remaining
                    if (remaining == 0) queue.addLast(next)
                }
            }
            return if (order.size == tasks.size) order else null
        }

        fun parallelLevels(tasks: List<MissionTask>): List<List<MissionTask>> {
            val byId = tasks.associateBy { it.taskId }
            val resolved = mutableSetOf<String>()
            val levels = mutableListOf<List<MissionTask>>()
            val pending = tasks.sortedByDescending { it.priority }.toMutableList()
            var guard = 0
            while (pending.isNotEmpty() && guard < tasks.size + 2) {
                val level = mutableListOf<MissionTask>()
                val iterator = pending.iterator()
                while (iterator.hasNext()) {
                    val task = iterator.next()
                    val depsReady = task.dependsOn.all { dep ->
                        byId[dep]?.let { it.taskId in resolved } ?: true
                    }
                    if (depsReady) {
                        level.add(task)
                        iterator.remove()
                    }
                }
                if (level.isEmpty()) break
                levels.add(level)
                level.forEach { resolved.add(it.taskId) }
                guard += 1
            }
            if (pending.isNotEmpty()) {
                levels.add(pending.toList())
            }
            return levels
        }

        val OpenCapabilities = setOf(
            "web_research",
            "analysis",
            "document_composition",
            "device_observe",
        )
    }
}
