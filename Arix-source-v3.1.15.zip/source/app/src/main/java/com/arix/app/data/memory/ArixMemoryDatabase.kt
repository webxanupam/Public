package com.arix.app.data.memory

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Fts4
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase

@Entity(
    tableName = "memories",
    indices = [
        Index("tier"),
        Index("projectId"),
        Index("sessionId"),
        Index("updatedAtMillis"),
        Index(value = ["contentHash"], unique = false),
    ],
)
data class MemoryEntryEntity(
    @PrimaryKey(autoGenerate = true) val rowId: Long = 0L,
    val id: String,
    val tier: String,
    val content: String,
    val tagsCsv: String,
    val sessionId: String?,
    val projectId: String?,
    val source: String,
    val importance: Int,
    val createdAtMillis: Long,
    val updatedAtMillis: Long,
    val expiresAtMillis: Long?,
    val lastAccessAtMillis: Long,
    val accessCount: Int,
    val contentHash: String,
)

@Fts4(contentEntity = MemoryEntryEntity::class)
@Entity(tableName = "memories_fts")
data class MemoryFtsEntity(
    val content: String,
    val tagsCsv: String,
)

@Dao
interface ArixMemoryDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entry: MemoryEntryEntity): Long

    @Query("DELETE FROM memories WHERE id = :id")
    suspend fun deleteById(id: String): Int

    @Query("SELECT * FROM memories WHERE id = :id LIMIT 1")
    suspend fun findById(id: String): MemoryEntryEntity?

    @Query("SELECT * FROM memories WHERE contentHash = :hash AND tier = :tier LIMIT 1")
    suspend fun findByHash(tier: String, hash: String): MemoryEntryEntity?

    @Query("SELECT * FROM memories")
    fun allBlocking(): List<MemoryEntryEntity>

    @Query(
        "SELECT memories.* FROM memories JOIN memories_fts ON memories.rowId = memories_fts.rowid " +
            "WHERE memories_fts MATCH :ftsQuery LIMIT :limit",
    )
    fun searchFtsBlocking(ftsQuery: String, limit: Int): List<MemoryEntryEntity>

    @Query(
        "SELECT * FROM memories WHERE content LIKE '%' || :token || '%' OR tagsCsv LIKE '%' || :token || '%' LIMIT :limit",
    )
    fun searchLikeBlocking(token: String, limit: Int): List<MemoryEntryEntity>

    @Query("SELECT tier, COUNT(*) as count FROM memories GROUP BY tier")
    fun tierCountsBlocking(): List<TierCountRow>

    @Query("UPDATE memories SET lastAccessAtMillis = :now, accessCount = accessCount + 1 WHERE id = :id")
    suspend fun touch(id: String, now: Long)

    @Query(
        "DELETE FROM memories WHERE expiresAtMillis IS NOT NULL AND expiresAtMillis < :now",
    )
    fun sweepExpiredBlocking(now: Long): Int

    @Query("DELETE FROM memories WHERE tier = 'ephemeral' AND updatedAtMillis < :staleBefore")
    fun sweepStaleEphemeralBlocking(staleBefore: Long): Int

    @Query("SELECT COUNT(*) FROM memories")
    fun countBlocking(): Int
}

data class TierCountRow(
    val tier: String,
    val count: Int,
)

@Database(
    entities = [MemoryEntryEntity::class, MemoryFtsEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class ArixMemoryDatabase : RoomDatabase() {
    abstract fun memoryDao(): ArixMemoryDao

    companion object {
        const val DatabaseName = "arix_memory_v2.db"
    }
}
