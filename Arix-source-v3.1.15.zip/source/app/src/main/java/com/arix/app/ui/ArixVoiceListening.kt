package com.arix.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.arix.app.R
import com.arix.app.ui.theme.ArixError
import com.arix.app.ui.theme.ArixOnSurface
import com.arix.app.ui.theme.ArixOnSurfaceVariant
import com.arix.app.ui.theme.ArixOutline
import com.arix.app.ui.theme.ArixPrimary
import com.arix.app.ui.theme.ArixTertiary
import com.arix.app.voice.ArixSpeechRecognitionController
import kotlin.math.abs
import kotlin.math.sin

@Composable
internal fun ArixComposerVoiceListening(
    isListening: Boolean,
    partialText: String,
    errorText: String?,
    modifier: Modifier = Modifier,
    onStopAndSend: () -> Unit,
    onCancel: () -> Unit,
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(2.dp),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            ListeningMicIndicator(isListening = isListening)
            Spacer(Modifier.width(10.dp))
            ArixVoiceWaveform(
                rmsProvider = { ArixSpeechRecognitionController.rmsLevel },
                listeningProvider = { isListening },
                modifier = Modifier
                    .weight(1f)
                    .height(34.dp),
            )
            Spacer(Modifier.width(8.dp))
            ListeningActionButton(
                icon = Icons.Rounded.ArrowUpward,
                contentDescription = stringResource(R.string.voice_send_now),
                emphasized = true,
                onClick = onStopAndSend,
            )
            Spacer(Modifier.width(6.dp))
            ListeningActionButton(
                icon = Icons.Rounded.Close,
                contentDescription = stringResource(R.string.common_cancel),
                emphasized = false,
                onClick = onCancel,
            )
        }
        AnimatedVisibility(
            visible = errorText != null || partialText.isNotBlank(),
            enter = fadeIn(tween(120, easing = LinearEasing)),
            exit = fadeOut(tween(120, easing = LinearEasing)),
        ) {
            Text(
                text = errorText ?: partialText,
                style = MaterialTheme.typography.bodyMedium,
                color = if (errorText != null) ArixError else ArixOnSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 2.dp, end = 2.dp, bottom = 2.dp),
            )
        }
        if (errorText == null && partialText.isBlank() && isListening) {
            Text(
                text = stringResource(R.string.voice_speak_to_send),
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant.copy(alpha = 0.75f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 2.dp, end = 2.dp, bottom = 2.dp),
            )
        }
    }
}

@Composable
private fun ListeningMicIndicator(isListening: Boolean) {
    val pulse = remember { Animatable(1f) }
    LaunchedEffect(isListening) {
        if (isListening) {
            while (true) {
                pulse.animateTo(
                    1.14f,
                    ArixMotion.sheetSpring(dampingRatio = 0.75f, stiffness = 240f),
                )
                pulse.animateTo(
                    0.96f,
                    ArixMotion.sheetSpring(dampingRatio = 0.75f, stiffness = 240f),
                )
            }
        } else {
            pulse.snapTo(1f)
        }
    }
    Box(
        modifier = Modifier.size(34.dp),
        contentAlignment = Alignment.Center,
    ) {
        val pulseValue = { pulse.value }
        Box(
            modifier = Modifier
                .size(26.dp)
                .graphicsLayer {
                    val scale = pulseValue()
                    scaleX = scale
                    scaleY = scale
                    transformOrigin = TransformOrigin.Center
                }
                .clip(CircleShape)
                .background(
                    Brush.linearGradient(listOf(ArixPrimary, ArixTertiary)),
                ),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = Icons.Rounded.Mic,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(15.dp),
            )
        }
    }
}

@Composable
private fun ListeningActionButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    emphasized: Boolean,
    onClick: () -> Unit,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val scale = remember { Animatable(1f) }
    LaunchedEffect(pressed) {
        scale.animateTo(
            if (pressed) 0.88f else 1f,
            ArixMotion.controlSpring(),
        )
    }
    Box(
        modifier = Modifier
            .size(40.dp)
            .graphicsLayer {
                val s = scale.value
                scaleX = s
                scaleY = s
            }
            .clip(CircleShape)
            .background(
                if (emphasized) {
                    Brush.linearGradient(listOf(ArixPrimary, ArixTertiary))
                } else {
                    Brush.linearGradient(
                        listOf(ArixOutline.copy(alpha = 0.18f), ArixOutline.copy(alpha = 0.18f)),
                    )
                },
            )
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = if (emphasized) Color.White else ArixOnSurface,
            modifier = Modifier.size(19.dp),
        )
    }
}

@Composable
internal fun ArixVoiceWaveform(
    rmsProvider: () -> Float,
    listeningProvider: () -> Boolean,
    modifier: Modifier = Modifier,
) {
    val density = androidx.compose.ui.platform.LocalDensity.current
    val phase = remember { mutableFloatStateOf(0f) }
    val envelope = remember { mutableFloatStateOf(0f) }

    LaunchedEffect(Unit) {
        var lastFrameNanos = 0L
        while (true) {
            withFrameNanos { frameNanos ->
                if (lastFrameNanos != 0L) {
                    val deltaSeconds = (frameNanos - lastFrameNanos) / 1_000_000_000f
                    phase.floatValue += deltaSeconds
                }
                lastFrameNanos = frameNanos
            }
        }
    }

    val barWidthPx = with(density) { 3.5f.dp.toPx() }
    val gapPx = with(density) { 3.dp.toPx() }
    val minBarHeightPx = with(density) { 5.dp.toPx() }
    val maxExtraHeightPx = with(density) { 24.dp.toPx() }

    Canvas(modifier = modifier) {
        val t = phase.floatValue
        val listening = listeningProvider()
        val target = (rmsProvider().coerceIn(0f, 12f) / 12f).let { raw ->
            if (listening) raw else 0f
        }
        val attack = if (target > envelope.floatValue) 0.55f else 0.16f
        envelope.floatValue += (target - envelope.floatValue) * attack
        val amp = envelope.floatValue

        val slot = barWidthPx + gapPx
        val barCount = ((size.width + gapPx) / slot).toInt().coerceIn(5, 56)
        val usableWidth = barCount * slot - gapPx
        val startLeft = (size.width - usableWidth) / 2f
        val centerY = size.height / 2f

        val glowColor = ArixPrimary
        drawRoundRect(
            brush = Brush.horizontalGradient(
                colors = listOf(
                    Color.Transparent,
                    glowColor.copy(alpha = 0.04f + 0.16f * amp),
                    glowColor.copy(alpha = 0.06f + 0.22f * amp),
                    glowColor.copy(alpha = 0.04f + 0.16f * amp),
                    Color.Transparent,
                ),
                startX = 0f,
                endX = size.width,
            ),
            topLeft = Offset(0f, centerY - minBarHeightPx - maxExtraHeightPx * 0.55f),
            size = Size(size.width, (minBarHeightPx + maxExtraHeightPx) * 1.1f),
            cornerRadius = CornerRadius(size.height / 2f),
        )

        val sweepCenter = ((t * 0.55f) % 2f).let { phase01 -> if (phase01 > 1f) 2f - phase01 else phase01 }
        val sweepX = sweepCenter * size.width

        for (index in 0 until barCount) {
            val left = startLeft + index * slot
            val center = (barCount - 1) / 2f
            val distance = if (center > 0f) abs(index - center) / center else 0f

            val wave = (
                sin(t * 5.2f + index * 0.62f) * 0.62f +
                    sin(t * 3.1f + index * 1.41f) * 0.38f
                ) * 0.5f + 0.5f

            val idleBreath = 0.16f + 0.1f * sin(t * 2.1f + index * 0.5f)
            val shape = 1f - 0.58f * distance
            val level = (amp * shape * (0.34f + 0.66f * wave)) + idleBreath * (1f - amp)
            val barHeight = (
                minBarHeightPx + level.coerceIn(0f, 1f) * maxExtraHeightPx
                ).coerceAtLeast(minBarHeightPx)

            val top = centerY - barHeight / 2f
            val barColor = lerpColor(ArixPrimary, ArixTertiary, index / (barCount - 1f).coerceAtLeast(1f))

            val distToSweep = abs((left + barWidthPx / 2f) - sweepX)
            val specular = (1f - (distToSweep / (size.width * 0.18f)).coerceIn(0f, 1f)).coerceIn(0f, 1f)

            drawRoundRect(
                color = barColor.copy(alpha = (0.55f + 0.4f * amp + 0.18f * specular).coerceIn(0f, 1f)),
                topLeft = Offset(left, top),
                size = Size(barWidthPx, barHeight),
                cornerRadius = CornerRadius(barWidthPx / 2f),
            )
        }
    }
}

private fun lerpColor(from: Color, to: Color, fraction: Float): Color =
    Color(
        red = androidx.compose.ui.util.lerp(from.red, to.red, fraction),
        green = androidx.compose.ui.util.lerp(from.green, to.green, fraction),
        blue = androidx.compose.ui.util.lerp(from.blue, to.blue, fraction),
        alpha = 1f,
    )
@Composable
internal fun rememberVoiceHandsFreeEngine(
    active: Boolean,
    onSettled: (String) -> Unit,
    onSilenceStopRequested: () -> Unit,
) {
    val settledHandler by androidx.compose.runtime.rememberUpdatedState(onSettled)
    val silenceHandler by androidx.compose.runtime.rememberUpdatedState(onSilenceStopRequested)
    LaunchedEffect(active) {
        if (!active) return@LaunchedEffect
        var everListened = false
        var sentForThisUtterance = false
        while (true) {
            kotlinx.coroutines.delay(EnginePollMillis)
            val now = android.os.SystemClock.elapsedRealtime()
            val controller = ArixSpeechRecognitionController
            if (controller.isListening) {
                everListened = true
                sentForThisUtterance = false
                if (
                    controller.heardSpeech &&
                    now - controller.lastVoiceActivityAtMs > VoiceSilenceStopMillis
                ) {
                    silenceHandler()
                }
            } else if (everListened && !sentForThisUtterance) {
                var settled = controller.finalText
                if (settled.isBlank()) {
                    val settleDeadline = now + LateFinalWaitMillis
                    while (settled.isBlank() && android.os.SystemClock.elapsedRealtime() < settleDeadline) {
                        kotlinx.coroutines.delay(40)
                        settled = controller.finalText
                    }
                    if (settled.isBlank()) settled = controller.partialText
                }
                if (settled.isNotBlank()) {
                    sentForThisUtterance = true
                    settledHandler(settled)
                }
                everListened = false
            }
        }
    }
}

internal val EnginePollMillis = 50L

internal val VoiceSilenceStopMillis = 800L

internal val LateFinalWaitMillis = 700L

@Composable
internal fun rememberVoiceRecognitionSession(active: Boolean) {
    val context = LocalContext.current
    DisposableEffect(active) {
        if (active) {
            ArixSpeechRecognitionController.start(context) { }
        }
        onDispose {
            if (active) {
                ArixSpeechRecognitionController.cancel()
            }
        }
    }
}
