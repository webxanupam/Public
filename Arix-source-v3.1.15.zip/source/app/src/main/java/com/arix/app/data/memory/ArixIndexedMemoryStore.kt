package com.arix.app.data.memory

import android.content.Context
import androidx.room.Room
import com.arix.app.data.ArixMemoryManager
import com.arix.app.data.ArixMemoryManager.Tier
import java.io.File
import java.security.MessageDigest
import java.util.Locale
import java.util.UUID
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class ArixIndexedMemoryStore(
    context: Context,
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO),
    private val nowMillis: () -> Long = System::currentTimeMillis,
) {

    private val appContext = context.applicationContext

    @Volatile
    internal var daoOverride: ArixMemoryDao? = null

    internal fun overrideDaoForTest(dao: ArixMemoryDao) {
        daoOverride = dao
    }

    internal suspend fun overrideEntriesForTest(entries: List<MemoryEntryEntity>) {
        allEntries().forEach { dao.deleteById(it.id) }
        entries.forEach { dao.upsert(it) }
    }

    private val dao: ArixMemoryDao
        get() = daoOverride ?: builtDao

    private val builtDao: ArixMemoryDao by lazy {
        Room.databaseBuilder(appContext, ArixMemoryDatabase::class.java, ArixMemoryDatabase.DatabaseName)
            .build()
            .memoryDao()
    }

    data class RankedEntry(
        val entity: MemoryEntryEntity,
        val score: Double,
    )

    data class RememberOutcome(val id: String, val updated: Boolean, val supersededId: String?)

    suspend fun remember(
        tier: Tier,
        content: String,
        tags: List<String> = emptyList(),
        importance: Int = tier.defaultImportance,
        sessionId: String? = null,
        projectId: String? = null,
        source: String = "agent",
        expiresAtMillis: Long? = defaultExpiry(tier),
    ): RememberOutcome {
        val normalized = content.trim()
        val hash = contentHash(normalized)
        val existing = dao.findByHash(tier.storageValue, hash)
        if (existing != null) {
            dao.upsert(
                existing.copy(
                    tagsCsv = mergeTags(existing.tagsCsv, tags),
                    importance = importance.coerceIn(1, 5),
                    updatedAtMillis = nowMillis(),
                    lastAccessAtMillis = nowMillis(),
                    projectId = projectId ?: existing.projectId,
                    expiresAtMillis = expiresAtMillis ?: existing.expiresAtMillis,
                ),
            )
            return RememberOutcome(id = existing.id, updated = true, supersededId = null)
        }
        val superseded = findContradicting(tier, normalized, tags)
        if (superseded != null) {
            dao.upsert(superseded.copy(expiresAtMillis = nowMillis()))
        }
        val entry = MemoryEntryEntity(
            id = UUID.randomUUID().toString().substring(0, 12),
            tier = tier.storageValue,
            content = normalized,
            tagsCsv = tags.distinct().joinToString(","),
            sessionId = sessionId,
            projectId = projectId,
            source = source,
            importance = importance.coerceIn(1, 5),
            createdAtMillis = nowMillis(),
            updatedAtMillis = nowMillis(),
            expiresAtMillis = expiresAtMillis,
            lastAccessAtMillis = nowMillis(),
            accessCount = 1,
            contentHash = hash,
        )
        dao.upsert(entry)
        return RememberOutcome(id = entry.id, updated = false, supersededId = superseded?.id)
    }

    fun rankedSearch(
        query: String,
        sessionId: String? = null,
        tier: Tier? = null,
        projectId: String? = null,
        limit: Int = 8,
    ): List<RankedEntry> {
        if (query.isBlank()) return emptyList()
        val tokens = tokenize(query)
        val candidates = ftsCandidates(query, tokens, candidateLimit = 512)
            .let { list -> if (tier == null) list else list.filter { it.tier == tier.storageValue } }
        val now = nowMillis()
        val scored = candidates.mapNotNull { entry ->
            val score = scoreEntry(entry, tokens, sessionId, projectId, now) ?: return@mapNotNull null
            RankedEntry(entry, score)
        }.sortedByDescending { it.score }
            .take(limit.coerceIn(1, MaxSearchLimit))
        if (scored.isNotEmpty()) {
            scope.launch {
                runCatching { scored.forEach { dao.touch(it.entity.id, nowMillis()) } }
            }
        }
        return scored
    }

    fun allEntries(): List<MemoryEntryEntity> = runCatching { dao.allBlocking() }.getOrDefault(emptyList())

    fun stats(): Map<String, Int> = runCatching {
        dao.tierCountsBlocking().associate { it.tier to it.count }
    }.getOrDefault(emptyMap())

    fun count(): Int = runCatching { dao.countBlocking() }.getOrDefault(0)

    fun sweep(): Int = runCatching {
        val now = nowMillis()
        dao.sweepExpiredBlocking(now) + dao.sweepStaleEphemeralBlocking(now - EphemeralLifetimeMillis)
    }.getOrDefault(0)

    suspend fun deleteById(id: String): Boolean = dao.findById(id)?.let { dao.deleteById(id) > 0 } ?: false

    suspend fun deleteMatching(tier: Tier?, query: String): Int {
        val tokens = tokenize(query)
        val matches = allEntries().filter { entry ->
            (tier == null || entry.tier == tier.storageValue) &&
                (query.isBlank() || entryContains(entry, tokens))
        }
        matches.forEach { dao.deleteById(it.id) }
        return matches.size
    }

    suspend fun migrateLegacyJsonIfPresent(filesDir: File): Int {
        val legacyFile = File(filesDir, "arix_memory.json")
        if (!legacyFile.isFile) return 0
        val raw = runCatching { legacyFile.readText() }.getOrNull() ?: return 0
        val entriesArray = runCatching {
            runCatching { JSONObject(raw) }.getOrNull()?.optJSONArray("entries")
                ?: runCatching { JSONArray(raw) }.getOrNull()
        }.getOrNull() ?: run {
            runCatching { legacyFile.renameTo(File(filesDir, "arix_memory.json.corrupt")) }
            return 0
        }
        var imported = 0
        for (index in 0 until entriesArray.length()) {
            val json = entriesArray.optJSONObject(index) ?: continue
            val tier = Tier.fromStorageValue(json.optString("tier")) ?: continue
            val content = json.optString("content").trim()
            if (content.isEmpty()) continue
            remember(
                tier = tier,
                content = content,
                tags = parseTags(json.optJSONArray("tags")),
                importance = json.optInt("importance", tier.defaultImportance),
                sessionId = json.optString("session_id").takeIf { it.isNotBlank() },
                source = "legacy-migration",
            )
            imported += 1
        }
        runCatching { legacyFile.renameTo(File(filesDir, "arix_memory.json.migrated")) }
        return imported
    }

    private fun scoreEntry(
        entry: MemoryEntryEntity,
        queryTokens: Set<String>,
        sessionId: String?,
        projectId: String?,
        now: Long,
    ): Double? {
        val entryTokens = tokenize("${entry.content} ${entry.tagsCsv}")
        if (entryTokens.isEmpty()) return null
        val overlap = queryTokens.count { it in entryTokens }
        if (overlap == 0) return null
        var score = overlap * 2.0 + entry.importance
        val ageDays = ((now - entry.updatedAtMillis) / MillisPerDay).coerceAtLeast(0)
        score += 2.0 / (1.0 + ageDays / 30.0)
        if (sessionId != null && entry.tier == Tier.CONVERSATION.storageValue && entry.sessionId == sessionId) {
            score += 2.0
        }
        if (projectId != null && entry.projectId == projectId) {
            score += 1.5
        }
        score += 0.1 * entry.accessCount.coerceAtMost(20)
        return score
    }

    private fun ftsCandidates(query: String, tokens: Set<String>, candidateLimit: Int): List<MemoryEntryEntity> {
        val ftsQuery = buildFtsQuery(tokens)
        if (ftsQuery.isNotBlank()) {
            runCatching { dao.searchFtsBlocking(ftsQuery, candidateLimit) }.getOrNull()
                ?.takeIf { it.isNotEmpty() }
                ?.let { return it }
        }
        val unioned = LinkedHashSet<MemoryEntryEntity>()
        tokens.forEach { token ->
            runCatching { dao.searchLikeBlocking(token, candidateLimit) }
                .getOrDefault(emptyList())
                .forEach { unioned.add(it) }
        }
        return unioned.toList()
    }

    private fun findContradicting(
        tier: Tier,
        normalizedContent: String,
        tags: List<String>,
    ): MemoryEntryEntity? {
        if (tags.isEmpty()) return null
        val candidates = rankedSearch(
            query = normalizedContent.take(120),
            tier = tier,
            limit = 12,
        ).map { it.entity }
        val newTokens = tokenize(normalizedContent)
        val newTags = tags.map { it.lowercase(Locale.US) }.toSet()
        return candidates.firstOrNull { candidate ->
            val candidateTags = candidate.tagsCsv.split(',').map { it.trim().lowercase(Locale.US) }.filter { it.isNotEmpty() }
            val tagOverlap = newTags.intersect(candidateTags.toSet())
            if (tagOverlap.isEmpty()) return@firstOrNull false
            val candidateTokens = tokenize(candidate.content)
            val union = newTokens union candidateTokens
            val intersection = newTokens intersect candidateTokens
            val jaccard = if (union.isEmpty()) 0.0 else intersection.size.toDouble() / union.size
            jaccard in 0.35..0.85
        }
    }

    private fun mergeTags(existingCsv: String, newTags: List<String>): String =
        (existingCsv.split(',').map { it.trim() }.filter { it.isNotEmpty() } + newTags)
            .distinct()
            .take(MaxTagsPerEntry)
            .joinToString(",")

    companion object {
        const val MaxSearchLimit = 25
        const val MaxTagsPerEntry = 12
        const val MillisPerDay = 24L * 60 * 60 * 1000
        const val EphemeralLifetimeMillis = 24L * 60 * 60 * 1000

        fun defaultExpiry(tier: Tier): Long? = when (tier) {
            Tier.EPHEMERAL -> null
            else -> null
        }

        fun contentHash(normalizedContent: String): String {
            val digest = MessageDigest.getInstance("SHA-256")
            return digest.digest(normalizedContent.lowercase(Locale.US).toByteArray(Charsets.UTF_8))
                .joinToString("") { "%02x".format(it) }
                .take(24)
        }

        fun tokenize(text: String): Set<String> =
            text.lowercase(Locale.US)
                .split(Regex("[^a-z0-9\\u4e00-\\u9fff]+"))
                .filter { it.length >= 2 }
                .toSet()

        private fun entryContains(entry: MemoryEntryEntity, tokens: Set<String>): Boolean {
            val entryTokens = tokenize("${entry.content} ${entry.tagsCsv}")
            return tokens.any { it in entryTokens }
        }

        private fun parseTags(array: JSONArray?): List<String> {
            if (array == null) return emptyList()
            return buildList {
                for (index in 0 until array.length()) {
                    array.optString(index).trim().takeIf { it.isNotEmpty() }?.let(::add)
                }
            }
        }

        internal fun buildFtsQuery(tokens: Set<String>): String = tokens
            .filter { token -> token.all { it.isLetterOrDigit() } }
            .take(8)
            .joinToString(" OR ") { token -> "$token*" }
    }
}

fun MemoryEntryEntity.toLegacyEntry(): ArixMemoryManager.ArixMemoryEntry = ArixMemoryManager.ArixMemoryEntry(
    id = id,
    tier = Tier.fromStorageValue(tier) ?: Tier.PERSONAL,
    content = content,
    tags = tagsCsv.split(',').map { it.trim() }.filter { it.isNotEmpty() },
    sessionId = sessionId,
    createdAtMillis = createdAtMillis,
    updatedAtMillis = updatedAtMillis,
    importance = importance,
)
