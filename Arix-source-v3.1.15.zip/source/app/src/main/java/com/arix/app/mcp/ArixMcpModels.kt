package com.arix.app.mcp

import org.json.JSONArray
import org.json.JSONObject

data class ArixMcpServerConfig(
    val name: String,
    val url: String? = null,
    val headers: Map<String, String> = emptyMap(),
    val command: String? = null,
    val args: List<String> = emptyList(),
    val env: Map<String, String> = emptyMap(),
    val enabled: Boolean = true,
    val disabledTools: Set<String> = emptySet(),
    val oauth: ArixMcpOAuthConfig? = null,
) {
    val isStdio: Boolean get() = !command.isNullOrBlank()

    fun toJson(): JSONObject = JSONObject().apply {
        if (isStdio) {
            put("command", command)
            if (args.isNotEmpty()) put("args", JSONArray(args))
            if (env.isNotEmpty()) {
                put("env", JSONObject().apply { env.forEach { (k, v) -> put(k, v) } })
            }
        } else {
            put("url", url.orEmpty())
            if (headers.isNotEmpty()) {
                put("headers", JSONObject().apply { headers.forEach { (k, v) -> put(k, v) } })
            }
        }
        put("enabled", enabled)
        if (disabledTools.isNotEmpty()) {
            put("disabledTools", JSONArray(disabledTools))
        }
        oauth?.let { put("oauth", it.toJson()) }
    }

    companion object {
        private val NAME_REGEX = Regex("[a-zA-Z0-9_-]+")

        fun isValidName(name: String): Boolean = NAME_REGEX.matches(name)

        fun fromJson(name: String, json: JSONObject): ArixMcpServerConfig {
            val command = json.optString("command").trim().takeIf { it.isNotEmpty() }
            val url = json.optString("url").trim().takeIf { it.isNotEmpty() }
            val headers = mutableMapOf<String, String>()
            json.optJSONObject("headers")?.let { headerObject ->
                headerObject.keys().forEach { key ->
                    headers[key] = headerObject.optString(key)
                }
            }
            val args = mutableListOf<String>()
            json.optJSONArray("args")?.let { array ->
                for (index in 0 until array.length()) {
                    array.optString(index).takeIf { it.isNotEmpty() }?.let(args::add)
                }
            }
            val env = mutableMapOf<String, String>()
            json.optJSONObject("env")?.let { envObject ->
                envObject.keys().forEach { key -> env[key] = envObject.optString(key) }
            }
            val disabled = mutableSetOf<String>()
            json.optJSONArray("disabledTools")?.let { array ->
                for (index in 0 until array.length()) {
                    array.optString(index).takeIf { it.isNotEmpty() }?.let(disabled::add)
                }
            }
            return ArixMcpServerConfig(
                name = name,
                url = url,
                headers = headers,
                command = command,
                args = args,
                env = env,
                enabled = json.optBoolean("enabled", true),
                disabledTools = disabled,
                oauth = json.optJSONObject("oauth")?.let(ArixMcpOAuthConfig::fromJson),
            )
        }
    }
}

data class ArixMcpToolDescriptor(
    val name: String,
    val description: String? = null,
    val inputSchema: JSONObject? = null,
) {
    companion object {
        fun fromJson(json: JSONObject): ArixMcpToolDescriptor = ArixMcpToolDescriptor(
            name = json.optString("name"),
            description = json.optString("description").takeIf { it.isNotEmpty() },
            inputSchema = json.optJSONObject("inputSchema"),
        )
    }
}

data class ArixMcpCallResult(
    val text: String,
    val isError: Boolean,
    val images: List<Pair<String, String>> = emptyList(),
)

data class ArixMcpServerStatus(
    val name: String,
    val state: State,
    val toolCount: Int = 0,
    val error: String? = null,
) {
    enum class State { CONNECTING, CONNECTED, FAILED, DISABLED }
}
