package com.arix.app.agent.a11y

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.os.Build
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * Arix's accessibility service (ported from Mika's ScreenAccessibility — Apache-2.0).
 * Operations and events are forwarded to the currently connected instance, so a task
 * holding an older instance recovers after a service reconnect.
 *
 * The agent uses it to READ the virtual display (node tree text + clickable elements)
 * and to dispatch gestures on a specific display; input injection on the background
 * screen primarily goes through the shell helper ([com.arix.app.agent.shell.IArixShell]).
 */
open class ScreenAccessibility : AccessibilityService() {

    private class DisplayEvent(val displayId: Int, val event: AccessibilityEvent)

    override fun onServiceConnected() {
        super.onServiceConnected()
        // Many apps mark result text controls as "not important for accessibility";
        // without reading them the agent cannot see results. Declared in the config
        // file, applied again at runtime in case the system kept an old config.
        serviceInfo?.let { info ->
            if (info.flags and AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS == 0) {
                info.flags = info.flags or AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
                serviceInfo = info
            }
        }
        _instance.value = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        clearInstance()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        clearInstance()
        super.onDestroy()
    }

    private fun clearInstance() {
        _instance.compareAndSet(this, null)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (instance.value !== this) return
        if (event.eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED) windowChanges.tryEmit(Unit)
        if (event.eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
        ) {
            windowGeneration.incrementAndGet()
        }
        // Nobody subscribed: don't copy, don't look up the display (events are dense).
        if (events.subscriptionCount.value == 0) return
        val displayId = displayOf(event)
        if (displayId == Display.INVALID_DISPLAY) return
        // Below API 33 the system recycles the event object after the callback
        // returns; copy it before subscribers read it asynchronously.
        events.tryEmit(DisplayEvent(displayId, AccessibilityEvent(event)))
    }

    override fun onInterrupt() = Unit

    /** Windows on the given display; empty when the display has none (or is gone). */
    fun windowsOn(displayId: Int): List<AccessibilityWindowInfo> =
        instance.value?.windowsOnAllDisplays?.get(displayId).orEmpty()

    /** Root node of the active window on [displayId], or null. */
    fun rootOn(displayId: Int) = windowsOn(displayId)
        .firstOrNull { it.isActive && it.root != null }?.root
        ?: windowsOn(displayId).firstOrNull { it.root != null }?.root

    /** One-finger gesture along [path] on the given display; true when completed. */
    suspend fun gesture(displayId: Int, path: Path, durationMs: Long): Boolean =
        gesture(displayId, listOf(path), durationMs)

    suspend fun gesture(displayId: Int, paths: List<Path>, durationMs: Long): Boolean =
        dispatch(displayId, paths.map { GestureDescription.StrokeDescription(it, 0, durationMs.coerceAtLeast(1)) })

    /** [count] taps in one gesture at the same point: each held [holdMs], [gapMs] apart. */
    suspend fun taps(displayId: Int, x: Float, y: Float, count: Int, holdMs: Long, gapMs: Long): Boolean {
        val at = Path().apply { moveTo(x, y) }
        return dispatch(
            displayId,
            (0 until count).map { i ->
                GestureDescription.StrokeDescription(at, i * (holdMs + gapMs), holdMs.coerceAtLeast(1))
            },
        )
    }

    private suspend fun dispatch(displayId: Int, strokes: List<GestureDescription.StrokeDescription>): Boolean {
        val service = instance.value ?: return false
        val gesture = GestureDescription.Builder()
            .setDisplayId(displayId)
            .apply { strokes.forEach(::addStroke) }
            .build()
        return suspendCancellableCoroutine { cont ->
            val callback = object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription) {
                    if (cont.isActive) cont.resume(true)
                }

                override fun onCancelled(gestureDescription: GestureDescription) {
                    if (cont.isActive) cont.resume(false)
                }
            }
            if (!service.dispatchGesture(gesture, callback, null) && cont.isActive) cont.resume(false)
        }
    }

    /** Result of taking a screenshot of the user's main screen. */
    sealed interface MainShot {
        class Ok(val bitmap: Bitmap) : MainShot
        data object Secure : MainShot
        data class Failed(val code: Int) : MainShot
    }

    /**
     * Screenshot of the main screen (the one the user is looking at). The system
     * enforces a minimum interval between screenshots; when too fast, wait a second
     * and try once more. Returns a software bitmap (readable / encodable).
     */
    suspend fun takeMainScreenshot(): MainShot {
        val first = screenshotOnce()
        if (first !is MainShot.Failed || first.code != ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT) return first
        delay(SCREENSHOT_INTERVAL_MS)
        return screenshotOnce()
    }

    private suspend fun screenshotOnce(): MainShot = suspendCancellableCoroutine { cont ->
        val service = instance.value
        if (service == null) {
            cont.resume(MainShot.Failed(ERROR_TAKE_SCREENSHOT_NO_ACCESSIBILITY_ACCESS))
            return@suspendCancellableCoroutine
        }
        service.takeScreenshot(Display.DEFAULT_DISPLAY, service.mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                val shot = runCatching {
                    result.hardwareBuffer.use { buffer ->
                        val hw = Bitmap.wrapHardwareBuffer(buffer, result.colorSpace) ?: return@runCatching null
                        hw.copy(Bitmap.Config.ARGB_8888, false).also { hw.recycle() }
                    }
                }.getOrNull()
                if (cont.isActive) {
                    cont.resume(shot?.let(MainShot::Ok) ?: MainShot.Failed(ERROR_TAKE_SCREENSHOT_INTERNAL_ERROR))
                }
            }

            override fun onFailure(errorCode: Int) {
                // A secure (FLAG_SECURE) window on screen: Android 14+ has a dedicated
                // code; earlier systems return a black frame the caller can detect.
                val secure = Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE &&
                    errorCode == ERROR_TAKE_SCREENSHOT_SECURE_WINDOW
                if (cont.isActive) cont.resume(if (secure) MainShot.Secure else MainShot.Failed(errorCode))
            }
        })
    }

    /** Accessibility events that happened on the given display. The channel survives instance switches. */
    fun eventsFor(displayId: Int): Flow<AccessibilityEvent> =
        events.filter { it.displayId == displayId }.map { it.event }

    /** Signal that windows changed (added, removed, moved — including IME show/hide). */
    fun windowChanges(): Flow<Unit> = windowChanges

    /**
     * Which display an event happened on. API 33+ carries the display id on the event;
     * earlier systems are mapped through the window id across all displays.
     */
    private fun displayOf(event: AccessibilityEvent): Int {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) return event.displayId
        val windowId = event.windowId
        if (windowId == -1) return Display.INVALID_DISPLAY
        val all = windowsOnAllDisplays
        for (i in 0 until all.size()) {
            if (all.valueAt(i).any { it.id == windowId }) return all.keyAt(i)
        }
        return Display.INVALID_DISPLAY
    }

    companion object {
        private const val EVENT_BUFFER = 64
        private const val SCREENSHOT_INTERVAL_MS = 1_000L

        // Hot flows: subscribers subscribe UNDISPATCHED before acting, so a service
        // switch cannot open an async subscription window. Events are observational
        // only; when a subscriber can't keep up the oldest are dropped.
        private val events = MutableSharedFlow<DisplayEvent>(
            extraBufferCapacity = EVENT_BUFFER,
            onBufferOverflow = BufferOverflow.DROP_OLDEST,
        )
        private val windowChanges = MutableSharedFlow<Unit>(
            extraBufferCapacity = 1,
            onBufferOverflow = BufferOverflow.DROP_OLDEST,
        )
        private val windowGeneration = java.util.concurrent.atomic.AtomicLong()

        /** Bumped every time a window is added/removed/page-switched on any display. */
        fun windowGeneration(): Long = windowGeneration.get()

        private val _instance = MutableStateFlow<ScreenAccessibility?>(null)

        /** The connected service instance; null while the service is off or disconnected. */
        val instance: StateFlow<ScreenAccessibility?> = _instance.asStateFlow()
    }
}
