package com.arix.app.ui

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.GestureDetector
import android.view.MotionEvent
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.view.ViewCompat
import com.arix.app.ArixApplication
import com.arix.app.R
import com.arix.app.data.LocalRuntimeId
import com.arix.app.data.RuntimeWorkspaceFileBridge
import com.arix.app.data.WorkspaceFileBridge
import com.arix.app.ui.theme.ArixBackground
import com.arix.app.ui.theme.ArixOnSurface
import com.arix.app.ui.theme.ArixOnSurfaceVariant
import com.arix.app.ui.theme.ArixOutline
import com.arix.app.ui.theme.ArixOutlineSoft
import com.arix.app.ui.theme.ArixPrimary
import com.arix.app.ui.theme.ArixSecondary
import com.arix.app.ui.theme.ArixSurface
import com.arix.app.ui.theme.ArixSurfaceHigh
import com.arix.app.ui.theme.ArixSurfaceVariant
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.URLDecoder
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.util.Base64
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

internal const val LinkAnnotationTag = "url"

internal data class MarkdownSourceText(
    val text: String,
    val sourceOffset: Int,
)

internal data class MarkdownLine(
    val text: String,
    val startOffset: Int,
)

internal data class MarkdownImageSpec(
    val altText: String,
    val url: String,
    val layout: MarkdownMediaLayout = defaultMarkdownImageLayout(),
)

internal data class MarkdownAutoLinkMatch(
    val displayText: String,
    val targetUrl: String,
    val endExclusive: Int = displayText.length,
    val displayStartIndex: Int = 0,
)

internal data class MarkdownMediaLayout(
    val width: MarkdownMediaWidth? = null,
    val heightDp: Int? = null,
    val minHeightDp: Int? = null,
    val maxHeightDp: Int? = null,
    val fit: MarkdownMediaFit = MarkdownMediaFit.Contain,
    val scroll: Boolean = false,
    val showAll: Boolean = false,
)

internal sealed interface MarkdownMediaWidth {
    data class Fraction(val value: Float) : MarkdownMediaWidth
    data class DpValue(val value: Int) : MarkdownMediaWidth
}

internal enum class MarkdownMediaFit {
    Contain,
    Cover,
}

internal data class MarkdownCodeFenceHeader(
    val language: String,
    val attributes: Map<String, String>,
)

internal sealed interface MarkdownBlock {
    data class Paragraph(val text: MarkdownSourceText) : MarkdownBlock
    data class Heading(val level: Int, val text: MarkdownSourceText) : MarkdownBlock
    data class UnorderedList(val items: List<MarkdownSourceText>) : MarkdownBlock
    data class OrderedList(val items: List<MarkdownSourceText>) : MarkdownBlock
    data class Quote(val text: MarkdownSourceText) : MarkdownBlock
    data class Image(val image: MarkdownImageSpec) : MarkdownBlock
    data class ImageGroup(val images: List<MarkdownImageSpec>) : MarkdownBlock

    data class LocalFile(val path: String) : MarkdownBlock

    data class RemoteFile(val url: String) : MarkdownBlock

    data class MediaLink(val spec: MarkdownMediaLinkSpec) : MarkdownBlock

    data class LinkCard(val url: String) : MarkdownBlock

    data class MagnetLink(val uri: String) : MarkdownBlock

    data class EmbedFrame(val spec: MarkdownEmbedFrameSpec) : MarkdownBlock

    data class Mermaid(val diagram: MarkdownMermaidSpec) : MarkdownBlock
    data class Table(
        val headers: List<MarkdownSourceText>,
        val rows: List<List<MarkdownSourceText>>,
    ) : MarkdownBlock
    data class CodeFence(
        val code: MarkdownSourceText,
        val language: String = "",
    ) : MarkdownBlock
    data object Rule : MarkdownBlock
}

private fun parseMarkdown(markdown: String): List<MarkdownBlock> {
    val lines = splitMarkdownLines(markdown)
    val blocks = mutableListOf<MarkdownBlock>()
    parseMarkdownBlocks(
        lines = lines,
        startIndex = 0,
        endIndexExclusive = lines.size,
        blocks = blocks,
    )
    return blocks
}

internal fun parseMarkdownBlocks(
    lines: List<MarkdownLine>,
    startIndex: Int,
    endIndexExclusive: Int,
    blocks: MutableList<MarkdownBlock>,
) {
    var index = startIndex

    while (index < endIndexExclusive) {
        val line = lines[index]
        val trimmed = line.text.trim()

        if (trimmed.isBlank()) {
            index++
            continue
        }

        if (trimmed.startsWith("```")) {
            val fenceHeader = parseMarkdownCodeFenceHeader(trimmed)
            val fenceLanguage = fenceHeader.language.lowercase()
            index++
            val codeStartOffset = if (index < endIndexExclusive) lines[index].startOffset else line.startOffset + line.text.length
            val codeLines = mutableListOf<String>()
            while (index < endIndexExclusive && !lines[index].text.trim().startsWith("```")) {
                codeLines += lines[index].text
                index++
            }
            if (index < endIndexExclusive) index++
            val code = MarkdownSourceText(
                text = codeLines.joinToString("\n"),
                sourceOffset = codeStartOffset,
            )
            blocks += if (fenceLanguage == "mermaid") {
                MarkdownBlock.Mermaid(
                    MarkdownMermaidSpec(
                        code = code,
                        layout = parseMarkdownMediaLayout(
                            attributes = fenceHeader.attributes,
                            defaults = defaultMarkdownMermaidLayout(),
                        ),
                    )
                )
            } else {
                MarkdownBlock.CodeFence(code, fenceLanguage)
            }
            continue
        }

        val setextHeadingLevel = setextHeadingLevel(lines, index)
        if (setextHeadingLevel != null) {
            blocks += MarkdownBlock.Heading(
                level = setextHeadingLevel,
                text = MarkdownSourceText(
                    text = trimmed,
                    sourceOffset = line.startOffset + line.text.indexOf(trimmed).coerceAtLeast(0),
                ),
            )
            index += 2
            continue
        }

        val headingMatch = headingPattern.matchEntire(trimmed)
        if (headingMatch != null) {
            blocks += MarkdownBlock.Heading(
                level = headingMatch.groupValues[1].length,
                text = MarkdownSourceText(
                    text = headingMatch.groupValues[2].trim(),
                    sourceOffset = contentStartOffset(
                        line = line,
                        trimmedLine = trimmed,
                        markerLength = headingMatch.groupValues[1].length,
                    ),
                ),
            )
            index++
            continue
        }

        if (horizontalRulePattern.matches(trimmed)) {
            blocks += MarkdownBlock.Rule
            index++
            continue
        }

        if (trimmed.startsWith(">")) {
            val quoteLines = mutableListOf<String>()
            val quoteStartOffset = contentStartOffset(
                line = line,
                trimmedLine = trimmed,
                markerLength = 1,
            )
            while (index < endIndexExclusive && lines[index].text.trim().startsWith(">")) {
                quoteLines += lines[index].text.trim().removePrefix(">").trimStart()
                index++
            }
            blocks += MarkdownBlock.Quote(
                MarkdownSourceText(
                    text = quoteLines.joinToString("\n"),
                    sourceOffset = quoteStartOffset,
                )
            )
            continue
        }

        if (looksLikeMarkdownTable(lines, index)) {
            val headerLine = lines[index]
            val headerCells = parseMarkdownTableCells(headerLine)
            val columnCount = headerCells.size
            index += 2

            val rows = mutableListOf<List<MarkdownSourceText>>()
            while (index < endIndexExclusive) {
                val candidate = lines[index]
                if (candidate.text.trim().isBlank() || !looksLikeMarkdownTableDataRow(candidate.text, columnCount)) {
                    break
                }
                rows += normalizeMarkdownTableRow(
                    cells = parseMarkdownTableCells(candidate),
                    columnCount = columnCount,
                    line = candidate,
                )
                index++
            }

            blocks += MarkdownBlock.Table(
                headers = normalizeMarkdownTableRow(
                    cells = headerCells,
                    columnCount = columnCount,
                    line = headerLine,
                ),
                rows = rows,
            )
            continue
        }

        if (unorderedPattern.matches(trimmed)) {
            val items = mutableListOf<MarkdownSourceText>()
            while (index < endIndexExclusive) {
                val candidate = lines[index]
                val match = unorderedPattern.matchEntire(candidate.text.trim())
                if (match == null) break
                items += MarkdownSourceText(
                    text = match.groupValues[1],
                    sourceOffset = contentStartOffset(
                        line = candidate,
                        trimmedLine = candidate.text.trim(),
                        markerLength = 1,
                    ),
                )
                index++
            }
            blocks += MarkdownBlock.UnorderedList(items)
            continue
        }

        if (orderedPattern.matches(trimmed)) {
            val items = mutableListOf<MarkdownSourceText>()
            while (index < endIndexExclusive) {
                val candidate = lines[index]
                val candidateTrimmed = candidate.text.trim()
                val match = orderedPattern.matchEntire(candidateTrimmed)
                if (match == null) break
                items += MarkdownSourceText(
                    text = match.groupValues[2],
                    sourceOffset = contentStartOffset(
                        line = candidate,
                        trimmedLine = candidateTrimmed,
                        markerLength = match.groupValues[1].length + 1,
                    ),
                )
                index++
            }
            blocks += MarkdownBlock.OrderedList(items)
            continue
        }

        val images = parseMarkdownImageSequence(trimmed)
        if (images != null) {
            blocks += if (images.size == 1) {
                MarkdownBlock.Image(images.single())
            } else {
                MarkdownBlock.ImageGroup(images)
            }
            index++
            continue
        }

        val paragraphBuffer = StringBuilder()
        var paragraphStartOffset = line.startOffset
        var paragraphHasContent = false
        while (index < endIndexExclusive) {
            val candidateLine = lines[index]
            val candidate = candidateLine.text
            if (candidate.trim().isBlank() || beginsSpecialBlock(lines, index)) {
                break
            }
            val mediaLinkSpec = parseMediaLinkUrl(candidate.trim())
            if (mediaLinkSpec != null) {
                if (paragraphHasContent) {
                    blocks += MarkdownBlock.Paragraph(
                        MarkdownSourceText(
                            text = paragraphBuffer.toString(),
                            sourceOffset = paragraphStartOffset,
                        )
                    )
                    paragraphBuffer.clear()
                    paragraphHasContent = false
                }
                blocks += MarkdownBlock.MediaLink(mediaLinkSpec)
                index++
                continue
            }
            val remoteImageUrl = parseRemoteImageLinkUrl(candidate.trim())
            if (remoteImageUrl != null) {
                if (paragraphHasContent) {
                    blocks += MarkdownBlock.Paragraph(
                        MarkdownSourceText(
                            text = paragraphBuffer.toString(),
                            sourceOffset = paragraphStartOffset,
                        )
                    )
                    paragraphBuffer.clear()
                    paragraphHasContent = false
                }
                blocks += MarkdownBlock.Image(
                    MarkdownImageSpec(
                        altText = remoteFileDisplayName(remoteImageUrl),
                        url = remoteImageUrl,
                        layout = defaultMarkdownImageLayout(),
                    )
                )
                index++
                continue
            }
            val remoteFileUrl = parseRemoteFileUrl(candidate.trim())
            if (remoteFileUrl != null) {
                if (paragraphHasContent) {
                    blocks += MarkdownBlock.Paragraph(
                        MarkdownSourceText(
                            text = paragraphBuffer.toString(),
                            sourceOffset = paragraphStartOffset,
                        )
                    )
                    paragraphBuffer.clear()
                    paragraphHasContent = false
                }
                blocks += MarkdownBlock.RemoteFile(remoteFileUrl)
                index++
                continue
            }
            val embedFrameSpec = parseEmbedFrameSpec(candidate.trim())
            if (embedFrameSpec != null) {
                if (paragraphHasContent) {
                    blocks += MarkdownBlock.Paragraph(
                        MarkdownSourceText(
                            text = paragraphBuffer.toString(),
                            sourceOffset = paragraphStartOffset,
                        )
                    )
                    paragraphBuffer.clear()
                    paragraphHasContent = false
                }
                blocks += MarkdownBlock.EmbedFrame(embedFrameSpec)
                index++
                continue
            }
            val webLinkCardUrl = parseWebLinkCardUrl(candidate.trim())
            if (webLinkCardUrl != null) {
                if (paragraphHasContent) {
                    blocks += MarkdownBlock.Paragraph(
                        MarkdownSourceText(
                            text = paragraphBuffer.toString(),
                            sourceOffset = paragraphStartOffset,
                        )
                    )
                    paragraphBuffer.clear()
                    paragraphHasContent = false
                }
                blocks += MarkdownBlock.LinkCard(webLinkCardUrl)
                index++
                continue
            }
            val magnetUri = parseMagnetLink(candidate.trim())
            if (magnetUri != null) {
                if (paragraphHasContent) {
                    blocks += MarkdownBlock.Paragraph(
                        MarkdownSourceText(
                            text = paragraphBuffer.toString(),
                            sourceOffset = paragraphStartOffset,
                        )
                    )
                    paragraphBuffer.clear()
                    paragraphHasContent = false
                }
                blocks += MarkdownBlock.MagnetLink(magnetUri)
                index++
                continue
            }
            val segments = splitMarkdownLineByLocalMedia(candidate.trim())
            val hasMedia = segments.any { it is MarkdownLocalMediaSegment.MediaPath }
            if (!hasMedia) {
                if (paragraphHasContent) paragraphBuffer.append('\n')
                paragraphBuffer.append(candidate.trimEnd())
                paragraphHasContent = true
                index++
                continue
            }
            segments.forEach { segment ->
                when (segment) {
                    is MarkdownLocalMediaSegment.Text -> {
                        val segmentText = segment.text.trim()
                        if (segmentText.isNotEmpty()) {
                            if (paragraphHasContent) paragraphBuffer.append('\n')
                            paragraphBuffer.append(segmentText)
                            paragraphHasContent = true
                        }
                    }

                    is MarkdownLocalMediaSegment.MediaPath -> {
                        if (paragraphHasContent) {
                            blocks += MarkdownBlock.Paragraph(
                                MarkdownSourceText(
                                    text = paragraphBuffer.toString(),
                                    sourceOffset = paragraphStartOffset,
                                )
                            )
                            paragraphBuffer.clear()
                            paragraphHasContent = false
                        }
                        blocks += localMediaBlock(segment.path)
                    }
                }
            }
            index++
        }
        if (paragraphHasContent || paragraphBuffer.isNotBlank()) {
            blocks += MarkdownBlock.Paragraph(
                MarkdownSourceText(
                    text = paragraphBuffer.toString(),
                    sourceOffset = paragraphStartOffset,
                )
            )
        }
    }
}

internal class StreamingMarkdownParseCache {
    internal var prefixEndOffset: Int = 0
    internal var prefixEndLineIndex: Int = 0
    internal var prefixBlocks: List<MarkdownBlock> = emptyList()
    internal var lastSource: String? = null
    internal var lastResult: List<MarkdownBlock> = emptyList()
}

private const val StreamingMarkdownTailKeepChars = 768

private class MarkdownParseBoundary(val offset: Int, val lineIndex: Int)

private fun findSafeParseBoundary(
    source: String,
    fromOffset: Int,
    fromLineIndex: Int,
    maxEnd: Int,
): MarkdownParseBoundary {
    var bestOffset = fromOffset
    var bestLineIndex = fromLineIndex
    var fenceOpen = false
    var lineStart = fromOffset.coerceIn(0, source.length)
    var lineIndex = fromLineIndex
    val limit = maxEnd.coerceIn(0, source.length)
    while (lineStart < limit) {
        val newlineAt = source.indexOf('\n', lineStart)
        val lineEnd = if (newlineAt >= 0) newlineAt else source.length
        val line = source.substring(lineStart, lineEnd.coerceAtMost(source.length)).trim()
        if (line.startsWith("```")) {
            fenceOpen = !fenceOpen
        } else if (!fenceOpen && line.isEmpty() && lineEnd < limit) {
            bestOffset = (lineEnd + 1).coerceAtMost(source.length)
            bestLineIndex = lineIndex + 1
        }
        lineIndex += 1
        lineStart = lineEnd + 1
    }
    return MarkdownParseBoundary(bestOffset, bestLineIndex)
}

internal fun parseMarkdownIncremental(
    source: String,
    cache: StreamingMarkdownParseCache,
): List<MarkdownBlock> {
    if (cache.lastSource == source) return cache.lastResult

    val lines = splitMarkdownLines(source)

    val previousSource = cache.lastSource
    val appendValid = cache.prefixEndOffset in 0..source.length &&
        (
            cache.prefixEndOffset == 0 || (
                previousSource != null &&
                    previousSource.length >= cache.prefixEndOffset &&
                    source.regionMatches(0, previousSource, 0, cache.prefixEndOffset)
                )
            )
    if (!appendValid) {
        cache.prefixEndOffset = 0
        cache.prefixEndLineIndex = 0
        cache.prefixBlocks = emptyList()
    }

    val boundary = findSafeParseBoundary(
        source = source,
        fromOffset = cache.prefixEndOffset,
        fromLineIndex = cache.prefixEndLineIndex,
        maxEnd = source.length - StreamingMarkdownTailKeepChars,
    )
    if (boundary.offset > cache.prefixEndOffset) {
        val stableBlocks = cache.prefixBlocks.toMutableList()
        parseMarkdownBlocks(
            lines = lines,
            startIndex = cache.prefixEndLineIndex,
            endIndexExclusive = boundary.lineIndex,
            blocks = stableBlocks,
        )
        cache.prefixEndOffset = boundary.offset
        cache.prefixEndLineIndex = boundary.lineIndex
        cache.prefixBlocks = stableBlocks
    }

    val result = cache.prefixBlocks.toMutableList()
    parseMarkdownBlocks(
        lines = lines,
        startIndex = cache.prefixEndLineIndex,
        endIndexExclusive = lines.size,
        blocks = result,
    )
    cache.lastSource = source
    cache.lastResult = result
    return result
}

private fun localMediaBlock(path: String): MarkdownBlock =
    if (isLocalImageMediaPath(path)) {
        MarkdownBlock.Image(
            MarkdownImageSpec(
                altText = path.substringAfterLast('/'),
                url = path,
                layout = MarkdownMediaLayout(
                    minHeightDp = 1,
                    maxHeightDp = DefaultImageMaxHeightDp,
                    fit = MarkdownMediaFit.Contain,
                ),
            )
        )
    } else {
        MarkdownBlock.LocalFile(path)
    }

private fun splitMarkdownLines(markdown: String): List<MarkdownLine> {
    val lines = mutableListOf<MarkdownLine>()
    var start = 0
    for (index in 0..markdown.length) {
        if (index == markdown.length || markdown[index] == '\n') {
            lines += MarkdownLine(
                text = markdown.substring(start, index),
                startOffset = start,
            )
            start = index + 1
        }
    }
    return lines
}

private fun contentStartOffset(
    line: MarkdownLine,
    trimmedLine: String,
    markerLength: Int,
): Int {
    val trimmedOffset = line.text.indexOf(trimmedLine).coerceAtLeast(0)
    var contentOffset = line.startOffset + trimmedOffset + markerLength
    val lineEndOffset = line.startOffset + line.text.length
    while (contentOffset < lineEndOffset && line.text[contentOffset - line.startOffset].isWhitespace()) {
        contentOffset++
    }
    return contentOffset
}

private fun beginsSpecialBlock(
    lines: List<MarkdownLine>,
    index: Int,
): Boolean {
    val line = lines.getOrNull(index)?.text ?: return false
    val trimmed = line.trim()
    return trimmed.startsWith("```") ||
        looksLikeMarkdownImageLine(trimmed) ||
        setextHeadingLevel(lines, index) != null ||
        looksLikeMarkdownTable(lines, index) ||
        headingPattern.matches(trimmed) ||
        unorderedPattern.matches(trimmed) ||
        orderedPattern.matches(trimmed) ||
        trimmed.startsWith(">") ||
        horizontalRulePattern.matches(trimmed)
}

private val headingPattern = Regex("^(#{1,6})\\s+(.+)$")

private val unorderedPattern = Regex("^[-*+]\\s+(.+)$")

private val orderedPattern = Regex("^(\\d+)[.)]\\s+(.+)$")

private val setextHeadingPattern = Regex("^\\s*(=+|-+)\\s*$")

private val horizontalRulePattern = Regex(
    "^(?:(?:\\*\\s*){3,}|(?:-\\s*){3,}|(?:_\\s*){3,})$"
)

private val markdownTableSeparatorPattern = Regex("^:?-{3,}:?$")

private val autoLinkPattern = Regex("""^(https?://\S+|www\.\S+)""")

private fun setextHeadingLevel(
    lines: List<MarkdownLine>,
    index: Int,
): Int? {
    val heading = lines.getOrNull(index)?.text?.trim().orEmpty()
    if (heading.isBlank() || beginsStandaloneMarkdownBlock(heading)) return null
    val underline = lines.getOrNull(index + 1)?.text ?: return null
    val match = setextHeadingPattern.matchEntire(underline) ?: return null
    return if (match.groupValues[1].startsWith("=")) 1 else 2
}

private fun beginsStandaloneMarkdownBlock(trimmed: String): Boolean =
    trimmed.startsWith("```") ||
        trimmed.startsWith(">") ||
        headingPattern.matches(trimmed) ||
        unorderedPattern.matches(trimmed) ||
        orderedPattern.matches(trimmed) ||
        parseMarkdownImageSequence(trimmed) != null ||
        horizontalRulePattern.matches(trimmed)

private fun looksLikeMarkdownTable(
    lines: List<MarkdownLine>,
    index: Int,
): Boolean {
    if (index + 1 >= lines.size) return false
    val headerCells = parseMarkdownTableCells(lines[index])
    if (headerCells.size < 2) return false
    return isMarkdownTableSeparator(
        line = lines[index + 1].text,
        expectedColumns = headerCells.size,
    )
}

private fun looksLikeMarkdownTableLine(line: String): Boolean =
    line.count { it == '|' } >= 1

private fun looksLikeMarkdownImageLine(line: String): Boolean =
    parseMarkdownImageSequence(line) != null

private fun looksLikeMarkdownTableDataRow(
    line: String,
    expectedColumns: Int,
): Boolean {
    if (!looksLikeMarkdownTableLine(line)) return false
    return splitMarkdownTableCells(line).size == expectedColumns
}

private fun isMarkdownTableSeparator(
    line: String,
    expectedColumns: Int,
): Boolean {
    val cells = splitMarkdownTableCells(line)
    if (cells.size != expectedColumns) return false
    return cells.all { markdownTableSeparatorPattern.matches(it.trim()) }
}

private fun parseMarkdownTableCells(line: MarkdownLine): List<MarkdownSourceText> =
    splitMarkdownTableCellsWithOffsets(line.text).map { (cellText, startOffset) ->
        val trimmedCell = cellText.trim()
        val leadingWhitespace = cellText.indexOfFirst { !it.isWhitespace() }
            .let { if (it < 0) cellText.length else it }
        MarkdownSourceText(
            text = trimmedCell,
            sourceOffset = line.startOffset + startOffset + leadingWhitespace,
        )
    }

private fun normalizeMarkdownTableRow(
    cells: List<MarkdownSourceText>,
    columnCount: Int,
    line: MarkdownLine,
): List<MarkdownSourceText> {
    if (cells.size >= columnCount) return cells.take(columnCount)
    val trailingOffset = line.startOffset + line.text.length
    return cells + List(columnCount - cells.size) {
        MarkdownSourceText(text = "", sourceOffset = trailingOffset)
    }
}

private fun splitMarkdownTableCells(line: String): List<String> =
    splitMarkdownTableCellsWithOffsets(line).map { it.first }

private fun splitMarkdownTableCellsWithOffsets(line: String): List<Pair<String, Int>> {
    if ('|' !in line) return emptyList()

    val pipeIndices = line.indices.filter { line[it] == '|' }
    val cells = mutableListOf<Pair<String, Int>>()
    var segmentStart = 0

    if (pipeIndices.isNotEmpty() && line.substring(0, pipeIndices.first()).isBlank()) {
        segmentStart = pipeIndices.first() + 1
    }

    pipeIndices.forEach { pipeIndex ->
        if (pipeIndex < segmentStart) return@forEach
        val cellText = line.substring(segmentStart, pipeIndex)
        val isTrailingEmptyCell = pipeIndex == line.lastIndex && cellText.isBlank()
        if (!isTrailingEmptyCell) {
            cells += cellText to segmentStart
        }
        segmentStart = pipeIndex + 1
    }

    if (segmentStart <= line.length) {
        val tail = line.substring(segmentStart)
        val hasExplicitTrailingPipe = line.trimEnd().endsWith("|")
        if (!(hasExplicitTrailingPipe && tail.isBlank())) {
            cells += tail to segmentStart
        }
    }

    return cells
}

internal data class MarkdownInlineLinkMatch(
    val label: String,
    val destination: String,
    val endExclusive: Int,
)

internal data class MarkdownMathMatch(
    val rawText: String,
    val endExclusive: Int,
)

internal fun containsRenderableMarkdownMath(
    text: String,
): Boolean {
    var index = 0
    while (index < text.length) {
        if (text.startsWith("`", index)) {
            val codeEnd = text.indexOf('`', index + 1)
            if (codeEnd > index) {
                index = codeEnd + 1
                continue
            }
        }
        val mathMatch = parseMarkdownMathAt(text, index)
        if (mathMatch != null) return true
        index++
    }
    return false
}

internal fun parseMarkdownMathAt(
    text: String,
    startIndex: Int,
): MarkdownMathMatch? {
    if (startIndex !in text.indices) return null
    val openingDelimiter = when {
        text.startsWith("$$", startIndex) -> "$$"
        text.startsWith("\\[", startIndex) -> "\\["
        text.startsWith("\\(", startIndex) -> "\\("
        text[startIndex] == '$' -> "$"
        else -> return null
    }
    val closingDelimiter = when (openingDelimiter) {
        "$$" -> "$$"
        "\\[" -> "\\]"
        "\\(" -> "\\)"
        else -> "$"
    }
    val contentStart = startIndex + openingDelimiter.length
    if (contentStart >= text.length) return null

    var index = contentStart
    while (index < text.length) {
        if (text.startsWith(closingDelimiter, index)) {
            val content = text.substring(contentStart, index)
            if (!isRenderableMarkdownMathContent(openingDelimiter, content)) return null
            return MarkdownMathMatch(
                rawText = text.substring(startIndex, index + closingDelimiter.length),
                endExclusive = index + closingDelimiter.length,
            )
        }
        if (text[index] == '\\' && !text.startsWith(closingDelimiter, index) && index + 1 < text.length) {
            index += 2
            continue
        }
        index++
    }
    return null
}

private fun isRenderableMarkdownMathContent(
    openingDelimiter: String,
    content: String,
): Boolean {
    val trimmed = content.trim()
    if (trimmed.isBlank()) return false
    if (openingDelimiter != "$") return true
    if (trimmed.contains('\n')) return false
    return trimmed.any { it in "\\_^{}=+-*/()[]<>" } || trimmed.none(Char::isWhitespace)
}

internal fun parseInlineMarkdownLink(
    text: String,
    startIndex: Int,
): MarkdownInlineLinkMatch? {
    if (startIndex !in text.indices || text[startIndex] != '[') return null
    val closeBracket = text.indexOf("](", startIndex)
    if (closeBracket <= startIndex) return null

    var index = closeBracket + 2
    var nestedParentheses = 0
    while (index < text.length) {
        val character = text[index]
        if (character == '\\' && index + 1 < text.length) {
            index += 2
            continue
        }
        when (character) {
            '(' -> nestedParentheses++
            ')' -> {
                if (nestedParentheses == 0) break
                nestedParentheses--
            }
        }
        index++
    }
    if (index >= text.length || text[index] != ')') return null

    val destination = extractMarkdownLinkDestination(
        text.substring(closeBracket + 2, index)
    ).orEmpty()
    if (destination.isBlank()) return null

    return MarkdownInlineLinkMatch(
        label = text.substring(startIndex + 1, closeBracket),
        destination = destination,
        endExclusive = index + 1,
    )
}

internal fun inlineMarkdown(
    text: String,
    sourceOffset: Int,
): AnnotatedString = buildAnnotatedString {
    appendInline(text, sourceOffset)
}

private fun AnnotatedString.Builder.appendInline(
    text: String,
    sourceOffset: Int,
) {
    var index = 0
    while (index < text.length) {
        val mathMatch = parseMarkdownMathAt(text, index)
        if (mathMatch != null) {
            appendSourceSegment(
                text = mathMatch.rawText,
                sourceOffset = sourceOffset + index,
            )
            index = mathMatch.endExclusive
            continue
        }

        if (text.startsWith("**", index)) {
            val end = text.indexOf("**", index + 2)
            if (end > index + 2) {
                pushStyle(SpanStyle(fontWeight = FontWeight.SemiBold))
                appendInline(
                    text = text.substring(index + 2, end),
                    sourceOffset = sourceOffset + index + 2,
                    )
                pop()
                index = end + 2
                continue
            }
        }

        if (text.startsWith("`", index)) {
            val end = text.indexOf('`', index + 1)
            if (end > index + 1) {
                pushStyle(
                    SpanStyle(
                        fontFamily = FontFamily.Monospace,
                        background = ArixSurfaceHigh,
                    )
                )
                appendSourceSegment(
                    text = text.substring(index + 1, end),
                    sourceOffset = sourceOffset + index + 1,
                    )
                pop()
                index = end + 1
                continue
            }
        }

        val linkMatch = parseInlineMarkdownLink(text, index)
        if (linkMatch != null) {
            pushStyle(
                SpanStyle(
                    color = ArixPrimary,
                )
            )
            pushStringAnnotation(
                tag = LinkAnnotationTag,
                annotation = linkMatch.destination,
            )
            appendInline(
                text = linkMatch.label,
                sourceOffset = sourceOffset + index + 1,
            )
            pop()
            pop()
            index = linkMatch.endExclusive
            continue
        }

        val autoLink = parseAutoLink(text, index)
        if (autoLink != null) {
            pushStyle(
                SpanStyle(
                    color = ArixPrimary,
                )
            )
            pushStringAnnotation(
                tag = LinkAnnotationTag,
                annotation = autoLink.targetUrl,
            )
            appendSourceSegment(
                text = autoLink.displayText,
                sourceOffset = sourceOffset + index + autoLink.displayStartIndex,
            )
            pop()
            pop()
            index += autoLink.endExclusive
            continue
        }

        val bracketedAutoLink = parseBracketedAutoLink(text, index)
        if (bracketedAutoLink != null) {
            pushStyle(
                SpanStyle(
                    color = ArixPrimary,
                )
            )
            pushStringAnnotation(
                tag = LinkAnnotationTag,
                annotation = bracketedAutoLink.targetUrl,
            )
            appendSourceSegment(
                text = bracketedAutoLink.displayText,
                sourceOffset = sourceOffset + index + bracketedAutoLink.displayStartIndex,
            )
            pop()
            pop()
            index += bracketedAutoLink.endExclusive
            continue
        }

        if (text.startsWith("*", index)) {
            val end = text.indexOf('*', index + 1)
            if (end > index + 1) {
                pushStyle(
                    SpanStyle(fontStyle = FontStyle.Italic)
                )
                appendInline(
                    text = text.substring(index + 1, end),
                    sourceOffset = sourceOffset + index + 1,
                )
                pop()
                index = end + 1
                continue
            }
        }

        appendSourceSegment(
            text = text[index].toString(),
            sourceOffset = sourceOffset + index,
        )
        index++
    }
}

internal fun parseAutoLink(
    text: String,
    startIndex: Int,
): MarkdownAutoLinkMatch? {
    val rawMatch = autoLinkPattern.matchAt(text, startIndex) ?: return null
    val displayText = trimAutoLinkEdgePunctuation(rawMatch.value)
    if (displayText.isBlank()) return null
    val targetUrl = if (displayText.startsWith("www.", ignoreCase = true)) {
        "https://$displayText"
    } else {
        displayText
    }
    return MarkdownAutoLinkMatch(
        displayText = displayText,
        targetUrl = targetUrl,
    )
}

private fun trimAutoLinkEdgePunctuation(raw: String): String {
    var text = raw.trimEnd('.', ',', ';', ':', '!', '?')
    while (text.isNotEmpty()) {
        val closing = text.last()
        if (closing != ']' && closing != '}' && closing != ')') break
        val opening = when (closing) {
            ']' -> '['
            '}' -> '{'
            else -> '('
        }
        val opens = text.count { it == opening }
        val closes = text.count { it == closing }
        if (closes > opens) text = text.dropLast(1) else break
    }
    return text
}

private fun parseBracketedAutoLink(
    text: String,
    startIndex: Int,
): MarkdownAutoLinkMatch? {
    if (startIndex !in text.indices || text[startIndex] != '[') return null
    val closeBracket = text.indexOf(']', startIndex + 1)
    if (closeBracket <= startIndex + 1) return null
    val inner = text.substring(startIndex + 1, closeBracket).trim()
    if (inner.contains(' ')) return null
    if (!inner.startsWith("http://", ignoreCase = true) &&
        !inner.startsWith("https://", ignoreCase = true) &&
        !inner.startsWith("www.", ignoreCase = true)
    ) {
        return null
    }
    val displayText = inner.trimEnd('.', ',', ';', ':')
    if (displayText.isBlank()) return null
    val targetUrl = if (displayText.startsWith("www.", ignoreCase = true)) {
        "https://$displayText"
    } else {
        displayText
    }
    return MarkdownAutoLinkMatch(
        displayText = displayText,
        targetUrl = targetUrl,
        endExclusive = closeBracket + 1 - startIndex,
        displayStartIndex = 1,
    )
}

private fun AnnotatedString.Builder.appendSourceSegment(
    text: String,
    sourceOffset: Int,
) {
    appendStreamingSource(text, sourceOffset)
}
