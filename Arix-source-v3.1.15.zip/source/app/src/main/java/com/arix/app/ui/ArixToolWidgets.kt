package com.arix.app.ui

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import com.arix.app.data.ArixMediaApi
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.CurrencyRupee
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.CloudUpload
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.arix.app.R
import com.arix.app.ui.theme.ArixBackground
import com.arix.app.ui.theme.ArixOnPrimary
import com.arix.app.ui.theme.ArixOnSurface
import com.arix.app.ui.theme.ArixOnSurfaceVariant
import com.arix.app.ui.theme.ArixOutline
import com.arix.app.ui.theme.ArixPrimary
import com.arix.app.ui.theme.ArixSurface
import com.arix.app.ui.theme.ArixSurfaceHigh
import com.arix.app.ui.theme.ArixSurfaceHigher
import com.arix.app.ui.theme.ArixTertiary
import androidx.compose.ui.graphics.Brush
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

data class ArixSystemResultModel(
    val ok: Boolean,
    val title: String,
    val detail: String,
)

data class ArixPaymentModel(
    val ok: Boolean,
    val payee: String,
    val payeeName: String,
    val amount: Double,
    val note: String,
    val upiUri: String,
    val upiApps: List<String>,
    val errorMessage: String,
)

data class ArixMcpFieldModel(
    val name: String,
    val value: String,
)

data class ArixMcpItemModel(
    val title: String,
    val posterUrl: String,
    val description: String,
    val streams: List<ArixMcpFieldModel>,
    val links: List<ArixMcpFieldModel>,
    val fields: List<ArixMcpFieldModel>,
)

data class ArixMcpDataWidgetModel(
    val serverName: String,
    val toolName: String,
    val items: List<ArixMcpItemModel>,
    val summaryFields: List<ArixMcpFieldModel>,
)

sealed interface ArixToolWidgetPayload {
    data class SystemResult(val model: ArixSystemResultModel) : ArixToolWidgetPayload
    data class Payment(val model: ArixPaymentModel) : ArixToolWidgetPayload
    data class McpData(val model: ArixMcpDataWidgetModel) : ArixToolWidgetPayload
    data class MediaResults(val model: ArixMediaResultsModel) : ArixToolWidgetPayload
    data class BrowserScreenshot(val model: ArixBrowserScreenshotModel) : ArixToolWidgetPayload
    data class GeneratedImage(val model: ArixGeneratedImageModel) : ArixToolWidgetPayload
    data class FileShare(val model: ArixFileShareModel) : ArixToolWidgetPayload
}

data class ArixBrowserScreenshotModel(
    val base64: String,
    val mimeType: String,
    val width: Int,
    val height: Int,
    val title: String,
    val host: String,
)

data class ArixGeneratedImageModel(
    val base64: String,
    val mimeType: String,
    val width: Int,
    val height: Int,
    val prompt: String,
    val seed: Int?,
    val bytes: Int,
)

data class ArixFileShareModel(
    val ok: Boolean,
    val url: String,
    val fileName: String,
    val serverId: String,
    val serverLabel: String,
    val sizeBytes: Long,
    val expires: String,
)

data class ArixMediaResultsModel(
    val items: List<com.arix.app.media.ArixMediaItem>,
    val source: String,
    val message: String,
)

internal fun parseArixToolWidgetPayload(outputJson: String): ArixToolWidgetPayload? {
    if (outputJson.isBlank()) return null
    val output = runCatching { JSONObject(outputJson) }.getOrNull() ?: return null
    val widgetKind = output.optString("widget")
    return when (widgetKind) {
        "browser_screenshot" -> {
            val base64 = output.optString("base64")
            if (base64.isBlank()) return null
            ArixToolWidgetPayload.BrowserScreenshot(
                ArixBrowserScreenshotModel(
                    base64 = base64,
                    mimeType = output.optString("mime_type").ifBlank { "image/jpeg" },
                    width = output.optInt("image_width"),
                    height = output.optInt("image_height"),
                    title = output.optString("captured_title"),
                    host = output.optString("captured_host"),
                ),
            )
        }

        "image", "generated_image" -> {
            val base64 = output.optString("image_base64")
            if (base64.isBlank()) return null
            val seedValue = if (output.has("seed") && !output.isNull("seed")) {
                output.optInt("seed")
            } else {
                null
            }
            ArixToolWidgetPayload.GeneratedImage(
                ArixGeneratedImageModel(
                    base64 = base64,
                    mimeType = output.optString("mime_type").ifBlank { "image/jpeg" },
                    width = output.optInt("image_width"),
                    height = output.optInt("image_height"),
                    prompt = output.optString("prompt"),
                    seed = seedValue,
                    bytes = output.optInt("bytes"),
                ),
            )
        }

        "system_result" -> {
            val detail = output.optString("detail")
            val title = output.optString("title")
            if (detail.isBlank() && title.isBlank()) return null
            ArixToolWidgetPayload.SystemResult(
                ArixSystemResultModel(
                    ok = output.optBoolean("ok", true),
                    title = title,
                    detail = detail,
                ),
            )
        }

        "upi_payment" -> {
            val payee = output.optString("payee")
            val upiUri = output.optString("upi_uri")
            if (payee.isBlank() && upiUri.isBlank() && output.optString("errmsg").isBlank()) return null
            ArixToolWidgetPayload.Payment(
                ArixPaymentModel(
                    ok = output.optBoolean("ok", false),
                    payee = payee,
                    payeeName = output.optString("payee_name"),
                    amount = output.optDouble("amount"),
                    note = output.optString("note"),
                    upiUri = upiUri,
                    upiApps = buildList {
                        val array = output.optJSONArray("upi_apps")
                        if (array != null) {
                            for (index in 0 until array.length()) add(array.optString(index))
                        }
                    },
                    errorMessage = output.optString("errmsg"),
                ),
            )
        }

        "file_share" -> {
            val url = output.optString("url")
            if (!output.optBoolean("ok", false) || url.isBlank()) return null
            ArixToolWidgetPayload.FileShare(
                ArixFileShareModel(
                    ok = true,
                    url = url,
                    fileName = output.optString("file").ifBlank { remoteFileDisplayName(url) },
                    serverId = output.optString("server").ifBlank { "filebin" },
                    serverLabel = output.optString("server_label").ifBlank { "Server" },
                    sizeBytes = output.optLong("size", -1L),
                    expires = output.optString("expires"),
                ),
            )
        }

        "mcp_data" -> parseMcpDataWidgetPayload(output)

        "media_results" -> parseMediaResultsWidgetPayload(output)

        else -> null
    }
}

private val McpTitleFieldNames = setOf(
    "title", "name", "movie", "moviename", "movie_title", "film", "label", "heading",
    "caption", "show", "series", "seriesname", "song", "track", "book", "headline",
)
private val McpPosterFieldNames = setOf(
    "poster", "image", "thumbnail", "thumb", "cover", "artwork", "picture", "img",
    "posterurl", "poster_url", "imageurl", "image_url", "thumburl", "thumb_url",
    "coverurl", "cover_url", "backdrop", "logo", "photo", "still",
)
private val McpStreamFieldNames = setOf(
    "stream", "streamurl", "stream_url", "video", "videourl", "video_url", "play",
    "playurl", "watch", "watchurl", "watch_url", "source", "file", "fileurl",
    "download", "downloadurl", "mp4", "m3u8", "hls", "media", "mediaurl", "url_stream",
)
private val McpLinkFieldNames = setOf(
    "url", "link", "uri", "href", "page", "web", "website", "site", "external",
    "imdb", "imdburl", "imdb_url", "tmdb", "tmdburl", "tmdb_url", "detail", "detailurl",
)
private val McpDescriptionFieldNames = setOf(
    "description", "desc", "overview", "summary", "plot", "synopsis", "details",
    "about", "note", "info", "information",
)
private val McpMediaExtensions = listOf(".mp4", ".m3u8", ".mkv", ".webm", ".mpd", ".avi", ".mov", ".ts")
private val McpImageExtensions = listOf(".jpg", ".jpeg", ".png", ".webp", ".gif", ".avif", ".bmp")
private val McpIgnoredFieldNames = setOf("id", "_id", "uid", "key", "type", "schema", "jsonrpc", "method")

private fun mcpValueLooksLikeStream(name: String, value: String): Boolean {
    if (!value.startsWith("http")) return false
    val lower = value.substringBefore("?").lowercase()
    if (McpMediaExtensions.any { lower.endsWith(it) }) return true
    return name.lowercase() in McpStreamFieldNames
}

private fun mcpValueLooksLikeImage(name: String, value: String): Boolean {
    if (!value.startsWith("http")) return false
    val lower = value.substringBefore("?").lowercase()
    if (McpImageExtensions.any { lower.endsWith(it) }) return true
    return name.lowercase() in McpPosterFieldNames
}

private fun mcpFieldValueText(value: Any?): String = when (value) {
    null -> ""
    is String -> value
    is Boolean -> if (value) "true" else "false"
    is Int, is Long, is Double, is Float -> value.toString()
    is org.json.JSONObject, is org.json.JSONArray -> value.toString()
    else -> value.toString()
}

private fun parseMcpItem(entry: JSONObject): ArixMcpItemModel {
    var title = ""
    var poster = ""
    var description = ""
    val streams = mutableListOf<ArixMcpFieldModel>()
    val links = mutableListOf<ArixMcpFieldModel>()
    val fields = mutableListOf<ArixMcpFieldModel>()

    for (key in entry.keys().asSequence().toList()) {
        val rawValue = entry.opt(key) ?: continue
        val text = mcpFieldValueText(rawValue)
        if (text.isBlank()) continue
        val lowerKey = key.lowercase().replace("_", "").replace("-", "")
        val originalLower = key.lowercase()
        when {
            lowerKey in McpTitleFieldNames && title.isBlank() && rawValue is String ->
                title = text.trim()

            lowerKey in McpDescriptionFieldNames && description.isBlank() && rawValue is String ->
                description = text.trim()

            mcpValueLooksLikeImage(originalLower, text) && poster.isBlank() ->
                poster = text.trim()

            mcpValueLooksLikeStream(originalLower, text) ->
                streams.add(ArixMcpFieldModel(name = key, value = text.trim()))

            text.startsWith("http") && (
                lowerKey in McpLinkFieldNames ||
                    lowerKey.endsWith("url") ||
                    lowerKey.endsWith("link")
                ) ->
                links.add(ArixMcpFieldModel(name = key, value = text.trim()))

            lowerKey !in McpIgnoredFieldNames ->
                fields.add(ArixMcpFieldModel(name = key, value = text.trim().take(400)))
        }
    }
    if (title.isBlank()) {
        title = fields.firstOrNull()?.value?.take(80) ?: ""
    }
    return ArixMcpItemModel(
        title = title,
        posterUrl = poster,
        description = description,
        streams = streams,
        links = links,
        fields = fields,
    )
}

private fun mcpFindResultItems(output: JSONObject): List<JSONObject> {
    val candidates = mutableListOf<JSONObject>()

    val resultObject = output.optJSONObject("result")
    if (resultObject != null) {
        val content = resultObject.optJSONArray("content")
        if (content != null) {
            for (index in 0 until content.length()) {
                val block = content.optJSONObject(index) ?: continue
                val text = block.optString("text")
                val parsedText = text.takeIf { it.isNotBlank() }
                    ?.let { runCatching { JSONObject(it) }.getOrNull() }
                if (parsedText != null) candidates.add(parsedText)
            }
        }
        candidates.add(resultObject)
    }

    val containers = buildList {
        add(output)
        resultObject?.let(::add)
        candidates.forEach(::add)
    }
    val listKeys = listOf(
        "results", "result", "data", "items", "item", "list", "entries", "movies",
        "movie", "series", "shows", "episodes", "tracks", "songs", "books", "posts",
        "products", "records", "values", "docs", "documents", "children",
    )
    for (container in containers) {
        for (listKey in listKeys) {
            val array = container.optJSONArray(listKey) ?: continue
            val items = mutableListOf<JSONObject>()
            for (index in 0 until array.length()) {
                when (val element = array.opt(index)) {
                    is JSONObject -> items.add(element)
                    is String -> items.add(JSONObject().put("title", element))
                    else -> Unit
                }
            }
            if (items.isNotEmpty()) return items
        }
    }

    if (candidates.isNotEmpty()) {
        return candidates.filter { candidate ->
            candidate.keys().asSequence().any { key ->
                !McpIgnoredFieldNames.contains(key.lowercase())
            }
        }
    }
    if (resultObject == null) {
        val single = output.keys().asSequence().toList().any { key ->
            key.lowercase() !in McpIgnoredFieldNames &&
                !key.lowercase().startsWith("ok") &&
                key != "stdout" && key != "widget" && key != "tool_name" &&
                key != "server_id" && key != "server_name" && key != "mcp_call_name"
        }
        if (single) return listOf(output)
    }
    return emptyList()
}

private fun parseMcpDataWidgetPayload(output: JSONObject): ArixToolWidgetPayload? {
    val serverName = output.optString("server_name").ifBlank { "MCP" }
    val toolName = output.optString("tool_name").ifBlank {
        output.optString("mcp_call_name").substringAfterLast("__").substringAfter(':')
    }
    val rawItems = mcpFindResultItems(output)
    val items = rawItems.map(::parseMcpItem).filter { item ->
        item.title.isNotBlank() || item.posterUrl.isNotBlank() ||
            item.streams.isNotEmpty() || item.fields.isNotEmpty()
    }
    if (items.isEmpty() && !output.has("result")) return null

    val summaryFields = buildList {
        for (key in output.keys().asSequence().toList()) {
            if (key in setOf("ok", "widget", "stdout", "result", "server_id", "server_name", "tool_name", "mcp_call_name", "content")) continue
            val value = output.opt(key) ?: continue
            if (value is org.json.JSONArray) continue
            val text = mcpFieldValueText(value)
            if (text.isNotBlank() && text.length < 160) {
                add(ArixMcpFieldModel(name = key, value = text))
            }
        }
    }
    return ArixToolWidgetPayload.McpData(
        ArixMcpDataWidgetModel(
            serverName = serverName,
            toolName = toolName,
            items = items.take(30),
            summaryFields = summaryFields.take(6),
        ),
    )
}

private fun parseMediaResultsWidgetPayload(output: JSONObject): ArixToolWidgetPayload? {
    val resultsArray = output.optJSONArray("results") ?: return null
    val items = mutableListOf<com.arix.app.media.ArixMediaItem>()
    val seenStreams = HashSet<String>()
    val seenIds = HashSet<String>()
    for (index in 0 until resultsArray.length()) {
        val entry = resultsArray.optJSONObject(index) ?: continue
        val item = com.arix.app.media.ArixMediaItem.fromJson(entry) ?: continue
        if (!seenStreams.add(item.streamUrl) || !seenIds.add(item.id)) continue
        items.add(item)
    }
    if (items.isEmpty()) return null
    return ArixToolWidgetPayload.MediaResults(
        ArixMediaResultsModel(
            items = items,
            source = output.optString("source"),
            message = output.optString("message"),
        ),
    )
}

private fun Modifier.widgetNoRippleClickable(onClick: () -> Unit): Modifier = composed {
    clickable(
        enabled = true,
        indication = null,
        interactionSource = remember { MutableInteractionSource() },
        onClick = onClick,
    )
}

@Composable
fun ArixToolResultWidget(
    toolName: String,
    outputJson: String,
    modifier: Modifier = Modifier,
) {
    val payload = remember(toolName, outputJson) {
        val isMcpToolCall = toolName == "arix_mcp_call" || toolName.startsWith("mcp__") ||
            (toolName.contains(':') && toolName.substringBefore(':').let { prefix ->
                prefix != "arix" && prefix.isNotBlank()
            })
        if (toolName in setOf("system_control", "upi_pay", "media_search") || isMcpToolCall) {
            parseArixToolWidgetPayload(outputJson)
        } else {
            null
        }
    }
    when (payload) {
        is ArixToolWidgetPayload.SystemResult -> SystemResultWidget(payload.model, modifier)
        is ArixToolWidgetPayload.Payment -> PaymentWidget(payload.model, modifier)
        is ArixToolWidgetPayload.McpData -> McpDataWidget(payload.model, modifier)
        is ArixToolWidgetPayload.MediaResults -> MediaResultsWidget(payload.model, modifier)
        is ArixToolWidgetPayload.BrowserScreenshot -> BrowserScreenshotWidget(payload.model, modifier)
        is ArixToolWidgetPayload.GeneratedImage -> GeneratedImageWidget(payload.model, modifier)
        is ArixToolWidgetPayload.FileShare -> FileShareWidget(payload.model, modifier)
        null -> Unit
    }
}

@Composable
internal fun ArixWidgetActionButton(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    primary: Boolean,
    enabled: Boolean = true,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val container = if (primary) ArixPrimary else ArixSurfaceHigher
    val content = if (primary) ArixOnPrimary else ArixOnSurface
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (enabled) container else ArixSurfaceHigher)
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .let { if (enabled) it.widgetNoRippleClickable(onClick = onClick) else it },
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            modifier = Modifier.size(18.dp),
            tint = if (enabled) content else ArixOnSurfaceVariant,
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            color = if (enabled) content else ArixOnSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

private fun formatTemperature(value: Double): String =
    if (value == value.toLong().toDouble()) {
        value.toLong().toString()
    } else {
        String.format(java.util.Locale.US, "%.1f", value)
    }

@Composable
internal fun PaymentWidget(
    model: ArixPaymentModel,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    var launchFailed by remember { mutableStateOf(false) }
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(ArixSurfaceHigh)
            .border(1.dp, ArixOutline.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(ArixPrimary.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = Icons.Rounded.CurrencyRupee,
                    contentDescription = null,
                    tint = ArixPrimary,
                    modifier = Modifier.size(26.dp),
                )
            }
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        text = "₹",
                        style = MaterialTheme.typography.titleLarge,
                        color = ArixOnSurfaceVariant,
                        modifier = Modifier.padding(bottom = 2.dp),
                    )
                    Text(
                        text = formatTemperature(model.amount),
                        style = MaterialTheme.typography.displaySmall.copy(
                            fontWeight = FontWeight.SemiBold,
                            fontSize = androidx.compose.ui.unit.TextUnit(28f, androidx.compose.ui.unit.TextUnitType.Sp),
                        ),
                        color = ArixOnSurface,
                    )
                }
                Text(
                    text = stringResource(R.string.widget_payment_title),
                    style = MaterialTheme.typography.labelMedium,
                    color = ArixOnSurfaceVariant,
                )
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            if (model.payeeName.isNotBlank()) {
                PaymentDetailRow(
                    label = stringResource(R.string.widget_payment_to),
                    value = model.payeeName,
                )
            }
            if (model.payee.isNotBlank()) {
                PaymentDetailRow(
                    label = stringResource(R.string.widget_payment_payee),
                    value = model.payee,
                )
            }
            if (model.note.isNotBlank()) {
                PaymentDetailRow(
                    label = stringResource(R.string.widget_payment_note),
                    value = model.note,
                )
            }
        }
        if (model.upiApps.isNotEmpty()) {
            Text(
                text = stringResource(R.string.widget_payment_apps, model.upiApps.joinToString(", ")),
                style = MaterialTheme.typography.labelSmall,
                color = ArixOnSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (!model.ok && model.errorMessage.isNotBlank()) {
            Text(
                text = model.errorMessage,
                style = MaterialTheme.typography.bodySmall,
                color = androidx.compose.ui.graphics.Color(0xFFE57373),
            )
        }
        if (launchFailed) {
            Text(
                text = stringResource(R.string.widget_payment_launch_failed),
                style = MaterialTheme.typography.bodySmall,
                color = androidx.compose.ui.graphics.Color(0xFFE57373),
            )
        }
        if (model.upiUri.isNotBlank()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(ArixPrimary)
                    .widgetNoRippleClickable {
                        launchFailed = !runCatching {
                            context.startActivity(
                                Intent(Intent.ACTION_VIEW, Uri.parse(model.upiUri))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                            )
                        }.isSuccess
                    }
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.OpenInNew,
                    contentDescription = null,
                    tint = ArixOnPrimary,
                    modifier = Modifier.size(18.dp),
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = stringResource(R.string.widget_payment_pay, formatTemperature(model.amount)),
                    style = MaterialTheme.typography.titleSmall,
                    color = ArixOnPrimary,
                    fontWeight = FontWeight.SemiBold,
                )
            }
        }
    }
}

@Composable
private fun PaymentDetailRow(
    label: String,
    value: String,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = ArixOnSurfaceVariant,
            modifier = Modifier.width(72.dp),
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            color = ArixOnSurface,
            fontWeight = FontWeight.Medium,
        )
    }
}

@Composable
internal fun McpDataWidget(
    model: ArixMcpDataWidgetModel,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val clipboardManager = androidx.compose.ui.platform.LocalClipboardManager.current
    var expandedItemIndex by remember(model) { mutableStateOf(-1) }
    var activeStream by remember(model) { mutableStateOf<Pair<String, String>?>(null) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(ArixSurfaceHigh)
            .border(1.dp, ArixOutline.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(26.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(ArixPrimary.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = Icons.Rounded.Memory,
                    contentDescription = null,
                    tint = ArixPrimary,
                    modifier = Modifier.size(15.dp),
                )
            }
            Spacer(Modifier.width(8.dp))
            Column {
                Text(
                    text = model.serverName,
                    style = MaterialTheme.typography.titleSmall,
                    color = ArixOnSurface,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (model.toolName.isNotBlank()) {
                    Text(
                        text = model.toolName,
                        style = MaterialTheme.typography.labelSmall,
                        color = ArixOnSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }

        if (model.summaryFields.isNotEmpty()) {
            model.summaryFields.forEach { field ->
                McpFieldRow(
                    field = field,
                    onClick = { clipboardManager.setText(androidx.compose.ui.text.AnnotatedString(field.value)) },
                )
            }
        }

        val posterItems = model.items.withIndex().filter { it.value.posterUrl.isNotBlank() }
        if (posterItems.size >= 2) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                posterItems.take(12).forEach { (index, item) ->
                    Column(
                        modifier = Modifier
                            .width(104.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(ArixSurfaceHigher)
                            .widgetNoRippleClickable {
                                expandedItemIndex = if (expandedItemIndex == index) -1 else index
                            }
                            .padding(6.dp),
                        verticalArrangement = Arrangement.spacedBy(5.dp),
                    ) {
                        val poster = rememberRemoteImage(
                            ArixMediaApi.thumbUrl(item.posterUrl),
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(0.68f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(ArixSurfaceHigh),
                            contentAlignment = Alignment.Center,
                        ) {
                            if (poster != null) {
                                Image(
                                    bitmap = poster,
                                    contentDescription = item.title,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop,
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Rounded.Movie,
                                    contentDescription = null,
                                    tint = ArixOnSurfaceVariant,
                                    modifier = Modifier.size(22.dp),
                                )
                            }
                        }
                        Text(
                            text = item.title,
                            style = MaterialTheme.typography.labelSmall,
                            color = ArixOnSurface,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                        if (item.streams.isNotEmpty()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Rounded.PlayArrow,
                                    contentDescription = null,
                                    tint = ArixPrimary,
                                    modifier = Modifier.size(13.dp),
                                )
                                Spacer(Modifier.width(3.dp))
                                Text(
                                    text = "Stream",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ArixPrimary,
                                    maxLines = 1,
                                )
                            }
                        }
                    }
                }
            }
        }

        model.items.take(12).forEachIndexed { index, item ->
            if (posterItems.size >= 2 && expandedItemIndex != index && item.streams.isEmpty() && item.links.isEmpty() && item.fields.isEmpty()) {
                return@forEachIndexed
            }
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(ArixSurfaceHigher)
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(7.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (item.posterUrl.isNotBlank() && posterItems.size < 2) {
                        val poster = rememberRemoteImage(ArixMediaApi.thumbUrl(item.posterUrl))
                        Box(
                            modifier = Modifier
                                .size(width = 56.dp, height = 78.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(ArixSurfaceHigh),
                            contentAlignment = Alignment.Center,
                        ) {
                            if (poster != null) {
                                Image(
                                    bitmap = poster,
                                    contentDescription = item.title,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop,
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Rounded.Movie,
                                    contentDescription = null,
                                    tint = ArixOnSurfaceVariant,
                                    modifier = Modifier.size(18.dp),
                                )
                            }
                        }
                        Spacer(Modifier.width(10.dp))
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = item.title.ifBlank { "—" },
                            style = MaterialTheme.typography.labelLarge,
                            color = ArixOnSurface,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                        if (item.description.isNotBlank()) {
                            Text(
                                text = item.description,
                                style = MaterialTheme.typography.labelSmall,
                                color = ArixOnSurfaceVariant,
                                maxLines = if (expandedItemIndex == index) 6 else 2,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }

                if (item.streams.isNotEmpty()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        item.streams.forEach { stream ->
                            Text(
                                text = stream.name.replace('_', ' '),
                                style = MaterialTheme.typography.labelMedium,
                                color = ArixOnPrimary,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(ArixPrimary)
                                    .widgetNoRippleClickable {
                                        activeStream = stream.name to stream.value
                                    }
                                    .padding(horizontal = 12.dp, vertical = 7.dp),
                            )
                        }
                    }
                }

                if (item.links.isNotEmpty()) {
                    item.links.take(4).forEach { link ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(ArixSurfaceHigh)
                                .widgetNoRippleClickable { openExternally(context, link.value) }
                                .padding(horizontal = 10.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.OpenInNew,
                                contentDescription = null,
                                tint = ArixPrimary,
                                modifier = Modifier.size(14.dp),
                            )
                            Spacer(Modifier.width(7.dp))
                            Text(
                                text = link.name,
                                style = MaterialTheme.typography.labelMedium,
                                color = ArixPrimary,
                                maxLines = 1,
                                modifier = Modifier.weight(1f),
                            )
                        }
                    }
                }

                if (item.fields.isNotEmpty()) {
                    item.fields.take(if (expandedItemIndex == index) 30 else 6).forEach { field ->
                        McpFieldRow(
                            field = field,
                            onClick = { clipboardManager.setText(androidx.compose.ui.text.AnnotatedString(field.value)) },
                        )
                    }
                    if (item.fields.size > 6 && expandedItemIndex != index) {
                        Text(
                            text = "+${item.fields.size - 6} more fields",
                            style = MaterialTheme.typography.labelSmall,
                            color = ArixPrimary,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .widgetNoRippleClickable { expandedItemIndex = index }
                                .padding(horizontal = 4.dp, vertical = 2.dp),
                        )
                    }
                }
            }
        }

        activeStream?.let { (label, url) ->
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Rounded.PlayCircle,
                        contentDescription = null,
                        tint = ArixPrimary,
                        modifier = Modifier.size(16.dp),
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = label.replace('_', ' '),
                        style = MaterialTheme.typography.labelMedium,
                        color = ArixOnSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                    Icon(
                        imageVector = Icons.Rounded.Close,
                        contentDescription = "Close player",
                        tint = ArixOnSurfaceVariant,
                        modifier = Modifier
                            .size(20.dp)
                            .widgetNoRippleClickable { activeStream = null }
                            .padding(2.dp),
                    )
                }
                ArixVideoPlayer(
                    streamUrl = url,
                    referer = "",
                    posterUrl = "",
                )
            }
        }

    }
}

@Composable
private fun McpFieldRow(
    field: ArixMcpFieldModel,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(ArixSurfaceHigh)
            .widgetNoRippleClickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = field.name,
            style = MaterialTheme.typography.labelSmall,
            color = ArixOnSurfaceVariant,
            maxLines = 1,
            modifier = Modifier.width(96.dp),
            overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = field.value,
            style = MaterialTheme.typography.labelSmall,
            color = ArixOnSurface,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
        Icon(
            imageVector = Icons.Rounded.ContentCopy,
            contentDescription = null,
            tint = ArixOnSurfaceVariant.copy(alpha = 0.6f),
            modifier = Modifier.size(12.dp),
        )
    }
}

@Composable
internal fun rememberRemoteImage(url: String): ImageBitmap? {
    return produceState<ImageBitmap?>(initialValue = null, url) {
        if (url.isBlank()) return@produceState
        value = withContext(Dispatchers.IO) {
            ArixMediaApi.loadPoster(url, widthPx = 244)?.asImageBitmap()
        }
    }.value
}

private fun openExternally(context: Context, url: String) {
    ArixLinkActions.openUrl(context, url)
}

@Composable
internal fun FileShareWidget(
    model: ArixFileShareModel,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var copied by remember(model.url) { mutableStateOf(false) }
    val copiedLabel = stringResource(R.string.widget_link_copied)
    val sizeLabel = remember(model.sizeBytes) {
        if (model.sizeBytes > 0L) com.arix.app.data.ArixFileShareClient.formatBytes(model.sizeBytes) else ""
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(ArixSurfaceHigh)
            .border(1.dp, ArixOutline, RoundedCornerShape(18.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(3.dp)
                .clip(RoundedCornerShape(999.dp))
                .background(Brush.horizontalGradient(listOf(ArixPrimary, ArixTertiary))),
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(13.dp))
                    .background(ArixPrimary.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = Icons.Rounded.CloudUpload,
                    contentDescription = null,
                    tint = ArixPrimary,
                    modifier = Modifier.size(22.dp),
                )
            }
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                Text(
                    text = model.fileName.ifBlank { "Shared file" },
                    style = MaterialTheme.typography.titleSmall,
                    color = ArixOnSurface,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(
                        text = model.serverLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = ArixOnSurfaceVariant,
                        modifier = Modifier
                            .clip(RoundedCornerShape(999.dp))
                            .background(ArixSurfaceHigher)
                            .padding(horizontal = 8.dp, vertical = 2.dp),
                    )
                    if (sizeLabel.isNotBlank()) {
                        Text(
                            text = sizeLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = ArixOnSurfaceVariant,
                        )
                    }
                }
            }
            Icon(
                imageVector = Icons.Rounded.CheckCircle,
                contentDescription = null,
                tint = ArixPrimary,
                modifier = Modifier.size(18.dp),
            )
        }
        Text(
            text = model.url,
            style = MaterialTheme.typography.bodySmall.copy(
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
            ),
            color = ArixPrimary,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(ArixSurface)
                .border(1.dp, ArixOutline.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                .padding(horizontal = 10.dp, vertical = 8.dp),
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            ArixWidgetActionButton(
                label = stringResource(R.string.widget_link_open),
                icon = Icons.AutoMirrored.Rounded.OpenInNew,
                primary = true,
                modifier = Modifier.weight(1f),
                onClick = { openExternally(context, model.url) },
            )
            ArixWidgetActionButton(
                label = if (copied) copiedLabel else stringResource(R.string.widget_link_copy),
                icon = if (copied) Icons.Rounded.CheckCircle else Icons.Rounded.ContentCopy,
                primary = false,
                enabled = !copied,
                modifier = Modifier.weight(1f),
                onClick = {
                    clipboard.setText(androidx.compose.ui.text.AnnotatedString(model.url))
                    copied = true
                },
            )
            ArixWidgetActionButton(
                label = stringResource(R.string.widget_file_share),
                icon = Icons.Rounded.Share,
                primary = false,
                modifier = Modifier.weight(1f),
                onClick = { ArixMediaActions.shareText(context, model.url) },
            )
        }
        if (model.expires.isNotBlank()) {
            Text(
                text = model.expires,
                style = MaterialTheme.typography.labelSmall,
                color = ArixOnSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
internal fun SystemResultWidget(
    model: ArixSystemResultModel,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(ArixSurfaceHigh)
            .border(1.dp, ArixOutline.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Icon(
            imageVector = if (model.ok) Icons.Rounded.CheckCircle else Icons.Rounded.WarningAmber,
            contentDescription = null,
            modifier = Modifier.size(20.dp),
            tint = if (model.ok) ArixPrimary else androidx.compose.ui.graphics.Color(0xFFE5757A),
        )
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            if (model.title.isNotBlank()) {
                Text(
                    text = model.title,
                    style = MaterialTheme.typography.labelLarge,
                    color = ArixOnSurface,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            if (model.detail.isNotBlank()) {
                Text(
                    text = model.detail,
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

object ArixMediaDownloads {
    fun saveToDownloads(
        context: Context,
        displayName: String,
        mimeType: String,
        bytes: ByteArray,
    ): Uri {
        val appContext = context.applicationContext
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = android.content.ContentValues().apply {
                put(android.provider.MediaStore.Downloads.DISPLAY_NAME, displayName)
                put(android.provider.MediaStore.Downloads.MIME_TYPE, mimeType)
                put(android.provider.MediaStore.Downloads.IS_PENDING, 1)
            }
            val resolver = appContext.contentResolver
            val collection =
                android.provider.MediaStore.Downloads.getContentUri(android.provider.MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val itemUri = resolver.insert(collection, values)
                ?: error("The download could not be created in the system Downloads store.")
            try {
                resolver.openOutputStream(itemUri)?.use { output ->
                    output.write(bytes)
                    output.flush()
                } ?: error("The download file could not be written.")
                values.clear()
                values.put(android.provider.MediaStore.Downloads.IS_PENDING, 0)
                resolver.update(itemUri, values, null, null)
            } catch (throwable: Throwable) {
                runCatching { resolver.delete(itemUri, null, null) }
                error("The download failed: ${throwable.message}")
            }
            return itemUri
        }
        val downloadsDirectory = context.getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS)
            ?: error("External storage is not available for downloads on this device.")
        val targetFile = File(downloadsDirectory, displayName)
        targetFile.writeBytes(bytes)
        return Uri.fromFile(targetFile)
    }
}

@Composable
internal fun BrowserScreenshotWidget(
    model: ArixBrowserScreenshotModel,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    var previewing by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val bitmap by produceState<android.graphics.Bitmap?>(initialValue = null, model.base64) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                val bytes = android.util.Base64.decode(model.base64, android.util.Base64.DEFAULT)
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            }.getOrNull()
        }
    }
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(ArixSurfaceHigh)
            .border(1.dp, ArixOutline.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(RoundedCornerShape(9.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(
                                ArixPrimary.copy(alpha = 0.22f),
                                ArixTertiary.copy(alpha = 0.28f),
                            ),
                        ),
                    ),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = Icons.Rounded.PhotoCamera,
                    contentDescription = null,
                    tint = ArixPrimary,
                    modifier = Modifier.size(15.dp),
                )
            }
            Text(
                text = "Browser Screenshot",
                style = MaterialTheme.typography.titleSmall,
                color = ArixOnSurface,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            if (model.host.isNotBlank()) {
                Text(
                    text = model.host,
                    style = MaterialTheme.typography.labelMedium,
                    color = ArixOnSurfaceVariant,
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .background(ArixSurfaceHigher)
                        .padding(horizontal = 9.dp, vertical = 3.dp),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(
                    if (model.width > 0 && model.height > 0) {
                        model.width.toFloat() / model.height.toFloat()
                    } else {
                        9f / 16f
                    },
                )
                .clip(RoundedCornerShape(14.dp))
                .background(androidx.compose.ui.graphics.Color.Black)
                .let { host ->
                    if (bitmap != null) host.widgetNoRippleClickable { previewing = true } else host
                },
            contentAlignment = Alignment.Center,
        ) {
            bitmap?.let {
                Image(
                    bitmap = it.asImageBitmap(),
                    contentDescription = "Browser screenshot",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize(),
                )
            } ?: androidx.compose.material3.CircularProgressIndicator(
                strokeWidth = 3.dp,
                color = ArixPrimary,
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(
                text = listOfNotNull(
                    model.title.ifBlank { null },
                    "${model.width}×${model.height}",
                ).joinToString(" · "),
                style = MaterialTheme.typography.labelSmall,
                color = ArixOnSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            ArixWidgetActionButton(
                label = "Save",
                icon = Icons.Rounded.Download,
                primary = false,
                enabled = !saving && bitmap != null,
            ) {
                saving = true
                scope.launch {
                    val result = withContext(Dispatchers.IO) {
                        runCatching {
                            val bytes = android.util.Base64.decode(
                                model.base64,
                                android.util.Base64.DEFAULT,
                            )
                            ArixMediaDownloads.saveToDownloads(
                                context = context,
                                displayName = "arix-screenshot-${System.currentTimeMillis()}.jpg",
                                mimeType = model.mimeType.ifBlank { "image/jpeg" },
                                bytes = bytes,
                            )
                        }
                    }
                    saving = false
                    val message = if (result.isSuccess) "Screenshot saved to Downloads" else "Could not save the screenshot"
                    android.widget.Toast.makeText(context, message, android.widget.Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    if (previewing && bitmap != null) {
        ArixMediaViewerDialog(
            onDismiss = { previewing = false },
            bitmap = bitmap!!.asImageBitmap(),
            imageBytes = runCatching {
                android.util.Base64.decode(model.base64, android.util.Base64.DEFAULT)
            }.getOrNull(),
            imageMimeType = model.mimeType,
            title = model.title.ifBlank { model.host }.ifBlank { "Browser Screenshot" },
            detail = listOfNotNull(
                if (model.width > 0 && model.height > 0) "${model.width}x${model.height}" else null,
                model.host.ifBlank { null },
            ).joinToString(" · "),
            fileName = "arix-screenshot-${System.currentTimeMillis()}.jpg",
        )
    }
}

@Composable
internal fun GeneratedImageWidget(
    model: ArixGeneratedImageModel,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    var previewing by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val bitmap by produceState<android.graphics.Bitmap?>(initialValue = null, model.base64) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                val bytes = android.util.Base64.decode(model.base64, android.util.Base64.DEFAULT)
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            }.getOrNull()
        }
    }
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(ArixSurfaceHigh)
            .border(1.dp, ArixOutline.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(RoundedCornerShape(9.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(
                                ArixPrimary.copy(alpha = 0.22f),
                                ArixTertiary.copy(alpha = 0.28f),
                            ),
                        ),
                    ),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = Icons.Rounded.AutoAwesome,
                    contentDescription = null,
                    tint = ArixPrimary,
                    modifier = Modifier.size(15.dp),
                )
            }
            Text(
                text = "Image",
                style = MaterialTheme.typography.titleSmall,
                color = ArixOnSurface,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            Text(
                text = listOfNotNull(
                    if (model.width > 0 && model.height > 0) "${model.width}x${model.height}" else null,
                    if (model.bytes > 0) ArixMediaActions.formatFileSize(model.bytes.toLong()) else null,
                ).joinToString(" · ").ifBlank { "image" },
                style = MaterialTheme.typography.labelMedium,
                color = ArixOnSurfaceVariant,
                modifier = Modifier
                    .clip(RoundedCornerShape(999.dp))
                    .background(ArixSurfaceHigher)
                    .padding(horizontal = 9.dp, vertical = 3.dp),
                maxLines = 1,
            )
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(
                    if (model.width > 0 && model.height > 0) {
                        model.width.toFloat() / model.height.toFloat()
                    } else {
                        1f
                    },
                )
                .clip(RoundedCornerShape(14.dp))
                .background(androidx.compose.ui.graphics.Color.Black)
                .let { host ->
                    if (bitmap != null) host.widgetNoRippleClickable { previewing = true } else host
                },
            contentAlignment = Alignment.Center,
        ) {
            bitmap?.let {
                Image(
                    bitmap = it.asImageBitmap(),
                    contentDescription = "AI generated image",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize(),
                )
            } ?: androidx.compose.material3.CircularProgressIndicator(
                strokeWidth = 3.dp,
                color = ArixPrimary,
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(
                text = listOfNotNull(
                    model.prompt.ifBlank { null },
                    "${model.width}×${model.height}",
                    model.seed?.let { "seed $it" },
                ).joinToString(" · "),
                style = MaterialTheme.typography.labelSmall,
                color = ArixOnSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            ArixWidgetActionButton(
                label = "Save",
                icon = Icons.Rounded.Download,
                primary = false,
                enabled = !saving && bitmap != null,
            ) {
                saving = true
                scope.launch {
                    val result = withContext(Dispatchers.IO) {
                        runCatching {
                            val bytes = android.util.Base64.decode(
                                model.base64,
                                android.util.Base64.DEFAULT,
                            )
                            val extension = when {
                                model.mimeType.endsWith("png") -> "png"
                                model.mimeType.endsWith("webp") -> "webp"
                                else -> "jpg"
                            }
                            ArixMediaDownloads.saveToDownloads(
                                context = context,
                                displayName = "arix-image-${System.currentTimeMillis()}.$extension",
                                mimeType = model.mimeType.ifBlank { "image/jpeg" },
                                bytes = bytes,
                            )
                        }
                    }
                    saving = false
                    val message = if (result.isSuccess) "Image saved to Downloads" else "Could not save the image"
                    android.widget.Toast.makeText(context, message, android.widget.Toast.LENGTH_SHORT).show()
                }
            }
            ArixWidgetActionButton(
                label = "Share",
                icon = Icons.Rounded.Share,
                primary = false,
                enabled = !saving,
            ) {
                saving = true
                scope.launch {
                    val shared = withContext(Dispatchers.IO) {
                        runCatching {
                            val bytes = android.util.Base64.decode(
                                model.base64,
                                android.util.Base64.DEFAULT,
                            )
                            val extension = when {
                                model.mimeType.endsWith("png") -> "png"
                                model.mimeType.endsWith("webp") -> "webp"
                                else -> "jpg"
                            }
                            ArixMediaActions.shareBytes(
                                context = context,
                                fileName = "arix-image-${System.currentTimeMillis()}.$extension",
                                mimeType = model.mimeType.ifBlank { "image/jpeg" },
                                bytes = bytes,
                            )
                        }.getOrDefault(false)
                    }
                    saving = false
                    if (!shared) {
                        android.widget.Toast.makeText(context, "Could not share the image", android.widget.Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
    if (previewing && bitmap != null) {
        ArixMediaViewerDialog(
            onDismiss = { previewing = false },
            bitmap = bitmap!!.asImageBitmap(),
            imageBytes = runCatching {
                android.util.Base64.decode(model.base64, android.util.Base64.DEFAULT)
            }.getOrNull(),
            imageMimeType = model.mimeType,
            title = model.prompt.ifBlank { "Image" },
            detail = listOfNotNull(
                if (model.width > 0 && model.height > 0) "${model.width}x${model.height}" else null,
                model.seed?.let { "seed $it" },
            ).joinToString(" · "),
            fileName = "arix-image.${if (model.mimeType.endsWith("png")) "png" else "jpg"}",
        )
    }
}
