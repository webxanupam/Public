package com.arix.app.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

class ArixUpiPaymentController(
    private val context: Context,
) {

    fun execute(argumentsJson: String): String {
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            ?: return failureResult("Invalid JSON arguments for the payment.")

        val payeeRaw = arguments.optString("payee")
            .ifBlank { arguments.optString("upi_id") }
            .ifBlank { arguments.optString("vpa") }
            .ifBlank { arguments.optString("phone") }
            .ifBlank { arguments.optString("number") }
            .trim()
        val payeeName = arguments.optString("payee_name").ifBlank { arguments.optString("name") }.trim()
        val note = arguments.optString("note").ifBlank { arguments.optString("remark") }.trim()
        val amountValue = arguments.optDouble("amount", 0.0)
        val currency = arguments.optString("currency", "INR").trim().uppercase()

        if (payeeRaw.isBlank()) {
            return failureResult(
                "No payee was provided. Ask the user for the UPI ID (like name@bank) or the " +
                    "10-digit mobile number registered with UPI."
            )
        }
        if (amountValue <= 0.0) {
            return failureResult(
                "No valid amount was provided. Ask the user how much to pay before launching the payment."
            )
        }
        if (currency != "INR") {
            return failureResult(
                "UPI deep links only support INR payments; '$currency' was requested. Ask the user " +
                    "how to proceed."
            )
        }

        val payee = normalizePayee(payeeRaw)
        val amount = formatAmount(amountValue)

        val deepLink = buildString {
            append("upi://pay?")
            append("pa=").append(urlEncode(payee))
            append("&pn=").append(urlEncode(payeeName.ifBlank { payee }))
            append("&am=").append(amount)
            append("&cu=INR")
            if (note.isNotBlank()) append("&tn=").append(urlEncode(note.take(50)))
            append("&tr=ARIX").append(System.currentTimeMillis())
        }

        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(deepLink))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        val resolvable = runCatching {
            context.packageManager.queryIntentActivities(intent, 0)
        }.getOrDefault(emptyList())

        return runCatching {
            context.startActivity(intent)
            JSONObject()
                .put("widget", "upi_payment")
                .put("ok", true)
                .put("status", "launched")
                .put("payee", payee)
                .put("payee_name", payeeName)
                .put("amount", amountValue)
                .put("currency", "INR")
                .put("note", note)
                .put("upi_uri", deepLink)
                .put("upi_apps", JSONArray(resolvable.map { it.loadLabel(context.packageManager).toString() }))
                .put(
                    "stdout",
                    "Opened the UPI payment sheet for ₹$amount to $payee" +
                        (resolvable.takeIf { it.isNotEmpty() }?.let { " — ${it.size} UPI app(s) available." } ?: ".") +
                        " The user must confirm the payment inside their UPI app.",
                )
                .toString()
        }.getOrElse { throwable ->
            JSONObject()
                .put("widget", "upi_payment")
                .put("ok", false)
                .put("payee", payee)
                .put("amount", amountValue)
                .put("upi_uri", deepLink)
                .put(
                    "errmsg",
                    "No UPI app accepted the payment request (${throwable.message ?: "unknown error"}). " +
                        "Ask the user to install or open a UPI app (GPay, PhonePe, Paytm, BHIM) first.",
                )
                .toString()
        }
    }

    private fun normalizePayee(raw: String): String {
        val value = raw.trim()
        return when {
            value.contains('@') -> value
            value.removePrefix("+").matches(Regex("\\d{10,12}")) -> value.removePrefix("+")
            else -> value
        }
    }

    private fun formatAmount(value: Double): String =
        if (value == value.toLong().toDouble()) {
            value.toLong().toString()
        } else {
            String.format(java.util.Locale.US, "%.2f", value)
        }

    private fun failureResult(message: String): String = JSONObject()
        .put("widget", "upi_payment")
        .put("ok", false)
        .put("errmsg", message)
        .toString()

    private fun urlEncode(value: String): String =
        java.net.URLEncoder.encode(value, Charsets.UTF_8.name())
}
