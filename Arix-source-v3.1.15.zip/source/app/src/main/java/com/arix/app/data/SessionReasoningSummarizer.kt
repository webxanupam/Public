package com.arix.app.data

import com.arix.app.data.pi.PiCompletionClient
import kotlinx.coroutines.flow.StateFlow

internal class SessionReasoningSummarizer(
    private val settingsRepository: SettingsRepository,
    private val piCompletionClient: PiCompletionClient?,
    private val currentSettings: StateFlow<AppSettings>,
    private val currentProviderConfigs: StateFlow<List<LlmProviderConfig>>,
) {

    data class ReasoningSummary(
        val title: String,
        val detail: String,
    )

    private class ThinkingCatalogCacheSnapshot(
        val levelMaps: Map<String, Map<String, String>>,
        val catalog: Map<String, List<String>>,
        val reasoningModels: Set<String> = emptySet(),
        val loadedAtMillis: Long,
    )

    @Volatile
    private var thinkingCatalogCacheSnapshot: ThinkingCatalogCacheSnapshot? = null

    private suspend fun cachedThinkingCatalogSnapshot(): ThinkingCatalogCacheSnapshot {
        val now = System.currentTimeMillis()
        thinkingCatalogCacheSnapshot?.let { snapshot ->
            if (now - snapshot.loadedAtMillis < ThinkingCatalogCacheTtlMillis) {
                return snapshot
            }
        }
        val snapshot = ThinkingCatalogCacheSnapshot(
            levelMaps = settingsRepository.loadThinkingLevelMapsCache(),
            catalog = settingsRepository.loadThinkingCatalogCache(),
            reasoningModels = settingsRepository.loadReasoningModelsCache(),
            loadedAtMillis = System.currentTimeMillis(),
        )
        thinkingCatalogCacheSnapshot = snapshot
        return snapshot
    }

    suspend fun summarizeReasoningChunk(rawText: String): ReasoningSummary? {
        val settings = currentSettings.value
        val providerConfigs = currentProviderConfigs.value
        val titleSettings = resolveModelSettings(
            baseSettings = settings,
            providerConfigs = providerConfigs,
            preferredModelKey = resolveDefaultTitleModelKey(settings, providerConfigs),
            fallbackModelKey = resolveDefaultChatModelKey(settings, providerConfigs),
        )
        if (!titleSettings.isProviderSetupValid()) {
            return null
        }
        val modelKey = thinkingCatalogKey(titleSettings.piProviderId, titleSettings.modelId)
        val catalogSnapshot = cachedThinkingCatalogSnapshot()
        val thinkingLevelMap = catalogSnapshot.levelMaps[modelKey].orEmpty()
        val isReasoningModel = modelKey in catalogSnapshot.reasoningModels
        val prompt = buildString {
            appendLine("Summarize this assistant reasoning excerpt for a user-visible thinking timeline.")
            appendLine("Return exactly two short paragraphs: first a concise title, then one detail paragraph.")
            appendLine("Title style: a short gerund or noun phrase about the purpose or outcome, without 'I', 'The assistant', or a tool-action headline.")
            appendLine("Detail style: natural first-person planning language. 'I need to...', 'I should...', 'I will...', and 'I am...' are all acceptable when they fit.")
            appendLine("Never write from a third-person assistant perspective such as 'The assistant is...' or 'The model is...'.")
            appendLine("Do not mention that this is a summary, do not add bullets, and do not invent context.")
            appendLine()
            appendLine("Use this style:")
            appendLine("Providing accurate and properly cited documentation")
            appendLine()
            appendLine("I need to make sure I include citations for all factual information, especially from official docs, since I haven't performed any live API tests. It's essential to clarify that my info is based on public documentation and mention the safety of returning raw reasoning in OpenRouter. I should avoid long CoT examples.")
            appendLine()
            appendLine("Reasoning excerpt:")
            append(rawText.take(ReasoningSummaryMaxInputChars))
        }
        val result = piCompletionClient?.completeOnce(
            settings = titleSettings,
            systemPrompt = ReasoningSummarySystemPrompt,
            messages = listOf(
                LlmMessage(
                    role = "user",
                    contentParts = listOf(LlmTextPart(prompt)),
                )
            ),
            disableReasoning = true,
            thinkingLevelMap = thinkingLevelMap,
            isReasoningModel = isReasoningModel,
        )?.getOrNull()?.assistantText?.trim().orEmpty()
        return parseReasoningSummary(result)
    }

    fun fallbackReasoningSummary(): ReasoningSummary = ReasoningSummary(
        title = "Reasoning summary unavailable",
        detail = "Select this description to view the original reasoning.",
    )

    private fun parseReasoningSummary(text: String): ReasoningSummary? {
        val lines = text.lines().map(String::trim).filter(String::isNotBlank)
        if (lines.isEmpty()) return null
        val title = lines.first().trim('"').take(ReasoningSummaryTitleMaxChars)
        val detail = lines.drop(1)
            .joinToString(" ")
            .trim()
            .ifBlank { title }
            .take(ReasoningSummaryDetailMaxChars)
        return ReasoningSummary(title = title, detail = detail)
    }

    private companion object {
        const val ThinkingCatalogCacheTtlMillis = 30_000L
        const val ReasoningSummaryMaxInputChars = 8_000
        const val ReasoningSummaryTitleMaxChars = 120
        const val ReasoningSummaryDetailMaxChars = 520
        const val ReasoningSummarySystemPrompt =
            "You write concise user-visible progress summaries for assistant reasoning. Use a consistent first-person planning style, and never quote long private reasoning verbatim."
    }
}
