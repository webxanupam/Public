package com.arix.app.data

import org.json.JSONObject
import java.util.ArrayDeque
import java.util.concurrent.ConcurrentHashMap

internal class ArixAgentSupervisor(
    private val diagnosticLogger: ArixDiagnosticLogger? = null,
) {

    class TurnState(
        val sessionId: String,
        val objective: String,
    ) {
        @Volatile var toolCalls: Int = 0
        @Volatile var failures: Int = 0
        @Volatile var currentStep: String = ""
        @Volatile var lastVerified: Boolean? = null
        @Volatile var startedAtMillis: Long = System.currentTimeMillis()
        val signatureCounts = LinkedHashMap<String, Int>(64)
        val completed = ArrayDeque<String>()
        val failed = ArrayDeque<String>()
        @Volatile var plan: List<PlanItem> = emptyList()
    }

    data class PlanItem(val id: Int, val title: String, val status: String)

    private val turns = ConcurrentHashMap<String, TurnState>()

    fun beginTurn(sessionId: String, objective: String) {
        val trimmedObjective = objective.trim().take(160)
        turns[sessionId] = TurnState(sessionId, trimmedObjective)
        log(
            "turn_begin",
            mapOf("session_id" to sessionId, "objective_chars" to trimmedObjective.length),
        )
    }

    fun endTurn(sessionId: String) {
        val turn = turns.remove(sessionId) ?: return
        log(
            "turn_end",
            mapOf(
                "session_id" to sessionId,
                "tool_calls" to turn.toolCalls,
                "failures" to turn.failures,
                "duration_ms" to (System.currentTimeMillis() - turn.startedAtMillis),
            ),
        )
    }

    fun beforeToolCall(sessionId: String, toolName: String, argumentsJson: String): JSONObject? {
        val turn = turns[sessionId] ?: return null

        turn.toolCalls += 1
        if (turn.toolCalls > MaxToolCallsPerTurn) {
            return guardFailure(
                "LIMIT_REACHED",
                "This turn has already executed $MaxToolCallsPerTurn tool calls. Stop calling tools " +
                    "and give the user your final answer based on what was observed.",
            )
        }

        if (toolName in LoopTrackedTools) {
            val signature = "$toolName|${normalizeArguments(argumentsJson)}"
            val count = signatureCounts(turn, signature)
            if (count >= LoopSignatureLimit) {
                return guardFailure(
                    "LOOP_DETECTED",
                    "This identical call was already executed $count times — it is a loop. Choose a " +
                        "DIFFERENT approach, change the arguments, or report the obstacle to the user.",
                )
            }
        }

        return null
    }

    fun afterToolCall(
        sessionId: String,
        toolName: String,
        argumentsJson: String,
        rawOutput: String,
    ) {
        val turn = turns[sessionId] ?: return
        val parsed = runCatching { JSONObject(rawOutput) }.getOrNull()
        val ok = parsed?.optBoolean("ok", false) ?: false
        val verified = parsed?.optBoolean("verified", false)

        turn.currentStep = toolName
        turn.lastVerified = verified

        if (toolName in LoopTrackedTools) {
            val signature = "$toolName|${normalizeArguments(argumentsJson)}"
            bumpSignature(turn, signature)
        }

        val entry = describeToolCall(toolName, argumentsJson)
        if (ok) {
            turn.completed.addLast(entry)
            while (turn.completed.size > LedgerCapacity) turn.completed.removeFirst()
        } else {
            turn.failures += 1
            turn.failed.addLast(entry)
            while (turn.failed.size > LedgerCapacity) turn.failed.removeFirst()
        }

        log(
            "tool_call",
            mapOf(
                "session_id" to sessionId,
                "tool" to toolName,
                "ok" to ok,
                "verified" to verified,
            ),
        )
    }

    fun setPlan(sessionId: String, titles: List<String>): List<PlanItem>? {
        val turn = turns[sessionId] ?: return null
        val cleaned = titles.map { it.trim().take(120) }.filter { it.isNotEmpty() }.take(MaxPlanItems)
        turn.plan = cleaned.mapIndexed { index, title ->
            PlanItem(index + 1, title, if (index == 0) StatusInProgress else StatusPending)
        }
        return turn.plan
    }

    fun updatePlan(sessionId: String, id: Int, status: String): List<PlanItem>? {
        val turn = turns[sessionId] ?: return null
        if (turn.plan.none { it.id == id }) return null
        turn.plan = turn.plan.map { item ->
            when {
                item.id == id -> item.copy(status = status)
                status == StatusInProgress && item.status == StatusInProgress -> item.copy(status = StatusPending)
                else -> item
            }
        }
        return turn.plan
    }

    fun planChecklist(plan: List<PlanItem>): String = plan.joinToString("\n") { item ->
        val mark = when (item.status) {
            StatusCompleted -> "[x]"
            StatusInProgress -> "[>]"
            else -> "[ ]"
        }
        "$mark ${item.id}. ${item.title}"
    }

    fun compactStateBlock(sessionId: String): String? {
        val turn = turns[sessionId] ?: return null
        val verifiedLedger = when (turn.lastVerified) {
            true -> "last state-changing action verified"
            false -> "last state-changing action NOT verified — verify before claiming success"
            null -> "no state-changing action yet"
        }
        return buildString {
            append("TASK STATE (runtime): objective: ${turn.objective.ifBlank { "(unspecified)" }}")
            append(" | step ${turn.toolCalls}: ${turn.currentStep.ifBlank { "(start)" }}")
            append(" | completed ${turn.completed.size}, failed ${turn.failures}")
            append(" | $verifiedLedger.")
            if (turn.failures >= HardFailureHintThreshold) {
                append(" Multiple failures recorded — consider reporting the obstacle instead of retrying.")
            }
            if (turn.plan.isNotEmpty()) {
                append("\nPLAN (keep it current with arix_tasks):\n${planChecklist(turn.plan)}")
                if (turn.plan.all { it.status == StatusCompleted }) {
                    append("\nEvery plan step is done — give the final answer now.")
                }
            }
        }
    }

    private fun signatureCounts(turn: TurnState, signature: String): Int =
        synchronized(turn.signatureCounts) { turn.signatureCounts[signature] ?: 0 }

    private fun bumpSignature(turn: TurnState, signature: String) {
        synchronized(turn.signatureCounts) {
            val next = (turn.signatureCounts[signature] ?: 0) + 1
            turn.signatureCounts[signature] = next
            if (turn.signatureCounts.size > 128) {
                turn.signatureCounts.remove(turn.signatureCounts.keys.first())
            }
        }
    }

    private fun describeToolCall(toolName: String, argumentsJson: String): String {
        val brief = normalizeArguments(argumentsJson).take(60)
        return "$toolName($brief)"
    }

    private fun normalizeArguments(argumentsJson: String): String {
        val parsed = runCatching { JSONObject(argumentsJson) }.getOrNull() ?: return argumentsJson.hashCode().toString()
        return parsed.keys().asSequence().sorted().joinToString(",") { key ->
            val value = parsed.opt(key)?.toString()?.take(80) ?: ""
            "$key=$value"
        }
    }

    private fun guardFailure(errorCode: String, message: String): JSONObject = ArixToolContract.withTool(
        ArixToolContract.failure(errorCode, message),
        "supervisor",
    )

    private fun log(event: String, details: Map<String, Any?>) {
        runCatching {
            diagnosticLogger?.event(
                category = "agent_supervisor",
                event = event,
                details = details,
            )
        }
    }

    companion object {
        private const val MaxToolCallsPerTurn = 64
        private const val LoopSignatureLimit = 3
        private const val LedgerCapacity = 8
        private const val HardFailureHintThreshold = 4
        private const val MaxPlanItems = 12
        const val StatusPending = "pending"
        const val StatusInProgress = "in_progress"
        const val StatusCompleted = "completed"

        val LoopTrackedTools = setOf(
            "upi_pay", "arix_ensure_package", "arix_memory", "arix_diagnostics",
        )

        fun timeoutFor(toolName: String): Long = when (toolName) {
            "arix_ensure_package" -> 1_200_000L
            "arix_runtime_manage" -> 600_000L
            "arix_swarm" -> 600_000L
            "browser" -> 120_000L
            ArixWebAccessTool.ToolNameSearch -> 180_000L
            ArixWebAccessTool.ToolNameFetch -> 90_000L
            "upi_pay" -> 30_000L
            "media_search" -> 90_000L
            "arix_memory", "arix_diagnostics" -> 15_000L
            "arix_tasks" -> 5_000L
            else -> 120_000L
        }

        val MutatingDeviceTools = setOf(
            "upi_pay", "arix_ensure_package",
        )
    }
}
