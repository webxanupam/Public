package com.arix.app.runtime

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

enum class ArixFileOperationKind(val label: String) {
    Copy("Copying"),
    Move("Moving"),
    Delete("Deleting"),
    Import("Importing"),
    Create("Creating"),
    Rename("Renaming"),
    Save("Saving"),
    Extract("Extracting"),
}

data class ArixFileOperation(
    val kind: ArixFileOperationKind,
    val currentIndex: Int = 1,
    val totalCount: Int = 1,
) {
    val isBatch: Boolean get() = totalCount > 1

    val progressLabel: String
        get() = if (isBatch) {
            "${kind.label} $currentIndex of $totalCount"
        } else {
            kind.label
        }
}

object ArixFileOperationBus {

    const val minimumHiddenWindowMillis: Long = 550L

    private val _activeOperation = MutableStateFlow<ArixFileOperation?>(null)
    val activeOperation: StateFlow<ArixFileOperation?> = _activeOperation.asStateFlow()

    private val _completions = MutableSharedFlow<Unit>(replay = 0, extraBufferCapacity = 16)
    val completions: SharedFlow<Unit> = _completions.asSharedFlow()

    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError.asStateFlow()

    private val failureChannel = Channel<String>(capacity = 16)
    val failures = failureChannel.receiveAsFlow()

    private var runningOperations = 0
    private var currentKind: ArixFileOperationKind? = null
    private var currentTotal = 1
    private var currentIndex = 1
    private var scope: CoroutineScope? = null

    private fun busScope(): CoroutineScope = scope ?: CoroutineScope(
        SupervisorJob() + Dispatchers.Main.immediate,
    ).also { scope = it }

    @androidx.annotation.VisibleForTesting
    internal fun resetForTesting() {
        scope?.cancel()
        scope = null
        runningOperations = 0
        currentKind = null
        currentTotal = 1
        currentIndex = 1
        _activeOperation.value = null
        _lastError.value = null
    }

    fun launch(
        kind: ArixFileOperationKind,
        totalCount: Int = 1,
        block: suspend () -> Unit,
    ) {
        runningOperations += 1
        if (runningOperations == 1 || currentKind == null) {
            currentKind = kind
            currentTotal = totalCount.coerceAtLeast(1)
            currentIndex = 1
        }
        publishActive()
        busScope().launch {
            try {
                block()
                _completions.tryEmit(Unit)
            } catch (error: Throwable) {
                if (error is CancellationException) throw error
                val message = error.message?.takeIf { it.isNotBlank() }
                    ?: "File operation failed."
                _lastError.value = message
                failureChannel.trySend(message)
            } finally {
                runningOperations -= 1
                if (runningOperations <= 0) {
                    runningOperations = 0
                    currentKind = null
                    _activeOperation.value = null
                } else {
                    publishActive()
                }
            }
        }
    }

    fun reportProgress(index: Int) {
        if (runningOperations <= 0) return
        currentIndex = index.coerceIn(1, currentTotal)
        publishActive()
    }

    fun clearError() {
        _lastError.value = null
    }

    private fun publishActive() {
        val kind = currentKind ?: return
        _activeOperation.value = ArixFileOperation(
            kind = kind,
            currentIndex = currentIndex,
            totalCount = currentTotal,
        )
    }
}
