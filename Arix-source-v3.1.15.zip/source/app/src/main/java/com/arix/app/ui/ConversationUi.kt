package com.arix.app.ui

import android.os.SystemClock
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.Canvas
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.AttachFile
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Compress
import androidx.compose.material.icons.rounded.Extension
import androidx.compose.material.icons.rounded.Forum
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import kotlinx.coroutines.launch
import androidx.compose.ui.platform.LocalContext
import com.arix.app.agent.ArixPhoneAgent
import com.arix.app.agent.ArixPipMode
import com.arix.app.platform.LocalReduceMotion
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.snapshotFlow
import kotlinx.coroutines.flow.collectLatest
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.key
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asComposePath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.activity.compose.BackHandler
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import androidx.core.graphics.PathParser
import com.arix.app.R
import com.arix.app.data.InstalledSkill
import com.arix.app.data.ModelCatalogInfo
import com.arix.app.data.ModelsDevModelLimits
import com.arix.app.data.PendingSessionInput
import com.arix.app.data.ProviderModelOption
import com.arix.app.data.SessionFollowUpMode
import com.arix.app.data.SupportedReasoningEfforts
import com.arix.app.data.ArixReasoningPhase
import com.arix.app.data.mochiReaction
import com.arix.app.data.quickActionLabel
import com.arix.app.data.thinkingCatalogKey
import com.arix.app.ui.theme.ArixBackground
import com.arix.app.ui.theme.ArixBackgroundGradientTop
import com.arix.app.ui.theme.ArixOnSurface
import com.arix.app.ui.theme.ArixOnSurfaceVariant
import com.arix.app.ui.theme.ArixOutline
import com.arix.app.ui.theme.ArixPrimary
import com.arix.app.voice.ArixSpeechRecognitionController
import com.arix.app.ui.theme.ArixTertiary
import com.arix.app.ui.theme.ArixOutlineSoft
import com.arix.app.ui.theme.ArixScrim
import com.arix.app.ui.theme.ArixSurface
import com.arix.app.ui.theme.ArixSurfaceHigh
import com.arix.app.ui.theme.ArixSurfaceHigher
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.delay
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.Locale

private sealed interface ConversationListItem {
    val key: String

    data class Message(
        val message: ChatMessage,
    ) : ConversationListItem {
        override val key: String = message.id
    }

    data class AssistantGroup(
        val messages: List<ChatMessage>,
    ) : ConversationListItem {
        override val key: String = messages.firstOrNull()?.responseGroupId
            ?: messages.firstOrNull()?.id
            ?: "assistant-group"
    }

    data class CompactStatus(
        val message: ChatMessage,
    ) : ConversationListItem {
        override val key: String = message.id
    }
}

private val ConversationTopFadeHeight = 42.dp
private val ComposerCardShape = RoundedCornerShape(26.dp)
private val ComposerFocusedCardShape = RoundedCornerShape(28.dp)
private val ComposerPlusMenuMaxHeight = 372.dp
private const val MinimumWallClockMillis = 946_684_800_000L

private val ChatGptControlShadow = Color(0x14000000)
private val ChatGptComposerShadow = Color(0x18000000)

private val ComposerAccentBrush = Brush.linearGradient(
    listOf(
        Color(0xFF9D6BFF),
        Color(0xFF6E3FE8),
    ),
)
private val ChatGptMotionEasing = CubicBezierEasing(0.22f, 0.84f, 0.18f, 1f)

internal enum class PendingGenerationIndicator {
    None,
    Thinking,
    Status,
}

internal fun pendingGenerationIndicator(
    isSending: Boolean,
    pendingAssistantText: String,
    pendingStatusText: String,
    hasVisiblePendingReasoning: Boolean = false,
    hasVisiblePendingWork: Boolean = false,
    lastVisibleMessageAuthor: MessageAuthor? = null,
): PendingGenerationIndicator = when {
    !isSending -> PendingGenerationIndicator.None
    pendingStatusText.isNotBlank() -> PendingGenerationIndicator.Status
    hasVisiblePendingReasoning -> PendingGenerationIndicator.None
    hasVisiblePendingWork -> PendingGenerationIndicator.None
    lastVisibleMessageAuthor == MessageAuthor.Agent -> PendingGenerationIndicator.None
    pendingAssistantText.isBlank() -> PendingGenerationIndicator.Thinking
    else -> PendingGenerationIndicator.None
}

internal fun shouldRenderPendingGenerationBlock(
    isSending: Boolean,
    pendingResponseBlocks: List<AssistantResponseBlock>,
    pendingToolInvocations: List<ChatToolInvocation>,
    pendingStatusText: String,
    lastVisibleAgentText: String?,
): Boolean {
    val hasPendingContent = pendingResponseBlocks.isNotEmpty() ||
        pendingToolInvocations.isNotEmpty() ||
        isSending
    if (!hasPendingContent) return false

    val pendingText = pendingResponseBlocks.visibleText().trim()
    val lastAgentText = lastVisibleAgentText?.trim().orEmpty()
    val isCommittedTextEcho = pendingText.isNotBlank() &&
        lastAgentText.isNotBlank() &&
        pendingText == lastAgentText &&
        pendingToolInvocations.isEmpty() &&
        pendingStatusText.isBlank()
    return !isCommittedTextEcho
}

internal fun hasVisibleReasoningStatus(trace: ReasoningTrace): Boolean =
    trace.latestStatusText.isNotBlank() ||
        trace.rawText.isNotBlank() ||
        trace.hasTimelineContent ||
        trace.completedAtMillis != null

private fun topOverlayBodyGradient(): Brush = Brush.verticalGradient(
    colorStops = arrayOf(
        0.0f to ArixBackground.copy(alpha = 0.98f),
        0.28f to ArixBackground.copy(alpha = 0.92f),
        0.58f to ArixBackground.copy(alpha = 0.52f),
        0.82f to ArixBackground.copy(alpha = 0.18f),
        1.0f to Color.Transparent,
    )
)

private fun topOverlayTailGradient(): Brush = Brush.verticalGradient(
    colorStops = arrayOf(
        0.0f to ArixBackground.copy(alpha = 0.10f),
        0.42f to ArixBackground.copy(alpha = 0.04f),
        1.0f to Color.Transparent,
    )
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ConversationScreen(
    conversationStateKey: String,
    messages: List<ChatMessage>,
    workspaceDirectory: String,
    pendingToolInvocations: List<ChatToolInvocation>,
    pendingToolInvocationStateKey: String,
    pendingResponseBlocks: List<AssistantResponseBlock>,
    pendingAssistantText: String,
    pendingStatusText: String,
    pendingStatusDetail: String,
    activeTurnStartedAtMillis: Long?,
    reasoningPhase: ArixReasoningPhase = ArixReasoningPhase.IDLE,
    isCompacting: Boolean,
    pendingInputs: List<PendingSessionInput>,
    inputValue: String,
    draftAttachments: List<ChatAttachment>,
    modelOptions: List<ProviderModelOption>,
    modelCatalogInfo: Map<String, ModelCatalogInfo>,
    selectedModelKey: String,
    reasoningEffort: String,
    thinkingLevelsByProviderModel: Map<String, List<String>>,
    thinkingLevelClampsByProviderModel: Map<String, Map<String, String>>,
    modelLimitsByProviderModel: Map<String, ModelsDevModelLimits> = emptyMap(),
    availableSkills: List<InstalledSkill>,
    selectedSkillIds: List<String>,
    isEditing: Boolean,
    showStarterPromptHint: Boolean,
    recentSessions: List<ChatSession> = emptyList(),
    onOpenSession: (String) -> Unit = {},
    onOpenScreen: (AppScreen) -> Unit = {},
    onInputChanged: (String) -> Unit,
    onModelSelected: (String, (Boolean) -> Unit) -> Unit,
    onModelSelectorOpened: () -> Unit,
    onReasoningEffortSelected: (String) -> Unit,
    onRemoveDraftAttachment: (String) -> Unit,
    onSetSkillSelected: (String, Boolean) -> Unit,
    onCancelEdit: () -> Unit,
    onSend: () -> Unit,
    onQueueFollowUp: () -> Unit,
    onSteerFollowUp: () -> Unit,
    onMenu: () -> Unit,
    onNewChat: () -> Unit,
    onPickImages: () -> Unit,
    onPickFiles: () -> Unit,
    onStartVoiceInput: () -> Unit = {},
    voiceListening: Boolean = false,
    onVoiceListeningSettled: (String) -> Unit = {},
    onVoiceListeningCancelled: () -> Unit = {},
    onSaveAttachment: (ChatAttachment) -> Unit,
    onOpenLink: (String) -> Unit,
    onEditMessage: (String) -> Unit,
    onDeleteMessage: (String) -> Unit,
    onRedoAgentMessage: (String) -> Unit,
    onRetryUserMessage: (String) -> Unit,
    onSwitchUserMessageBranch: (String, Int) -> Unit,
    onCopyMessage: (ChatMessage) -> Unit,
    onPauseGeneration: () -> Unit,
    onDismissStarterPromptHint: () -> Unit,
    canContinueFromCheckpoint: Boolean = false,
    onContinueFromCheckpoint: () -> Unit = {},
    isSending: Boolean,
    bottomBarReserve: Dp = 0.dp,
) {
    val listState = rememberSaveable(
        conversationStateKey,
        saver = LazyListState.Saver,
    ) {
        LazyListState()
    }
    val allowRootImageRead = true
    val conversationItems = remember(messages) { buildConversationListItems(messages) }
    val compactSuggestion = remember(messages) { compactCommandSuggestion(messages) }
    val sessionTotalTokens = remember(messages) {
        messages.sumOf { message -> message.usageStatistics?.totalTokens ?: 0L }
            .takeIf { it > 0L }
    }
    val compactSuggestionText = compactSuggestion.percent?.let { percent ->
        stringResource(R.string.chat_compact_thread_context_percent, percent)
    } ?: stringResource(R.string.chat_compact_thread_context)
    val lastVisibleMessageAuthor = remember(messages) {
        messages.lastOrNull { message ->
            message.displayKind == MessageDisplayKind.Standard
        }?.author
    }
    val lastVisibleAgentText = remember(messages) {
        messages.lastOrNull { message ->
            message.displayKind == MessageDisplayKind.Standard &&
                message.author == MessageAuthor.Agent
        }?.text
    }
    var previewAttachment by remember { mutableStateOf<ChatAttachment?>(null) }
    var shouldAutoFollow by rememberSaveable(conversationStateKey) { mutableStateOf(true) }
    var topBarBodyHeightPx by remember { mutableIntStateOf(0) }
    var composerBodyHeightPx by remember { mutableIntStateOf(0) }
    var composerFocused by remember { mutableStateOf(false) }

    val keyboardController = LocalSoftwareKeyboardController.current
    val focusManager = LocalFocusManager.current
    fun exitComposerInput() {
        keyboardController?.hide()
        focusManager.clearFocus(force = true)
    }
    BackHandler(enabled = composerFocused) {
        exitComposerInput()
    }

    val playbackState by com.arix.app.media.ArixPlaybackController.state.collectAsState()
    var playerSheetOpen by remember { mutableStateOf(false) }
    var miniPlayerHeightPx by remember { mutableIntStateOf(0) }

    val density = LocalDensity.current
    val fallbackTopBarBodyHeight = with(density) {
        WindowInsets.statusBars.getTop(this).toDp() + 68.dp
    }
    val topBarBodyHeight = with(density) {
        if (topBarBodyHeightPx > 0) topBarBodyHeightPx.toDp() else fallbackTopBarBodyHeight
    }
    val composerBodyHeight = with(density) {
        if (composerBodyHeightPx > 0) composerBodyHeightPx.toDp() else 112.dp
    }
    val miniPlayerReserve = with(density) {
        if (playbackState.hasMedia && miniPlayerHeightPx > 0) {
            miniPlayerHeightPx.toDp() + 8.dp
        } else {
            0.dp
        }
    }
    val imeBottom = with(density) {
        WindowInsets.ime.getBottom(this).toDp()
    }
    val animatedImeBottom by animateDpAsState(
        targetValue = imeBottom,
        animationSpec = tween(durationMillis = 260, easing = ChatGptMotionEasing),
        label = "conversation_empty_ime_bottom",
    )
    val animatedImeBottomPx = with(density) { animatedImeBottom.roundToPx() }
    val effectiveNavReserve = if (imeBottom > 0.dp) 0.dp else bottomBarReserve
    val conversationScrollConnection = remember(listState) {
        object : NestedScrollConnection {
            override fun onPostScroll(
                consumed: Offset,
                available: Offset,
                source: NestedScrollSource,
            ): Offset {
                if (source == NestedScrollSource.UserInput) {
                    shouldAutoFollow = listState.isAtConversationBottom()
                }
                return Offset.Zero
            }

            override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
                shouldAutoFollow = listState.isAtConversationBottom()
                return Velocity.Zero
            }
        }
    }

    suspend fun scrollToConversationBottom() {
        val layoutInfo = listState.layoutInfo
        val lastIndex = layoutInfo.totalItemsCount - 1
        if (lastIndex < 0) return
        val lastItem = layoutInfo.visibleItemsInfo.lastOrNull()
        if (lastItem != null && lastItem.index == lastIndex) {
            val itemBottom = lastItem.offset + lastItem.size
            val viewportBottom = layoutInfo.viewportEndOffset
            val delta = itemBottom - viewportBottom + layoutInfo.afterContentPadding
            if (delta > 0) {
                listState.scrollBy(delta.toFloat())
            }
        } else {
            listState.scrollToItem(lastIndex)
            val info = listState.layoutInfo
            val item = info.visibleItemsInfo.lastOrNull()
            if (item != null && item.index == lastIndex) {
                val delta = item.offset + item.size - info.viewportEndOffset + info.afterContentPadding
                if (delta > 0) listState.scrollBy(delta.toFloat())
            }
        }
    }

    val autoFollowContentKey = remember(
        conversationItems,
        pendingInputs,
        pendingResponseBlocks,
        pendingAssistantText,
        pendingToolInvocations,
        pendingStatusText,
        pendingStatusDetail,
        isCompacting,
        isSending,
    ) {
        buildString {
            append(conversationItems.lastOrNull()?.key.orEmpty())
            append('|')
            append(pendingInputs.joinToString("|") { "${it.id}:${it.preview.length}:${it.attachmentCount}" })
            append('|')
            append(
                pendingResponseBlocks.joinToString("|") { block ->
                    when (block) {
                        is AssistantResponseBlock.Text -> "${block.id}:text:${block.text.length}"
                        is AssistantResponseBlock.ToolGroup -> block.toolInvocations.joinToString(
                            prefix = "${block.id}:tools:",
                            separator = ",",
                        ) { invocation ->
                            "${invocation.id}:${invocation.isRunning}:${invocation.outputJson.length}"
                        }
                        is AssistantResponseBlock.Reasoning -> buildString {
                            append("${block.id}:reasoning:")
                            append(block.trace.rawText.length)
                            append(':')
                            append(block.trace.latestStatusText.length)
                            append(':')
                            append(block.trace.completedAtMillis ?: 0L)
                            append(':')
                            append(block.trace.chunks.joinToString(",") { chunk ->
                                "${chunk.id}:${chunk.title.length}:${chunk.detail.length}:${chunk.isPending}:${chunk.timelineOrder}"
                            })
                            append(':')
                            append(block.trace.toolInvocations.joinToString(",") { invocation ->
                                "${invocation.id}:${invocation.isRunning}:${invocation.outputJson.length}:${invocation.startedAtMillis}:${invocation.completedAtMillis ?: 0L}:${invocation.timelineOrder}"
                            })
                        }
                        is AssistantResponseBlock.Status ->
                            "${block.id}:status:${block.text}:${block.detail}"
                    }
                }
            )
            append('|')
            append(pendingAssistantText.length)
            append('|')
            append(
                pendingToolInvocations.joinToString("|") { invocation ->
                    "${invocation.id}:${invocation.isRunning}:${invocation.outputJson.length}"
                }
            )
            append('|')
            append(pendingStatusText)
            append('|')
            append(pendingStatusDetail)
            append('|')
            append(isCompacting)
            append('|')
            append(isSending)
        }
    }
    val latestContentKey by rememberUpdatedState(autoFollowContentKey)
    val latestGenerating by rememberUpdatedState(
        isSending || isCompacting || pendingResponseBlocks.isNotEmpty() ||
            pendingToolInvocations.isNotEmpty() || pendingAssistantText.isNotEmpty(),
    )
    LaunchedEffect(listState, shouldAutoFollow) {
        if (!shouldAutoFollow) return@LaunchedEffect
        snapshotFlow { latestContentKey + "|" + latestGenerating + "|" + listState.layoutInfo.totalItemsCount }
            .collectLatest {
                var calmSince = -1L
                while (shouldAutoFollow) {
                    val now = withFrameNanos { it }
                    if (calmSince < 0L) calmSince = now
                    if (listState.layoutInfo.totalItemsCount > 0 && !listState.isScrollInProgress) {
                        scrollToConversationBottom()
                    }
                    if (!latestGenerating && now - calmSince > 650_000_000L) break
                }
            }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = ArixBackground,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(ArixBackgroundGradientTop, ArixBackground, ArixSurface)
                    )
                )
                .padding(innerPadding)
                .pointerInput(Unit) {
                    detectTapGestures {
                        exitComposerInput()
                    }
                }
        ) {
            if (messages.isEmpty()) {
                // v3.1.14 — extension surfaces for the empty-chat state.
                ArixExtensionSlot(
                    slot = ArixExtensionSlotChatEmpty,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .fillMaxWidth()
                        .padding(
                            start = 22.dp,
                            end = 22.dp,
                            top = topBarBodyHeight,
                            bottom = composerBodyHeight + miniPlayerReserve +
                                effectiveNavReserve + animatedImeBottom + 26.dp,
                        ),
                )
                IstGreetingHeader(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .fillMaxWidth()
                        .padding(
                            start = 22.dp,
                            end = 22.dp,
                            top = topBarBodyHeight,
                            bottom = composerBodyHeight + miniPlayerReserve +
                                effectiveNavReserve + animatedImeBottom + 26.dp,
                        ),
                    recentSessions = recentSessions,
                    onOpenSession = onOpenSession,
                    onOpenScreen = onOpenScreen,
                    isThinking = isSending,
                    isListening = voiceListening,
                    imeVisible = imeBottom > 0.dp,
                    musicActive = playbackState.hasMedia &&
                        (playbackState.isPlaying || playbackState.isBuffering),
                )
            } else {
                StreamingRevealHost(conversationKey = conversationStateKey) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize()
                        .nestedScroll(conversationScrollConnection),
                    contentPadding = PaddingValues(
                        start = 20.dp,
                        end = 20.dp,
                        top = topBarBodyHeight + 10.dp,
                        bottom = composerBodyHeight + miniPlayerReserve +
                            effectiveNavReserve + animatedImeBottom + 28.dp,
                    ),
                    verticalArrangement = Arrangement.spacedBy(22.dp),
                ) {
                    items(
                        conversationItems,
                        key = { it.key },
                        contentType = { it::class.simpleName ?: "item" },
                    ) { item ->
                        when (item) {
                            is ConversationListItem.Message -> {
                                val message = item.message
                                ConversationMessageBubble(
                                    message = message,
                                    actionsEnabled = !isSending,
                                    workspaceDirectory = workspaceDirectory,
                                    allowRootImageRead = allowRootImageRead,
                                    onOpenAttachment = { previewAttachment = it },
                                    onOpenLink = onOpenLink,
                                    onEdit = { onEditMessage(message.id) },
                                    onDelete = { onDeleteMessage(message.id) },
                                    onCopy = { onCopyMessage(message) },
                                    onRedo = { onRedoAgentMessage(message.id) },
                                    onRetry = { onRetryUserMessage(message.id) },
                                    onSwitchBranch = { delta -> onSwitchUserMessageBranch(message.id, delta) },
                                    sessionTotalTokens = sessionTotalTokens,
                                )
                            }

                            is ConversationListItem.AssistantGroup -> {
                                val lastMessage = item.messages.last()
                                ConversationAssistantGroupBubble(
                                    messages = item.messages,
                                    actionsEnabled = !isSending,
                                    workspaceDirectory = workspaceDirectory,
                                    allowRootImageRead = allowRootImageRead,
                                    onOpenAttachment = { previewAttachment = it },
                                    onOpenLink = onOpenLink,
                                    onCopy = {
                                        onCopyMessage(
                                            lastMessage.copy(
                                                text = item.messages.joinToString("\n\n") { message -> message.text }
                                                    .trim(),
                                            )
                                        )
                                    },
                                    onRedo = { onRedoAgentMessage(lastMessage.id) },
                                    onDelete = { onDeleteMessage(lastMessage.id) },
                                    sessionTotalTokens = sessionTotalTokens,
                                )
                            }

                            is ConversationListItem.CompactStatus -> {
                                CompactStatusDivider(text = item.message.text.ifBlank { stringResource(R.string.chat_context_compacted) })
                            }
                        }
                    }
                    if (canContinueFromCheckpoint && !isSending) {
                        item(key = "checkpoint-continue-chip") {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                OutlinedButton(
                                    onClick = onContinueFromCheckpoint,
                                    modifier = Modifier.weight(1f),
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.PlayArrow,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                    )
                                    Spacer(Modifier.width(6.dp))
                                    Text(stringResource(R.string.chat_continue_from_checkpoint))
                                }
                            }
                        }
                    }
                    if (isCompacting) {
                        item(key = "compact-running-status") {
                            CompactStatusDivider(
                                text = stringResource(R.string.chat_compacting_context),
                                isRunning = true,
                            )
                        }
                    }
                    if (
                        shouldRenderPendingGenerationBlock(
                            isSending = isSending,
                            pendingResponseBlocks = pendingResponseBlocks,
                            pendingToolInvocations = pendingToolInvocations,
                            pendingStatusText = pendingStatusText,
                            lastVisibleAgentText = lastVisibleAgentText,
                        )
                    ) {
                        item(key = "pending-generation-block") {
                            val indicator = pendingGenerationIndicator(
                                isSending = isSending,
                                pendingAssistantText = pendingAssistantText,
                                pendingStatusText = pendingStatusText,
                                hasVisiblePendingWork = pendingResponseBlocks.hasVisiblePendingWork() ||
                                    pendingToolInvocations.isNotEmpty(),
                                lastVisibleMessageAuthor = lastVisibleMessageAuthor,
                                hasVisiblePendingReasoning = pendingResponseBlocks.any {
                                    it is AssistantResponseBlock.Reasoning &&
                                        hasVisibleReasoningStatus(it.trace)
                                },
                            )
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                when (indicator) {
                                    PendingGenerationIndicator.Thinking -> {
                                        ConversationThinkingIndicator()
                                    }

                                    PendingGenerationIndicator.Status -> Unit

                                    PendingGenerationIndicator.None -> Unit
                                }
                                PendingAssistantTimeline(
                                    blocks = pendingResponseBlocks,
                                    workspaceDirectory = workspaceDirectory,
                                    allowRootImageRead = allowRootImageRead,
                                    onOpenLink = onOpenLink,
                                    pendingToolInvocationStateKey = pendingToolInvocationStateKey,
                                    pendingToolInvocations = pendingToolInvocations,
                                    activeTurnStartedAtMillis = activeTurnStartedAtMillis,
                                    reasoningPhase = reasoningPhase,
                                    statusText = if (indicator == PendingGenerationIndicator.Status) {
                                        pendingStatusText
                                    } else {
                                        ""
                                    },
                                    statusDetail = if (indicator == PendingGenerationIndicator.Status) {
                                        pendingStatusDetail
                                    } else {
                                        ""
                                    },
                                    showStatusFallback = indicator == PendingGenerationIndicator.Status,
                                )
                            }
                        }
                    }
                    items(pendingInputs, key = { it.id }) { pendingInput ->
                        PendingSessionInputBubble(pendingInput = pendingInput)
                    }
                    item(key = "conversation-bottom-anchor") {
                        Spacer(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(1.dp)
                        )
                    }
                }
                }
            }

            ConversationTopOverlay(
                modifier = Modifier.align(Alignment.TopCenter),
                onBodyHeightChanged = { topBarBodyHeightPx = it },
                modelOptions = modelOptions,
                modelCatalogInfo = modelCatalogInfo,
                selectedModelKey = selectedModelKey,
                reasoningEffort = reasoningEffort,
                thinkingLevelsByProviderModel = thinkingLevelsByProviderModel,
                thinkingLevelClampsByProviderModel = thinkingLevelClampsByProviderModel,
                modelLimitsByProviderModel = modelLimitsByProviderModel,
                onMenu = onMenu,
                onModelSelected = onModelSelected,
                onModelSelectorOpened = onModelSelectorOpened,
                onReasoningEffortSelected = onReasoningEffortSelected,
                onNewChat = onNewChat,
                isCompanionListening = voiceListening,
                isCompanionThinking = isSending,
            )

            // v3.1.14 — extension surfaces: anything pinned to chat.top sits
            // directly under the top bar.
            ArixExtensionSlot(
                slot = ArixExtensionSlotChatTop,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .padding(top = topBarBodyHeight),
            )

            // v3.1.14 — extension composer menu items + composer-top surfaces,
            // stacked right above the composer.
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(
                        bottom = composerBodyHeight + miniPlayerReserve +
                            effectiveNavReserve + animatedImeBottom,
                    ),
            ) {
                ArixComposerExtensionSurface()
            }

            ConversationComposerOverlay(
                modifier = Modifier.align(Alignment.BottomCenter),
                conversationStateKey = conversationStateKey,
                onBodyHeightChanged = { composerBodyHeightPx = it },
                bottomBarReserve = effectiveNavReserve,
                value = inputValue,
                attachments = draftAttachments,
                availableSkills = availableSkills,
                selectedSkillIds = selectedSkillIds,
                isEditing = isEditing,
                isSending = isSending,
                showStarterPromptHint = showStarterPromptHint,
                compactSuggestionText = compactSuggestionText,
                onValueChange = onInputChanged,
                onRemoveAttachment = onRemoveDraftAttachment,
                onSetSkillSelected = onSetSkillSelected,
                onCancelEdit = onCancelEdit,
                onPickImages = onPickImages,
                onPickFiles = onPickFiles,
                onStartVoiceInput = onStartVoiceInput,
                voiceListening = voiceListening,
                onVoiceListeningSettled = onVoiceListeningSettled,
                onVoiceListeningCancelled = onVoiceListeningCancelled,
                onPauseGeneration = onPauseGeneration,
                onDismissStarterPromptHint = onDismissStarterPromptHint,
                onFocusChanged = { composerFocused = it },
                onSend = onSend,
                onQueueFollowUp = onQueueFollowUp,
                onSteerFollowUp = onSteerFollowUp,
            )

            AnimatedVisibility(
                visible = playbackState.hasMedia,
                modifier = Modifier.align(Alignment.BottomCenter),
                enter = slideInVertically(animationSpec = tween(280)) { it / 2 } + fadeIn(),
                exit = slideOutVertically(animationSpec = tween(220)) { it / 2 } + fadeOut(),
            ) {
                ArixMiniPlayer(
                    modifier = Modifier
                        .padding(
                            bottom = composerBodyHeight +
                                WindowInsets.navigationBars.asPaddingValues()
                                    .calculateBottomPadding()
                                    .coerceAtMost(ArixBottomNavInsetCap) +
                                (if (imeBottom > 0.dp) 12.dp else ComposerBottomGap) +
                                effectiveNavReserve +
                                MiniPlayerGap +
                                animatedImeBottom,
                        )
                        .onSizeChanged { miniPlayerHeightPx = it.height },
                    onExpand = { playerSheetOpen = true },
                )
            }
            if (playerSheetOpen) {
                ArixPlayerSheet(onDismiss = { playerSheetOpen = false })
            }

            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth(0.92f)
                    .padding(
                        bottom = composerBodyHeight +
                            WindowInsets.navigationBars.asPaddingValues()
                                .calculateBottomPadding()
                                .coerceAtMost(ArixBottomNavInsetCap) +
                            (if (imeBottom > 0.dp) 12.dp else ComposerBottomGap) +
                            effectiveNavReserve +
                            MiniPlayerGap +
                            animatedImeBottom +
                            (if (playbackState.hasMedia) {
                                with(density) { miniPlayerHeightPx.toDp() } + MiniPlayerGap
                            } else {
                                0.dp
                            }),
                    ),
            ) {
                ArixUploadProgressWidget()
            }

            previewAttachment?.let { attachment ->
                AttachmentPreviewDialog(
                    attachment = attachment,
                    onDismiss = { previewAttachment = null },
                    onSave = { onSaveAttachment(attachment) },
                )
            }

            // v3.1.15 — the agent phone-control small live view (Mika port): a
            // floating watch-only window over the conversation, dragged anywhere,
            // spring-snapping to a corner; green border while working, breathing
            // orange when it needs you; close leaves a small button bottom-right.
            val phoneAgentContext = LocalContext.current
            val phoneAgent = remember { ArixPhoneAgent.of(phoneAgentContext) }
            val pipScope = androidx.compose.runtime.rememberCoroutineScope()
            val pipState by phoneAgent.pip.collectAsState()
            val liveFrame by phoneAgent.frames.collectAsState()
            // Hold the last frame while the done look is on screen.
            var lastPipFrame by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
            LaunchedEffect(liveFrame, pipState.mode) {
                liveFrame?.let { lastPipFrame = it }
            }
            val pipFrame = liveFrame
                ?: lastPipFrame.takeIf { pipState.visible && pipState.mode == ArixPipMode.Done }
            if (pipState.visible) {
                ArixAgentPip(
                    pip = pipState,
                    frame = pipFrame,
                    webContent = false,
                    reduceMotion = LocalReduceMotion.current,
                    topInset = with(density) { topBarBodyHeight.toPx() },
                    bottomInset = with(density) {
                        (composerBodyHeight + miniPlayerReserve + effectiveNavReserve + animatedImeBottom).toPx()
                    },
                    onExpand = phoneAgent::pipExpand,
                    onCollapse = phoneAgent::pipCollapse,
                    onAttention = {
                        phoneAgent.pipAttend()
                        pipScope.launch { scrollToConversationBottom() }
                    },
                    onClose = {
                        phoneAgent.pipClose()
                    },
                    onReopen = phoneAgent::pipReopen,
                )
            }
        }
    }
}

private fun LazyListState.isAtConversationBottom(): Boolean {
    val layoutInfo = layoutInfo
    if (layoutInfo.totalItemsCount == 0) return true
    val lastVisibleItem = layoutInfo.visibleItemsInfo.lastOrNull() ?: return true
    val isLastItemVisible = lastVisibleItem.index == layoutInfo.totalItemsCount - 1
    val distanceFromBottom = layoutInfo.viewportEndOffset - (lastVisibleItem.offset + lastVisibleItem.size)
    return isLastItemVisible && distanceFromBottom >= -32
}

@Composable
private fun ConversationTopOverlay(
    modifier: Modifier = Modifier,
    onBodyHeightChanged: (Int) -> Unit,
    modelOptions: List<ProviderModelOption>,
    modelCatalogInfo: Map<String, ModelCatalogInfo>,
    selectedModelKey: String,
    reasoningEffort: String,
    thinkingLevelsByProviderModel: Map<String, List<String>>,
    thinkingLevelClampsByProviderModel: Map<String, Map<String, String>>,
    modelLimitsByProviderModel: Map<String, ModelsDevModelLimits>,
    onMenu: () -> Unit,
    onModelSelected: (String, (Boolean) -> Unit) -> Unit,
    onModelSelectorOpened: () -> Unit,
    onReasoningEffortSelected: (String) -> Unit,
    onNewChat: () -> Unit,
    isCompanionListening: Boolean = false,
    isCompanionThinking: Boolean = false,
) {
    Column(
        modifier = modifier.fillMaxWidth(),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(topOverlayBodyGradient())
                .onSizeChanged { onBodyHeightChanged(it.height) },
        ) {
            Column {
                ConversationTopBar(
                    modelOptions = modelOptions,
                    modelCatalogInfo = modelCatalogInfo,
                    selectedModelKey = selectedModelKey,
                    reasoningEffort = reasoningEffort,
                    thinkingLevelsByProviderModel = thinkingLevelsByProviderModel,
                    thinkingLevelClampsByProviderModel = thinkingLevelClampsByProviderModel,
                    modelLimitsByProviderModel = modelLimitsByProviderModel,
                    onMenu = onMenu,
                    onModelSelected = onModelSelected,
                    onModelSelectorOpened = onModelSelectorOpened,
                    onReasoningEffortSelected = onReasoningEffortSelected,
                    onNewChat = onNewChat,
                    isCompanionListening = isCompanionListening,
                    isCompanionThinking = isCompanionThinking,
                )
            }
        }
        Spacer(
            modifier = Modifier
                .fillMaxWidth()
                .height(ConversationTopFadeHeight)
                .background(topOverlayTailGradient())
        )
    }
}

@Composable
private fun ConversationTopBar(
    modifier: Modifier = Modifier,
    modelOptions: List<ProviderModelOption>,
    modelCatalogInfo: Map<String, ModelCatalogInfo>,
    selectedModelKey: String,
    reasoningEffort: String,
    thinkingLevelsByProviderModel: Map<String, List<String>>,
    thinkingLevelClampsByProviderModel: Map<String, Map<String, String>>,
    modelLimitsByProviderModel: Map<String, ModelsDevModelLimits>,
    onMenu: () -> Unit,
    onModelSelected: (String, (Boolean) -> Unit) -> Unit,
    onModelSelectorOpened: () -> Unit,
    onReasoningEffortSelected: (String) -> Unit,
    onNewChat: () -> Unit,
    isCompanionListening: Boolean = false,
    isCompanionThinking: Boolean = false,
) {
    ArixConversationTopBarFrame(
        modifier = modifier
            .fillMaxWidth()
            .statusBarsPadding(),
        menuDescription = stringResource(R.string.common_menu),
        onMenu = onMenu,
        showCompanion = true,
        companionSlot = {
            com.arix.app.companion.ArixChatHeaderCompanion(
                isListening = isCompanionListening,
                isThinking = isCompanionThinking,
                onTap = onNewChat,
            )
        },
    ) {
        ConversationModelSelector(
            options = modelOptions,
            modelCatalogInfo = modelCatalogInfo,
            selectedModelKey = selectedModelKey,
            reasoningEffort = reasoningEffort,
            thinkingLevelsByProviderModel = thinkingLevelsByProviderModel,
            thinkingLevelClampsByProviderModel = thinkingLevelClampsByProviderModel,
            modelLimitsByProviderModel = modelLimitsByProviderModel,
            onSelected = onModelSelected,
            onOpened = onModelSelectorOpened,
            onReasoningEffortSelected = onReasoningEffortSelected,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Composable
private fun ConversationModelSelector(
    options: List<ProviderModelOption>,
    modelCatalogInfo: Map<String, ModelCatalogInfo>,
    selectedModelKey: String,
    reasoningEffort: String,
    thinkingLevelsByProviderModel: Map<String, List<String>>,
    thinkingLevelClampsByProviderModel: Map<String, Map<String, String>>,
    modelLimitsByProviderModel: Map<String, ModelsDevModelLimits>,
    onSelected: (String, (Boolean) -> Unit) -> Unit,
    onOpened: () -> Unit,
    onReasoningEffortSelected: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    var expanded by remember { mutableStateOf(false) }
    var showingReasoningEffort by remember { mutableStateOf(false) }
    var menuSelectedModelKey by remember { mutableStateOf(selectedModelKey) }
    var anchorHeightPx by remember { mutableIntStateOf(0) }
    val menuVisibility = remember { MutableTransitionState(false) }
    menuVisibility.targetState = expanded
    val density = LocalDensity.current
    val menuWidth = 242.dp
    val selectedOption = options.firstOrNull { it.key == menuSelectedModelKey } ?: options.firstOrNull()
    val activeOption = options.firstOrNull { it.key == selectedModelKey } ?: options.firstOrNull()
    val supportedThinkingLevels = selectedOption?.let { option ->
        thinkingLevelsByProviderModel[thinkingCatalogKey(option.piProviderId, option.modelId)]
    }.orEmpty().let { levels ->
        if (levels.isEmpty() || levels.none { it != "off" }) {
            SupportedReasoningEfforts
        } else {
            levels
        }
    }
    val effectiveReasoningEffort = selectedOption?.let { option ->
        thinkingLevelClampsByProviderModel[thinkingCatalogKey(option.piProviderId, option.modelId)]
            ?.get(reasoningEffort)
            ?.takeIf { mapped -> supportedThinkingLevels.contains(mapped) }
    } ?: reasoningEffort
    val fallbackLabel = stringResource(R.string.chat_select_model)
    val selectedDisplay = remember(selectedOption, modelCatalogInfo) {
        selectedOption?.let { option ->
            formatSelectedModelDisplayName(
                rawName = modelCatalogInfo[option.key]?.displayName ?: option.modelId,
            )
        }
    }
    val activeDisplay = remember(activeOption, modelCatalogInfo) {
        activeOption?.let { option ->
            formatSelectedModelDisplayName(
                rawName = modelCatalogInfo[option.key]?.displayName ?: option.modelId,
            )
        }
    }
    val selectedModelName = selectedDisplay
        ?.let { display -> listOf(display.primary, display.secondary).filter(String::isNotBlank) }
        ?.joinToString(" ")
        ?.takeIf(String::isNotBlank)
        ?: selectedOption?.chatLabel
        ?: fallbackLabel

    Box(
        modifier = modifier,
        contentAlignment = Alignment.CenterStart,
    ) {
        Box(
            modifier = Modifier.height(38.dp)
                .onGloballyPositioned { coordinates ->
                    val bounds = coordinates.boundsInWindow()
                    anchorHeightPx = bounds.height.toInt()
                },
        ) {
            Box(
                modifier = Modifier.matchParentSize()
                    .offset(y = 4.dp)
                    .blur(14.dp, edgeTreatment = BlurredEdgeTreatment.Unbounded)
                    .clip(RoundedCornerShape(999.dp))
                    .background(ChatGptControlShadow),
            )
            Row(
                modifier = Modifier.height(38.dp)
                    .clip(RoundedCornerShape(999.dp))
                    .background(ArixSurface.copy(alpha = 0.96f))
                    .clickable(enabled = options.isNotEmpty()) {
                        onOpened()
                        menuSelectedModelKey = selectedModelKey
                        showingReasoningEffort = false
                        expanded = true
                },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (activeDisplay != null) {
                    SelectedModelDisplay(
                        displayName = activeDisplay,
                        modifier = Modifier
                            .widthIn(max = 240.dp)
                            .padding(horizontal = 17.dp),
                    )
                } else {
                    Text(
                        text = fallbackLabel,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Normal),
                        color = ArixOnSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier
                            .widthIn(max = 220.dp)
                            .padding(horizontal = 17.dp),
                    )
                }
            }
        }

        if (menuVisibility.currentState || menuVisibility.targetState) {
            Popup(
                alignment = Alignment.TopStart,
                offset = IntOffset(0, anchorHeightPx + with(density) { 10.dp.roundToPx() }),
                onDismissRequest = { expanded = false },
                properties = PopupProperties(
                    focusable = true,
                    dismissOnBackPress = true,
                    dismissOnClickOutside = true,
                ),
            ) {
                androidx.compose.animation.AnimatedVisibility(
                    visibleState = menuVisibility,
                    enter = fadeIn() + scaleIn(
                        initialScale = 0.96f,
                        transformOrigin = TransformOrigin(0.5f, 0f),
                    ) + slideInVertically(initialOffsetY = { -it / 10 }),
                    exit = fadeOut() + scaleOut(
                        targetScale = 0.98f,
                        transformOrigin = TransformOrigin(0.5f, 0f),
                    ) + slideOutVertically(targetOffsetY = { -it / 12 }),
                ) {
                    AnimatedContent(
                        targetState = showingReasoningEffort && supportedThinkingLevels.isNotEmpty(),
                        transitionSpec = {
                            val enteringOffset: (Int) -> Int = { width ->
                                if (targetState) width / 10 else -width / 10
                            }
                            val exitingOffset: (Int) -> Int = { width ->
                                if (targetState) -width / 10 else width / 10
                            }
                            (
                                fadeIn(
                                    animationSpec = tween(
                                        durationMillis = 220,
                                        delayMillis = 60,
                                        easing = ChatGptMotionEasing,
                                    ),
                                ) + slideInHorizontally(
                                    animationSpec = tween(
                                        durationMillis = 340,
                                        easing = ChatGptMotionEasing,
                                    ),
                                    initialOffsetX = enteringOffset,
                                )
                            ).togetherWith(
                                fadeOut(
                                    animationSpec = tween(
                                        durationMillis = 150,
                                        easing = ChatGptMotionEasing,
                                    ),
                                ) + slideOutHorizontally(
                                    animationSpec = tween(
                                        durationMillis = 280,
                                        easing = ChatGptMotionEasing,
                                    ),
                                    targetOffsetX = exitingOffset,
                                )
                            ).using(
                                SizeTransform(clip = false) { _, _ ->
                                    tween(
                                        durationMillis = 360,
                                        easing = ChatGptMotionEasing,
                                    )
                                }
                            )
                        },
                        modifier = Modifier
                            .width(menuWidth)
                            .shadow(14.dp, RoundedCornerShape(22.dp), ambientColor = ArixScrim, spotColor = ArixScrim)
                            .clip(RoundedCornerShape(22.dp))
                            .background(ArixSurface)
                            .padding(vertical = 5.dp),
                        label = "conversation-model-menu-mode",
                    ) {
                        if (it) {
                            ConversationReasoningEffortMenu(
                                efforts = supportedThinkingLevels,
                                selectedEffort = effectiveReasoningEffort,
                                selectedModelName = selectedModelName,
                                onBack = { showingReasoningEffort = false },
                                onSelected = { effort ->
                                    onReasoningEffortSelected(effort)
                                    expanded = false
                                },
                            )
                        } else {
                            ConversationModelListMenu(
                                options = options,
                                modelCatalogInfo = modelCatalogInfo,
                                modelLimitsByProviderModel = modelLimitsByProviderModel,
                                selectedOption = selectedOption,
                                reasoningEffort = effectiveReasoningEffort,
                                showReasoningEffort = supportedThinkingLevels.isNotEmpty(),
                                onReasoningEffortClick = { showingReasoningEffort = true },
                                onSelected = { option ->
                                    menuSelectedModelKey = option.key
                                    onSelected(option.key) { hasThinkingLevels ->
                                        if (expanded && menuSelectedModelKey == option.key) {
                                            if (hasThinkingLevels) {
                                                showingReasoningEffort = true
                                            } else {
                                                expanded = false
                                            }
                                        }
                                    }
                                },
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun reasoningEffortLabel(effort: String): String = when (effort.trim().lowercase()) {
    "off" -> stringResource(R.string.chat_reasoning_effort_off)
    "minimal" -> stringResource(R.string.chat_reasoning_effort_minimal)
    "low" -> stringResource(R.string.chat_reasoning_effort_low)
    "medium" -> stringResource(R.string.chat_reasoning_effort_medium)
    "high" -> stringResource(R.string.chat_reasoning_effort_high)
    "xhigh" -> stringResource(R.string.chat_reasoning_effort_xhigh)
    "max" -> stringResource(R.string.chat_reasoning_effort_max)
    else -> effort.trim().replaceFirstChar { it.titlecase() }
}

@Composable
private fun ConversationMenuModeEntry(
    title: String,
    value: String,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(start = 19.dp, end = 14.dp, top = 10.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                color = ArixOnSurface,
            )
            Text(
                text = value,
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun ConversationReasoningEffortMenu(
    efforts: List<String>,
    selectedEffort: String,
    selectedModelName: String,
    onBack: () -> Unit,
    onSelected: (String) -> Unit,
) {
    Column(
        horizontalAlignment = Alignment.Start,
    ) {
        ConversationMenuModeEntry(
            title = stringResource(R.string.chat_model),
            value = selectedModelName,
            onClick = onBack,
        )
        efforts.forEach { effort ->
            val selected = effort == selectedEffort
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 5.dp, vertical = 1.dp)
                    .clip(RoundedCornerShape(15.dp))
                    .background(
                        if (selected) ArixOnSurface.copy(alpha = 0.06f) else Color.Transparent,
                    )
                    .clickable { onSelected(effort) }
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = reasoningEffortLabel(effort),
                    style = MaterialTheme.typography.bodyMedium,
                    color = ArixOnSurface,
                    modifier = Modifier.weight(1f),
                )
                if (selected) {
                    Icon(
                        imageVector = Icons.Rounded.Check,
                        contentDescription = null,
                        tint = ArixOnSurfaceVariant,
                        modifier = Modifier.size(16.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun ConversationModelListMenu(
    options: List<ProviderModelOption>,
    modelCatalogInfo: Map<String, ModelCatalogInfo>,
    modelLimitsByProviderModel: Map<String, ModelsDevModelLimits>,
    selectedOption: ProviderModelOption?,
    reasoningEffort: String,
    showReasoningEffort: Boolean,
    onReasoningEffortClick: () -> Unit,
    onSelected: (ProviderModelOption) -> Unit,
) {
    Column(
        horizontalAlignment = Alignment.Start,
    ) {
        if (showReasoningEffort) {
            ConversationMenuModeEntry(
                title = stringResource(R.string.chat_reasoning_effort),
                value = reasoningEffortLabel(reasoningEffort),
                onClick = onReasoningEffortClick,
            )
        }
        Column(
            modifier = Modifier
                .heightIn(max = 312.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.Start,
        ) {
            options.forEach { option ->
                ConversationModelMenuRow(
                    label = option.chatLabel,
                    catalogInfo = modelCatalogInfo[option.key],
                    limits = modelLimitsByProviderModel[
                        thinkingCatalogKey(option.piProviderId, option.modelId)
                    ],
                    selected = option.key == selectedOption?.key,
                    onClick = { onSelected(option) },
                )
            }
        }
    }
}

@Composable
private fun ConversationModelMenuRow(
    label: String,
    catalogInfo: ModelCatalogInfo?,
    limits: ModelsDevModelLimits?,
    selected: Boolean,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 5.dp, vertical = 1.dp)
            .clip(RoundedCornerShape(15.dp))
            .background(if (selected) ArixOnSurface.copy(alpha = 0.06f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 9.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(9.dp),
    ) {
        LabLogoBadge(
            catalogInfo = catalogInfo,
            modifier = Modifier.size(22.dp),
        )
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Normal),
                color = ArixOnSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Start,
            )
            val limitsText = limits?.toMenuLimitsLabel()
            if (limitsText != null) {
                Text(
                    text = limitsText,
                    style = MaterialTheme.typography.labelSmall,
                    color = ArixOnSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        if (selected) {
            Icon(
                imageVector = Icons.Rounded.Check,
                contentDescription = null,
                tint = ArixOnSurfaceVariant,
                modifier = Modifier.size(16.dp),
            )
        }
    }
}

private fun ModelsDevModelLimits.toMenuLimitsLabel(): String? {
    val context = contextWindow?.let(::formatModelLimitTokenCount)
    val output = maxOutputTokens?.let(::formatModelLimitTokenCount)
    return when {
        context != null && output != null -> "$context ctx · $output out"
        context != null -> "$context ctx"
        output != null -> "$output out"
        else -> null
    }
}

private fun formatModelLimitTokenCount(tokens: Int): String = when {
    tokens >= 1_000_000 -> {
        if (tokens % 1_000_000 == 0) "${tokens / 1_000_000}M"
        else String.format(java.util.Locale.US, "%.1fM", tokens / 1_000_000.0)
    }
    tokens >= 1_000 -> {
        if (tokens % 1_000 == 0) "${tokens / 1_000}K"
        else String.format(java.util.Locale.US, "%.1fK", tokens / 1_000.0)
    }
    else -> tokens.toString()
}

@Composable
private fun LabLogoBadge(
    catalogInfo: ModelCatalogInfo?,
    modifier: Modifier = Modifier,
) {
    val info = catalogInfo
    val logoPaths = remember(catalogInfo) {
        info?.toLabLogoPaths().orEmpty()
    }
    if (info != null && logoPaths.isNotEmpty()) {
        Canvas(
            modifier = modifier,
        ) {
            val scaleX = size.width / info.labLogoViewportWidth
            val scaleY = size.height / info.labLogoViewportHeight
            scale(scaleX = scaleX, scaleY = scaleY, pivot = Offset.Zero) {
                logoPaths.forEach { path ->
                    drawPath(path = path, color = labLogoTint())
                }
            }
        }
        return
    }
    Box(
        modifier = modifier,
    )
}

private fun ModelCatalogInfo.toLabLogoPaths(): List<Path> {
    if (labLogoPathData.isEmpty()) return emptyList()
    return labLogoPathData.mapNotNull { pathData ->
        runCatching {
            PathParser.createPathFromPathData(pathData).asComposePath()
        }.getOrNull()
    }
}

private fun labLogoTint(): Color = ArixOnSurface

@Composable
private fun SelectedModelDisplay(
    displayName: SelectedModelDisplayName,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        Text(
            text = displayName.primary,
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Normal),
            color = ArixOnSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        if (displayName.secondary.isNotBlank()) {
            Text(
                text = displayName.secondary,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Normal),
                color = ArixOnSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f, fill = false),
            )
        }
        displayName.icon?.let { icon ->
            Icon(
                imageVector = when (icon) {
                    SelectedModelDisplayIcon.Fast -> LucideIcons.Zap
                    SelectedModelDisplayIcon.Reasoning -> LucideIcons.Brain
                },
                contentDescription = null,
                tint = ArixOnSurfaceVariant,
                modifier = Modifier.size(15.dp),
            )
        }
    }
}

internal data class SelectedModelDisplayName(
    val primary: String,
    val secondary: String,
    val icon: SelectedModelDisplayIcon? = null,
)

internal enum class SelectedModelDisplayIcon {
    Fast,
    Reasoning,
}

internal fun formatSelectedModelDisplayName(rawName: String): SelectedModelDisplayName {
    val normalizedTokens = rawName
        .trim()
        .substringAfterLast('/')
        .replace(Regex("[()]"), " ")
        .split(Regex("[\\s_-]+"))
        .mapNotNull { token ->
            token.trim().takeIf { it.isNotEmpty() }
        }
    val icon = when {
        normalizedTokens.any { it.equals("reasoning", ignoreCase = true) || it.equals("thinking", ignoreCase = true) } ->
            SelectedModelDisplayIcon.Reasoning
        normalizedTokens.any { token ->
            token.equals("ultraspeed", ignoreCase = true) ||
                token.equals("fast", ignoreCase = true) ||
                token.equals("spark", ignoreCase = true) ||
                token.equals("highspeed", ignoreCase = true)
        } -> SelectedModelDisplayIcon.Fast
        else -> null
    }
    val visibleTokens = normalizedTokens
        .filterNot { token ->
            token.equals("preview", ignoreCase = true) ||
                token.equals("reasoning", ignoreCase = true) ||
                token.equals("thinking", ignoreCase = true) ||
                token.equals("ultraspeed", ignoreCase = true) ||
                token.equals("fast", ignoreCase = true) ||
                token.equals("spark", ignoreCase = true) ||
                token.equals("highspeed", ignoreCase = true)
        }
        .let { tokens ->
            val isLong = tokens.joinToString(" ").length > 28 || tokens.size > 4
            if (!isLong) {
                tokens
            } else {
                tokens.filterNot { token -> token.matches(Regex("\\d+b", RegexOption.IGNORE_CASE)) || token.matches(Regex("a\\d+b", RegexOption.IGNORE_CASE)) }
            }
        }
    if (visibleTokens.isEmpty()) {
        return SelectedModelDisplayName(primary = rawName.trim().ifBlank { "" }, secondary = "", icon = icon)
    }
    val splitFirst = splitTrailingNumber(visibleTokens.first())
    val primary = titleModelToken(splitFirst.first)
    val secondaryTokens = buildList {
        splitFirst.second?.takeIf { it.isNotBlank() }?.let(::add)
        addAll(visibleTokens.drop(1))
    }
    return SelectedModelDisplayName(
        primary = primary,
        secondary = secondaryTokens.joinToString(" ") { titleModelToken(it) },
        icon = icon,
    )
}

private fun splitTrailingNumber(token: String): Pair<String, String?> {
    val match = Regex("^([A-Za-z]+)(\\d[\\w.]*)$").matchEntire(token) ?: return token to null
    return match.groupValues[1] to match.groupValues[2]
}

private fun titleModelToken(token: String): String {
    if (token.isBlank()) return token
    val uppercaseToken = token.uppercase()
    if (uppercaseToken == token && token.any(Char::isLetter)) return token
    if (token.equals("gpt", ignoreCase = true) || token.equals("glm", ignoreCase = true)) {
        return token.uppercase()
    }
    if (token.startsWith("v") && token.drop(1).firstOrNull()?.isDigit() == true) {
        return "v" + token.drop(1)
    }
    if (token.first().isDigit()) return token
    return token.replaceFirstChar { char ->
        if (char.isLowerCase()) char.titlecase(Locale.getDefault()) else char.toString()
    }
}

private val GreetingZone: ZoneId = ZoneId.systemDefault()

@Composable
private fun rememberIstHour(): Int {
    val today = remember { java.time.LocalDate.now(GreetingZone) }
    return remember(today) { ZonedDateTime.now(GreetingZone).hour }
}

private fun Modifier.noRippleClickable(onClick: () -> Unit): Modifier = composed {
    clickable(
        enabled = true,
        indication = null,
        interactionSource = remember { MutableInteractionSource() },
        onClick = onClick,
    )
}

@Composable
private fun IstGreetingHeader(
    modifier: Modifier = Modifier,
    recentSessions: List<ChatSession> = emptyList(),
    onOpenSession: (String) -> Unit = {},
    onOpenScreen: (AppScreen) -> Unit = {},
    isThinking: Boolean = false,
    isListening: Boolean = false,
    imeVisible: Boolean = false,
    musicActive: Boolean = false,
) {
    val istHour = rememberIstHour()
    val greetingText = when (istHour) {
        in 4..5 -> stringResource(R.string.greeting_early_morning)
        in 6..11 -> stringResource(R.string.greeting_morning)
        in 12..16 -> stringResource(R.string.greeting_afternoon)
        in 17..19 -> stringResource(R.string.greeting_evening)
        else -> stringResource(R.string.greeting_night)
    }
    val dividerBrush = Brush.horizontalGradient(
        colors = listOf(
            Color.Transparent,
            ArixTertiary.copy(alpha = 0.42f),
            ArixPrimary.copy(alpha = 0.22f),
            Color.Transparent,
        ),
    )
    val topGap by animateDpAsState(
        if (imeVisible) 2.dp else if (musicActive) 10.dp else 8.dp,
        tween(260),
        label = "home_top_gap",
    )
    val midGap by animateDpAsState(if (imeVisible) 6.dp else 14.dp, tween(260), label = "home_mid_gap")
    val robotGap by animateDpAsState(
        if (imeVisible) 8.dp else if (musicActive) 30.dp else 24.dp,
        tween(260),
        label = "home_robot_gap",
    )
    Column(
        modifier = modifier
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(topGap))

        com.arix.app.companion.ArixHomeCompanionCard(
            modifier = Modifier.fillMaxWidth(),
            isListening = isListening,
            isThinking = isThinking,
        )

        Spacer(Modifier.height(robotGap))
        GreetingRevealText(text = greetingText, musicActive = musicActive)

        AnimatedVisibility(
            visible = !imeVisible && !musicActive,
            enter = expandVertically(tween(260)) + fadeIn(tween(260)),
            exit = shrinkVertically(tween(220)) + fadeOut(tween(180)),
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(Modifier.height(midGap))
                Box(contentAlignment = Alignment.Center) {
                    Box(
                        modifier = Modifier
                            .width(132.dp)
                            .height(1.dp)
                            .background(dividerBrush),
                    )
                    Box(
                        modifier = Modifier
                            .size(3.dp)
                            .background(ArixTertiary.copy(alpha = 0.55f), CircleShape),
                    )
                }
                Spacer(Modifier.height(20.dp))
                if (recentSessions.isNotEmpty()) {
                    ArixHomeRecentSessions(
                        sessions = recentSessions,
                        onOpenSession = onOpenSession,
                    )
                    Spacer(Modifier.height(8.dp))
                }
            }
        }
    }
}

@Composable
private fun ArixHomeRecentSessions(
    sessions: List<ChatSession>,
    onOpenSession: (String) -> Unit,
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(0.dp),
    ) {
        Text(
            text = "Continue",
            style = MaterialTheme.typography.labelMedium.copy(
                letterSpacing = 2.2.sp,
                fontWeight = FontWeight.Medium,
            ),
            color = ArixOnSurfaceVariant.copy(alpha = 0.78f),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp),
        )
        Spacer(Modifier.height(4.dp))
        sessions.take(3).forEachIndexed { index, session ->
            ArixHomeRecentSessionRow(
                session = session,
                showDivider = index < minOf(3, sessions.size) - 1,
                onClick = { onOpenSession(session.id) },
            )
        }
    }
}

@Composable
private fun ArixHomeRecentSessionRow(
    session: ChatSession,
    showDivider: Boolean,
    onClick: () -> Unit,
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onClick)
                .padding(horizontal = 10.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = Icons.Rounded.Forum,
                contentDescription = null,
                tint = ArixTertiary.copy(alpha = 0.9f),
                modifier = Modifier.size(17.dp),
            )
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = session.title.ifBlank { "New chat" },
                    style = MaterialTheme.typography.titleSmall,
                    color = ArixOnSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = session.preview.ifBlank { "No messages yet" },
                    style = MaterialTheme.typography.labelSmall,
                    color = ArixOnSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Icon(
                imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                contentDescription = null,
                tint = ArixOnSurfaceVariant.copy(alpha = 0.7f),
                modifier = Modifier.size(18.dp),
            )
        }
        if (showDivider) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 39.dp)
                    .height(1.dp)
                    .background(ArixOutline.copy(alpha = 0.12f)),
            )
        }
    }
}

@Composable
private fun GreetingRevealText(
    text: String,
    musicActive: Boolean = false,
) {
    var revealed by remember(text) { mutableStateOf("") }
    var revealDone by remember(text) { mutableStateOf(false) }
    LaunchedEffect(text) {
        revealed = ""
        revealDone = false
        splitGreetingRevealUnits(text).forEach { unit ->
            delay(greetingRevealUnitDelay(unit))
            revealed += unit
        }
        revealDone = true
    }
    val highlightStart = text.lastIndexOf(',').let { comma ->
        if (comma >= 0 && comma + 1 < text.length) comma + 1 else -1
    }
    val highlightColor = Color(0xFFB366FF)
    val greetingStyle = MaterialTheme.typography.headlineMedium.copy(
        fontWeight = FontWeight.SemiBold,
        fontSize = 26.sp,
        lineHeight = 32.sp,
        letterSpacing = (-0.4).sp,
    )
    val annotated = buildAnnotatedString {
        val visible = revealed.ifEmpty { " " }
        if (highlightStart >= 0 && visible.length > highlightStart) {
            append(visible.substring(0, highlightStart))
            withStyle(
                SpanStyle(
                    brush = Brush.verticalGradient(
                        colors = listOf(Color(0xFFD98CFF), highlightColor),
                    ),
                ),
            ) {
                append(visible.substring(highlightStart))
            }
        } else {
            append(visible)
        }
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = annotated,
            style = greetingStyle,
            color = ArixOnSurface,
            textAlign = TextAlign.Center,
        )
        val accentAlpha by animateFloatAsState(
            targetValue = if (revealDone) 1f else 0f,
            animationSpec = tween(700),
            label = "greeting_accent_alpha",
        )
        val accentWidth by animateDpAsState(
            targetValue = if (musicActive) 34.dp else 22.dp,
            animationSpec = tween(320),
            label = "greeting_accent_width",
        )
        Spacer(Modifier.height(10.dp))
        Box(
            modifier = Modifier
                .width(accentWidth)
                .height(2.dp)
                .graphicsLayer { alpha = accentAlpha }
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            Color.Transparent,
                            ArixTertiary.copy(alpha = 0.65f),
                            ArixPrimary.copy(alpha = 0.45f),
                            Color.Transparent,
                        ),
                    ),
                    RoundedCornerShape(2.dp),
                ),
        )
    }
}

private fun splitGreetingRevealUnits(text: String): List<String> {
    if (text.isBlank()) return emptyList()
    val units = mutableListOf<String>()
    val builder = StringBuilder()
    text.forEach { char ->
        builder.append(char)
        val shouldSplit = char == ' ' || char == '\n' || char == '.' || char == '!' || char == '?' || char == ','
        if (shouldSplit) {
            units += builder.toString()
            builder.clear()
        }
    }
    if (builder.isNotEmpty()) {
        units += builder.toString()
    }
    return units
}

private fun greetingRevealUnitDelay(unit: String): Long {
    val trimmed = unit.trim()
    if (trimmed.isEmpty()) return 18L
    if (trimmed.length == 1 && trimmed.first() in setOf('.', ',', '!', '?')) return 180L
    return (80L + trimmed.length * 18L).coerceIn(96L, 240L)
}

@Composable
internal fun ConversationThinkingIndicator() {
    ShimmerStatusText(
        text = stringResource(R.string.chat_thinking),
        modifier = Modifier.padding(top = 6.dp),
    )
}

@Composable
internal fun PendingAssistantTimeline(
    blocks: List<AssistantResponseBlock>,
    workspaceDirectory: String,
    allowRootImageRead: Boolean,
    onOpenLink: (String) -> Unit,
    pendingToolInvocationStateKey: String,
    pendingToolInvocations: List<ChatToolInvocation>,
    activeTurnStartedAtMillis: Long?,
    statusText: String = "",
    statusDetail: String = "",
    showStatusFallback: Boolean = false,
    reasoningPhase: ArixReasoningPhase = ArixReasoningPhase.IDLE,
) {
    if (blocks.isEmpty()) {
        if (pendingToolInvocations.isNotEmpty()) {
            val pendingToolsStartedAtMillis = pendingToolInvocations
                .mapNotNull { it.startedAtMillis.takeIf { timestamp -> timestamp > 0L } }
                .plus(listOfNotNull(activeTurnStartedAtMillis?.takeIf { it > 0L }))
                .filter { it >= MinimumWallClockMillis }
                .minOrNull()
            val pendingToolsFallbackStartedRealtimeMillis = remember(pendingToolInvocationStateKey) {
                SystemClock.elapsedRealtime()
            }
            val pendingToolsDurationMillis by produceState(
                initialValue = runningWorkDurationMillis(
                    startedAtMillis = pendingToolsStartedAtMillis,
                    fallbackStartedRealtimeMillis = pendingToolsFallbackStartedRealtimeMillis,
                ),
                pendingToolsStartedAtMillis,
                pendingToolsFallbackStartedRealtimeMillis,
            ) {
                while (true) {
                    value = runningWorkDurationMillis(
                        startedAtMillis = pendingToolsStartedAtMillis,
                        fallbackStartedRealtimeMillis = pendingToolsFallbackStartedRealtimeMillis,
                    )
                    kotlinx.coroutines.delay(1_000L)
                }
            }
            ToolResultsInlineGallery(pendingToolInvocations)
            AgentWorkingStatusHeader(
                title = formatWorkedSummaryTitle(pendingToolsDurationMillis),
                mochiState = reasoningPhase.mochiReaction,
                invocations = pendingToolInvocations,
            )
            if (statusText.isNotBlank()) {
                ReconnectingStatusCard(
                    text = statusText,
                    detail = statusDetail,
                    isRunning = true,
                )
            }
            ToolInvocationList(
                toolInvocations = pendingToolInvocations,
                stateKey = pendingToolInvocationStateKey,
                autoExpand = true,
                renderInlineResults = false,
            )
        } else if (showStatusFallback && statusText.isNotBlank()) {
            ReconnectingStatusCard(
                text = statusText,
                detail = statusDetail,
                isRunning = true,
                modifier = Modifier.padding(top = 6.dp),
            )
        }
        return
    }

    val workStartedAtMillis = listOfNotNull(
        blocks.workStartedAtMillis(),
        activeTurnStartedAtMillis?.takeIf { it >= MinimumWallClockMillis },
    ).minOrNull()
    val fallbackWorkStartedRealtimeMillis = remember(activeTurnStartedAtMillis) {
        SystemClock.elapsedRealtime()
    }
    val workingDurationMillis by produceState(
        initialValue = runningWorkDurationMillis(
            startedAtMillis = workStartedAtMillis,
            fallbackStartedRealtimeMillis = fallbackWorkStartedRealtimeMillis,
        ),
        workStartedAtMillis,
        fallbackWorkStartedRealtimeMillis,
    ) {
        while (true) {
            value = runningWorkDurationMillis(
                startedAtMillis = workStartedAtMillis,
                fallbackStartedRealtimeMillis = fallbackWorkStartedRealtimeMillis,
            )
            kotlinx.coroutines.delay(1_000L)
        }
    }
    val shouldShowWorkingDisclosure = blocks.any { block ->
        when (block) {
            is AssistantResponseBlock.Text -> block.text.isNotBlank()
            is AssistantResponseBlock.ToolGroup -> block.toolInvocations.isNotEmpty()
            is AssistantResponseBlock.Reasoning -> hasVisibleReasoningStatus(block.trace)
            is AssistantResponseBlock.Status -> block.text.isNotBlank()
        }
    }

    if (shouldShowWorkingDisclosure) {
        ToolResultsInlineGallery(
            blocks.filterIsInstance<AssistantResponseBlock.ToolGroup>()
                .flatMap { it.toolInvocations },
        )
        AgentWorkingStatusHeader(
            title = formatWorkedSummaryTitle(workingDurationMillis),
            mochiState = reasoningPhase.mochiReaction,
            invocations = blocks.filterIsInstance<AssistantResponseBlock.ToolGroup>()
                .flatMap { it.toolInvocations },
        )
        if (statusText.isNotBlank()) {
            ReconnectingStatusCard(
                text = statusText,
                detail = statusDetail,
                isRunning = true,
            )
        }
        blocks.forEachIndexed { index, block ->
            PendingAssistantTimelineBlock(
                block = block,
                index = index,
                isLastBlock = index == blocks.lastIndex,
                workspaceDirectory = workspaceDirectory,
                allowRootImageRead = allowRootImageRead,
                onOpenLink = onOpenLink,
                pendingToolInvocationStateKey = pendingToolInvocationStateKey,
            )
        }
    } else if (showStatusFallback && statusText.isNotBlank()) {
        ReconnectingStatusCard(
            text = statusText,
            detail = statusDetail,
            isRunning = true,
            modifier = Modifier.padding(top = 6.dp),
        )
    }
}

@Composable
private fun PendingAssistantTimelineBlock(
    block: AssistantResponseBlock,
    index: Int,
    isLastBlock: Boolean,
    workspaceDirectory: String,
    allowRootImageRead: Boolean,
    onOpenLink: (String) -> Unit,
    pendingToolInvocationStateKey: String,
) {
    when (block) {
        is AssistantResponseBlock.Text -> {
            PendingAssistantResponseBlock(
                text = block.text,
                workspaceDirectory = workspaceDirectory,
                allowRootImageRead = allowRootImageRead,
                onOpenLink = onOpenLink,
            )
        }

        is AssistantResponseBlock.ToolGroup -> {
            if (block.toolInvocations.isNotEmpty()) {
                ToolInvocationList(
                    toolInvocations = block.toolInvocations,
                    stateKey = "$pendingToolInvocationStateKey-${block.id}",
                    autoExpand = isLastBlock,
                    renderInlineResults = false,
                )
            }
        }

        is AssistantResponseBlock.Reasoning -> {
            if (hasVisibleReasoningStatus(block.trace)) {
                ReasoningTraceStatus(
                    trace = block.trace,
                    onOpenLink = onOpenLink,
                )
            }
        }

        is AssistantResponseBlock.Status -> ReconnectingStatusCard(
            text = block.text,
            detail = block.detail,
        )
    }
}

private fun List<AssistantResponseBlock>.visibleText(): String =
    filterIsInstance<AssistantResponseBlock.Text>()
        .joinToString("\n\n") { it.text }

private fun List<AssistantResponseBlock>.hasVisiblePendingWork(): Boolean =
    any { block ->
        when (block) {
            is AssistantResponseBlock.Text -> block.text.isNotBlank()
            is AssistantResponseBlock.ToolGroup -> block.toolInvocations.isNotEmpty()
            is AssistantResponseBlock.Reasoning -> hasVisibleReasoningStatus(block.trace)
            is AssistantResponseBlock.Status -> block.text.isNotBlank()
        }
    }

private fun List<AssistantResponseBlock>.workStartedAtMillis(): Long? =
    flatMap { block ->
        when (block) {
            is AssistantResponseBlock.Text -> emptyList()
            is AssistantResponseBlock.Status -> emptyList()
            is AssistantResponseBlock.ToolGroup -> block.toolInvocations.mapNotNull {
                it.startedAtMillis.takeIf { timestamp -> timestamp > 0L }
            }
            is AssistantResponseBlock.Reasoning -> buildList {
                block.trace.startedAtMillis.takeIf { it > 0L }?.let(::add)
                block.trace.chunks.forEach { chunk ->
                    chunk.createdAtMillis.takeIf { it > 0L }?.let(::add)
                }
                block.trace.toolInvocations.forEach { invocation ->
                    invocation.startedAtMillis.takeIf { it > 0L }?.let(::add)
                }
            }
        }
    }
        .filter { it >= MinimumWallClockMillis }
        .minOrNull()

internal fun runningWorkDurationMillis(
    startedAtMillis: Long?,
    fallbackStartedRealtimeMillis: Long,
    nowMillis: Long = System.currentTimeMillis(),
    nowRealtimeMillis: Long = SystemClock.elapsedRealtime(),
): Long =
    if (startedAtMillis != null) {
        (nowMillis - startedAtMillis).coerceAtLeast(1_000L)
    } else {
        (nowRealtimeMillis - fallbackStartedRealtimeMillis).coerceAtLeast(1_000L)
    }

private fun buildConversationListItems(
    messages: List<ChatMessage>,
): List<ConversationListItem> = buildList {
    var index = 0
    while (index < messages.size) {
        val message = messages[index]
        when (message.displayKind) {
            MessageDisplayKind.HiddenContext -> {
                index += 1
                continue
            }

            MessageDisplayKind.CompactStatus -> {
                add(ConversationListItem.CompactStatus(message))
                index += 1
                continue
            }

            MessageDisplayKind.Standard -> Unit
        }
        val responseGroupId = message.responseGroupId
        if (
            message.author == MessageAuthor.Agent &&
            (!responseGroupId.isNullOrBlank() || isLegacyAssistantGroupStart(messages, index))
        ) {
            val groupedMessages = buildList {
                var groupIndex = index
                while (groupIndex < messages.size) {
                    val candidate = messages[groupIndex]
                    if (candidate.author != MessageAuthor.Agent) {
                        break
                    }
                    val matchesGroup = if (!responseGroupId.isNullOrBlank()) {
                        candidate.responseGroupId == responseGroupId
                    } else {
                        val offset = groupIndex - index
                        candidate.responseGroupId.isNullOrBlank() &&
                            candidate.createdAtMillis == message.createdAtMillis + offset
                    }
                    if (!matchesGroup) {
                        break
                    }
                    add(candidate)
                    groupIndex += 1
                }
            }
            if (groupedMessages.isNotEmpty()) {
                add(ConversationListItem.AssistantGroup(groupedMessages))
                index += groupedMessages.size
                continue
            }
        }
        add(ConversationListItem.Message(message))
        index += 1
    }
}

private data class CompactCommandSuggestion(
    val percent: Int?,
)

private fun compactCommandSuggestion(messages: List<ChatMessage>): CompactCommandSuggestion {
    val visibleMessages = messages.filter {
        it.displayKind != MessageDisplayKind.HiddenContext &&
            it.displayKind != MessageDisplayKind.CompactStatus
    }
    if (visibleMessages.size < 2) return CompactCommandSuggestion(percent = null)
    val estimatedChars = visibleMessages.sumOf { message ->
        message.text.length +
            message.attachments.sumOf { attachment ->
                attachment.name.length + attachment.mimeType.length + attachment.workspacePath.length
            } +
            message.toolInvocations.sumOf { invocation ->
                invocation.toolName.length + invocation.argumentsJson.length + invocation.outputJson.length
            }
    }
    val percent = ((estimatedChars * 100L) / 120_000L).toInt().coerceIn(1, 100)
    return CompactCommandSuggestion(percent = percent)
}

@Composable
private fun CompactStatusDivider(
    text: String,
    isRunning: Boolean = false,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Box(
            modifier = Modifier
                .weight(1f)
                .height(1.dp)
                .background(ArixOnSurfaceVariant.copy(alpha = 0.08f)),
        )
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(7.dp),
        ) {
            Icon(
                imageVector = if (isRunning) Icons.Rounded.RadioButtonUnchecked else Icons.Rounded.Check,
                contentDescription = null,
                tint = ArixOnSurfaceVariant.copy(alpha = 0.82f),
                modifier = Modifier.size(15.dp),
            )
            if (isRunning) {
                ShimmerStatusText(
                    text = text,
                    modifier = Modifier.widthIn(max = 190.dp),
                    travelDurationMillis = 2200,
                    pauseDurationMillis = 700,
                )
            } else {
                Text(
                    text = text,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                    color = ArixOnSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        Box(
            modifier = Modifier
                .weight(1f)
                .height(1.dp)
                .background(ArixOnSurfaceVariant.copy(alpha = 0.08f)),
        )
    }
}

@Composable
private fun SlashCommandSuggestionRow(
    suggestion: SlashCommandSuggestion,
    detail: String,
    input: String,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(ArixSurfaceHigh.copy(alpha = 0.92f))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Icon(
            imageVector = when (suggestion.icon) {
                SlashCommandIcon.Skill -> Icons.Rounded.AutoAwesome
                SlashCommandIcon.Command -> Icons.Rounded.Compress
            },
            contentDescription = null,
            tint = ArixOnSurfaceVariant,
            modifier = Modifier.size(18.dp),
        )
        Text(
            text = slashHighlightedName(suggestion.command, input),
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
            color = ArixOnSurface,
        )
        Text(
            text = detail,
            style = MaterialTheme.typography.bodyMedium,
            color = ArixOnSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
            textAlign = TextAlign.End,
        )
    }
}

private fun isLegacyAssistantGroupStart(
    messages: List<ChatMessage>,
    index: Int,
): Boolean {
    val message = messages.getOrNull(index) ?: return false
    if (
        message.author != MessageAuthor.Agent ||
        !message.responseGroupId.isNullOrBlank()
    ) {
        return false
    }
    val next = messages.getOrNull(index + 1) ?: return false
    return next.author == MessageAuthor.Agent &&
        next.responseGroupId.isNullOrBlank() &&
        next.createdAtMillis == message.createdAtMillis + 1
}

@Composable
private fun PendingSessionInputBubble(
    pendingInput: PendingSessionInput,
) {
    val modeLabel = when (pendingInput.mode) {
        SessionFollowUpMode.Queue -> stringResource(R.string.chat_pending_input_queued)
        SessionFollowUpMode.Steer -> stringResource(R.string.chat_pending_input_steering)
    }
    val attachmentLabel = when (pendingInput.attachmentCount) {
        0 -> null
        1 -> stringResource(R.string.chat_attachment_count_one)
        else -> stringResource(R.string.chat_attachment_count_other, pendingInput.attachmentCount)
    }
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.End,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 300.dp)
                .shadow(8.dp, RoundedCornerShape(24.dp), ambientColor = ArixScrim, spotColor = ArixScrim)
                .clip(RoundedCornerShape(24.dp))
                .background(ArixSurfaceHigh.copy(alpha = 0.96f))
                .padding(horizontal = 18.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = modeLabel,
                    style = MaterialTheme.typography.labelMedium,
                    color = ArixOnSurfaceVariant,
                )
                attachmentLabel?.let { label ->
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelSmall,
                        color = ArixOnSurfaceVariant,
                    )
                }
            }
            Text(
                text = pendingInput.preview.ifBlank {
                    stringResource(R.string.chat_additional_context)
                },
                style = MaterialTheme.typography.bodyLarge,
                color = ArixOnSurface,
            )
        }
    }
}

internal class PostSendEchoSuppressor(
    private val nowMillis: () -> Long = android.os.SystemClock::uptimeMillis,
) {
    private var sentText: String = ""
    private var armedAtUptimeMillis: Long = 0L

    private val armed: Boolean
        get() = armedAtUptimeMillis != 0L &&
            nowMillis() - armedAtUptimeMillis < EchoWindowMillis

    fun arm(text: String) {
        sentText = text
        armedAtUptimeMillis = nowMillis()
    }

    fun isEcho(text: String): Boolean {
        if (!armed || text.isBlank() || sentText.isBlank()) return false
        return text == sentText ||
            sentText.startsWith(text) ||
            text.startsWith(sentText)
    }

    private companion object {
        const val EchoWindowMillis = 400L
    }
}

private val ComposerBottomGap = 8.dp

private val MiniPlayerGap = 10.dp

@Composable
private fun ConversationComposerOverlay(
    modifier: Modifier = Modifier,
    conversationStateKey: String,
    onBodyHeightChanged: (Int) -> Unit,
    bottomBarReserve: Dp = 0.dp,
    value: String,
    attachments: List<ChatAttachment>,
    availableSkills: List<InstalledSkill>,
    selectedSkillIds: List<String>,
    isEditing: Boolean,
    isSending: Boolean,
    showStarterPromptHint: Boolean,
    compactSuggestionText: String,
    onValueChange: (String) -> Unit,
    onRemoveAttachment: (String) -> Unit,
    onSetSkillSelected: (String, Boolean) -> Unit,
    onCancelEdit: () -> Unit,
    onPickImages: () -> Unit,
    onPickFiles: () -> Unit,
    onStartVoiceInput: () -> Unit,
    voiceListening: Boolean,
    onVoiceListeningSettled: (String) -> Unit,
    onVoiceListeningCancelled: () -> Unit,
    onPauseGeneration: () -> Unit,
    onDismissStarterPromptHint: () -> Unit,
    onFocusChanged: (Boolean) -> Unit,
    onSend: () -> Unit,
    onQueueFollowUp: () -> Unit,
    onSteerFollowUp: () -> Unit,
) {
    val density = LocalDensity.current
    val imeVisible = WindowInsets.ime.getBottom(density) > 0
    val postSendEchoSuppressor = remember { PostSendEchoSuppressor() }
    val navigationInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val bottomLift by animateDpAsState(
        targetValue = if (imeVisible) 12.dp else ComposerBottomGap,
        animationSpec = tween(durationMillis = 260, easing = ChatGptMotionEasing),
        label = "composer_bottom_lift",
    )
    Box(
        modifier = modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.ime.only(WindowInsetsSides.Bottom))
            .padding(bottom = navigationInset.coerceAtMost(ArixBottomNavInsetCap))
            .padding(bottom = bottomLift + bottomBarReserve),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .onSizeChanged { onBodyHeightChanged(it.height) },
        ) {
            Column {
                key(conversationStateKey) {
                    ConversationComposerBar(
                    conversationStateKey = conversationStateKey,
                    value = value,
                    postSendEchoSuppressor = postSendEchoSuppressor,
                    attachments = attachments,
                    availableSkills = availableSkills,
                    selectedSkillIds = selectedSkillIds,
                    isEditing = isEditing,
                    isSending = isSending,
                    showStarterPromptHint = showStarterPromptHint,
                    compactSuggestionText = compactSuggestionText,
                    onValueChange = onValueChange,
                    onRemoveAttachment = onRemoveAttachment,
                    onSetSkillSelected = onSetSkillSelected,
                    onCancelEdit = onCancelEdit,
                    onPickImages = onPickImages,
                    onPickFiles = onPickFiles,
                    onStartVoiceInput = onStartVoiceInput,
                    voiceListening = voiceListening,
                    onVoiceListeningSettled = onVoiceListeningSettled,
                    onVoiceListeningCancelled = onVoiceListeningCancelled,
                    onPauseGeneration = onPauseGeneration,
                    onDismissStarterPromptHint = onDismissStarterPromptHint,
                    onFocusChanged = onFocusChanged,
                    onSend = onSend,
                    onQueueFollowUp = onQueueFollowUp,
                        onSteerFollowUp = onSteerFollowUp,
                    )
                }
            }
        }
    }
}

@Composable
internal fun ConversationComposerBar(
    modifier: Modifier = Modifier,
    conversationStateKey: String,
    value: String,
    postSendEchoSuppressor: PostSendEchoSuppressor,
    attachments: List<ChatAttachment>,
    availableSkills: List<InstalledSkill>,
    selectedSkillIds: List<String>,
    isEditing: Boolean,
    isSending: Boolean,
    showStarterPromptHint: Boolean,
    compactSuggestionText: String,
    onValueChange: (String) -> Unit,
    onRemoveAttachment: (String) -> Unit,
    onSetSkillSelected: (String, Boolean) -> Unit,
    onCancelEdit: () -> Unit,
    onPickImages: () -> Unit,
    onPickFiles: () -> Unit,
    onStartVoiceInput: () -> Unit,
    voiceListening: Boolean,
    onVoiceListeningSettled: (String) -> Unit,
    onVoiceListeningCancelled: () -> Unit,
    onPauseGeneration: () -> Unit,
    onDismissStarterPromptHint: () -> Unit,
    onFocusChanged: (Boolean) -> Unit,
    onSend: () -> Unit,
    onQueueFollowUp: () -> Unit,
    onSteerFollowUp: () -> Unit,
) {
    var attachmentMenuExpanded by remember(conversationStateKey) { mutableStateOf(false) }
    val attachmentMenuVisibility = remember(conversationStateKey) { MutableTransitionState(false) }
    attachmentMenuVisibility.targetState = attachmentMenuExpanded
    var followUpMenuExpanded by remember(conversationStateKey) { mutableStateOf(false) }
    val followUpMenuVisibility = remember(conversationStateKey) { MutableTransitionState(false) }
    followUpMenuVisibility.targetState = followUpMenuExpanded
    var textFieldFocused by remember { mutableStateOf(false) }
    var fieldValue by remember(conversationStateKey) { mutableStateOf(TextFieldValue(value, TextRange(value.length))) }
    var fieldReconcileSerial by remember(conversationStateKey) { mutableIntStateOf(0) }
    fun submitDraft(action: () -> Unit) {
        val textAtSend = fieldValue.text
        action()
        if (textAtSend.isNotBlank()) {
            fieldValue = TextFieldValue("", TextRange(0))
            postSendEchoSuppressor.arm(textAtSend)
            fieldReconcileSerial += 1
        }
    }
    LaunchedEffect(value, fieldReconcileSerial) {
        if (value != fieldValue.text) fieldValue = TextFieldValue(value, TextRange(value.length))
    }
    var measuredTextLineCount by remember { mutableIntStateOf(1) }
    var measuredTextHeight by remember { mutableStateOf(22.dp) }
    val density = LocalDensity.current
    val imeVisible = WindowInsets.ime.getBottom(density) > 0
    val selectedSkillSet = remember(selectedSkillIds) { selectedSkillIds.toSet() }
    val selectedSkillActions = remember(availableSkills, selectedSkillSet) {
        availableSkills.filter { selectedSkillSet.contains(it.id) }
    }
    val hasSelectedActions = selectedSkillActions.isNotEmpty()
    val hasComposerActionTray = hasSelectedActions
    val composerPlaceholder = when {
        value.isNotBlank() -> ""
        attachments.isNotEmpty() -> stringResource(R.string.chat_add_note)
        selectedSkillActions.size == 1 -> {
            selectedSkillActions.firstOrNull()?.quickActionLabel()
                ?: stringResource(R.string.chat_reply_to_arix)
        }
        hasSelectedActions -> stringResource(R.string.chat_ask_with_selected_tools)
        else -> stringResource(R.string.chat_ask_arix)
    }
    val hasDraft = value.isNotBlank() || attachments.isNotEmpty()
    val slashSuggestions = remember(fieldValue.text) {
        slashCommandSuggestions(fieldValue.text)
    }
    fun applySlashSuggestion(command: String) {
        val typedLength = fieldValue.text.drop(1).takeWhile { !it.isWhitespace() }.length
        val replaceEnd = (1 + typedLength).coerceAtMost(fieldValue.text.length)
        val suffix = fieldValue.text.substring(replaceEnd)
        val needsSpace = suffix.isEmpty() && slashSuggestions.firstOrNull { it.command == command }?.argumentHint?.isNotBlank() == true
        val replacement = command + if (needsSpace) " " else ""
        val next = replacement + suffix
        fieldValue = TextFieldValue(next, TextRange(replacement.length))
        onValueChange(next)
    }
    val canSendDraft = attachments.all { it.workspaceState == AttachmentWorkspaceState.Ready }
    val keepPlusSeparated = value.isNotBlank() || hasComposerActionTray
    val plusSeparated = keepPlusSeparated || (textFieldFocused && imeVisible)
    val explicitTextLineCount = if (value.isBlank()) {
        1
    } else {
        value.count { it == '\n' } + 1
    }
    val composerTextLineCount = if (value.isBlank()) {
        1
    } else {
        maxOf(explicitTextLineCount, measuredTextLineCount).coerceIn(1, 5)
    }
    val isMultilineComposer = composerTextLineCount > 1
    val composerTextStyle = MaterialTheme.typography.bodyLarge.copy(
        color = ArixOnSurface,
        fontSize = 16.sp,
        lineHeight = 22.sp,
        platformStyle = PlatformTextStyle(includeFontPadding = false),
        lineHeightStyle = LineHeightStyle(
            alignment = LineHeightStyle.Alignment.Center,
            trim = LineHeightStyle.Trim.Both,
        ),
    )
    val fieldTopPadding = when {
        hasComposerActionTray -> 12.dp
        isMultilineComposer -> 12.dp
        else -> 8.dp
    }
    val fieldBottomPadding = when {
        hasComposerActionTray -> 12.dp
        isMultilineComposer -> 12.dp
        else -> 8.dp
    }
    LaunchedEffect(plusSeparated) {
        onFocusChanged(plusSeparated)
    }
    fun runAfterAttachmentMenuDismiss(action: () -> Unit) {
        attachmentMenuExpanded = false
        action()
    }
    val composerHorizontalPadding by animateDpAsState(
        targetValue = when {
            plusSeparated -> 14.dp
            hasComposerActionTray -> 18.dp
            else -> 30.dp
        },
        animationSpec = tween(durationMillis = 260, easing = ChatGptMotionEasing),
        label = "composer_horizontal_padding",
    )
    val fieldStartPadding by animateDpAsState(
        targetValue = if (plusSeparated) 50.dp else 0.dp,
        animationSpec = tween(durationMillis = 260, easing = ChatGptMotionEasing),
        label = "composer_field_start",
    )
    val fieldContentStartPadding by animateDpAsState(
        targetValue = if (plusSeparated) 18.dp else 52.dp,
        animationSpec = tween(durationMillis = 260, easing = ChatGptMotionEasing),
        label = "composer_field_content_start",
    )
    val fieldMinHeight by animateDpAsState(
        targetValue = maxOf(
            if (plusSeparated) 56.dp else 50.dp,
            measuredTextHeight + fieldTopPadding + fieldBottomPadding,
        ),
        animationSpec = tween(durationMillis = 260, easing = ChatGptMotionEasing),
        label = "composer_field_min_height",
    )
    val plusShadowElevation by animateDpAsState(
        targetValue = if (plusSeparated) 10.dp else 0.dp,
        animationSpec = tween(durationMillis = 260, easing = ChatGptMotionEasing),
        label = "composer_plus_shadow",
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = composerHorizontalPadding),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        if (showStarterPromptHint) {
            SurfaceNotice(
                title = stringResource(R.string.chat_first_prompt_ready_title),
                subtitle = stringResource(R.string.chat_first_prompt_ready_subtitle),
                actionLabel = stringResource(R.string.common_hide),
                onAction = onDismissStarterPromptHint,
                actionEnabled = true,
            )
        }
        if (isEditing) {
            SurfaceNotice(
                title = stringResource(R.string.chat_editing_earlier_message_title),
                subtitle = stringResource(R.string.chat_editing_earlier_message_subtitle),
                actionLabel = stringResource(R.string.common_cancel),
                onAction = onCancelEdit,
                actionEnabled = true,
            )
        }
        AnimatedVisibility(
            visible = attachments.isEmpty() && slashSuggestions.isNotEmpty(),
            enter = fadeIn(animationSpec = tween(durationMillis = 160, easing = ChatGptMotionEasing)) +
                slideInVertically(
                    animationSpec = tween(durationMillis = 220, easing = ChatGptMotionEasing),
                    initialOffsetY = { it / 3 },
                ),
            exit = fadeOut(animationSpec = tween(durationMillis = 120, easing = ChatGptMotionEasing)) +
                slideOutVertically(
                    animationSpec = tween(durationMillis = 180, easing = ChatGptMotionEasing),
                    targetOffsetY = { it / 3 },
                ),
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 300.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(ArixSurfaceHigh.copy(alpha = 0.98f))
                    .padding(vertical = 4.dp),
            ) {
                items(slashSuggestions, key = { it.command }) { suggestion ->
                    SlashCommandSuggestionRow(
                        suggestion = suggestion,
                        detail = if (suggestion.command == "/compact") compactSuggestionText else suggestion.description,
                        input = fieldValue.text,
                        onClick = { applySlashSuggestion(suggestion.command) },
                    )
                }
            }
        }
        if (attachments.isNotEmpty()) {
            ComposerAttachmentTray(
                attachments = attachments,
                onRemoveAttachment = onRemoveAttachment,
            )
        }

        val fieldShape = if (plusSeparated) ComposerFocusedCardShape else ComposerCardShape
        val fieldControlAlignment = if (isMultilineComposer) Alignment.Bottom else Alignment.CenterVertically
        val fieldTextAlignment = if (isMultilineComposer) Alignment.TopStart else Alignment.CenterStart
        val plusButtonAlignment = if (isMultilineComposer || hasComposerActionTray) Alignment.BottomStart else Alignment.CenterStart
        Box(
            modifier = Modifier
                .fillMaxWidth(),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = fieldStartPadding)
            ) {
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .offset(y = 8.dp)
                        .blur(
                            radius = 22.dp,
                            edgeTreatment = BlurredEdgeTreatment.Unbounded,
                        )
                        .clip(fieldShape)
                        .background(ChatGptComposerShadow),
                )
                val composerBorderColor by animateColorAsState(
                    targetValue = if (textFieldFocused) {
                        ArixPrimary.copy(alpha = 0.55f)
                    } else {
                        ArixOutlineSoft
                    },
                    animationSpec = tween(durationMillis = 220, easing = ChatGptMotionEasing),
                    label = "composer_border_color",
                )
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = fieldMinHeight)
                        .animateContentSize(
                            animationSpec = tween(durationMillis = 320, easing = ChatGptMotionEasing),
                        )
                        .clip(fieldShape)
                        .background(ArixSurface)
                        .border(
                            width = 1.dp,
                            color = composerBorderColor,
                            shape = fieldShape,
                        )
                        .padding(
                            start = fieldContentStartPadding,
                            end = 8.dp,
                            top = fieldTopPadding,
                            bottom = fieldBottomPadding,
                        ),
                    verticalArrangement = Arrangement.spacedBy(if (hasComposerActionTray) 10.dp else 0.dp),
                ) {
                    AnimatedVisibility(
                        visible = hasComposerActionTray,
                        enter = fadeIn(
                            animationSpec = tween(durationMillis = 220, easing = ChatGptMotionEasing),
                        ) + slideInVertically(
                            animationSpec = tween(durationMillis = 280, easing = ChatGptMotionEasing),
                            initialOffsetY = { -it / 2 },
                        ),
                        exit = fadeOut(
                            animationSpec = tween(durationMillis = 160, easing = ChatGptMotionEasing),
                        ) + slideOutVertically(
                            animationSpec = tween(durationMillis = 220, easing = ChatGptMotionEasing),
                            targetOffsetY = { -it / 3 },
                        ),
                    ) {
                        ComposerActionTray(
                            modifier = Modifier.fillMaxWidth(),
                            skills = selectedSkillActions,
                            onRemoveSkill = { skillId -> onSetSkillSelected(skillId, false) },
                        )
                    }

                    rememberVoiceRecognitionSession(active = voiceListening)
                    rememberVoiceHandsFreeEngine(
                        active = voiceListening,
                        onSettled = { text -> onVoiceListeningSettled(text) },
                        onSilenceStopRequested = { ArixSpeechRecognitionController.stop() },
                    )
                    AnimatedContent(
                        targetState = voiceListening,
                        transitionSpec = {
                            ArixMotion.directionalEnter(ArixSheetOrigin.Bottom, distanceFraction = 0.5f)
                                .togetherWith(
                                    ArixMotion.directionalExit(ArixSheetOrigin.Bottom, distanceFraction = 0.5f),
                                )
                        },
                        label = "composer_voice_mode",
                    ) { isVoiceMode ->
                        if (isVoiceMode) {
                            ArixComposerVoiceListening(
                                isListening = ArixSpeechRecognitionController.isListening,
                                partialText = ArixSpeechRecognitionController.partialText,
                                errorText = ArixSpeechRecognitionController.errorText,
                                onStopAndSend = { ArixSpeechRecognitionController.stop() },
                                onCancel = onVoiceListeningCancelled,
                            )
                        } else {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = fieldControlAlignment,
                            ) {
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .heightIn(min = measuredTextHeight.coerceAtLeast(22.dp)),
                                    contentAlignment = fieldTextAlignment,
                                ) {
                                    if (value.isBlank()) {
                                        Text(
                                            text = composerPlaceholder,
                                            style = composerTextStyle,
                                            color = ArixOnSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                        )
                                    }
                                    BasicTextField(
                                        value = fieldValue,
                                        onValueChange = { next ->
                                            if (
                                                postSendEchoSuppressor.isEcho(next.text) &&
                                                fieldValue.text.isBlank()
                                            ) {
                                                fieldValue = TextFieldValue("", TextRange(0))
                                                return@BasicTextField
                                            }
                                            fieldValue = next
                                            onValueChange(next.text)
                                        },
                                        enabled = true,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .onFocusChanged { focusState ->
                                                if (textFieldFocused != focusState.isFocused) {
                                                    textFieldFocused = focusState.isFocused
                                                }
                                            },
                                        textStyle = composerTextStyle,
                                        maxLines = 5,
                                        keyboardOptions = KeyboardOptions(
                                            imeAction = ImeAction.Default,
                                        ),
                                        onTextLayout = { textLayoutResult ->
                                            val lineCount = textLayoutResult.lineCount.coerceIn(1, 5)
                                            if (measuredTextLineCount != lineCount) {
                                                measuredTextLineCount = lineCount
                                            }
                                            val visibleLineBottom = textLayoutResult.getLineBottom(lineCount - 1)
                                            val visibleLineTop = textLayoutResult.getLineTop(0)
                                            val textHeight = with(density) {
                                                (visibleLineBottom - visibleLineTop).toDp()
                                            }
                                            if (measuredTextHeight != textHeight) {
                                                measuredTextHeight = textHeight
                                            }
                                        },
                                        cursorBrush = SolidColor(ArixOnSurface),
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                val trailingAction = when {
                                    isSending && !hasDraft -> ComposerTrailingAction.StopGeneration
                                    hasDraft -> ComposerTrailingAction.Send
                                    else -> ComposerTrailingAction.VoiceInput
                                }
                                AnimatedContent(
                                    targetState = trailingAction,
                                    transitionSpec = {
                                        (
                                            fadeIn(tween(180, easing = ChatGptMotionEasing)) +
                                                scaleIn(
                                                    initialScale = 0.7f,
                                                    animationSpec = tween(220, easing = ChatGptMotionEasing),
                                                )
                                            ).togetherWith(
                                            fadeOut(tween(140, easing = ChatGptMotionEasing)) +
                                                scaleOut(
                                                    targetScale = 0.7f,
                                                    animationSpec = tween(160, easing = ChatGptMotionEasing),
                                                ),
                                        )
                                    },
                                    label = "composer_trailing_action",
                                ) { action ->
                                    when (action) {
                                        ComposerTrailingAction.StopGeneration -> ComposerPauseButton(
                                            onClick = onPauseGeneration,
                                        )

                                        ComposerTrailingAction.VoiceInput -> ComposerVoiceButton(
                                            onClick = onStartVoiceInput,
                                        )

                                        ComposerTrailingAction.Send -> Box {
                                            ComposerSubmitButton(
                                                hasDraft = hasDraft,
                                                canSendDraft = canSendDraft,
                                                isSending = isSending,
                                                onClick = {
                                                    if (!hasDraft || !canSendDraft) return@ComposerSubmitButton
                                                    if (isSending) {
                                                        followUpMenuExpanded = true
                                                    } else {
                                                        submitDraft(onSend)
                                                    }
                                                },
                                            )
                                            if (isSending && (followUpMenuVisibility.currentState || followUpMenuVisibility.targetState)) {
                                                FollowUpMenuPopup(
                                                    density = density,
                                                    onDismiss = { followUpMenuExpanded = false },
                                                    followUpMenuVisibility = followUpMenuVisibility,
                                                    onSteerFollowUp = { submitDraft(onSteerFollowUp) },
                                                    onQueueFollowUp = { submitDraft(onQueueFollowUp) },
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Box(
                modifier = Modifier.align(plusButtonAlignment)
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .shadow(plusShadowElevation, CircleShape, ambientColor = ChatGptControlShadow, spotColor = ChatGptControlShadow)
                        .clip(CircleShape)
                        .background(if (plusSeparated) ArixSurface else Color.Transparent)
                        .clickable(onClick = { attachmentMenuExpanded = !attachmentMenuExpanded }),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Add,
                        contentDescription = stringResource(R.string.chat_add_attachment_or_tool),
                        tint = ArixOnSurface,
                        modifier = Modifier.size(27.dp),
                    )
                }

                if (attachmentMenuVisibility.currentState || attachmentMenuVisibility.targetState) {
                    Popup(
                        alignment = Alignment.BottomStart,
                        offset = with(density) {
                            IntOffset(0, -42.dp.roundToPx())
                        },
                        onDismissRequest = { attachmentMenuExpanded = false },
                        properties = PopupProperties(
                            focusable = true,
                            dismissOnBackPress = true,
                            dismissOnClickOutside = true,
                        ),
                    ) {
                        androidx.compose.animation.AnimatedVisibility(
                            visibleState = attachmentMenuVisibility,
                            enter = fadeIn() +
                                scaleIn(
                                    initialScale = 0.92f,
                                    transformOrigin = TransformOrigin(0f, 1f),
                                ) +
                                slideInVertically(initialOffsetY = { it / 10 }),
                            exit = fadeOut() +
                                scaleOut(
                                    targetScale = 0.96f,
                                    transformOrigin = TransformOrigin(0f, 1f),
                                ) +
                                slideOutVertically(targetOffsetY = { it / 12 }),
                        ) {
                            Box(
                                modifier = Modifier
                                    .widthIn(min = 284.dp, max = 304.dp)
                                    .shadow(20.dp, RoundedCornerShape(30.dp), ambientColor = ArixScrim, spotColor = ArixScrim)
                                    .clip(RoundedCornerShape(30.dp))
                                    .background(ArixSurface),
                            ) {
                                Column(
                                    modifier = Modifier
                                        .heightIn(max = ComposerPlusMenuMaxHeight)
                                        .verticalScroll(rememberScrollState())
                                        .padding(horizontal = 12.dp, vertical = 12.dp),
                                    verticalArrangement = Arrangement.spacedBy(2.dp),
                                ) {
                                    ComposerPlusMenuRow(
                                        title = stringResource(R.string.chat_photos),
                                        icon = Icons.Rounded.Image,
                                        iconTint = Color(0xFF4E8D5A),
                                        iconContainerColor = ArixSurfaceHigh,
                                        onClick = {
                                            runAfterAttachmentMenuDismiss(onPickImages)
                                        },
                                    )
                                    ComposerPlusMenuRow(
                                        title = stringResource(R.string.chat_files),
                                        icon = Icons.Rounded.AttachFile,
                                        iconTint = ArixOnSurface,
                                        iconContainerColor = ArixSurfaceHigh,
                                        onClick = {
                                            runAfterAttachmentMenuDismiss(onPickFiles)
                                        },
                                    )
                                    if (availableSkills.isNotEmpty()) {
                                        Spacer(modifier = Modifier.height(6.dp))
                                    }
                                    availableSkills.forEach { skill ->
                                        val selected = selectedSkillSet.contains(skill.id)
                                        ComposerPlusMenuRow(
                                            title = skill.quickActionLabel(),
                                            icon = Icons.Rounded.Extension,
                                            selected = selected,
                                            iconTint = Color(0xFF9C6B2F),
                                            iconContainerColor = ArixSurfaceHigh,
                                            onClick = {
                                                runAfterAttachmentMenuDismiss {
                                                    onSetSkillSelected(skill.id, !selected)
                                                }
                                            },
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ComposerPauseButton(
    onClick: () -> Unit,
) {
    Box(
        modifier = Modifier
            .size(48.dp)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(ComposerAccentBrush),
            contentAlignment = Alignment.Center,
        ) {
            Box(
                modifier = Modifier
                    .offset(x = 0.5.dp)
                    .size(11.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(Color.White)
            )
        }
    }
}

@Composable
private fun ComposerSubmitButton(
    hasDraft: Boolean,
    canSendDraft: Boolean,
    isSending: Boolean,
    onClick: () -> Unit,
) {
    val enabled = hasDraft && canSendDraft
    val buttonBrush = if (enabled) {
        ComposerAccentBrush
    } else {
        null
    }
    Box(
        modifier = Modifier
            .size(48.dp)
            .clickable(
                enabled = enabled,
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .then(
                    if (buttonBrush != null) {
                        Modifier.background(buttonBrush)
                    } else {
                        Modifier.background(ArixSurfaceHigher)
                    },
                ),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = Icons.Rounded.ArrowUpward,
                contentDescription = if (isSending) {
                    stringResource(R.string.common_send_follow_up)
                } else {
                    stringResource(R.string.common_send)
                },
                tint = Color.White,
                modifier = Modifier.size(21.dp),
            )
        }
    }
}

private enum class ComposerTrailingAction {
    StopGeneration,
    Send,
    VoiceInput,
}

@Composable
private fun ComposerVoiceButton(
    onClick: () -> Unit,
) {
    val interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.88f else 1f,
        animationSpec = tween(140, easing = ChatGptMotionEasing),
        label = "voice_button_scale",
    )
    val haloAlpha = rememberInfiniteTransition(label = "voice_button_halo").animateFloat(
        initialValue = 0.18f,
        targetValue = 0.45f,
        animationSpec = infiniteRepeatable(
            tween(1200, easing = ChatGptMotionEasing),
            androidx.compose.animation.core.RepeatMode.Reverse,
        ),
        label = "voice_button_halo_alpha",
    )
    val haloBrush = remember {
        Brush.linearGradient(listOf(Color(0xFF9D6BFF), Color(0xFF6E3FE8)))
    }
    Box(
        modifier = Modifier
            .size(48.dp)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .graphicsLayer {
                    val breathe = 1f + 0.03f * haloAlpha.value
                    val s = scale * breathe
                    scaleX = s
                    scaleY = s
                }
                .clip(CircleShape)
                .drawBehind {
                    val halo = 0.10f + 0.14f * haloAlpha.value
                    drawRect(brush = haloBrush, alpha = halo)
                }
                .background(ComposerAccentBrush),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = Icons.Rounded.Mic,
                contentDescription = stringResource(R.string.chat_voice_input),
                tint = Color.White,
                modifier = Modifier.size(19.dp),
            )
        }
    }
}

@Composable
private fun FollowUpMenuPopup(
    density: androidx.compose.ui.unit.Density,
    onDismiss: () -> Unit,
    followUpMenuVisibility: androidx.compose.animation.core.MutableTransitionState<Boolean>,
    onSteerFollowUp: () -> Unit,
    onQueueFollowUp: () -> Unit,
) {
    Popup(
        alignment = Alignment.BottomEnd,
        offset = with(density) {
            IntOffset(0, -12.dp.roundToPx())
        },
        onDismissRequest = onDismiss,
        properties = PopupProperties(
            focusable = true,
            dismissOnBackPress = true,
            dismissOnClickOutside = true,
        ),
    ) {
        androidx.compose.animation.AnimatedVisibility(
            visibleState = followUpMenuVisibility,
            enter = fadeIn() +
                scaleIn(
                    initialScale = 0.92f,
                    transformOrigin = TransformOrigin(1f, 1f),
                ) +
                slideInVertically(initialOffsetY = { it / 10 }),
            exit = fadeOut() +
                scaleOut(
                    targetScale = 0.96f,
                    transformOrigin = TransformOrigin(1f, 1f),
                ) +
                slideOutVertically(targetOffsetY = { it / 12 }),
        ) {
            Column(
                modifier = Modifier
                    .widthIn(min = 252.dp, max = 284.dp)
                    .shadow(20.dp, RoundedCornerShape(30.dp), ambientColor = ArixScrim, spotColor = ArixScrim)
                    .clip(RoundedCornerShape(30.dp))
                    .background(ArixSurface)
                    .padding(horizontal = 12.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                ComposerPlusMenuRow(
                    title = stringResource(R.string.branch_steer_current_run),
                    icon = Icons.Rounded.AutoAwesome,
                    iconTint = Color(0xFF8D6C2F),
                    iconContainerColor = Color(0xFFFFF3DE),
                    onClick = {
                        onDismiss()
                        onSteerFollowUp()
                    },
                )
                ComposerPlusMenuRow(
                    title = stringResource(R.string.branch_queue_next_turn),
                    icon = Icons.Rounded.ArrowUpward,
                    iconTint = Color(0xFF2F6DA3),
                    iconContainerColor = Color(0xFFEAF2FF),
                    onClick = {
                        onDismiss()
                        onQueueFollowUp()
                    },
                )
            }
        }
    }
}

@Composable
private fun ComposerActionTray(
    modifier: Modifier = Modifier,
    skills: List<InstalledSkill>,
    onRemoveSkill: (String) -> Unit,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(end = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        skills.forEach { skill ->
            ComposerActionChip(
                label = skill.quickActionLabel(),
                icon = Icons.Rounded.Extension,
                onRemove = { onRemoveSkill(skill.id) },
            )
        }
    }
}

@Composable
private fun ComposerActionChip(
    label: String,
    icon: ImageVector,
    onRemove: () -> Unit,
) {
    Row(
        modifier = Modifier
            .widthIn(max = 220.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Color(0xFFE8F1FF))
            .padding(start = 12.dp, end = 6.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = Color(0xFF4F8CFF),
            modifier = Modifier.size(16.dp),
        )
        Text(
            text = label,
            modifier = Modifier.weight(1f, fill = false),
            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Medium),
            color = Color(0xFF2E6FD5),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Box(
            modifier = Modifier
                .size(18.dp)
                .clickable(onClick = onRemove),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = Icons.Rounded.Close,
                contentDescription = stringResource(R.string.common_remove),
                tint = Color(0xFF4F8CFF),
                modifier = Modifier.size(14.dp),
            )
        }
    }
}

@Composable
private fun ComposerPlusMenuRow(
    title: String,
    icon: ImageVector,
    iconTint: Color,
    iconContainerColor: Color,
    onClick: () -> Unit,
    selected: Boolean = false,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(iconContainerColor),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconTint,
                modifier = Modifier.size(20.dp),
            )
        }
        Text(
            text = title,
            modifier = Modifier.weight(1f),
            style = MaterialTheme.typography.bodyLarge,
            color = ArixOnSurface,
        )
        if (selected) {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(ArixPrimary.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = Icons.Rounded.Check,
                    contentDescription = null,
                    tint = ArixPrimary,
                    modifier = Modifier.size(15.dp),
                )
            }
        }
    }
}
