package com.arix.app.mcp

import org.json.JSONObject

object ArixMcpJsonImporter {

    sealed interface Outcome {
        data class Imported(val imported: List<String>, val skipped: List<String>) : Outcome
        data class Error(val reason: Reason) : Outcome
    }

    enum class Reason { NOT_JSON, MISSING_SERVERS, EMPTY_SERVERS, INVALID_ENTRIES }

    fun parse(raw: String): Outcome {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return Outcome.Error(Reason.NOT_JSON)
        val root = runCatching { JSONObject(trimmed) }.getOrNull()
            ?: return Outcome.Error(Reason.NOT_JSON)
        val servers = root.optJSONObject("mcpServers")
            ?: return Outcome.Error(Reason.MISSING_SERVERS)
        if (servers.length() == 0) return Outcome.Error(Reason.EMPTY_SERVERS)
        val imported = mutableListOf<String>()
        val skipped = mutableListOf<String>()
        servers.keys().forEach { name ->
            val entry = servers.optJSONObject(name)
            if (entry == null) {
                skipped += name
                return@forEach
            }
            val hasCommand = entry.optString("command").trim().isNotEmpty()
            val hasUrl = entry.optString("url").trim().isNotEmpty()
            if (!hasCommand && !hasUrl) {
                skipped += name
                return@forEach
            }
            if (!ArixMcpServerConfig.isValidName(name)) {
                skipped += name
                return@forEach
            }
            imported += name
        }
        if (imported.isEmpty()) return Outcome.Error(Reason.INVALID_ENTRIES)
        return Outcome.Imported(imported, skipped)
    }

    fun merge(existing: List<ArixMcpServerConfig>, raw: String): Pair<Outcome, List<ArixMcpServerConfig>> {
        val outcome = parse(raw)
        if (outcome !is Outcome.Imported) return outcome to existing
        val root = JSONObject(raw.trim())
        val serversObject = root.getJSONObject("mcpServers")
        val byName = existing.associateBy { it.name }.toMutableMap()
        outcome.imported.forEach { name ->
            val newConfig = ArixMcpServerConfig.fromJson(name, serversObject.getJSONObject(name))
            val old = byName[name]
            byName[name] = if (old == null) {
                newConfig
            } else {
                newConfig.copy(
                    enabled = old.enabled,
                    disabledTools = old.disabledTools,
                    oauth = old.oauth,
                    headers = newConfig.headers.ifEmpty { old.headers },
                    env = newConfig.env.ifEmpty { old.env },
                )
            }
        }
        return outcome to byName.values.sortedBy { it.name.lowercase() }
    }
}
