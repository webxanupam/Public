package com.arix.app.ui

import android.graphics.BitmapFactory
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.GppMaybe
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.SmartToy
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.arix.app.browser.ArixBrowserBookmarks
import com.arix.app.browser.ArixBrowserImage
import com.arix.app.browser.ArixBrowserInteraction
import com.arix.app.browser.ArixBrowserSession
import com.arix.app.browser.ArixBrowserSnapshot
import com.arix.app.browser.ArixBrowserTab
import com.arix.app.browser.ArixBrowserTabs
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private typealias ChromeColors = ArixChromeColors

@Composable
private fun chromeColors(): ChromeColors = arixChromeColors()

@Composable
fun ArixBrowserScreen(
    onBack: () -> Unit,
    onOpenChat: () -> Unit = onBack,
    onCancelGeneration: () -> Unit = {},
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val keyboard = LocalSoftwareKeyboardController.current
    val scope = rememberCoroutineScope()
    val chrome = chromeColors()
    val agentSnapshot by ArixBrowserSession.snapshots.collectAsState()
    val tabs by ArixBrowserTabs.tabs.collectAsState()
    var activeTabId by remember { mutableStateOf<Long?>(null) }
    val activeTab = tabs.firstOrNull { it.id == activeTabId }
    var address by remember { mutableStateOf("") }
    var addressFocused by remember { mutableStateOf(false) }
    var actionPending by remember { mutableStateOf(false) }
    var showResetDialog by remember { mutableStateOf(false) }
    var toolsOpen by remember { mutableStateOf(false) }
    var toolsPage by remember { mutableStateOf(BrowserToolsPage.Menu) }
    var readerText by remember { mutableStateOf<String?>(null) }
    var readerLoading by remember { mutableStateOf(false) }
    var screenshotPreview by remember { mutableStateOf<ArixBrowserImage?>(null) }

    val isAgentTab = activeTab == null
    val effectiveSnapshot = activeTab?.let(::tabSnapshot) ?: agentSnapshot

    val bookmarks by ArixBrowserBookmarks.bookmarks.collectAsState()
    var bookmarksOpen by remember { mutableStateOf(false) }
    var tabsSheetOpen by remember { mutableStateOf(false) }

    LaunchedEffect(context.applicationContext) {
        ArixBrowserSession.initialize(context.applicationContext)
        ArixBrowserTabs.initialize(context.applicationContext)
        ArixBrowserBookmarks.initialize(context.applicationContext)
    }
    LaunchedEffect(activeTabId, activeTab?.evicted) {
        activeTab?.let { tab ->
            if (tab.evicted) {
                ArixBrowserTabs.rehydrateTabIfNeeded(tab)
            }
        }
    }
    LaunchedEffect(effectiveSnapshot.displayUrl, addressFocused) {
        if (!addressFocused) {
            address = effectiveSnapshot.displayUrl
        }
    }

    fun launchBrowserAction(action: () -> Unit) {
        if (actionPending) return
        actionPending = true
        scope.launch {
            try {
                withContext(Dispatchers.IO) { action() }
            } finally {
                actionPending = false
            }
        }
    }

    fun navigatePageBack(): Boolean {
        return if (isAgentTab) {
            if (agentSnapshot.canGoBack) {
                launchBrowserAction { ArixBrowserSession.goBackFromUser() }
                true
            } else {
                false
            }
        } else {
            val tab = activeTab
            if (tab != null && tab.canGoBack) {
                ArixBrowserTabs.goBack(tab)
                true
            } else {
                false
            }
        }
    }

    BackHandler(enabled = !addressFocused) {
        if (!navigatePageBack()) onBack()
    }

    fun navigate() {
        if (actionPending) return
        val target = if (address == effectiveSnapshot.displayUrl) {
            effectiveSnapshot.url
        } else {
            address.trim()
        }
        if (target.isBlank()) return
        keyboard?.hide()
        if (isAgentTab) {
            launchBrowserAction {
                ArixBrowserSession.navigateFromUser(context.applicationContext, target)
            }
        } else {
            activeTab?.let { ArixBrowserTabs.navigate(it, target) }
        }
    }

    fun openNewTab() {
        val tab = ArixBrowserTabs.createTab(context.applicationContext)
        if (tab == null) {
            Toast.makeText(context, "Tab limit reached (5 tabs).", Toast.LENGTH_SHORT).show()
        } else {
            activeTabId = tab.id
            address = ""
        }
    }

    fun closeTabAndFixSelection(tab: ArixBrowserTab) {
        val remaining = tabs.filterNot { it === tab }
        activeTabId = when {
            activeTabId == tab.id -> remaining.lastOrNull()?.id
            else -> activeTabId
        }
        ArixBrowserTabs.closeTab(tab)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(chrome.window)
            .statusBarsPadding()
            .imePadding()
            .navigationBarsPadding(),
    ) {
        BrowserTopBar(
            chrome = chrome,
            snapshot = effectiveSnapshot,
            address = address,
            onAddressChange = { address = it },
            addressFocused = addressFocused,
            onAddressFocusChange = { addressFocused = it },
            isBookmarked = ArixBrowserBookmarks.isBookmarked(effectiveSnapshot.url),
            onToggleBookmark = {
                val url = effectiveSnapshot.url
                if (url.isNotBlank() && effectiveSnapshot.hasCommittedPage) {
                    ArixBrowserBookmarks.toggle(
                        context.applicationContext,
                        url,
                        effectiveSnapshot.title.ifBlank { effectiveSnapshot.host },
                    )
                }
            },
            tabCount = tabs.size + 1,
            agentBusy = isAgentTab && (agentSnapshot.isLoading || agentSnapshot.isUserControlling),
            onOpenTabs = { tabsSheetOpen = true },
            onBackToArix = onBack,
            onGo = ::navigate,
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color.White),
        ) {
            if (isAgentTab) {
                BrowserWebViewHost(modifier = Modifier.fillMaxSize())
            } else {
                activeTab?.let { tab ->
                    TabWebViewHost(tab = tab, modifier = Modifier.fillMaxSize())
                }
            }

            BrowserPageOverlay(
                isAgentTab = isAgentTab,
                modifier = Modifier.fillMaxSize(),
            )

            androidx.compose.animation.AnimatedVisibility(
                visible = effectiveSnapshot.isLoading && effectiveSnapshot.available,
                modifier = Modifier.align(Alignment.TopCenter),
                enter = fadeIn(),
                exit = fadeOut(),
            ) {
                LinearProgressIndicator(
                    progress = { (effectiveSnapshot.progress.takeIf { it in 1..99 }?.let { it / 100f }) ?: 0f },
                    modifier = Modifier.fillMaxWidth().height(3.dp),
                    color = chrome.accent,
                    trackColor = Color.Transparent,
                )
            }

            BrowserStateOverlay(
                chrome = chrome,
                snapshot = effectiveSnapshot,
                onRetry = {
                    if (effectiveSnapshot.isLoading) {
                        if (isAgentTab) {
                            scope.launch(Dispatchers.IO) { ArixBrowserSession.stopFromUser() }
                        } else {
                            activeTab?.let(ArixBrowserTabs::stop)
                        }
                    } else {
                        if (isAgentTab) {
                            launchBrowserAction { ArixBrowserSession.reloadFromUser() }
                        } else {
                            activeTab?.let(ArixBrowserTabs::reload)
                        }
                    }
                },
            )
        }

        BrowserPageAskBar(
            snapshot = effectiveSnapshot,
            onOpenChat = onOpenChat,
            onStop = onCancelGeneration,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
        )

        BrowserBottomBar(
            chrome = chrome,
            snapshot = effectiveSnapshot,
            pending = actionPending,
            onBack = {
                if (isAgentTab) {
                    launchBrowserAction { ArixBrowserSession.goBackFromUser() }
                } else {
                    activeTab?.let(ArixBrowserTabs::goBack)
                }
            },
            onForward = {
                if (isAgentTab) {
                    launchBrowserAction { ArixBrowserSession.goForwardFromUser() }
                } else {
                    activeTab?.let(ArixBrowserTabs::goForward)
                }
            },
            onHome = {
                if (effectiveSnapshot.isLoading) {
                    if (isAgentTab) {
                        scope.launch(Dispatchers.IO) { ArixBrowserSession.stopFromUser() }
                    } else {
                        activeTab?.let(ArixBrowserTabs::stop)
                    }
                } else {
                    if (isAgentTab) {
                        launchBrowserAction { ArixBrowserSession.reloadFromUser() }
                    } else {
                        activeTab?.let(ArixBrowserTabs::reload)
                    }
                }
            },
            onBookmarks = { bookmarksOpen = true },
            onMenu = {
                toolsOpen = true
                toolsPage = BrowserToolsPage.Menu
            },
        )
    }

    if (tabsSheetOpen) {
        BrowserTabsSheet(
            chrome = chrome,
            tabs = tabs,
            activeTabId = activeTabId,
            agentActive = agentSnapshot.available && agentSnapshot.title.isNotBlank(),
            agentLoading = agentSnapshot.isLoading || agentSnapshot.isUserControlling,
            onSelectTab = { activeTabId = it },
            onSelectAgentTab = { activeTabId = null },
            onCloseTab = ::closeTabAndFixSelection,
            onNewTab = {
                tabsSheetOpen = false
                openNewTab()
            },
            onDismiss = { tabsSheetOpen = false },
        )
    }

    if (bookmarksOpen) {
        BrowserBookmarksSheet(
            chrome = chrome,
            bookmarks = bookmarks,
            onOpenBookmark = { url ->
                bookmarksOpen = false
                if (isAgentTab) {
                    launchBrowserAction {
                        ArixBrowserSession.navigateFromUser(context.applicationContext, url)
                    }
                } else {
                    activeTab?.let { ArixBrowserTabs.navigate(it, url) }
                }
            },
            onRemoveBookmark = { url ->
                ArixBrowserBookmarks.remove(context.applicationContext, url)
            },
            onClearAll = {
                ArixBrowserBookmarks.clear(context.applicationContext)
            },
            onDismiss = { bookmarksOpen = false },
        )
    }

    if (toolsOpen) {
        ArixBrowserToolsSheet(
            chrome = chrome,
            onDismiss = { toolsOpen = false },
            page = toolsPage,
            onPageChange = { toolsPage = it },
            snapshot = effectiveSnapshot,
            activeTab = activeTab,
            desktopMode = if (isAgentTab) agentSnapshot.isDesktopMode else activeTab?.desktopMode == true,
            onReader = {
                toolsOpen = false
                if (!readerLoading && !actionPending) {
                    readerLoading = true
                    readerText = ""
                    scope.launch {
                        try {
                            readerText = if (isAgentTab) {
                                val result = withContext(Dispatchers.IO) {
                                    ArixBrowserSession.readReadableFromUser()
                                }
                                val parsed = runCatching {
                                    org.json.JSONObject(result.content)
                                }.getOrNull()
                                parsed?.optString("text")
                                    ?: "Could not extract the page text."
                            } else {
                                val tab = activeTab ?: return@launch
                                withContext(Dispatchers.IO) {
                                    ArixBrowserTabs.readReadable(tab)
                                }
                            }
                        } finally {
                            readerLoading = false
                        }
                    }
                }
            },
            onScreenshot = {
                toolsOpen = false
                if (actionPending) return@ArixBrowserToolsSheet
                actionPending = true
                scope.launch {
                    try {
                        val image = if (isAgentTab) {
                            val result = withContext(Dispatchers.IO) {
                                ArixBrowserSession.captureScreenshotFromUser()
                            }
                            result.images.firstOrNull()
                        } else {
                            val tab = activeTab ?: return@launch
                            withContext(Dispatchers.IO) { ArixBrowserTabs.screenshot(tab) }
                        }
                        if (image != null) {
                            screenshotPreview = image
                        } else {
                            Toast.makeText(context, "Could not capture the page.", Toast.LENGTH_SHORT).show()
                        }
                    } finally {
                        actionPending = false
                    }
                }
            },
            onDesktopMode = { desktop ->
                toolsOpen = false
                if (isAgentTab) {
                    launchBrowserAction { ArixBrowserSession.setDesktopMode(desktop) }
                } else {
                    activeTab?.let { ArixBrowserTabs.setDesktopMode(it, desktop) }
                }
            },
            onReset = {
                toolsOpen = false
                if (isAgentTab) {
                    showResetDialog = true
                } else {
                    activeTab?.let { tab ->
                        address = ""
                        ArixBrowserTabs.navigate(tab, "about:blank")
                    }
                }
            },
        )
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            containerColor = chrome.toolbar,
            titleContentColor = chrome.text,
            textContentColor = chrome.textSecondary,
            title = { Text("Reset browser session") },
            text = {
                Text(
                    "This closes the current page and clears cookies, storage " +
                        "and history for the shared browser session."
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showResetDialog = false
                        address = ""
                        launchBrowserAction { ArixBrowserSession.resetFromUser() }
                    },
                ) { Text("Reset", color = Color(0xFFF28B82)) }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text("Cancel", color = chrome.textSecondary)
                }
            },
        )
    }

    readerText?.let { text ->
        ReaderDialog(
            chrome = chrome,
            text = text,
            loading = readerLoading,
            onDismiss = { readerText = null },
        )
    }

    screenshotPreview?.let { image ->
        ScreenshotDialog(
            chrome = chrome,
            image = image,
            onDismiss = { screenshotPreview = null },
            onShare = {
                scope.launch(Dispatchers.IO) {
                    val ok = ArixMediaActions.shareBytes(
                        context = context,
                        fileName = "arix-browser-${System.currentTimeMillis()}.jpg",
                        mimeType = "image/jpeg",
                        bytes = decodeDataUrl(image.dataUrl),
                    )
                    if (!ok) {
                        Toast.makeText(context, "Could not share the screenshot.", Toast.LENGTH_SHORT).show()
                    }
                }
            },
            onSave = {
                scope.launch(Dispatchers.IO) {
                    val saved = saveScreenshotToPictures(context, image.dataUrl)
                    val message = if (saved != null) {
                        "Saved to ${saved.absolutePath}"
                    } else {
                        "Could not save the screenshot."
                    }
                    Toast.makeText(context, message, Toast.LENGTH_LONG).show()
                }
            },
        )
    }
}

private fun tabSnapshot(tab: ArixBrowserTab): ArixBrowserSnapshot = ArixBrowserSnapshot(
    available = tab.available,
    url = tab.url,
    displayUrl = tab.url,
    host = tab.host,
    title = tab.title,
    isLoading = tab.isLoading,
    isPageVisible = tab.hasCommittedPage,
    hasCommittedPage = tab.hasCommittedPage,
    progress = tab.progress,
    canGoBack = tab.canGoBack,
    canGoForward = tab.canGoForward,
    error = tab.error,
    isUserControlling = true,
    isDesktopMode = tab.desktopMode,
)

@Composable
private fun BrowserTopBar(
    chrome: ChromeColors,
    snapshot: ArixBrowserSnapshot,
    address: String,
    onAddressChange: (String) -> Unit,
    addressFocused: Boolean,
    onAddressFocusChange: (Boolean) -> Unit,
    isBookmarked: Boolean,
    onToggleBookmark: () -> Unit,
    tabCount: Int,
    agentBusy: Boolean,
    onOpenTabs: () -> Unit,
    onBackToArix: () -> Unit,
    onGo: () -> Unit,
) {
    val focusRequester = remember { FocusRequester() }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(chrome.toolbar),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 4.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(
                onClick = onBackToArix,
                modifier = Modifier.size(40.dp),
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = "Back to Arix",
                    tint = chrome.text,
                    modifier = Modifier.size(22.dp),
                )
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(42.dp)
                    .clip(RoundedCornerShape(21.dp))
                    .background(if (addressFocused) chrome.omniboxFocused else chrome.omnibox)
                    .then(
                        if (addressFocused) {
                            Modifier.border(2.dp, chrome.accent, RoundedCornerShape(21.dp))
                        } else {
                            Modifier.border(1.dp, chrome.fieldBorder.copy(alpha = 0.35f), RoundedCornerShape(21.dp))
                        }
                    ),
            ) {
                BasicTextField(
                    value = address,
                    onValueChange = onAddressChange,
                    modifier = Modifier
                        .fillMaxSize()
                        .focusRequester(focusRequester)
                        .onFocusChanged { onAddressFocusChange(it.isFocused) },
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyMedium.copy(
                        color = chrome.text,
                        fontFamily = FontFamily.SansSerif,
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Uri,
                        imeAction = ImeAction.Go,
                    ),
                    keyboardActions = KeyboardActions(onGo = { onGo() }),
                    cursorBrush = androidx.compose.ui.graphics.SolidColor(chrome.accent),
                    decorationBox = { innerTextField ->
                        Box(modifier = Modifier.fillMaxSize()) {
                            Icon(
                                imageVector = if (snapshot.url.startsWith("https://")) {
                                    Icons.Rounded.Lock
                                } else {
                                    Icons.Rounded.Language
                                },
                                contentDescription = null,
                                tint = if (snapshot.url.startsWith("https://")) {
                                    chrome.textSecondary
                                } else {
                                    chrome.textSecondary.copy(alpha = 0.7f)
                                },
                                modifier = Modifier
                                    .align(Alignment.CenterStart)
                                    .padding(start = 12.dp)
                                    .size(15.dp),
                            )
                            if (!addressFocused && address.isBlank()) {
                                Text(
                                    text = "Search or enter address",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = chrome.textSecondary,
                                    maxLines = 1,
                                    modifier = Modifier
                                        .align(Alignment.CenterStart)
                                        .padding(start = 34.dp, end = 30.dp),
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .align(Alignment.CenterStart)
                                    .padding(start = 34.dp, end = 34.dp)
                                    .fillMaxWidth(),
                            ) {
                                innerTextField()
                            }
                            Box(
                                modifier = Modifier
                                    .align(Alignment.CenterEnd)
                                    .padding(end = 3.dp)
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .clickable(
                                        interactionSource = remember { MutableInteractionSource() },
                                        indication = null,
                                    ) { onToggleBookmark() },
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(
                                    imageVector = if (isBookmarked) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                                    contentDescription = if (isBookmarked) "Remove bookmark" else "Bookmark this page",
                                    tint = if (isBookmarked) chrome.accent else chrome.textSecondary,
                                    modifier = Modifier.size(19.dp),
                                )
                            }
                        }
                    },
                )
            }

            Box(
                modifier = Modifier
                    .padding(start = 4.dp)
                    .size(38.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                    ) { onOpenTabs() },
                contentAlignment = Alignment.Center,
            ) {
                val pulse = if (agentBusy) {
                    val transition = rememberInfiniteTransition(label = "tabs_pulse")
                    transition.animateFloat(
                        initialValue = 0.4f,
                        targetValue = 1f,
                        animationSpec = infiniteRepeatable(tween(650, easing = LinearEasing), RepeatMode.Reverse),
                        label = "tabs_pulse_alpha",
                    ).value
                } else {
                    1f
                }
                Box(
                    modifier = Modifier
                        .size(22.dp)
                        .alpha(pulse)
                        .border(2.dp, chrome.text, RoundedCornerShape(6.dp)),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = tabCount.coerceAtMost(99).toString(),
                        style = MaterialTheme.typography.labelSmall,
                        color = chrome.text,
                        maxLines = 1,
                    )
                }
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(chrome.divider))
    }
}

@Composable
private fun BrowserBottomBar(
    chrome: ChromeColors,
    snapshot: ArixBrowserSnapshot,
    pending: Boolean,
    onBack: () -> Unit,
    onForward: () -> Unit,
    onHome: () -> Unit,
    onBookmarks: () -> Unit,
    onMenu: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(chrome.toolbar),
    ) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(chrome.divider))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            BrowserNavButton(
                icon = Icons.AutoMirrored.Rounded.ArrowBack,
                description = "Back",
                enabled = snapshot.canGoBack && !pending,
                chrome = chrome,
                onClick = onBack,
            )
            BrowserNavButton(
                icon = Icons.AutoMirrored.Rounded.ArrowForward,
                description = "Forward",
                enabled = snapshot.canGoForward && !pending,
                chrome = chrome,
                onClick = onForward,
            )
            BrowserNavButton(
                icon = if (snapshot.isLoading) Icons.Rounded.Close else Icons.Rounded.Home,
                description = if (snapshot.isLoading) "Stop loading" else "Reload",
                enabled = snapshot.available,
                chrome = chrome,
                onClick = onHome,
            )
            BrowserNavButton(
                icon = Icons.Rounded.StarBorder,
                description = "Bookmarks",
                enabled = true,
                chrome = chrome,
                onClick = onBookmarks,
            )
            BrowserNavButton(
                icon = Icons.Rounded.MoreVert,
                description = "Menu",
                enabled = true,
                chrome = chrome,
                onClick = onMenu,
            )
        }
    }
}

@Composable
private fun BrowserNavButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    enabled: Boolean,
    chrome: ChromeColors,
    onClick: () -> Unit,
) {
    val alpha by animateFloatAsState(
        targetValue = if (enabled) 1f else 0.34f,
        animationSpec = tween(140),
        label = "browser_nav_alpha",
    )
    IconButton(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier
            .size(44.dp)
            .alpha(alpha),
    ) {
        Icon(
            imageVector = icon,
            contentDescription = description,
            tint = chrome.text,
            modifier = Modifier.size(23.dp),
        )
    }
}

@Composable
private fun BrowserTabsSheet(
    chrome: ChromeColors,
    tabs: List<ArixBrowserTab>,
    activeTabId: Long?,
    agentActive: Boolean,
    agentLoading: Boolean,
    onSelectTab: (Long) -> Unit,
    onSelectAgentTab: () -> Unit,
    onCloseTab: (ArixBrowserTab) -> Unit,
    onNewTab: () -> Unit,
    onDismiss: () -> Unit,
) {
    BrowserSheetScaffold(
        chrome = chrome,
        title = "Tabs",
        onDismiss = onDismiss,
    ) {
        item {
            BrowserSheetRow(
                chrome = chrome,
                leading = {
                    Icon(
                        imageVector = Icons.Rounded.SmartToy,
                        contentDescription = null,
                        tint = if (activeTabId == null) chrome.accent else chrome.textSecondary,
                        modifier = Modifier.size(20.dp),
                    )
                },
                title = "Arix shared session",
                subtitle = if (agentLoading) "Agent is working…" else "The page the agent drives",
                selected = activeTabId == null,
                onClick = onSelectAgentTab,
                trailing = null,
            )
        }
        items(tabs, key = { it.id }) { tab ->
            BrowserSheetRow(
                chrome = chrome,
                leading = {
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(
                                if (tab.id == activeTabId) chrome.accent.copy(alpha = 0.8f)
                                else chrome.textSecondary.copy(alpha = 0.35f)
                            ),
                    )
                },
                title = tab.displayTitle.ifBlank { "New tab" },
                subtitle = tab.host.ifBlank { tab.url },
                selected = tab.id == activeTabId,
                onClick = { onSelectTab(tab.id) },
                trailing = {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null,
                            ) { onCloseTab(tab) },
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = "Close tab",
                            tint = chrome.textSecondary,
                            modifier = Modifier.size(16.dp),
                        )
                    }
                },
            )
        }
        item {
            BrowserSheetRow(
                chrome = chrome,
                leading = {
                    Icon(
                        imageVector = Icons.Rounded.Add,
                        contentDescription = null,
                        tint = chrome.accent,
                        modifier = Modifier.size(20.dp),
                    )
                },
                title = "New tab",
                subtitle = "Open a fresh page",
                selected = false,
                onClick = onNewTab,
                trailing = null,
            )
        }
    }
}

@Composable
private fun BrowserBookmarksSheet(
    chrome: ChromeColors,
    bookmarks: List<ArixBrowserBookmarks.Bookmark>,
    onOpenBookmark: (String) -> Unit,
    onRemoveBookmark: (String) -> Unit,
    onClearAll: () -> Unit,
    onDismiss: () -> Unit,
) {
    BrowserSheetScaffold(
        chrome = chrome,
        title = "Bookmarks",
        onDismiss = onDismiss,
        trailing = {
            if (bookmarks.isNotEmpty()) {
                TextButton(onClick = onClearAll) {
                    Text("Clear all", color = chrome.accent, style = MaterialTheme.typography.labelMedium)
                }
            }
        },
    ) {
        if (bookmarks.isEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 28.dp, vertical = 34.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Icon(
                        imageVector = Icons.Rounded.StarBorder,
                        contentDescription = null,
                        tint = chrome.textSecondary.copy(alpha = 0.6f),
                        modifier = Modifier.size(34.dp),
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = "No bookmarks yet",
                        style = MaterialTheme.typography.titleSmall,
                        color = chrome.text,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Tap the star in the address bar to save a page.",
                        style = MaterialTheme.typography.bodySmall,
                        color = chrome.textSecondary,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    )
                }
            }
        } else {
            items(bookmarks, key = { it.url }) { bookmark ->
                BrowserSheetRow(
                    chrome = chrome,
                    leading = {
                        Icon(
                            imageVector = Icons.Rounded.Star,
                            contentDescription = null,
                            tint = chrome.accent,
                            modifier = Modifier.size(18.dp),
                        )
                    },
                    title = bookmark.title,
                    subtitle = bookmark.url,
                    selected = false,
                    onClick = { onOpenBookmark(bookmark.url) },
                    trailing = {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .clickable(
                                    interactionSource = remember { MutableInteractionSource() },
                                    indication = null,
                                ) { onRemoveBookmark(bookmark.url) },
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Delete,
                                contentDescription = "Remove bookmark",
                                tint = chrome.textSecondary,
                                modifier = Modifier.size(16.dp),
                            )
                        }
                    },
                )
            }
        }
    }
}

@Composable
private fun BrowserSheetScaffold(
    chrome: ChromeColors,
    title: String,
    onDismiss: () -> Unit,
    trailing: (@Composable () -> Unit)? = null,
    content: androidx.compose.foundation.lazy.LazyListScope.() -> Unit,
) {
    BrowserSheetPanel(chrome = chrome, title = title, onDismiss = onDismiss, trailing = trailing) {
        androidx.compose.foundation.lazy.LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            content = content,
        )
    }
}

@Composable
private fun BrowserSheetPanel(
    chrome: ChromeColors,
    title: String,
    onDismiss: () -> Unit,
    trailing: (@Composable () -> Unit)?,
    sheetContent: @Composable () -> Unit,
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x99000000))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
            ) { onDismiss() },
    ) {
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp))
                .background(chrome.toolbar)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                ) {  }
                .navigationBarsPadding()
                .padding(bottom = 8.dp),
        ) {
            Box(
                modifier = Modifier
                    .padding(top = 10.dp)
                    .align(Alignment.CenterHorizontally)
                    .size(width = 42.dp, height = 4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(chrome.textSecondary.copy(alpha = 0.45f)),
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 20.dp, end = 12.dp, top = 8.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = chrome.text,
                    modifier = Modifier.weight(1f),
                )
                trailing?.invoke()
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(chrome.divider),
            )
            sheetContent()
        }
    }
}

@Composable
private fun BrowserSheetRow(
    chrome: ChromeColors,
    leading: @Composable () -> Unit,
    title: String,
    subtitle: String,
    selected: Boolean,
    onClick: () -> Unit,
    trailing: (@Composable () -> Unit)?,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (selected) chrome.tabActive.copy(alpha = 0.55f) else Color.Transparent)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
            ) { onClick() }
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(modifier = Modifier.size(24.dp), contentAlignment = Alignment.Center) { leading() }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                color = chrome.text,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (subtitle.isNotBlank()) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = chrome.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        trailing?.invoke()
    }
}

@Composable
private fun BrowserPageOverlay(
    isAgentTab: Boolean,
    modifier: Modifier = Modifier,
) {
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val interaction by ArixBrowserSession.interactions.collectAsState()

    val ripple = remember { Animatable(1f) }
    var rippleCenter by remember { mutableStateOf(Offset.Zero) }
    var rippleActive by remember { mutableStateOf(false) }
    var lastActivityAtMs by remember { mutableStateOf(0L) }
    var chipVisible by remember { mutableStateOf(false) }

    fun cssToViewPx(v: Int): Float = with(density) { v.dp.toPx() }

    LaunchedEffect(interaction?.atMillis) {
        val event = interaction ?: return@LaunchedEffect
        if (!event.isAgent) return@LaunchedEffect
        lastActivityAtMs = System.currentTimeMillis()
        when (event.action) {
            "click" -> {
                if (event.x >= 0 && event.y >= 0) {
                    val center = Offset(cssToViewPx(event.x), cssToViewPx(event.y))
                    rippleCenter = center
                    rippleActive = true
                    scope.launch {
                        ripple.snapTo(0f)
                        ripple.animateTo(1f, tween(700))
                        rippleActive = false
                    }
                }
            }
            else -> Unit
        }
    }

    LaunchedEffect(lastActivityAtMs) {
        if (lastActivityAtMs == 0L) return@LaunchedEffect
        chipVisible = true
        while (System.currentTimeMillis() - lastActivityAtMs < 1_600) {
            delay(100)
        }
        chipVisible = false
    }

    Box(
        modifier = modifier
    ) {
        if (rippleActive) {
            val radius = 8.dp + 22.dp * ripple.value
            val ringAlpha = (1f - ripple.value) * 0.9f
            Box(
                modifier = Modifier
                    .offset(
                        x = with(density) { rippleCenter.x.toDp() } - radius,
                        y = with(density) { rippleCenter.y.toDp() } - radius,
                    )
                    .size(radius * 2)
                    .clip(CircleShape)
                    .background(chromeColors().accent.copy(alpha = ringAlpha * 0.25f))
                    .border(1.5.dp, chromeColors().accent.copy(alpha = ringAlpha), CircleShape),
            )
        }
        val chipText = when (interaction?.takeIf { it.isAgent }?.action) {
            "type" -> "typing \u201c${interaction?.textHint.orEmpty()}\u201d"
            "scroll" -> "scrolling"
            "navigate" -> "navigating"
            "go_back" -> "going back"
            "go_forward" -> "going forward"
            "reload" -> "reloading"
            else -> null
        }
        if (chipVisible && chipText != null) {
            Row(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(10.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xE6202124))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                CircularProgressIndicator(
                    strokeWidth = 2.dp,
                    color = ArixChromeDark.accent,
                    modifier = Modifier.size(12.dp),
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = chipText,
                    style = MaterialTheme.typography.labelSmall,
                    color = ArixChromeDark.text,
                    maxLines = 1,
                )
            }
        }
    }
}

private enum class BrowserOverlay {
    None,
    Empty,
    Loading,
    Failed,
}

@Composable
private fun androidx.compose.foundation.layout.BoxScope.BrowserStateOverlay(
    chrome: ChromeColors,
    snapshot: ArixBrowserSnapshot,
    onRetry: () -> Unit,
) {
    val overlay = when {
        !snapshot.available -> BrowserOverlay.Empty
        !snapshot.hasCommittedPage && snapshot.error != null -> BrowserOverlay.Failed
        !snapshot.hasCommittedPage -> BrowserOverlay.Loading
        else -> BrowserOverlay.None
    }
    androidx.compose.animation.Crossfade(
        targetState = overlay,
        label = "browser_overlay",
        modifier = Modifier.fillMaxSize(),
    ) { state ->
        when (state) {
            BrowserOverlay.Empty -> BrowserEmptyState(chrome, Modifier.fillMaxSize())
            BrowserOverlay.Loading -> BrowserLoadingState(chrome, snapshot.host, Modifier.fillMaxSize())
            BrowserOverlay.Failed -> BrowserFailedState(chrome, snapshot.error, onRetry, Modifier.fillMaxSize())
            BrowserOverlay.None -> Unit
        }
    }
}

@Composable
private fun BrowserOverlayIcon(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier
            .size(64.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(tint.copy(alpha = 0.12f)),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = tint,
            modifier = Modifier.size(28.dp),
        )
    }
}

@Composable
private fun BrowserEmptyState(chrome: ChromeColors, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(chrome.toolbar.copy(alpha = 0.6f))
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        BrowserOverlayIcon(
            icon = Icons.Rounded.Language,
            tint = chrome.accent,
        )
        Spacer(Modifier.height(16.dp))
        Text(
            text = "The browser hasn't opened a page yet",
            style = MaterialTheme.typography.titleSmall,
            color = chrome.text,
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = "Enter a URL above — or ask Arix to browse for you.\n" +
                "The same session stays live for takeover.",
            style = MaterialTheme.typography.bodySmall,
            color = chrome.textSecondary,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
    }
}

@Composable
private fun BrowserLoadingState(
    chrome: ChromeColors,
    host: String,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .background(chrome.toolbar.copy(alpha = 0.6f))
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        CircularProgressIndicator(
            color = chrome.accent,
            strokeWidth = 3.dp,
            modifier = Modifier.size(34.dp),
        )
        Spacer(Modifier.height(16.dp))
        Text(
            text = if (host.isBlank()) "Opening…" else "Opening $host…",
            style = MaterialTheme.typography.bodyMedium,
            color = chrome.textSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun BrowserFailedState(
    chrome: ChromeColors,
    error: String?,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .background(chrome.toolbar.copy(alpha = 0.6f))
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        BrowserOverlayIcon(
            icon = Icons.Rounded.GppMaybe,
            tint = Color(0xFFF28B82),
        )
        Spacer(Modifier.height(16.dp))
        Text(
            text = "The page can't be opened",
            style = MaterialTheme.typography.titleSmall,
            color = chrome.text,
        )
        if (!error.isNullOrBlank()) {
            Spacer(Modifier.height(6.dp))
            Text(
                text = error,
                style = MaterialTheme.typography.bodySmall,
                color = chrome.textSecondary,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
        }
        Spacer(Modifier.height(14.dp))
        TextButton(onClick = onRetry) {
            Text("Reload", color = chrome.accent)
        }
    }
}

@Composable
private fun ReaderDialog(
    chrome: ChromeColors,
    text: String,
    loading: Boolean,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = chrome.toolbar,
        titleContentColor = chrome.text,
        textContentColor = chrome.text,
        title = { Text("Page text") },
        text = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(420.dp),
            ) {
                if (loading) {
                    CircularProgressIndicator(
                        color = chrome.accent,
                        modifier = Modifier.align(Alignment.Center),
                    )
                } else {
                    Text(
                        text = text.ifBlank { "No readable text found on this page." },
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = FontFamily.Monospace,
                            lineHeight = 19.sp,
                        ),
                        color = chrome.text,
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState()),
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close", color = chrome.accent) }
        },
    )
}

@Composable
private fun ScreenshotDialog(
    chrome: ChromeColors,
    image: ArixBrowserImage,
    onDismiss: () -> Unit,
    onShare: () -> Unit,
    onSave: () -> Unit,
) {
    val bitmap = remember(image.dataUrl) { decodeDataUrlBitmap(image.dataUrl) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = chrome.toolbar,
        titleContentColor = chrome.text,
        title = { Text("Screenshot") },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                if (bitmap != null) {
                    androidx.compose.foundation.Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = "Page screenshot",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(360.dp)
                            .clip(RoundedCornerShape(14.dp)),
                    )
                } else {
                    Text(
                        "Could not decode the captured image.",
                        color = chrome.textSecondary,
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "${image.width} × ${image.height}",
                    style = MaterialTheme.typography.labelSmall,
                    color = chrome.textSecondary,
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onSave) { Text("Save", color = chrome.accent) }
        },
        dismissButton = {
            Row {
                TextButton(onClick = onShare) { Text("Share", color = chrome.textSecondary) }
                TextButton(onClick = onDismiss) { Text("Close", color = chrome.textSecondary) }
            }
        },
    )
}

private fun decodeDataUrl(dataUrl: String): ByteArray =
    runCatching {
        val base64 = dataUrl.substringAfter("base64,", "")
        android.util.Base64.decode(base64, android.util.Base64.NO_WRAP)
    }.getOrDefault(ByteArray(0))

private fun decodeDataUrlBitmap(dataUrl: String): android.graphics.Bitmap? =
    runCatching {
        val bytes = decodeDataUrl(dataUrl)
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }
        .getOrNull()
        .takeIf { it != null && it.width > 0 }

private fun saveScreenshotToPictures(context: android.content.Context, dataUrl: String): File? =
    runCatching {
        val bytes = decodeDataUrl(dataUrl)
        if (bytes.isEmpty()) return null
        val dir = context.getExternalFilesDir(android.os.Environment.DIRECTORY_PICTURES)
            ?: context.filesDir
        val file = File(dir, "arix-browser-${System.currentTimeMillis()}.jpg")
        file.writeBytes(bytes)
        file
    }.getOrNull()

@Composable
private fun BrowserWebViewHost(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val container = remember(context) {
        FrameLayout(context).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
            )
            setBackgroundColor(android.graphics.Color.WHITE)
        }
    }
    DisposableEffect(container, context) {
        ArixBrowserSession.attachTo(container, context)
        onDispose { ArixBrowserSession.detachFrom(container) }
    }
    AndroidView(
        factory = { container },
        update = { view -> view.setBackgroundColor(android.graphics.Color.WHITE) },
        modifier = modifier,
    )
}

@Composable
private fun TabWebViewHost(
    tab: ArixBrowserTab,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val container = remember(tab, context) {
        FrameLayout(context).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
            )
            setBackgroundColor(android.graphics.Color.WHITE)
        }
    }
    DisposableEffect(tab, container, context) {
        ArixBrowserTabs.attachTabView(tab, container)
        onDispose { ArixBrowserTabs.detachTabView(tab, container) }
    }
    AndroidView(
        factory = { container },
        update = { view -> view.setBackgroundColor(android.graphics.Color.WHITE) },
        modifier = modifier,
    )
}
