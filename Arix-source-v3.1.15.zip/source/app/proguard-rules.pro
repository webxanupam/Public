-dontwarn android.app.ActivityThread
-dontwarn android.app.ContextImpl
-dontwarn android.app.LoadedApk

-keepclassmembers enum com.vladsch.flexmark.** {
    *;
}

-repackageclasses ''
-allowaccessmodification

-optimizationpasses 5

# v3.0.73 — narrowed the -assumenosideeffects patterns. The previous
# shapes (`{ *; }` on kotlin.Metadata / DebugMetadataKt and `*** v(...)`
# on android.util.Log) all matched java.lang.Object's inherited methods
# too (R8 surfaced each as "matches the following method(s) on
# java.lang.Object: clone(), equals(), finalize(), getClass(),
# hashCode(), notify(), notifyAll(), toString(), wait() … This is most
# likely not intended"). The kotlin.Metadata and DebugMetadataKt rules
# are removed entirely (every narrower shape still matched Object's
# methods, and the optimization benefit was marginal — R8 strips
# kotlin.Metadata anyway under -repackageclasses); the android.util.Log
# rule stays with the explicit `int` return type so R8 keeps stripping
# log calls (the most impactful of the three) without the over-broad
# warning.
-assumenosideeffects class android.util.Log {
    public static int v(...);
    public static int d(...);
    public static int i(...);
    public static int w(...);
    public static int e(...);
}

# ====================================================================== #
# v2.9.13 release hardening — aggressive shrinking with guarded surface. #
# ====================================================================== #

# Preserve the attributes R8 needs to reconcile reflection, generics and
# nested-class references used by serialization, Room and the tool bridge.
-keepattributes Signature, InnerClasses, EnclosingMethod, *Annotation*, RuntimeVisibleAnnotations, AnnotationDefault

# ---- kotlinx-serialization (shared models: AppSettings, PiProviderCatalog) ----
# Generated serializers are looked up via the Companion.serializer() chain;
# R8's default shrinking breaks it without these keeps.
-dontnote kotlinx.serialization.**
-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class com.arix.app.**$$serializer { *; }
-keepclassmembers class com.arix.app.** {
    *** Companion;
}
-keepclasseswithmembers class com.arix.app.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# ---- Room (KSP-generated implementations are compile-time, but the
#      entity/DAO classes are reflected by the generated code paths and
#      exported schema validators) ----
-keep class * extends androidx.room.RoomDatabase { *; }
-keep @androidx.room.Entity class * { *; }
-keepclassmembers class * {
    @androidx.room.* <fields>;
    @androidx.room.* <init>(...);
}

# ---- System integration surface (manifest-driven instantiation; AGP
#      keeps these, made explicit as belt-and-braces for R8 config
#      changes) ----
-keep class com.arix.app.MainActivity { *; }
-keep class com.arix.app.media.ArixMediaPlaybackService { *; }

# ---- Snakeyaml (reflective bean access from YAML extension manifests) ----
-dontwarn org.yaml.snakeyaml.**
-keep class org.yaml.snakeyaml.** { *; }

# ---- OkHttp / Okio (service-loader + TLS capability probing) ----
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn javax.annotation.**
-keepnames class okhttp3.internal.publicsuffix.PublicSuffixDatabase
-keepclassmembers interface okhttp3.internal.r8.** {
    *;
}

# ---- Jsoup / flexmark (DOM class names surfaced via reflection-lite paths) ----
-dontwarn org.jsoup.**
-keepnames class org.jsoup.** { *; }

# ---- Speech recognition callbacks referenced from platform dispatch ----
# (v3.0.37 — TTS output was removed; voice INPUT recognition stays.)
-keepclassmembers class com.arix.app.voice.** {
    public *;
}

# ---- Coroutines debug metadata stripped, but keep continuation fields ----
-keepclassmembers class kotlinx.coroutines.** {
    volatile <fields>;
}

# ---- v2.9.21 Post Editor: the WebView JS bridge. evaluateJavascript
#      dispatches by the runtime string name ("ArixBridge"), and the
#      @JavascriptInterface methods are looked up reflectively — the
#      aggressive shrink/repackage must keep them. ----
-keepclassmembers class com.arix.app.ui.ArixPostEditorToolKt$* {
    @android.webkit.JavascriptInterface <methods>;
}
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# v3.1.15 — phone control (Mika port). The shell-uid helper process is
# launched via `app_process ... com.arix.app.agent.shell.HelperMain`, i.e.
# BY CLASS NAME from this same APK; R8 must never rename or strip it. The
# IArixShell AIDL binder and the accessibility service are framework entry
# points; the rest of the package uses reflection (ActivityManager internals,
# context creation) that R8 cannot see.
-keep class com.arix.app.agent.shell.HelperMain { *; }
-keep class com.arix.app.agent.shell.ShellService { *; }
-keep class com.arix.app.agent.shell.ShellContext { *; }
-keep class com.arix.app.agent.shell.HelperProcess { *; }
-keep class com.arix.app.agent.shell.IArixShell { *; }
-keep class com.arix.app.agent.shell.IArixShell** { *; }
-keep class com.arix.app.agent.a11y.** { *; }
-keep class com.arix.app.agent.display.** { *; }
-keepclassmembers class com.arix.app.agent.** { *; }
-keepclasseswithmembers class com.arix.app.agent.** { *; }
# Accessibility service callbacks are invoked by the framework.
-keepclassmembers class * extends android.accessibilityservice.AccessibilityService {
    public void onAccessibilityEvent(android.view.accessibility.AccessibilityEvent);
    public void onInterrupt();
    public void onServiceConnected();
    public boolean onUnbind(android.content.Intent);
    public void onDestroy();
}
