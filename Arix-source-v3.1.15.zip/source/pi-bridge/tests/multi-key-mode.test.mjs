// v3.0.87 — MULTI-KEY MODE (Aharou port) bridge tests.
// Covers the three new rotation knobs against a mock OpenAI-compatible
// endpoint: the multi_key_enabled toggle (pool off = single key), the
// key_switch_status_codes trigger (401 switches like a quota error) and
// the round_robin per-turn starting key.
import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import { createServer } from "node:http";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { test } from "node:test";

const activeClients = new Set();

class BridgeClient {
  constructor(environment = {}, bridgePath = "dist/bridge.mjs", cwd = process.cwd()) {
    const { spawn } = require_node();
    this.child = spawn(process.execPath, [bridgePath], {
      cwd,
      stdio: ["pipe", "pipe", "pipe"],
      env: { ...process.env, ...environment },
    });
    this.pending = new Map();
    this.stderr = "";
    const { createInterface } = require_node();
    createInterface({ input: this.child.stdout }).on("line", (line) => {
      if (!line.trim()) return;
      let frame;
      try {
        frame = JSON.parse(line);
      } catch {
        return;
      }
      if (frame.type === "event") return;
      const pending = this.pending.get(frame.id);
      if (!pending) return;
      this.pending.delete(frame.id);
      clearTimeout(pending.timeout);
      if (frame.type === "error" || frame.ok === false) {
        pending.reject(new Error(frame.error?.message || "Pi bridge request failed."));
      } else {
        pending.resolve(frame.payload);
      }
    });
    this.child.stderr.setEncoding("utf8");
    this.child.stderr.on("data", (chunk) => {
      this.stderr += chunk;
    });
    activeClients.add(this);
  }
  request(id, type, payload = {}, timeoutMs = 30_000) {
    this.child.stdin.write(`${JSON.stringify({ id, type, payload })}\n`);
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`Timed out waiting for ${type}: ${this.stderr}`));
      }, timeoutMs);
      this.pending.set(id, { resolve, reject, timeout });
    });
  }
  async close() {
    activeClients.delete(this);
    this.child.kill();
    await new Promise((resolve) => this.child.on("exit", resolve));
  }
}

function require_node() {
  return globalThis.__node_mods;
}
const { spawn } = await import("node:child_process");
const { createInterface } = await import("node:readline");
globalThis.__node_mods = { spawn, createInterface };

function userMessage(text) {
  return { role: "user", content: [{ type: "text", text }] };
}

function writeOpenAiSse(response, text) {
  response.writeHead(200, { "content-type": "text/event-stream" });
  const chunk1 = {
    id: "chatcmpl-1",
    object: "chat.completion.chunk",
    choices: [{ index: 0, delta: { content: text }, finish_reason: null }],
  };
  const chunk2 = {
    id: "chatcmpl-1",
    object: "chat.completion.chunk",
    choices: [{ index: 0, delta: {}, finish_reason: "stop" }],
    usage: { prompt_tokens: 10, completion_tokens: 5, total_tokens: 15 },
  };
  response.write(`data: ${JSON.stringify(chunk1)}\n\n`);
  response.write(`data: ${JSON.stringify(chunk2)}\n\n`);
  response.write("data: [DONE]\n\n");
  response.end();
}

function writeOpenAi401(response) {
  response.writeHead(401, { "content-type": "application/json" });
  response.end(
    JSON.stringify({
      error: {
        message: "Incorrect API key provided: invalid. HTTP 401 Unauthorized.",
        type: "invalid_request_error",
        code: "invalid_api_key",
      },
    }),
  );
}

async function withMockServer(handler) {
  const server = createServer(handler);
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  return {
    baseUrl: `http://127.0.0.1:${address.port}/v1`,
    close: () => server.close(),
  };
}

test("multi_key_enabled=false keeps the pool single-key (no rotation on 401)", async (t) => {
  const home = await mkdtemp(join(tmpdir(), "arix-multikey-off-"));
  t.after(() => rm(home, { recursive: true, force: true }));
  const seenKeys = [];
  const mock = await withMockServer((request, response) => {
    const chunks = [];
    request.on("data", (chunk) => chunks.push(chunk));
    request.on("end", () => {
      const key = String(request.headers["authorization"] ?? "").replace(/^Bearer\s+/i, "");
      seenKeys.push(key);
      if (key.includes("bad-key")) {
        writeOpenAi401(response);
        return;
      }
      writeOpenAiSse(response, "ok");
    });
  });
  const client = new BridgeClient({ HOME: home, USERPROFILE: home });
  try {
    const result = await client.request("multikey-off", "complete_once", {
      model_config: {
        provider_type: "custom",
        provider_config_id: "arix-multikey-off-test",
        pi_provider_id: "arix-multikey-off-test",
        pi_api: "openai-completions",
        model_id: "test-model",
        base_url: mock.baseUrl,
        api_key: "bad-key",
        api_keys: ["bad-key", "fresh-key"],
        multi_key_enabled: false,
        reasoning: false,
        max_retries: 0,
        max_provider_retries: 0,
      },
      system_prompt: "You are terse.",
      messages: [userMessage("hi")],
      reasoning: "off",
    });
    assert.ok(!result.assistant_text.includes("ok"), "the error must surface");
    assert.deepEqual(
      seenKeys.filter((k) => k.includes("fresh-key")),
      [],
      "the disabled pool must never rotate to the second key",
    );
  } finally {
    await client.close();
    mock.close();
  }
});

test("custom status codes (401) trigger the rotation like a quota error", async (t) => {
  const home = await mkdtemp(join(tmpdir(), "arix-multikey-401-"));
  t.after(() => rm(home, { recursive: true, force: true }));
  const seenKeys = [];
  const mock = await withMockServer((request, response) => {
    const chunks = [];
    request.on("data", (chunk) => chunks.push(chunk));
    request.on("end", () => {
      const key = String(request.headers["authorization"] ?? "").replace(/^Bearer\s+/i, "");
      seenKeys.push(key);
      if (key.includes("bad-key")) {
        writeOpenAi401(response);
        return;
      }
      writeOpenAiSse(response, "rotated on 401");
    });
  });
  const client = new BridgeClient({ HOME: home, USERPROFILE: home });
  try {
    const result = await client.request("multikey-401", "complete_once", {
      model_config: {
        provider_type: "custom",
        provider_config_id: "arix-multikey-401-test",
        pi_provider_id: "arix-multikey-401-test",
        pi_api: "openai-completions",
        model_id: "test-model",
        base_url: mock.baseUrl,
        api_key: "bad-key",
        api_keys: ["bad-key", "fresh-key"],
        multi_key_enabled: true,
        key_switch_status_codes: [401, 403],
        key_cooldown_minutes: 5,
        reasoning: false,
        max_retries: 0,
        max_provider_retries: 0,
      },
      system_prompt: "You are terse.",
      messages: [userMessage("hi")],
      reasoning: "off",
    });
    assert.equal(result.assistant_text, "rotated on 401");
    assert.ok(
      seenKeys.some((k) => k.includes("fresh-key")),
      "the 401 must switch to the second key",
    );
  } finally {
    await client.close();
    mock.close();
  }
});

test("round_robin spreads consecutive one-shot calls across the pool", async (t) => {
  const home = await mkdtemp(join(tmpdir(), "arix-multikey-rr-"));
  t.after(() => rm(home, { recursive: true, force: true }));
  const seenKeys = [];
  const mock = await withMockServer((request, response) => {
    const chunks = [];
    request.on("data", (chunk) => chunks.push(chunk));
    request.on("end", () => {
      const key = String(request.headers["authorization"] ?? "").replace(/^Bearer\s+/i, "");
      seenKeys.push(key);
      writeOpenAiSse(response, "ok");
    });
  });
  const client = new BridgeClient({ HOME: home, USERPROFILE: home });
  const baseConfig = {
    provider_type: "custom",
    provider_config_id: "arix-multikey-rr-test",
    pi_provider_id: "arix-multikey-rr-test",
    pi_api: "openai-completions",
    model_id: "test-model",
    base_url: mock.baseUrl,
    api_key: "key-a",
    api_keys: ["key-a", "key-b", "key-c"],
    multi_key_enabled: true,
    key_rotation_strategy: "round_robin",
    key_cooldown_minutes: 0,
    reasoning: false,
    max_retries: 0,
    max_provider_retries: 0,
  };
  try {
    for (let index = 0; index < 3; index += 1) {
      await client.request(`rr-${index}`, "complete_once", {
        model_config: baseConfig,
        system_prompt: "You are terse.",
        messages: [userMessage("hi")],
        reasoning: "off",
      });
    }
    const uniqueKeys = new Set(seenKeys);
    assert.ok(
      uniqueKeys.size >= 2,
      `round robin must spread the starting key across turns. seen=${JSON.stringify(seenKeys)}`,
    );
  } finally {
    await client.close();
    mock.close();
  }
});
