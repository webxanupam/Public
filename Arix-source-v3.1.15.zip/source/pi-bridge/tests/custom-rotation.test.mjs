// CUSTOM (OpenAI-compatible) provider key-rotation repro test.
// Simulates a real OpenAI-style 429 TPM quota error on the FIRST key and a
// healthy second key, against a mock /v1/chat/completions endpoint — the
// user's setup ("limit: 250000, tokens/minute" + 2 configured keys).
import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import { createServer } from "node:http";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { test } from "node:test";

const activeClients = new Set();

class BridgeClient {
  constructor(environment = {}, bridgePath = "dist/bridge.mjs", cwd = process.cwd()) {
    const { spawn } = require_node();
    this.child = spawn(process.execPath, [bridgePath], {
      cwd,
      stdio: ["pipe", "pipe", "pipe"],
      env: { ...process.env, ...environment },
    });
    this.pending = new Map();
    this.stderr = "";
    const { createInterface } = require_node();
    createInterface({ input: this.child.stdout }).on("line", (line) => {
      if (!line.trim()) return;
      let frame;
      try {
        frame = JSON.parse(line);
      } catch {
        return;
      }
      if (frame.type === "event") return;
      const pending = this.pending.get(frame.id);
      if (!pending) return;
      this.pending.delete(frame.id);
      clearTimeout(pending.timeout);
      if (frame.type === "error" || frame.ok === false) {
        pending.reject(new Error(frame.error?.message || "Pi bridge request failed."));
      } else {
        pending.resolve(frame.payload);
      }
    });
    this.child.stderr.setEncoding("utf8");
    this.child.stderr.on("data", (chunk) => {
      this.stderr += chunk;
    });
    activeClients.add(this);
  }
  request(id, type, payload = {}, timeoutMs = 30_000) {
    this.child.stdin.write(`${JSON.stringify({ id, type, payload })}\n`);
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`Timed out waiting for ${type}: ${this.stderr}`));
      }, timeoutMs);
      this.pending.set(id, { resolve, reject, timeout });
    });
  }
  async close() {
    activeClients.delete(this);
    this.child.kill();
    await new Promise((resolve) => this.child.on("exit", resolve));
  }
}

function require_node() {
  return globalThis.__node_mods;
}
const { spawn } = await import("node:child_process");
const { createInterface } = await import("node:readline");
globalThis.__node_mods = { spawn, createInterface };

function userMessage(text) {
  return { role: "user", content: [{ type: "text", text }] };
}

// OpenAI-compatible SSE success response.
function writeOpenAiSse(response, text) {
  response.writeHead(200, { "content-type": "text/event-stream" });
  const chunk1 = {
    id: "chatcmpl-1",
    object: "chat.completion.chunk",
    choices: [{ index: 0, delta: { content: text }, finish_reason: null }],
  };
  const chunk2 = {
    id: "chatcmpl-1",
    object: "chat.completion.chunk",
    choices: [{ index: 0, delta: {}, finish_reason: "stop" }],
    usage: { prompt_tokens: 10, completion_tokens: 5, total_tokens: 15 },
  };
  response.write(`data: ${JSON.stringify(chunk1)}\n\n`);
  response.write(`data: ${JSON.stringify(chunk2)}\n\n`);
  response.write("data: [DONE]\n\n");
  response.end();
}

// The user's reported shape: TPM quota exhaustion with the 250000 limit.
function writeOpenAi429(response) {
  response.writeHead(429, { "content-type": "application/json" });
  response.end(
    JSON.stringify({
      error: {
        message:
          "Rate limit reached: limit: 250000, tokens/minute. Please retry after 60s.",
        type: "rate_limit_error",
        code: "rate_limit_exceeded",
      },
    }),
  );
}

test("custom openai provider rotates to the next key on 429 TPM quota exhaustion (run_turn agent path)", async (t) => {
  const home = await mkdtemp(join(tmpdir(), "arix-custom-rotation-"));
  const workspace = join(home, "workspace");
  t.after(() => rm(home, { recursive: true, force: true }));

  const seenKeys = [];
  const server = createServer((request, response) => {
    const chunks = [];
    request.on("data", (chunk) => chunks.push(chunk));
    request.on("end", () => {
      const key = String(request.headers["authorization"] ?? "").replace(/^Bearer\s+/i, "");
      seenKeys.push(key);
      if (key.includes("exhausted-key")) {
        writeOpenAi429(response);
        return;
      }
      writeOpenAiSse(response, "rotated and done");
    });
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  const baseUrl = `http://127.0.0.1:${address.port}/v1`;

  const client = new BridgeClient({ HOME: home, USERPROFILE: home, ARIX_PI_BRIDGE_DEBUG: "1" });
  try {
    const config = {
      provider_type: "custom",
      provider_config_id: "arix-custom-rotation-test",
      pi_provider_id: "arix-custom-rotation-test",
      pi_api: "openai-completions",
      model_id: "test-model",
      base_url: baseUrl,
      api_key: "exhausted-key",
      api_keys: ["exhausted-key", "fresh-key"],
      reasoning: false,
      max_retries: 0,
      max_provider_retries: 0,
    };
    const result = await client.request("custom-rotation-agent-turn", "run_turn", {
      session_id: "custom-rotation-agent",
      model_config: config,
      system_prompt: "You are a terse assistant. Reply in plain text.",
      workspace_directory: workspace,
      workspace_trusted: true,
      termux_workspace_directory: workspace,
      host_tools: [],
      messages: [userMessage("say hi")],
      reasoning: "off",
      runtime: "termux",
      platform: "android",
    });
    console.log("TURN RESULT:", JSON.stringify(result).slice(0, 600));
    console.log("SEEN KEYS:", JSON.stringify(seenKeys));
    assert.ok(
      seenKeys.some((k) => k.includes("fresh-key")),
      `the next key must answer after the quota error (custom agent turn path). seen=${JSON.stringify(seenKeys)}`,
    );
  } finally {
    await client.close();
    server.close();
  }
});

test("custom openai provider rotates on 429 for complete_once (one-shot path)", async (t) => {
  const home = await mkdtemp(join(tmpdir(), "arix-custom-rotation-once-"));
  t.after(() => rm(home, { recursive: true, force: true }));

  const seenKeys = [];
  const server = createServer((request, response) => {
    const chunks = [];
    request.on("data", (chunk) => chunks.push(chunk));
    request.on("end", () => {
      const key = String(request.headers["authorization"] ?? "").replace(/^Bearer\s+/i, "");
      seenKeys.push(key);
      if (key.includes("exhausted-key")) {
        writeOpenAi429(response);
        return;
      }
      writeOpenAiSse(response, "rotated and done");
    });
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  const baseUrl = `http://127.0.0.1:${address.port}/v1`;

  const client = new BridgeClient({ HOME: home, USERPROFILE: home, ARIX_PI_BRIDGE_DEBUG: "1" });
  try {
    const config = {
      provider_type: "custom",
      provider_config_id: "arix-custom-rotation-once-test",
      pi_provider_id: "arix-custom-rotation-once-test",
      pi_api: "openai-completions",
      model_id: "test-model",
      base_url: baseUrl,
      api_key: "exhausted-key",
      api_keys: ["exhausted-key", "fresh-key"],
      reasoning: false,
      max_retries: 0,
      max_provider_retries: 0,
    };
    const result = await client.request("custom-rotation-once", "complete_once", {
      model_config: config,
      system_prompt: "Reply briefly.",
      messages: [userMessage("say hi")],
      reasoning: "off",
    });
    console.log("ONCE RESULT:", JSON.stringify(result).slice(0, 400));
    console.log("SEEN KEYS:", JSON.stringify(seenKeys));
    assert.ok(
      seenKeys.some((k) => k.includes("fresh-key")),
      `the next key must answer after the quota error (complete_once path). seen=${JSON.stringify(seenKeys)}`,
    );
  } finally {
    await client.close();
    server.close();
  }
});

test("custom openai provider: BOTH keys exhausted surfaces the all-keys-exhausted annotation", async (t) => {
  const home = await mkdtemp(join(tmpdir(), "arix-custom-both-"));
  const workspace = join(home, "workspace");
  t.after(() => rm(home, { recursive: true, force: true }));

  const seenKeys = [];
  const server = createServer((request, response) => {
    const chunks = [];
    request.on("data", (chunk) => chunks.push(chunk));
    request.on("end", () => {
      const key = String(request.headers["authorization"] ?? "").replace(/^Bearer\s+/i, "");
      seenKeys.push(key);
      writeOpenAi429(response);
    });
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  const baseUrl = `http://127.0.0.1:${address.port}/v1`;

  const client = new BridgeClient({ HOME: home, USERPROFILE: home, ARIX_PI_BRIDGE_DEBUG: "1" });
  try {
    const config = {
      provider_type: "custom",
      provider_config_id: "arix-custom-both-test",
      pi_provider_id: "arix-custom-both-test",
      pi_api: "openai-completions",
      model_id: "test-model",
      base_url: baseUrl,
      api_key: "exhausted-key",
      api_keys: ["exhausted-key", "fresh-key"],
      reasoning: false,
      max_retries: 0,
      max_provider_retries: 0,
    };
    const result = await client.request("custom-both-turn", "run_turn", {
      session_id: "custom-both-agent",
      model_config: config,
      system_prompt: "You are a terse assistant. Reply in plain text.",
      workspace_directory: workspace,
      workspace_trusted: true,
      termux_workspace_directory: workspace,
      host_tools: [],
      messages: [userMessage("say hi")],
      reasoning: "off",
      runtime: "termux",
      platform: "android",
    });
    console.log("BOTH RESULT:", JSON.stringify(result).slice(0, 800));
    console.log("SEEN KEYS:", JSON.stringify(seenKeys));
    const text = JSON.stringify(result);
    assert.ok(seenKeys.includes("fresh-key"), "the second key must have been tried");
    assert.ok(
      text.includes("all 2 configured API keys are exhausted"),
      `the final error must say all keys were tried. got=${text.slice(0, 400)}`,
    );
  } finally {
    await client.close();
    server.close();
  }
});

test("custom openai provider rotates with the REAL app retry config (max_retries 5, 60s delay)", async (t) => {
  const home = await mkdtemp(join(tmpdir(), "arix-custom-retry-"));
  const workspace = join(home, "workspace");
  t.after(() => rm(home, { recursive: true, force: true }));

  const seenKeys = [];
  const server = createServer((request, response) => {
    const chunks = [];
    request.on("data", (chunk) => chunks.push(chunk));
    request.on("end", () => {
      const key = String(request.headers["authorization"] ?? "").replace(/^Bearer\s+/i, "");
      seenKeys.push(key);
      if (key.includes("exhausted-key")) {
        // 429 with a short retry-after so pi-ai's retry loop is fast.
        response.writeHead(429, {
          "content-type": "application/json",
          "retry-after": "1",
        });
        response.end(
          JSON.stringify({
            error: {
              message: "Rate limit reached: limit: 250000, tokens/minute.",
              type: "rate_limit_error",
              code: "rate_limit_exceeded",
            },
          }),
        );
        return;
      }
      writeOpenAiSse(response, "rotated and done");
    });
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  const baseUrl = `http://127.0.0.1:${address.port}/v1`;

  const client = new BridgeClient({ HOME: home, USERPROFILE: home, ARIX_PI_BRIDGE_DEBUG: "1" });
  try {
    const config = {
      provider_type: "custom",
      provider_config_id: "arix-custom-retry-test",
      pi_provider_id: "arix-custom-retry-test",
      pi_api: "openai-completions",
      model_id: "test-model",
      base_url: baseUrl,
      api_key: "exhausted-key",
      api_keys: ["exhausted-key", "fresh-key"],
      reasoning: false,
      max_retries: 5,
      max_retry_delay_ms: 2_000,
    };
    const result = await client.request("custom-retry-turn", "run_turn", {
      session_id: "custom-retry-agent",
      model_config: config,
      system_prompt: "You are a terse assistant. Reply in plain text.",
      workspace_directory: workspace,
      workspace_trusted: true,
      termux_workspace_directory: workspace,
      host_tools: [],
      messages: [userMessage("say hi")],
      reasoning: "off",
      runtime: "termux",
      platform: "android",
    });
    console.log("RETRY RESULT:", JSON.stringify(result).slice(0, 600));
    console.log("SEEN KEYS:", JSON.stringify(seenKeys));
    assert.ok(
      seenKeys.some((k) => k.includes("fresh-key")),
      `the next key must answer after quota retries exhaust. seen=${JSON.stringify(seenKeys)}`,
    );
  } finally {
    await client.close();
    server.close();
  }
});
