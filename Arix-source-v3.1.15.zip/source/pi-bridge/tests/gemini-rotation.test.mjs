// Gemini (builtin google provider) key-rotation repro test.
// Simulates a real Gemini 429 quota error on the FIRST key and a healthy
// second key, against a mock generativelanguage-style SSE endpoint.
import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import { createServer } from "node:http";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { test } from "node:test";

const activeClients = new Set();

class BridgeClient {
  constructor(environment = {}, bridgePath = "dist/bridge.mjs", cwd = process.cwd()) {
    const { spawn } = require_node();
    this.child = spawn(process.execPath, [bridgePath], {
      cwd,
      stdio: ["pipe", "pipe", "pipe"],
      env: { ...process.env, ...environment },
    });
    this.pending = new Map();
    this.stderr = "";
    const { createInterface } = require_node();
    createInterface({ input: this.child.stdout }).on("line", (line) => {
      if (!line.trim()) return;
      let frame;
      try {
        frame = JSON.parse(line);
      } catch {
        return;
      }
      if (frame.type === "event") return;
      const pending = this.pending.get(frame.id);
      if (!pending) return;
      this.pending.delete(frame.id);
      clearTimeout(pending.timeout);
      if (frame.type === "error" || frame.ok === false) {
        pending.reject(new Error(frame.error?.message || "Pi bridge request failed."));
      } else {
        pending.resolve(frame.payload);
      }
    });
    this.child.stderr.setEncoding("utf8");
    this.child.stderr.on("data", (chunk) => {
      this.stderr += chunk;
    });
    activeClients.add(this);
  }
  request(id, type, payload = {}, timeoutMs = 30_000) {
    this.child.stdin.write(`${JSON.stringify({ id, type, payload })}\n`);
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`Timed out waiting for ${type}: ${this.stderr}`));
      }, timeoutMs);
      this.pending.set(id, { resolve, reject, timeout });
    });
  }
  async close() {
    activeClients.delete(this);
    this.child.kill();
    await new Promise((resolve) => this.child.on("exit", resolve));
  }
}

function require_node() {
  return globalThis.__node_mods;
}
// ESM: load child_process/readline once.
const { spawn } = await import("node:child_process");
const { createInterface } = await import("node:readline");
globalThis.__node_mods = { spawn, createInterface };

function userMessage(text) {
  return { role: "user", content: [{ type: "text", text }] };
}

function writeGeminiSse(response, text) {
  response.writeHead(200, { "content-type": "text/event-stream" });
  const chunk1 = {
    candidates: [{ content: { parts: [{ text }], role: "model" } }],
    modelVersion: "gemini-2.0-flash",
  };
  const chunk2 = {
    candidates: [
      { content: { parts: [], role: "model" }, finishReason: "STOP" },
    ],
    usageMetadata: {
      promptTokenCount: 10,
      candidatesTokenCount: 5,
      totalTokenCount: 15,
    },
    modelVersion: "gemini-2.0-flash",
  };
  response.write(`data: ${JSON.stringify(chunk1)}\n\n`);
  response.write(`data: ${JSON.stringify(chunk2)}\n\n`);
  response.end();
}

test("gemini builtin provider rotates to the next key on 429 quota exhaustion (complete_once)", async (t) => {
  const home = await mkdtemp(join(tmpdir(), "arix-gemini-rotation-"));
  t.after(() => rm(home, { recursive: true, force: true }));

  const seenKeys = [];
  const server = createServer((request, response) => {
    const chunks = [];
    request.on("data", (chunk) => chunks.push(chunk));
    request.on("end", () => {
      const key = String(request.headers["x-goog-api-key"] ?? "");
      seenKeys.push(key);
      if (key.includes("exhausted-key")) {
        // Real Gemini daily/quota exhaustion shape.
        response.writeHead(429, { "content-type": "application/json" });
        response.end(
          JSON.stringify({
            error: {
              code: 429,
              message:
                "Resource has been exhausted (e.g. check quota).",
              status: "RESOURCE_EXHAUSTED",
            },
          }),
        );
        return;
      }
      writeGeminiSse(response, "rotated and done");
    });
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  const baseUrl = `http://127.0.0.1:${address.port}/v1beta`;

  const client = new BridgeClient({ HOME: home, USERPROFILE: home });
  try {
    const config = {
      provider_type: "builtin",
      provider_config_id: "gemini-rotation-test",
      pi_provider_id: "google",
      pi_api: "google-generative-ai",
      model_id: "gemini-2.0-flash",
      base_url: baseUrl,
      api_key: "exhausted-key",
      api_keys: ["exhausted-key", "fresh-key"],
      reasoning: false,
      max_retries: 0,
      max_provider_retries: 0,
    };
    const result = await client.request("gemini-rotation-turn", "complete_once", {
      model_config: config,
      system_prompt: "Reply briefly.",
      messages: [userMessage("say hi")],
      reasoning: "off",
    });
    console.log("RESULT:", JSON.stringify(result).slice(0, 400));
    console.log("SEEN KEYS:", JSON.stringify(seenKeys));
    assert.equal(result.assistant_text, "rotated and done");
    assert.ok(seenKeys.some((k) => k.includes("fresh-key")), "the next key must answer after the quota error");
  } finally {
    await client.close();
    server.close();
  }
});

test("gemini builtin provider rotates to the next key on 429 quota exhaustion (run_turn agent path)", async (t) => {
  const home = await mkdtemp(join(tmpdir(), "arix-gemini-rotation-turn-"));
  const workspace = join(home, "workspace");
  t.after(() => rm(home, { recursive: true, force: true }));

  const seenKeys = [];
  const server = createServer((request, response) => {
    const chunks = [];
    request.on("data", (chunk) => chunks.push(chunk));
    request.on("end", () => {
      const key = String(request.headers["x-goog-api-key"] ?? "");
      seenKeys.push(key);
      if (key.includes("exhausted-key")) {
        response.writeHead(429, { "content-type": "application/json" });
        response.end(
          JSON.stringify({
            error: {
              code: 429,
              message:
                "Resource has been exhausted (e.g. check quota).",
              status: "RESOURCE_EXHAUSTED",
            },
          }),
        );
        return;
      }
      writeGeminiSse(response, "rotated and done");
    });
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  const baseUrl = `http://127.0.0.1:${address.port}/v1beta`;

  const client = new BridgeClient({ HOME: home, USERPROFILE: home, ARIX_PI_BRIDGE_DEBUG: "1" });
  try {
    const config = {
      provider_type: "builtin",
      provider_config_id: "gemini-rotation-turn-test",
      pi_provider_id: "google",
      pi_api: "google-generative-ai",
      model_id: "gemini-2.0-flash",
      base_url: baseUrl,
      api_key: "exhausted-key",
      api_keys: ["exhausted-key", "fresh-key"],
      reasoning: false,
      max_retries: 0,
      max_provider_retries: 0,
    };
    const result = await client.request("gemini-rotation-agent-turn", "run_turn", {
      session_id: "gemini-rotation-agent",
      model_config: config,
      system_prompt: "You are a terse assistant. Reply in plain text.",
      workspace_directory: workspace,
      workspace_trusted: true,
      termux_workspace_directory: workspace,
      host_tools: [],
      messages: [userMessage("say hi")],
      reasoning: "off",
      runtime: "termux",
      platform: "android",
    });
    console.log("TURN RESULT:", JSON.stringify(result).slice(0, 600));
    console.log("SEEN KEYS:", JSON.stringify(seenKeys));
    assert.ok(
      seenKeys.some((k) => k.includes("fresh-key")),
      "the next key must answer after the quota error (agent turn path)",
    );
  } finally {
    await client.close();
    server.close();
  }
});

test("gemini builtin pool exhaustion surfaces a clear final error after trying every key", async (t) => {
  const home = await mkdtemp(join(tmpdir(), "arix-gemini-exhausted-"));
  const workspace = join(home, "workspace");
  t.after(() => rm(home, { recursive: true, force: true }));

  const seenKeys = [];
  const server = createServer((request, response) => {
    const chunks = [];
    request.on("data", (chunk) => chunks.push(chunk));
    request.on("end", () => {
      const key = String(request.headers["x-goog-api-key"] ?? "");
      seenKeys.push(key);
      response.writeHead(429, { "content-type": "application/json" });
      response.end(
        JSON.stringify({
          error: {
            code: 429,
            message: "Resource has been exhausted (e.g. check quota).",
            status: "RESOURCE_EXHAUSTED",
          },
        }),
      );
    });
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  const baseUrl = `http://127.0.0.1:${address.port}/v1beta`;

  const client = new BridgeClient({ HOME: home, USERPROFILE: home });
  try {
    const config = {
      provider_type: "builtin",
      provider_config_id: "gemini-exhausted-test",
      pi_provider_id: "google",
      pi_api: "google-generative-ai",
      model_id: "gemini-2.0-flash",
      base_url: baseUrl,
      api_key: "key-one",
      api_keys: ["key-one", "key-two", "key-three"],
      reasoning: false,
      max_retries: 0,
      max_provider_retries: 0,
    };
    const result = await client.request("gemini-exhausted-turn", "run_turn", {
      session_id: "gemini-exhausted-agent",
      model_config: config,
      system_prompt: "You are a terse assistant. Reply in plain text.",
      workspace_directory: workspace,
      workspace_trusted: true,
      termux_workspace_directory: workspace,
      host_tools: [],
      messages: [userMessage("say hi")],
      reasoning: "off",
      runtime: "termux",
      platform: "android",
    });
    console.log("EXHAUSTED SEEN KEYS:", JSON.stringify(seenKeys));
    console.log(
      "EXHAUSTED ERROR:",
      String(result.assistant_message?.errorMessage ?? result.error_message ?? "").slice(0, 300),
    );
    // Every key was tried, exactly once each (no infinite retry loop).
    assert.deepEqual(
      seenKeys.sort(),
      ["key-one", "key-three", "key-two"],
      "all three keys must be tried once each",
    );
    const errorText = String(result.assistant_message?.errorMessage ?? "");
    assert.ok(
      errorText.includes("all 3 configured API keys are exhausted"),
      `the final error must clearly state the whole pool is exhausted, got: ${errorText}`,
    );
  } finally {
    await client.close();
    server.close();
  }
});
