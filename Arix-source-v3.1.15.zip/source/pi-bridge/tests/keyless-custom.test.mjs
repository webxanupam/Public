// v3.0.94 — KEYLESS custom (OpenAI-compatible) provider test.
//
// The Kilo free gateway (api.kilo.ai) serves its free tier ANONYMOUSLY:
// it rejects invalid bearer tokens but answers requests with NO
// Authorization header. A custom provider configured without an API key
// must therefore send its requests with the Authorization header entirely
// ABSENT (bridge: placeholder key "unused" + `Authorization: null` header,
// which the OpenAI SDK documents as "suppress this default header").
//
// The mock server below enforces exactly that contract: any request that
// carries an Authorization header fails with the INVALID_TOKEN error Kilo
// itself returns; keyless requests get a normal SSE completion.
import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import { createServer } from "node:http";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { test } from "node:test";

const activeClients = new Set();

class BridgeClient {
  constructor(environment = {}, bridgePath = "dist/bridge.mjs", cwd = process.cwd()) {
    const { spawn } = require_node();
    this.child = spawn(process.execPath, [bridgePath], {
      cwd,
      stdio: ["pipe", "pipe", "pipe"],
      env: { ...process.env, ...environment },
    });
    this.pending = new Map();
    this.stderr = "";
    const { createInterface } = require_node();
    createInterface({ input: this.child.stdout }).on("line", (line) => {
      if (!line.trim()) return;
      let frame;
      try {
        frame = JSON.parse(line);
      } catch {
        return;
      }
      if (frame.type === "event") return;
      const pending = this.pending.get(frame.id);
      if (!pending) return;
      this.pending.delete(frame.id);
      clearTimeout(pending.timeout);
      if (frame.type === "error" || frame.ok === false) {
        pending.reject(new Error(frame.error?.message || "Pi bridge request failed."));
      } else {
        pending.resolve(frame.payload);
      }
    });
    this.child.stderr.setEncoding("utf8");
    this.child.stderr.on("data", (chunk) => {
      this.stderr += chunk;
    });
    activeClients.add(this);
  }
  request(id, type, payload = {}, timeoutMs = 30_000) {
    this.child.stdin.write(`${JSON.stringify({ id, type, payload })}\n`);
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`Timed out waiting for ${type}: ${this.stderr}`));
      }, timeoutMs);
      this.pending.set(id, { resolve, reject, timeout });
    });
  }
  async close() {
    activeClients.delete(this);
    this.child.kill();
    await new Promise((resolve) => this.child.on("exit", resolve));
  }
}

function require_node() {
  return globalThis.__node_mods;
}
const { spawn } = await import("node:child_process");
const { createInterface } = await import("node:readline");
globalThis.__node_mods = { spawn, createInterface };

function userMessage(text) {
  return { role: "user", content: [{ type: "text", text }] };
}

// OpenAI-compatible SSE success response.
function writeOpenAiSse(response, text) {
  response.writeHead(200, { "content-type": "text/event-stream" });
  const chunk1 = {
    id: "chatcmpl-1",
    object: "chat.completion.chunk",
    choices: [{ index: 0, delta: { content: text }, finish_reason: null }],
  };
  const chunk2 = {
    id: "chatcmpl-1",
    object: "chat.completion.chunk",
    choices: [{ index: 0, delta: {}, finish_reason: "stop" }],
    usage: { prompt_tokens: 10, completion_tokens: 5, total_tokens: 15 },
  };
  response.write(`data: ${JSON.stringify(chunk1)}\n\n`);
  response.write(`data: ${JSON.stringify(chunk2)}\n\n`);
  response.write("data: [DONE]\n\n");
  response.end();
}

// Kilo's actual anonymous-tier contract: any Authorization header with an
// invalid token is a 401; no header at all = served.
function writeInvalidToken(response) {
  response.writeHead(401, { "content-type": "application/json" });
  response.end(
    JSON.stringify({
      error: {
        code: "INVALID_TOKEN",
        message: "Your authentication token is invalid. Please sign in again.",
      },
      error_type: "authentication_required",
    }),
  );
}

test("keyless custom provider sends NO Authorization header and completes the turn (run_turn agent path)", async (t) => {
  const home = await mkdtemp(join(tmpdir(), "arix-keyless-custom-"));
  const workspace = join(home, "workspace");
  t.after(() => rm(home, { recursive: true, force: true }));

  const seenAuthHeaders = [];
  const server = createServer((request, response) => {
    const chunks = [];
    request.on("data", (chunk) => chunks.push(chunk));
    request.on("end", () => {
      seenAuthHeaders.push(request.headers["authorization"] ?? null);
      if (request.headers["authorization"] !== undefined) {
        writeInvalidToken(response);
        return;
      }
      writeOpenAiSse(response, "keyless and working");
    });
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  const baseUrl = `http://127.0.0.1:${address.port}/v1`;

  const client = new BridgeClient({ HOME: home, USERPROFILE: home, ARIX_PI_BRIDGE_DEBUG: "1" });
  try {
    // Exactly the shape the Kotlin mapper produces for the Kilo provider:
    // provider_type "custom" + openai-completions + NO api key.
    const config = {
      provider_type: "custom",
      provider_config_id: "arix-kilo-keyless-test",
      pi_provider_id: "kilo",
      pi_api: "openai-completions",
      model_id: "kilo-auto/free",
      base_url: baseUrl,
      api_key: "",
      reasoning: false,
      max_retries: 0,
      max_provider_retries: 0,
    };
    const result = await client.request("keyless-agent-turn", "run_turn", {
      session_id: "keyless-agent",
      model_config: config,
      system_prompt: "You are a terse assistant. Reply in plain text.",
      workspace_directory: workspace,
      workspace_trusted: true,
      termux_workspace_directory: workspace,
      host_tools: [],
      messages: [userMessage("say hi")],
      reasoning: "off",
      runtime: "termux",
      platform: "android",
    });
    console.log("TURN RESULT:", JSON.stringify(result).slice(0, 400));
    console.log("SEEN AUTH HEADERS:", JSON.stringify(seenAuthHeaders));
    assert.ok(
      seenAuthHeaders.length > 0,
      "the turn must have reached the mock provider at least once",
    );
    assert.ok(
      seenAuthHeaders.every((header) => header === null),
      `every request must carry NO Authorization header (Kilo anonymous tier). seen=${JSON.stringify(seenAuthHeaders)}`,
    );
    const text = JSON.stringify(result);
    assert.ok(
      text.includes("keyless and working"),
      `the keyless turn must complete with the mock reply. result=${text.slice(0, 400)}`,
    );
  } finally {
    await client.close();
    server.close();
  }
});

test("keyed custom providers keep their Bearer token (no behavior change)", async (t) => {
  const home = await mkdtemp(join(tmpdir(), "arix-keyed-custom-"));
  const workspace = join(home, "workspace");
  t.after(() => rm(home, { recursive: true, force: true }));

  const seenAuthHeaders = [];
  const server = createServer((request, response) => {
    const chunks = [];
    request.on("data", (chunk) => chunks.push(chunk));
    request.on("end", () => {
      seenAuthHeaders.push(request.headers["authorization"] ?? null);
      writeOpenAiSse(response, "keyed and working");
    });
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  const baseUrl = `http://127.0.0.1:${address.port}/v1`;

  const client = new BridgeClient({ HOME: home, USERPROFILE: home, ARIX_PI_BRIDGE_DEBUG: "1" });
  try {
    const config = {
      provider_type: "custom",
      provider_config_id: "arix-keyed-custom-test",
      pi_provider_id: "arix-keyed-custom-test",
      pi_api: "openai-completions",
      model_id: "test-model",
      base_url: baseUrl,
      api_key: "real-key",
      reasoning: false,
      max_retries: 0,
      max_provider_retries: 0,
    };
    const result = await client.request("keyed-agent-turn", "run_turn", {
      session_id: "keyed-agent",
      model_config: config,
      system_prompt: "You are a terse assistant. Reply in plain text.",
      workspace_directory: workspace,
      workspace_trusted: true,
      termux_workspace_directory: workspace,
      host_tools: [],
      messages: [userMessage("say hi")],
      reasoning: "off",
      runtime: "termux",
      platform: "android",
    });
    const text = JSON.stringify(result);
    assert.ok(
      seenAuthHeaders.some((header) => header === "Bearer real-key"),
      `a keyed provider must still send its Bearer token. seen=${JSON.stringify(seenAuthHeaders)}`,
    );
    assert.ok(
      text.includes("keyed and working"),
      `the keyed turn must complete with the mock reply.`,
    );
  } finally {
    await client.close();
    server.close();
  }
});
