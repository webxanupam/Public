import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { copyFile, mkdtemp, mkdir, readFile, rm, writeFile } from "node:fs/promises";
import { createServer } from "node:http";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createInterface } from "node:readline";
import { afterEach, test } from "node:test";
import {
  createBashToolDefinition,
  createEditToolDefinition,
  createFindToolDefinition,
  createGrepToolDefinition,
  createLsToolDefinition,
  createReadToolDefinition,
  createWriteToolDefinition,
} from "@earendil-works/pi-coding-agent";

const activeClients = new Set();

class BridgeClient {
  constructor(environment = {}, bridgePath = "dist/bridge.mjs", cwd = process.cwd()) {
    this.child = spawn(process.execPath, [bridgePath], {
      cwd,
      stdio: ["pipe", "pipe", "pipe"],
      env: { ...process.env, ...environment },
    });
    this.pending = new Map();
    this.events = [];
    this.eventWaiters = [];
    this.stderr = "";
    createInterface({ input: this.child.stdout }).on("line", (line) => {
      if (!line.trim()) return;
      let frame;
      try {
        frame = JSON.parse(line);
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        this.failHarness(
          new Error(
            `Pi bridge emitted non-JSON stdout: ${message}${this.stderr ? `\nstderr: ${this.stderr}` : ""}`,
          ),
        );
        return;
      }
      if (frame.type === "event") {
        this.events.push(frame);
        const remaining = [];
        for (const waiter of this.eventWaiters) {
          if (waiter.predicate(frame)) {
            clearTimeout(waiter.timeout);
            waiter.resolve(frame);
          } else {
            remaining.push(waiter);
          }
        }
        this.eventWaiters = remaining;
        return;
      }
      const pending = this.pending.get(frame.id);
      if (!pending) return;
      this.pending.delete(frame.id);
      clearTimeout(pending.timeout);
      if (frame.type === "error" || frame.ok === false) {
        pending.reject(new Error(frame.error?.message || "Pi bridge request failed."));
      } else {
        pending.resolve(frame.payload);
      }
    });
    this.child.stderr.setEncoding("utf8");
    this.child.stderr.on("data", (chunk) => {
      this.stderr += chunk;
    });
    activeClients.add(this);
  }

  failHarness(error) {
    for (const pending of this.pending.values()) {
      clearTimeout(pending.timeout);
      pending.reject(error);
    }
    this.pending.clear();
    for (const waiter of this.eventWaiters) {
      clearTimeout(waiter.timeout);
      waiter.reject(error);
    }
    this.eventWaiters = [];
  }

  request(id, type, payload = {}, timeoutMs = 10_000) {
    this.child.stdin.write(`${JSON.stringify({ id, type, payload })}\n`);
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`Timed out waiting for ${type}: ${this.stderr}`));
      }, timeoutMs);
      this.pending.set(id, { resolve, reject, timeout });
    });
  }

  send(id, type, payload = {}) {
    this.child.stdin.write(`${JSON.stringify({ id, type, payload })}\n`);
  }

  waitForEvent(predicate, timeoutMs = 5_000) {
    const existing = this.events.find(predicate);
    if (existing) return Promise.resolve(existing);
    return new Promise((resolve, reject) => {
      const waiter = {
        predicate,
        resolve,
        reject,
        timeout: setTimeout(() => {
          this.eventWaiters = this.eventWaiters.filter((candidate) => candidate !== waiter);
          reject(new Error(`Timed out waiting for Pi event: ${this.stderr}`));
        }, timeoutMs),
      };
      this.eventWaiters.push(waiter);
    });
  }

  async close() {
    activeClients.delete(this);
    for (const pending of this.pending.values()) {
      clearTimeout(pending.timeout);
      pending.reject(new Error("Pi bridge test client closed."));
    }
    this.pending.clear();
    this.child.stdin.end();
    if (!this.child.killed) this.child.kill();
  }
}

afterEach(async () => {
  await Promise.all([...activeClients].map((client) => client.close()));
});

test("lists Pi-discovered project skills without Aether managed copies", async () => {
  const root = await mkdtemp(join(tmpdir(), "aether-skills-"));
  const workspace = join(root, "workspace");
  const agentDir = join(root, "agent");
  const projectSkill = join(workspace, ".agents", "skills", "review");
  const managedSkill = join(workspace, ".arix", "skills", "managed");
  await mkdir(projectSkill, { recursive: true });
  await mkdir(managedSkill, { recursive: true });
  await mkdir(agentDir, { recursive: true });
  await writeFile(
    join(projectSkill, "SKILL.md"),
    "---\nname: review\ndescription: Reviews code changes\n---\n",
  );
  await writeFile(
    join(managedSkill, "SKILL.md"),
    "---\nname: managed\ndescription: Already managed by Aether\n---\n",
  );
  const client = new BridgeClient({ HOME: root });
  try {
    const payload = await client.request("skills-1", "list_discovered_skills", {
      workspace_directory: workspace,
      agent_directory: agentDir,
      workspace_trusted: true,
    });
    assert.deepEqual(payload.skills.map((skill) => skill.name), ["review"]);
    assert.equal(payload.skills[0].file_path, join(projectSkill, "SKILL.md"));
  } finally {
    await client.close();
    await rm(root, { recursive: true, force: true });
  }
});

function fauxConfig(overrides = {}) {
  return {
    provider_type: "faux",
    provider_config_id: "faux",
    pi_provider_id: "faux",
    pi_api: "faux",
    model_id: "faux-1",
    base_url: "http://localhost:0",
    reasoning: false,
    faux_response: "done",
    ...overrides,
  };
}

test("service tier reaches Chat Completions bodies and is omitted when blank", async (t) => {
  const bodies = [];
  const server = createServer((request, response) => {
    const chunks = [];
    request.on("data", (chunk) => chunks.push(chunk));
    request.on("end", () => {
      bodies.push(JSON.parse(Buffer.concat(chunks).toString("utf8")));
      writeSuccessfulChatCompletion(response, "TIER_OK", "tier-model");
    });
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  t.after(() => new Promise((resolve) => server.close(resolve)));
  const client = new BridgeClient();
  for (const tier of [undefined, "  ", " fast ", "ultrafast", "priority"]) {
    const result = await client.request(`tier-${tier}`, "complete_once", {
      model_config: {
        provider_type: "openai_compatible", provider_config_id: "tier-test",
        pi_provider_id: "arix-tier", pi_api: "openai-completions",
        model_id: "tier-model", base_url: `http://127.0.0.1:${server.address().port}/v1`,
        api_key: "test", service_tier: tier, compatibility_mode: true, max_retries: 0,
      },
      messages: [userMessage("hello")],
    });
    assert.equal(result.assistant_text, "TIER_OK", JSON.stringify(result));
    assert.equal(bodies.at(-1).service_tier, tier?.trim() || undefined);
    if (!tier?.trim()) assert.equal(Object.hasOwn(bodies.at(-1), "service_tier"), false);
  }
});

function turnPayload(sessionId, messages, config = fauxConfig(), hostTools = []) {
  return {
    session_id: sessionId,
    model_config: config,
    system_prompt: "Use the supplied tools when needed.",
    workspace_directory: process.cwd(),
    messages,
    host_tools: hostTools,
    reasoning: "off",
  };
}

function userMessage(text) {
  return { role: "user", content: [{ type: "text", text }] };
}

function writeSuccessfulChatCompletion(response, content, model) {
  response.writeHead(200, { "content-type": "text/event-stream" });
  response.write(`data: ${JSON.stringify({
    id: `chatcmpl-${model}`,
    object: "chat.completion.chunk",
    created: 1,
    model,
    choices: [{
      index: 0,
      delta: { role: "assistant", content },
      finish_reason: null,
    }],
  })}\n\n`);
  response.write(`data: ${JSON.stringify({
    id: `chatcmpl-${model}`,
    object: "chat.completion.chunk",
    created: 1,
    model,
    choices: [{ index: 0, delta: {}, finish_reason: "stop" }],
    usage: { prompt_tokens: 4, completion_tokens: 2, total_tokens: 6 },
  })}\n\n`);
  response.end("data: [DONE]\n\n");
}

function hostTool(name, executionMode = "parallel") {
  return {
    name,
    description: `Run ${name}.`,
    parameters: {
      type: "object",
      properties: {
        value: { type: "string" },
        optional_note: { type: "string" },
      },
      required: ["value"],
      additionalProperties: false,
    },
    execution_mode: executionMode,
  };
}

async function respondToHostTool(client, frame, id) {
  return client.request(id, "host_tool_result", {
    session_id: frame.payload.session_id,
    tool_request_id: frame.payload.tool_request_id,
    tool_call_id: frame.payload.tool_call_id,
    tool_name: frame.payload.tool_name,
    arguments_json: frame.payload.arguments_json,
    output_json: JSON.stringify({ ok: true, stdout: frame.payload.tool_name }),
    raw_output_json: JSON.stringify({ ok: true, stdout: frame.payload.tool_name }),
    is_error: false,
    content: [{ type: "text", text: JSON.stringify({ ok: true }) }],
  });
}

const RESPONSES_TEST_TURN_COUNT = 3;
const RESPONSES_TEST_PROMPT = "x".repeat(60_000);

function openAIResponseEvents(responseNumber) {
  const text = `answer-${responseNumber}`;
  const messageId = `msg_${responseNumber}`;
  return [
    {
      type: "response.output_item.added",
      item: {
        type: "message",
        id: messageId,
        role: "assistant",
        status: "in_progress",
        content: [],
      },
    },
    { type: "response.content_part.added", part: { type: "output_text", text: "" } },
    { type: "response.output_text.delta", delta: text },
    {
      type: "response.output_item.done",
      item: {
        type: "message",
        id: messageId,
        role: "assistant",
        status: "completed",
        content: [{ type: "output_text", text }],
      },
    },
    {
      type: "response.completed",
      response: {
        id: `resp_${responseNumber}`,
        status: "completed",
        usage: {
          input_tokens: 5,
          output_tokens: 3,
          input_tokens_details: { cached_tokens: 0 },
          output_tokens_details: { reasoning_tokens: 0 },
        },
      },
    },
  ];
}

async function createOpenAIResponsesServer() {
  const requests = [];
  let responseCount = 0;
  const server = createServer((request, response) => {
    const chunks = [];
    request.on("data", (chunk) => chunks.push(chunk));
    request.on("end", () => {
      const body = JSON.parse(Buffer.concat(chunks).toString("utf8"));
      requests.push({ url: request.url, body });
      responseCount += 1;
      response.writeHead(200, { "content-type": "text/event-stream" });
      for (const event of openAIResponseEvents(responseCount)) {
        response.write(`data: ${JSON.stringify(event)}\n\n`);
      }
      response.end("data: [DONE]\n\n");
    });
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  assert.ok(address && typeof address === "object");
  return {
    requests,
    baseUrl: `http://127.0.0.1:${address.port}/v1`,
    close: () => new Promise((resolve) => server.close(resolve)),
  };
}

function openAIFetchRedirectEnvironment(targetBaseUrl) {
  const preloadSource = `
const targetOrigin = process.env.AETHER_TEST_OPENAI_REDIRECT_ORIGIN;
if (!targetOrigin) throw new Error("AETHER_TEST_OPENAI_REDIRECT_ORIGIN is required.");
const originalFetch = globalThis.fetch;
globalThis.fetch = (input, init) => {
  const rawUrl = typeof input === "string" || input instanceof URL ? String(input) : input.url;
  const url = new URL(rawUrl);
  if (url.hostname !== "api.openai.com") return originalFetch(input, init);
  return originalFetch(new URL(url.pathname + url.search, targetOrigin), init);
};
`;
  const preloadSpecifier = `data:text/javascript,${encodeURIComponent(preloadSource)}`;
  return {
    AETHER_TEST_OPENAI_REDIRECT_ORIGIN: new URL(targetBaseUrl).origin,
    NODE_OPTIONS: `${process.env.NODE_OPTIONS ?? ""} --import=${preloadSpecifier}`.trim(),
  };
}

function openAIResponsesModelConfig(baseUrl, overrides = {}) {
  return {
    provider_type: "builtin",
    provider_config_id: "responses-test",
    pi_provider_id: "openai",
    pi_api: "builtin",
    model_id: "gpt-5.6-sol",
    base_url: baseUrl,
    api_key: "secret-key",
    reasoning: true,
    context_window: 128_000,
    max_tokens: 16_384,
    max_retries: 0,
    ...overrides,
  };
}

async function runResponsesTurns(client, sessionId, modelConfig, sessionDirectory) {
  for (let turn = 1; turn <= RESPONSES_TEST_TURN_COUNT; turn += 1) {
    await client.request(
      `${sessionId}-turn-${turn}`,
      "run_turn",
      {
        ...turnPayload(
          sessionId,
          [userMessage(`turn ${turn}: ${RESPONSES_TEST_PROMPT}`)],
          modelConfig,
        ),
        workspace_directory: sessionDirectory,
        session_directory: sessionDirectory,
        max_retries: 0,
      },
      20_000,
    );
  }
}

test("reports pinned bridge and Pi versions", async () => {
  const client = new BridgeClient();
  const ping = await client.request("ping-1", "ping");

  assert.equal(ping.bridge_version, "2.0.0-alpha.0");
  assert.equal(ping.pi_ai_version, "0.99.2");
  assert.equal(ping.pi_agent_core_version, "0.99.2");
  assert.equal(ping.pi_coding_agent_version, "0.99.2");
  assert.match(ping.node_version, /^v\d+\./);
});

test("v3.0.86 reports whole-turn usage totals with cache tokens and generation time", async () => {
  const client = new BridgeClient();
  const result = await client.request("usage-turn", "run_turn", {
    ...turnPayload("session-usage", [userMessage("hello")]),
  });
  assert.equal(result.assistant_text, "done");
  // pi 0.99.2's faux provider synthesizes usage per API call (input/output
  // token estimates, cache read/write from the session prompt cache); the
  // bridge accumulates it and reports the WHOLE-TURN total with the
  // fields single-call usage cannot express (request_count, active
  // generation time).
  assert.equal(result.usage.request_count, 1);
  for (const key of ["input_tokens", "output_tokens", "total_tokens", "cached_input_tokens", "cache_write_tokens"]) {
    assert.equal(typeof result.usage[key], "number", `${key} is reported`);
  }
  assert.equal(
    result.usage.total_tokens,
    result.usage.input_tokens + result.usage.output_tokens +
      result.usage.cached_input_tokens + result.usage.cache_write_tokens,
  );
  assert.equal(result.usage.output_duration_ms >= 0, true);
  // First call of a session: the full prompt is a cache WRITE, nothing read.
  assert.equal(result.usage.cached_input_tokens, 0);
  assert.equal(result.usage.cache_write_tokens > 0, true);
});

test("v3.0.86 deferred follow-ups accumulate usage into the reported turn", async () => {
  const client = new BridgeClient();
  const first = await client.request("usage-deferred-turn", "run_turn", {
    ...turnPayload("session-usage-deferred", [userMessage("hello")]),
  });
  assert.equal(first.usage.request_count, 1);

  // An injected message delivered to an IDLE session continues the turn
  // that was already reported: its usage accumulates instead of restarting
  // (the bridge's deferred follow-up path keeps the totals running).
  const followUp = await client.request("usage-deferred-follow-up", "follow_up", {
    session_id: "session-usage-deferred",
    message: userMessage("and one more thing"),
  });
  assert.equal(followUp.assistant_text, "done");
  assert.equal(followUp.usage.request_count, 2);
  // The follow-up re-sends the cached conversation prefix: part of the
  // prompt becomes a cache READ instead of a fresh cache write.
  assert.equal(followUp.usage.cached_input_tokens > 0, true);
  assert.equal(followUp.usage.input_tokens > 0, true);
  assert.equal(
    followUp.usage.total_tokens,
    followUp.usage.input_tokens + followUp.usage.output_tokens +
      followUp.usage.cached_input_tokens + followUp.usage.cache_write_tokens,
  );
  assert.equal(followUp.usage.output_duration_ms >= 0, true);
});

test("runs text turns and reuses the persisted Pi assistant session", async () => {
  const client = new BridgeClient();
  const config = fauxConfig({ faux_response: "first answer" });
  const first = await client.request(
    "turn-1",
    "run_turn",
    turnPayload("session-persist", [userMessage("hello")], config),
  );
  assert.equal(first.assistant_text, "first answer");
  assert.equal(first.session_reused, false);

  const second = await client.request(
    "turn-2",
    "run_turn",
    turnPayload(
      "session-persist",
      [
        userMessage("hello"),
        {
          role: "assistant",
          content: [{ type: "text", text: first.assistant_text }],
          provider_payload: {
            piAssistantMessage: first.assistant_message,
            provider: first.provider,
            model: first.model,
          },
        },
        userMessage("continue"),
      ],
      config,
    ),
  );
  assert.equal(second.session_reused, true);
  assert.equal(second.assistant_text, "first answer");
});

test("closes AgentSession instances explicitly", async () => {
  const client = new BridgeClient();
  await client.request(
    "close-create",
    "run_turn",
    turnPayload("session-close", [userMessage("hello")]),
  );

  const closed = await client.request("close-session", "close_session", {
    session_id: "session-close",
  });
  assert.equal(closed.closed, true);
  await assert.rejects(
    client.request("close-follow-up", "follow_up", {
      session_id: "session-close",
      message: userMessage("still there?"),
    }),
    /Unknown Pi session/,
  );
});

test("rehydrates a persisted AgentSession before navigation", async (t) => {
  const home = await mkdtemp(join(tmpdir(), "aether-session-rehydrate-"));
  t.after(() => rm(home, { recursive: true, force: true }));
  const client = new BridgeClient({ HOME: home, USERPROFILE: home });
  const config = fauxConfig();
  const first = await client.request(
    "rehydrate-create",
    "run_turn",
    turnPayload("session-rehydrate", [userMessage("hello")], config),
  );
  await client.request("rehydrate-close", "close_session", {
    session_id: "session-rehydrate",
  });

  const navigation = await client.request("rehydrate-navigate", "navigate_session", {
    session_id: "session-rehydrate",
    entry_id: first.session_leaf_id,
    model_config: config,
    workspace_directory: process.cwd(),
    workspace_trusted: true,
  });

  assert.equal(navigation.session_id, "session-rehydrate");
  assert.equal(navigation.session_leaf_id, first.session_leaf_id);
});

test("imports validated Pi JSONL into a relocated session file", async (t) => {
  const home = await mkdtemp(join(tmpdir(), "aether-jsonl-import-"));
  t.after(() => rm(home, { recursive: true, force: true }));
  const client = new BridgeClient({ HOME: home, USERPROFILE: home });
  await client.request("jsonl-create", "run_turn", turnPayload("session-jsonl", [userMessage("hello")]));
  const exported = await client.request("jsonl-export", "export_session_jsonl", {
    session_id: "session-jsonl",
  });
  const jsonl = await readFile(exported.exported_path, "utf8");
  await client.request("jsonl-close", "close_session", {
    session_id: "session-jsonl",
    session_file: exported.exported_path,
    delete_file: true,
  });
  const imported = await client.request("jsonl-import", "import_session_jsonl", {
    session_id: "session-jsonl",
    jsonl,
  });
  assert.equal(imported.imported, true);
  assert.match(imported.session_file, /_session-jsonl\.jsonl$/);
  await assert.rejects(
    client.request("jsonl-invalid", "import_session_jsonl", {
      session_id: "other-session",
      jsonl,
    }),
    /header\/session id mismatch/,
  );
});

test("uses Pi Coding Agent native tool schemas and platform runtime sets", async (t) => {
  const home = await mkdtemp(join(tmpdir(), "aether-native-tools-"));
  const workspace = join(home, "primary-workspace");
  const termuxWorkspace = join(home, "termux-workspace");
  await Promise.all([mkdir(workspace), mkdir(termuxWorkspace)]);
  t.after(() => rm(home, { recursive: true, force: true }));
  const client = new BridgeClient({ HOME: home, USERPROFILE: home });

  const cases = [
    ["android-local", "android", "termux", ["read", "bash", "edit", "write", "grep", "find", "ls"]],
    ["android-termux", "android", "termux", ["read", "bash", "edit", "write", "grep", "find", "ls"]],
    ["ios-termux", "ios", "termux", ["read", "bash", "edit", "write", "grep", "find", "ls"]],
  ];
  for (const [sessionId, platform, runtime, expectedTools] of cases) {
    await client.request(`${sessionId}-turn`, "run_turn", {
      ...turnPayload(sessionId, [userMessage("hello")]),
      platform,
      runtime,
      workspace_directory: workspace,
      termux_workspace_directory: termuxWorkspace,
    });
    const state = await client.request(`${sessionId}-state`, "get_session_state", {
      session_id: sessionId,
    });
    assert.deepEqual(state.active_tools, expectedTools);
  }

  const state = await client.request("android-local-schemas", "get_session_state", {
    session_id: "android-local",
  });
  const actualByName = Object.fromEntries(state.tools.map((tool) => [tool.name, tool.parameters]));
  const expectedDefinitions = [
    createReadToolDefinition(workspace),
    createBashToolDefinition(workspace),
    createEditToolDefinition(workspace),
    createWriteToolDefinition(workspace),
    createGrepToolDefinition(workspace),
    createFindToolDefinition(workspace),
    createLsToolDefinition(workspace),
  ];
  for (const definition of expectedDefinitions) {
    assert.deepEqual(actualByName[definition.name], definition.parameters);
  }
  assert.equal(actualByName.read.properties.offset.description.includes("1-indexed"), true);
  assert.equal("working_directory" in actualByName.bash.properties, false);
  assert.equal("environment" in actualByName.bash.properties, false);
});

test("allows only Aether-owned host tools", async (t) => {
  const home = await mkdtemp(join(tmpdir(), "aether-host-tools-"));
  t.after(() => rm(home, { recursive: true, force: true }));
  const client = new BridgeClient({ HOME: home, USERPROFILE: home });
  const sharedNames = [
    "arix_config_get",
    "arix_config_set",
    "arix_skill_manage",
    "arix_developer_manage",
  ];
  // v2.9.7: the built-in WebView `browser` tool is back — Android only
  // (the iOS host tool filter still excludes it).
  const androidOnlyNames = ["browser"];
  const removedNames = [
    "analyze_image",
    "activate_skill",
    "read_skill_resource",
    "fetch_web_url",
    "tavily_search",
    "mcp_call_tool",
    "aether_mcp_manage",
    "arix_extension_manage",
  ];
  const requested = [...sharedNames, ...androidOnlyNames, ...removedNames].map((name) => hostTool(name));

  await client.request("android-host-turn", "run_turn", {
    ...turnPayload("android-host", [userMessage("hello")], fauxConfig(), requested),
    platform: "android",
  });
  const android = await client.request("android-host-state", "get_session_state", {
    session_id: "android-host",
  });
  assert.deepEqual(sharedNames.filter((name) => android.active_tools.includes(name)), sharedNames);
  assert.deepEqual(
    androidOnlyNames.filter((name) => android.active_tools.includes(name)),
    androidOnlyNames,
  );
  assert.deepEqual(removedNames.filter((name) => android.active_tools.includes(name)), []);

  await client.request("ios-host-turn", "run_turn", {
    ...turnPayload("ios-host", [userMessage("hello")], fauxConfig(), requested),
    platform: "ios",
  });
  const ios = await client.request("ios-host-state", "get_session_state", {
    session_id: "ios-host",
  });
  assert.deepEqual(sharedNames.filter((name) => ios.active_tools.includes(name)), sharedNames);
  assert.deepEqual(androidOnlyNames.filter((name) => ios.active_tools.includes(name)), []);
  assert.deepEqual(removedNames.filter((name) => ios.active_tools.includes(name)), []);
});

test("accepts steer and follow-up messages on a live persistent harness", async () => {
  const client = new BridgeClient();
  const config = fauxConfig({
    faux_response: "working response with enough tokens to keep the stream active briefly",
    faux_tokens_per_second: 12,
  });
  const run = client.request(
    "steer-turn",
    "run_turn",
    turnPayload("session-steer", [userMessage("start")], config),
    15_000,
  );

  let steer;
  for (let attempt = 0; attempt < 30; attempt += 1) {
    steer = await client.request(`steer-${attempt}`, "steer", {
      session_id: "session-steer",
      message: userMessage("include this too"),
    });
    if (steer.accepted) break;
    await new Promise((resolve) => setTimeout(resolve, 20));
  }
  assert.equal(steer?.accepted, true);
  const steeredResult = await run;
  assert.equal(steeredResult.assistant_text.includes("working response"), true);

  const followUp = await client.request(
    "follow-up",
    "follow_up",
    {
      session_id: "session-steer",
      message: userMessage("one more question"),
    },
    15_000,
  );
  assert.equal(followUp.assistant_text.includes("working response"), true);
});

test("aborts an active harness by session id", async () => {
  const client = new BridgeClient();
  const config = fauxConfig({
    faux_response: Array.from({ length: 80 }, () => "slow").join(" "),
    faux_tokens_per_second: 1,
  });
  const run = client.request(
    "abort-turn",
    "run_turn",
    turnPayload("session-abort", [userMessage("start slowly")], config),
    15_000,
  );

  let abortResult;
  for (let attempt = 0; attempt < 30; attempt += 1) {
    abortResult = await client.request(`abort-${attempt}`, "abort", {
      session_id: "session-abort",
    });
    if (abortResult.aborted) break;
    await new Promise((resolve) => setTimeout(resolve, 20));
  }
  assert.equal(abortResult?.aborted, true);
  void run.catch(() => {});
});

test("reconnects a failed provider stream without restarting the harness turn", async (t) => {
  let requestCount = 0;
  const server = createServer((request, response) => {
    request.resume();
    request.on("end", () => {
      requestCount += 1;
      response.writeHead(200, { "content-type": "text/event-stream" });
      const content = requestCount === 1 ? "STALE" : "RECOVERED";
      response.write(
        `data: ${JSON.stringify({
          id: `chatcmpl-retry-${requestCount}`,
          object: "chat.completion.chunk",
          created: 1,
          model: "retry-model",
          choices: [
            {
              index: 0,
              delta: { role: "assistant", content },
              finish_reason: null,
            },
          ],
        })}\n\n`,
      );
      if (requestCount === 1) {
        response.end();
        return;
      }
      response.write(
        `data: ${JSON.stringify({
          id: `chatcmpl-retry-${requestCount}`,
          object: "chat.completion.chunk",
          created: 1,
          model: "retry-model",
          choices: [{ index: 0, delta: {}, finish_reason: "stop" }],
        })}\n\n`,
      );
      response.end("data: [DONE]\n\n");
    });
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  t.after(() => new Promise((resolve) => server.close(resolve)));
  const address = server.address();
  assert.ok(address && typeof address === "object");

  const client = new BridgeClient();
  const result = await client.request(
    "provider-reconnect",
    "run_turn",
    turnPayload(
      "session-provider-reconnect",
      [userMessage("retry this request")],
      {
        provider_type: "openai_compatible",
        provider_config_id: "provider-reconnect",
        pi_provider_id: "aether-retry-test",
        pi_api: "openai-completions",
        model_id: "retry-model",
        base_url: `http://127.0.0.1:${address.port}/v1`,
        api_key: "secret-key",
        reasoning: false,
        max_retries: 2,
        max_retry_delay_ms: 1,
      },
    ),
  );

  assert.equal(requestCount, 2);
  assert.equal(result.assistant_text, "RECOVERED", JSON.stringify(result));
  assert.deepEqual(
    client.events
      .filter(
        (frame) =>
          frame.id === "provider-reconnect" &&
          ["assistant_text_delta", "assistant_stream_reset", "assistant_retry"].includes(
            frame.event,
          ),
      )
      .map((frame) => frame.event),
    ["assistant_text_delta", "assistant_stream_reset", "assistant_retry", "assistant_text_delta"],
  );
});

test("reports Pi AgentSession retry errors", async () => {
  // v3.0.32 — this test previously waited for assistant_retry with a
  // connection-REFUSED provider host and no provider-retry budget, so it
  // raced pi-ai's retryProviderRequest (network errors are retryable and
  // default to 6 attempts with 0.5s→8s exponential backoff ≈ 23s of
  // silence) and always timed out at the 5s event wait — verified failing
  // identically on the pristine v3.0.31 tree. The product retry semantics
  // (v2.9.12: provider retries survive transient 429/5xx/network errors)
  // are intentional and stay untouched; this test now pins the contract
  // the app actually depends on: a provider network failure with retries
  // disabled surfaces a clean assistant_error with a non-empty message.
  // (Top-level max_retries is the PROVIDER budget for the turn's stream
  // options; model_config.max_retries is the AGENT retry budget.)
  const unavailable = createServer();
  await new Promise((resolve) => unavailable.listen(0, "127.0.0.1", resolve));
  const address = unavailable.address();
  assert.ok(address && typeof address === "object");
  await new Promise((resolve) => unavailable.close(resolve));

  const client = new BridgeClient();
  const run = client.request(
    "provider-network-detail",
    "run_turn",
    {
      ...turnPayload(
        "session-provider-network-detail",
        [userMessage("show the network failure")],
        {
          provider_type: "openai_compatible",
          provider_config_id: "provider-network-detail",
          pi_provider_id: "aether-network-detail-test",
          pi_api: "openai-completions",
          model_id: "network-detail-model",
          base_url: `http://127.0.0.1:${address.port}/v1`,
          api_key: "secret-key",
          reasoning: false,
          max_retries: 0,
          max_retry_delay_ms: 1,
        },
      ),
      max_retries: 0,
      provider_max_retries: 0,
    },
  );
  const failure = await run;

  // v3.0.32 — in the native agent-turn flow the model request failure is
  // reported through the run_turn RESPONSE (stop_reason "error" +
  // error_message), which is what the app reads to surface provider
  // failures; no assistant_error/assistant_retry events fire when every
  // retry budget is 0.
  assert.equal(failure.stop_reason, "error");
  assert.equal(typeof failure.error_message, "string");
  assert.notEqual(failure.error_message.trim(), "");
});

test("maps a custom OpenAI-compatible provider through Pi", async (t) => {
  let receivedRequest;
  const server = createServer((request, response) => {
    const chunks = [];
    request.on("data", (chunk) => chunks.push(chunk));
    request.on("end", () => {
      receivedRequest = {
        url: request.url,
        authorization: request.headers.authorization,
        customHeader: request.headers["x-aether-test"],
        body: JSON.parse(Buffer.concat(chunks).toString("utf8")),
      };
      response.writeHead(200, { "content-type": "text/event-stream" });
      response.write(
        `data: ${JSON.stringify({
          id: "chatcmpl-pi-test",
          object: "chat.completion.chunk",
          created: 1,
          model: "custom-model",
          choices: [
            {
              index: 0,
              delta: { role: "assistant", content: "CUSTOM_OK" },
              finish_reason: null,
            },
          ],
        })}\n\n`,
      );
      response.write(
        `data: ${JSON.stringify({
          id: "chatcmpl-pi-test",
          object: "chat.completion.chunk",
          created: 1,
          model: "custom-model",
          choices: [{ index: 0, delta: {}, finish_reason: "stop" }],
          usage: {
            prompt_tokens: 4,
            completion_tokens: 2,
            total_tokens: 6,
          },
        })}\n\n`,
      );
      response.end("data: [DONE]\n\n");
    });
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  t.after(() => new Promise((resolve) => server.close(resolve)));
  const address = server.address();
  assert.ok(address && typeof address === "object");

  const client = new BridgeClient();
  const result = await client.request(
    "custom-completion",
    "complete_once",
    {
      model_config: {
        provider_type: "openai_compatible",
        provider_config_id: "custom-completion",
        pi_provider_id: "aether-test",
        pi_api: "openai-completions",
        model_id: "custom-model",
        base_url: `http://127.0.0.1:${address.port}/v1`,
        api_key: "secret-key",
        custom_headers: { "X-Aether-Test": "present" },
        reasoning: false,
      },
      system_prompt: "Reply briefly.",
      messages: [userMessage("hello")],
      stream: false,
    },
  );

  assert.equal(result.assistant_text, "CUSTOM_OK", JSON.stringify(result));
  assert.equal(receivedRequest.url, "/v1/chat/completions");
  assert.equal(receivedRequest.authorization, "Bearer secret-key");
  assert.equal(receivedRequest.customHeader, "present");
  assert.equal(receivedRequest.body.model, "custom-model");
});

test("falls back from developer to system only for a structured role rejection", async (t) => {
  const receivedRoles = [];
  const server = createServer((request, response) => {
    const chunks = [];
    request.on("data", (chunk) => chunks.push(chunk));
    request.on("end", () => {
      const body = JSON.parse(Buffer.concat(chunks).toString("utf8"));
      const role = body.messages?.[0]?.role;
      receivedRoles.push(role);
      if (role === "developer") {
        response.writeHead(400, { "content-type": "application/json" });
        response.end(JSON.stringify({
          detail: [{
            type: "literal_error",
            loc: ["body", "messages", 0, "role"],
            msg: "Input should be 'system', 'user', 'assistant' or 'tool'",
            input: "developer",
          }],
        }));
        return;
      }
      writeSuccessfulChatCompletion(response, "FALLBACK_OK", "fallback-model");
    });
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  t.after(() => new Promise((resolve) => server.close(resolve)));
  const address = server.address();
  assert.ok(address && typeof address === "object");

  const client = new BridgeClient();
  const result = await client.request("developer-fallback", "complete_once", {
    model_config: {
      provider_type: "openai_compatible",
      provider_config_id: "developer-fallback",
      pi_provider_id: "aether-developer-fallback",
      pi_api: "openai-completions",
      model_id: "fallback-model",
      base_url: `http://127.0.0.1:${address.port}/v1`,
      api_key: "secret-key",
      reasoning: true,
      max_retries: 0,
    },
    system_prompt: "Reply briefly.",
    messages: [userMessage("hello")],
    reasoning: "low",
  });

  assert.equal(result.assistant_text, "FALLBACK_OK", JSON.stringify(result));
  assert.equal(result.developer_role_unsupported_detected, true);
  assert.deepEqual(receivedRoles, ["developer", "system"]);
});

test("recognizes explicit developer-role rejections across provider error formats", async (t) => {
  const cases = [
    {
      model: "unsupported-value-model",
      error: {
        error: {
          message: "Unsupported value 'developer' for messages[0].role.",
          code: "unsupported_value",
          param: "messages[0].role",
        },
      },
    },
    {
      model: "developer-message-model",
      error: { message: "Developer messages are not supported by this endpoint." },
    },
    {
      model: "role-path-model",
      error: { detail: "messages[0].role does not support 'developer'." },
    },
  ];
  const rolesByModel = new Map(cases.map(({ model }) => [model, []]));
  const errorsByModel = new Map(cases.map(({ model, error }) => [model, error]));
  const server = createServer((request, response) => {
    const chunks = [];
    request.on("data", (chunk) => chunks.push(chunk));
    request.on("end", () => {
      const body = JSON.parse(Buffer.concat(chunks).toString("utf8"));
      const role = body.messages?.[0]?.role;
      rolesByModel.get(body.model)?.push(role);
      if (role === "developer") {
        response.writeHead(400, { "content-type": "application/json" });
        response.end(JSON.stringify(errorsByModel.get(body.model)));
        return;
      }
      writeSuccessfulChatCompletion(response, "FALLBACK_OK", body.model);
    });
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  t.after(() => new Promise((resolve) => server.close(resolve)));
  const address = server.address();
  assert.ok(address && typeof address === "object");

  const client = new BridgeClient();
  for (const { model } of cases) {
    const result = await client.request(`developer-fallback-${model}`, "complete_once", {
      model_config: {
        provider_type: "openai_compatible",
        provider_config_id: `developer-fallback-${model}`,
        pi_provider_id: "aether-developer-fallback",
        pi_api: "openai-completions",
        model_id: model,
        base_url: `http://127.0.0.1:${address.port}/v1`,
        api_key: "secret-key",
        reasoning: true,
        max_retries: 0,
      },
      system_prompt: "Reply briefly.",
      messages: [userMessage("hello")],
      reasoning: "low",
    });

    assert.equal(result.assistant_text, "FALLBACK_OK", JSON.stringify(result));
    assert.equal(result.developer_role_unsupported_detected, true);
    assert.deepEqual(rolesByModel.get(model), ["developer", "system"]);
  }
});

test("applies the developer-role fallback inside an agent turn", async (t) => {
  const receivedRoles = [];
  const server = createServer((request, response) => {
    const chunks = [];
    request.on("data", (chunk) => chunks.push(chunk));
    request.on("end", () => {
      const body = JSON.parse(Buffer.concat(chunks).toString("utf8"));
      const role = body.messages?.[0]?.role;
      receivedRoles.push(role);
      if (role === "developer") {
        response.writeHead(400, { "content-type": "application/json" });
        response.end(JSON.stringify({
          error: {
            message: "Invalid value: 'developer'. Supported values are: 'system', 'user', 'assistant', and 'tool'.",
            type: "invalid_request_error",
            param: "messages[0].role",
          },
        }));
        return;
      }
      writeSuccessfulChatCompletion(response, "AGENT_FALLBACK_OK", "agent-fallback-model");
    });
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  t.after(() => new Promise((resolve) => server.close(resolve)));
  const address = server.address();
  assert.ok(address && typeof address === "object");

  const client = new BridgeClient();
  const result = await client.request(
    "developer-agent-fallback",
    "run_turn",
    {
      ...turnPayload("session-developer-agent-fallback", [userMessage("hello")], {
        provider_type: "openai_compatible",
        provider_config_id: "developer-agent-fallback",
        pi_provider_id: "aether-developer-agent-fallback",
        pi_api: "openai-completions",
        model_id: "agent-fallback-model",
        base_url: `http://127.0.0.1:${address.port}/v1`,
        api_key: "secret-key",
        reasoning: true,
        max_retries: 0,
      }),
      reasoning: "low",
    },
  );

  assert.equal(result.assistant_text, "AGENT_FALLBACK_OK", JSON.stringify(result));
  assert.equal(result.developer_role_unsupported_detected, true);
  assert.deepEqual(receivedRoles, ["developer", "system"]);
});

test("does not treat unrelated developer errors as role incompatibility", async (t) => {
  let requestCount = 0;
  const server = createServer((request, response) => {
    request.resume();
    request.on("end", () => {
      requestCount += 1;
      response.writeHead(401, { "content-type": "application/json" });
      response.end(JSON.stringify({
        error: { message: "The developer account API key is invalid." },
      }));
    });
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  t.after(() => new Promise((resolve) => server.close(resolve)));
  const address = server.address();
  assert.ok(address && typeof address === "object");

  const client = new BridgeClient();
  const result = await client.request("developer-unrelated-error", "complete_once", {
    model_config: {
      provider_type: "openai_compatible",
      provider_config_id: "developer-unrelated-error",
      pi_provider_id: "aether-developer-unrelated-error",
      pi_api: "openai-completions",
      model_id: "unrelated-error-model",
      base_url: `http://127.0.0.1:${address.port}/v1`,
      api_key: "secret-key",
      reasoning: true,
      max_retries: 0,
    },
    system_prompt: "Reply briefly.",
    messages: [userMessage("hello")],
    reasoning: "low",
  });

  assert.match(result.error_message, /developer account api key is invalid/i);
  assert.equal(result.developer_role_unsupported_detected, false);
  assert.equal(requestCount, 1);
});

test("uses system immediately when the provider is already marked", async (t) => {
  let receivedRole;
  const server = createServer((request, response) => {
    const chunks = [];
    request.on("data", (chunk) => chunks.push(chunk));
    request.on("end", () => {
      const body = JSON.parse(Buffer.concat(chunks).toString("utf8"));
      receivedRole = body.messages?.[0]?.role;
      writeSuccessfulChatCompletion(response, "MARKED_OK", "marked-model");
    });
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  t.after(() => new Promise((resolve) => server.close(resolve)));
  const address = server.address();
  assert.ok(address && typeof address === "object");

  const client = new BridgeClient();
  const result = await client.request("developer-marked", "complete_once", {
    model_config: {
      provider_type: "openai_compatible",
      provider_config_id: "developer-marked",
      pi_provider_id: "aether-developer-marked",
      pi_api: "openai-completions",
      model_id: "marked-model",
      base_url: `http://127.0.0.1:${address.port}/v1`,
      api_key: "secret-key",
      reasoning: true,
      supports_developer_role: false,
      max_retries: 0,
    },
    system_prompt: "Reply briefly.",
    messages: [userMessage("hello")],
    reasoning: "low",
  });

  assert.equal(result.assistant_text, "MARKED_OK", JSON.stringify(result));
  assert.equal(result.developer_role_unsupported_detected, false);
  assert.equal(receivedRole, "system");
});

test("passes reasoning_effort none when off is selected for a model with thinkingLevelMap off: none", async (t) => {
  let receivedRequest;
  const server = createServer((request, response) => {
    const chunks = [];
    request.on("data", (chunk) => chunks.push(chunk));
    request.on("end", () => {
      receivedRequest = {
        url: request.url,
        authorization: request.headers.authorization,
        body: JSON.parse(Buffer.concat(chunks).toString("utf8")),
      };
      response.writeHead(200, { "content-type": "text/event-stream" });
      response.write(
        `data: ${JSON.stringify({
          id: "chatcmpl-pi-none-test",
          object: "chat.completion.chunk",
          created: 1,
          model: "reasoning-model",
          choices: [
            {
              index: 0,
              delta: { role: "assistant", content: "NONE_OK" },
              finish_reason: null,
            },
          ],
        })}\n\n`,
      );
      response.write(
        `data: ${JSON.stringify({
          id: "chatcmpl-pi-none-test",
          object: "chat.completion.chunk",
          created: 1,
          model: "reasoning-model",
          choices: [{ index: 0, delta: {}, finish_reason: "stop" }],
          usage: {
            prompt_tokens: 4,
            completion_tokens: 2,
            total_tokens: 6,
          },
        })}\n\n`,
      );
      response.end("data: [DONE]\n\n");
    });
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  t.after(() => new Promise((resolve) => server.close(resolve)));
  const address = server.address();
  assert.ok(address && typeof address === "object");

  const client = new BridgeClient();
  const result = await client.request(
    "custom-reasoning-none",
    "complete_once",
    {
      model_config: {
        provider_type: "openai_compatible",
        provider_config_id: "custom-reasoning-none",
        pi_provider_id: "aether-test-reasoning",
        pi_api: "openai-completions",
        model_id: "reasoning-model",
        base_url: `http://127.0.0.1:${address.port}/v1`,
        api_key: "secret-key",
        reasoning: true,
        thinking_level_map: { off: "none" },
      },
      reasoning: "off",
      system_prompt: "Reply briefly.",
      messages: [userMessage("hello")],
      stream: false,
    },
  );

  assert.equal(result.assistant_text, "NONE_OK", JSON.stringify(result));
  assert.equal(receivedRequest.body.reasoning_effort, "none");
  assert.equal(Object.hasOwn(result.usage, "reasoning_tokens"), false);
});

test("updates reasoning effort when reusing an agent session", async (t) => {
  const receivedBodies = [];
  const server = createServer((request, response) => {
    const chunks = [];
    request.on("data", (chunk) => chunks.push(chunk));
    request.on("end", () => {
      const body = JSON.parse(Buffer.concat(chunks).toString("utf8"));
      receivedBodies.push(body);
      const answer = body.reasoning_effort === "none" ? "NONE_OK" : "LOW_OK";
      response.writeHead(200, { "content-type": "text/event-stream" });
      response.write(
        `data: ${JSON.stringify({
          id: `chatcmpl-agent-reasoning-${receivedBodies.length}`,
          object: "chat.completion.chunk",
          created: 1,
          model: "reasoning-model",
          choices: [{
            index: 0,
            delta: { role: "assistant", reasoning_content: "HIDDEN_REASONING" },
            finish_reason: null,
          }],
        })}\n\n`,
      );
      response.write(
        `data: ${JSON.stringify({
          id: `chatcmpl-agent-reasoning-${receivedBodies.length}`,
          object: "chat.completion.chunk",
          created: 1,
          model: "reasoning-model",
          choices: [{ index: 0, delta: { content: answer }, finish_reason: null }],
        })}\n\n`,
      );
      response.write(
        `data: ${JSON.stringify({
          id: `chatcmpl-agent-reasoning-${receivedBodies.length}`,
          object: "chat.completion.chunk",
          created: 1,
          model: "reasoning-model",
          choices: [{ index: 0, delta: {}, finish_reason: "stop" }],
          usage: { prompt_tokens: 4, completion_tokens: 4, total_tokens: 8 },
        })}\n\n`,
      );
      response.end("data: [DONE]\n\n");
    });
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  t.after(() => new Promise((resolve) => server.close(resolve)));
  const address = server.address();
  assert.ok(address && typeof address === "object");

  const client = new BridgeClient();
  const config = {
    provider_type: "openai_compatible",
    provider_config_id: "agent-reasoning-level",
    pi_provider_id: "aether-test-agent-reasoning",
    pi_api: "openai-completions",
    model_id: "reasoning-model",
    base_url: `http://127.0.0.1:${address.port}/v1`,
    api_key: "secret-key",
    reasoning: true,
    thinking_level_map: { off: "none" },
  };
  const sessionId = "session-agent-reasoning-level";
  const low = await client.request(
    "agent-reasoning-low",
    "run_turn",
    { ...turnPayload(sessionId, [userMessage("first")], config), reasoning: "low" },
  );
  const off = await client.request(
    "agent-reasoning-off",
    "run_turn",
    { ...turnPayload(sessionId, [userMessage("second")], config), reasoning: "off" },
  );

  assert.equal(low.session_reused, false);
  assert.equal(off.session_reused, true);
  assert.deepEqual(receivedBodies.map((body) => body.reasoning_effort), ["low", "none"]);
  assert.equal(off.reasoning_text, "HIDDEN_REASONING");
  assert.equal(off.assistant_text, "NONE_OK");
  assert.ok(
    client.events.some(
      (frame) =>
        frame.id === "agent-reasoning-off" &&
        frame.event === "assistant_reasoning_delta" &&
        frame.payload.delta === "HIDDEN_REASONING",
    ),
  );
});

test("reads top-level reasoning_tokens from OpenAI-compatible completion usage", async (t) => {
  const server = createServer((request, response) => {
    request.resume();
    request.on("end", () => {
      response.writeHead(200, { "content-type": "text/event-stream" });
      response.write(
        `data: ${JSON.stringify({
          id: "chatcmpl-top-level-reasoning-usage",
          object: "chat.completion.chunk",
          created: 1,
          model: "reasoning-model",
          choices: [
            {
              index: 0,
              delta: { role: "assistant", reasoning_content: "Brief reasoning" },
              finish_reason: null,
            },
          ],
        })}\n\n`,
      );
      response.write(
        `data: ${JSON.stringify({
          id: "chatcmpl-top-level-reasoning-usage",
          object: "chat.completion.chunk",
          created: 1,
          model: "reasoning-model",
          choices: [
            {
              index: 0,
              delta: { content: "ANSWER" },
              finish_reason: null,
            },
          ],
        })}\n\n`,
      );
      response.write(
        `data: ${JSON.stringify({
          id: "chatcmpl-top-level-reasoning-usage",
          object: "chat.completion.chunk",
          created: 1,
          model: "reasoning-model",
          choices: [{ index: 0, delta: {}, finish_reason: "stop" }],
          usage: {
            prompt_tokens: 4,
            completion_tokens: 9,
            total_tokens: 13,
            reasoning_tokens: 5,
          },
        })}\n\n`,
      );
      response.end("data: [DONE]\n\n");
    });
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  t.after(() => new Promise((resolve) => server.close(resolve)));
  const address = server.address();
  assert.ok(address && typeof address === "object");

  const client = new BridgeClient();
  const result = await client.request(
    "custom-top-level-reasoning-usage",
    "complete_once",
    {
      model_config: {
        provider_type: "openai_compatible",
        provider_config_id: "custom-top-level-reasoning-usage",
        pi_provider_id: "aether-test-reasoning",
        pi_api: "openai-completions",
        model_id: "reasoning-model",
        base_url: `http://127.0.0.1:${address.port}/v1`,
        api_key: "secret-key",
        reasoning: true,
      },
      reasoning: "low",
      system_prompt: "Reply briefly.",
      messages: [userMessage("hello")],
      stream: false,
    },
  );

  assert.equal(result.assistant_text, "ANSWER", JSON.stringify(result));
  assert.equal(result.reasoning_text, "Brief reasoning", JSON.stringify(result));
  assert.equal(result.usage.reasoning_tokens, 5, JSON.stringify(result));
});

test("accepts arbitrary manual model IDs for a built-in provider", async (t) => {
  let receivedRequest;
  const server = createServer((request, response) => {
    const chunks = [];
    request.on("data", (chunk) => chunks.push(chunk));
    request.on("end", () => {
      receivedRequest = {
        url: request.url,
        authorization: request.headers.authorization,
        customHeader: request.headers["x-aether-test"],
        body: JSON.parse(Buffer.concat(chunks).toString("utf8")),
      };
      response.writeHead(400, { "content-type": "application/json" });
      response.end(JSON.stringify({ error: { message: "expected test failure" } }));
    });
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  t.after(() => new Promise((resolve) => server.close(resolve)));
  const address = server.address();
  assert.ok(address && typeof address === "object");

  const client = new BridgeClient();
  const result = await client.request("custom-openai-native", "complete_once", {
    model_config: {
      provider_type: "builtin",
      provider_config_id: "custom-openai-native",
      pi_provider_id: "openai",
      pi_api: "builtin",
      model_id: "sfsefehfjksdnf",
      base_url: `http://127.0.0.1:${address.port}/v1`,
      api_key: "secret-key",
      custom_headers: { "X-Aether-Test": "present" },
      reasoning: true,
      max_retries: 0,
    },
    system_prompt: "Reply briefly.",
    messages: [userMessage("hello")],
    reasoning: "high",
    stream: false,
  });

  assert.match(result.error_message, /expected test failure|400/);
  assert.equal(receivedRequest.url, "/v1/responses");
  assert.equal(receivedRequest.authorization, "Bearer secret-key");
  assert.equal(receivedRequest.customHeader, "present");
  assert.equal(receivedRequest.body.model, "sfsefehfjksdnf");
  assert.equal(receivedRequest.body.reasoning.effort, "high");
});

test("omits explicit cache mode for custom OpenAI Responses endpoints", async (t) => {
  const home = await mkdtemp(join(tmpdir(), "aether-custom-responses-"));
  const api = await createOpenAIResponsesServer();
  const client = new BridgeClient({ HOME: home, USERPROFILE: home });
  t.after(async () => {
    await client.close();
    await api.close();
    await rm(home, { recursive: true, force: true });
  });

  const sessionId = "custom-responses-compaction";
  await runResponsesTurns(
    client,
    sessionId,
    openAIResponsesModelConfig(api.baseUrl),
    home,
  );
  const compacted = await client.request(
    "custom-responses-compact",
    "compact_session",
    { session_id: sessionId },
    20_000,
  );

  assert.ok(compacted.compaction);
  assert.equal(api.requests.length, RESPONSES_TEST_TURN_COUNT + 1);
  for (const request of api.requests) {
    assert.equal(request.url, "/v1/responses");
    assert.equal(
      Object.prototype.hasOwnProperty.call(request.body, "prompt_cache_options"),
      false,
    );
  }
});

test("preserves explicit cache mode for the official OpenAI Responses endpoint", async (t) => {
  const home = await mkdtemp(join(tmpdir(), "aether-official-responses-"));
  const api = await createOpenAIResponsesServer();
  const client = new BridgeClient({
    HOME: home,
    USERPROFILE: home,
    ...openAIFetchRedirectEnvironment(api.baseUrl),
  });
  t.after(async () => {
    await client.close();
    await api.close();
    await rm(home, { recursive: true, force: true });
  });

  const sessionId = "official-responses-compaction";
  await runResponsesTurns(
    client,
    sessionId,
    openAIResponsesModelConfig("https://API.OPENAI.COM:443/v1/", {
      provider_config_id: sessionId,
    }),
    home,
  );
  const compacted = await client.request(
    "official-responses-compact",
    "compact_session",
    { session_id: sessionId },
    20_000,
  );

  assert.ok(compacted.compaction);
  assert.equal(api.requests.length, RESPONSES_TEST_TURN_COUNT + 1);
  for (const request of api.requests) {
    assert.equal(request.url, "/v1/responses");
  }
  for (const request of api.requests.slice(0, -1)) {
    assert.equal(
      Object.prototype.hasOwnProperty.call(request.body, "prompt_cache_options"),
      false,
    );
  }
  assert.deepEqual(api.requests.at(-1).body.prompt_cache_options, { mode: "explicit" });
});

test("lists every built-in Pi provider and its model catalog", async () => {
  const client = new BridgeClient();
  const catalog = await client.request("providers", "list_providers");
  const providers = catalog.providers;

  // v3.0.35 — the SUBSCRIPTION (sign-in) providers are gone: openai-codex
  // and github-copilot are filtered out of the advertised catalog
  // (RemovedSubscriptionProviderIds in bridge.ts; the third id,
  // gemini-subscription, was never a pi-ai builtin). The catalog is
  // pi-ai's 39 builtins minus the two subscription ones (37).
  // v3.0.79 — -1: the v3.0.77 "gemini-cli" provider (Google sign-in on
  // the Code Assist backend) is REMOVED again — its on-device OAuth +
  // onboarding never completed (ETIMEDOUT / ECONNREFUSED on the bridge's
  // direct fetches to Google endpoints, "onboarding returned no
  // cloudaicompanion project"), so it joins RemovedSubscriptionProviderIds
  // and the advertised catalog is back to the plain pi-ai builtin list (37).
  // v3.0.86 — Pi 0.99.2 ships 42 builtins; after the six RemovedProviderIds
  // (openai-codex, github-copilot, gemini-subscription, gemini-cli,
  // cerebras, kimi-coding) and dropping the model-less "typesafe" entry
  // the advertised catalog is 37 again.
  assert.equal(providers.length, 37);
  assert.equal(new Set(providers.map((provider) => provider.id)).size, 37);
  assert.ok(providers.every((provider) => provider.models.length > 0));
  assert.ok(providers.every((provider) => provider.models.every((model) => model.id)));

  const ids = providers.map((provider) => provider.id);
  assert.equal(ids.includes("openai-codex"), false);
  assert.equal(ids.includes("github-copilot"), false);
  assert.equal(ids.includes("gemini-subscription"), false);
  assert.equal(ids.includes("gemini-cli"), false);

  const oauthProviders = providers
    .filter((provider) => provider.auth.oauth)
    .map((provider) => provider.id)
    .sort();
  // v3.0.86 — Pi 0.99.2 grew OAuth flows for meta, openai and radius;
  // kimi-coding was removed with the provider (v3.0.85).
  assert.deepEqual(oauthProviders, [
    "anthropic",
    "meta",
    "openai",
    "openrouter",
    "radius",
    "xai",
  ]);
});

test("validates Pi OAuth protocol requests without legacy provider fallbacks", async () => {
  const client = new BridgeClient();
  const promptResult = await client.request("prompt-missing", "auth_prompt_result", {
    prompt_id: "missing",
    value: "unused",
  });
  assert.equal(promptResult.accepted, false);

  await assert.rejects(
    client.request("oauth-unsupported", "login_provider", {
      // v3.0.86 — pi 0.99.2's "openai" provider DOES bundle an OAuth flow
      // now; "groq" is the API-key-only builtin that must still reject.
      provider_id: "groq",
      provider_config_id: `test-${"groq"}`,
    }),
    /does not support OAuth/,
  );
  await assert.rejects(
    client.request("oauth-unknown", "login_provider", {
      provider_id: "legacy-custom-provider",
      provider_config_id: "test-unknown",
    }),
    /Unknown built-in Pi provider/,
  );
});

test("bundles every Pi OAuth flow into the standalone bridge", async () => {
  const client = new BridgeClient();
  // v3.0.35 — openai-codex and github-copilot are REMOVED subscription
  // providers: login_provider must reject them outright (they are no
  // longer in the bridge's provider map). The remaining OAuth-capable
  // builtins (anthropic, kimi-coding, openrouter, xai) still bundle their
  // pi-ai flows; anthropic's manual_code prompt pins that the generic
  // OAuth transport survived the removal.
  // v3.0.79 — the v3.0.77 gemini-cli provider is REMOVED again: it joins
  // the rejection list (removed from the bridge's provider map together
  // with its deleted ./gemini-cli.ts module).
  for (const providerId of [
    "openai-codex",
    "github-copilot",
    "gemini-subscription",
    "gemini-cli",
  ]) {
    await assert.rejects(
      client.request(`oauth-removed-${providerId}`, "login_provider", {
        provider_id: providerId,
        provider_config_id: `test-${providerId}`,
      }),
      /Unknown built-in Pi provider/,
    );
  }

  const requestId = "oauth-anthropic-bundle";
  const login = client.request(
    requestId,
    "login_provider",
    {
      provider_id: "anthropic",
      provider_config_id: "test-anthropic",
    },
    15_000,
  );
  const prompt = await client.waitForEvent(
    (frame) => frame.id === requestId && frame.event === "auth_prompt",
    10_000,
  );
  // pi >= 1.4: Anthropic starts with a sign-in method chooser ("select");
  // older kernels jumped straight to the copy-code ("manual_code") prompt.
  assert.ok(
    prompt.payload.prompt_type === "manual_code" || prompt.payload.prompt_type === "select",
    `unexpected first Anthropic prompt type: ${prompt.payload.prompt_type}`,
  );

  const cancelled = await client.request("oauth-anthropic-cancel", "auth_prompt_result", {
    prompt_id: prompt.payload.prompt_id,
    cancelled: true,
  });
  assert.equal(cancelled.accepted, true);
  await assert.rejects(login, /cancel/i);
});

test("uses Pi provider-specific API key login prompts", async () => {
  const client = new BridgeClient();

  const openAILogin = client.request("api-key-openai", "login_provider", {
    provider_id: "openai",
    provider_config_id: `test-${"openai"}`,
    auth_method: "api_key",
  });
  const openAIPrompt = await client.waitForEvent(
    (frame) =>
      frame.id === "api-key-openai" &&
      frame.event === "auth_prompt" &&
      frame.payload.message === "Enter OpenAI API key",
  );
  await client.request("api-key-openai-result", "auth_prompt_result", {
    prompt_id: openAIPrompt.payload.prompt_id,
    value: "openai-test-key",
  });
  const openAIResult = await openAILogin;
  assert.equal(openAIResult.auth_method, "api_key");
  assert.equal(openAIResult.api_key, "openai-test-key");

  const cloudflareLogin = client.request("api-key-cloudflare", "login_provider", {
    provider_id: "cloudflare-ai-gateway",
    provider_config_id: `test-${"cloudflare-ai-gateway"}`,
    auth_method: "api_key",
  });
  const cloudflareAnswers = [
    ["Enter Cloudflare API key", "cloudflare-test-key"],
    ["Enter Cloudflare account ID", "account-id"],
    ["Enter Cloudflare AI Gateway ID", "gateway-id"],
  ];
  for (const [message, value] of cloudflareAnswers) {
    const prompt = await client.waitForEvent(
      (frame) =>
        frame.id === "api-key-cloudflare" &&
        frame.event === "auth_prompt" &&
        frame.payload.message === message,
    );
    await client.request(`cloudflare-${value}`, "auth_prompt_result", {
      prompt_id: prompt.payload.prompt_id,
      value,
    });
  }
  const cloudflareResult = await cloudflareLogin;
  assert.equal(cloudflareResult.api_key, "cloudflare-test-key");
  assert.deepEqual(cloudflareResult.provider_env, {
    CLOUDFLARE_ACCOUNT_ID: "account-id",
    CLOUDFLARE_GATEWAY_ID: "gateway-id",
  });

  const bedrockLogin = client.request("api-key-bedrock", "login_provider", {
    provider_id: "amazon-bedrock",
    provider_config_id: `test-${"amazon-bedrock"}`,
    auth_method: "api_key",
  });
  const bedrockPrompt = await client.waitForEvent(
    (frame) =>
      frame.id === "api-key-bedrock" &&
      frame.event === "auth_prompt" &&
      frame.payload.prompt_type === "select",
  );
  assert.deepEqual(
    bedrockPrompt.payload.options.map((option) => option.id),
    ["bearer-token", "aws-profile", "credential-chain"],
  );
  await client.request("api-key-bedrock-cancel", "auth_prompt_result", {
    prompt_id: bedrockPrompt.payload.prompt_id,
    cancelled: true,
  });
  await assert.rejects(bedrockLogin, /cancel/i);
});

test("rejects non-OpenAI custom Pi APIs", async () => {
  const client = new BridgeClient();
  for (const piApi of ["anthropic-messages", "google-vertex", "openai-responses"]) {
    await assert.rejects(
      client.request(`custom-${piApi}`, "complete_once", {
        model_config: {
          provider_type: "custom",
          provider_config_id: `custom-${piApi}`,
          pi_provider_id: "custom-test",
          pi_api: piApi,
          model_id: "custom-model",
          base_url: "http://127.0.0.1:1/v1",
        },
        messages: [userMessage("hello")],
      }),
      /Unsupported custom Pi API/,
    );
  }
});

test("v2.9.3 keeps utility host tools allowlisted and device-control tools dropped on android", async (t) => {
  const home = await mkdtemp(join(tmpdir(), "arix-device-tools-"));
  t.after(() => rm(home, { recursive: true, force: true }));
  const client = new BridgeClient({ HOME: home, USERPROFILE: home });
  const utilityNames = [
    // v3.0.85 — weather/qr_code host tools were removed (the executor now
    // answers TOOL_NOT_FOUND for them); upi_pay is the remaining utility.
    "upi_pay",
  ];
  const removedNames = [
    "device_status",
    "read_screen",
    "ui_action",
    "open_app",
    "open_settings",
    "open_url",
    "arix_system",
    "agent_mode",
    "arix_agent_mode_manage",
    "adb",
    "system_control",
  ];
  const requested = [...utilityNames, ...removedNames].map((name) => hostTool(name));

  await client.request("device-tools-turn", "run_turn", {
    ...turnPayload("device-tools", [userMessage("hello")], fauxConfig(), requested),
    platform: "android",
  });
  const state = await client.request("device-tools-state", "get_session_state", {
    session_id: "device-tools",
  });
  assert.deepEqual(
    utilityNames.filter((name) => state.active_tools.includes(name)),
    utilityNames,
  );
  assert.deepEqual(removedNames.filter((name) => state.active_tools.includes(name)), []);
});

test("v2.7.6 keeps ios limited to the non-device host tools", async (t) => {
  const home = await mkdtemp(join(tmpdir(), "arix-ios-device-tools-"));
  t.after(() => rm(home, { recursive: true, force: true }));
  const client = new BridgeClient({ HOME: home, USERPROFILE: home });
  const requested = ["device_status", "read_screen", "ui_action", "weather"].map((name) => hostTool(name));
  await client.request("ios-device-turn", "run_turn", {
    ...turnPayload("ios-device", [userMessage("hello")], fauxConfig(), requested),
    platform: "ios",
  });
  const state = await client.request("ios-device-state", "get_session_state", {
    session_id: "ios-device",
  });
  assert.equal(state.active_tools.includes("device_status"), false);
  assert.equal(state.active_tools.includes("read_screen"), false);
  assert.equal(state.active_tools.includes("ui_action"), false);
  assert.equal(state.active_tools.includes("weather"), false);
});

test("v2.7.6 unknown host tools are dropped without fuzzy matching", async (t) => {
  const home = await mkdtemp(join(tmpdir(), "arix-fuzzy-"));
  t.after(() => rm(home, { recursive: true, force: true }));
  const client = new BridgeClient({ HOME: home, USERPROFILE: home });
  const nearMisses = ["read_scren", "ui-action", "openApp", "device_statuses", "weather_tool"];
  const requested = ["arix_memory", ...nearMisses].map((name) => hostTool(name));
  await client.request("fuzzy-turn", "run_turn", {
    ...turnPayload("fuzzy", [userMessage("hello")], fauxConfig(), requested),
    platform: "android",
  });
  const state = await client.request("fuzzy-state", "get_session_state", {
    session_id: "fuzzy",
  });
  assert.equal(state.active_tools.includes("arix_memory"), true);
  assert.deepEqual(nearMisses.filter((name) => state.active_tools.includes(name)), []);
});

test("v2.9.3 drops the removed arix_system control tool on every platform", async (t) => {
  const home = await mkdtemp(join(tmpdir(), "arix-system-tool-"));
  t.after(() => rm(home, { recursive: true, force: true }));
  const client = new BridgeClient({ HOME: home, USERPROFILE: home });
  const requested = ["arix_system"].map((name) => hostTool(name));
  await client.request("arix-system-turn", "run_turn", {
    ...turnPayload("arix-system", [userMessage("open settings")], fauxConfig(), requested),
    platform: "android",
  });
  const state = await client.request("arix-system-state", "get_session_state", {
    session_id: "arix-system",
  });
  assert.equal(
    state.active_tools.includes("arix_system"),
    false,
    "arix_system is a removed surface and must never be exposed to the model",
  );
  await client.request("ios-arix-system-turn", "run_turn", {
    ...turnPayload("ios-arix-system", [userMessage("open settings")], fauxConfig(), requested),
    platform: "ios",
  });
  const iosState = await client.request("ios-arix-system-state", "get_session_state", {
    session_id: "ios-arix-system",
  });
  assert.equal(iosState.active_tools.includes("arix_system"), false);
});

test("v2.7.12 history trimming keeps tool pairs intact (source contract)", async () => {
  const source = await readFile(new URL("../src/bridge.ts", import.meta.url), "utf8");
  assert.ok(
    source.includes('kept[pairSafeStart]?.role === "toolResult"'),
    "history trimming must skip leading orphaned toolResult messages",
  );
  assert.ok(
    source.includes("dropped_orphaned_tool_results"),
    "trim diagnostics must report the dropped orphans",
  );
});

// ---------------------------------------------------------------------------
// v3.0.50 regressions: credential clear/re-seed, system-prompt staleness.
// ---------------------------------------------------------------------------

test("v3.0.50 clear_provider_credential re-seeds from the next model_config", async (t) => {
  const requests = [];
  const server = createServer((request, response) => {
    const chunks = [];
    request.on("data", (chunk) => chunks.push(chunk));
    request.on("end", () => {
      requests.push({ url: request.url, authorization: request.headers.authorization || "" });
      writeSuccessfulChatCompletion(response, "OK", "custom-model");
    });
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  t.after(() => new Promise((resolve) => server.close(resolve)));
  const address = server.address();
  assert.ok(address && typeof address === "object");

  const modelConfig = {
    provider_type: "openai_compatible",
    provider_config_id: "reseed-test",
    pi_provider_id: "aether-reseed",
    pi_api: "openai-completions",
    model_id: "custom-model",
    base_url: `http://127.0.0.1:${address.port}/v1`,
    api_key: "reseed-key",
    reasoning: false,
  };

  const client = new BridgeClient();
  const first = await client.request("reseed-1", "complete_once", {
    model_config: modelConfig,
    system_prompt: "Reply briefly.",
    messages: [userMessage("hello")],
    stream: false,
  });
  assert.equal(first.assistant_text, "OK");

  // The app clears on every non-OAuth provider-config edit; the next request
  // with the same model_config used to fail with "Provider is not
  // configured" until the bridge process was restarted.
  await client.request("reseed-clear", "clear_provider_credential", {
    provider_config_id: "reseed-test",
  });
  requests.length = 0;
  const second = await client.request("reseed-2", "complete_once", {
    model_config: modelConfig,
    system_prompt: "Reply briefly.",
    messages: [userMessage("hello again")],
    stream: false,
  });
  assert.equal(second.assistant_text, "OK");
  assert.equal(requests.length, 1);
  assert.equal(requests[0].authorization, "Bearer reseed-key");
});

test("v3.0.50 a reused kernel session is recreated when the system prompt changes", async (t) => {
  const systemPrompts = [];
  const server = createServer((request, response) => {
    const chunks = [];
    request.on("data", (chunk) => chunks.push(chunk));
    request.on("end", () => {
      const body = JSON.parse(Buffer.concat(chunks).toString("utf8"));
      const system = body.messages?.find((message) => message.role === "system" || message.role === "developer");
      systemPrompts.push(system?.content ?? "");
      writeSuccessfulChatCompletion(response, "OK", "custom-model");
    });
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  t.after(() => new Promise((resolve) => server.close(resolve)));
  const address = server.address();
  assert.ok(address && typeof address === "object");

  const config = {
    provider_type: "openai_compatible",
    provider_config_id: "prompt-sig-test",
    pi_provider_id: "aether-prompt-sig",
    pi_api: "openai-completions",
    model_id: "custom-model",
    base_url: `http://127.0.0.1:${address.port}/v1`,
    api_key: "prompt-sig-key",
    reasoning: false,
  };
  const workspace = await mkdtemp(join(tmpdir(), "arix-prompt-sig-"));
  t.after(() => rm(workspace, { recursive: true, force: true }));

  const client = new BridgeClient();
  const turn = (id, systemPrompt) =>
    client.request(id, "run_turn", {
      session_id: "prompt-sig-session",
      model_config: config,
      system_prompt: systemPrompt,
      workspace_directory: workspace,
      workspace_trusted: true,
      termux_workspace_directory: workspace,
      host_tools: [],
      messages: [userMessage("hi")],
      reasoning: "off",
      runtime: "termux",
      platform: "android",
    });

  const first = await turn("prompt-sig-1", "PROMPT-FIRST");
  assert.equal(first.session_reused, false);
  const second = await turn("prompt-sig-2", "PROMPT-SECOND");
  assert.equal(second.session_reused, false, "a changed system prompt must recreate the session");
  const third = await turn("prompt-sig-3", "PROMPT-SECOND");
  assert.equal(third.session_reused, true, "an identical system prompt must reuse the session");
  await client.request("prompt-sig-close", "close_session", {
    session_id: "prompt-sig-session",
    delete_file: true,
  });
});

test("v3.0.50 source contract: credential re-seed and prompt signature exist", async () => {
  const source = await readFile(new URL("../src/bridge.ts", import.meta.url), "utf8");
  assert.ok(
    source.includes("sharedCredentialStates.delete(providerConfigId)"),
    "clearSharedCredential must drop the shared entry so the next construction re-seeds",
  );
  assert.ok(
    source.includes("async seedIfEmpty(credential: Credential)"),
    "BridgeCredentialStore must support seeding an empty shared state",
  );
  assert.ok(
    source.includes("function systemPromptSignatureFor(payload: JsonObject)"),
    "the reuse gate must compare a system-prompt signature",
  );
});

// ------------------------------------------------------------------ //
// v3.0.61 — MULTI-KEY POOL: automatic key rotation on quota exhaustion.
// A provider whose FIRST key is quota-exhausted (429, after pi-ai's own
// retry budget) must transparently shift to the NEXT configured key and
// finish the task — no hard stop, no surfaced error.
// ------------------------------------------------------------------ //

test("v3.0.61 multi-key pool rotates to the next key on quota exhaustion and completes the task", async (t) => {
  const home = await mkdtemp(join(tmpdir(), "arix-key-rotation-"));
  t.after(() => rm(home, { recursive: true, force: true }));

  const seenAuthorizations = [];
  const server = createServer((request, response) => {
    const chunks = [];
    request.on("data", (chunk) => chunks.push(chunk));
    request.on("end", () => {
      const authorization = request.headers["authorization"] ?? "";
      seenAuthorizations.push(String(authorization));
      if (authorization.includes("exhausted-key")) {
        // Hard daily-quota exhaustion: not transient, no retry-after.
        response.writeHead(429, { "content-type": "application/json" });
        response.end(
          JSON.stringify({
            error: {
              message: "You exceeded your current quota, please check your plan and billing details.",
              type: "insufficient_quota",
              code: "insufficient_quota",
            },
          }),
        );
        return;
      }
      writeSuccessfulChatCompletion(response, "rotated and done", "test-model");
    });
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  assert.ok(address && typeof address === "object");
  const baseUrl = `http://127.0.0.1:${address.port}/v1`;

  const client = new BridgeClient({ HOME: home, USERPROFILE: home });
  try {
    const config = {
      provider_type: "custom",
      provider_config_id: "rotation-test",
      pi_provider_id: "arix-rotation-test",
      pi_api: "openai-completions",
      model_id: "test-model",
      base_url: baseUrl,
      api_key: "exhausted-key",
      api_keys: ["exhausted-key", "fresh-key"],
      reasoning: false,
      max_retries: 0,
      max_provider_retries: 0,
    };
    const result = await client.request("rotation-turn", "complete_once", {
      model_config: config,
      system_prompt: "Reply briefly.",
      messages: [userMessage("say hi")],
      reasoning: "off",
    });

    // The task COMPLETED: the answer came through the rotated key.
    assert.equal(result.assistant_text, "rotated and done");
    // The exhausted key was tried first, then the fresh one answered.
    assert.ok(
      seenAuthorizations.some((value) => value.includes("exhausted-key")),
      "the primary key must be tried first",
    );
    assert.ok(
      seenAuthorizations.some((value) => value.includes("fresh-key")),
      "the next key must answer after the quota error",
    );
  } finally {
    await client.close();
    server.close();
  }
});

test("v3.0.61 source contract: key-rotation machinery exists", async () => {
  const source = await readFile(new URL("../src/bridge.ts", import.meta.url), "utf8");
  assert.ok(source.includes("function withKeyRotation"), "key-rotation stream wrapper");
  assert.ok(source.includes("function rotateToNextKey"), "rotation advance");
  assert.ok(source.includes("function registerKeyPool"), "pool registration on buildModels");
  assert.ok(source.includes("api_key_rotated"), "rotation debug event");
  assert.ok(source.includes("isQuotaExhaustionError"), "quota-error detection");
  // v3.0.85 — the qr_code host tool was removed; the upi_pay utility
  // covers the allowlisted-tool contract now.
  assert.ok(source.includes('"upi_pay"'), "upi_pay host tool (allowlisted utility)");
  assert.ok(
    !source.includes("geminiWebStreams"),
    "the gemini-web provider must stay removed",
  );
  assert.ok(
    !source.includes("pollinations"),
    "the Pollinations fallback must stay removed",
  );
});

test("v3.0.78 dynamic context: minimal-tier turns drop the coding-agent native tools", async (t) => {
  // A minimal-tier turn ("hi" — pure small talk) must not carry the seven
  // native coding tools (read/bash/edit/write/grep/find/ls, ~1.2k tokens
  // of schema); a turn without a context policy keeps them exactly.
  const recordedRequests = [];
  const server = createServer((request, response) => {
    let body = "";
    request.on("data", (chunk) => { body += chunk; });
    request.on("end", () => {
      recordedRequests.push(JSON.parse(body || "{}"));
      response.writeHead(200, { "content-type": "text/event-stream" });
      response.write(`data: ${JSON.stringify({
        candidates: [{
          content: { role: "model", parts: [{ text: "hello!" }] },
          finishReason: "STOP",
          index: 0,
        }],
        usageMetadata: { promptTokenCount: 100, candidatesTokenCount: 3, totalTokenCount: 103 },
        modelVersion: "gemini-3.5-flash-lite",
      })}\n\n`);
      response.write("data: [DONE]\n\n");
      response.end();
    });
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  t.after(() => server.close());
  const baseUrl = `http://127.0.0.1:${server.address().port}/v1beta`;

  const home = await mkdtemp(join(tmpdir(), "arix-minimal-tools-"));
  t.after(() => rm(home, { recursive: true, force: true }));
  const client = new BridgeClient({ HOME: home, GEMINI_API_KEY: "test-key" });
  t.after(() => client.close());

  const config = {
    provider_type: "builtin",
    provider_config_id: "google",
    pi_provider_id: "google",
    pi_api: "builtin",
    model_id: "gemini-3.5-flash-lite",
    base_url: baseUrl,
    api_key: "test-key",
    reasoning: false,
  };
  const turn = (sessionId, contextPolicy) => client.request(
    `${sessionId}-turn`,
    "run_turn",
    {
      session_id: sessionId,
      model_config: config,
      system_prompt: "test",
      workspace_directory: home,
      workspace_trusted: true,
      messages: [userMessage("hi")],
      host_tools: [],
      reasoning: "off",
      session_directory: home,
      max_retries: 0,
      ...(contextPolicy ? { context_policy: contextPolicy } : {}),
    },
    30_000,
  );

  const nativeNames = new Set(["read", "bash", "edit", "write", "grep", "find", "ls"]);
  const toolNamesOf = (body) =>
    (body.tools ?? [])
      .flatMap((tool) => tool.functionDeclarations ?? [])
      .map((declaration) => declaration.name);

  // No policy → legacy behavior: the native coding tools are present.
  await turn("minimal-legacy", undefined);
  let names = toolNamesOf(recordedRequests.at(-1));
  assert.ok(
    ["read", "bash"].every((name) => names.includes(name)),
    `legacy turns keep the native coding tools (got: ${names.join(",")})`,
  );

  // Standard tier → identical tool set.
  await turn("minimal-standard", { tier: "standard", trim_fraction: 0.55, compact_threshold: 0.75 });
  names = toolNamesOf(recordedRequests.at(-1));
  assert.ok(names.includes("bash"), "standard-tier turns keep the native coding tools");

  // Minimal tier → NO native coding tools.
  await turn("minimal-tier", { tier: "minimal", trim_fraction: 0.35, compact_threshold: 0.6 });
  names = toolNamesOf(recordedRequests.at(-1));
  assert.ok(
    names.every((name) => !nativeNames.has(name)),
    `minimal-tier turns must not carry the native coding tools (got: ${names.join(",")})`,
  );

  // And back to standard on the SAME session id: the tool signature
  // change recreates the session with the full set again.
  await turn("minimal-tier", { tier: "standard", trim_fraction: 0.55, compact_threshold: 0.75 });
  names = toolNamesOf(recordedRequests.at(-1));
  assert.ok(names.includes("bash"), "a later standard turn restores the native coding tools");
});
