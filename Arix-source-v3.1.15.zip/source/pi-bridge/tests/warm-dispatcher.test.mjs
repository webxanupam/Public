/**
 * v3.0.38 — tests for the bridge WARM-DIRECT dispatcher (the network
 * proxy stack was removed; see warm-dispatcher.ts). Coverage:
 *  1. the proxy stack is GONE end-to-end: `set_network_proxy` is no
 *     longer a recognized request, `ping` no longer reports a proxy, and
 *     neither the bridge source nor the built bundle contains any proxy
 *     dispatcher machinery (EnvHttpProxyAgent, port probing);
 *  2. the warm keep-alive tuning survives (source + bundle): provider
 *     connections stay hot between turns — the v3.0.32 latency fix;
 *  3. provider network failures still carry the plain "could not reach"
 *     guidance (without pointing at the removed proxy setting).
 */
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { createServer } from "node:http";
import { createInterface } from "node:readline";
import { after, test } from "node:test";
import { readFile } from "node:fs/promises";

const activeChildren = new Set();

/** Spawns the built bridge and speaks the newline-delimited JSON protocol. */
class WarmDispatcherTestBridge {
  constructor() {
    this.child = spawn(process.execPath, ["dist/bridge.mjs"], {
      cwd: process.cwd(),
      stdio: ["pipe", "pipe", "pipe"],
      env: { ...process.env },
    });
    activeChildren.add(this.child);
    this.pending = new Map();
    this.stderr = "";
    this.child.stderr.setEncoding("utf8");
    this.child.stderr.on("data", (chunk) => (this.stderr += chunk));
    this.readline = createInterface({ input: this.child.stdout });
    this.readline.on("line", (line) => {
      const trimmed = line.trim();
      if (!trimmed) return;
      let frame;
      try {
        frame = JSON.parse(trimmed);
      } catch {
        return;
      }
      const waiter = this.pending.get(frame.id);
      if (waiter) {
        this.pending.delete(frame.id);
        clearTimeout(waiter.timeout);
        waiter.resolve(frame);
      }
    });
  }

  request(type, payload = {}, timeoutMs = 20_000) {
    const id = `warm-test-${Math.random().toString(36).slice(2)}`;
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`Timed out waiting for ${type}: ${this.stderr}`));
      }, timeoutMs);
      this.pending.set(id, { resolve, timeout });
      this.child.stdin.write(`${JSON.stringify({ id, type, payload })}\n`);
    });
  }

  close() {
    activeChildren.delete(this.child);
    this.readline.close();
    this.child.stdin.end();
    this.child.kill();
  }
}

after(async () => {
  for (const child of activeChildren) {
    if (!child.killed) child.kill();
  }
});

test("the proxy stack is gone: set_network_proxy is unrecognized and ping reports no proxy", async () => {
  const bridge = new WarmDispatcherTestBridge();
  try {
    // ping answers (bridge healthy) but carries NO network_proxy field.
    const ping = await bridge.request("ping");
    assert.equal(ping.type, "response");
    assert.equal("network_proxy" in ping.payload, false);

    // The removed handler is no longer recognized.
    const removed = await bridge.request("set_network_proxy", {
      proxy_url: "http://127.0.0.1:7890",
    });
    assert.equal(removed.type, "error");
    const note =
      typeof removed.error === "object" && removed.error !== null
        ? removed.error.message ?? JSON.stringify(removed.error)
        : String(removed.error ?? "");
    assert.match(note, /unsupported request type/i);
  } finally {
    bridge.close();
  }
});

test("neither the bridge source nor the bundle carries proxy machinery", async () => {
  const bridgeSource = await readFile("src/bridge.ts", "utf8");
  const dispatcherSource = await readFile("src/warm-dispatcher.ts", "utf8");
  const bundle = await readFile("dist/bridge.mjs", "utf8");

  // No Arix proxy protocol / probing machinery anywhere in the runtime.
  // (The vendored undici LIBRARY export table still lists its own
  // EnvHttpProxyAgent class — never invoked by the bridge — so the pins
  // target the Arix protocol and probe strings instead of library class
  // names.)
  for (const text of [bridgeSource, bundle]) {
    assert.equal(text.includes("set_network_proxy"), false);
    assert.equal(text.includes("probeLocalProxyFor"), false);
    assert.equal(text.includes("maybeAutoDetectLocalProxy"), false);
    assert.equal(text.includes("ARIX_LOCAL_PROXY_PORTS"), false);
  }
  // The old proxy module is gone entirely.
  await assert.rejects(() => readFile("src/network-proxy.ts", "utf8"));

  // The warm keep-alive tuning survives in the active dispatcher module.
  assert.match(dispatcherSource, /keepAliveTimeout: 60_000/);
  assert.match(dispatcherSource, /setGlobalDispatcher/);
  assert.match(bridgeSource, /installWarmDispatcher\(\);/);
});

test("provider network failures carry the plain reachability guidance", async () => {
  // A provider port nothing binds: every direct attempt dies instantly
  // (ECONNREFUSED), exactly like a blocked/unreachable provider endpoint.
  const unavailable = createServer();
  await new Promise((resolve) => unavailable.listen(0, "127.0.0.1", resolve));
  const providerPort = unavailable.address().port;
  await new Promise((resolve) => unavailable.close(resolve));

  const bridge = new WarmDispatcherTestBridge();
  try {
    const failure = await bridge.request(
      "run_turn",
      {
        session_id: "session-reachability-guidance",
        model_config: {
          provider_type: "openai_compatible",
          provider_config_id: "provider-guidance",
          pi_provider_id: "aether-reachability-guidance",
          pi_api: "openai-completions",
          model_id: "guidance-model",
          base_url: `http://127.0.0.1:${providerPort}/v1`,
          api_key: "secret-key",
          reasoning: false,
        },
        system_prompt: "Use the supplied tools when needed.",
        workspace_directory: process.cwd(),
        messages: [{ role: "user", content: [{ type: "text", text: "hello" }] }],
        host_tools: [],
        reasoning: "off",
        max_retries: 0,
        provider_max_retries: 0,
        max_retry_delay_ms: 1,
      },
      30_000,
    );
    assert.equal(failure.type, "response", JSON.stringify(failure.error ?? failure.payload));
    assert.equal(failure.payload.stop_reason, "error");
    const message = failure.payload.error_message ?? "";
    assert.match(message, /Could not reach/i);
    // The removed setting is no longer referenced.
    assert.equal(message.includes("Network proxy"), false);
  } finally {
    bridge.close();
  }
});
