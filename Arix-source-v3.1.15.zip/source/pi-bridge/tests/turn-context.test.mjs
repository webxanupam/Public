// v3.0.83 — TURN-CONTEXT OUT-OF-BAND DELIVERY (the token-regression fix).
//
// v3.0.82 prefixed the ephemeral turn context onto the LAST USER message,
// which the kernel session PERSISTED into its JSONL — every past user
// message kept its own copy of the memory/session-context/task-state
// block, so token consumption grew turn over turn (the user's report:
// "before in v81 arix consume less token now after it consume more").
//
// v3.0.83 ships the block as the run_turn payload's `turn_context` field;
// the bridge injects it into the outgoing MODEL REQUEST's system prompt
// at request time (provider stream wrapper) and NEVER writes it into the
// kernel session history.
//
// These tests pin BOTH halves with the faux provider (whose usage
// estimate serializes the request context — system prompt included):
//
//   1. INJECTION: a turn WITH a turn_context reports strictly more input
//      tokens than the same turn WITHOUT it (the block reached the model
//      request).
//   2. NO PERSISTENCE + NO ACCUMULATION: after two turns with two
//      different markers, NEITHER marker appears in the kernel session
//      JSONL, and turn 2's input estimate reflects exactly ONE marker
//      (not two — the v3.0.82 accumulation signature).

import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createInterface } from "node:readline";
import { afterEach, test } from "node:test";

const activeChildren = new Set();

class TurnContextClient {
  constructor(environment = {}) {
    this.child = spawn(process.execPath, ["dist/bridge.mjs"], {
      cwd: process.cwd(),
      stdio: ["pipe", "pipe", "pipe"],
      env: { ...process.env, ...environment },
    });
    this.pending = new Map();
    this.stderr = "";
    this.child.stderr.setEncoding("utf8");
    this.child.stderr.on("data", (chunk) => {
      this.stderr += chunk;
    });
    activeChildren.add(this.child);
    createInterface({ input: this.child.stdout }).on("line", (line) => {
      if (!line.trim()) return;
      let frame;
      try {
        frame = JSON.parse(line);
      } catch {
        return;
      }
      // Events (assistant_text_delta etc.) share the request id but are
      // NOT the response — only "response" frames resolve the request.
      if (frame.type === "event") return;
      const pending = this.pending.get(frame.id);
      if (pending) {
        this.pending.delete(frame.id);
        clearTimeout(pending.timeout);
        if (frame.error) {
          pending.reject(new Error(`${frame.error.message ?? "bridge error"}\n${this.stderr}`));
        } else {
          // Resolve the whole frame: `ok` lives at the top level, the
          // run_turn result (assistant text, usage, session_file...) in
          // `payload`.
          pending.resolve(frame);
        }
      }
    });
  }

  request(id, type, payload = {}, timeoutMs = 30_000) {
    this.child.stdin.write(`${JSON.stringify({ id, type, payload })}\n`);
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`Timed out waiting for ${type}: ${this.stderr}`));
      }, timeoutMs);
      this.pending.set(id, { resolve, reject, timeout });
    });
  }

  async close() {
    for (const pending of this.pending.values()) {
      clearTimeout(pending.timeout);
      pending.reject(new Error("client closed"));
    }
    this.pending.clear();
    this.child.stdin.end();
    if (!this.child.killed) this.child.kill();
    activeChildren.delete(this.child);
  }
}

afterEach(async () => {
  for (const child of activeChildren) {
    if (!child.killed) child.kill();
  }
  activeChildren.clear();
});

function fauxConfig() {
  return {
    provider_type: "faux",
    provider_config_id: "faux",
    pi_provider_id: "faux",
    pi_api: "faux",
    model_id: "faux-1",
    base_url: "http://localhost:0",
    reasoning: false,
    faux_response: "done",
  };
}

function turnPayload(sessionId, messages, extra = {}) {
  return {
    session_id: sessionId,
    model_config: fauxConfig(),
    system_prompt: "You are a test agent.",
    workspace_directory: process.cwd(),
    messages,
    host_tools: [],
    reasoning: "off",
    ...extra,
  };
}

function userMessage(text) {
  return { role: "user", content: [{ type: "text", text }] };
}

const MARKER_ONE = "EPHEMERAL-TURN-CONTEXT-MARKER-ONE ".repeat(20).trim();
const MARKER_TWO = "EPHEMERAL-TURN-CONTEXT-MARKER-TWO ".repeat(20).trim();
const markerTokens = Math.ceil(MARKER_ONE.length / 4);

test("turn context is injected into the model request but never persisted", async () => {
  const home = await mkdtemp(join(tmpdir(), "arix-turn-context-"));
  const client = new TurnContextClient({ HOME: home, USERPROFILE: home, PI_OFFLINE: "1" });
  try {
    const promptTokensOf = (frame) =>
      (frame.payload.usage?.input_tokens ?? 0) + (frame.payload.usage?.cached_input_tokens ?? 0);

    // Control session S1: three turns, NO turn_context ever.
    await client.request("c1", "run_turn", turnPayload("s-control", [userMessage("hello one")]));
    await client.request("c2", "run_turn", turnPayload("s-control", [userMessage("hello two")]));
    const control3 = await client.request(
      "c3",
      "run_turn",
      turnPayload("s-control", [userMessage("hello three")]),
    );
    assert.ok(control3.ok, JSON.stringify(control3.error));
    const controlPromptTokens = promptTokensOf(control3);

    // Marked session S2: SAME texts; the turn_context marker rides turns
    // 2 and 3 (per-turn injection — exactly like the memory block).
    await client.request("m1", "run_turn", turnPayload("s-marked", [userMessage("hello one")]));
    const marked2 = await client.request(
      "m2",
      "run_turn",
      turnPayload("s-marked", [userMessage("hello two")], { turn_context: MARKER_ONE }),
    );
    assert.ok(marked2.ok, JSON.stringify(marked2.error));
    const marked2PromptTokens = promptTokensOf(marked2);
    assert.ok(
      marked2PromptTokens >= controlPromptTokens - markerTokens + Math.floor(markerTokens * 0.6),
      `turn with a turn_context must carry the marker in the model request ` +
        `(marked ${marked2PromptTokens} vs control ${controlPromptTokens}, marker ${markerTokens})`,
    );

    const marked3 = await client.request(
      "m3",
      "run_turn",
      turnPayload("s-marked", [userMessage("hello three")], { turn_context: MARKER_ONE }),
    );
    assert.ok(marked3.ok, JSON.stringify(marked3.error));
    const marked3PromptTokens = promptTokensOf(marked3);

    // INJECTION: the marked session's request carries ~exactly ONE
    // marker over the control (the block reached the model request).
    const delta = marked3PromptTokens - controlPromptTokens;
    assert.ok(
      delta >= Math.floor(markerTokens * 0.6) && delta <= Math.ceil(markerTokens * 1.4),
      `turn 3 should carry exactly ONE marker over the control (delta ${delta}, marker ${markerTokens})`,
    );

    // NO PERSISTENCE: the kernel session JSONL contains NO marker.
    const journal = await readFile(marked3.payload.session_file, "utf8");
    assert.ok(
      !journal.includes("EPHEMERAL-TURN-CONTEXT-MARKER-ONE"),
      "the ephemeral context must NOT persist into the kernel session JSONL",
    );

    // NO ACCUMULATION: growth from turn 2 to turn 3 is the short new
    // exchange ONLY — not another copy of turn 2's marker (the v3.0.82
    // bug: every past user message kept its own prefix, so each turn
    // added one more marker to every subsequent request).
    const growth = marked3PromptTokens - marked2PromptTokens;
    assert.ok(
      growth <= 40,
      `turn-to-turn growth must be the new exchange only, not an accumulating marker (growth ${growth})`,
    );
  } finally {
    await client.close();
    await rm(home, { recursive: true, force: true });
  }
});

test("a turn without turn_context behaves exactly as before", async () => {
  const home = await mkdtemp(join(tmpdir(), "arix-turn-context-plain-"));
  const client = new TurnContextClient({ HOME: home, USERPROFILE: home, PI_OFFLINE: "1" });
  try {
    const firstFrame = await client.request(
      "plain-one",
      "run_turn",
      turnPayload("turn-context-plain", [userMessage("plain one")]),
    );
    assert.ok(firstFrame.ok, JSON.stringify(firstFrame.error));

    const secondFrame = await client.request(
      "plain-two",
      "run_turn",
      turnPayload("turn-context-plain", [userMessage("plain two")]),
    );
    assert.ok(secondFrame.ok, JSON.stringify(secondFrame.error));

    const journal = await readFile(secondFrame.payload.session_file, "utf8");
    assert.ok(journal.includes("plain one"));
    assert.ok(journal.includes("plain two"));
    assert.ok(!journal.includes("turn_context"));
  } finally {
    await client.close();
    await rm(home, { recursive: true, force: true });
  }
});
