/**
 * v3.0.38 — WARM CONNECTION dispatcher for the bridge runtime.
 *
 * HISTORY: undici's default keep-alive (4s) drops the provider's TLS/TCP
 * connection between chat turns, so every follow-up message paid a fresh
 * DNS + TCP + TLS handshake (~100-400ms on mobile) before the model
 * request even started. A 60s keep-alive keeps provider connections hot
 * across the gaps of a normal conversation. Feature-neutral: pooling
 * only changes connection reuse, never request semantics.
 *
 * v3.0.38 — PROXY REMOVAL (reliability + latency): the v3.0.33 network
 * proxy stack (manual Settings → Reliability proxy, Android system-proxy
 * auto-detection, curl-style env fallback and the v3.0.34 local-proxy
 * port probing) was removed entirely. The auto-detected configuration
 * could latch onto a stale Wi-Fi/global proxy that no longer forwards
 * traffic — every provider request then waited out the full connect
 * timeout through a dead tunnel, which is exactly the "AI responds very
 * late" symptom. The bridge now ALWAYS connects DIRECTLY with the warm
 * keep-alive tuning below; no proxy code path exists anywhere between
 * the app settings and the provider socket.
 */

import { Agent as UndiciAgent, setGlobalDispatcher } from "undici";

/** Warm-connection tuning for the direct dispatcher. */
const WARM_DISPATCHER_OPTIONS = {
  keepAliveTimeout: 60_000,
  keepAliveMaxTimeout: 120_000,
  connect: { timeout: 30_000 },
} as const;

/** Installs the global direct dispatcher with warm keep-alive tuning.
 * Called once at bridge startup; nothing can reconfigure it afterwards. */
export function installWarmDispatcher(): void {
  try {
    setGlobalDispatcher(new UndiciAgent({ ...WARM_DISPATCHER_OPTIONS }));
  } catch {
    // Non-fatal: keep whatever dispatcher is installed.
  }
}
