import { flushCompileCache } from "node:module";
import { AsyncLocalStorage } from "node:async_hooks";
import * as fs from "node:fs/promises";
import * as os from "node:os";
import * as path from "node:path";
import { createInterface } from "node:readline";
import { spawn } from "node:child_process";
import { stdin as input, stderr } from "node:process";
import {
  getSupportedThinkingLevels,
  clampThinkingLevel,
  createModels,
  createProvider,
  hasApi,
  defaultProviderAuthContext,
  fauxAssistantMessage,
  fauxProvider,
  fauxToolCall,
  InMemoryModelsStore,
  createAssistantMessageEventStream,
  type AuthContext,
  type AuthInteraction,
  type AssistantMessage,
  type AssistantMessageEvent,
  type AssistantMessageEventStream,
  type Context,
  type Credential,
  type CredentialInfo,
  type CredentialStore,
  type ImageContent,
  type Message,
  type Model,
  type Provider,
  type MutableModels,
  type ProviderStreams,
  type SimpleStreamOptions,
  type StreamOptions,
  type TextContent,
  type TranscriptContext,
  type Usage,
} from "@earendil-works/pi-ai";
import {
  builtinProviders,
  getBuiltinModels,
  getBuiltinProviders,
} from "@earendil-works/pi-ai/providers/all";
import { registerBunOAuthFlows } from "@earendil-works/pi-ai/bun-oauth";
import { installWarmDispatcher } from "./warm-dispatcher.js";
import {
  type AgentMessage,
  type AgentToolResult,
} from "@earendil-works/pi-agent-core";
import {
  AgentSession,
  DefaultResourceLoader,
  ModelRuntime,
  SessionManager,
  SettingsManager,
  createAgentSession,
  createBashToolDefinition,
  createLocalBashOperations,
  createEditToolDefinition,
  createFindToolDefinition,
  createGrepToolDefinition,
  createLsToolDefinition,
  createReadToolDefinition,
  createWriteToolDefinition,
  type AgentSessionEvent,
  type BashOperations,
  type EditOperations,
  type ReadOperations,
  type ToolDefinition,
  type WriteOperations,
  type ExtensionFactory,
} from "@earendil-works/pi-coding-agent";
import { openAICompletionsApi } from "@earendil-works/pi-ai/api/openai-completions.lazy";
import type { TSchema } from "typebox";
import { bridgeDebug, bridgeDiagnostic, elapsedMillis } from "./debug.js";
import {
  arixAppExtensionSnapshot,
  configureArixExtensionTransport,
  dispatchArixAppExtensionEvent,
  invokeArixAppExtensionAction,
  loadArixAppExtensions,
} from "./arix-extensions.js";
import {
  discoverArixExtensionPaths,
  discoverPackageExtensionPaths,
  installArixExtensionPackage,
  listArixExtensionPackages,
  removeArixExtensionPackage,
  updateArixExtensionPackage,
} from "./extensions.js";
import { reserveProtocolStdout, writeProtocolFrame } from "./protocol-output.js";

reserveProtocolStdout();

registerBunOAuthFlows();

const BRIDGE_VERSION = "2.0.0-alpha.0";
// v3.0.86 — Pi runtime upgraded 0.85.1 → 0.99.2 (bundled deps, protocol
// unchanged on the wire; the Kotlin PiKernelBridge version constants move
// with these).
const PI_AI_VERSION = "0.99.2";
const PI_AGENT_CORE_VERSION = "0.99.2";
const PI_CODING_AGENT_VERSION = "0.99.2";

/** v3.0.35 — SUBSCRIPTION (sign-in/OAuth) providers REMOVED per user
 * request: "remove all subscription providers including gemini too".
 * OpenAI Codex (ChatGPT sign-in), GitHub Copilot (Copilot sign-in) and the
 * v3.0.32 "gemini-subscription" (Google AI Pro/Ultra sign-in on the Code
 * Assist backend — see the deleted gemini-code-assist module) are gone from
 * the advertised catalog AND from login_provider resolution; every
 * remaining provider is API-key authenticated. Stored app configs that
 * referenced them resolve to "unconfigured" on the app side (the Kotlin
 * catalog no longer lists them) and are re-set-up with an API key.
 *
 * v3.0.79 — the v3.0.77 "gemini-cli" provider (Google sign-in, the
 * deleted ./gemini-cli.ts module) is REMOVED again per user request: its
 * browser OAuth + Code Assist onboarding never completed on the user's
 * device (the bridge's direct fetches to accounts.google.com /
 * oauth2.googleapis.com / cloudcode-pa.googleapis.com died with
 * ETIMEDOUT / ECONNREFUSED while the browser — a different network
 * stack — succeeded, leaving the flow stuck on "onboarding returned no
 * cloudaicompanion project"). It joins the removed-subscription set so
 * the advertised catalog, login_provider resolution and the credential
 * machinery all treat it as unknown, exactly like the v3.0.35 removals.
 * The API-key "google" provider (Google AI Studio) remains THE Gemini
 * path. */
const RemovedSubscriptionProviderIds = new Set([
  "openai-codex",
  "github-copilot",
  "gemini-subscription",
  "gemini-cli",
]);

/* v3.0.85 — the CEREBRAS and KIMI FOR CODING providers were REMOVED per
 * user request, mirroring the app-side PiProviderCatalog. They are
 * filtered from the advertised catalog and the built-in provider map;
 * a stored config for either id resolves app-side to the
 * OpenAI-compatible custom path (PiProviderCatalog.find misses → the
 * custom definition with the stored base URL), so nothing is lost for
 * existing users — they just re-see it as a custom endpoint. */
const RemovedProviderIds = new Set([
  ...RemovedSubscriptionProviderIds,
  "cerebras",
  "kimi-coding",
]);

const DEFAULT_AGENT_RETRY_MAX_RETRIES = 5;
// v2.9.12: free-tier survival — transient provider 429/5xx errors are retried
// with exponential backoff (honoring retry-after) instead of failing the turn.
const DEFAULT_PROVIDER_RETRY_MAX_RETRIES = 6;
const RUNTIME_OPERATION_CHUNK_BYTES = 64 * 1024;
const DEVELOPER_ROLE_ERROR_BODY_MAX_CHARS = 16 * 1024;

// v3.0.82 — PROACTIVE KEY ROTATION ("rotate near 250k, not after the 429").
// The v3.0.61/v3.0.63 rotation is REACTIVE: it fires only after a quota
// error already killed the in-flight request, which costs one full
// request round-trip, the retry budget and — on the Gemini free tier —
// surfaces "You exceeded your current quota … limit: 250000" as a chat
// error on single-key setups. This layer tracks ACTUAL per-key input
// token usage (from stream results) in a rolling one-minute window and
// rotates MECHANICALLY when the active key's projected usage for the
// next request crosses the budget threshold, so the request never lands
// on an exhausted key in the first place. Reactive rotation stays as the
// backstop (it also covers RPM-style limits the token window cannot
// predict).
const DEFAULT_KEY_ROTATION_TPM_BUDGET = 250_000;
const KEY_ROTATION_USAGE_WINDOW_MS = 60_000;
// Rotate when projected usage reaches 80% of the budget — enough headroom
// for one more large request to be caught mid-flight, not so early that a
// single big prompt burns through keys.
const KEY_ROTATION_THRESHOLD_FRACTION = 0.8;

type JsonObject = Record<string, unknown>;

interface BridgeRequest {
  id?: string;
  type?: string;
  payload?: JsonObject;
}

interface ModelConfig {
  provider_type: string;
  provider_config_id: string;
  pi_provider_id: string;
  pi_api: string;
  model_id: string;
  base_url: string;
  api_key?: string;
  /** v3.0.61 — MULTI-KEY POOL: every key (primary first). On quota
   * exhaustion the bridge rotates to the next key and re-issues the
   * request, so a running task never hard-stops on a daily free limit. */
  api_keys?: string[];
  custom_headers?: Record<string, string>;
  service_tier?: string;
  compatibility_mode?: boolean;
  supports_developer_role?: boolean;
  reasoning?: boolean;
  thinking_level_map?: Record<string, string | null>;
  /** v3.0.86 — MODEL CAPABILITIES resolved by the host from models.dev
   * (thinking levels, context window, output limit, input modalities).
   * When present they REPLACE the values Pi's bundled catalog would
   * otherwise supply: models.dev is the capability source of truth, Pi's
   * catalog only supplies transport details (api, compat, base URL). */
  models_dev?: ModelsDevMetadata;
  context_window?: number;
  max_tokens?: number;
  timeout_ms?: number;
  max_retries?: number;
  max_provider_retries?: number;
  max_retry_delay_ms?: number;
  auth_method?: "api_key" | "oauth" | "ambient";
  oauth_credential?: JsonObject;
  provider_env?: Record<string, string>;
  faux_response?: string;
  faux_tool_calls?: Array<{ name: string; arguments: JsonObject; id?: string }>;
  faux_tokens_per_second?: number;
  /** v3.0.82 — PROACTIVE KEY ROTATION BUDGET: per-key input-token budget
   * over a rolling minute (TPM). When the active key's projected usage
   * approaches this budget the bridge mechanically shifts to the next
   * key BEFORE the provider can return a 429 quota error, so long tasks
   * keep running instead of dying with "You exceeded your current quota".
   * Default 250,000 (the Gemini generate_content free-tier input-TPM
   * limit the user hit); 0 disables the proactive path (reactive 429
   * rotation stays). */
  key_rotation_tpm_budget?: number;
  /** v3.0.87 — MULTI-KEY MODE (Aharou port): master toggle. When false
   * the pool is ignored and the provider behaves as single-key. */
  multi_key_enabled?: boolean;
  /** v3.0.89 — PROACTIVE RPM BUDGET: per-key REQUEST budget over a
   * rolling minute. Free tiers (Gemini flash/lite, Groq…) enforce
   * requests-per-minute caps that the TPM window cannot predict (a
   * 20-RPM key dies while its token usage is still tiny). When the
   * active key's request count in the last minute approaches this
   * budget the bridge shifts to the next key pre-flight. Default 15
   * (safe under the common free-tier 20 RPM); 0 disables the RPM path. */
  key_rotation_rpm_budget?: number;
  /** v3.0.87 — how the pool picks the starting key: "sequential" (first
   * key, switch only on failure) or "round_robin" (each new turn starts
   * on the next key; requests inside one turn stay sticky so server-side
   * prompt caches survive). */
  key_rotation_strategy?: "sequential" | "round_robin";
  /** v3.0.87 — minutes a FAILED key is benched before rejoining the
   * pool (0 = no cooldown; default 5). */
  key_cooldown_minutes?: number;
  /** v3.0.87 — HTTP status codes that trigger an automatic switch
   * (empty/undefined = the Aharou default 401, 402, 403, 429). */
  key_switch_status_codes?: number[];
}

interface HostToolDefinition {
  name: string;
  description: string;
  parameters?: JsonObject;
  execution_mode?: "sequential" | "parallel";
}

interface PendingHostToolRequest {
  sessionId: string;
  resolve: (result: AgentToolResult<JsonObject>) => void;
  reject: (error: Error) => void;
  onUpdate?: (partialResult: AgentToolResult<JsonObject>) => void;
}

interface PendingRuntimeOperation {
  sessionId: string;
  resolve: (result: JsonObject) => void;
  reject: (error: Error) => void;
  onChunk?: (chunk: Buffer) => void;
}

interface AgentSessionState {
  sessionId: string;
  configSignature: string;
  // v3.0.50 — the kernel session is created with the turn's system
  // prompt (appendSystemPrompt); pi has no public per-turn system-prompt
  // override on AgentSession.prompt(). Without this signature a reused
  // session kept TURN 1's prompt forever: the app rebuilds the prompt
  // every turn (memory block, supervisor task-state block, session
  // context, expanded {{placeholders}}), and none of those updates ever
  // reached the model on later turns.
  systemPromptSignature: string;
  toolSignature: string;
  skillSignature: string;
  mcpConfigSignature: string;
  // v3.1.14 — extensions: the resolved Pi-extension path set is part of
  // the session's tool registry. Include its signature in the reuse key
  // so installing/enabling a package cannot leave an existing session
  // with a stale tool list.
  extensionSignature: string;
  configuredExtensionPaths: string[];
  pendingRecreate: boolean;
  workspaceDirectory: string;
  termuxWorkspaceDirectory: string;
  runtime: "termux";
  platform: "android" | "ios";
  modelRuntime: ModelRuntime;
  model: Model<string>;
  compatibilityFallbackState: CompatibilityFallbackState;
  credentialStore?: BridgeCredentialStore;
  session: AgentSession;
  resourceLoader: DefaultResourceLoader;
  settingsManager: SettingsManager;
  pendingReload: boolean;
  currentRequestId: string;
  turnStartedAtMillis?: number;
  firstAssistantEventAtMillis?: number;
  lastAgentEventAtMillis?: number;
  // v3.0.86 — WHOLE-TURN TOKEN TOTALS. Pi reports usage per API call; one
  // Arix turn can issue several calls (tool loops, auto retries, deferred
  // follow-ups), so the bridge accumulates them and hands the app a
  // per-turn total — including cache read/write tokens and the active
  // generation time (for tokens/second) that single-call usage cannot
  // express.
  turnUsage: TurnUsageTotals;
  outputStartedAtMillis?: number;
  outputDurationMillis: number;
  toolArgsById: Map<string, unknown>;
  lastAccessedAt: number;
  /** v2.9.16 (ACP): set when this kernel session serves an ACP session. */
  acpSessionId?: string;
  /**
   * v3.0.77 — dynamic-context preemptive-compaction trigger (fraction of
   * the context window). Refreshed by every run_turn from the turn's
   * classified tier; follow-up prompts reuse the latest value. Legacy
   * default 0.8 when no policy was ever supplied.
   */
  contextCompactThreshold: number;
  /**
   * v3.0.78 — true while this kernel session serves a MINIMAL-tier turn
   * (pure small talk / quick self-contained questions): the coding-agent
   * native tools (read/bash/edit/write/grep/find/ls) are NOT part of the
   * session — their schemas cost ~1.2k tokens a conversational turn never
   * uses. The tier flip on the next turn changes the tool signature, so
   * prepareNativeAgentSession recreates the session with the right set
   * (the JSONL conversation file persists across recreation).
   */
  minimalTools: boolean;
  /**
   * v3.0.83 — the per-turn ephemeral context (memory / session-context /
   * task-state) rides HERE, out-of-band. run_turn sets it before the turn
   * and clears it after; the provider stream wrapper appends it to the
   * outgoing MODEL REQUEST's system prompt at request time. It is never
   * written into the kernel session history, so token consumption stays
   * flat across turns (the v3.0.82 scheme prefixed the last user message,
   * which the kernel persisted — every past user message accumulated its
   * own copy of the block and usage grew turn over turn).
   */
  turnContextHolder: { context: string };
}

interface CompatibilityFallbackState {
  developerRoleUnsupportedDetected: boolean;
}

type PiThinkingLevel = "off" | "minimal" | "low" | "medium" | "high" | "xhigh" | "max";

const PI_THINKING_LEVELS: readonly PiThinkingLevel[] = [
  "off",
  "minimal",
  "low",
  "medium",
  "high",
  "xhigh",
  "max",
];

// Gemini's discrete thinkingLevel control only has these wire values; Pi's
// Google transport rejects any other mapping at request time.
const GOOGLE_THINKING_WIRE_LEVELS = new Set<string>(["minimal", "low", "medium", "high"]);

interface ModelsDevMetadata {
  reasoning?: boolean;
  /** Pi thinking levels the provider accepts for this model, from models.dev reasoning options. */
  thinking_levels?: PiThinkingLevel[];
  context_window?: number;
  max_tokens?: number;
  input?: Array<"text" | "image">;
}

// Pi reports usage per API call; one Arix turn can issue several calls
// (tool loops, auto retries, deferred follow-ups), so the bridge accumulates
// them and hands the app a per-turn total.
interface TurnUsageTotals {
  inputTokens: number;
  outputTokens: number;
  reasoningTokens: number;
  reasoningReported: boolean;
  cachedInputTokens: number;
  cacheWriteTokens: number;
  totalTokens: number;
  requestCount: number;
}

const activeAborters = new Map<string, () => void | Promise<unknown>>();
const pendingHostToolRequests = new Map<string, PendingHostToolRequest>();
const pendingRuntimeOperations = new Map<string, PendingRuntimeOperation>();
const pendingAuthPrompts = new Map<
  string,
  {
    resolve: (value: string) => void;
    reject: (error: Error) => void;
    requestId: string;
  }
>();
const agentSessions = new Map<string, AgentSessionState>();
// v3.0.30 — idle eviction for cached agent sessions. Each entry holds a
// ModelRuntime, the full AgentSession transcript, a resource loader and a
// tool registry; previously ONLY an explicit close_session removed entries,
// so a host that crashed/reconnected without closing (or one using
// per-request session ids) leaked them for the process lifetime. The
// already-maintained `lastAccessedAt` now drives a periodic sweep: entries
// idle beyond the window are closed and dropped — except kernel sessions
// still serving a live ACP session (their transcript lives only in the
// kernel session) and sessions mid-turn.
const AgentSessionIdleEvictMillis = 30 * 60 * 1000;

function sweepIdleAgentSessions(): void {
  const now = Date.now();
  for (const [sessionId, state] of agentSessions) {
    if (now - state.lastAccessedAt < AgentSessionIdleEvictMillis) continue;
    if (state.currentRequestId) continue;
    if (state.acpSessionId) {
      const record = acpSessions.get(state.acpSessionId);
      if (record && !record.closed) continue;
    }
    void closeNativeAgentSession(sessionId).catch(() => undefined);
  }
}
interface SharedCredentialState {
  credential?: Credential;
  queue: Promise<void>;
}

const sharedCredentialStates = new Map<string, SharedCredentialState>();

const builtinProviderById = new Map(
  builtinProviders()
    // v3.0.35 — subscription (sign-in) providers are not part of the
    // bridge's provider surface anymore. v3.0.85 — cerebras and
    // kimi-coding join the removed set (see RemovedProviderIds).
    .filter((provider) => !RemovedProviderIds.has(provider.id))
    .map((provider) => [provider.id, provider] as const),
);

/**
 * v3.0.32 — LATENCY: undici's default keep-alive (4s) drops the provider's
 * TLS/TCP connection between chat turns, so every follow-up message paid
 * a fresh DNS + TCP + TLS handshake (~100-400ms on mobile) before the
 * model request even started. A 60s keep-alive keeps provider connections
 * hot across the gaps of a normal conversation. Feature-neutral: pooling
 * only changes connection reuse, never request semantics.
 *
 * v3.0.38 — the v3.0.33 proxy-aware installer was removed with the whole
 * network-proxy stack (see warm-dispatcher.ts): the bridge now always
 * connects directly with the warm keep-alive tuning.
 */
installWarmDispatcher();
let defaultModelConfig: ModelConfig | undefined;
let hostToolCounter = 0;
let runtimeOperationCounter = 0;
let authPromptCounter = 0;
let compileCacheFlushed = false;

function flushStartupCompileCache(): void {
  if (compileCacheFlushed) return;
  compileCacheFlushed = true;
  try {
    flushCompileCache();
  } catch {
  }
}

class BridgeCredentialStore implements CredentialStore {
  private readonly state: SharedCredentialState;

  constructor(
    readonly providerId: string,
    providerConfigId: string,
    initialCredential?: Credential,
  ) {
    const existing = sharedCredentialStates.get(providerConfigId);
    if (existing) {
      // v3.0.50 — re-seed an EMPTY shared state. The app clears a
      // provider's credential (clear_provider_credential) on every
      // non-OAuth provider-config edit and re-sends the fresh key with
      // the next model_config; the shared entry used to keep
      // `credential: undefined` forever (the constructor discarded
      // initialCredential whenever an entry existed), so every request
      // after ANY provider edit failed with "No API key found for …"
      // until the bridge process was restarted. Seeding through the queue
      // keeps the serialization discipline; an existing credential is
      // still authoritative (key rotation goes through clear + resend).
      if (existing.credential === undefined && initialCredential !== undefined) {
        existing.queue = existing.queue
          .then(() => {
            if (existing.credential === undefined) existing.credential = initialCredential;
          })
          .catch(() => undefined);
      }
      this.state = existing;
    } else {
      this.state = { credential: initialCredential, queue: Promise.resolve() };
      sharedCredentialStates.set(providerConfigId, this.state);
    }
  }

  async read(providerId: string): Promise<Credential | undefined> {
    if (providerId !== this.providerId) return undefined;
    const startedAt = Date.now();
    bridgeDebug("credential_read_start", { provider_id: providerId });
    await this.state.queue;
    bridgeDebug("credential_read_done", {
      provider_id: providerId,
      has_credential: this.state.credential !== undefined,
      elapsed_ms: elapsedMillis(startedAt),
    });
    return this.state.credential;
  }

  async list(): Promise<readonly CredentialInfo[]> {
    await this.state.queue;
    const credential = this.state.credential;
    return credential ? [{ providerId: this.providerId, type: credential.type }] : [];
  }

  async modify(
    providerId: string,
    fn: (current: Credential | undefined) => Promise<Credential | undefined>,
  ): Promise<Credential | undefined> {
    if (providerId !== this.providerId) return undefined;
    const startedAt = Date.now();
    bridgeDebug("credential_modify_start", { provider_id: providerId });
    let result: Credential | undefined;
    const operation = this.state.queue.then(async () => {
      const next = await fn(this.state.credential);
      if (next !== undefined) this.state.credential = next;
      result = this.state.credential;
    });
    this.state.queue = operation.catch(() => undefined);
    try {
      await operation;
      bridgeDebug("credential_modify_done", {
        provider_id: providerId,
        elapsed_ms: elapsedMillis(startedAt),
      });
    } catch (error) {
      bridgeDebug("credential_modify_failed", {
        provider_id: providerId,
        error: errorMessageWithCause(error),
        elapsed_ms: elapsedMillis(startedAt),
      });
      throw error;
    }
    return result;
  }

  async delete(providerId: string): Promise<void> {
    if (providerId !== this.providerId) return;
    bridgeDebug("credential_delete_start", { provider_id: providerId });
    const operation = this.state.queue.then(() => {
      this.state.credential = undefined;
    });
    this.state.queue = operation.catch(() => undefined);
    await operation;
    bridgeDebug("credential_delete_done", { provider_id: providerId });
  }

  /**
   * v3.0.50 — seed a credential only when the shared state is EMPTY.
   * Used on the session-reuse path so a state emptied by
   * clear_provider_credential (the app clears on every provider-config
   * edit) heals from the model_config the next turn still carries; an
   * existing credential (e.g. a refreshed OAuth token) is untouched.
   */
  async seedIfEmpty(credential: Credential): Promise<void> {
    bridgeDebug("credential_seed_if_empty", { provider_id: this.providerId });
    const operation = this.state.queue.then(() => {
      if (this.state.credential === undefined) this.state.credential = credential;
    });
    this.state.queue = operation.catch(() => undefined);
    await operation;
  }
}

async function replaceSharedCredential(
  providerConfigId: string,
  credential: Credential,
): Promise<void> {
  bridgeDebug("shared_credential_replace", { provider_config_id: providerConfigId });
  const existing = sharedCredentialStates.get(providerConfigId);
  if (!existing) {
    sharedCredentialStates.set(providerConfigId, {
      credential,
      queue: Promise.resolve(),
    });
    return;
  }
  const operation = existing.queue.then(() => {
    existing.credential = credential;
  });
  existing.queue = operation.catch(() => undefined);
  await operation;
}

async function clearSharedCredential(providerConfigId: string): Promise<boolean> {
  bridgeDebug("shared_credential_clear", { provider_config_id: providerConfigId });
  const existing = sharedCredentialStates.get(providerConfigId);
  if (!existing) return false;
  const operation = existing.queue.then(() => {
    existing.credential = undefined;
  });
  existing.queue = operation.catch(() => undefined);
  await operation;
  // v3.0.50 — drop the entry entirely. Leaving an entry with
  // `credential: undefined` made the NEXT BridgeCredentialStore
  // construction (from the model_config that follows a provider edit)
  // silently discard its initialCredential and fail every request with
  // "No API key found for …" / "Provider is not configured" until the
  // bridge restarted. Deleting it lets the next construction seed a
  // fresh state from the current model_config.
  sharedCredentialStates.delete(providerConfigId);
  return true;
}

// ------------------------------------------------------------------ //
// v3.0.61 — MULTI-KEY POOL: automatic key rotation on quota exhaustion.
//
// User requirement: "a mechanism [for a] multiple key add system so if
// one daily free limit expire auto shift next key and without stop
// complete the task". The app sends the FULL key pool (primary first)
// in model_config.api_keys; when a provider request fails with a
// QUOTA/429-style error and another key is available, the bridge
// switches the active credential to the next key and re-issues the SAME
// request transparently — the agent loop, the task and the streaming UX
// continue without interruption. pi-ai's own retry logic still handles
// TRANSIENT throttles (short 429s with retry-after) first; rotation
// only kicks in when that retry budget is exhausted, i.e. the key is
// genuinely out of quota.
// ------------------------------------------------------------------ //

interface KeyRotationState {
  keys: string[];
  activeIndex: number;
  /** v3.0.87 — Aharou port: keyIndex → epoch-ms until which the key is
   * benched after a failure (cooldown). Entries are lazily pruned. */
  cooldownUntil: Map<number, number>;
}

const keyRotationStates = new Map<string, KeyRotationState>();

// v3.0.87 — Aharou default status codes that switch keys: auth (401),
// billing (402), permission (403), rate limit (429).
const DEFAULT_KEY_SWITCH_STATUS_CODES = [401, 402, 403, 429];

/** The effective switch-trigger codes (custom set replaces default). */
function keySwitchStatusCodes(config: ModelConfig): number[] {
  const custom = config.key_switch_status_codes;
  if (Array.isArray(custom) && custom.length > 0) return custom;
  return DEFAULT_KEY_SWITCH_STATUS_CODES;
}

/** Whether the ACTIVE key is currently benched (cooldown). */
function keyInCooldown(state: KeyRotationState, keyIndex: number, now = Date.now()): boolean {
  const until = state.cooldownUntil.get(keyIndex) ?? 0;
  if (until <= 0) return false;
  if (now >= until) {
    state.cooldownUntil.delete(keyIndex);
    return false;
  }
  return true;
}

/** v3.0.87 — cooldown minutes for failed keys (0 = disabled). */
function keyCooldownMillis(config: ModelConfig): number {
  const minutes = Math.max(0, Math.floor(config.key_cooldown_minutes ?? 5));
  return minutes * 60_000;
}

// v3.0.82 — rolling per-key input-token usage (the proactive-rotation
// signal). Keyed by "<provider_config_id>#<key index>"; every entry is
// {at, tokens} with `at` inside the last KEY_ROTATION_USAGE_WINDOW_MS.
const keyUsageWindows = new Map<string, Array<{ at: number; tokens: number }>>();

// v3.0.89 — rolling per-key REQUEST counts (the RPM proactive-rotation
// signal). Same keying and window as the token map; entries are
// timestamps only (a request is one count regardless of size).
const keyRequestWindows = new Map<string, number[]>();

/** v3.0.89 — default RPM budget (see ModelConfig.key_rotation_rpm_budget).
 *  15 sits safely under the common free-tier 20-RPM caps; single-key
 *  pools are never rotated (effectiveApiKeys length check upstream). */
const DEFAULT_KEY_ROTATION_RPM_BUDGET = 15;

function keyUsageWindowKey(config: ModelConfig, keyIndex: number): string {
  return `${config.provider_config_id}#${keyIndex}`;
}

/** v3.0.89 — records one REQUEST on a key (RPM window). */
function recordKeyRequest(config: ModelConfig, key: string): void {
  const state = keyRotationStates.get(config.provider_config_id);
  if (!state) return;
  const keyIndex = state.keys.indexOf(key);
  if (keyIndex < 0) return;
  const windowKey = keyUsageWindowKey(config, keyIndex);
  const now = Date.now();
  const window = keyRequestWindows.get(windowKey) ?? [];
  window.push(now);
  while (window.length > 0 && now - window[0] > KEY_ROTATION_USAGE_WINDOW_MS) {
    window.shift();
  }
  keyRequestWindows.set(windowKey, window);
}

/** v3.0.89 — requests the key made in the rolling window. */
function recentKeyRequests(config: ModelConfig, keyIndex: number, now = Date.now()): number {
  const window = keyRequestWindows.get(keyUsageWindowKey(config, keyIndex));
  if (!window || window.length === 0) return 0;
  while (window.length > 0 && now - window[0] > KEY_ROTATION_USAGE_WINDOW_MS) {
    window.shift();
  }
  return window.length;
}

/** v3.0.89 — the per-config RPM budget (0 = RPM rotation disabled). */
function keyRotationRpmBudget(config: ModelConfig): number {
  const raw = config.key_rotation_rpm_budget;
  const numeric = typeof raw === "number" && Number.isFinite(raw) ? raw : Number.NaN;
  if (!Number.isFinite(numeric)) return DEFAULT_KEY_ROTATION_RPM_BUDGET;
  return Math.max(0, Math.floor(numeric));
}

/** Records ACTUAL input tokens consumed by a request on a given key. */
function recordKeyInputTokens(config: ModelConfig, key: string, inputTokens: number): void {
  if (!Number.isFinite(inputTokens) || inputTokens <= 0) return;
  const state = keyRotationStates.get(config.provider_config_id);
  if (!state) return;
  const keyIndex = state.keys.indexOf(key);
  if (keyIndex < 0) return;
  const windowKey = keyUsageWindowKey(config, keyIndex);
  const now = Date.now();
  const window = keyUsageWindows.get(windowKey) ?? [];
  window.push({ at: now, tokens: Math.ceil(inputTokens) });
  pruneKeyUsageWindow(window, now);
  keyUsageWindows.set(windowKey, window);
}

function pruneKeyUsageWindow(window: Array<{ at: number; tokens: number }>, now: number): void {
  while (window.length > 0 && now - window[0].at > KEY_ROTATION_USAGE_WINDOW_MS) {
    window.shift();
  }
}

/** Input tokens the key consumed in the rolling window (0 when unknown). */
function recentKeyInputTokens(config: ModelConfig, keyIndex: number, now = Date.now()): number {
  const window = keyUsageWindows.get(keyUsageWindowKey(config, keyIndex));
  if (!window || window.length === 0) return 0;
  pruneKeyUsageWindow(window, now);
  return window.reduce((total, sample) => total + sample.tokens, 0);
}

/** The per-config TPM budget (0 = proactive rotation disabled). */
function keyRotationTpmBudget(config: ModelConfig): number {
  const raw = config.key_rotation_tpm_budget;
  const numeric = typeof raw === "number" && Number.isFinite(raw) ? raw : Number.NaN;
  if (!Number.isFinite(numeric)) return DEFAULT_KEY_ROTATION_TPM_BUDGET;
  return Math.max(0, Math.floor(numeric));
}

/**
 * v3.0.82 — the mechanical pre-flight check. Estimates the input tokens
 * the NEXT request will cost (message bodies + system prompt), projects
 * the ACTIVE key's rolling usage against the budget and, when it would
 * cross the threshold, advances to the next key with headroom. Returns
 * the key the request should use (the rotated one) or undefined to keep
 * the current key.
 */
function rotateForTokenBudget(
  config: ModelConfig,
  estimatedInputTokens: number,
): string | undefined {
  const budget = keyRotationTpmBudget(config);
  // v3.0.89 — the RPM budget joins the TPM budget as a second proactive
  // signal (free tiers die on requests-per-minute long before tokens).
  const rpmBudget = keyRotationRpmBudget(config);
  const state = keyRotationStates.get(config.provider_config_id);
  if (!state || state.keys.length <= 1) return undefined;
  const threshold = Math.floor(budget * KEY_ROTATION_THRESHOLD_FRACTION);
  const now = Date.now();
  const activeUsage = recentKeyInputTokens(config, state.activeIndex, now);
  const activeRequests = recentKeyRequests(config, state.activeIndex, now);
  const tpmHot =
    budget > 0 && activeUsage + Math.max(estimatedInputTokens, 0) > threshold;
  const rpmHot =
    rpmBudget > 0 &&
    activeRequests + 1 >= Math.max(1, Math.floor(rpmBudget * KEY_ROTATION_THRESHOLD_FRACTION));
  if (!tpmHot && !rpmHot) return undefined;
  // The active key is near its budget — mechanically shift to the next
  // key with the most headroom ("same vice versa do each key": when every
  // key is loaded, fall back to the LEAST-used one; the rolling window
  // keeps expiring so an exhausted pool recovers automatically).
  let bestIndex = -1;
  let bestScore = Number.POSITIVE_INFINITY;
  for (let offset = 1; offset <= state.keys.length; offset += 1) {
    const candidate = (state.activeIndex + offset) % state.keys.length;
    const usage = recentKeyInputTokens(config, candidate, now);
    const requests = recentKeyRequests(config, candidate, now);
    // v3.0.89 — a request-count-first score: under RPM pressure the key
    // with the fewest recent requests wins even if it carried more tokens.
    const score = requests * 1_000_000 + usage;
    if (score < bestScore) {
      bestScore = score;
      bestIndex = candidate;
    }
    if (score === 0) break; // untouched key — perfect headroom
  }
  if (bestIndex < 0 || bestIndex === state.activeIndex) return undefined;
  const projectedBest = recentKeyInputTokens(config, bestIndex, now) + Math.max(estimatedInputTokens, 0);
  const projectedActive = activeUsage + Math.max(estimatedInputTokens, 0);
  // Only rotate when the candidate is genuinely better; when the whole
  // pool is equally saturated keep the active key (the reactive layer
  // and the retry budget still handle the tail of the window). Under
  // RPM pressure the token projection is not the deciding signal, so
  // the rpmHot branch bypasses the token-only comparison.
  if (!rpmHot && projectedBest >= projectedActive) return undefined;
  state.activeIndex = bestIndex;
  bridgeDebug("api_key_rotated_proactive", {
    provider_config_id: config.provider_config_id,
    key_index: bestIndex,
    pool_size: state.keys.length,
    active_window_tokens: activeUsage,
    active_window_requests: activeRequests,
    estimated_request_tokens: estimatedInputTokens,
    tpm_budget: budget,
    rpm_budget: rpmBudget,
  });
  return state.keys[bestIndex];
}

/** Rough input-token estimate for a request context (4 chars/token,
 * consistent with the kernel's own estimator). */
function estimateContextInputTokens(context: { messages?: unknown; systemPrompt?: unknown }): number {
  let chars = 0;
  try {
    chars += JSON.stringify(context.messages ?? []).length;
  } catch {
    chars += 4_000;
  }
  const systemPrompt = typeof context.systemPrompt === "string" ? context.systemPrompt : "";
  chars += systemPrompt.length;
  return Math.ceil(chars / 4);
}

/** The blank-free, deduplicated pool for a config — primary key first.
 * v3.0.87 — MULTI-KEY MODE toggle: a disabled multi-key mode degrades
 * to the single primary key (Aharou semantics; legacy v3.0.61 configs
 * that never carried the flag default to enabled). */
function effectiveApiKeys(config: ModelConfig): string[] {
  const pool = Array.isArray(config.api_keys) ? config.api_keys : [];
  if (config.multi_key_enabled === false) {
    const primary = (config.api_key ?? "").trim();
    return primary ? [primary] : [];
  }
  return [...new Set([config.api_key ?? "", ...pool].map((key) => key.trim()).filter(Boolean))];
}

/**
 * Registers/refreshes the pool for a config. Called on every
 * buildModels; keeps the CURRENT active key across turns when it is
 * still part of the (possibly edited) pool, resets to the primary
 * otherwise. Single-key configs (the common case) carry no state.
 *
 * v3.0.87 — ROUND_ROBIN strategy (Aharou port): each new TURN starts on
 * the next non-cooling key so quota spreads across the pool; requests
 * inside one turn stay on one key (prompt-cache friendly). buildModels
 * runs once per run_turn / complete_once, so advancing here equals
 * per-turn rotation.
 */
function registerKeyPool(config: ModelConfig): void {
  const keys = effectiveApiKeys(config);
  if (keys.length <= 1) {
    keyRotationStates.delete(config.provider_config_id);
    return;
  }
  const existing = keyRotationStates.get(config.provider_config_id);
  if (existing) {
    const activeKey = existing.keys[existing.activeIndex];
    const preservedIndex = activeKey ? keys.indexOf(activeKey) : -1;
    existing.keys = keys;
    existing.activeIndex = preservedIndex >= 0 ? preservedIndex : 0;
    if (config.key_rotation_strategy === "round_robin") {
      advanceRoundRobin(config, existing);
    }
  } else {
    const state: KeyRotationState = { keys, activeIndex: 0, cooldownUntil: new Map() };
    keyRotationStates.set(config.provider_config_id, state);
  }
}

/** v3.0.87 — advances to the NEXT non-cooling key (round-robin). */
function advanceRoundRobin(config: ModelConfig, state: KeyRotationState): void {
  const now = Date.now();
  for (let offset = 1; offset <= state.keys.length; offset += 1) {
    const candidate = (state.activeIndex + offset) % state.keys.length;
    if (!keyInCooldown(state, candidate, now)) {
      state.activeIndex = candidate;
      bridgeDebug("api_key_round_robin", {
        provider_config_id: config.provider_config_id,
        key_index: candidate,
        pool_size: state.keys.length,
      });
      return;
    }
  }
  // Every key is cooling — keep the current one.
}

/** LLM7 documents an anonymous `Authorization: Bearer <any>` usage for its
 * free tier — a REMOVED Authorization header is rejected there, so keep the
 * placeholder bearer on the wire for that host (unlike Kilo/Pollinations). */
function usesDocumentedAnonymousBearer(baseUrl: string | undefined): boolean {
  try {
    return new URL(baseUrl ?? "").hostname === "api.llm7.io";
  } catch {
    return false;
  }
}

/** The key a NEW request should use (rotated active key or the primary).
 * v3.0.87 — lazy cooldown recovery: when the active key is benched the
 * cursor moves to the first AVAILABLE one (Aharou semantics — a cooled
 * key automatically rejoins once its window expires). */
function activeApiKeyFor(config: ModelConfig): string {
  const state = keyRotationStates.get(config.provider_config_id);
  if (!state) return config.api_key ?? "";
  if (keyInCooldown(state, state.activeIndex)) {
    for (let offset = 1; offset <= state.keys.length; offset += 1) {
      const candidate = (state.activeIndex + offset) % state.keys.length;
      if (!keyInCooldown(state, candidate)) {
        state.activeIndex = candidate;
        break;
      }
    }
  }
  return state.keys[state.activeIndex] ?? config.api_key ?? "";
}

const DAILY_QUOTA_PATTERN = /per[ _-]?day|daily|\bRPD\b|free[ _-]?tier.*day/i;
const MINUTE_QUOTA_PATTERN = /per[ _-]?minute|\bRPM\b|\bTPM\b|requests?[ _-]per[ _-]?min|rate[ _-]?limit/i;

/** Seconds a provider asks us to wait ("retry in 23.4s", retryDelay "23s", Retry-After: 30). */
function retryDelayMillisFromError(message: string): number | undefined {
  const text = message.replace(/\s+/g, " ");
  const match =
    /retry[ _-]?delay"?\s*[:=]\s*"?(\d+(?:\.\d+)?)\s*(ms|s|m)?/i.exec(text) ??
    /retry(?:ing)?[ _-]?(?:in|after)\s*:?\s*(\d+(?:\.\d+)?)\s*(ms|s|sec|seconds|m|min|minutes)?/i.exec(text);
  if (!match) return undefined;
  const value = Number(match[1]);
  if (!Number.isFinite(value) || value < 0) return undefined;
  const unit = (match[2] ?? "s").toLowerCase();
  if (unit === "ms") return Math.ceil(value);
  if (unit.startsWith("m")) return Math.ceil(value * 60_000);
  return Math.ceil(value * 1000);
}

/**
 * How long the failing key sits out. Per-minute limits (Gemini RPM/TPM)
 * recover within a minute, so the key is benched only for the provider's
 * own retry delay (or 60 s) instead of the long configured cooldown that
 * suits daily quotas. Daily quotas and auth failures keep the configured
 * cooldown.
 */
function cooldownForFailure(config: ModelConfig, errorMessage: string): number {
  const configured = keyCooldownMillis(config);
  if (configured <= 0 || !errorMessage) return configured;
  if (DAILY_QUOTA_PATTERN.test(errorMessage)) return configured;
  const delay = retryDelayMillisFromError(errorMessage);
  if (delay !== undefined) return Math.min(configured, Math.max(2_000, delay + 1_000));
  if (MINUTE_QUOTA_PATTERN.test(errorMessage)) return Math.min(configured, 60_000);
  return configured;
}

/** True when some OTHER key could take over right now (so a throttled request need not wait). */
function hasFailoverKey(config: ModelConfig): boolean {
  const state = keyRotationStates.get(config.provider_config_id);
  if (!state || state.keys.length <= 1) return false;
  const now = Date.now();
  for (let offset = 1; offset < state.keys.length; offset += 1) {
    if (!keyInCooldown(state, (state.activeIndex + offset) % state.keys.length, now)) return true;
  }
  return false;
}

/**
 * Advances to the NEXT usable key and BENCHES the failing one (v3.0.87
 * Aharou port: cooldown minutes; the last available key is never
 * benched — cooling it would lock the user out entirely). Returns the
 * key, or undefined when the whole pool is exhausted.
 */
function rotateToNextKey(config: ModelConfig, errorMessage = ""): string | undefined {
  const state = keyRotationStates.get(config.provider_config_id);
  if (!state) return undefined;
  const now = Date.now();
  // v3.0.87 — the failing key is only benched when an alternative EXISTS
  // (Aharou's last-key protection). NOTE: offset runs 1..len-1 — the
  // CURRENT key is never a rotation target (offset == len would wrap
  // back onto the active index and re-use the just-failed key).
  let nextIndex = -1;
  for (let offset = 1; offset < state.keys.length; offset += 1) {
    const candidate = (state.activeIndex + offset) % state.keys.length;
    if (!keyInCooldown(state, candidate, now)) {
      nextIndex = candidate;
      break;
    }
  }
  if (nextIndex < 0) return undefined;
  const cooldown = cooldownForFailure(config, errorMessage);
  if (cooldown > 0) {
    state.cooldownUntil.set(state.activeIndex, now + cooldown);
  }
  state.activeIndex = nextIndex;
  bridgeDebug("api_key_rotated", {
    provider_config_id: config.provider_config_id,
    key_index: nextIndex,
    pool_size: state.keys.length,
    cooldown_ms: cooldown,
  });
  return state.keys[nextIndex];
}

/**
 * Quota-exhaustion signatures across providers: HTTP 429 bodies,
 * "rate limit", Google's RESOURCE_EXHAUSTED, OpenAI's "exceeded your
 * current quota", daily/free-tier limits, requests-per-minute caps.
 */
const QUOTA_EXHAUSTION_PATTERN =
  /(?:\b429\b|too many requests|rate[ _-]?limit|resource[ _-]?exhausted|quota|daily[ _-]?(?:limit|quota|free)|(?:requests?|tokens?)[ _-]per[ _-]?(?:minute|second|day)|limit[ _-]?(?:reached|exceeded)|free[ _-]?tier|exceeded[ _-]?(?:your|the)[ _-]?(?:current[ _-]?)?(?:quota|limit)|plan[ _-]?(?:and[ _-]?)?billing)/i;

function isQuotaExhaustionError(errorMessage: string): boolean {
  return QUOTA_EXHAUSTION_PATTERN.test(errorMessage.replace(/\s+/g, " ").trim());
}

/**
 * v3.0.87 — MULTI-KEY MODE (Aharou port): a first-event error switches
 * keys when it is a quota-style failure OR its message carries one of
 * the CONFIGURED HTTP status codes. A custom code set REPLACES the
 * default 401/402/403/429 exactly like Aharou's "Auto-switch status
 * codes" field; the quota TEXT signatures stay as a fixed fallback
 * (Aharou's KEY_FAILURE_MESSAGES equivalent).
 */
function isKeySwitchFailure(config: ModelConfig, errorMessage: string): boolean {
  if (isQuotaExhaustionError(errorMessage)) return true;
  const codes = keySwitchStatusCodes(config);
  if (codes.length === 0) return false;
  const normalized = errorMessage.replace(/\s+/g, " ").trim();
  return codes.some((code) =>
    new RegExp(`(?:^|[^0-9])${code}(?:[^0-9]|$)`).test(normalized),
  );
}

/**
 * Wraps a ProviderStreams so a FIRST-EVENT quota error rotates the key
 * and replays the request (once per remaining key). Errors that arrive
 * mid-stream (after content) pass through untouched, as do every other
 * error kinds — rotation never masks real failures.
 */
function withKeyRotation(
  streams: ProviderStreams,
  config: ModelConfig,
): ProviderStreams {
  if (effectiveApiKeys(config).length <= 1) return streams;
  return {
    ...streams,
    stream: rotatedStreamCall(config, streams.stream.bind(streams)) as ProviderStreams["stream"],
    streamSimple: rotatedStreamCall(config, streams.streamSimple.bind(streams)) as ProviderStreams["streamSimple"],
  };
}

/**
 * v3.0.61 — wraps a whole PROVIDER (built-in path: the api lives inside
 * the provider's stream/streamSimple dispatch and cannot be swapped
 * after construction). Every member delegates to the original; only the
 * two stream entry points get the quota-rotation retry.
 */
function withProviderKeyRotation(provider: Provider, config: ModelConfig): Provider {
  if (effectiveApiKeys(config).length <= 1) return provider;
  return {
    ...provider,
    stream: rotatedStreamCall(
      config,
      provider.stream.bind(provider),
    ) as Provider["stream"],
    streamSimple: rotatedStreamCall(
      config,
      provider.streamSimple.bind(provider),
    ) as Provider["streamSimple"],
  };
}

/**
 * v3.0.83 — TURN-CONTEXT REQUEST-TIME INJECTION (the token-regression
 * fix). The app ships the per-turn ephemeral context (memory /
 * session-context / task-state) as the run_turn payload's `turn_context`
 * field; runNativeAgentTurn stashes it in the session's holder and this
 * wrapper appends it to the OUTGOING MODEL REQUEST's system prompt right
 * before the provider call. The kernel session history is never touched,
 * so the block is model-visible for exactly the requests of THIS turn
 * (v3.0.81 token parity) while the kernel session stays byte-stable and
 * reusable across turns (the v3.0.82 latency win). Applied OUTERMOST
 * (around the key-rotation wrapper) so the rotation budget estimator
 * also sees the injected tokens.
 */
function withTurnContextProvider(provider: Provider, holder: { context: string }): Provider {
  return {
    ...provider,
    stream: turnContextStreamCall(
      holder,
      provider.stream.bind(provider),
    ) as Provider["stream"],
    streamSimple: turnContextStreamCall(
      holder,
      provider.streamSimple.bind(provider),
    ) as Provider["streamSimple"],
  };
}

/** The stream-level half of the turn-context injection wrapper. */
function withTurnContextStreams(streams: ProviderStreams, holder: { context: string }): ProviderStreams {
  return {
    ...streams,
    stream: turnContextStreamCall(holder, streams.stream.bind(streams)) as ProviderStreams["stream"],
    streamSimple: turnContextStreamCall(holder, streams.streamSimple.bind(streams)) as ProviderStreams["streamSimple"],
  };
}

function turnContextStreamCall<
  TModel extends Model<string>,
  TOptions extends StreamOptions | SimpleStreamOptions | undefined,
>(
  holder: { context: string },
  call: (model: TModel, context: TranscriptContext, options: TOptions) => AssistantMessageEventStream,
): (model: TModel, context: TranscriptContext, options: TOptions) => AssistantMessageEventStream {
  return (model, context, options) => {
    const turnContext = holder.context.trim();
    if (!turnContext) return call(model, context, options);
    return call(model, appendToTranscriptSystemPrompt(context, turnContext), options);
  };
}

/**
 * v3.0.86 — pi 0.99.2 replaced the provider-level `systemPrompt` field
 * with a NORMALIZED transcript (`TranscriptContext`): the prompt rides in
 * the leading system message, produced only by `normalizeContext`. The
 * turn-context injection therefore appends to that leading system message
 * (string content concatenated; structured TextContent appended as a text
 * block) instead of writing a `systemPrompt` field that no longer exists.
 */
function appendToTranscriptSystemPrompt(context: TranscriptContext, addition: string): TranscriptContext {
  const messages = [...context.messages];
  const leading = messages[0];
  if (leading && leading.role === "system") {
    if (typeof leading.content === "string") {
      messages[0] = {
        ...leading,
        content: leading.content ? `${leading.content}\n\n${addition}` : addition,
      } as typeof leading;
    } else {
      messages[0] = {
        ...leading,
        content: [...(leading.content ?? []), { type: "text", text: `\n\n${addition}` }],
      } as typeof leading;
    }
  } else {
    messages.unshift({ role: "system", content: addition } as (typeof messages)[number]);
  }
  return { messages } as unknown as TranscriptContext;
}

/** The shared rotation replay used by both wrappers above. */
function rotatedStreamCall<
  TModel extends Model<string>,
  TOptions extends StreamOptions | SimpleStreamOptions | undefined,
>(
  config: ModelConfig,
  call: (model: TModel, context: TranscriptContext, options: TOptions) => AssistantMessageEventStream,
): (model: TModel, context: TranscriptContext, options: TOptions) => AssistantMessageEventStream {
  return (model, context, options) => {
    const output = createAssistantMessageEventStream();
    void (async () => {
      let rotationsThisRequest = 0;
      let lastQuotaError: AssistantMessage | undefined;
      // v3.0.82 — PROACTIVE pre-flight: rotate BEFORE the request when the
      // active key's rolling input-token usage is near the TPM budget, so
      // the call never lands on a key the provider is about to reject.
      // The override mirrors the reactive replay below (options.apiKey plus
      // the shared credential for builtin providers).
      const proactiveKey = rotateForTokenBudget(config, estimateContextInputTokens(context));
      if (proactiveKey !== undefined) {
        options = { ...options, apiKey: proactiveKey } as TOptions;
        if (config.provider_type === "builtin") {
          await replaceSharedCredential(config.provider_config_id, {
            type: "api_key",
            key: proactiveKey,
            ...(Object.keys(config.provider_env ?? {}).length > 0
              ? { env: config.provider_env }
              : {}),
          } as Credential);
        }
        emitArixSubscriberEvent("provider_key_rotated", {
          provider_config_id: config.provider_config_id,
          key_index: keyRotationStates.get(config.provider_config_id)?.activeIndex ?? 0,
          pool_size: effectiveApiKeys(config).length,
          attempt: 0,
          reason: "token_budget",
        });
      }
      // v3.0.82 — the key THIS request actually uses (for usage tracking).
      const optionApiKey = (options as { apiKey?: unknown }).apiKey;
      let requestKey =
        typeof optionApiKey === "string" && optionApiKey.trim()
          ? optionApiKey.trim()
          : activeApiKeyFor(config);
      // v3.0.89 — RPM window: this request counts against its key the
      // moment it leaves (the 429 arrives too late to count it).
      recordKeyRequest(config, requestKey);
      while (true) {
        // FAST FAILOVER: while another key is ready, a throttled request must
        // not sit through pi-ai's backoff on the exhausted key - surface the
        // 429 at once so the same request is replayed on the next key. With
        // no spare key left the normal retry/backoff budget applies.
        const attemptOptions = hasFailoverKey(config)
          ? ({ ...options, maxRetries: 0 } as TOptions)
          : options;
        const attempt = call(model, context, attemptOptions);
        const iterator = attempt[Symbol.asyncIterator]();
        const first = await iterator.next();
        if (
          !first.done &&
          first.value.type === "error" &&
          isKeySwitchFailure(config, first.value.error.errorMessage ?? "")
        ) {
          lastQuotaError = first.value.error;
          const nextKey = rotateToNextKey(config, first.value.error.errorMessage ?? "");
          if (nextKey !== undefined) {
            rotationsThisRequest += 1;
            // v3.0.63 — surface the rotation to the app (no key material,
            // ever): the island/companion reacts, the reliability HUD can
            // count fallbacks. Debug-only stderr event stays as-is.
            emitArixSubscriberEvent("provider_key_rotated", {
              provider_config_id: config.provider_config_id,
              key_index: keyRotationStates.get(config.provider_config_id)?.activeIndex ?? 0,
              pool_size: effectiveApiKeys(config).length,
              attempt: rotationsThisRequest,
            });
            // Built-in providers read the credential from the shared
            // store; replace it so FUTURE requests (next turns, one-shot
            // completions) start on the rotated key.
            if (config.provider_type === "builtin") {
              await replaceSharedCredential(config.provider_config_id, {
                type: "api_key",
                key: nextKey,
                ...(Object.keys(config.provider_env ?? {}).length > 0
                  ? { env: config.provider_env }
                  : {}),
              } as Credential);
            }
            // Models.applyAuth resolved the OLD key into the request
            // options upstream; the replay must carry the ROTATED one
            // (the provider apis read options.apiKey).
            options = { ...options, apiKey: nextKey } as TOptions;
            // v3.0.82 — usage accounting follows the replayed key.
            requestKey = nextKey;
            // v3.0.89 — the replay is a new request on the new key.
            recordKeyRequest(config, requestKey);
            continue;
          }
        }
        // v3.0.63 — CLEAR FINAL ERROR when the whole pool is exhausted: if
        // this request already rotated at least once and the (final) error
        // is still a quota exhaustion, annotate it so the user understands
        // EVERY configured key was tried — not just the last one.
        if (
          !first.done &&
          first.value.type === "error" &&
          rotationsThisRequest > 0 &&
          lastQuotaError === first.value.error &&
          isKeySwitchFailure(config, first.value.error.errorMessage ?? "")
        ) {
          const poolSize = effectiveApiKeys(config).length;
          const base = first.value.error.errorMessage?.trim() || "Provider quota exhausted";
          first.value.error.errorMessage =
            `${base} (all ${poolSize} configured API keys are exhausted ` +
            `— add another key or wait for the quota to reset)`;
        }
        if (!first.done) output.push(first.value);
        while (true) {
          const next = await iterator.next();
          if (next.done) break;
          // v3.0.89 — MID-STREAM QUOTA BENCH: a quota error that arrives
          // AFTER content has streamed cannot be replayed (the user
          // already saw partial text), but the failing key must still be
          // benched NOW — otherwise the app's auto-retry/continue lands
          // on the SAME dead key and dies again. Rotate immediately and
          // surface the switch; the stream error still flows through so
          // the checkpoint/auto-continue layer takes over.
          if (
            next.value.type === "error" &&
            isKeySwitchFailure(config, next.value.error.errorMessage ?? "")
          ) {
            const benchedKey = rotateToNextKey(config, next.value.error.errorMessage ?? "");
            if (benchedKey !== undefined) {
              if (config.provider_type === "builtin") {
                await replaceSharedCredential(config.provider_config_id, {
                  type: "api_key",
                  key: benchedKey,
                  ...(Object.keys(config.provider_env ?? {}).length > 0
                    ? { env: config.provider_env }
                    : {}),
                } as Credential);
              }
              emitArixSubscriberEvent("provider_key_rotated", {
                provider_config_id: config.provider_config_id,
                key_index: keyRotationStates.get(config.provider_config_id)?.activeIndex ?? 0,
                pool_size: effectiveApiKeys(config).length,
                attempt: 1,
                reason: "midstream_quota",
              });
              // Annotate so the app's failure formatter reports the pool
              // state accurately instead of the generic single-key text.
              const poolSize = effectiveApiKeys(config).length;
              const base = next.value.error.errorMessage?.trim() || "Provider quota exhausted";
              next.value.error.errorMessage =
                `${base} (key benched; switched to backup — ${poolSize} keys configured, ` +
                `continuing on the next attempt)`;
            }
          }
          output.push(next.value);
        }
        const result = await attempt.result();
        // v3.0.82 — feed the proactive-rotation window with the ACTUAL
        // input tokens this request burned on its key.
        recordKeyInputTokens(config, requestKey, result?.usage?.input ?? 0);
        output.end(result);
        return;
      }
    })().catch((error: unknown) => {
      const message: AssistantMessage = {
        role: "assistant",
        content: [],
        api: model.api,
        provider: model.provider,
        model: model.id,
        usage: emptyUsage(),
        stopReason: "error",
        errorMessage: errorMessageWithCause(error),
        timestamp: Date.now(),
      };
      output.push({ type: "error", reason: "error", error: message });
      output.end(message);
    });
    return output;
  };
}


// ------------------------------------------------------------------------- //
// v3.1.14 — Arix Script Extensions                                          //
//                                                                           //
// A port of Aether's extension runtime: JS/TS extensions loaded from        //
// ~/.arix/extensions (plus the standard ~/.pi/agent/extensions and Pi       //
// packages) contribute settings cards, composer menu items, chat surfaces, //
// tool titles and host-call handlers. The Kotlin host drives them through  //
// the request types below and receives events over its subscribe channel.  //
// ------------------------------------------------------------------------- //

interface PendingArixHostCall {
  resolve: (result: JsonObject) => void;
  reject: (error: Error) => void;
  timeout: NodeJS.Timeout;
}

const arixSubscriberRequestIds = new Set<string>();
const arixOperationContext = new AsyncLocalStorage<string>();
const activeArixOperationRequestIds = new Set<string>();
const pendingArixHostCalls = new Map<string, PendingArixHostCall>();
let arixHostCallCounter = 0;
let currentExtensionLoadOptions = {
  disabledExtensionPaths: [] as string[],
  disabledPackageSources: [] as string[],
};

function emitArixExtensionSubscriberEvent(event: string, payload: JsonObject = {}): void {
  for (const requestId of arixSubscriberRequestIds) writeEvent(requestId, event, payload);
}

function requestArixHost(method: string, args: JsonObject): Promise<JsonObject> {
  const operationRequestId = arixOperationContext.getStore();
  const requestId = operationRequestId && activeArixOperationRequestIds.has(operationRequestId)
    ? operationRequestId
    : arixSubscriberRequestIds.values().next().value;
  if (!requestId) {
    bridgeDebug("arix_host_call_no_subscriber", { method });
    throw new Error("The Arix app host is not subscribed.");
  }
  const callId = `arix-host-${Date.now()}-${++arixHostCallCounter}`;
  bridgeDebug("arix_host_call_start", { call_id: callId, method, routed_request_id: requestId });
  writeEvent(requestId, "arix_host_call", { call_id: callId, method, args });
  const startedAt = Date.now();
  return new Promise<JsonObject>((resolve, reject) => {
    const timeout = setTimeout(() => {
      pendingArixHostCalls.delete(callId);
      bridgeDebug("arix_host_call_timeout", {
        call_id: callId,
        method,
        elapsed_ms: elapsedMillis(startedAt),
      });
      reject(new Error(`Arix host call timed out: ${method}`));
    }, 2 * 60 * 1000);
    pendingArixHostCalls.set(callId, { resolve, reject, timeout });
  });
}

async function runArixOperation<T>(requestId: string, operation: () => Promise<T>): Promise<T> {
  activeArixOperationRequestIds.add(requestId);
  try {
    return await arixOperationContext.run(requestId, operation);
  } finally {
    activeArixOperationRequestIds.delete(requestId);
  }
}

function resolveArixHostCall(payload: JsonObject): boolean {
  const callId = asString(payload.call_id).trim();
  const pending = callId ? pendingArixHostCalls.get(callId) : undefined;
  if (!pending) {
    bridgeDebug("arix_host_result_orphaned", { call_id: callId });
    return false;
  }
  pendingArixHostCalls.delete(callId);
  clearTimeout(pending.timeout);
  bridgeDebug("arix_host_call_resolved", { call_id: callId, ok: asBoolean(payload.ok, true) });
  if (asBoolean(payload.ok, true)) {
    pending.resolve(asObject(payload.result));
  } else {
    pending.reject(new Error(asString(payload.error, "Arix host call failed.")));
  }
  return true;
}

configureArixExtensionTransport({
  requestHost: requestArixHost,
  invalidate(version) {
    emitArixExtensionSubscriberEvent("arix_invalidated", { version });
  },
  notify(message, level) {
    emitArixExtensionSubscriberEvent("arix_notification", { message, level });
  },
});

function nativeExtensionPathIsDisabled(
  candidatePath: string,
  disabledPaths: Set<string>,
): boolean {
  const candidate = path.resolve(candidatePath);
  return [...disabledPaths].some((disabledPath) => {
    const relative = path.relative(disabledPath, candidate);
    return relative === "" || (
      !relative.startsWith(`..${path.sep}`) &&
      relative !== ".." &&
      !path.isAbsolute(relative)
    );
  });
}

async function resolveNativeExtensionSet(
  workspaceDirectory: string,
  configuredExtensionPaths: string[],
  loadOptions: { disabledExtensionPaths: string[]; disabledPackageSources: string[] },
): Promise<{ extensionPaths: string[]; signature: string }> {
  const disabledPaths = new Set(
    loadOptions.disabledExtensionPaths.map((entry) => path.resolve(entry)),
  );
  const discoveredPaths = discoverArixExtensionPaths(
    workspaceDirectory,
    configuredExtensionPaths,
  ).filter((candidate) => !nativeExtensionPathIsDisabled(candidate, disabledPaths));
  const packagePaths = await discoverPackageExtensionPaths(
    workspaceDirectory,
    new Set(loadOptions.disabledPackageSources),
  );
  const extensionPaths = [...new Set([...discoveredPaths, ...packagePaths])].sort();
  return {
    extensionPaths,
    signature: JSON.stringify(extensionPaths),
  };
}

async function installedExtensionPackagesPayload(): Promise<JsonObject> {
  return {
    packages: (await listArixExtensionPackages(process.cwd())).map((installedPackage) => ({
      source: installedPackage.source,
      scope: installedPackage.scope,
      filtered: installedPackage.filtered,
      installed_path: installedPackage.installedPath ?? "",
      name: installedPackage.name,
      version: installedPackage.version,
      description: installedPackage.description,
      extension_count: installedPackage.extensionCount,
      aether_extension_count: installedPackage.aetherExtensionCount,
      arix_extension_count: installedPackage.arixExtensionCount,
      native_entrypoint_count: installedPackage.nativeEntrypointCount,
      skill_count: installedPackage.skillCount,
      prompt_count: installedPackage.promptCount,
      theme_count: installedPackage.themeCount,
      skill_paths: installedPackage.skillPaths,
    })),
  };
}

function nativeExtensionLoadOptionsFromPayload(payload: JsonObject): {
  disabledExtensionPaths: string[];
  disabledPackageSources: string[];
} {
  const hasOptions = Object.prototype.hasOwnProperty.call(payload, "disabled_extension_paths") ||
    Object.prototype.hasOwnProperty.call(payload, "disabled_package_sources");
  if (hasOptions) {
    currentExtensionLoadOptions = {
      disabledExtensionPaths: stringArray(payload.disabled_extension_paths),
      disabledPackageSources: stringArray(payload.disabled_package_sources),
    };
  }
  return currentExtensionLoadOptions;
}

async function reloadAllExtensionSessions(payload: JsonObject = {}): Promise<JsonObject> {
  const loadOptions = nativeExtensionLoadOptionsFromPayload(payload);
  // Packages can provide both Pi and Arix entrypoints. Resolve their npm
  // dependencies before reloading native Pi sessions so both loaders observe
  // the same ready package tree.
  const skipArixExtensions = asBoolean(payload.skip_arix_extensions, false);
  const arixReload = skipArixExtensions
    ? { reloaded: false, errors: [] }
    : await loadArixAppExtensions(process.cwd(), loadOptions);
  const results: JsonObject[] = [];
  for (const state of [...agentSessions.values()]) {
    const { signature: extensionSignature } = await resolveNativeExtensionSet(
      state.workspaceDirectory,
      state.configuredExtensionPaths,
      loadOptions,
    );
    const requiresRecreation = extensionSignature !== state.extensionSignature;
    const scheduled = !state.session.isIdle;
    if (scheduled) {
      state.pendingReload = true;
      state.pendingRecreate = requiresRecreation;
    } else if (requiresRecreation) {
      await closeNativeAgentSession(state.sessionId);
    } else {
      await state.session.reload();
    }
    results.push({
      session_id: state.sessionId,
      reloaded: !scheduled,
      scheduled,
      recreated_on_next_use: requiresRecreation,
      errors: requiresRecreation ? [] : state.resourceLoader.getExtensions().errors,
    });
  }
  // ResourceLoader keeps healthy extensions active while reporting broken ones
  // as diagnostics. A diagnostic must not make an unrelated import/enable
  // operation fail; an actual reload exception is already propagated above.
  const sessionReloadSucceeded = results.every((result) =>
    result.reloaded === true || result.scheduled === true
  );
  return {
    // Arix Script extensions are reloaded independently. Keep the session
    // operation usable when one unrelated Arix extension remains broken; its
    // details are still returned in arix_reload.errors for diagnostics.
    succeeded: sessionReloadSucceeded,
    session_count: results.length,
    sessions: results,
    arix_reload: arixReload,
    arix: skipArixExtensions ? {} : await arixAppExtensionSnapshot(),
  };
}

async function installExtensionPackageRequest(id: string, payload: JsonObject): Promise<JsonObject> {
  const source = asString(payload.source).trim();
  const progress = (phase: string) => writeEvent(id, "extension_package_progress", { phase, source });
  await installArixExtensionPackage(process.cwd(), source, progress);
  progress("reloading");
  const reload = await reloadAllExtensionSessions(payload);
  progress("refreshing");
  return {
    installed: true,
    source,
    ...(await installedExtensionPackagesPayload()),
    reload,
  };
}

async function removeExtensionPackageRequest(payload: JsonObject): Promise<JsonObject> {
  const source = asString(payload.source).trim();
  const removed = await removeArixExtensionPackage(process.cwd(), source);
  return {
    removed,
    source,
    ...(await installedExtensionPackagesPayload()),
  };
}

async function updateExtensionPackageRequest(id: string, payload: JsonObject): Promise<JsonObject> {
  const source = asString(payload.source).trim();
  const progress = (phase: string) => writeEvent(id, "extension_package_progress", { phase, source });
  await updateArixExtensionPackage(process.cwd(), source, progress);
  progress("reloading");
  const reload = await reloadAllExtensionSessions(payload);
  progress("refreshing");
  return {
    updated: true,
    source,
    ...(await installedExtensionPackagesPayload()),
    reload,
  };
}

async function reloadArixAppExtensionsRequest(id: string, payload: JsonObject): Promise<JsonObject> {
  return runArixOperation(id, async () => {
    const result = await loadArixAppExtensions(
      process.cwd(),
      nativeExtensionLoadOptionsFromPayload(payload),
    );
    return {
      ...result,
      snapshot: await arixAppExtensionSnapshot(asObject(payload.context)),
    };
  });
}

async function getArixAppExtensionsRequest(id: string, payload: JsonObject): Promise<JsonObject> {
  return runArixOperation(id, async () => ({
    snapshot: await arixAppExtensionSnapshot(asObject(payload.context)),
  }));
}

async function invokeArixAppExtensionActionRequest(
  id: string,
  payload: JsonObject,
): Promise<JsonObject> {
  return runArixOperation(id, async () => ({
    ...(await invokeArixAppExtensionAction(
      asString(payload.extension_id),
      asString(payload.action),
      asObject(payload.args),
      asObject(payload.context),
    )),
    snapshot: await arixAppExtensionSnapshot(asObject(payload.context)),
  }));
}

async function dispatchArixAppExtensionEventRequest(
  id: string,
  payload: JsonObject,
): Promise<JsonObject> {
  return runArixOperation(id, async () => ({
    ...(await dispatchArixAppExtensionEvent(
      asString(payload.event),
      asObject(payload.data),
      asObject(payload.context),
    )),
    snapshot: await arixAppExtensionSnapshot(asObject(payload.context)),
  }));
}

function writeFrame(frame: JsonObject): void {
  writeProtocolFrame(frame);
}

function writeEvent(id: string, event: string, payload: JsonObject = {}): void {
  writeFrame({ type: "event", id, event, payload });
}

function writeResponse(id: string, payload: JsonObject = {}): void {
  writeFrame({ type: "response", id, ok: true, payload });
}

function writeError(id: string | undefined, error: unknown, code = "bridge_error"): void {
  const message = errorMessageWithCause(error);
  writeFrame({
    type: "error",
    id: id ?? "",
    ok: false,
    error: {
      code,
      message,
    },
  });
}

const activeTurnRequestIds = new Set<string>();

function emitArixSubscriberEvent(event: string, payload: JsonObject = {}): void {
  if (event !== "provider_key_rotated") return;
  for (const requestId of activeTurnRequestIds) {
    writeEvent(requestId, event, payload);
  }
}

function errorMessageWithCause(error: unknown): string {
  const messages: string[] = [];
  const seen = new Set<object>();
  const pending: unknown[] = [error];
  while (pending.length > 0 && seen.size < 32) {
    const current = pending.shift();
    if (!current || typeof current !== "object" || seen.has(current)) continue;
    seen.add(current);
    const record = current as {
      message?: unknown;
      code?: unknown;
      errno?: unknown;
      syscall?: unknown;
      address?: unknown;
      hostname?: unknown;
      port?: unknown;
      cause?: unknown;
      reason?: unknown;
      errors?: unknown;
    };
    const message = typeof record.message === "string" ? record.message.trim() : "";
    const code = typeof record.code === "string" || typeof record.code === "number"
      ? String(record.code).trim()
      : "";
    const errno = typeof record.errno === "string" || typeof record.errno === "number"
      ? String(record.errno).trim()
      : "";
    const syscall = typeof record.syscall === "string" ? record.syscall.trim() : "";
    const host = [record.hostname ?? record.address, record.port]
      .filter((value) => typeof value === "string" || typeof value === "number")
      .map(String)
      .filter(Boolean)
      .join(":");
    const context = [code, errno !== code ? errno : "", syscall, host]
      .filter((value) => value && !message.includes(value))
      .join(", ");
    const detail = context
      ? `${message || "Network request failed"} (${context})`
      : message;
    if (detail && !messages.includes(detail)) messages.push(detail);
    pending.push(record.cause, record.reason);
    if (Array.isArray(record.errors)) pending.push(...record.errors);
  }
  if (messages.length > 0) return messages.join(": ");
  return error instanceof Error ? error.name : String(error);
}

function fetchWithDetailedErrors(
  fetchImplementation: typeof fetch,
  onError?: (detail: string) => void,
): typeof fetch {
  return async (input, init) => {
    const url = fetchUrl(input);
    const method = typeof init?.method === "string" ? init.method : "GET";
    const startedAt = Date.now();
    bridgeDebug("fetch_start", { method, url });
    try {
      const response = await fetchImplementation(input, init);
      bridgeDebug("fetch_end", {
        method,
        url,
        status: response.status,
        elapsed_ms: elapsedMillis(startedAt),
      });
      return response;
    } catch (error) {
      const detail = errorMessageWithCause(error);
      bridgeDebug("fetch_error", {
        method,
        url,
        error: detail,
        aborted: Boolean(init?.signal?.aborted),
        elapsed_ms: elapsedMillis(startedAt),
      });
      onError?.(detail);
      if (error instanceof Error && detail === error.message) throw error;
      throw new Error(detail, { cause: error });
    }
  };
}

globalThis.fetch = fetchWithDetailedErrors(globalThis.fetch.bind(globalThis));

function fetchUrl(input: string | URL | Request): string {
  if (typeof input === "string") return input;
  if (input instanceof URL) return input.toString();
  return input.url;
}

function asObject(value: unknown): JsonObject {
  return value && typeof value === "object" && !Array.isArray(value) ? (value as JsonObject) : {};
}

function asString(value: unknown, fallback = ""): string {
  return typeof value === "string" ? value : fallback;
}

function asNumber(value: unknown, fallback: number): number {
  return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}

function asBoolean(value: unknown, fallback: boolean): boolean {
  return typeof value === "boolean" ? value : fallback;
}

function normalizeBaseUrlForComparison(value: string | undefined): string {
  const trimmed = (value ?? "").trim();
  if (!trimmed) return "";
  try {
    const url = new URL(trimmed);
    url.pathname = url.pathname.replace(/\/+$/, "");
    return url.toString();
  } catch {
    return trimmed.replace(/\/+$/, "");
  }
}

function isCustomResponsesEndpoint(
  model: Model<string>,
  configuredBaseUrl: string | undefined,
  defaultBaseUrl: string | undefined,
): model is Model<"openai-responses"> {
  const configured = normalizeBaseUrlForComparison(configuredBaseUrl);
  return (
    hasApi(model, "openai-responses") &&
    configured.length > 0 &&
    configured !== normalizeBaseUrlForComparison(defaultBaseUrl)
  );
}

function normalizeHeaders(value: unknown): Record<string, string> {
  const inputHeaders = asObject(value);
  const headers: Record<string, string> = {};
  for (const [key, rawValue] of Object.entries(inputHeaders)) {
    if (!key.trim()) continue;
    if (typeof rawValue === "string") headers[key] = rawValue;
  }
  return headers;
}

function normalizeThinkingLevelMap(rawValue: unknown): Record<string, string | null> | undefined {
  const raw = asObject(rawValue);
  if (!raw || Object.keys(raw).length === 0) return undefined;
  const result: Record<string, string | null> = {};
  for (const [key, value] of Object.entries(raw)) {
    if (value === null) {
      result[key] = null;
    } else if (typeof value === "string") {
      result[key] = value;
    }
  }
  return Object.keys(result).length > 0 ? result : undefined;
}

function positiveInteger(value: unknown): number | undefined {
  return typeof value === "number" && Number.isFinite(value) && value > 0 ? Math.floor(value) : undefined;
}

// v3.0.86 — models.dev capability metadata, validated before it can reach
// a Model: levels must be Pi thinking levels, limits positive integers.
function normalizeModelsDevMetadata(rawValue: unknown): ModelsDevMetadata | undefined {
  const raw = asObject(rawValue);
  if (Object.keys(raw).length === 0) return undefined;
  const metadata: ModelsDevMetadata = {};
  if (typeof raw.reasoning === "boolean") metadata.reasoning = raw.reasoning;
  if (Array.isArray(raw.thinking_levels)) {
    const levels = new Set(raw.thinking_levels.map((level) => asString(level).trim().toLowerCase()));
    metadata.thinking_levels = PI_THINKING_LEVELS.filter((level) => levels.has(level));
  }
  const contextWindow = positiveInteger(raw.context_window);
  if (contextWindow) metadata.context_window = contextWindow;
  const maxTokens = positiveInteger(raw.max_tokens);
  if (maxTokens) metadata.max_tokens = maxTokens;
  if (Array.isArray(raw.input)) {
    const input = new Set(raw.input.map((entry) => asString(entry).trim().toLowerCase()));
    metadata.input = input.has("image") ? ["text", "image"] : ["text"];
  }
  return Object.keys(metadata).length > 0 ? metadata : undefined;
}

/**
 * Rebuild Pi's per-level support map from the levels models.dev reports.
 *
 * Pi treats a level as supported unless it maps to null, except xhigh/max,
 * which need an explicit wire value. Existing wire values are kept because
 * they encode transport-specific spellings; levels models.dev reports
 * without one are sent under their own name. The off entry is left alone:
 * the host decides it separately (models.dev "none" effort or toggle).
 */
function modelsDevThinkingLevelMap(
  model: Model<string>,
  levels: readonly PiThinkingLevel[] | undefined,
): Record<string, string | null> | undefined {
  const supported = new Set(levels ?? []);
  // Without an explicit effort list (budget-token or toggle-only models)
  // models.dev cannot say which levels exist, so Pi's defaults stay.
  if (!PI_THINKING_LEVELS.some((level) => level !== "off" && supported.has(level))) return undefined;
  const base = (model.thinkingLevelMap ?? {}) as Record<string, string | null | undefined>;
  const googleTransport = model.api.startsWith("google");
  const result: Record<string, string | null> = {};
  if (base.off !== undefined) result.off = base.off;
  for (const level of PI_THINKING_LEVELS) {
    if (level === "off") continue;
    const existing = base[level];
    if (!supported.has(level)) {
      result[level] = null;
    } else if (typeof existing === "string") {
      result[level] = existing;
    } else if (googleTransport && !GOOGLE_THINKING_WIRE_LEVELS.has(level)) {
      result[level] = null;
    } else if (existing === null || level === "xhigh" || level === "max") {
      result[level] = level;
    }
  }
  return result;
}

function applyModelsDevMetadata(model: Model<string>, metadata: ModelsDevMetadata | undefined): Model<string> {
  if (!metadata) return model;
  const next = { ...model } as Model<string> & Record<string, unknown>;
  if (metadata.reasoning !== undefined) next.reasoning = metadata.reasoning;
  if (metadata.context_window) next.contextWindow = metadata.context_window;
  if (metadata.max_tokens) next.maxTokens = metadata.max_tokens;
  if (metadata.input) next.input = metadata.input;
  const thinkingLevelMap = modelsDevThinkingLevelMap(next, metadata.thinking_levels);
  if (thinkingLevelMap) next.thinkingLevelMap = thinkingLevelMap;
  return next;
}

function withExplicitThinkingLevelMap(
  model: Model<string>,
  thinkingLevelMap: Record<string, string | null> | undefined,
): Model<string> {
  if (!thinkingLevelMap) return model;
  return {
    ...model,
    thinkingLevelMap: {
      ...(model.thinkingLevelMap ?? {}),
      ...thinkingLevelMap,
    },
  } as Model<string>;
}

/**
 * Serve the configured model from the provider's catalog so every Pi lookup
 * by id (session restore, extensions, compaction) sees the same
 * host-resolved metadata instead of the bundled catalog entry.
 */
function providerServingModel(provider: Provider, model: Model<string>): Provider {
  return {
    ...provider,
    getModels: () => {
      const models = provider.getModels();
      let replaced = false;
      const merged = models.map((candidate) => {
        if (candidate.id !== model.id) return candidate;
        replaced = true;
        return model;
      });
      return replaced ? merged : [...merged, model];
    },
  } as Provider;
}

function normalizeModelConfig(rawValue: unknown): ModelConfig {
  const raw = asObject(rawValue);
  const providerType = asString(raw.provider_type).trim();
  const providerConfigId = asString(raw.provider_config_id).trim();
  const piProviderId = asString(raw.pi_provider_id).trim();
  const piApi = asString(raw.pi_api).trim();
  const modelId = asString(raw.model_id).trim();
  const baseUrl = asString(raw.base_url).trim();
  if (!providerType) throw new Error("model_config.provider_type is required.");
  if (!providerConfigId) throw new Error("model_config.provider_config_id is required.");
  if (!piProviderId) throw new Error("model_config.pi_provider_id is required.");
  if (!piApi) throw new Error("model_config.pi_api is required.");
  if (!modelId) throw new Error("model_config.model_id is required.");
  if (providerType !== "faux" && providerType !== "builtin" && !baseUrl) {
    throw new Error("model_config.base_url is required.");
  }
  const authMethod = asString(raw.auth_method).trim();
  bridgeDebug("model_config_normalized", {
    provider_type: providerType,
    pi_provider_id: piProviderId,
    pi_api: piApi,
    model_id: modelId,
    base_url: baseUrl,
    auth_method: authMethod || "api_key",
    has_api_key: asString(raw.api_key) !== "",
    custom_header_names: Object.keys(normalizeHeaders(raw.custom_headers)),
    timeout_ms: asNumber(raw.timeout_ms, 360000),
    max_retries: Math.max(0, asNumber(raw.max_retries, DEFAULT_AGENT_RETRY_MAX_RETRIES)),
    max_retry_delay_ms: asNumber(raw.max_retry_delay_ms, 60000),
    reasoning: asBoolean(raw.reasoning, false),
  });
  return {
    provider_type: providerType,
    provider_config_id: providerConfigId,
    pi_provider_id: piProviderId,
    pi_api: piApi,
    model_id: modelId,
    base_url: baseUrl,
    api_key: asString(raw.api_key),
    // v3.0.61 — multi-key pool: blank-free, deduplicated, primary first.
    api_keys: Array.isArray(raw.api_keys)
      ? [...new Set(
          raw.api_keys
            .filter((entry): entry is string => typeof entry === "string")
            .map((entry) => entry.trim())
            .filter(Boolean),
        )]
      : undefined,
    // v3.0.87 — Aharou-style multi-key mode: toggle, strategy, cooldown
    // and custom switch status codes (see the rotation engine below).
    multi_key_enabled: asBoolean(raw.multi_key_enabled, true),
    key_rotation_strategy:
      raw.key_rotation_strategy === "round_robin" ? "round_robin" : "sequential",
    key_cooldown_minutes: Math.max(0, Math.floor(asNumber(raw.key_cooldown_minutes, 5))),
    key_switch_status_codes: Array.isArray(raw.key_switch_status_codes)
      ? raw.key_switch_status_codes
          .filter((entry): entry is number => typeof entry === "number" && Number.isFinite(entry))
          .map((entry) => Math.floor(entry))
          .filter((entry) => entry >= 100 && entry <= 599)
      : undefined,
    custom_headers: normalizeHeaders(raw.custom_headers),
    service_tier: asString(raw.service_tier).trim() || undefined,
    compatibility_mode: asBoolean(raw.compatibility_mode, false),
    supports_developer_role: raw.supports_developer_role === false ? false : undefined,
    reasoning: asBoolean(raw.reasoning, false),
    thinking_level_map: normalizeThinkingLevelMap(raw.thinking_level_map),
    models_dev: normalizeModelsDevMetadata(raw.models_dev),
    context_window: asNumber(raw.context_window, 128000),
    max_tokens: asNumber(raw.max_tokens, 16384),
    timeout_ms: asNumber(raw.timeout_ms, 360000),
    max_retries: Math.max(0, asNumber(raw.max_retries, DEFAULT_AGENT_RETRY_MAX_RETRIES)),
    // v3.0.50 — normalize max_provider_retries: the field was declared on
    // ModelConfig and consumed by the completion/session retry budgets
    // (`config.max_provider_retries ?? DEFAULT_PROVIDER_RETRY_MAX_RETRIES`)
    // but never read from the payload, so any app-side provider retry
    // budget was silently dropped.
    max_provider_retries: raw.max_provider_retries === undefined
      ? undefined
      : Math.max(0, asNumber(raw.max_provider_retries, 0)),
    max_retry_delay_ms: asNumber(raw.max_retry_delay_ms, 60000),
    auth_method:
      authMethod === "oauth" || authMethod === "ambient" ? authMethod : "api_key",
    oauth_credential: asObject(raw.oauth_credential),
    provider_env: normalizeHeaders(raw.provider_env),
    faux_response: asString(raw.faux_response),
    faux_tool_calls: normalizeFauxToolCalls(raw.faux_tool_calls),
    faux_tokens_per_second: asNumber(raw.faux_tokens_per_second, 0),
  };
}

function isOAuthCredential(value: JsonObject): value is JsonObject & {
  access: string;
  refresh: string;
  expires: number;
} {
  return (
    typeof value.access === "string" &&
    typeof value.refresh === "string" &&
    typeof value.expires === "number"
  );
}

function credentialForConfig(config: ModelConfig): Credential | undefined {
  if (config.auth_method === "oauth" && isOAuthCredential(config.oauth_credential ?? {})) {
    return {
      type: "oauth",
      ...config.oauth_credential,
    } as Credential;
  }
  if (config.auth_method === "api_key" && (config.api_key || Object.keys(config.provider_env ?? {}).length > 0)) {
    return {
      type: "api_key",
      key: config.api_key || undefined,
      env: config.provider_env,
    };
  }
  return undefined;
}

function authContextFor(config: ModelConfig): AuthContext {
  const fallback = defaultProviderAuthContext();
  const configuredEnv = config.provider_env ?? {};
  return {
    env: async (name) => configuredEnv[name] ?? fallback.env(name),
    fileExists: (path) => fallback.fileExists(path),
  };
}

function normalizeFauxToolCalls(rawValue: unknown): Array<{ name: string; arguments: JsonObject; id?: string }> {
  if (!Array.isArray(rawValue)) return [];
  return rawValue.flatMap((rawCall) => {
    const raw = asObject(rawCall);
    const name = asString(raw.name, asString(raw.tool_name)).trim();
    if (!name) return [];
    return [
      {
        name,
        arguments: asObject(raw.arguments),
        id: asString(raw.id).trim() || undefined,
      },
    ];
  });
}

function apiStreamsFor(piApi: string): ProviderStreams {
  switch (piApi) {
    case "openai-completions":
      return openAICompletionsApi();
    default:
      throw new Error(`Unsupported custom Pi API: ${piApi}`);
  }
}

function requestContainsDeveloperMessage(payload: unknown): boolean {
  const messages = asObject(payload).messages;
  return Array.isArray(messages) && messages.some((message) =>
    asString(asObject(message).role).trim().toLowerCase() === "developer"
  );
}

function serviceTierProvider(provider: Provider, config: ModelConfig): Provider {
  const serviceTier = config.service_tier;
  if (!serviceTier) return provider;
  const wrap = (call: ProviderStreams["streamSimple"]): ProviderStreams["streamSimple"] =>
    (model, context, options) => call(model, context, {
      ...options,
      onPayload: async (payload, requestModel) => {
        const transformed = await options?.onPayload?.(payload, requestModel);
        return { ...asObject(transformed ?? payload), service_tier: serviceTier };
      },
    });
  return {
    ...provider,
    stream: wrap(provider.stream.bind(provider)) as Provider["stream"],
    streamSimple: wrap(provider.streamSimple.bind(provider)),
  } as Provider;
}

function compatibilityModeStreams(streams: ProviderStreams): ProviderStreams {
  type SupportedOptions = StreamOptions | SimpleStreamOptions;
  type StreamCall = (
    model: Model<"openai-completions">,
    context: TranscriptContext,
    options?: SupportedOptions,
  ) => AssistantMessageEventStream;

  const wrap = (call: StreamCall): StreamCall => (model, context, options) => call(model, context, {
    ...options,
    onPayload: async (payload: unknown, requestModel: Model<"openai-completions">) => {
      const transformed = await options?.onPayload?.(payload, requestModel);
      const normalizedPayload = asObject(transformed ?? payload);
      const messages = normalizedPayload.messages;
      if (!Array.isArray(messages)) return transformed ?? payload;
      return {
        ...normalizedPayload,
        messages: messages.map((message) => {
          const normalizedMessage = asObject(message);
          const role = asString(normalizedMessage.role).trim().toLowerCase();
          return role === "system" || role === "developer"
            ? { ...normalizedMessage, role: "user" }
            : message;
        }),
      };
    },
  } as SupportedOptions);

  return {
    ...streams,
    stream: wrap(streams.stream as StreamCall) as ProviderStreams["stream"],
    streamSimple: wrap(streams.streamSimple as StreamCall) as ProviderStreams["streamSimple"],
  };
}

function isDeveloperRoleUnsupportedError(errorMessage: string): boolean {
  const normalized = errorMessage.toLowerCase().replace(/\s+/g, " ").trim();
  if (!normalized.includes("developer")) return false;

  const directRoleRejections = [
    /(?:invalid|unsupported|unknown|unrecognized|unrecognised)\s+(?:message\s+)?role[^.\n]{0,80}["']?developer["']?/,
    /(?:role|message role)[^.\n]{0,80}["']?developer["']?[^.\n]{0,80}(?:not\s+(?:supported|allowed|valid|recognized|recognised|permitted)|unsupported|invalid|unknown)/,
    /["']?developer["']?[^.\n]{0,50}(?:is\s+)?(?:not\s+(?:a\s+)?(?:supported|allowed|valid|recognized|recognised|permitted)|(?:an?\s+)?(?:unsupported|invalid|unknown|unrecognized|unrecognised))\s+(?:message\s+)?role/,
    /["']?developer["']?\s+(?:message\s+)?role[^.\n]{0,60}(?:not\s+(?:supported|allowed|valid|recognized|recognised|permitted)|unsupported|invalid|unknown)/,
    /["']?developer["']?\s+messages?[^.\n]{0,60}(?:not\s+(?:supported|allowed|valid|recognized|recognised|permitted)|unsupported|invalid|unknown)/,
    /(?:message\s+)?role[^.\n]{0,120}(?:must be one of|expected one of|allowed values?)[^.\n]{0,160}(?:got|received|input|provided)?[^.\n]{0,30}["']?developer["']?/,
  ];
  if (directRoleRejections.some((pattern) => pattern.test(normalized))) return true;

  const hasMessageRoleLocation =
    /messages?(?:\[[^\]]+\]|\.[^.\s:]+)*[.\s:'"\]]role/.test(normalized) ||
    /["']messages["'][^\n]{0,160}["']role["']/.test(normalized);
  const hasDeveloperInput =
    /["'](?:input|value|received|got)["']\s*:\s*["']developer["']/.test(normalized) ||
    /(?:input|value|received|got)\s+(?:was\s+)?["']developer["']/.test(normalized);
  const hasEnumRejection =
    /literal_error|enum(?:_error)?|input should be|expected (?:one of|a value)|must be one of|supported (?:message )?roles?|allowed (?:message )?roles?|permitted (?:message )?roles?/.test(normalized);
  if (hasMessageRoleLocation && hasDeveloperInput && hasEnumRejection) return true;
  const hasExplicitValueRejection =
    /does not support|cannot be|not\s+(?:supported|allowed|valid|recognized|recognised|permitted)|unsupported(?:[_\s-]+(?:value|role|parameter|field))?|invalid(?:[_\s-]+(?:value|role|parameter|field|message))|unknown(?:[_\s-]+(?:value|role|parameter|field))|unrecogni[sz]ed(?:[_\s-]+(?:value|role|parameter|field))/.test(normalized);
  if (hasMessageRoleLocation && hasExplicitValueRejection) return true;
  if (
    hasMessageRoleLocation &&
    /(?:invalid|unsupported) value\s*:?\s*["']developer["']/.test(normalized) &&
    /supported values?|allowed values?|must be one of|expected one of/.test(normalized)
  ) return true;

  return (
    /(?:supported|allowed|valid|permitted) (?:message )?roles?[^.\n]{0,160}(?:system|user)[^.\n]{0,160}(?:got|received|input|provided)[^.\n]{0,40}["']?developer["']?/.test(normalized) ||
    /(?:supported|allowed|valid|permitted) (?:message )?roles?[^.\n]{0,160}(?:system|user)[^.\n]{0,160}["']?developer["']?[^.\n]{0,40}(?:was )?provided/.test(normalized)
  );
}

function developerRoleFallbackStreams(
  streams: ProviderStreams,
  state: CompatibilityFallbackState,
): ProviderStreams {
  type SupportedOptions = StreamOptions | SimpleStreamOptions;
  type StreamCall = (
    model: Model<"openai-completions">,
    context: TranscriptContext,
    options?: SupportedOptions,
  ) => AssistantMessageEventStream;

  const wrap = (call: StreamCall): StreamCall => (model, context, options) => {
    const output = createAssistantMessageEventStream();
    void (async () => {
      let sentDeveloperMessage = false;
      let providerErrorBody = "";
      const requestFetch = options?.fetch ?? globalThis.fetch;
      const observedOptions = {
        ...options,
        fetch: async (input: string | URL | Request, init?: RequestInit) => {
          const response = await requestFetch(input, init);
          if (!response.ok) {
            providerErrorBody = await response.clone().text()
              .then((body) => body.slice(0, DEVELOPER_ROLE_ERROR_BODY_MAX_CHARS))
              .catch(() => "");
          }
          return response;
        },
        onPayload: async (payload: unknown, requestModel: Model<"openai-completions">) => {
          const transformed = await options?.onPayload?.(payload, requestModel);
          sentDeveloperMessage = requestContainsDeveloperMessage(transformed ?? payload);
          return transformed;
        },
      } as SupportedOptions;
      const firstAttempt = call(model, context, observedOptions);
      const iterator = firstAttempt[Symbol.asyncIterator]();
      const first = await iterator.next();
      if (
        !first.done &&
        first.value.type === "error" &&
        sentDeveloperMessage &&
        model.compat?.supportsDeveloperRole !== false &&
        isDeveloperRoleUnsupportedError(
          `${first.value.error.errorMessage ?? ""}\n${providerErrorBody}`,
        )
      ) {
        model.compat = {
          ...(model.compat ?? {}),
          supportsDeveloperRole: false,
        };
        state.developerRoleUnsupportedDetected = true;
        const fallback = call(model, context, options);
        for await (const event of fallback) output.push(event);
        output.end(await fallback.result());
        return;
      }
      if (!first.done) output.push(first.value);
      while (true) {
        const next = await iterator.next();
        if (next.done) break;
        output.push(next.value);
      }
      output.end(await firstAttempt.result());
    })().catch((error) => {
      const message: AssistantMessage = {
        role: "assistant",
        content: [],
        api: model.api,
        provider: model.provider,
        model: model.id,
        usage: emptyUsage(),
        stopReason: "error",
        errorMessage: errorMessageWithCause(error),
        timestamp: Date.now(),
      };
      output.push({ type: "error", reason: "error", error: message });
      output.end(message);
    });
    return output;
  };

  return {
    ...streams,
    stream: wrap(streams.stream as StreamCall) as ProviderStreams["stream"],
    streamSimple: wrap(streams.streamSimple as StreamCall) as ProviderStreams["streamSimple"],
  };
}

function createArixModel(config: ModelConfig): Model<string> {
  return {
    id: config.model_id,
    name: config.model_id,
    api: config.pi_api,
    provider: config.pi_provider_id,
    baseUrl: config.base_url,
    reasoning: config.reasoning ?? false,
    thinkingLevelMap: config.thinking_level_map,
    input: ["text", "image"],
    cost: {
      input: 0,
      output: 0,
      cacheRead: 0,
      cacheWrite: 0,
    },
    contextWindow: config.context_window ?? 128000,
    maxTokens: config.max_tokens ?? 16384,
    headers: config.custom_headers,
    ...(config.supports_developer_role === false
      ? { compat: { supportsDeveloperRole: false } }
      : {}),
  } as Model<string>;
}


function buildModels(
  config: ModelConfig,
  turnContextHolder: { context: string } = { context: "" },
): {
  models: MutableModels;
  model: Model<string>;
  provider: Provider;
  credentialStore?: BridgeCredentialStore;
  compatibilityFallbackState: CompatibilityFallbackState;
} {
  const compatibilityFallbackState: CompatibilityFallbackState = {
    developerRoleUnsupportedDetected: false,
  };
  bridgeDebug("build_models_start", {
    provider_type: config.provider_type,
    pi_provider_id: config.pi_provider_id,
    pi_api: config.pi_api,
    model_id: config.model_id,
    base_url: config.base_url,
    auth_method: config.auth_method,
  });
  // v3.0.61 — register the multi-key pool (no-op for single-key setups,
  // the common case) so quota errors can rotate to the next key.
  registerKeyPool(config);
  if (config.provider_type === "faux") {
    bridgeDebug("build_models_path", { path: "faux" });
    const models = createModels();
    const faux = fauxProvider({
      provider: config.pi_provider_id,
      models: [
        {
          id: config.model_id,
          reasoning: config.reasoning ?? true,
          input: ["text", "image"],
          contextWindow: config.context_window ?? 128000,
          maxTokens: config.max_tokens ?? 16384,
        },
      ],
      tokensPerSecond: config.faux_tokens_per_second ?? 0,
    });
    // v3.0.86 — pi 0.99.2's faux provider SYNTHESIZES usage per API call
    // (input/output from token estimates, cache read/write from the
    // session's prompt-cache prefix), so faux turns now exercise the
    // whole-turn usage accumulation without a live provider.
    if (config.faux_tool_calls && config.faux_tool_calls.length > 0) {
      faux.setResponses([
        fauxAssistantMessage(
          config.faux_tool_calls.map((toolCall) =>
            fauxToolCall(
              toolCall.name,
              toolCall.arguments as Parameters<typeof fauxToolCall>[1],
              toolCall.id ? { id: toolCall.id } : undefined,
            ),
          ),
          { stopReason: "toolUse" },
        ),
        ...Array.from({ length: 32 }, () => fauxAssistantMessage(config.faux_response || "ok")),
      ]);
    } else {
      faux.setResponses(
        Array.from({ length: 32 }, () => fauxAssistantMessage(config.faux_response || "ok")),
      );
    }
    models.setProvider(faux.provider);
    const model = faux.getModel(config.model_id) ?? faux.getModel();
    // v3.0.83 — turn-context injection wraps the faux provider too (the
    // faux branch used to return early and skip the wrapper — the
    // turn-context tests caught it).
    const fauxTurnContextProvider = withTurnContextProvider(faux.provider, turnContextHolder);
    models.setProvider(fauxTurnContextProvider);
    return { models, model, provider: fauxTurnContextProvider, compatibilityFallbackState };
  }

  if (config.provider_type === "builtin") {
    bridgeDebug("build_models_path", { path: "builtin", pi_provider_id: config.pi_provider_id });
    const provider = builtinProviderById.get(config.pi_provider_id);
    if (!provider) throw new Error(`Unknown built-in Pi provider: ${config.pi_provider_id}`);
    const providerModels = provider.getModels();
    const builtinModel = providerModels.find((candidate) => candidate.id === config.model_id);
    const modelTemplate = builtinModel ?? providerModels[0];
    if (!modelTemplate) {
      throw new Error(`Built-in Pi provider ${config.pi_provider_id} has no protocol template.`);
    }
    const defaultBaseUrl = provider.baseUrl ?? modelTemplate.baseUrl;
    const customBaseUrlModelOverrides = isCustomResponsesEndpoint(
      modelTemplate,
      config.base_url,
      defaultBaseUrl,
    )
      ? {
          compat: {
            ...(modelTemplate.compat ?? {}),
            supportsExplicitPromptCacheMode: false,
          },
        }
      : {};
    // v3.0.30 — honor `supports_developer_role` for BUILT-IN providers too:
    // the app sends the flag for every provider kind, but the builtin branch
    // never mapped it, so users enabling "developer role unsupported" on a
    // catalog provider kept hitting the same 400s and the setting appeared
    // to do nothing. pi-ai's streams consult `model.compat.supportsDeveloperRole`
    // (compat.supportsDeveloperRole ?? detected), so setting the flag here
    // makes the builtin stream use the "system" role — no stream wrapping
    // needed (the developerRoleFallbackStreams wrapper stays a custom-provider
    // safety net).
    const developerRoleCompat = config.supports_developer_role === false
      ? {
          compat: {
            ...(modelTemplate.compat ?? {}),
            ...(customBaseUrlModelOverrides.compat ?? {}),
            supportsDeveloperRole: false,
          },
        }
      : {};
    const credentialStore = new BridgeCredentialStore(
      provider.id,
      config.provider_config_id,
      credentialForConfig(config),
    );
    const models = createModels({
      credentials: credentialStore,
      authContext: authContextFor(config),
    });
    // v3.0.63 — FIX (the v3.0.61 regression): the rotation wrapper must be
    // THE provider that leaves this function. Previously the wrapped
    // provider was only set on the LOCAL `models` collection (used by
    // one-shot complete_once), while the RETURNED `provider` — the one
    // buildModelRuntime hands to ModelRuntime.registerNativeProvider for
    // every AGENT TURN — was still the raw builtin. Agent turns (the
    // actual chat path: run_turn) therefore never rotated on quota
    // exhaustion and surfaced the 429/token-limit error instead of
    // shifting to the next key. Both consumers now share ONE wrapped
    // instance.
    const rotationWrappedProvider = withProviderKeyRotation(provider, config);
    models.setProvider(rotationWrappedProvider);
    // v3.0.83 — turn-context injection wraps OUTERMOST (the rotation
    // estimator then also sees the injected ephemeral tokens).
    const turnContextProvider = withTurnContextProvider(rotationWrappedProvider, turnContextHolder);
    models.setProvider(turnContextProvider);
    const catalogModel = {
      ...modelTemplate,
      ...(builtinModel
        ? {}
        : {
            id: config.model_id,
            name: config.model_id,
            // A model entered through a provider's live model list is not in
            // Pi's static catalog yet. Keep image input enabled so a newly
            // released vision model is not silently downgraded to text-only
            // just because the catalog has not caught up.
            input: ["text", "image"],
            reasoning: config.reasoning ?? false,
            contextWindow: config.context_window ?? 128000,
            maxTokens: config.max_tokens ?? 16384,
            thinkingLevelMap: undefined,
            cost: {
              input: 0,
              output: 0,
              cacheRead: 0,
              cacheWrite: 0,
            },
          }),
      ...customBaseUrlModelOverrides,
      ...developerRoleCompat,
      ...(config.base_url ? { baseUrl: config.base_url } : {}),
      headers: {
        ...modelTemplate.headers,
        ...config.custom_headers,
      },
    } as Model<string>;
    // v3.0.86 — models.dev is the capability source of truth; Pi's bundled
    // catalog only supplies transport details (api, compat, base URL) it
    // cannot describe. Host-resolved thinking levels / context window /
    // output limit / input modalities REPLACE the catalog values, and the
    // host's explicit thinking_level_map (clamps) is applied on top.
    const model = withExplicitThinkingLevelMap(
      applyModelsDevMetadata(catalogModel, config.models_dev),
      config.thinking_level_map,
    );
    // Serve the merged model from the provider catalog so every Pi lookup
    // by id (session restore, extensions, compaction) sees the same
    // host-resolved metadata instead of the bundled catalog entry. Wrapping
    // happens OUTERMOST (over the rotation + turn-context wrappers) for the
    // same reason those wrappers must be the returned provider.
    const servingProvider = serviceTierProvider(providerServingModel(turnContextProvider, model), config);
    models.setProvider(servingProvider);
    // v3.0.63 — return the ROTATION-WRAPPED provider (see the comment at
    // models.setProvider above): buildModelRuntime registers exactly this
    // object into the ModelRuntime, so every agent-turn stream passes
    // through the quota-rotation replay.
    // v3.0.83 — and the TURN-CONTEXT-wrapped one (outermost).
    // v3.0.86 — and the SERVING one (outermost, model-metadata overlay).
    return {
      models,
      model,
      provider: servingProvider,
      credentialStore,
      compatibilityFallbackState,
    };
  }

  const models = createModels();
  // v3.0.86 — models.dev metadata applies to custom (openai-compatible)
  // providers too: a catalog-resolved context window / output limit /
  // reasoning flag beats the generic 128k/16k defaults.
  const model = withExplicitThinkingLevelMap(
    applyModelsDevMetadata(createArixModel(config), config.models_dev),
    config.thinking_level_map,
  );
  bridgeDebug("build_models_path", { path: "custom", pi_api: config.pi_api });
  const headers = config.custom_headers ?? {};
  const provider = serviceTierProvider(createProvider({
    id: config.pi_provider_id,
    name: config.pi_provider_id,
    baseUrl: config.base_url,
    headers,
    auth: {
      apiKey: {
        name: "Arix provider credentials",
        resolve: async () => {
          // v3.0.61 — multi-key pool: resolve the ACTIVE key (the
          // rotated one after a quota failure), not the frozen primary.
          const activeKey = activeApiKeyFor(config);
          // v3.0.94 — KEYLESS custom providers (the Kilo free gateway,
          // local Ollama / LM Studio endpoints, ...). pi-ai's
          // OpenAI-completions client refuses to run without a
          // credential ("No API key for provider"), and the OpenAI SDK
          // stamps `Authorization: Bearer <key>` on every request — but
          // Kilo's gateway REJECTS invalid bearer tokens while serving
          // its free models anonymously. Satisfy both: hand the SDK a
          // placeholder key (so the client constructs and the request
          // validates) while REMOVING the Authorization header via the
          // SDK's documented null-header semantics — header stacks are
          // merged in order and a later null value deletes the earlier
          // bearer entry, so the request goes out with NO Authorization
          // header at all. Works for every keyless OpenAI-compatible
          // endpoint; providers that DO need a key were already failing
          // earlier ("No API key for provider") so their behavior is
          // unchanged.
          const keyless = !activeKey;
          const sendsPlaceholderBearer = keyless && usesDocumentedAnonymousBearer(config.base_url);
          return {
            auth: {
              apiKey: activeKey || (keyless ? "unused" : undefined),
              baseUrl: config.base_url || undefined,
              headers: keyless && !sendsPlaceholderBearer
                ? { ...headers, Authorization: null }
                : headers,
            },
            source: "Arix",
          };
        },
      },
    },
    models: [model],
    api: withTurnContextStreams(
      withKeyRotation(
        developerRoleFallbackStreams(
          config.compatibility_mode
            ? compatibilityModeStreams(apiStreamsFor(config.pi_api))
            : apiStreamsFor(config.pi_api),
          compatibilityFallbackState,
        ),
        config,
      ),
      turnContextHolder,
    ),
  }), config);
  models.setProvider(provider);
  return { models, model, provider, compatibilityFallbackState };
}

async function buildModelRuntime(
  config: ModelConfig,
  turnContextHolder: { context: string } = { context: "" },
): Promise<{
  modelRuntime: ModelRuntime;
  model: Model<string>;
  credentialStore?: BridgeCredentialStore;
  compatibilityFallbackState: CompatibilityFallbackState;
}> {
  const startedAt = Date.now();
  bridgeDebug("model_runtime_create_start", {
    provider_type: config.provider_type,
    model_id: config.model_id,
  });
  const built = buildModels(config, turnContextHolder);
  const modelRuntime = await ModelRuntime.create({
    credentials: built.credentialStore,
    modelsPath: null,
    modelsStore: new InMemoryModelsStore(),
    allowModelNetwork: false,
    refreshOnCreate: false,
  });
  modelRuntime.registerNativeProvider(built.provider);
  bridgeDebug("model_runtime_create_done", {
    provider_type: config.provider_type,
    model_id: config.model_id,
    elapsed_ms: elapsedMillis(startedAt),
  });
  return {
    modelRuntime,
    model: built.model,
    credentialStore: built.credentialStore,
    compatibilityFallbackState: built.compatibilityFallbackState,
  };
}

async function credentialPayload(
  credentialStore: BridgeCredentialStore | undefined,
): Promise<JsonObject> {
  if (!credentialStore) return {};
  const credential = await credentialStore.read(credentialStore.providerId);
  if (!credential || credential.type !== "oauth") return {};
  return {
    oauth_credential: credential as unknown as JsonObject,
  };
}

function providerCatalogPayload(): JsonObject {
  // v3.0.35 — subscription (sign-in) providers are filtered out
  // (RemovedProviderIds): the advertised catalog is API-key providers
  // only. v3.0.85 — cerebras and kimi-coding are filtered too.
  // v3.0.86 — pi 0.99.2 lists a "typesafe" provider entry with NO models;
  // a model-less entry cannot be configured or serve as a protocol
  // template, so it is dropped from the advertised catalog.
  return {
    providers: [
      ...getBuiltinProviders()
        .filter((providerId) => !RemovedProviderIds.has(providerId))
        .filter((providerId) => getBuiltinModels(providerId).length > 0)
        .map((providerId) => {
      const provider = builtinProviderById.get(providerId);
      const models = getBuiltinModels(providerId);
      return {
        id: providerId,
        name: provider?.name ?? providerId,
        base_url: provider?.baseUrl ?? "",
        auth: {
          api_key: provider?.auth.apiKey?.name ?? "",
          api_key_login: Boolean(provider?.auth.apiKey?.login),
          oauth: provider?.auth.oauth?.name ?? "",
          ambient: Boolean(provider?.auth.apiKey && !provider.auth.apiKey.login),
        },
        models: models.map((model) => ({
          id: model.id,
          name: model.name,
          api: model.api,
          reasoning: model.reasoning,
          thinking_levels: getSupportedThinkingLevels(model),
          thinking_level_clamps: Object.fromEntries(
            ["off", "minimal", "low", "medium", "high", "xhigh", "max"].map((level) => [
              level,
              clampThinkingLevel(model, level as "off" | "minimal" | "low" | "medium" | "high" | "xhigh" | "max"),
            ]),
          ),
          input: model.input,
          context_window: model.contextWindow,
          max_tokens: model.maxTokens,
        })),
      };
    }),
    ],
  };
}

function normalizeContentPart(rawValue: unknown): { type: "text"; text: string } | { type: "image"; mimeType: string; data: string } | undefined {
  const raw = asObject(rawValue);
  const type = asString(raw.type);
  if (type === "image") {
    const data = asString(raw.data).trim();
    if (!data) return undefined;
    return {
      type: "image",
      mimeType: asString(raw.mime_type, asString(raw.mimeType, "application/octet-stream")),
      data,
    };
  }
  // v3.0.30 — unknown content types (audio, future part kinds) used to be
  // normalized as EMPTY text parts; drop them instead so providers never
  // receive meaningless empty content.
  const text = asString(raw.text);
  if (type !== "text" && !text) return undefined;
  return { type: "text", text };
}

function normalizeUserContent(rawContent: unknown): string | Array<{ type: "text"; text: string } | { type: "image"; mimeType: string; data: string }> {
  if (typeof rawContent === "string") return rawContent;
  if (!Array.isArray(rawContent)) return "";
  const parts = rawContent.map(normalizeContentPart).filter((part): part is NonNullable<typeof part> => Boolean(part));
  if (parts.length === 1 && parts[0].type === "text") return parts[0].text;
  return parts;
}

function textFromContent(rawContent: unknown): string {
  if (typeof rawContent === "string") return rawContent;
  if (!Array.isArray(rawContent)) return "";
  return rawContent
    .map((part) => {
      const raw = asObject(part);
      return asString(raw.type) === "text" ? asString(raw.text) : "";
    })
    .filter(Boolean)
    .join("");
}

function persistedPiAssistantMessage(rawProviderPayload: unknown): JsonObject {
  const providerPayload = asObject(rawProviderPayload);
  const wrapped = asObject(
    providerPayload.piAssistantMessage ??
      providerPayload.pi_assistant_message ??
      providerPayload.assistant_message,
  );
  if (wrapped.role === "assistant" && Array.isArray(wrapped.content)) return wrapped;
  if (providerPayload.role === "assistant" && Array.isArray(providerPayload.content)) {
    return providerPayload;
  }
  return {};
}

function normalizeMessages(rawMessages: unknown): Context["messages"] {
  if (!Array.isArray(rawMessages)) return [];
  const messages: Message[] = [];
  // v3.0.30 — legacy/imported assistant messages without a persisted Pi
  // payload used to be reconstructed as plain text, discarding their tool
  // calls while the following toolResult messages were kept verbatim.
  // OpenAI-compatible endpoints reject a `tool` message that doesn't follow
  // an assistant message with matching tool_calls, so the very first turn of
  // such a session failed with a provider 400. When reconstructing, look
  // ahead at the directly-following toolResult run and synthesize matching
  // toolCall content parts (id + name) so the history stays provider-valid.
  for (let index = 0; index < rawMessages.length; index++) {
    const raw = asObject(rawMessages[index]);
    const role = asString(raw.role);
    if (role === "assistant") {
      const persistedAssistant = persistedPiAssistantMessage(raw.provider_payload);
      if (persistedAssistant.role === "assistant" && Array.isArray(persistedAssistant.content)) {
        messages.push(persistedAssistant as unknown as AssistantMessage);
        continue;
      }
      const content: Array<
        | { type: "text"; text: string }
        | { type: "toolCall"; id: string; name: string; arguments: Record<string, unknown> }
      > = [
        { type: "text" as const, text: asString(raw.text, textFromContent(raw.content)) },
      ];
      let lookahead = index + 1;
      while (lookahead < rawMessages.length) {
        const next = asObject(rawMessages[lookahead]);
        if (asString(next.role) !== "toolResult") break;
        content.push({
          type: "toolCall" as const,
          id: asString(next.tool_call_id, asString(next.toolCallId)),
          name: asString(next.tool_name, asString(next.toolName)),
          arguments: {},
        });
        lookahead += 1;
      }
      messages.push({
        role: "assistant" as const,
        content,
        api: asString(raw.api, "arix"),
        provider: asString(raw.provider, "arix"),
        model: asString(raw.model, "unknown"),
        usage: emptyUsage(),
        stopReason: "stop" as const,
        timestamp: asNumber(raw.timestamp, Date.now()),
      } as unknown as AssistantMessage);
      continue;
    }
    if (role === "toolResult") {
      messages.push({
        role: "toolResult" as const,
        toolCallId: asString(raw.tool_call_id, asString(raw.toolCallId)),
        toolName: asString(raw.tool_name, asString(raw.toolName)),
        content: [{ type: "text" as const, text: asString(raw.text, asString(raw.content)) }],
        isError: asBoolean(raw.is_error, asBoolean(raw.isError, false)),
        timestamp: asNumber(raw.timestamp, Date.now()),
      });
      continue;
    }
    messages.push({
      role: "user" as const,
      content: normalizeUserContent(raw.content ?? raw.text),
      timestamp: asNumber(raw.timestamp, Date.now()),
    });
  }
  return messages;
}

function buildContext(payload: JsonObject): Context {
  return {
    systemPrompt: asString(payload.system_prompt),
    messages: normalizeMessages(payload.messages),
  };
}

function emptyUsage(): Usage {
  return {
    input: 0,
    output: 0,
    cacheRead: 0,
    cacheWrite: 0,
    totalTokens: 0,
    cost: {
      input: 0,
      output: 0,
      cacheRead: 0,
      cacheWrite: 0,
      total: 0,
    },
  };
}

function usagePayload(usage: Usage | undefined): JsonObject {
  if (!usage) return {};
  return {
    input_tokens: usage.input,
    output_tokens: usage.output,
    total_tokens: usage.totalTokens,
    reasoning_tokens: usage.reasoning,
    cached_input_tokens: usage.cacheRead,
    // v3.0.86 — cache WRITE tokens reach the app too (they were dropped
    // here even though pi-ai reports them; cache writes are billed higher
    // on several providers, so usage statistics need them).
    cache_write_tokens: usage.cacheWrite,
  };
}

// v3.0.86 — WHOLE-TURN USAGE ACCUMULATION. See AgentSessionState.turnUsage.
function emptyTurnUsage(): TurnUsageTotals {
  return {
    inputTokens: 0,
    outputTokens: 0,
    reasoningTokens: 0,
    reasoningReported: false,
    cachedInputTokens: 0,
    cacheWriteTokens: 0,
    totalTokens: 0,
    requestCount: 0,
  };
}

function resetTurnUsage(state: AgentSessionState): void {
  state.turnUsage = emptyTurnUsage();
  state.outputStartedAtMillis = undefined;
  state.outputDurationMillis = 0;
}

function trackTurnUsage(state: AgentSessionState, event: AgentSessionEvent): void {
  if (event.type === "message_update" && event.message.role === "assistant") {
    if (state.outputStartedAtMillis === undefined) {
      state.outputStartedAtMillis = Date.now();
    }
    return;
  }
  if (event.type === "message_end" && event.message.role === "assistant") {
    const startedAt = state.outputStartedAtMillis;
    if (startedAt !== undefined) {
      state.outputDurationMillis += Math.max(0, Date.now() - startedAt);
      state.outputStartedAtMillis = undefined;
    }
    const usage = (event.message as unknown as { usage?: Usage }).usage;
    if (usage) {
      const input = usage.input ?? 0;
      const output = usage.output ?? 0;
      state.turnUsage.inputTokens += input;
      state.turnUsage.outputTokens += output;
      if (usage.reasoning !== undefined) {
        state.turnUsage.reasoningReported = true;
        state.turnUsage.reasoningTokens += usage.reasoning;
      }
      state.turnUsage.cachedInputTokens += usage.cacheRead ?? 0;
      state.turnUsage.cacheWriteTokens += usage.cacheWrite ?? 0;
      state.turnUsage.totalTokens += usage.totalTokens ?? input + output;
      state.turnUsage.requestCount += 1;
    }
    return;
  }
  if (event.type === "auto_retry_start") {
    // The retried attempt produced no usable output; drop its generation window.
    state.outputStartedAtMillis = undefined;
  }
}

function turnUsagePayload(state: AgentSessionState): JsonObject {
  const totals = state.turnUsage;
  if (totals.requestCount === 0) return {};
  const payload: JsonObject = {
    input_tokens: totals.inputTokens,
    output_tokens: totals.outputTokens,
    total_tokens: totals.totalTokens,
    cached_input_tokens: totals.cachedInputTokens,
    cache_write_tokens: totals.cacheWriteTokens,
    request_count: totals.requestCount,
    output_duration_ms: state.outputDurationMillis,
  };
  if (totals.reasoningReported) payload.reasoning_tokens = totals.reasoningTokens;
  return payload;
}

function assistantText(message: AssistantMessage): string {
  return message.content
    .filter((block) => block.type === "text")
    .map((block) => block.text)
    .join("");
}

function assistantThinking(message: AssistantMessage): string {
  return message.content
    .filter((block) => block.type === "thinking")
    .map((block) => block.thinking)
    .join("");
}

function assistantPayload(message: AssistantMessage): JsonObject {
  return {
    assistant_text: assistantText(message),
    reasoning_text: assistantThinking(message),
    assistant_message: message as unknown as JsonObject,
    usage: usagePayload(message.usage),
    provider: message.provider,
    model: message.model,
    response_id: message.responseId,
    stop_reason: message.stopReason,
    // v3.0.38 — network-unreachable provider failures keep a plain,
    // actionable note (the proxy-setting guidance went away with the
    // network-proxy stack).
    error_message: networkAwareErrorMessage(message.errorMessage, message.provider),
  };
}

/** Wraps a network-unreachable provider error with a readable note
 * (the raw errno dumps were opaque); other errors pass untouched. */
function networkAwareErrorMessage(
  errorMessage: string | undefined,
  provider: string | undefined,
): string | undefined {
  if (!errorMessage) return errorMessage;
  const detail = errorMessage.slice(0, 200);
  if (!isNetworkUnreachableError(detail)) return errorMessage;
  return (
    `Could not reach ${provider || "the provider"} from the app — the ` +
      `device network is blocking or cannot reach it. Check the internet ` +
      `connection (or the VPN app's own status) and try again. [${detail}]`
  );
}

/** True when an error looks like a blocked/unreachable network failure. */
function isNetworkUnreachableError(message: string): boolean {
  const lowered = message.toLowerCase();
  return (
    lowered.includes("fetch failed") ||
    lowered.includes("connection error") ||
    lowered.includes("etimedout") ||
    lowered.includes("econnrefused") ||
    lowered.includes("econnreset") ||
    lowered.includes("ehostunreach") ||
    lowered.includes("enetunreach") ||
    lowered.includes("enotfound") ||
    lowered.includes("eai_again") ||
    lowered.includes("und_err_connect_timeout") ||
    lowered.includes("und_err_socket")
  );
}

function emitStreamEvent(requestId: string, event: AssistantMessageEvent): void {
  switch (event.type) {
    case "text_delta":
      writeEvent(requestId, "assistant_text_delta", { delta: event.delta });
      break;
    case "thinking_delta":
      writeEvent(requestId, "assistant_reasoning_delta", { delta: event.delta });
      break;
    case "toolcall_start":
      writeEvent(requestId, "tool_call_start", { content_index: event.contentIndex });
      break;
    case "toolcall_delta":
      writeEvent(requestId, "tool_call_delta", { content_index: event.contentIndex, delta: event.delta });
      break;
    case "toolcall_end":
      writeEvent(requestId, "tool_call_end", {
        id: event.toolCall.id,
        name: event.toolCall.name,
        arguments: event.toolCall.arguments,
      });
      break;
    case "done":
      writeEvent(requestId, "assistant_done", assistantPayload(event.message));
      break;
    case "error":
      writeEvent(requestId, "assistant_error", assistantPayload(event.error));
      break;
  }
}

function streamOptionsFor(
  payload: JsonObject,
  signal: AbortSignal,
  config: ModelConfig,
  model: Model<string>,
): SimpleStreamOptions {
  const options: SimpleStreamOptions = {
    signal,
    sessionId: asString(payload.session_id),
    headers: normalizeHeaders(payload.headers),
    timeoutMs: asNumber(payload.timeout_ms, config.timeout_ms ?? 360000),
    // v3.0.30 — default to the PROVIDER retry budget, matching run_turn's
    // sessionSettings (`max_provider_retries`). The old default reused the
    // AGENT retry setting (`max_retries`, default 5), so title/naming/
    // compaction one-shot completions retried with different semantics
    // (fewer attempts) than agent turns.
    maxRetries: asNumber(
      payload.max_retries,
      config.max_provider_retries ?? DEFAULT_PROVIDER_RETRY_MAX_RETRIES,
    ),
    maxRetryDelayMs: asNumber(payload.max_retry_delay_ms, config.max_retry_delay_ms ?? 60000),
  };
  const temperature = payload.temperature;
  if (typeof temperature === "number") options.temperature = temperature;
  const maxTokens = payload.max_tokens;
  if (typeof maxTokens === "number") options.maxTokens = maxTokens;
  const thinkingLevel = thinkingLevelFor(payload);
  const reasoning = thinkingLevel && thinkingLevel !== "off"
    ? clampThinkingLevel(model, thinkingLevel)
    : undefined;
  if (reasoning) {
    options.reasoning = reasoning as SimpleStreamOptions["reasoning"];
  }
  return options;
}

function normalizeHostToolDefinitions(rawTools: unknown): HostToolDefinition[] {
  if (!Array.isArray(rawTools)) return [];
  return rawTools
    .map((rawTool): HostToolDefinition | undefined => {
      const raw = asObject(rawTool);
      const name = asString(raw.name).trim();
      if (!name) return undefined;
      const executionMode = asString(raw.execution_mode, asString(raw.executionMode)).trim();
      return {
        name,
        description: asString(raw.description),
        parameters: asObject(raw.parameters),
        execution_mode: executionMode === "sequential" ? "sequential" : "parallel",
      };
    })
    .filter((tool): tool is HostToolDefinition => Boolean(tool));
}

function hostToolSchema(definition: HostToolDefinition): TSchema {
  const schema = asObject(definition.parameters);
  if (asString(schema.type)) return schema as unknown as TSchema;
  return {
    type: "object",
    properties: {},
    additionalProperties: true,
  } as unknown as TSchema;
}

function normalizeToolArguments(args: unknown): JsonObject {
  if (typeof args === "string") {
    try {
      return asObject(JSON.parse(args));
    } catch {
      return {};
    }
  }
  return asObject(args);
}

function normalizeToolContent(rawContent: unknown, fallbackText: string): Array<TextContent | ImageContent> {
  if (!Array.isArray(rawContent)) return [{ type: "text", text: fallbackText }];
  const content = rawContent
    .map((rawPart): TextContent | ImageContent | undefined => {
      const part = asObject(rawPart);
      const type = asString(part.type);
      if (type === "image") {
        const data = asString(part.data).trim();
        if (!data) return undefined;
        return {
          type: "image",
          mimeType: asString(part.mime_type, asString(part.mimeType, "application/octet-stream")),
          data,
        };
      }
      if (type === "text") {
        return { type: "text", text: asString(part.text) };
      }
      return undefined;
    })
    .filter((part): part is TextContent | ImageContent => Boolean(part));
  return content.length > 0 ? content : [{ type: "text", text: fallbackText }];
}

function hostToolResultFromPayload(payload: JsonObject): AgentToolResult<JsonObject> {
  const outputText = asString(payload.output_json, asString(payload.output, ""));
  const details = {
    ...asObject(payload.details),
    tool_request_id: asString(payload.tool_request_id),
    tool_call_id: asString(payload.tool_call_id),
    tool_name: asString(payload.tool_name),
    arguments_json: asString(payload.arguments_json),
    output_json: outputText,
    raw_output_json: asString(payload.raw_output_json),
    is_error: asBoolean(payload.is_error, false),
  };
  return {
    content: normalizeToolContent(payload.content, outputText),
    details,
    terminate: asBoolean(payload.terminate, false) || undefined,
  };
}

function resolveHostToolResult(payload: JsonObject): boolean {
  const toolRequestId = asString(payload.tool_request_id).trim();
  const pending = toolRequestId ? pendingHostToolRequests.get(toolRequestId) : undefined;
  if (!pending) {
    bridgeDebug("host_tool_result_orphaned", {
      tool_request_id: toolRequestId,
      tool_name: asString(payload.tool_name),
    });
    return false;
  }
  pendingHostToolRequests.delete(toolRequestId);
  bridgeDebug("host_tool_result_accepted", {
    tool_request_id: toolRequestId,
    tool_name: asString(payload.tool_name),
    is_error: asBoolean(payload.is_error, false),
  });
  applyRuntimeToolResult(payload);
  pending.resolve(hostToolResultFromPayload(payload));
  return true;
}

function applyHostToolProgress(payload: JsonObject): boolean {
  const toolRequestId = asString(payload.tool_request_id).trim();
  const pending = toolRequestId ? pendingHostToolRequests.get(toolRequestId) : undefined;
  if (!pending) {
    bridgeDebug("host_tool_progress_orphaned", { tool_request_id: toolRequestId });
    return false;
  }
  pending.onUpdate?.(hostToolResultFromPayload(payload));
  return true;
}

function toolTextOutput(result: AgentToolResult<JsonObject> | undefined): string {
  if (!result) return "";
  return result.content
    .filter((part): part is TextContent => part.type === "text")
    .map((part) => part.text)
    .join("");
}

function toolResultFallbackSummary(result: AgentToolResult<JsonObject> | undefined): string {
  if (!result) return "";
  const content = Array.isArray(result.content) ? result.content : [];
  const imageBlocks = content.filter(
    (part): part is ImageContent => part.type === "image",
  );
  if (imageBlocks.length > 0) {
    const lines = imageBlocks.map((block) => {
      const bytes = typeof block.data === "string" && block.data.length > 0
        ? Math.max(1, Math.round((block.data.length * 3) / 4 / 1024))
        : 0;
      const sizeLabel = bytes > 0 ? `, ~${bytes} KB` : "";
      return `[image: ${block.mimeType ?? "image/png"}${sizeLabel}]`;
    });
    return `Tool returned ${imageBlocks.length} image${imageBlocks.length === 1 ? "" : "s"}.\n${lines.join("\n")}`;
  }
  const details = asObject(result.details);
  if (details && Object.keys(details).length > 0) {
    const relevant = Object.entries(details)
      .filter(([, value]) => {
        const type = typeof value;
        return type === "string" || type === "number" || type === "boolean";
      })
      .slice(0, 12) as Array<[string, string | number | boolean]>;
    if (relevant.length > 0) {
      return relevant.map(([key, value]) => `${key}: ${String(value)}`).join("\n");
    }
  }
  return content.length === 0 ? "" : "(no textual output)";
}

function toolEventPayload(
  toolCallId: string,
  toolName: string,
  args: unknown,
  result?: AgentToolResult<JsonObject>,
  isError?: boolean,
): JsonObject {
  const argsObject = normalizeToolArguments(args);
  const details = asObject(result?.details);
  return {
    id: toolCallId,
    name: toolName,
    arguments: argsObject,
    arguments_json: JSON.stringify(argsObject),
    output_json: asString(details.output_json, toolTextOutput(result)) || toolResultFallbackSummary(result),
    raw_output_json: asString(details.raw_output_json),
    content: result?.content ?? [],
    details,
    is_error: isError ?? asBoolean(details.is_error, false),
  };
}

function promptFromLastUserMessage(messages: Message[]): {
  history: AgentMessage[];
  text: string;
  images: ImageContent[];
} {
  const last = messages[messages.length - 1];
  if (!last || last.role !== "user") {
    return { history: messages as AgentMessage[], text: "", images: [] };
  }
  const content = last.content;
  if (typeof content === "string") {
    return { history: messages.slice(0, -1) as AgentMessage[], text: content, images: [] };
  }
  const text = content
    .filter((part): part is TextContent => part.type === "text")
    .map((part) => part.text)
    .join("\n");
  const images = content.filter((part): part is ImageContent => part.type === "image");
  return { history: messages.slice(0, -1) as AgentMessage[], text, images };
}

function thinkingLevelFor(payload: JsonObject): "off" | "minimal" | "low" | "medium" | "high" | "xhigh" | "max" | undefined {
  const reasoning = asString(payload.reasoning).trim().toLowerCase();
  if (!reasoning) return undefined;
  const normalized = reasoning === "none" ? "off" : reasoning;
  if (["off", "minimal", "low", "medium", "high", "xhigh", "max"].includes(normalized)) {
    return normalized as "off" | "minimal" | "low" | "medium" | "high" | "xhigh" | "max";
  }
  return undefined;
}

/**
 * v3.0.77 — DYNAMIC CONTEXT POLICY. The app classifies every turn by task
 * complexity (see ArixDynamicContextPolicy) and ships the derived budgets
 * with the run_turn payload; the bridge consumes them where the real
 * context lives:
 *  - `trimFraction`    — replay-path history budget (new kernel session
 *    files): fraction of the context window kept when trimming.
 *  - `compactThreshold` — preemptive compaction trigger for the LIVE
 *    kernel session (fraction of the context window; compaction is the
 *    LLM summarization that preserves all goals/decisions/paths/commands).
 * Simple turns (greetings, quick factual questions) therefore run with a
 * small effective context slice while complex turns (code, files, tool
 * chains, task state) get MORE room than the old fixed 0.6/0.8 budgets.
 * A payload without a policy keeps the legacy behavior exactly.
 */
interface ContextPolicy {
  tier: string;
  trimFraction: number;
  compactThreshold: number;
}

function clampFraction(value: unknown, fallback: number): number {
  const numeric = typeof value === "number" ? value : Number.NaN;
  if (!Number.isFinite(numeric)) return fallback;
  return Math.min(0.95, Math.max(0.05, numeric));
}

function contextPolicyFor(payload: JsonObject): ContextPolicy {
  const raw = asObject(payload.context_policy);
  if (!raw || Object.keys(raw).length === 0) {
    return { tier: "standard", trimFraction: 0.6, compactThreshold: 0.8 };
  }
  const tier = asString(raw.tier).trim().toLowerCase();
  return {
    tier: ["minimal", "standard", "deep"].includes(tier) ? tier : "standard",
    trimFraction: clampFraction(raw.trim_fraction, 0.6),
    compactThreshold: clampFraction(raw.compact_threshold, 0.8),
  };
}

function modelConfigSignature(config: ModelConfig): string {
  return JSON.stringify(config);
}

/**
 * v3.0.50 — stable signature of the turn's system prompt. The kernel
 * session is created with the FIRST turn's system prompt; pi exposes no
 * per-turn override on AgentSession.prompt(), so the session must be
 * recreated whenever the prompt changes (memory block, task-state block,
 * session context, expanded {{placeholders}}, user edits). A cheap
 * content hash keeps the session state small.
 */
function systemPromptSignatureFor(payload: JsonObject): string {
  const systemPrompt = asString(payload.system_prompt);
  if (!systemPrompt) return "";
  let hash = 0x811c9dc5;
  for (let index = 0; index < systemPrompt.length; index += 1) {
    hash ^= systemPrompt.charCodeAt(index);
    hash = Math.imul(hash, 0x01000193) >>> 0;
  }
  return `${systemPrompt.length.toString(36)}:${hash.toString(36)}`;
}

function hostToolSignature(rawTools: unknown, tier?: string): string {
  // v3.0.78 — the tier is part of the signature: minimal-tier sessions
  // run WITHOUT the coding-agent native tools, so a tier flip between
  // turns must force a session recreation with the right tool set (the
  // JSONL conversation file persists across recreation).
  const nativeTools = tier === "minimal" ? "minimal" : "full";
  return `${nativeTools}:${JSON.stringify(normalizeHostToolDefinitions(rawTools))}`;
}

function latestAssistantMessage(messages: AgentMessage[]): AssistantMessage | undefined {
  for (let index = messages.length - 1; index >= 0; index -= 1) {
    const message = messages[index];
    if (message.role === "assistant") return message;
  }
  return undefined;
}

const ARIX_HOST_TOOL_NAMES = new Set([
  "arix_config_get",
  "arix_config_set",
  "arix_skill_manage",
  "arix_scheduled_task_manage",
  "arix_developer_manage",
  "arix_runtime_manage",
  "arix_ensure_package",
  // v3.0.85 — the weather, qr_code, image_search, image_generation and
  // arix_mission agent tools were REMOVED per user request (keep this
  // allowlist in exact sync with ArixToolExecutor.hostToolNames — the
  // ToolRegistryBridgeConsistencyTest pins it).
  // v3.0.101 — image_generation removed again per user request: image
  // engines come from extensions / MCP, not inbuilt.
  "browser",
  // v3.1.15 — phone control (Mika port): the agent operates apps on a
  // separate background virtual display while the user keeps their phone;
  // the small live view in the chat shows what it is doing.
  "phone",
  // v2.9.16 — browser-driven web access (no third-party search API) and
  // the inbuilt Agent Swarm (v3.0.85: the DEFAULT path for long or
  // complex tasks).
  "web_search",
  "fetch_url",
  // v3.0.65 — the universal web scraper (any site, any content type;
  // server-side fetch with a Cloudflare-beating ladder + real-browser
  // fallback + workspace downloads).
  "web_scrape",
  "arix_swarm",
  "arix_tasks",
  "upi_pay",
  "arix_memory",
  "arix_diagnostics",
  // v3.0.0 — Project workspaces.
  "arix_projects",
  // v3.0.8 — native media search/resolve (MediaSearch → MediaResolver →
  // shared native Media3 player).
  "media_search",
  // v3.1.0 — the Tools tab's File Share moved INTO the agent (driven
  // by the file-transfer built-in skill): uploads workspace/device
  // files to a share server with a live progress widget + link card.
  "arix_file_share",
]);

function runtimeForPayload(payload: JsonObject): "termux" {
  return "termux";
}

function platformForPayload(payload: JsonObject): "android" | "ios" {
  return asString(payload.platform).trim().toLowerCase() === "ios" ? "ios" : "android";
}

function activeNativeToolNames(): string[] {
  // v3.0.30 — the old two-branch ternary was dead code: `runtime` is the
  // literal type "termux", so both arms returned the identical list.
  return ["read", "bash", "edit", "write", "grep", "find", "ls"];
}

function allowedHostToolDefinitions(rawTools: unknown, platform: "android" | "ios"): HostToolDefinition[] {
  return normalizeHostToolDefinitions(rawTools).filter((definition) => {
    // v3.0.87 — MCP tools are DYNAMIC (mcp__<server>__<tool>, one per
    // connected Model Context Protocol server; see ArixMcpManager). The
    // prefix gate mirrors the Kotlin executor's dispatch gate.
    if (definition.name.startsWith("mcp__") && platform === "android") return true;
    if (!ARIX_HOST_TOOL_NAMES.has(definition.name)) return false;
    if (platform === "ios") {
      return new Set([
        "arix_config_get",
        "arix_config_set",
        "arix_skill_manage",
              "arix_developer_manage",
      ]).has(definition.name);
    }
    return true;
  });
}

function requestAgentHostTool(
  state: AgentSessionState,
  definition: HostToolDefinition,
  toolCallId: string,
  args: unknown,
  signal: AbortSignal | undefined,
  onUpdate: ((partial: AgentToolResult<JsonObject>) => void) | undefined,
): Promise<AgentToolResult<JsonObject>> {
  const runRequestId = state.currentRequestId;
  if (!runRequestId) throw new Error(`Host tool ${definition.name} was called outside an active turn.`);
  const toolRequestId = `host-tool-${Date.now()}-${++hostToolCounter}`;
  const startedAt = Date.now();
  bridgeDebug("host_tool_request_sent", {
    tool_request_id: toolRequestId,
    tool_call_id: toolCallId,
    tool_name: definition.name,
    session_id: state.sessionId,
    run_request_id: runRequestId,
  });
  return new Promise((resolve, reject) => {
    const abort = () => {
      if (!pendingHostToolRequests.delete(toolRequestId)) return;
      bridgeDebug("host_tool_request_aborted", {
        tool_request_id: toolRequestId,
        tool_name: definition.name,
        elapsed_ms: elapsedMillis(startedAt),
      });
      reject(new Error(`Host tool ${definition.name} was aborted.`));
    };
    signal?.addEventListener("abort", abort, { once: true });
    pendingHostToolRequests.set(toolRequestId, {
      sessionId: state.sessionId,
      resolve: (result) => {
        signal?.removeEventListener("abort", abort);
        bridgeDebug("host_tool_request_resolved", {
          tool_request_id: toolRequestId,
          tool_name: definition.name,
          elapsed_ms: elapsedMillis(startedAt),
        });
        resolve(result);
      },
      reject: (error) => {
        signal?.removeEventListener("abort", abort);
        bridgeDebug("host_tool_request_rejected", {
          tool_request_id: toolRequestId,
          tool_name: definition.name,
          error: errorMessageWithCause(error),
          elapsed_ms: elapsedMillis(startedAt),
        });
        reject(error);
      },
      onUpdate,
    });
    writeEvent(runRequestId, "host_tool_request", {
      session_id: state.sessionId,
      tool_request_id: toolRequestId,
      tool_call_id: toolCallId,
      tool_name: definition.name,
      arguments: normalizeToolArguments(args),
      arguments_json: JSON.stringify(normalizeToolArguments(args)),
      execution_mode: definition.execution_mode ?? "parallel",
    });
  });
}

function createAgentHostToolDefinition(
  state: AgentSessionState,
  definition: HostToolDefinition,
): ToolDefinition<any, any, any> {
  return {
    name: definition.name,
    label: definition.name,
    description: definition.description,
    parameters: hostToolSchema(definition),
    executionMode: definition.execution_mode,
    execute: (toolCallId, args, signal, onUpdate) =>
      requestAgentHostTool(state, definition, toolCallId, args, signal, onUpdate),
  };
}

function requestRuntimeOperation(
  state: AgentSessionState,
  kind: string,
  payload: JsonObject,
  options: { signal?: AbortSignal; onChunk?: (chunk: Buffer) => void; input?: Buffer } = {},
): Promise<JsonObject> {
  const requestId = state.currentRequestId;
  if (!requestId) throw new Error(`Runtime operation ${kind} was called outside an active turn.`);
  const operationId = `runtime-op-${Date.now()}-${++runtimeOperationCounter}`;
  const startedAt = Date.now();
  bridgeDebug("runtime_op_request_sent", {
    operation_id: operationId,
    kind,
    session_id: state.sessionId,
    input_bytes: options.input?.length ?? 0,
  });
  return new Promise((resolve, reject) => {
    const abort = () => {
      if (!pendingRuntimeOperations.delete(operationId)) return;
      bridgeDebug("runtime_op_aborted", {
        operation_id: operationId,
        kind,
        elapsed_ms: elapsedMillis(startedAt),
      });
      writeEvent(requestId, "runtime_op_cancel", {
        operation_id: operationId,
        session_id: state.sessionId,
        runtime: state.runtime,
      });
      reject(new Error(`Runtime operation ${kind} was aborted.`));
    };
    options.signal?.addEventListener("abort", abort, { once: true });
    pendingRuntimeOperations.set(operationId, {
      sessionId: state.sessionId,
      onChunk: options.onChunk,
      resolve: (result) => {
        options.signal?.removeEventListener("abort", abort);
        bridgeDebug("runtime_op_resolved", {
          operation_id: operationId,
          kind,
          elapsed_ms: elapsedMillis(startedAt),
        });
        resolve(result);
      },
      reject: (error) => {
        options.signal?.removeEventListener("abort", abort);
        bridgeDebug("runtime_op_rejected", {
          operation_id: operationId,
          kind,
          error: errorMessageWithCause(error),
          elapsed_ms: elapsedMillis(startedAt),
        });
        reject(error);
      },
    });
    const inputChunks = options.input
      ? Array.from({ length: Math.ceil(options.input.length / RUNTIME_OPERATION_CHUNK_BYTES) }, (_, index) =>
          options.input!.subarray(index * RUNTIME_OPERATION_CHUNK_BYTES, (index + 1) * RUNTIME_OPERATION_CHUNK_BYTES))
      : [];
    writeEvent(requestId, "runtime_op_request", {
      operation_id: operationId,
      session_id: state.sessionId,
      runtime: state.runtime,
      kind,
      payload,
      input_chunk_count: inputChunks.length,
      input_byte_count: options.input?.length ?? 0,
    });
    inputChunks.forEach((chunk, sequence) => {
      writeEvent(requestId, "runtime_op_chunk", {
        operation_id: operationId,
        session_id: state.sessionId,
        runtime: state.runtime,
        direction: "input",
        sequence,
        data_base64: chunk.toString("base64"),
        final: sequence === inputChunks.length - 1,
      });
    });
  });
}

function runtimeOperationChunk(payload: JsonObject): boolean {
  const operationId = asString(payload.operation_id).trim();
  const pending = pendingRuntimeOperations.get(operationId);
  if (!pending) return false;
  const encoded = asString(payload.data_base64).trim();
  if (encoded) pending.onChunk?.(Buffer.from(encoded, "base64"));
  return true;
}

function runtimeOperationResult(payload: JsonObject): boolean {
  const operationId = asString(payload.operation_id).trim();
  const pending = pendingRuntimeOperations.get(operationId);
  if (!pending) {
    bridgeDebug("runtime_op_result_orphaned", { operation_id: operationId });
    return false;
  }
  pendingRuntimeOperations.delete(operationId);
  bridgeDebug("runtime_op_result_received", {
    operation_id: operationId,
    ok: asBoolean(payload.ok, true),
  });
  if (!asBoolean(payload.ok, true)) {
    pending.reject(new Error(asString(payload.error, "Runtime operation failed.")));
  } else {
    pending.resolve(asObject(payload.result));
  }
  return true;
}

function nodeTemporaryOutputPath(filePath: string): boolean {
  const relative = path.relative(os.tmpdir(), filePath);
  return !relative.startsWith(`..${path.sep}`) && relative !== ".." &&
    path.basename(filePath).startsWith("pi-bash-");
}

function runtimePath(state: AgentSessionState, absolutePath: string): string {
  if (state.runtime !== "termux" || nodeTemporaryOutputPath(absolutePath)) return absolutePath;
  const relative = path.relative(state.workspaceDirectory, absolutePath);
  if (relative === "" || (!relative.startsWith(`..${path.sep}`) && !path.isAbsolute(relative))) {
    return path.resolve(state.termuxWorkspaceDirectory, relative);
  }
  return absolutePath;
}

async function detectLocalImageMimeType(absolutePath: string): Promise<string | undefined> {
  const handle = await fs.open(absolutePath, "r");
  try {
    const bytes = Buffer.alloc(16);
    const { bytesRead } = await handle.read(bytes, 0, bytes.length, 0);
    const header = bytes.subarray(0, bytesRead);
    if (header.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return "image/png";
    if (header[0] === 0xff && header[1] === 0xd8 && header[2] === 0xff) return "image/jpeg";
    if (header.subarray(0, 6).toString("ascii") === "GIF87a" || header.subarray(0, 6).toString("ascii") === "GIF89a") return "image/gif";
    if (header.subarray(0, 2).toString("ascii") === "BM") return "image/bmp";
    if (header.subarray(0, 4).toString("ascii") === "RIFF" && header.subarray(8, 12).toString("ascii") === "WEBP") return "image/webp";
    return undefined;
  } finally {
    await handle.close();
  }
}

function termuxReadOperations(state: AgentSessionState): ReadOperations {
  return {
    access: async (absolutePath) => {
      if (nodeTemporaryOutputPath(absolutePath)) {
        await fs.access(absolutePath);
        return;
      }
      await requestRuntimeOperation(state, "access", { path: absolutePath, mode: "read" });
    },
    readFile: async (absolutePath) => {
      if (nodeTemporaryOutputPath(absolutePath)) return fs.readFile(absolutePath);
      const chunks: Buffer[] = [];
      const result = await requestRuntimeOperation(
        state,
        "readFile",
        { path: absolutePath },
        { onChunk: (chunk) => chunks.push(chunk) },
      );
      return chunks.length > 0
        ? Buffer.concat(chunks)
        : Buffer.from(asString(result.data_base64), "base64");
    },
    detectImageMimeType: async (absolutePath) => {
      if (nodeTemporaryOutputPath(absolutePath)) return undefined;
      const result = await requestRuntimeOperation(state, "detectMime", { path: absolutePath });
      return asString(result.mime_type).trim() || undefined;
    },
  };
}

function termuxEditOperations(state: AgentSessionState): EditOperations {
  const read = termuxReadOperations(state);
  return {
    access: read.access,
    readFile: read.readFile,
    writeFile: async (absolutePath, content) => {
      await requestRuntimeOperation(
        state,
        "writeFile",
        { path: absolutePath, atomic: true },
        { input: Buffer.from(content, "utf8") },
      );
    },
  };
}

function termuxWriteOperations(state: AgentSessionState): WriteOperations {
  return {
    mkdir: async (directory) => {
      await requestRuntimeOperation(state, "mkdir", { path: directory, recursive: true });
    },
    writeFile: async (absolutePath, content) => {
      await requestRuntimeOperation(
        state,
        "writeFile",
        { path: absolutePath, atomic: true },
        { input: Buffer.from(content, "utf8") },
      );
    },
  };
}

// v3.0.82 — TOOL RESULT COMPACTION (terminal): the kernel-side bash tool
// already bounds the MODEL-VISIBLE result through its OutputAccumulator
// (last 2000 lines / 50 KB, full output persisted to a temp file whose
// path is included in the result so the model can re-read it with the
// read tool — see pi-coding-agent's core/tools/bash.js). The app-side UI
// streams the complete output through its own runtime_op_chunk path, so
// both sides of the contract ("model gets compacted output, UI gets the
// full stream") are satisfied without a bridge-level re-compactor.

function termuxBashOperations(state: AgentSessionState): BashOperations {
  return {
    exec: async (command, cwd, options) => {
      const result = await requestRuntimeOperation(
        state,
        "bash",
        {
          command,
          cwd,
          timeout_seconds: options.timeout,
          env: options.env ?? {},
        },
        { signal: options.signal, onChunk: options.onData },
      );
      const exitCode = result.exit_code;
      return { exitCode: typeof exitCode === "number" ? exitCode : null };
    },
  };
}

function dynamicReadOperations(state: AgentSessionState): ReadOperations {
  return {
    access: async (absolutePath) => {
      const resolved = runtimePath(state, absolutePath);
      if (state.runtime === "termux" && !nodeTemporaryOutputPath(resolved)) {
        await termuxReadOperations(state).access(resolved);
      } else {
        await fs.access(resolved);
      }
    },
    readFile: async (absolutePath) => {
      const resolved = runtimePath(state, absolutePath);
      return state.runtime === "termux" && !nodeTemporaryOutputPath(resolved)
        ? termuxReadOperations(state).readFile(resolved)
        : fs.readFile(resolved);
    },
    detectImageMimeType: async (absolutePath) => {
      const resolved = runtimePath(state, absolutePath);
      return state.runtime === "termux" && !nodeTemporaryOutputPath(resolved)
        ? termuxReadOperations(state).detectImageMimeType?.(resolved)
        : detectLocalImageMimeType(resolved);
    },
  };
}

function dynamicEditOperations(state: AgentSessionState): EditOperations {
  const read = dynamicReadOperations(state);
  return {
    access: read.access,
    readFile: read.readFile,
    writeFile: async (absolutePath, content) => {
      const resolved = runtimePath(state, absolutePath);
      if (state.runtime === "termux") {
        await termuxEditOperations(state).writeFile(resolved, content);
      } else {
        await fs.writeFile(resolved, content, "utf8");
      }
    },
  };
}

function dynamicWriteOperations(state: AgentSessionState): WriteOperations {
  return {
    mkdir: async (directory) => {
      const resolved = runtimePath(state, directory);
      if (state.runtime === "termux") {
        await termuxWriteOperations(state).mkdir(resolved);
      } else {
        await fs.mkdir(resolved, { recursive: true });
      }
    },
    writeFile: async (absolutePath, content) => {
      const resolved = runtimePath(state, absolutePath);
      if (state.runtime === "termux") {
        await termuxWriteOperations(state).writeFile(resolved, content);
      } else {
        await fs.writeFile(resolved, content, "utf8");
      }
    },
  };
}

function dynamicBashOperations(state: AgentSessionState): BashOperations {
  const local = createLocalBashOperations();
  return {
    exec: (command, cwd, options) => state.runtime === "termux"
      ? termuxBashOperations(state).exec(command, runtimePath(state, cwd), options)
      : local.exec(command, cwd, options),
  };
}

// v3.1.1 — the v3.0.99 observed-bash wrapper (the per-execution event
// stream emitted for the Agent Computer panel) was REMOVED together
// with the panel itself (user request): the bash tool is back to the
// plain definition with dynamic runtime operations.

function nativeToolDefinitions(state: AgentSessionState): ToolDefinition<any, any, any>[] {
  const cwd = state.workspaceDirectory;
  return [
    createReadToolDefinition(cwd, { operations: dynamicReadOperations(state) }),
    createBashToolDefinition(cwd, { operations: dynamicBashOperations(state) }),
    createEditToolDefinition(cwd, { operations: dynamicEditOperations(state) }),
    createWriteToolDefinition(cwd, { operations: dynamicWriteOperations(state) }),
    createGrepToolDefinition(cwd),
    createFindToolDefinition(cwd),
    createLsToolDefinition(cwd),
  ];
}

function applyRuntimeToolResult(payload: JsonObject): void {
  if (asString(payload.tool_name) !== "arix_runtime_manage" || asBoolean(payload.is_error, false)) return;
  const sessionId = asString(payload.session_id).trim();
  const state = agentSessions.get(sessionId);
  if (!state) return;
  const raw = asString(payload.raw_output_json, asString(payload.output_json));
  let result: JsonObject;
  try {
    result = asObject(JSON.parse(raw));
  } catch {
    return;
  }
  if (!asBoolean(result.ok, false) || asString(result.action) !== "set") return;
  const runtime = asString(result.runtime).trim();
  if (runtime !== "termux") return;
  state.runtime = runtime;
  state.session.sessionManager.appendCustomEntry("arix_runtime", {
    runtime,
    cwd: runtime === "termux" ? state.termuxWorkspaceDirectory : state.workspaceDirectory,
  });
  setActiveSessionTools(state);
}

function sessionSettings(payload: JsonObject, config: ModelConfig): SettingsManager {
  return SettingsManager.inMemory({
    defaultProvider: config.pi_provider_id,
    defaultModel: config.model_id,
    defaultThinkingLevel: thinkingLevelFor(payload) ?? "off",
    enableSkillCommands: true,
    compaction: { enabled: true },
    retry: {
      enabled: true,
      maxRetries: Math.max(0, asNumber(payload.max_retries, config.max_retries ?? DEFAULT_AGENT_RETRY_MAX_RETRIES)),
      provider: {
        timeoutMs: asNumber(payload.timeout_ms, config.timeout_ms ?? 360000),
        // v2.9.12: provider-level retries are ON (was 0). A 429 from a
        // provider free tier (Gemini RPM/TPM limits) is a TRANSIENT
        // throttle, not a permanent failure — pi-ai's retryProviderRequest
        // backs off exponentially, honors retry-after, and re-issues the
        // exact same stream request transparently. Without this, the very
        // first 429 killed the whole agentic turn ("free tier warning")
        // even though waiting a few seconds would have succeeded.
        maxRetries: Math.max(
          0,
          asNumber(payload.provider_max_retries, config.max_provider_retries ?? DEFAULT_PROVIDER_RETRY_MAX_RETRIES),
        ),
        maxRetryDelayMs: asNumber(payload.max_retry_delay_ms, config.max_retry_delay_ms ?? 60000),
      },
    },
    images: { autoResize: true, blockImages: false },
  }, { projectTrusted: asBoolean(payload.workspace_trusted, false) });
}

function stringArray(value: unknown): string[] {
  return Array.isArray(value)
    ? value.filter((entry): entry is string => typeof entry === "string" && entry.trim().length > 0)
    : [];
}

async function createSessionManager(
  sessionId: string,
  cwd: string,
  payload: JsonObject,
): Promise<{ manager: SessionManager; existed: boolean }> {
  const explicitFile = asString(payload.session_file).trim();
  if (explicitFile) return { manager: SessionManager.open(explicitFile, undefined, cwd), existed: true };
  const sessionDirectory = asString(
    payload.session_directory,
    path.join(os.homedir(), ".arix", "agent-sessions"),
  );
  await fs.mkdir(sessionDirectory, { recursive: true });
  const suffix = `_${sessionId}.jsonl`;
  const existing = (await fs.readdir(sessionDirectory))
    .filter((entry) => entry.endsWith(suffix))
    .sort()
    .at(-1);
  if (existing) {
    return {
      manager: SessionManager.open(path.join(sessionDirectory, existing), sessionDirectory, cwd),
      existed: true,
    };
  }
  return {
    manager: SessionManager.create(cwd, sessionDirectory, { id: sessionId }),
    existed: false,
  };
}

const arixFailurePolicyExtensionFactory: ExtensionFactory = (pi) => {
  pi.on("tool_result", (event) => {
    const details = event.details as { is_error?: unknown } | undefined;
    const hostToolFailed = details?.is_error === true;
    if (!event.isError && !hostToolFailed) return undefined;
    const guidance =
      `\n\n[Arix policy — tool failure] The tool '${event.toolName}' FAILED. ` +
      "First note briefly (for your final answer) what failed and the exact error. " +
      "Then recover like a capable autonomous assistant: understand the cause and either " +
      "retry the same tool with corrected arguments, or switch to a different AVAILABLE tool " +
      "when the failure clearly proves this one cannot do the job. " +
      "Stop and ask the user only when: (a) two attempts on the same objective have both " +
      "failed, or (b) the next step is irreversible or spends money (payments, deletions, " +
      "credential or permission changes, sending messages on the user's behalf), or " +
      "(c) the request is genuinely ambiguous. Never fabricate success: report only what " +
      "the tool results actually show. Do not repeat a failing call unchanged.";
    const content = Array.isArray(event.content) ? [...event.content] : [];
    if (content.length === 0) {
      return { content: [{ type: "text", text: guidance.trim() }] };
    }
    const lastPart = content[content.length - 1];
    if (lastPart && lastPart.type === "text") {
      content[content.length - 1] = { type: "text", text: lastPart.text + guidance };
    } else {
      content.push({ type: "text", text: guidance.trim() });
    }
    return { content };
  });
};

function setActiveSessionTools(state: AgentSessionState): void {
  const nativeNames = new Set(["read", "bash", "edit", "write", "grep", "find", "ls"]);
  const nonNative = state.session.getActiveToolNames()
    .filter((name) => !nativeNames.has(name));
  // v3.0.78 — a Minimal-tier session was created WITHOUT the coding-agent
  // native tools; re-activating their names here would resurrect tools the
  // turn never advertised.
  state.session.setActiveToolsByName([
    ...(state.minimalTools ? [] : activeNativeToolNames()),
    ...nonNative,
  ]);
}

function emitAgentSessionEvent(state: AgentSessionState, event: AgentSessionEvent): void {
  state.lastAgentEventAtMillis = Date.now();
  // v2.9.16 (ACP): mirror agent events to the ACP client as
  // session/update notifications (agent_message_chunk, tool_call, …).
  if (state.acpSessionId) {
    emitAcpUpdateForAgentEvent(state.acpSessionId, event);
  }
  const requestId = state.currentRequestId;
  if (!requestId) {
    if (event.type !== "message_update") {
      bridgeDebug("agent_session_event_without_request", {
        event_type: event.type,
        session_id: state.sessionId,
      });
    }
    return;
  }
  switch (event.type) {
    case "message_update":
      if (event.message.role === "assistant" &&
          (event.assistantMessageEvent.type === "text_delta" || event.assistantMessageEvent.type === "thinking_delta")) {
        if (state.firstAssistantEventAtMillis === undefined) {
          state.firstAssistantEventAtMillis = Date.now();
          bridgeDebug("first_assistant_delta", {
            session_id: state.sessionId,
            delta_type: event.assistantMessageEvent.type,
            elapsed_since_turn_start_ms: state.turnStartedAtMillis
              ? state.firstAssistantEventAtMillis - state.turnStartedAtMillis
              : undefined,
          });
        }
        emitStreamEvent(requestId, event.assistantMessageEvent);
      }
      return;
    case "tool_execution_start":
      state.toolArgsById.set(event.toolCallId, event.args);
      writeEvent(requestId, "tool_call_start", toolEventPayload(event.toolCallId, event.toolName, event.args));
      return;
    case "tool_execution_update":
      writeEvent(requestId, "tool_call_delta", toolEventPayload(event.toolCallId, event.toolName, event.args, event.partialResult));
      return;
    case "tool_execution_end":
      writeEvent(requestId, "tool_call_end", toolEventPayload(
        event.toolCallId,
        event.toolName,
        state.toolArgsById.get(event.toolCallId) ?? {},
        event.result,
        event.isError,
      ));
      state.toolArgsById.delete(event.toolCallId);
      return;
    case "auto_retry_start":
      writeEvent(requestId, "assistant_stream_reset", {});
      writeEvent(requestId, "assistant_retry", {
        attempt: event.attempt,
        max_attempts: event.maxAttempts,
        delay_ms: event.delayMs,
        error_message: event.errorMessage,
      });
      return;
    case "compaction_start":
      writeEvent(requestId, "compaction_start", { reason: event.reason });
      return;
    case "compaction_end":
      writeEvent(requestId, "compaction_end", {
        reason: event.reason,
        aborted: event.aborted,
        will_retry: event.willRetry,
        error_message: event.errorMessage ?? "",
      });
      return;
    case "entry_appended":
      writeEvent(requestId, "session_entry_appended", { entry: event.entry });
      return;
    case "agent_settled":
      if (state.pendingReload) {
        state.pendingReload = false;
        if (state.pendingRecreate) {
          state.pendingRecreate = false;
          void closeNativeAgentSession(state.sessionId).catch(() => {});
          return;
        }
        void state.session.reload().catch((error) => {
          stderr.write(`pi session reload failed: ${errorMessageWithCause(error)}\n`);
        });
      }
      return;
    default:
      return;
  }
}

async function createNativeAgentSession(
  sessionId: string,
  payload: JsonObject,
  config: ModelConfig,
  history: AgentMessage[],
  acpRecord?: AcpSessionRecord,
  contextPolicy: ContextPolicy = contextPolicyFor(payload),
): Promise<AgentSessionState> {
  const workspaceDirectory = asString(payload.workspace_directory, process.cwd()) || process.cwd();
  const termuxWorkspaceDirectory = asString(payload.termux_workspace_directory, workspaceDirectory) || workspaceDirectory;
  let runtime = runtimeForPayload(payload);
  const platform = platformForPayload(payload);
  // v3.0.83 — the TURN-CONTEXT holder: created with the session (and
  // kept on the state so it survives the per-turn set/clear cycle);
  // runNativeAgentTurn fills it from payload.turn_context right before
  // the prompt and clears it in finally. The provider stream wrapper
  // reads it at REQUEST time.
  const turnContextHolder = { context: "" };
  const built = await buildModelRuntime(config, turnContextHolder);
  const settingsManager = sessionSettings(payload, config);
  const agentDir = asString(payload.agent_directory, path.join(os.homedir(), ".pi", "agent"));
  const configuredExtensionPaths = stringArray(payload.extension_paths);
  const { extensionPaths: additionalExtensionPaths, signature: extensionSignature } =
    await resolveNativeExtensionSet(
      workspaceDirectory,
      configuredExtensionPaths,
      {
        disabledExtensionPaths: stringArray(payload.disabled_extension_paths),
        disabledPackageSources: stringArray(payload.disabled_package_sources),
      },
    );
  const resourceLoader = new DefaultResourceLoader({
    cwd: workspaceDirectory,
    agentDir,
    settingsManager,
    additionalExtensionPaths,
    extensionFactories: acpRecord
      ? [arixFailurePolicyExtensionFactory, acpPermissionExtensionFactory(acpRecord)]
      : [arixFailurePolicyExtensionFactory],
    additionalSkillPaths: stringArray(payload.skill_paths),
    appendSystemPrompt: [asString(payload.system_prompt)].filter(Boolean),
  });
  await resourceLoader.reload({
    resolveProjectTrust: async () => asBoolean(payload.workspace_trusted, false),
  });
  const { manager, existed } = await createSessionManager(sessionId, workspaceDirectory, payload);
  // v3.0.78 — DYNAMIC CONTEXT: the coding-agent native tools ship on
  // Standard/Deep turns ONLY. Their seven schemas cost ~1.2k tokens per
  // request; a Minimal turn ("hi") never calls them, and the app already
  // reduces the advertised HOST tools to the conversational subset for
  // that tier (see ArixDynamicContextPolicy). Tool-signature changes
  // recreate the session (the JSONL history persists), so a later
  // Standard turn transparently restores the full set.
  const minimalTools = contextPolicy.tier === "minimal";
  if (!existed) {
    // v3.0.77 — the replay-path budget is tier-scaled by the dynamic
    // context policy (see contextPolicyFor); payloads without a policy
    // keep the legacy 0.6 fraction exactly.
    const boundedHistory = trimHistoryForContextWindow(
      history,
      typeof built.model.contextWindow === "number" && built.model.contextWindow > 0
        ? built.model.contextWindow
        : 128_000,
      contextPolicy.trimFraction,
    );
    boundedHistory.forEach((message) => manager.appendMessage(message as never));
  }
  if (existed) {
    const runtimeEntry = manager.getEntries().findLast((entry) =>
      entry.type === "custom" && entry.customType === "arix_runtime"
    );
    if (runtimeEntry?.type === "custom") {
      const persistedRuntime = asString(asObject(runtimeEntry.data).runtime);
      if (persistedRuntime === "termux") runtime = persistedRuntime;
    }
  }
  const state = {
    sessionId,
    configSignature: modelConfigSignature(config),
    systemPromptSignature: systemPromptSignatureFor(payload),
    toolSignature: hostToolSignature(allowedHostToolDefinitions(payload.host_tools, platform), contextPolicy.tier),
    skillSignature: JSON.stringify(stringArray(payload.skill_paths).sort()),
    mcpConfigSignature: await mcpConfigFingerprint(agentDir),
    extensionSignature,
    configuredExtensionPaths,
    pendingRecreate: false,
    workspaceDirectory,
    termuxWorkspaceDirectory,
    runtime,
    platform,
    modelRuntime: built.modelRuntime,
    model: built.model,
    compatibilityFallbackState: built.compatibilityFallbackState,
    credentialStore: built.credentialStore,
    // v3.0.77 — dynamic-context compaction trigger for this session;
    // each run_turn refreshes it from the turn's classified tier, and
    // follow-up prompts reuse the latest value. Default = legacy 0.8.
    contextCompactThreshold: contextPolicy.compactThreshold,
    // v3.0.78 — whether this session runs without the coding-agent native
    // tools (Minimal-tier turns).
    minimalTools,
    // v3.0.83 — per-turn ephemeral-context holder (see the comment at
    // buildModelRuntime above).
    turnContextHolder,
    session: undefined as unknown as AgentSession,
    resourceLoader,
    settingsManager,
    pendingReload: false,
    currentRequestId: "",
    turnUsage: emptyTurnUsage(),
    outputDurationMillis: 0,
    toolArgsById: new Map<string, unknown>(),
    lastAccessedAt: Date.now(),
  } satisfies AgentSessionState;
  const customTools = [
    ...(minimalTools ? [] : nativeToolDefinitions(state)),
    ...allowedHostToolDefinitions(payload.host_tools, platform).map((tool) =>
      createAgentHostToolDefinition(state, tool),
    ),
  ];
  const created = await createAgentSession({
    cwd: workspaceDirectory,
    agentDir,
    modelRuntime: built.modelRuntime,
    model: built.model,
    thinkingLevel: thinkingLevelFor(payload),
    resourceLoader,
    settingsManager,
    sessionManager: manager,
    noTools: "builtin",
    customTools,
  });
  state.session = created.session;
  // v3.0.86 — usage tracking rides ahead of the event fan-out so every
  // message_end (tool loops, retries, follow-ups) accumulates into the
  // per-turn totals regardless of the emission switch.
  state.session.subscribe((event) => {
    trackTurnUsage(state, event);
    emitAgentSessionEvent(state, event);
  });
  await state.session.bindExtensions({ mode: "rpc" });
  setActiveSessionTools(state);
  agentSessions.set(sessionId, state);
  return state;
}

async function listDiscoveredSkills(payload: JsonObject): Promise<JsonObject> {
  const workspaceDirectory = asString(payload.workspace_directory, process.cwd()) || process.cwd();
  const agentDir = asString(payload.agent_directory, path.join(os.homedir(), ".pi", "agent"));
  const settingsManager = SettingsManager.create(workspaceDirectory, agentDir, {
    projectTrusted: asBoolean(payload.workspace_trusted, true),
  });
  const resourceLoader = new DefaultResourceLoader({
    cwd: workspaceDirectory,
    agentDir,
    settingsManager,
    additionalSkillPaths: stringArray(payload.skill_paths),
    noExtensions: true,
    noPromptTemplates: true,
    noThemes: true,
    noContextFiles: true,
  });
  await resourceLoader.reload({
    resolveProjectTrust: async () => asBoolean(payload.workspace_trusted, true),
  });
  const managedRoot = path.resolve(workspaceDirectory, ".arix", "skills");
  const skills = resourceLoader.getSkills().skills
    .filter((skill) => {
      const relative = path.relative(managedRoot, path.resolve(skill.filePath));
      return skill.sourceInfo.origin !== "package" &&
        relative !== "" &&
        (relative.startsWith(`..${path.sep}`) || path.isAbsolute(relative));
    })
    .map((skill) => ({
      name: skill.name,
      description: skill.description,
      file_path: skill.filePath,
      base_dir: skill.baseDir,
      source: skill.sourceInfo.source,
      scope: skill.sourceInfo.scope,
      origin: skill.sourceInfo.origin,
    }));
  return { skills };
}

function rejectPendingHostToolsForAgentSession(sessionId: string, message: string): void {
  for (const [toolRequestId, pending] of pendingHostToolRequests) {
    if (pending.sessionId !== sessionId) continue;
    pending.reject(new Error(message));
    pendingHostToolRequests.delete(toolRequestId);
  }
}

function nativeBridgePrompt(rawMessage: unknown): { text: string; images: ImageContent[] } {
  const messages = normalizeMessages([rawMessage]);
  const message = messages[0];
  if (!message || message.role !== "user") throw new Error("A user message is required.");
  if (typeof message.content === "string") return { text: message.content, images: [] };
  return {
    text: message.content
      .filter((part): part is TextContent => part.type === "text")
      .map((part) => part.text)
      .join("\n"),
    images: message.content.filter((part): part is ImageContent => part.type === "image"),
  };
}

async function closeNativeAgentSession(sessionId: string): Promise<boolean> {
  const state = agentSessions.get(sessionId);
  if (!state) return false;
  agentSessions.delete(sessionId);
  rejectPendingHostToolsForAgentSession(sessionId, "Host tool execution ended with the Pi session.");
  for (const [operationId, pending] of pendingRuntimeOperations) {
    if (pending.sessionId !== sessionId) continue;
    pending.reject(new Error("Runtime operation ended with the Pi session."));
    pendingRuntimeOperations.delete(operationId);
  }
  await state.session.abort().catch(() => undefined);
  state.session.dispose();
  return true;
}

function nativeSessionFromPayload(payload: JsonObject): AgentSessionState {
  const sessionId = asString(payload.session_id).trim();
  if (!sessionId) throw new Error("session_id is required for Pi AgentSession operations.");
  const state = agentSessions.get(sessionId);
  if (!state) throw new Error(`Unknown Pi session: ${sessionId}`);
  return state;
}

async function ensureNativeSessionForRequest(payload: JsonObject): Promise<AgentSessionState> {
  const sessionId = asString(payload.session_id).trim();
  if (!sessionId) throw new Error("session_id is required for Pi AgentSession operations.");
  const existing = agentSessions.get(sessionId);
  if (existing) return existing;
  const config = normalizeModelConfig(payload.model_config ?? defaultModelConfig);
  if (!config) throw new Error(`Unknown Pi session: ${sessionId}`);
  return createNativeAgentSession(sessionId, payload, config, []);
}

function nativeSessionPayload(state: AgentSessionState): JsonObject {
  return {
    session_id: state.session.sessionId,
    session_file: state.session.sessionFile ?? "",
    session_leaf_id: state.session.sessionManager.getLeafId() ?? "",
    runtime: state.runtime,
    cwd: state.runtime === "termux" ? state.termuxWorkspaceDirectory : state.workspaceDirectory,
    is_idle: state.session.isIdle,
    is_streaming: state.session.isStreaming,
    is_compacting: state.session.isCompacting,
    active_tools: state.session.getActiveToolNames(),
    tools: state.session.getAllTools().map((tool) => ({
      name: tool.name,
      description: tool.description,
      parameters: tool.parameters,
      prompt_guidelines: tool.promptGuidelines ?? [],
      source_path: tool.sourceInfo.path,
    })),
    entries: state.session.sessionManager.getEntries(),
    tree: state.session.sessionManager.getTree(),
  };
}

async function compactNativeAgentSession(id: string, payload: JsonObject): Promise<JsonObject> {
  const state = await ensureNativeSessionForRequest(payload);
  if (!state.session.isIdle) throw new Error("Cannot manually compact a busy Pi AgentSession.");
  state.currentRequestId = id;
  activeAborters.set(id, () => state.session.abortCompaction());
  try {
    const result = await state.session.compact(asString(payload.custom_instructions).trim() || undefined);
    return { ...nativeSessionPayload(state), compaction: result as unknown as JsonObject };
  } finally {
    activeAborters.delete(id);
    if (state.currentRequestId === id) state.currentRequestId = "";
  }
}

async function navigateNativeAgentSession(id: string, payload: JsonObject): Promise<JsonObject> {
  const state = await ensureNativeSessionForRequest(payload);
  if (!state.session.isIdle) throw new Error("Cannot navigate a busy Pi AgentSession.");
  const entryId = asString(payload.entry_id).trim();
  if (!entryId && asBoolean(payload.reset, false)) {
    state.session.sessionManager.resetLeaf();
    return { ...nativeSessionPayload(state), navigation: { reset: true } };
  }
  if (!entryId) throw new Error("entry_id is required for Pi session navigation.");
  state.currentRequestId = id;
  activeAborters.set(id, () => state.session.abortBranchSummary());
  try {
    const result = await state.session.navigateTree(entryId, {
      summarize: asBoolean(payload.summarize, false),
      customInstructions: asString(payload.custom_instructions).trim() || undefined,
      replaceInstructions: asBoolean(payload.replace_instructions, false),
      label: asString(payload.label).trim() || undefined,
    });
    return { ...nativeSessionPayload(state), navigation: result };
  } finally {
    activeAborters.delete(id);
    if (state.currentRequestId === id) state.currentRequestId = "";
  }
}

async function reloadNativeAgentSession(payload: JsonObject): Promise<JsonObject> {
  const state = nativeSessionFromPayload(payload);
  if (!state.session.isIdle) {
    state.pendingReload = true;
    return { ...nativeSessionPayload(state), reloaded: false, scheduled: true };
  }
  await state.session.reload();
  return { ...nativeSessionPayload(state), reloaded: true, scheduled: false };
}

function exportNativeAgentSession(payload: JsonObject): JsonObject {
  const state = nativeSessionFromPayload(payload);
  const outputPath = asString(payload.output_path).trim() || undefined;
  return {
    ...nativeSessionPayload(state),
    exported_path: state.session.exportToJsonl(outputPath),
  };
}

async function importNativeAgentSession(payload: JsonObject): Promise<JsonObject> {
  const sessionId = asString(payload.session_id).trim();
  const jsonl = asString(payload.jsonl);
  if (!sessionId || !jsonl.trim()) throw new Error("session_id and jsonl are required.");
  const firstLine = jsonl.split(/\r?\n/, 1)[0] ?? "";
  let header: JsonObject;
  try {
    header = JSON.parse(firstLine) as JsonObject;
  } catch {
    throw new Error("Pi JSONL header is invalid.");
  }
  if (header.type !== "session" || asString(header.id) !== sessionId) {
    throw new Error("Pi JSONL header/session id mismatch.");
  }
  const sessionDirectory = asString(
    payload.session_directory,
    path.join(os.homedir(), ".arix", "agent-sessions"),
  );
  await fs.mkdir(sessionDirectory, { recursive: true });
  const target = path.join(sessionDirectory, `${Date.now()}_${sessionId}.jsonl`);
  // v3.0.50 — path-confinement guard: a session_id containing separators
  // or traversal segments used to escape the sessions directory on write
  // (the JSONL header check only compares the id string, not the path).
  if (path.basename(target) !== `${Date.now()}_${sessionId}.jsonl`) {
    throw new Error("session_id must not contain path separators or traversal segments.");
  }
  const temporary = `${target}.tmp-${process.pid}`;
  await fs.writeFile(temporary, jsonl.endsWith("\n") ? jsonl : `${jsonl}\n`, "utf8");
  await fs.rename(temporary, target);
  await closeNativeAgentSession(sessionId);
  return { imported: true, session_id: sessionId, session_file: target };
}

async function mcpConfigFingerprint(agentDirectory: string): Promise<string> {
  const file = path.join(agentDirectory, "mcp.json");
  try {
    const stats = await fs.stat(file);
    return `${stats.size}:${stats.mtimeMs}`;
  } catch {
    return "none";
  }
}

async function prepareNativeAgentSession(
  payload: JsonObject,
  history: AgentMessage[],
  contextPolicy: ContextPolicy = contextPolicyFor(payload),
): Promise<{ state: AgentSessionState; reused: boolean }> {
  const config = normalizeModelConfig(payload.model_config ?? defaultModelConfig);
  const sessionId = asString(payload.session_id).trim();
  if (!sessionId) throw new Error("session_id is required for Pi AgentSession.");
  const platform = platformForPayload(payload);
  const signature = hostToolSignature(allowedHostToolDefinitions(payload.host_tools, platform), contextPolicy.tier);
  const workspaceDirectory = asString(payload.workspace_directory, process.cwd()) || process.cwd();
  const skillSignature = JSON.stringify(stringArray(payload.skill_paths).sort());
  const agentDirectory = asString(payload.agent_directory, path.join(os.homedir(), ".pi", "agent"));
  const mcpSignature = await mcpConfigFingerprint(agentDirectory);
  const { signature: extensionSignature } = await resolveNativeExtensionSet(
    workspaceDirectory,
    stringArray(payload.extension_paths),
    {
      disabledExtensionPaths: stringArray(payload.disabled_extension_paths),
      disabledPackageSources: stringArray(payload.disabled_package_sources),
    },
  );
  const existing = agentSessions.get(sessionId);
  const reusable = existing &&
    existing.configSignature === modelConfigSignature(config) &&
    existing.systemPromptSignature === systemPromptSignatureFor(payload) &&
    existing.toolSignature === signature &&
    existing.skillSignature === skillSignature &&
    existing.mcpConfigSignature === mcpSignature &&
    existing.extensionSignature === extensionSignature &&
    existing.workspaceDirectory === workspaceDirectory &&
    existing.runtime === runtimeForPayload(payload);
  if (existing && !reusable) await closeNativeAgentSession(sessionId);
  if (!reusable) {
    return {
      state: await createNativeAgentSession(sessionId, payload, config, history, undefined, contextPolicy),
      reused: false,
    };
  }
  // v3.0.50 — heal a reused session whose shared credential state was
  // emptied by clear_provider_credential (the app clears on every
  // provider-config edit). Same-signature reuse used to keep serving
  // `credential: undefined` → "No API key found for …" until restart.
  if (existing.credentialStore) {
    const freshCredential = credentialForConfig(config);
    if (freshCredential) await existing.credentialStore.seedIfEmpty(freshCredential);
  }
  existing.lastAccessedAt = Date.now();
  setActiveSessionTools(existing);
  return { state: existing, reused: true };
}

// v3.0.30 — image-aware token estimation. The old estimator counted
// `JSON.stringify(message).length / 4`, which included full base64 image
// payloads 1:1 — a single ~500 KB screenshot measured as ~167k "tokens",
// permanently above the compaction budget, so image-bearing sessions were
// preemptively compacted on EVERY subsequent turn, irreversibly summarizing
// away the conversation. Image data is now excluded from the character count
// and each image part contributes a fixed tile-based constant instead
// (~1100 tokens ≈ an auto-resized ~1024px image at moderate detail).
const EstimatedTokensPerImage = 1_100;

function estimateSingleMessageTokens(message: AgentMessage): number {
  let images = 0;
  let chars = 0;
  const content = (message as { content?: unknown }).content;
  if (Array.isArray(content)) {
    for (const part of content) {
      if (
        part &&
        typeof part === "object" &&
        (part as { type?: unknown }).type === "image"
      ) {
        images += 1;
      } else {
        try {
          chars += JSON.stringify(part).length;
        } catch {
          chars += 200;
        }
      }
    }
    chars += 64; // role/timestamp/envelope overhead
  } else {
    try {
      chars = JSON.stringify(message).length;
    } catch {
      chars = 2_000;
    }
  }
  return Math.ceil(chars / 4) + images * EstimatedTokensPerImage;
}

function estimateMessageTokens(messages: AgentMessage[]): number {
  let total = 0;
  for (const message of messages) {
    total += estimateSingleMessageTokens(message);
  }
  return total;
}

const CONTEXT_OVERFLOW_PATTERNS: RegExp[] = [
  /context[ _]length/i,
  /context[ _]window/i,
  /context[ _]size/i,
  /maximum[ _]context/i,
  /max[_ ](?:tokens|prompt|context)/i,
  /too[ _]many[ _]tokens/i,
  /prompt[ _]is[ _]too[ _]long/i,
  /input[ _]tokens?[_ ]exceed/i,
  /exceeds?[ _]the[ _](?:token|context|prompt)/i,
  /input[ _]length[` ']*exceed/i,
  /request[ _]too[ _]large/i,
  /\b400\b.*\btokens?\b/i,
  /reducing[ _]the[ _]message/i,
  /reduce[ _]the[ _]length/i,
];

function isContextOverflowError(errorText: string): boolean {
  const text = (errorText ?? "").toString();
  if (!text) return false;
  return CONTEXT_OVERFLOW_PATTERNS.some((pattern) => pattern.test(text));
}

async function compactSessionIfNearContextLimit(
  id: string,
  state: AgentSessionState,
  nextPromptText: string,
  threshold: number = state.contextCompactThreshold ?? 0.8,
): Promise<void> {
  try {
    if (!state.session.isIdle) return;
    const messages = state.session.messages;
    if (messages.length < 6) return;
    const contextWindow =
      typeof state.model.contextWindow === "number" && state.model.contextWindow > 0
        ? state.model.contextWindow
        : 128_000;
    // v3.0.77 — the threshold is tier-scaled by the dynamic context policy
    // (simple turns compact earlier — a dense summary is enough for them;
    // complex turns keep more raw history). Compaction itself always runs
    // the same information-preserving instruction.
    const budget = Math.floor(contextWindow * Math.min(0.95, Math.max(0.05, threshold)));
    const estimatedTokens =
      estimateMessageTokens(messages) + Math.ceil((nextPromptText?.length ?? 0) / 4);
    if (estimatedTokens <= budget) return;
    bridgeDebug("preemptive_compaction", {
      session_id: state.sessionId,
      estimated_tokens: estimatedTokens,
      budget_tokens: budget,
      context_tier_threshold: threshold,
    });
    writeEvent(id, "compaction_start", { reason: "preemptive" });
    const compaction = await state.session.compact(
      "Produce a dense, information-preserving summary of this conversation so far. " +
        "Keep all user goals, decisions, file paths, commands and their results, and any " +
        "pending work; drop verbose tool output and duplicated content.",
    );
    writeEvent(id, "compaction_end", {
      reason: "preemptive",
      aborted: false,
      will_retry: false,
      error_message: "",
      tokens_before: compaction.tokensBefore,
    });
  } catch (error) {
    writeEvent(id, "compaction_end", {
      reason: "preemptive",
      aborted: true,
      will_retry: false,
      error_message: errorMessageWithCause(error),
    });
  }
}

function trimHistoryForContextWindow(
  history: AgentMessage[],
  contextWindow: number,
  trimFraction: number = 0.6,
): AgentMessage[] {
  if (history.length <= 2) return history;
  // v3.0.77 — the fraction is tier-scaled by the dynamic context policy
  // (deep tasks keep more replayed history; simple tasks keep less).
  const budget = Math.floor(contextWindow * Math.min(0.95, Math.max(0.05, trimFraction)));
  const totalTokens = estimateMessageTokens(history);
  if (totalTokens <= budget) return history;
  const kept: AgentMessage[] = [];
  let keptTokens = 0;
  for (let index = history.length - 1; index >= 0; index -= 1) {
    const messageTokens = estimateMessageTokens([history[index]]);
    if (kept.length > 0 && keptTokens + messageTokens > budget) break;
    kept.unshift(history[index]);
    keptTokens += messageTokens;
  }
  let pairSafeStart = 0;
  while (pairSafeStart < kept.length && kept[pairSafeStart]?.role === "toolResult") {
    pairSafeStart += 1;
  }
  const pairSafe = pairSafeStart > 0 ? kept.slice(pairSafeStart) : kept;
  if (pairSafe.length === history.length) return history;
  bridgeDebug("history_trimmed_for_context", {
    original_messages: history.length,
    kept_messages: pairSafe.length,
    dropped_orphaned_tool_results: pairSafeStart,
    estimated_tokens: totalTokens,
    budget_tokens: budget,
    trim_fraction: trimFraction,
  });
  return pairSafe;
}

async function runNativeAgentPrompt(
  id: string,
  state: AgentSessionState,
  text: string,
  images: ImageContent[],
  // v3.0.86 — deferred follow-ups (an injected message delivered to an
  // IDLE session) CONTINUE the turn that was already reported, so their
  // usage must accumulate instead of restarting; normal run_turn prompts
  // reset the totals.
  resetUsage = true,
): Promise<AssistantMessage> {
  state.currentRequestId = id;
  state.lastAccessedAt = Date.now();
  state.turnStartedAtMillis = Date.now();
  state.lastAgentEventAtMillis = Date.now();
  if (resetUsage) resetTurnUsage(state);
  activeAborters.set(id, () => state.session.abort());
  const heartbeat = setInterval(() => {
    try {
      const lastAgentEvent = state.lastAgentEventAtMillis ?? state.turnStartedAtMillis ?? Date.now();
      const activeTools = state.session.getActiveToolNames();
      writeEvent(id, "bridge_heartbeat", {
        session_id: state.sessionId,
        streaming: state.session.isStreaming,
        compacting: state.session.isCompacting,
        active_tool_count: activeTools.length,
        active_tools: activeTools.slice(0, 8),
        agent_idle_ms: Math.max(0, Date.now() - lastAgentEvent),
      });
    } catch {
    }
  }, 15_000);
  try {
    const assistantBefore = latestAssistantMessage(state.session.messages);
    await compactSessionIfNearContextLimit(id, state, text);
    let promptError: unknown;
    let overflowed = false;
    try {
      await state.session.prompt(text, { images: images.length > 0 ? images : undefined });
    } catch (error) {
      promptError = error;
      if (!isContextOverflowError(errorMessageWithCause(error))) throw error;
      overflowed = true;
    }
    await state.session.waitForIdle();
    let message = latestAssistantMessage(state.session.messages);
    if (!overflowed && message && isContextOverflowError(message.errorMessage ?? "")) {
      overflowed = true;
    }
    if (overflowed && state.session.isIdle) {
      bridgeDebug("context_overflow_auto_compact", {
        session_id: state.sessionId,
        prompt_threw: promptError !== undefined,
      });
      writeEvent(id, "compaction_start", { reason: "context_overflow" });
      try {
        const compaction = await state.session.compact(
          "Produce a dense, information-preserving summary of this conversation so far. " +
            "Keep all user goals, decisions, file paths, commands and their results, and any " +
            "pending work; drop verbose tool output and duplicated content.",
        );
        writeEvent(id, "compaction_end", {
          reason: "context_overflow",
          aborted: false,
          will_retry: false,
          error_message: "",
          tokens_before: compaction.tokensBefore,
        });
      } catch (compactionError) {
        writeEvent(id, "compaction_end", {
          reason: "context_overflow",
          aborted: true,
          will_retry: false,
          error_message: errorMessageWithCause(compactionError),
        });
      }
      if (promptError !== undefined) {
        promptError = undefined;
        try {
          await state.session.prompt(text, { images: images.length > 0 ? images : undefined });
        } catch (retryError) {
          promptError = retryError;
        }
        await state.session.waitForIdle();
      }
      message = latestAssistantMessage(state.session.messages);
      if (promptError !== undefined) throw promptError;
    }
    if (!message) throw new Error(`Pi session ${state.sessionId} has no assistant response.`);
    if (message === assistantBefore) {
      throw new Error(`Pi session ${state.sessionId} produced no new assistant response.`);
    }
    return message;
  } finally {
    clearInterval(heartbeat);
    activeAborters.delete(id);
    if (state.currentRequestId === id) state.currentRequestId = "";
    state.lastAccessedAt = Date.now();
  }
}

async function runNativeAgentTurn(id: string, payload: JsonObject): Promise<JsonObject> {
  const messages = normalizeMessages(payload.messages);
  const prompt = promptFromLastUserMessage(messages);
  // v3.0.77 — the turn's classified context tier drives the replay trim
  // and the preemptive compaction trigger (see contextPolicyFor).
  const contextPolicy = contextPolicyFor(payload);
  const { state, reused } = await prepareNativeAgentSession(payload, prompt.history, contextPolicy);
  state.contextCompactThreshold = contextPolicy.compactThreshold;
  const requestedThinkingLevel = thinkingLevelFor(payload) ?? "off";
  state.session.setThinkingLevel(requestedThinkingLevel);
  bridgeDiagnostic("agent_turn_thinking_level", {
    session_id: state.sessionId,
    requested: requestedThinkingLevel,
    effective: state.session.thinkingLevel,
    session_reused: reused,
    context_tier: contextPolicy.tier,
  });
  // v3.0.83 — TURN CONTEXT, OUT-OF-BAND (token-regression fix): the
  // ephemeral block (memory / session-context / task-state) is injected
  // into every MODEL REQUEST of THIS turn by the provider stream
  // wrapper — it is NOT part of prompt.text, so the kernel never
  // persists it and history stays clean across turns.
  state.turnContextHolder.context = asString(payload.turn_context).trim();
  activeTurnRequestIds.add(id);
  try {
    const message = await runNativeAgentPrompt(id, state, prompt.text, prompt.images);
    return {
      ...assistantPayload(message),
      // v3.0.86 — WHOLE-TURN TOTALS: the bridge accumulated every API
      // call of this turn (tool loops, retries); hand the app the total
      // with cache read/write and active generation time instead of the
      // last single-call usage.
      usage: turnUsagePayload(state),
      ...(await credentialPayload(state.credentialStore)),
      session_id: state.session.sessionId,
      session_file: state.session.sessionFile ?? "",
      session_leaf_id: state.session.sessionManager.getLeafId() ?? "",
      runtime: state.runtime,
      cwd: state.runtime === "termux" ? state.termuxWorkspaceDirectory : state.workspaceDirectory,
      session_reused: reused,
      developer_role_unsupported_detected:
        state.compatibilityFallbackState.developerRoleUnsupportedDetected,
    };
  } finally {
    activeTurnRequestIds.delete(id);
    state.turnContextHolder.context = "";
  }
}

async function steerNativeAgentSession(payload: JsonObject): Promise<JsonObject> {
  const state = agentSessions.get(asString(payload.session_id).trim());
  if (!state || !state.session.isStreaming) return { accepted: false };
  const prompt = nativeBridgePrompt(payload.message);
  await state.session.steer(prompt.text, prompt.images);
  return { accepted: true };
}

async function followUpNativeAgentSession(id: string, payload: JsonObject): Promise<JsonObject> {
  const state = agentSessions.get(asString(payload.session_id).trim());
  if (!state) throw new Error(`Unknown Pi session: ${asString(payload.session_id)}`);
  const prompt = nativeBridgePrompt(payload.message);
  if (state.session.isStreaming) {
    await state.session.followUp(prompt.text, prompt.images);
    await state.session.waitForIdle();
    const message = latestAssistantMessage(state.session.messages);
    if (!message) throw new Error(`Pi session ${state.sessionId} has no assistant response.`);
    return {
      ...assistantPayload(message),
      usage: turnUsagePayload(state),
      developer_role_unsupported_detected:
        state.compatibilityFallbackState.developerRoleUnsupportedDetected,
    };
  }
  // v3.0.86 — an injected message delivered to an idle session continues
  // the turn that was already reported, so its usage keeps accumulating
  // instead of restarting (resetUsage = false) and the response reports
  // the updated whole-turn totals.
  return {
    ...assistantPayload(await runNativeAgentPrompt(id, state, prompt.text, prompt.images, false)),
    usage: turnUsagePayload(state),
    developer_role_unsupported_detected:
      state.compatibilityFallbackState.developerRoleUnsupportedDetected,
  };
}

async function runSimpleCompletion(id: string, payload: JsonObject, stream: boolean): Promise<JsonObject> {
  const config = normalizeModelConfig(payload.model_config ?? defaultModelConfig);
  const { models, model, credentialStore, compatibilityFallbackState } = buildModels(config);
  const controller = new AbortController();
  activeAborters.set(id, () => controller.abort());
  try {
    const context = buildContext(payload);
    const options = streamOptionsFor(payload, controller.signal, config, model);
    if (stream) {
      const eventStream = models.streamSimple(model, context, options);
      for await (const event of eventStream) {
        emitStreamEvent(id, event);
      }
      const message = await eventStream.result();
      return {
        ...assistantPayload(message),
        ...(await credentialPayload(credentialStore)),
        developer_role_unsupported_detected:
          compatibilityFallbackState.developerRoleUnsupportedDetected,
      };
    }
    const message = await models.completeSimple(model, context, options);
    return {
      ...assistantPayload(message),
      ...(await credentialPayload(credentialStore)),
      developer_role_unsupported_detected:
        compatibilityFallbackState.developerRoleUnsupportedDetected,
    };
  } finally {
    activeAborters.delete(id);
  }
}

function requestAuthPrompt(
  requestId: string,
  prompt: {
    type: "text" | "secret" | "select" | "manual_code";
    message: string;
    placeholder?: string;
    options?: readonly { id: string; label: string; description?: string }[];
    signal?: AbortSignal;
  },
): Promise<string> {
  const promptId = `auth-prompt-${Date.now()}-${++authPromptCounter}`;
  writeEvent(requestId, "auth_prompt", {
    prompt_id: promptId,
    prompt_type: prompt.type,
    message: prompt.message,
    placeholder: prompt.placeholder ?? "",
    options: prompt.options ?? [],
  });
  return new Promise<string>((resolve, reject) => {
    if (prompt.signal?.aborted) {
      reject(new Error("Authentication prompt was cancelled."));
      return;
    }
    const abortListener = () => {
      pendingAuthPrompts.delete(promptId);
      reject(new Error("Authentication prompt was cancelled."));
    };
    prompt.signal?.addEventListener("abort", abortListener, { once: true });
    pendingAuthPrompts.set(promptId, {
      requestId,
      resolve: (value) => {
        prompt.signal?.removeEventListener("abort", abortListener);
        resolve(value);
      },
      reject: (error) => {
        prompt.signal?.removeEventListener("abort", abortListener);
        reject(error);
      },
    });
  });
}

function resolveAuthPrompt(payload: JsonObject): boolean {
  const promptId = asString(payload.prompt_id).trim();
  const pending = promptId ? pendingAuthPrompts.get(promptId) : undefined;
  if (!pending) return false;
  pendingAuthPrompts.delete(promptId);
  if (asBoolean(payload.cancelled, false)) {
    pending.reject(new Error("Authentication was cancelled."));
  } else {
    pending.resolve(asString(payload.value));
  }
  return true;
}

async function loginProvider(id: string, payload: JsonObject): Promise<JsonObject> {
  const providerConfigId = asString(payload.provider_config_id).trim();
  if (!providerConfigId) throw new Error("provider_config_id is required for provider login.");
  const providerId = asString(payload.provider_id).trim();
  const provider = builtinProviderById.get(providerId);
  if (!provider) throw new Error(`Unknown built-in Pi provider: ${providerId}`);
  const authMethod = asString(payload.auth_method, "oauth").trim();
  const controller = new AbortController();
  activeAborters.set(id, () => controller.abort());
  const callbacks = {
    signal: controller.signal,
    prompt: (prompt) => {
      return requestAuthPrompt(id, prompt);
    },
    notify: (event) => {
      switch (event.type) {
        case "auth_url":
          writeEvent(id, "auth_url", {
            url: event.url,
            instructions: event.instructions ?? "",
          });
          break;
        case "device_code":
          writeEvent(id, "auth_device_code", {
            user_code: event.userCode,
            verification_uri: event.verificationUri,
            interval_seconds: event.intervalSeconds,
            expires_in_seconds: event.expiresInSeconds,
          });
          break;
        case "progress":
          writeEvent(id, "auth_progress", { message: event.message });
          break;
        case "info":
          writeEvent(id, "auth_progress", {
            message: event.message,
            links: event.links ?? [],
          });
          break;
      }
    },
  } satisfies AuthInteraction;
  try {
    if (authMethod === "api_key") {
      const apiKey = provider.auth.apiKey;
      if (!apiKey) throw new Error(`Pi provider ${providerId} does not support API key authentication.`);
      if (!apiKey.login) {
        throw new Error(`Pi provider ${providerId} uses ambient credentials and has no interactive login.`);
      }
      const credential = await apiKey.login(callbacks);
      return {
        provider_id: providerId,
        auth_method: "api_key",
        api_key: credential.key ?? "",
        provider_env: credential.env ?? {},
      };
    }
    if (authMethod !== "oauth") {
      throw new Error(`Unsupported Pi authentication method: ${authMethod}`);
    }
    const oauth = provider.auth.oauth;
    if (!oauth) throw new Error(`Pi provider ${providerId} does not support OAuth.`);
    const credential = await oauth.login(callbacks);
    await replaceSharedCredential(providerConfigId, credential);
    return {
      provider_id: providerId,
      auth_method: "oauth",
      oauth_credential: credential as unknown as JsonObject,
    };
  } finally {
    activeAborters.delete(id);
    for (const [promptId, prompt] of pendingAuthPrompts) {
      if (prompt.requestId === id) {
        prompt.reject(new Error("Authentication flow ended before the prompt completed."));
        pendingAuthPrompts.delete(promptId);
      }
    }
  }
}

async function clearProviderCredential(payload: JsonObject): Promise<JsonObject> {
  const providerConfigId = asString(payload.provider_config_id).trim();
  if (!providerConfigId) throw new Error("provider_config_id is required to clear provider credentials.");
  return { cleared: await clearSharedCredential(providerConfigId) };
}

async function prewarmNativeAgentSession(payload: JsonObject): Promise<JsonObject> {
  const requestedId = asString(payload.session_id).trim() || "arix-prewarm";
  const prewarmPayload: JsonObject = { ...payload, session_id: requestedId };
  const { state, reused } = await prepareNativeAgentSession(prewarmPayload, []);
  bridgeDebug("prewarm_session", {
    session_id: state.sessionId,
    reused,
  });
  return {
    prewarmed: true,
    session_id: state.sessionId,
    session_reused: reused,
  };
}

async function closeAgentSessionRequest(payload: JsonObject): Promise<JsonObject> {
  const sessionId = asString(payload.session_id).trim();
  if (!sessionId) throw new Error("session_id is required to close a Pi AgentSession.");
  const state = agentSessions.get(sessionId);
  const sessionFile = state?.session.sessionFile ?? asString(payload.session_file).trim();
  const closed = await closeNativeAgentSession(sessionId);
  let deleted = false;
  if (asBoolean(payload.delete_file, false) && sessionFile) {
    const expectedSuffix = `_${sessionId}.jsonl`;
    if (!path.basename(sessionFile).endsWith(expectedSuffix)) {
      throw new Error("Refusing to delete a Pi session file that does not match the session id.");
    }
    deleted = await fs.unlink(sessionFile).then(() => true).catch((error: NodeJS.ErrnoException) => {
      if (error.code === "ENOENT") return false;
      throw error;
    });
  }
  return { closed, deleted, session_file: sessionFile };
}

async function abortBridgeTarget(payload: JsonObject): Promise<JsonObject> {
  const targetId = asString(payload.request_id, asString(payload.target_id)).trim();
  const sessionId = asString(payload.session_id).trim();
  const aborter = targetId ? activeAborters.get(targetId) : undefined;
  const state = sessionId ? agentSessions.get(sessionId) : undefined;
  if (aborter) {
    void Promise.resolve(aborter()).catch((error) => {
      stderr.write(`pi-bridge abort failed: ${error instanceof Error ? error.message : String(error)}\n`);
    });
  } else if (state) {
    void state.session.abort().catch((error) => {
      stderr.write(`pi-bridge abort failed: ${error instanceof Error ? error.message : String(error)}\n`);
    });
  }
  for (const [toolRequestId, pending] of pendingHostToolRequests) {
    if (sessionId && pending.sessionId === sessionId) {
      pending.reject(new Error("Host tool execution aborted with the Pi session."));
      pendingHostToolRequests.delete(toolRequestId);
    }
  }
  for (const [operationId, pending] of pendingRuntimeOperations) {
    if (sessionId && pending.sessionId === sessionId) {
      pending.reject(new Error("Runtime operation aborted with the Pi session."));
      pendingRuntimeOperations.delete(operationId);
    }
  }
  for (const [promptId, pending] of pendingAuthPrompts) {
    if (targetId && pending.requestId === targetId) {
      pending.reject(new Error("Authentication was cancelled."));
      pendingAuthPrompts.delete(promptId);
    }
  }
  return { aborted: Boolean(aborter || state) };
}

async function handleRequest(request: BridgeRequest): Promise<void> {
  const id = asString(request.id);
  const type = asString(request.type);
  const payload = asObject(request.payload);
  if (!id) throw new Error("Request id is required.");
  switch (type) {
    case "ping":
      writeResponse(id, {
        bridge_version: BRIDGE_VERSION,
        pi_ai_version: PI_AI_VERSION,
        pi_agent_core_version: PI_AGENT_CORE_VERSION,
        pi_coding_agent_version: PI_CODING_AGENT_VERSION,
        node_version: process.version,
      });
      return;
    case "list_providers":
      writeResponse(id, providerCatalogPayload());
      return;
    case "login_provider":
      writeResponse(id, await loginProvider(id, payload));
      return;
    case "clear_provider_credential":
      writeResponse(id, await clearProviderCredential(payload));
      return;
    case "auth_prompt_result":
      writeResponse(id, { accepted: resolveAuthPrompt(payload) });
      return;
    case "set_model_config":
      defaultModelConfig = normalizeModelConfig(payload.model_config);
      writeResponse(id, { configured: true });
      return;
    case "complete_once":
      writeResponse(id, await runSimpleCompletion(id, payload, asBoolean(payload.stream, false)));
      return;
    case "run_turn":
      writeResponse(id, await runNativeAgentTurn(id, payload));
      return;
    case "close_session":
      writeResponse(id, await closeAgentSessionRequest(payload));
      return;
    case "prewarm_session":
      writeResponse(id, await prewarmNativeAgentSession(payload));
      return;
    case "get_session_state":
      writeResponse(id, nativeSessionPayload(nativeSessionFromPayload(payload)));
      return;
    case "compact_session":
      writeResponse(id, await compactNativeAgentSession(id, payload));
      return;
    case "navigate_session":
      writeResponse(id, await navigateNativeAgentSession(id, payload));
      return;
    case "reload_session":
      writeResponse(id, await reloadNativeAgentSession(payload));
      return;
    case "export_session_jsonl":
      writeResponse(id, exportNativeAgentSession(payload));
      return;
    case "import_session_jsonl":
      writeResponse(id, await importNativeAgentSession(payload));
      return;
    case "list_discovered_skills":
      writeResponse(id, await listDiscoveredSkills(payload));
      return;
    case "steer":
      writeResponse(id, await steerNativeAgentSession(payload));
      return;
    case "follow_up":
      writeResponse(id, await followUpNativeAgentSession(id, payload));
      return;
    case "host_tool_result":
      writeResponse(id, { accepted: resolveHostToolResult(payload) });
      return;
    case "host_tool_progress":
      writeResponse(id, { accepted: applyHostToolProgress(payload) });
      return;
    case "runtime_op_chunk":
      writeResponse(id, { accepted: runtimeOperationChunk(payload) });
      return;
    case "runtime_op_result":
      writeResponse(id, { accepted: runtimeOperationResult(payload) });
      return;
    case "runtime_op_cancel": {
      const operationId = asString(payload.operation_id).trim();
      const pending = pendingRuntimeOperations.get(operationId);
      if (pending) {
        pendingRuntimeOperations.delete(operationId);
        pending.reject(new Error(asString(payload.error, "Runtime operation cancelled by host.")));
      }
      writeResponse(id, { accepted: Boolean(pending) });
      return;
    }
    case "list_extension_packages":
      writeResponse(id, await installedExtensionPackagesPayload());
      return;
    case "install_extension_package":
      writeResponse(id, await installExtensionPackageRequest(id, payload));
      return;
    case "remove_extension_package":
      writeResponse(id, await removeExtensionPackageRequest(payload));
      return;
    case "update_extension_package":
      writeResponse(id, await updateExtensionPackageRequest(id, payload));
      return;
    case "reload_all_extensions":
      writeResponse(id, await reloadAllExtensionSessions(payload));
      return;
    case "reload_arix_extensions":
      writeResponse(id, await reloadArixAppExtensionsRequest(id, payload));
      return;
    case "get_arix_extensions":
      writeResponse(id, await getArixAppExtensionsRequest(id, payload));
      return;
    case "invoke_arix_extension_action":
      writeResponse(id, await invokeArixAppExtensionActionRequest(id, payload));
      return;
    case "dispatch_arix_extension_event":
      writeResponse(id, await dispatchArixAppExtensionEventRequest(id, payload));
      return;
    case "subscribe_arix_extensions":
      arixSubscriberRequestIds.add(id);
      writeEvent(id, "arix_invalidated", { subscribed: true });
      return;
    case "unsubscribe_arix_extensions":
      arixSubscriberRequestIds.delete(asString(payload.request_id, id));
      writeResponse(id, { unsubscribed: true });
      return;
    case "arix_host_result":
      writeResponse(id, { accepted: resolveArixHostCall(payload) });
      return;
    case "abort":
      writeResponse(id, await abortBridgeTarget(payload));
      return;
    default:
      throw new Error(`Unsupported request type: ${type}`);
  }
}

// ------------------------------------------------------------------------- //
// v2.9.16 — ACP (Agent Client Protocol) server layer                       //
//                                                                           //
// Newline-delimited JSON-RPC 2.0 over the SAME stdio as the legacy bridge  //
// protocol: every parsed line carrying {"jsonrpc":"2.0"} is routed here,   //
// everything else keeps flowing through handleRequest. The ACP surface     //
// gives the host (the Android app) a standards-shaped channel for the      //
// kernel: session lifecycle (new / load / restore / fork / list / close /  //
// delete), permission-mode switching (default / acceptEdits / plan /       //
// bypassPermissions) with real tool gating + session/request_permission    //
// round-trips, streaming session/update notifications, fs read/write       //
// against the kernel workspace, and embedded terminals (spawn / output /   //
// wait_for_exit / kill / release).                                         //
// ------------------------------------------------------------------------- //

const ACP_PROTOCOL_VERSION = 1;
const ACP_PERMISSION_TIMEOUT_MS = 120_000;
const ACP_FS_MAX_BYTES = 8 * 1024 * 1024;
const ACP_TERMINAL_MAX_BYTES = 4 * 1024 * 1024;

type AcpPermissionMode = "default" | "acceptEdits" | "plan" | "bypassPermissions";

interface AcpSessionRecord {
  acpId: string;
  kernelSessionId: string;
  cwd: string;
  sessionFile?: string;
  mode: AcpPermissionMode;
  approvedTools: Set<string>;
  createdAt: number;
  closed: boolean;
}

interface AcpTerminalProcess {
  id: string;
  child: import("node:child_process").ChildProcess;
  buffer: Buffer[];
  bufferedBytes: number;
  truncated: boolean;
  exitCode: number | null;
  exited: boolean;
  released: boolean;
}

const acpSessions = new Map<string, AcpSessionRecord>();
const acpTerminals = new Map<string, AcpTerminalProcess>();
const acpPendingClientRequests = new Map<
  string,
  { resolve: (value: JsonObject) => void; reject: (error: Error) => void; timeout: NodeJS.Timeout }
>();
let acpRequestCounter = 0;
let acpTerminalCounter = 0;
let acpClientInfo: JsonObject | undefined;

function isAcpFrame(value: unknown): boolean {
  return Boolean(
    value &&
    typeof value === "object" &&
    (value as Record<string, unknown>).jsonrpc === "2.0",
  );
}

function acpWrite(frame: Record<string, unknown>): void {
  writeProtocolFrame(frame);
}

function acpResult(id: unknown, result: Record<string, unknown>): void {
  acpWrite({ jsonrpc: "2.0", id, result });
}

function acpError(id: unknown, code: number, message: string): void {
  acpWrite({ jsonrpc: "2.0", id, error: { code, message } });
}

function acpNotify(method: string, params: Record<string, unknown>): void {
  acpWrite({ jsonrpc: "2.0", method, params });
}

function acpSessionUpdate(acpId: string, update: Record<string, unknown>): void {
  acpNotify("session/update", { sessionId: acpId, update });
}

/** Next ACP request id for agent→client requests (permissions, …). */
function nextAcpRequestId(): string {
  acpRequestCounter += 1;
  return `acp-req-${acpRequestCounter}`;
}

/** Permission gating per mode (the tools that require approval). */
function acpGatedToolsForMode(mode: AcpPermissionMode): string[] {
  switch (mode) {
    case "bypassPermissions":
      return [];
    case "acceptEdits":
      return ["bash"];
    case "plan":
      return ["bash", "edit", "write"];
    case "default":
    default:
      return ["bash", "edit", "write"];
  }
}

/**
 * The ACP permission gate, installed as a per-session extension factory
 * (same mechanism as the failure-policy extension): gated tool calls
 * trigger an agent→client `session/request_permission` request and are
 * blocked when the client denies (or stays silent past the timeout).
 */
function acpPermissionExtensionFactory(record: AcpSessionRecord): ExtensionFactory {
  return (pi) => {
    pi.on("tool_call", async (event) => {
      if (record.closed) return undefined;
      const toolName = (event as { toolName?: string }).toolName ?? "";
      const gated = acpGatedToolsForMode(record.mode);
      if (!gated.includes(toolName)) return undefined;
      if (record.approvedTools.has(toolName)) return undefined;
      const decision = await acpRequestPermission(record, toolName, event);
      if (decision === "approve_always") {
        record.approvedTools.add(toolName);
        return undefined;
      }
      if (decision === "approve_once") return undefined;
      return {
        block: true,
        reason:
          "The host denied this tool call through the ACP permission prompt " +
          "(mode: " + record.mode + "). Ask the host to switch the session mode " +
          "(session/set_mode) or approve the tool (session/set_permission) if it should run.",
        terminate: false,
      } as { block: boolean; reason: string; terminate: boolean };
    });
  };
}

/** Agent→client permission request with a hard timeout (deny by default). */
async function acpRequestPermission(
  record: AcpSessionRecord,
  toolName: string,
  event: unknown,
): Promise<string> {
  const requestId = nextAcpRequestId();
  return new Promise<string>((resolve) => {
    const timeout = setTimeout(() => {
      acpPendingClientRequests.delete(requestId);
      resolve("reject_once");
    }, ACP_PERMISSION_TIMEOUT_MS);
    acpPendingClientRequests.set(requestId, {
      resolve: (value) => {
        clearTimeout(timeout);
        acpPendingClientRequests.delete(requestId);
        resolve(asString(value.outcome ?? value.optionId).trim() || "reject_once");
      },
      reject: () => {
        clearTimeout(timeout);
        acpPendingClientRequests.delete(requestId);
        resolve("reject_once");
      },
      timeout,
    });
    acpNotify("session/request_permission", {
      sessionId: record.acpId,
      toolCall: {
        toolCallId: (event as { toolCallId?: string }).toolCallId ?? "",
        title: toolName,
        kind: "tool",
        rawInput: event ?? {},
      },
      options: [
        { optionId: "approve_once", name: "Allow once", kind: "allow_once" },
        { optionId: "approve_always", name: "Always allow this tool", kind: "allow_always" },
        { optionId: "reject_once", name: "Deny", kind: "reject_once" },
      ],
    });
  });
}

/** Resolve an agent→client request when the client answers. */
function resolveAcpClientRequest(id: unknown, payload: JsonObject): boolean {
  const key = String(id ?? "");
  const pending = acpPendingClientRequests.get(key);
  if (!pending) return false;
  acpPendingClientRequests.delete(key);
  clearTimeout(pending.timeout);
  pending.resolve(payload);
  return true;
}

/** Mirrors kernel agent events onto the ACP session/update channel. */
function emitAcpUpdateForAgentEvent(acpId: string, event: AgentSessionEvent): void {
  try {
    switch (event.type) {
      case "message_update": {
        if (event.message.role !== "assistant") return;
        const assistantEvent = event.assistantMessageEvent;
        // v3.0.24 — fix: the pi-ai stream events carry the delta on
        // `.delta` (the old `.textDelta` read never existed on the event
        // type, so every ACP agent_message_chunk / agent_thought_chunk
        // streamed EMPTY text).
        if (assistantEvent.type === "text_delta") {
          acpSessionUpdate(acpId, {
            sessionUpdate: "agent_message_chunk",
            content: { type: "text", text: assistantEvent.delta ?? "" },
          });
        } else if (assistantEvent.type === "thinking_delta") {
          acpSessionUpdate(acpId, {
            sessionUpdate: "agent_thought_chunk",
            content: { type: "text", text: assistantEvent.delta ?? "" },
          });
        }
        return;
      }
      case "tool_execution_start":
        acpSessionUpdate(acpId, {
          sessionUpdate: "tool_call",
          toolCallId: event.toolCallId,
          title: event.toolName,
          kind: "tool",
          rawInput: event.args ?? {},
        });
        return;
      case "tool_execution_update":
        acpSessionUpdate(acpId, {
          sessionUpdate: "tool_call_update",
          toolCallId: event.toolCallId,
          update: { content: [{ type: "text", text: "…" }] },
        });
        return;
      case "tool_execution_end": {
        // v3.0.24 — fix: tool results carry `content` as an ARRAY of
        // content parts; asString(array) is always "", so ACP clients
        // never saw any tool output. Flatten the text parts instead.
        const resultContent = (event.result as { content?: unknown } | undefined)?.content;
        const text = Array.isArray(resultContent)
          ? resultContent
              .map((part) => asString((part as { text?: unknown })?.text))
              .filter(Boolean)
              .join("\n")
          : asString(resultContent);
        acpSessionUpdate(acpId, {
          sessionUpdate: "tool_call_update",
          toolCallId: event.toolCallId,
          update: {
            content: [
              {
                type: "text",
                text: text.slice(0, 2000),
              },
            ],
          },
        });
        return;
      }
      default:
        return;
    }
  } catch {
    // ACP mirroring must never break the kernel's own event flow.
  }
}

/** Kernel payload for an ACP session prompt (reuses the native machinery). */
function acpPromptPayload(record: AcpSessionRecord, modelConfig?: JsonObject): JsonObject {
  const payload: JsonObject = {
    session_id: record.kernelSessionId,
    workspace_directory: record.cwd,
    termux_workspace_directory: record.cwd,
    workspace_trusted: record.mode === "bypassPermissions" || record.mode === "acceptEdits",
    platform: "android",
    runtime: "termux",
    host_tools: [] as unknown[],
    system_prompt:
      "You are the Arix kernel serving an ACP (Agent Client Protocol) host session. " +
      "Answer directly and completely.",
  };
  if (record.sessionFile) payload.session_file = record.sessionFile;
  if (modelConfig) payload.model_config = modelConfig;
  return payload;
}

async function acpEnsureKernelSession(record: AcpSessionRecord, modelConfig?: JsonObject) {
  const existing = agentSessions.get(record.kernelSessionId);
  const payload = acpPromptPayload(record, modelConfig);
  const rawConfig = (payload.model_config ?? defaultModelConfig) as JsonObject | undefined;
  // v3.0.50 — surface the intended "Unknown Pi session" error (instead
  // of normalizeModelConfig's "provider_type is required") when neither
  // the request nor a prior set_model_config supplied a model config.
  if (!rawConfig || Object.keys(rawConfig).length === 0) {
    throw new Error(`Unknown Pi session: ${record.kernelSessionId} (no model_config).`);
  }
  const config = normalizeModelConfig(rawConfig);
  if (existing) {
    // v3.0.30 — honor `model_config` changes on subsequent session/prompt
    // requests. The old code created the kernel session once and silently
    // reused the FIRST prompt's model config forever, so switching models
    // mid-session did nothing. When the config signature changed, recreate
    // the kernel session and carry the live transcript over as history so
    // the conversation continues under the new model (mirrors the legacy
    // run_turn path's signature check in prepareNativeAgentSession).
    if (existing.configSignature === modelConfigSignature(config)) {
      existing.acpSessionId = record.acpId;
      return existing;
    }
    const carriedHistory: AgentMessage[] = existing.session.messages ?? [];
    await closeNativeAgentSession(record.kernelSessionId).catch(() => undefined);
    const recreated = await createNativeAgentSession(
      record.kernelSessionId,
      payload,
      config,
      carriedHistory,
      record,
    );
    recreated.acpSessionId = record.acpId;
    return recreated;
  }
  // The ACP permission gate rides in through the session's extension
  // factories (same mechanism as the failure-policy extension).
  const created = await createNativeAgentSession(record.kernelSessionId, payload, config, [], record);
  created.acpSessionId = record.acpId;
  return created;
}

/** host→kernel ACP request dispatch. */
async function handleAcpRequest(id: unknown, method: string, params: JsonObject): Promise<void> {
  try {
    const result = await acpDispatch(method, params);
    acpResult(id, result);
  } catch (error) {
    acpError(id, -32000, errorMessageWithCause(error));
  }
}

async function acpDispatch(method: string, params: JsonObject): Promise<Record<string, unknown>> {
  switch (method) {
    case "initialize": {
      acpClientInfo = asObject(params.clientInfo);
      return {
        protocolVersion: ACP_PROTOCOL_VERSION,
        agentInfo: {
          name: "Arix Kernel",
          version: BRIDGE_VERSION,
        },
        authMethods: [],
      };
    }

    case "session/new": {
      const cwd = asString(params.cwd, process.cwd()) || process.cwd();
      const acpId = `acp-session-${Date.now()}-${++acpRequestCounter}`;
      const record: AcpSessionRecord = {
        acpId,
        kernelSessionId: acpId,
        cwd,
        mode: "default",
        approvedTools: new Set<string>(),
        createdAt: Date.now(),
        closed: false,
      };
      acpSessions.set(acpId, record);
      acpSessionUpdate(acpId, {
        sessionUpdate: "session_info_update",
        title: "ACP session",
        cwd,
      });
      return { sessionId: acpId };
    }

    case "session/load":
    case "session/restore": {
      const requested = asString(params.sessionId).trim();
      let sessionFile = asString(params.sessionPath).trim();
      if (!sessionFile && requested) {
        const directory = path.join(os.homedir(), ".arix", "agent-sessions");
        const matches = (await fs.readdir(directory).catch(() => [] as string[]))
          .filter((entry) => entry.endsWith(`_${requested}.jsonl`))
          .sort();
        const last = matches.length > 0 ? matches[matches.length - 1] : "";
        sessionFile = last ? path.join(directory, last) : "";
      }
      if (!sessionFile) throw new Error("session/load requires a sessionId or sessionPath.");
      const stat = await fs.stat(sessionFile).catch(() => undefined);
      if (!stat?.isFile()) throw new Error(`Session file not found: ${sessionFile}`);
      const acpId = requested || `acp-session-${Date.now()}-${++acpRequestCounter}`;
      const record: AcpSessionRecord = {
        acpId,
        kernelSessionId: acpId,
        cwd: asString(params.cwd, path.dirname(sessionFile)),
        sessionFile,
        mode: "default",
        approvedTools: new Set<string>(),
        createdAt: Date.now(),
        closed: false,
      };
      acpSessions.set(acpId, record);
      // Replay the stored entries as session/update chunks (ACP load).
      await replayAcpSessionFile(record);
      return { sessionId: acpId, restored: true };
    }

    case "session/fork": {
      const source = acpRequireRecord(params);
      if (!source.sessionFile) {
        throw new Error("session/fork requires a session created via session/load.");
      }
      const acpId = `acp-session-${Date.now()}-${++acpRequestCounter}`;
      const forkPath = source.sessionFile.replace(/\.jsonl$/, "") + `-fork-${Date.now()}.jsonl`;
      await fs.copyFile(source.sessionFile, forkPath);
      const record: AcpSessionRecord = {
        acpId,
        kernelSessionId: acpId,
        cwd: source.cwd,
        sessionFile: forkPath,
        mode: source.mode,
        approvedTools: new Set(source.approvedTools),
        createdAt: Date.now(),
        closed: false,
      };
      acpSessions.set(acpId, record);
      return { sessionId: acpId };
    }

    case "session/list": {
      const directory = path.join(os.homedir(), ".arix", "agent-sessions");
      const entries = await fs.readdir(directory).catch(() => [] as string[]);
      const sessions = await Promise.all(
        entries
          .filter((entry) => entry.endsWith(".jsonl"))
          .map(async (entry) => {
            const filePath = path.join(directory, entry);
            const stat = await fs.stat(filePath).catch(() => undefined);
            return {
              id: entry.replace(/\.jsonl$/, ""),
              path: filePath,
              modifiedAt: stat?.mtimeMs ?? 0,
              sizeBytes: stat?.size ?? 0,
            };
          }),
      );
      sessions.sort((a, b) => b.modifiedAt - a.modifiedAt);
      return { sessions: sessions.slice(0, 50) };
    }

    case "session/prompt": {
      const record = acpRequireRecord(params);
      if (record.closed) throw new Error("The ACP session is closed.");
      const promptBlocks = Array.isArray(params.prompt) ? params.prompt : [];
      const text = promptBlocks
        .map((block) => asString((block as Record<string, unknown>).text))
        .filter(Boolean)
        .join("\n");
      if (!text.trim()) throw new Error("session/prompt requires prompt content.");
      // v3.0.50 — pass the RAW model_config value through. asObject()
      // coerces a missing model_config to a truthy {} which then reached
      // normalizeModelConfig as {} (the `?? defaultModelConfig` fallback
      // in acpEnsureKernelSession was unreachable), so every ACP prompt
      // without an explicit model_config failed with
      // "model_config.provider_type is required.".
      const rawModelConfig = params.model_config;
      const modelConfig = rawModelConfig && typeof rawModelConfig === "object" && !Array.isArray(rawModelConfig)
        ? (rawModelConfig as JsonObject)
        : undefined;
      const state = await acpEnsureKernelSession(record, modelConfig);
      record.kernelSessionId = state.sessionId;
      const promptId = `acp-turn-${Date.now()}-${++acpRequestCounter}`;
      acpSessionUpdate(record.acpId, {
        sessionUpdate: "user_message_chunk",
        content: { type: "text", text },
      });
      const message = await runNativeAgentPrompt(promptId, state, text, []);
      return {
        stopReason: "end_turn",
        sessionId: record.acpId,
        message: {
          role: "assistant",
          content: message?.content ?? [],
        },
      };
    }

    case "session/cancel": {
      const record = acpRequireRecord(params);
      const state = agentSessions.get(record.kernelSessionId);
      if (state?.session.isStreaming) {
        await state.session.abort().catch(() => undefined);
      }
      return { cancelled: true };
    }

    case "session/set_mode": {
      const record = acpRequireRecord(params);
      const requested = asString(params.mode).trim() as AcpPermissionMode;
      const modes: AcpPermissionMode[] = ["default", "acceptEdits", "plan", "bypassPermissions"];
      if (!modes.includes(requested)) {
        throw new Error(`mode must be one of: ${modes.join(", ")}`);
      }
      record.mode = requested;
      acpSessionUpdate(record.acpId, {
        sessionUpdate: "current_mode_update",
        currentMode: requested,
      });
      return { mode: record.mode };
    }

    case "session/set_permission": {
      const record = acpRequireRecord(params);
      const tool = asString(params.tool).trim();
      if (!tool) throw new Error("session/set_permission requires a tool name.");
      if (asBoolean(params.allowed, true)) {
        record.approvedTools.add(tool);
      } else {
        record.approvedTools.delete(tool);
      }
      return { tool, allowed: record.approvedTools.has(tool) };
    }

    case "session/close": {
      const record = acpRequireRecord(params);
      await closeAcpSession(record, false);
      return { closed: true };
    }

    case "session/delete": {
      const record = acpRequireRecord(params);
      await closeAcpSession(record, true);
      return { deleted: true };
    }

    case "fs/read_text_file": {
      const filePath = acpResolveWorkspacePath(params);
      const content = await fs.readFile(filePath, "utf8");
      const bounded = content.length > ACP_FS_MAX_BYTES
        ? content.slice(0, ACP_FS_MAX_BYTES)
        : content;
      const lines = bounded.split("\n");
      const fromLine = Math.max(1, Number(params.line ?? 1) || 1);
      const limit = params.limit === undefined
        ? lines.length
        : Math.max(1, Number(params.limit) || 1);
      const slice = lines.slice(fromLine - 1, fromLine - 1 + limit).join("\n");
      return {
        content: slice,
        totalLines: lines.length,
        truncated: content.length > ACP_FS_MAX_BYTES,
      };
    }

    case "fs/write_text_file": {
      const filePath = acpResolveWorkspacePath(params);
      const content = asString(params.content);
      const tempPath = `${filePath}.acp-tmp-${Date.now()}`;
      await fs.writeFile(tempPath, content, "utf8");
      await fs.rename(tempPath, filePath);
      return { written: true, bytes: content.length };
    }

    case "terminal/create": {
      const command = asString(params.command).trim();
      if (!command) throw new Error("terminal/create requires a command.");
      const args = stringArray(params.args);
      const cwd = acpResolveDirectory(asString(params.cwd, process.cwd()));
      const terminalId = `acp-term-${++acpTerminalCounter}`;
      const child = spawn(command, args, {
        cwd,
        env: { ...process.env, TERM: "xterm-256color" },
        stdio: ["ignore", "pipe", "pipe"],
      });
      const terminal: AcpTerminalProcess = {
        id: terminalId,
        child,
        buffer: [],
        bufferedBytes: 0,
        truncated: false,
        exitCode: null,
        exited: false,
        released: false,
      };
      acpTerminals.set(terminalId, terminal);
      const collect = (chunk: Buffer) => {
        if (terminal.released) return;
        terminal.buffer.push(chunk);
        terminal.bufferedBytes += chunk.length;
        // v3.0.24 — fix the trimming accounting: the old code subtracted
        // the NEWEST chunk's length after shifting the OLDEST buffer,
        // so bufferedBytes drifted upward and every post-limit chunk
        // evicted one entry even when the buffer was far under the cap
        // (terminal/output lost most of its history). Shift until the
        // cap is actually honored.
        while (terminal.bufferedBytes > ACP_TERMINAL_MAX_BYTES && terminal.buffer.length > 1) {
          terminal.bufferedBytes -= terminal.buffer[0].length;
          terminal.buffer.shift();
          terminal.truncated = true;
        }
      };
      child.stdout?.on("data", collect);
      child.stderr?.on("data", collect);
      child.on("exit", (code) => {
        terminal.exited = true;
        terminal.exitCode = code ?? 0;
        // v3.0.30 — reap exited terminals: entries used to stay in the map
        // until an explicit terminal/release (which a crashed/disconnected
        // host never sends), leaking the buffer and record forever. Keep a
        // 60s grace window so the host can still read the final output and
        // exit status, then delete the entry.
        setTimeout(() => {
          acpTerminals.delete(terminalId);
        }, 60_000).unref?.();
      });
      return { terminalId, pid: child.pid ?? -1 };
    }

    case "terminal/output": {
      const terminal = acpRequireTerminal(params);
      const output = Buffer.concat(terminal.buffer).toString("utf8");
      return {
        output,
        truncated: terminal.truncated,
        exitStatus: terminal.exited ? (terminal.exitCode ?? 0) : undefined,
      };
    }

    case "terminal/wait_for_exit": {
      const terminal = acpRequireTerminal(params);
      if (!terminal.exited) {
        await new Promise<void>((resolve) => {
          const timer = setTimeout(resolve, asLong(params.timeout_ms, 30_000));
          terminal.child.once("exit", () => {
            clearTimeout(timer);
            resolve();
          });
        });
      }
      return { exitCode: terminal.exitCode ?? 0 };
    }

    case "terminal/kill": {
      const terminal = acpRequireTerminal(params);
      // v3.0.24 — Node's ChildProcess.kill() takes a `Signals` union,
      // not an arbitrary string; validate against the well-known signal
      // names and fall back to SIGTERM (previously a raw string was
      // passed straight through, which type-checked nowhere and could
      // throw for garbage input).
      const requested = asString(params.signal, "SIGTERM");
      const signal = isKnownSignal(requested) ? requested : "SIGTERM";
      // v3.0.30 — report the actual kill outcome: ChildProcess.kill()
      // returns false when the process already exited; the old code always
      // claimed { killed: true }.
      const killed = terminal.child.kill(signal);
      return { killed };
    }

    case "terminal/release": {
      const terminal = acpRequireTerminal(params);
      terminal.released = true;
      // v3.0.30 — a released terminal whose child is still running used to
      // keep the process alive forever (buffering stops, but the process
      // leaks). Kill it on release.
      if (!terminal.exited) {
        try {
          terminal.child.kill("SIGTERM");
        } catch {
          // already dead — nothing to do
        }
      }
      acpTerminals.delete(terminal.id);
      return { released: true };
    }

    default:
      throw new Error(`ACP method not found: ${method}`);
  }
}

function asLong(value: unknown, fallback: number): number {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

async function closeAcpSession(record: AcpSessionRecord, deleteFiles: boolean): Promise<void> {
  record.closed = true;
  await closeNativeAgentSession(record.kernelSessionId).catch(() => undefined);
  acpSessions.delete(record.acpId);
  if (deleteFiles && record.sessionFile) {
    await fs.rm(record.sessionFile, { force: true }).catch(() => undefined);
  }
}

function acpRequireRecord(params: JsonObject): AcpSessionRecord {
  const acpId = asString(params.sessionId).trim();
  const record = acpId ? acpSessions.get(acpId) : undefined;
  if (!record) throw new Error(`Unknown ACP session: ${acpId || "(none)"}`);
  return record;
}

function acpRequireTerminal(params: JsonObject): AcpTerminalProcess {
  const terminalId = asString(params.terminalId).trim();
  const terminal = acpTerminals.get(terminalId);
  if (!terminal) throw new Error(`Unknown ACP terminal: ${terminalId || "(none)"}`);
  return terminal;
}

function acpResolveDirectory(requested: string): string {
  const resolved = path.resolve(requested || process.cwd());
  return resolved;
}

/**
 * v3.0.24 — well-known POSIX signals accepted by ChildProcess.kill()
 * (Node types them as the `Signals` union). Anything else falls back to
 * SIGTERM at the terminal/kill call site.
 */
function isKnownSignal(value: string): value is NodeJS.Signals {
  return [
    "SIGABRT",
    "SIGALRM",
    "SIGBUS",
    "SIGCHLD",
    "SIGCONT",
    "SIGFPE",
    "SIGHUP",
    "SIGILL",
    "SIGINT",
    "SIGIO",
    "SIGIOT",
    "SIGKILL",
    "SIGPIPE",
    "SIGPOLL",
    "SIGPROF",
    "SIGPWR",
    "SIGQUIT",
    "SIGSEGV",
    "SIGSTKFLT",
    "SIGSTOP",
    "SIGSYS",
    "SIGTERM",
    "SIGTRAP",
    "SIGTSTP",
    "SIGTTIN",
    "SIGTTOU",
    "SIGUNUSED",
    "SIGURG",
    "SIGUSR1",
    "SIGUSR2",
    "SIGVTALRM",
    "SIGWINCH",
    "SIGXCPU",
    "SIGXFSZ",
    "SIGBREAK",
    "SIGLOST",
    "SIGINFO",
  ].includes(value.toUpperCase() as NodeJS.Signals);
}

function acpResolveWorkspacePath(params: JsonObject): string {
  const requested = asString(params.path).trim();
  if (!requested) throw new Error("path is required.");
  const resolved = path.resolve(process.cwd(), requested);
  // v3.0.30 — segment-safe confinement. The old string `startsWith` check
  // accepted any path whose text begins with the workspace path, so
  // `<workspace>-evil/secrets` (a sibling directory sharing the prefix)
  // passed the guard. Compare `path.relative` like `runtimePath` does:
  // the result must not escape upwards (`..`) and must not be absolute
  // (different drive/root).
  const workspaceRoot = path.resolve(process.cwd());
  const relative = path.relative(workspaceRoot, resolved);
  if (relative.startsWith("..") || path.isAbsolute(relative)) {
    throw new Error("ACP fs access is confined to the kernel workspace.");
  }
  return resolved;
}

async function replayAcpSessionFile(record: AcpSessionRecord): Promise<void> {
  try {
    const raw = await fs.readFile(record.sessionFile!, "utf8");
    for (const line of raw.split("\n")) {
      if (!line.trim()) continue;
      const entry = runCatchingJson(line);
      if (!entry) continue;
      const type = asString(entry.type);
      if (type === "message") {
        // v3.0.24 — typed view of the replayed JSONL entry (the raw
        // `Record<string, unknown>` had no `message` field, which
        // type-checked as `{}` and failed strict mode).
        const message = entry.message as { role?: unknown; content?: unknown } | undefined;
        const role = asString(message?.role);
        const text = Array.isArray(message?.content)
          ? (message.content as unknown[])
              .map((part) => asString((part as { text?: unknown })?.text))
              .filter(Boolean)
              .join("")
          : asString(message?.content);
        if (!text) continue;
        acpSessionUpdate(record.acpId, {
          sessionUpdate: role === "assistant" ? "agent_message_chunk" : "user_message_chunk",
          content: { type: "text", text: text.slice(0, 4000) },
        });
      }
    }
  } catch {
    // replay is best-effort
  }
}

function runCatchingJson(line: string): Record<string, unknown> | undefined {
  try {
    const parsed = JSON.parse(line) as unknown;
    return parsed && typeof parsed === "object" ? (parsed as Record<string, unknown>) : undefined;
  } catch {
    return undefined;
  }
}

/** Entry point for JSON-RPC frames arriving on stdin. */
function handleAcpFrame(frame: Record<string, unknown>): void {
  const id = frame.id;
  const method = typeof frame.method === "string" ? frame.method : "";
  if (method) {
    if (id === undefined) {
      // Notification from the client (e.g. session/cancel).
      handleAcpRequest(id, method, asObject(frame.params)).catch(() => undefined);
    } else {
      // v3.0.24 — id-carrying requests are answered through acpError()
      // inside handleAcpRequest, but the promise itself was left
      // unhandled; ANY synchronous throw inside the handler escaped as an
      // unhandled rejection (Node 22 kills the process by default).
      handleAcpRequest(id, method, asObject(frame.params)).catch((error) => {
        acpError(
          id,
          -32000,
          error instanceof Error ? error.message : String(error),
        );
      });
    }
    return;
  }
  // Response to an agent→client request (permission answers).
  if (id !== undefined) {
    const payload = (frame.result ?? {}) as Record<string, unknown>;
    resolveAcpClientRequest(id, asObject(payload));
  }
}

async function main(): Promise<void> {
  // v3.0.24 — last-resort unhandled-rejection safety net: a single stray
  // promise from a dependency used to kill the whole bridge (Node 22's
  // default is `--unhandled-rejections=throw`), taking every active
  // session and the agent runtime with it. Log to stderr and keep the
  // process alive; per-request errors are still reported through their
  // normal error frames.
  process.on("unhandledRejection", (reason) => {
    stderr.write(
      `pi-bridge unhandled rejection: ${
        reason instanceof Error ? reason.stack ?? reason.message : String(reason)
      }\n`,
    );
  });

  // v3.0.30 — periodic idle-session sweep (see sweepIdleAgentSessions).
  const sweepTimer = setInterval(sweepIdleAgentSessions, 5 * 60 * 1000);
  sweepTimer.unref?.();

  if (process.argv.includes("--ping")) {
    writeFrame({
      type: "response",
      id: "ping",
      ok: true,
      payload: {
        bridge_version: BRIDGE_VERSION,
        pi_ai_version: PI_AI_VERSION,
        pi_agent_core_version: PI_AGENT_CORE_VERSION,
        pi_coding_agent_version: PI_CODING_AGENT_VERSION,
        node_version: process.version,
      },
    });
    return;
  }

  const reader = createInterface({ input, crlfDelay: Infinity });
  for await (const line of reader) {
    if (!line.trim()) continue;
    let request: BridgeRequest;
    try {
      request = JSON.parse(line) as BridgeRequest;
    } catch (error) {
      writeError(undefined, error, "invalid_json");
      continue;
    }
    // v2.9.16 (ACP): JSON-RPC 2.0 frames share this stdio with the legacy
    // bridge protocol — route them to the ACP server layer.
    if (isAcpFrame(request)) {
      handleAcpFrame(request as unknown as Record<string, unknown>);
      continue;
    }
    handleRequest(request).then(
      flushStartupCompileCache,
      (error) => {
        flushStartupCompileCache();
        writeError(request.id, error);
      },
    );
  }
}

main().catch((error) => {
  stderr.write(`pi-bridge fatal: ${error instanceof Error ? error.stack ?? error.message : String(error)}\n`);
  process.exitCode = 1;
});
