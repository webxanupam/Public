# Arix Security Model (v3.0.30)

This document describes the security posture of the current v3.x
architecture. It replaces the v2.7.12-era review, which described
subsystems that no longer exist (the `arix_system` host tool, the
`arixctl` abstract-socket CLI, and the Chromium/proot browser stack with
CDP/VNC/noVNC — all removed in later releases). Every claim below was
re-verified against the v3.0.7 source tree.

## Device-control architecture (no ADB / no root / no Accessibility)

Arix never uses ADB, Shizuku, root, USB debugging or wireless debugging,
and **none of them are required to use the app**. Chat, tools, the
embedded runtime, browser research and the mission engine all work
without any privileged access.

The GUI agent (`gui_agent` tool + `ArixGuiAgentService`) — the only
feature that ever used the platform `AccessibilityService` — was
removed entirely in v3.0.77 at the user's request: no accessibility
service is declared in the manifest anymore and no code path requests
it. Every device-facing feature (notifications, clipboard via focus,
file management) uses standard unprivileged Android APIs.

## Runtime architecture (embedded Termux / proot)

The local tool runtime is a full Termux-compatible rootfs shipped inside
the APK (`assets/runtimes/termux/arm64-v8a/bootstrap.tar.xz`) and
extracted into the app's private data directory. Guest commands run
through `proot` — no root, no namespaces, no extra SELinux context:

* `targetSdk` is pinned to **28** (while `compileSdk` is 36): apps that
  target API 29+ fall under an SELinux neverallow that blocks `execve()`
  of binaries in the app's writable data directory, which would kill
  every guest command (`proot error: execve(...): Permission denied`).
  Upstream Termux ships target 28 for the same reason. Arix is
  side-loaded, so Play target-SDK policy does not apply; every API-level
  behavior (scoped storage, FGS start guards, exact-alarm gating) is
  level-checked at runtime instead of assumed from the target.
* Only `arm64-v8a` is packaged.
* The Node.js agent kernel (pi-bridge) runs as a child process of the
  app, driven over **piped stdio** — not over any network socket.
* Bootstrap can additionally be fetched from the network on first setup;
  failures self-heal on later starts (bounded by the bootstrap attempt
  gate).
* No root filesystem path outside the app's own data/shared-storage
  grants is writable by the guest.

## Embedded Browser (hardened in-app WebView)

v3.x replaced the old Chromium-in-proot/CDP/VNC stack with a single
shared **`android.webkit` WebView** (`ArixBrowserSession`) plus a pool of
offscreen research tabs (`ArixBrowserResearch`, `ArixBrowserTabs`).
There are **no local browser-control network endpoints at all** — no
CDP, no DevTools websocket, no VNC, no HTTP server; the codebase contains
no `ServerSocket`/`HttpServer` of any kind. The WebView is driven through
the platform API from the app process only, which removes the entire
loopback-listener attack surface of the old architecture. Hardening:

* `allowFileAccess = false`, `allowContentAccess = false` — a web page
  can never read the app's private storage (memory, DataStore, provider
  keys).
* `mixedContentMode = MIXED_CONTENT_NEVER_ALLOW` — an HTTPS page cannot
  load active content over HTTP (blocks MITM prompt-injection into the
  agent context).
* Safe Browsing enabled; third-party cookies disabled in both the shared
  session and the research tabs.
* Navigation scheme allowlist: the browser tool only accepts `http(s)`
  URLs — `file:`, `content:`, `data:` and `javascript:` targets are
  rejected before loading.
* Payment / captcha / OTP / credential pages are never automated: the
  browser tool returns `input_required` + `user_takeover` so the user
  finishes the flow themselves.
* Extracted page text is wrapped in an `<untrusted-web-content
  origin="…">` envelope before it reaches the model, so the agent can
  attribute injected instructions to their origin.

## Cleartext traffic

`network_security_config.xml` permits cleartext app-wide (v3.0.55,
re-affirmed v3.0.57): the media pipeline resolves streams from arbitrary
user-named sites, free-movie / archive mirrors and user-supplied direct
URLs whose hosts can be plain-HTTP CDNs and direct IP:port endpoints, so
a domain allow-list cannot work — matching every mainstream media
player. All OTHER traffic (model providers, bridges, research) is HTTPS
by convention of its endpoints. (v3.0.57 note: the MovieBox tool and
its Live TV player were removed entirely; the rationale above was
re-checked and cleartext is still required by the surviving chat media
pipeline.)

## Backup / credentials

`allowBackup` is **false** and `dataExtractionRules` disable cloud backup
and device-to-device transfer. The app's DataStore holds provider API
keys and OAuth credentials in plaintext (DataStore is not
Keystore-encrypted); disabling backup wholesale is the only option that
cannot silently regress when new credential stores are added.

## API-key handling

* **Provider keys / OAuth** — stored only in the app-private DataStore,
  redacted by `ArixExtensionHostSecurity` wherever settings cross the
  extension bridge, and redacted by `DiagnosticRedactor` (key-fragment
  matching on `apikey`, `api_key`, `token`, `secret`, `password`, …)
  before anything is written to diagnostics or logs.
* **Weather API key (v3.0.7)** — the app ships with a BUILT-IN
  Weather.com key again so the weather tool works out of the box
  (maintainer decision). Anything shipped inside an APK is extractable,
  so the built-in key is **non-secret by design** and is expected to
  carry provider-side restrictions (weather APIs only, rate caps). A
  user-supplied key (Settings → Web tools) takes precedence over the
  built-in key. If no key resolves at all, the weather tool returns a
  clear "not configured" failure instead of failing silently. Keys
  never appear in logs, diagnostics, or model-visible settings dumps.
* **A backend/proxy would be the stronger design** for any future
  secret-bearing client-side API, but Arix is a client-only app with no
  server component; the non-secret runtime-configuration model above is
  the honest equivalent.

## Signing

**v3.1.4 — current posture, stated honestly:** the source distribution
SHIPS the maintainer's active release signing material —
`keystore/arix-release-v3.keystore` (alias `arix`, RSA 2048, valid until
2056, cert SHA-256 `97cdc46e...ce36`) with its password wired as the
inbuilt default in `app/build.gradle.kts`. This is a deliberate
maintainer decision (personal, private, non-public app) so that a plain
`assembleRelease` from a fresh clone produces a same-key update APK that
installs in place over every previous Arix install. Understand the
consequence: **anyone with this archive can sign APKs that install
silently over every Arix install** (same signature = in-place update, no
uninstall prompt). Keep the archive private. The build still prefers
`ARIX_KEYSTORE_*` environment variables or untracked `local.properties`
entries when present. History note: the v2.9.10 "update key" shipped
inside the repository from v2.9.10 until v3.0.5 and must be treated as
**compromised**; it was removed in v3.0.6 and must never sign a release
again. A short-lived v3.1.4 build was mistakenly signed with a
newly-generated throwaway key and was superseded the same day by the
arix-release-v3 re-sign; only the re-signed build is canonical. Builds
signed with a different key require an uninstall first (Android refuses
in-place updates across signatures).

## Permissions (v3.0.30, verified against AndroidManifest + runtime code)

| Permission | Used by |
|---|---|
| INTERNET | LLM providers, weather, web research, runtime bootstrap download |
| POST_NOTIFICATIONS | Chat/mission/scheduled-task completion notifications |
| FOREGROUND_SERVICE (+ DATA_SYNC) | `ArixForegroundService`, assistant overlay emergency promotion |
| FOREGROUND_SERVICE_MEDIA_PLAYBACK | `ArixMediaPlaybackService` (chat media queue: music / video results played through the shared player) |
| RECEIVE_BOOT_COMPLETED | `ScheduledTaskRescheduleReceiver` (re-arm alarms after reboot) |
| SCHEDULE_EXACT_ALARM | `ScheduledTaskScheduler` (exact scheduled-task delivery) |
| RECORD_AUDIO | In-app speech recognition (`ArixSpeechRecognitionController`) |
| WAKE_LOCK | ExoPlayer network wake mode during background media playback + video keep-screen-on |
| READ_EXTERNAL_STORAGE (maxSdk 32) / WRITE_EXTERNAL_STORAGE (maxSdk 28) | File manager legacy storage grants |
| MANAGE_EXTERNAL_STORAGE | File manager "/device" root (All-files access, user-granted via Settings) |

No ADB-related permission or configuration exists (guard-tested), and no
permission is declared that the runtime code does not use. The CAMERA
permission is NOT declared (torch/system-control layer removed in
v2.9.2; QR support is encode-only).

## Plugin security

Plugins bundle skills, commands, agents and MCP servers. Importing a plugin means trusting its
instructions and any MCP server it configures; there is no sandbox. Plugin archives are unpacked
with path-escape, size and entry-count limits, only https downloads are used, and plugins can be
removed from Settings > Plugins, which also removes their skills and MCP servers.

## Known limitations (v3.0.30)

* Plugins and MCP servers run trusted instructions and code — the security boundary is
  the install decision, not a sandbox.
* Provider credentials are stored plaintext in app-private storage
  (backup-disabled); no Keystore encryption.
* The built-in and user-supplied weather keys are non-secret by nature
  and are only as safe as the provider-side restrictions configured for
  them (the built-in key is shared by every install and can be rotated
  only by shipping a new release).
* `targetSdk 28` is required by the embedded runtime's exec policy; the
  app compensates with runtime API-level checks (documented above).
* Cleartext is permitted app-wide in `network_security_config.xml` for
  the media pipeline's plain-HTTP streams (see the section above).
