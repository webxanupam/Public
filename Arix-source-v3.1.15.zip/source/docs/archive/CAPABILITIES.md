# Arix — Capability Map (v3.0.24)

Last verified against the v3.0.24 source tree. The authoritative answer to
"what can Arix actually do right now". Every capability below is implemented
in the current source; the agent's per-turn tool list is computed from live
state (the model is only ever offered capabilities that exist). Anything
NOT in this map is not implemented — and Arix never claims otherwise.

## The decision loop

```
UNDERSTAND → REASON → PLAN → CAPABILITY DISCOVERY → TOOL SELECTION
   → EXECUTION → OBSERVATION → VERIFICATION → ADAPT/REPLAN
   → ... → FINAL VERIFICATION → RESULT
```

Implemented by the Pi agent loop (pi-bridge `run_turn` + `PiAgentRunner`)
with the v2.7.9 bounded-autonomy failure policy and the v2.8.0 brain
policy (intent classes, confirmation by risk class, injection defense).

## Capability graph

| Capability | Provider | Gating (when the model is offered it) |
| --- | --- | --- |
| Reasoning / conversation | Pi framework model providers (builtin catalog, custom OpenAI-compatible) | provider configured |
| Tool intelligence (schemas, validation, loop guard, structured errors) | `ArixToolExecutor` | always |
| Long-term memory (7 tiers) | `ArixMemoryManager` + `arix_memory` | always |
| Session context / reference resolution | `ArixSessionContextTracker` (prompt block) | always (implicit) |
| Self-diagnostics | `ArixDiagnosticsService` + `arix_diagnostics` | always |
| Shell / Python / Node / Git runtime | embedded Termux (proot) + `RuntimeShellTool` | Termux installed |
| Termux self-repair (dpkg/apt recovery) | `TermuxRuntime` recovery layer | automatic, pre-install |
| Runtime/package management | `arix_runtime_manage`, `arix_ensure_package` | always |
| In-app browser (agent-driven WebView) | `browser` tool (`ArixBrowserSession`) + Browser tab | always |
| Web search (browser-driven, no third-party API) | `web_search` / `fetch_url` (`ArixWebAccessTool`), engines: DuckDuckGo (default) / Google / Bing | always (network) |
| Deep research (SERP harvest + parallel source reading, `[pN]` citations) | `ArixBrowserResearch` research-tab pool | `web_search` available |
| Agent Swarm (parallel sub-agents, steerable) | `arix_swarm` (`ArixSwarmManager`) | always |
| Missions (multi-step plan→execute→verify→recover) | `arix_mission` (`mission/` engine) | always |
| Automation 2.0 (scheduled trigger→condition→execute) | `ArixAutomationManager` + `ScheduledTaskManager` + `arix_scheduled_task_manage` | exact-alarm permission |
| MCP servers (Streamable HTTP) | `arix_mcp_manage` + the `mcp_data` chat widget (legacy `arix_mcp_list` / `arix_mcp_call` renderers kept for old persisted messages) | server connected |
| App extensions (Script API v2 surfaces/components) | `packages/extension-api` + `ArixAppExtensions` + pi-bridge runtime | extension installed |
| Native media (search, resolve, play; YouTube via InnerTube) | `media_search` (`media/` stack) + shared Media3 player + `ArixMediaPlaybackService` | always (network) |
| Image search | `image_search` (`ArixImageClient`) | always (network) |
| Robot companion (home-screen animated robot, music-synced dance) | `ArixRobotCompanion` + `ArixMusicPulse` | always |
| Post editor (WordPress/Blogger WYSIWYG) | Post Editor tool (`ArixPostEditorTool`) | tool opened |
| Virtual Screen (live in-chat browser view) | `ArixVirtualScreen` | browser active |
| Projects / personas | `arix_projects`, persona repository | always |
| QR generation | native `qr_code` agent tool (`ArixQrEncoder`) | always |
| App notifications (own progress/results) | `ArixNotificationController` | POST_NOTIFICATIONS |
| Weather | native `weather` tool | always (network) |
| UPI payments (user-confirmed) | native `upi_pay` deep link | always (UPI app present) |
| Skills (Create Extension, installed skills) | `AgentSkillManager` | skill enabled |
| Extensions management (MCP, mods, script extensions) | `PiExtensionManager` + `arix_extension_manage` | per-extension state |
| Self-management (config/skills/runtime/extensions/developer) | `arix_config_*`, `arix_skill_manage`, `arix_developer_manage`, … | always |
| Chat history / branching / compaction | `ChatRepository` (Room) + bridge compaction | always |
| ACP client (Agent Client Protocol host) | `ArixAcpClient` | always |

## The Android control layers (never mixed)

1. **Termux (proot)** — Linux runtime: shell, Python, Node, Git, local
   servers, data processing. The `arix_system` / `arixctl` system-control
   layer, ADB, root and Shizuku remain **absent by design**
   (guard-tested).
2. **In-app WebView browser** (`ArixBrowserSession`, shared by the agent
   tool, the Browser tab and the Virtual Screen) — web navigation,
   reading and interaction. No CDP, no VNC, no external Chromium
   (the old Chromium-in-proot stack was removed in v3.x). The
   accessibility GUI-agent layer (v2.9.8–v3.0.76) was removed in
   v3.0.77 at the user's request; the app declares no
   `AccessibilityService` anymore.

## Tool economy (smallest reliable path)

- Simple question / math → direct reasoning, no tools.
- Current information → `web_search` / `fetch_url` (browser-driven).
- A file's contents → workspace read / Termux.
- Python/shell work → Termux.
- Payments → `upi_pay` deep link only (never screen automation).
- Complex multi-step work → agent loop; fan-out via `arix_swarm` /
  `arix_mission` when parallelism or planning helps.
- Something failed → structured error → self-diagnose (`arix_diagnostics`
  when the cause is unclear) → corrected retry or alternative → escalate
  to the user after two failures on the same objective.

## Memory model

- **Ephemeral / conversation / tool tiers** — short-lived, relevance-gated.
- **Personal / preference / project / research tiers** — durable,
  user-controlled; browser research can save topic memos when
  "Save research to memory" is enabled.
- Injection: relevance-ranked top entries (token-overlap gate) into the
  system prompt, ≤1200 chars. Never a dump.
- Secrets are refused (heuristic + policy). Bulk delete needs
  `confirm=true`.

## Explicit non-capabilities (honesty section)

- No root / ADB / Shizuku-based control (by design, guard-tested).
- No third-party search API anywhere — web search runs through the real
  browser (SERP harvest), so no search-provider keys exist to configure.
- Assistant summoning (v3.0.42/43): the app registers as a selectable
  Android digital assistant (voice-interaction service, wake activity,
  popup window and a quick-settings tile); plus the share-sheet
  "Ask Arix" and system text-selection `PROCESS_TEXT` entries.
- Diagnostics report state; they do not repair subsystems (repair belongs
  to each subsystem's own recovery logic).

## Classification notes (previously misdocumented)

- **Removed** (previously listed as current): pi-web-access and
  pi-subagents bundled extensions (replaced in v2.9.16 by the native
  `web_search`/`fetch_url` tools and the inbuilt Agent Swarm),
  Chromium/noVNC/CDP visual browser (replaced by the in-app WebView
  stack in v3.x).
- **Removed**: accessibility GUI agent (returned v2.9.8 as `gui_agent`;
  removed again in v3.0.77 at the user's request — no
  `AccessibilityService` is declared anymore).
- **Implemented**: voice input (`ArixVoiceListening` +
  `ArixSpeechRecognitionController`) — voice OUTPUT (TTS read-aloud,
  `ArixVoiceSpeaker`/`ArixTtsEngine`) shipped through v3.0.36 and was
  removed in v3.0.37 per user request; the old "no voice input/output"
  claim described v2.6-v2.9.3 and is long obsolete for input.
- **Partially implemented / experimental**: ACP client surface (session
  lifecycle, streaming, permissions and terminals work; some tool update
  content fields were fixed in v3.0.24), PDF/DOCX/XLSX extraction
  (no dedicated parser ships in v3.0.24 — text extraction is runtime/
  extension-dependent).
