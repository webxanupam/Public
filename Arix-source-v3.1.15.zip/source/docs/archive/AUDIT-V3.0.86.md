# Arix — v3.0.86 Full-Project Audit Report

Scope: the complete v3.0.85 source (342 Kotlin files, the pi-bridge
TypeScript package, the Gradle build, resources) re-audited for the
v3.0.86 release. Method: mechanical full-suite runs (Kotlin 912/912,
pi-bridge Node 77/77), targeted review of every file the release
touches, plus repo-wide sweeps for the failure classes previous audits
found (stale pins, dead code, destructive merges, protocol drift).

## A. Version / toolchain pins audit

| Pin | Verdict | Evidence |
| --- | --- | --- |
| pi-ai / pi-agent-core / pi-coding-agent / pi-tui 0.99.2 | USED, bumped this release | pi-bridge/package.json; bridge.ts version constants; PiKernelBridge.kt mirrors them |
| Node >= 22.19.0 | USED | PiBridgeNodeMinVersion + engines; `ensureNodeRuntime` gate |
| Gradle 8.13 / AGP 8.13.2 / Kotlin 2.4.0 | USED | wrapper + libs.versions.toml; unchanged, verified building |
| compileSdk 36 / minSdk 30 / targetSdk 28 | USED (targetSdk deliberately pinned — see docs/TARGET_SDK.md) | app/build.gradle.kts |
| arix.versionName 3.0.86 / versionCode 211 | USED | gradle.properties + build.gradle.kts fallbacks re-synced; 27 guard tests re-pinned (repo convention) |

## B. Bugs found → fixed (6)

1. **Bridge dropped cache-WRITE usage tokens** — pi-ai reported `cacheWrite`
   but `usagePayload()` omitted it; cache writes are billed higher on
   several providers. Fixed: the key ships on every usage payload, and the
   whole-turn totals accumulate it. (pi-bridge/src/bridge.ts)
2. **Bridge-only catalog refresh would wipe cached limits** — the new
   limits merge subtracted keys even when the caller supplied none;
   `refreshBridgeThinkingCatalog()` (which has no limits — models.dev owns
   them) would have erased them on every bridge ping. Fixed: the merge
   only re-defines keys when the argument is non-empty.
   (SettingsRepository.saveThinkingCatalogCache)
3. **Five stale pi-bridge tests shipped red in v3.0.85** — the weather /
   qr-code host-tool expectations were never updated after the v3.0.85
   tool removals (the Kotlin 912 were green; the Node suite was not
   re-run for the zip). Re-pinned to the upi_pay allowlist contract.
   (pi-bridge/tests/bridge.test.mjs)
4. **`login_provider` OAuth test pinned to a provider that gained OAuth**
   — pi 0.99.2's "openai" now bundles an OAuth flow, so the negative test
   asserted a rejection that no longer happens. Switched to "groq"
   (API-key-only builtin). (pi-bridge/tests/bridge.test.mjs)
5. **Duplicate Kotlin argument** after threading the limits map through
   the conversation UI (ArixApp passed it twice); caught by the compiler
   and removed.
6. **Guard-test pin drift from the v3.0.85 → v3.0.86 bump** — 27 guard
   files pin the current version; all re-pointed per the repo's
   documented convention, and the V3083 turn-context pin was updated for
   the 0.99.2 `TranscriptContext` migration (the pinned source string
   no longer exists by design).

## C. Dead code removed

- `MarkdownFadeSpan` + the whole per-chunk text-alpha fade layer
  (`plainMarkdownText`, the `fadeSpan` parameter threading through
  MarkdownContent → every block renderer → TableRenderer →
  CodeBlockRenderer, `StreamingMarkdownFrame`, the two chunk-fade
  constants): fully superseded by the StreamingReveal engine.
- Four private catalog-lookup helpers in ProviderModelCatalogClient
  (`publicCatalogProviderIds`, `publicCatalogModelKeys`,
  `findPublicCatalogModel`, `findPublicCatalogModelAcrossProviders`)
  folded into the shared ModelsDevCapabilities resolver.
- The unused `Animatable` import and the old caret-in-source fade path
  in ConversationMessages.

## D. Known minor observations (documented, deliberately NOT changed)

1. `ArixMochiEngine.tick` reads `ArixMochiBus.musicBass` as a global —
   fine for a single-process app; documented here since the canvas now
   also reads it for the headphone beat.
2. The faux provider's usage synthesis (0.99.2) makes faux-turn tests
   usage-heavy in the token-count assertions; the two new usage tests
   assert structure and accumulation, not exact token counts, on
   purpose.
3. `MessageStatisticsPopup` gains two rows and may exceed its previous
   height on very small screens; `widthIn(max = 300.dp)` keeps it within
   the popup margins and the rows wrap into the existing scroll-safe
   layout.
4. Room schema is UNCHANGED this release (usage fields live inside
   `messageJson`); database version stays 9 with no migration needed.
5. pi-bridge/src/extension-bridge.ts still carries stale "0.85.1"
   version constants (cosmetic only, never read at runtime).

## E. Feature suggestions for the next update

1. **Cost estimation** — pi-ai usage already carries a `cost` block;
   surfacing per-turn/session cost next to the token statistics is a
   small step now that whole-turn totals exist.
2. **Per-request usage events** — the bridge could emit interim usage
   on `assistant_done` events (currently only the final response
   carries totals), enabling a live token counter while streaming.
3. **models.dev limits in Settings → Default models** — the chat picker
   shows limits; wiring the same label into the Settings model lists
   would be a small reuse of `toMenuLimitsLabel`.
4. **Headphone state for the home companion** — the home card enters
   Sleeping by hour; it could enter Listening from the same music-bus
   signals the header companion already consumes.
5. **Fade pacing controls** — expose the reveal duration (400 ms) and
   stagger as developer settings for accessibility tuning.
