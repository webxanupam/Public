# Arix — v3.0.41 Full-Project Audit Report

Scope: every Kotlin file in `app/src` (155 files), `shared/src` (31),
pi-bridge TypeScript, Gradle configuration, manifest and resources.
Method: three parallel deep-read passes (UI composables; data/runtime/
services; shared module + infra) + compiler/test verification. All 877
unit tests pass after the fixes; release build signed and verified.

---

## A. Manifest permission audit — all 13 permissions used, none removed

| Permission | Verdict | Primary code evidence |
|---|---|---|
| INTERNET | USED | TermuxRuntime bootstrap/network, weather/image/file-share clients, model catalogs, MCP, WebViews |
| POST_NOTIFICATIONS | USED | ArixNotificationController (check), MainActivity (request) |
| FOREGROUND_SERVICE | USED | ArixForegroundService.startForegroundService |
| FOREGROUND_SERVICE_DATA_SYNC | USED | ArixForegroundService (type=dataSync) |
| FOREGROUND_SERVICE_MEDIA_PLAYBACK | USED | ArixMediaPlaybackService + Media3 session |
| RECEIVE_BOOT_COMPLETED | USED | ScheduledTaskRescheduleReceiver (boot/time/timezone/pkg-replaced) |
| SCHEDULE_EXACT_ALARM | USED | ScheduledTaskScheduler.setExactAndAllowWhileIdle |
| RECORD_AUDIO | USED | ArixSpeechRecognitionController (in-app recognition) |
| WAKE_LOCK | USED | ArixGuiAgentService (bounded bright lock during GUI-agent runs) |
| READ_EXTERNAL_STORAGE (≤32) | USED | ArixDeviceStorage legacy grant path |
| WRITE_EXTERNAL_STORAGE (≤28) | USED | ArixDeviceStorage legacy grant path |
| MANAGE_EXTERNAL_STORAGE | USED | Files screen /device root (All-files-access card) |

**"All permissions already enabled":** v3.0.41 adds a startup permission
pass (notifications + mic + legacy storage) — see V3.0.41-CHANGES.md §3.
All-files-access keeps its platform-mandated settings deep link.

## B. Bugs found → fixed (20)

See V3.0.41-CHANGES.md §4 for the annotated list with file references.
Severity mix: 5 high (HTML editor cursor, stale seek duration, poster-rail
index mapping, non-cancellable 10-20 min process waits, backup dropping 8
settings), 15 medium/low (recomposition storms, stale model pill,
composition-time side effects, O(n²) markdown parsing, stale KaTeX theme
colors, main-thread IO, locale crash guard, message-id collisions,
background-run refresh race, swallowed DataStore failures, UTF-8 chunk
corruption, main-thread prewarm, Response leak, busy-poll, dead branches).

## C. Unused code removed

~200 lines of dead Kotlin + 1 dead drawable + the dead copyPiProviderIcons
Gradle pipeline (12 duplicate PNGs) + 30 catalog-only strings + the
catalog test file. Every candidate was re-verified against BOTH resource
accessor paths (`R.string.*` AND `Res.string.*`) before removal — the
audit's initial "56 unused strings" finding was retracted after the
second pattern check showed all of them live.

## D. Known minor observations (documented, deliberately NOT changed)

These are low-severity items an auditor would flag; none affect
correctness today and several involve trade-offs (fixing them would
change visible behavior):

1. Remote-image `produceState` producers keep the previous bitmap while a
   new URL loads (stale-but-plausible image instead of a placeholder
   flash) — ConversationMessages/MarkdownRenderer/ArixToolWidgets.
2. `AndroidView` factories capture first-composition callbacks (benign
   today: callbacks capture stable state).
3. Markdown image decoding allows up to 8 MB bitmaps without
   `inSampleSize` down-sampling (unlike the attachment path).
4. "Add to queue" during playback jumps playback to the appended item
   (existing designed behavior).
5. `ArixMusicPulse` timing fields are written on the capture thread and
   read on main without `@Volatile` (benign timing race).
6. File-picker display-name queries run on main in one Tools-UI path.
7. The root `extensions/` vendor directory referenced by
   `copyPreinstalledExtensions` does not exist in this tree — the task is
   a graceful no-op (mechanism kept for builds that vendor extensions).
8. `buildPiBridge` declares only `dist/bridge.mjs` as output although npm
   builds three bundles (the other two are test-only).

## E. Feature suggestions for the next update (attention-grabbers)

Chosen to build on the EXISTING engines (no new infrastructure risk) and
to demo well in a 30-second clip:

1. **Arix Vision — "point the camera, get it done".** The GUI-agent +
   accessibility tree + vision-capable chat models are already in the
   app. Adding a live-camera frame grab (CameraX → base64 → the existing
   image-capable model path) lets users point at a WiFi router label, a
   plant, an error screen, or a receipt and have Arix act on it (set up
   the router, diagnose the plant, file the receipt). One new permission,
   one new surface, enormous demo value.
2. **Screen-aware follow-ups ("What am I looking at?").** A screenshot
   share-target that pipes the CURRENT screen into the conversation with
   the accessibility-tree snapshot the GUI agent already collects —
   "explain this error and fix it" in one tap, from any app via the share
   sheet that already exists.
3. **Live Agent Watch (Virtual Screen, everywhere).** The shared browser
   + Virtual Screen card already streams agent browsing into chat.
   Extending it with a thumbnail strip of the agent's recent steps
   (screenshots/tool cards) turns invisible background work into a
   mesmerizing "the AI is working" show — the single most attention-
   grabbing UI pattern of 2025 agent apps.
4. **Voice-driven device control.** RECORD_AUDIO + the GUI agent +
   speech recognition already exist; wiring continuous "Hey Arix" (given
   the existing foreground service) so the user can say "open Photos and
   share the last screenshot with mom" is a headline feature.
5. **Scheduled agent routines ("morning brief").** The scheduled-task
   engine, weather client, mission engine and memory store already exist.
   A "Brief me every morning: weather + calendar-style mission digest +
   follow-ups from my saved research" template would showcase the
   automation stack with zero new subsystems.
6. **Arix Widgets (home-screen companions).** The mini-player, robot
   companion and music-pulse engine are ready-made Glance/AppWidget
   content: a dancing robot widget + tap-to-ask launcher keeps Arix
   visible all day.
