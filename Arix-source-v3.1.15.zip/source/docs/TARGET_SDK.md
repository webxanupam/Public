# Arix target SDK — root-cause analysis and modernization path

*v3.0.82 — written for the "TARGET SDK" work item. v3.0.88 — re-verified
after a second user request to "build for modern Android" (see the
"v3.0.88 re-verification" section at the bottom).*

## Where we stand

| Setting    | Value | Why |
|------------|-------|-----|
| compileSdk | 36    | Build against the newest platform APIs. |
| **minSdk** | **30** | **v3.0.82: minimum Android 11 (user requirement).** Devices below Android 11 are no longer supported. |
| targetSdk  | 28    | Pinned — see the root cause below. Side-loaded app, so Play policy does not apply. |

## The EXACT reason the embedded runtime requires targetSdk 28

The embedded Termux/proot runtime executes guest binaries from the app's
**writable data directory**:

```
/data/data/com.arix.app/files/runtimes/termux/usr/bin/bash   (guest: /data/data/com.termux/files/usr)
/data/data/com.arix.app/files/runtimes/termux/usr/bin/dpkg
/data/data/com.arix.app/files/runtimes/termux/usr/bin/node
…
```

Every guest command is launched by the host Android linker via proot:

```
/system/bin/linker64 <proot> … $PREFIX/bin/bash -lc "<command>"
```

Files inside the app's writable data directory carry the SELinux label
`app_data_file`. Android's system SELinux policy contains a **neverallow**
that forbids app processes of apps **targeting API 29+** from `execve()`
of `app_data_file` (the W^X / executable-data enforcement introduced with
scoped storage in Android 10):

```
neverallow { appdomain -untrusted_app_27 -untrusted_app_29 … } app_data_file:file { execute };
```

The exception list is keyed to the app's **targetSdk**, not the device
version or minSdk. Concretely:

* targetSdk 28 → the app process runs with a policy that still allows
  executing `app_data_file` → proot execve succeeds → the runtime works.
* targetSdk ≥ 29 → every `execve` of a guest binary returns
  **EACCES ("Permission denied")** → proot reports
  `proot error: execve(...): Permission denied` → **every** guest command,
  including the bootstrap's own `dpkg` repair, dies.

This was observed empirically in v2.9.25 (which briefly raised targetSdk
to 36): the runtime bootstrap broke on Android 10+ devices and the pin
back to 28 restored it. Upstream Termux itself ships targetSdk 28 for
exactly the same reason, and its runtime also installs packages at
runtime into a data-dir prefix.

A second, related constraint: the runtime is **dynamic** — `apt`/`dpkg`
install and update packages *into the data directory at run time*. Those
newly-written binaries would also carry `app_data_file`, so no amount of
pre-packaging the bootstrap solves the whole problem while the runtime
stays dynamic.

## Why simply bumping targetSdk is not a fix

Raising targetSdk to 29+ without redesigning the execution substrate
breaks every guest command on every device — not an edge case, the whole
Terminal tool, the pi-bridge kernel (a Node.js process!) and every
agent capability that shells out. "Do not simply change targetSdk and
hope it works" is exactly right.

## The designed migration path (v3.0.82 groundwork)

The component that must be redesigned is the **runtime execution
substrate** — the place where guest binaries are stored and executed:

1. **STATIC bootstrap via the native library directory.** Binaries
   packaged inside the APK's `lib/<abi>/` directory (named
   `lib<name>.so`, with `android:extractNativeLibs="true"` /
   `useLegacyPackaging = true`) are extracted by the installer into
   `/data/app/<pkg>/lib/<abi>/` and labeled **`apk_lib_data_file`** —
   which IS executable for apps targeting any API level. Shipping the
   bootstrap's core executables (linker, busybox, bash, coreutils, dpkg,
   apt, node) this way gives a fixed, always-executable runtime core.
2. **A `RuntimeExecPolicy` seam.** The runtime then distinguishes:
   * *core* executables → always resolved from the lib dir (executable
     under any targetSdk);
   * *dynamically installed* files → still in the data dir, which works
     while targetSdk is 28.
   A future build can flip `arix.targetSdk` once the dynamic-install
   surface is either frozen (fixed runtime image) or routed through the
   lib-dir core (e.g. a `dpkg` that installs into a directory bind-mounted
   read-only from a lib-dir overlay).
3. **What does NOT need to change:** every platform behavior the app
   already runtime-checks (scoped storage + MANAGE_EXTERNAL_STORAGE on
   30+, background FGS start guards on 31+, FGS timeouts on 34+,
   exact-alarm gating on 12+). Those migrations are complete and keyed to
   `Build.VERSION.SDK_INT`, independent of targetSdk.

Until (1)+(2) land, **targetSdk stays 28** — the same choice upstream
Termux makes — and the app remains fully functional on Android 11+
(which is now the floor via minSdk 30).

## What v3.0.82 changed

* `minSdk` 26 → **30** (Android 11 minimum, per the user requirement).
* This document (the "identify exactly why" deliverable).
* The groundwork seam for the static-runtime migration is isolated in
  `runtime/TermuxRuntime.kt` (bootstrap layout + `TermuxHostLinker`
  execution), so the future flip is a contained change rather than a
  cross-cutting hunt.

## v3.0.88 re-verification (second user request)

The user reported again: *"This app build in older version of android —
do it for android 11 to start support min need device."* Findings on
re-examination, with the shipped v3.0.87 APK verified through
`aapt dump badging`:

* **Android 11 minimum: already guaranteed.** The shipped APK declares
  `sdkVersion:'30'` — every device from Android 11 (API 30) through
  Android 16 (API 36) installs and runs it. This is now permanently
  guarded by `V3088SourceGuardTest.android 11 is the minimum supported
  device`.
* **The "older version" install notice comes from `targetSdkVersion:'28'`**
  and is advisory only — it never blocks installation and nothing in the
  app degrades because of it.
* **Raising targetSdk was re-evaluated and rejected again**, with the
  runtime audited end-to-end this time: the bootstrap asset is a full
  Termux rootfs (4,807 entries, 73.3 MB unpacked) extracted into the
  app's writable data directory, every guest binary (bash, dpkg, apt,
  node, npx …) is `execve()`d from there through the host
  `linker64` + proot launch chain, and `apt`/`pkg` install further
  binaries into the same data directory **at run time** (Settings →
  Termux → Packages). Any `targetSdk ≥ 29` kills all of it on every
  device (the SELinux neverallow is keyed to the target, not the
  device); upstream Termux ships 28 for the identical reason, and this
  app carries `isGuestExecBlockedOutput` /
  `TermuxGuestExecBlockedAdvice` precisely because the breakage was
  observed once before (v2.9.25, briefly targetSdk 36).
* The static-bootstrap migration (lib-dir core + frozen runtime image)
  remains the only path to a modern targetSdk; it cannot ship as part of
  a hot-fix release because it would freeze or remove the dynamic
  package-install surface (a user-facing feature), and it requires
  on-device verification. `V3088SourceGuardTest.target sdk stays at 28
  for the embedded runtime` keeps the pin — and the reason — executable
  documentation.

## v3.1.4 re-verification (third request: "minimum android 12")

The user asked again: *"The app built for old android so fix it. Make it
newer version minimum android 12 do all compatible for android 11 not
older version android."* Re-verified end-to-end for this release:

* **"Compatible for Android 11, not older"** — guaranteed and guarded:
  `minSdk = 30` (Android 11 is the OLDEST installable device), nothing
  below installs, and `V3088SourceGuardTest.android 11 is the minimum
  supported device` keeps it executable.
* **"Newer version / modern Android"** — the app COMPILES against the
  newest platform (compileSdk 36, Android 16) and every modern platform
  behavior is already migrated and runtime-keyed to `Build.VERSION.SDK_INT`
  (scoped storage + all-files access on 30+, background FGS start guards
  on 31+, FGS onTimeout budgets on 34+, exact-alarm gating on 12+,
  notification trampolines, photo picker, etc.). On an Android 12/13/14/
  15/16 phone the app runs with all current-gen behavior — the ONLY thing
  targetSdk 28 changes is the SELinux exec policy for the embedded
  runtime (below).
* **targetSdk stays 28 — still not a bug.** Raising it to 29+ (e.g. 31
  "Android 12" or 36) trips the SELinux neverallow that kills
  `execve`/PROT_EXEC of every guest binary in
  `/data/data/com.arix.app/files/runtimes/termux` — the Termux rootfs the
  WHOLE app is built on (bash/dpkg/node = the pi-bridge agent kernel,
  the Terminal tool, every skill including Video Studio's ffmpeg/python).
  Upstream Termux ships targetSdk 28 for the identical reason; the
  breakage was observed empirically once before (v2.9.25). The only
  install-time effect is a side-load advisory dialog — never a block.
* The static-bootstrap migration (lib-dir core + frozen runtime image)
  remains the only real path to a modern targetSdk; it still cannot ship
  without removing the dynamic package-install surface (a user feature)
  and without on-device verification.
