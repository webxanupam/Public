#!/usr/bin/env python3
"""Scan all V*SourceGuardTest pins: every assertTrue/assertFalse
contains() against a source file, resolved and checked. Reports stale
pins (pre-existing test bugs) so they can be superseded.

v3.1.4 - REWRITTEN resolver. The old line-by-line checker had three bugs
that produced false STALE reports (7 of them on the v3.1.2 tree):
  1. it never reset variable mappings between test methods, so a local
     `bridge` in one method was resolved against an unrelated `bridge`
     assigned in another method (V3038: Kotlin PiKernelBridge vs the
     TypeScript bridge.ts);
  2. it only tracked single-source assignments, so concatenated sources
     (`val renderer = appSource(a) + appSource(b)`) were checked against
     the FIRST file only (V3029: pins living in WebContentRenderer.kt);
  3. it unescaped only \\" and \\\\, so pins containing \\$ or \\n escaped
     (V2926 / V3011 / V3099).
The new resolver parses the whole file text, tracks the nearest
same-scope assignment (resetting at every `fun ` boundary), supports
concatenated appSource()/rootFile() chains, decodes the full Kotlin
escape set, and supports the optional assertTrue("msg", ...) form.
Assignments it cannot resolve statically (File(...).readText(), helper
functions, template arguments) are counted as skipped, not stale.
"""
import io
import os
import re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TESTS = os.path.join(ROOT, "app/src/test/java/com/arix/app/data")

ASSIGN_RE = re.compile(
    r'val\s+(\w+)\s*=\s*((?:appSource|rootFile)\s*\(\s*"[^"]*"\s*\)'
    r'(?:\s*\+\s*(?:appSource|rootFile)\s*\(\s*"[^"]*"\s*\))*)'
)
PIN_RE = re.compile(
    r'assert(True|False)\(\s*(?:"(?:[^"\\]|\\.)*"\s*,\s*)?(\w+)\.contains\(\s*"((?:[^"\\]|\\.)*)"\s*\)\s*\)'
)
FUN_RE = re.compile(r'^\s*(?:@\w+\s*(?:\([^)]*\))?\s*)*fun\s', re.MULTILINE)

ESCAPES = {
    "n": "\n", "t": "\t", "r": "\r", "b": "\b",
    '"': '"', "'": "'", "\\": "\\", "$": "$", "0": "\0",
}

def unescape_kotlin(s):
    out = []
    i = 0
    while i < len(s):
        c = s[i]
        if c == "\\" and i + 1 < len(s):
            n = s[i + 1]
            if n == "u" and i + 5 < len(s):
                try:
                    out.append(chr(int(s[i + 2:i + 6], 16)))
                    i += 6
                    continue
                except ValueError:
                    pass
            out.append(ESCAPES.get(n, n))
            i += 2
        else:
            out.append(c)
            i += 1
    return "".join(out)

def resolve_target(kind, rel):
    if kind == "appSource":
        return os.path.join(ROOT, "app/src/main/java/com/arix/app", rel)
    return os.path.join(ROOT, rel)

def line_of(text, offset):
    return text.count("\n", 0, offset) + 1

def check_file(path):
    with io.open(path, encoding="utf-8") as fh:
        text = fh.read()

    assignments = []
    for m in ASSIGN_RE.finditer(text):
        chain = []
        for part in re.finditer(r'(appSource|rootFile)\s*\(\s*"([^"]*)"\s*\)', m.group(2)):
            chain.append((part.group(1), part.group(2)))
        assignments.append((m.group(1), chain, m.start()))

    results = {"ok": 0, "stale": [], "skipped": 0}
    for m in PIN_RE.finditer(text):
        kind, var, raw_needle = m.group(1), m.group(2), m.group(3)
        offset = m.start()

        scope_start = 0
        for fm in FUN_RE.finditer(text, 0, offset):
            scope_start = fm.start()

        candidates = [a for a in assignments if a[0] == var and a[2] < offset and a[2] > scope_start]
        if not candidates:
            results["skipped"] += 1
            continue
        _, chain, _ = candidates[-1]
        content = ""
        missing = []
        for func, rel in chain:
            target = resolve_target(func, rel)
            if os.path.isfile(target):
                with io.open(target, encoding="utf-8") as fh:
                    content += fh.read()
            else:
                missing.append(rel)
        if missing and not content:
            results["skipped"] += 1
            continue
        needle = unescape_kotlin(raw_needle)
        found = needle in content
        if kind == "True" and not found:
            results["stale"].append(
                (os.path.basename(path), line_of(text, offset), "assertTrue", ", ".join(c[1] for c in chain), needle)
            )
        elif kind == "False" and found:
            results["stale"].append(
                (os.path.basename(path), line_of(text, offset), "assertFalse(FOUND)", ", ".join(c[1] for c in chain), needle)
            )
        else:
            results["ok"] += 1
    return results

def main():
    total = {"ok": 0, "stale": [], "skipped": 0}
    for fn in sorted(os.listdir(TESTS)):
        if not (fn.startswith("V") and fn.endswith("SourceGuardTest.kt")):
            continue
        r = check_file(os.path.join(TESTS, fn))
        total["ok"] += r["ok"]
        total["stale"] += r["stale"]
        total["skipped"] += r["skipped"]

    print(f"pins OK: {total['ok']}")
    print(f"pins skipped (not statically resolvable): {total['skipped']}")
    print(f"STALE PINS: {len(total['stale'])}")
    for fn, ln, kind, rel, needle in total["stale"]:
        print(f"  {fn}:{ln} {kind} {rel} :: {needle[:90]}")
    return 1 if total["stale"] else 0

if __name__ == "__main__":
    raise SystemExit(main())
