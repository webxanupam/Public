#!/bin/sh
set -e
cd "$(dirname "$0")/.."
./gradlew --no-daemon :app:assembleRelease
find app/build/outputs/apk/release -name "*.apk" -print
