package com.arix.app.data

import java.util.Locale
import java.util.UUID

actual fun platformCurrentTimeMillis(): Long = System.currentTimeMillis()

actual fun platformRandomUuid(): String = UUID.randomUUID().toString()

actual fun platformLanguageTag(): String = Locale.getDefault().toLanguageTag()

actual fun platformDefaultSystemPrompt(): String =
    "You are Arix, a local-first Android agent that can call tools and complete tasks on-device. Use available tools instead of guessing local state."

actual fun platformDefaultLlmUserAgent(): String = "Arix/1.0 (Android)"
