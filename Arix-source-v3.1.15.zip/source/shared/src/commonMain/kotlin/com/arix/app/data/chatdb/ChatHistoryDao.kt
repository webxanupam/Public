package com.arix.app.data.chatdb

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

@Dao
interface ChatHistoryDao {
    @Query("SELECT * FROM chat_sessions ORDER BY sortOrder ASC")
    fun observeSessions(): Flow<List<ChatSessionEntity>>

    @Query("SELECT * FROM chat_sessions ORDER BY sortOrder ASC")
    suspend fun getSessions(): List<ChatSessionEntity>

    @Query("SELECT * FROM chat_state_meta WHERE id = :id")
    fun observeMeta(id: String = ChatStateMetaEntityId): Flow<ChatStateMetaEntity?>

    @Query("SELECT * FROM chat_state_meta WHERE id = :id")
    suspend fun getMeta(id: String = ChatStateMetaEntityId): ChatStateMetaEntity?

    @Query("SELECT * FROM chat_sessions WHERE id = :sessionId")
    suspend fun getSession(sessionId: String): ChatSessionEntity?

    @Query("SELECT * FROM chat_agent_sessions WHERE chatSessionId = :sessionId")
    suspend fun getAgentSession(sessionId: String): ChatAgentSessionEntity?

    @Query("SELECT * FROM chat_agent_message_refs WHERE chatSessionId = :sessionId ORDER BY arixMessageId, ordinal")
    suspend fun getAgentMessageRefs(sessionId: String): List<ChatAgentMessageRefEntity>

    @Query("SELECT * FROM chat_agent_message_refs WHERE chatSessionId = :sessionId AND arixMessageId = :messageId ORDER BY ordinal")
    suspend fun getAgentMessageRefs(sessionId: String, messageId: String): List<ChatAgentMessageRefEntity>

    @Query("SELECT COUNT(*) FROM chat_messages WHERE sessionId = :sessionId")
    suspend fun getMessageCountForSession(sessionId: String): Int

    @Query("SELECT id AS messageId, length(messageJson) AS jsonLength FROM chat_messages WHERE sessionId = :sessionId ORDER BY position ASC")
    suspend fun getMessageFingerprintsForSession(sessionId: String): List<ChatMessageFingerprintEntity>

    @Query("SELECT COUNT(*) FROM chat_messages WHERE sessionId = :sessionId AND responseGroupId = :responseGroupId AND position >= :fromPosition")
    suspend fun getMessageCountForResponseGroup(
        sessionId: String,
        responseGroupId: String,
        fromPosition: Int,
    ): Int

    @Query("SELECT * FROM chat_messages WHERE sessionId = :sessionId ORDER BY position ASC")
    suspend fun getMessagesForSession(sessionId: String): List<ChatMessageEntity>

    @Query("""
        SELECT sessionId, COUNT(*) AS messageCount, MAX(COALESCE(createdAtMillis, 0)) AS lastMessageAtMillis
        FROM chat_messages
        WHERE sessionId IN (:sessionIds)
        GROUP BY sessionId
    """)
    suspend fun getMessageStatsForSessions(sessionIds: List<String>): List<ChatSessionMessageStatsEntity>

    @Query("""
        SELECT sessionId, COUNT(*) AS messageCount, MAX(COALESCE(createdAtMillis, 0)) AS lastMessageAtMillis
        FROM chat_messages
        WHERE sessionId IN (:sessionIds)
        GROUP BY sessionId
    """)
    fun observeMessageStatsForSessions(sessionIds: List<String>): Flow<List<ChatSessionMessageStatsEntity>>

    @Query("""
        SELECT sessionId, id, position, author, text, createdAtMillis, responseGroupId, displayKind, messageSchemaVersion, length(messageJson) AS messageJsonLength, isIncomplete
        FROM chat_messages
        WHERE hasUsageStatistics = 1
        ORDER BY sessionId ASC, position ASC
    """)
    suspend fun getUsageStatisticsMessageSummaries(): List<ChatMessageSummaryEntity>

    @Query("""
        SELECT sessionId, id, position, author, text, createdAtMillis, responseGroupId, displayKind, messageSchemaVersion, length(messageJson) AS messageJsonLength, isIncomplete
        FROM chat_messages
        WHERE sessionId = :sessionId
        ORDER BY position ASC
    """)
    fun observeMessageSummariesForSession(sessionId: String): Flow<List<ChatMessageSummaryEntity>>

    @Query("""
        SELECT sessionId, id, position, author, text, createdAtMillis, responseGroupId, displayKind, messageSchemaVersion, length(messageJson) AS messageJsonLength, isIncomplete
        FROM chat_messages
        WHERE sessionId IN (:sessionIds)
        ORDER BY sessionId ASC, position ASC
    """)
    suspend fun getMessageSummariesForSessions(sessionIds: List<String>): List<ChatMessageSummaryEntity>

    suspend fun getMessageSummariesForSession(sessionId: String): List<ChatMessageSummaryEntity> =
        observeMessageSummariesForSession(sessionId).first()

    @Query("""
        SELECT length(messageJson)
        FROM chat_messages
        WHERE sessionId = :sessionId AND id = :messageId
    """)
    suspend fun getMessageJsonLength(
        sessionId: String,
        messageId: String,
    ): Int?

    @Query("""
        SELECT substr(messageJson, :start, :length)
        FROM chat_messages
        WHERE sessionId = :sessionId AND id = :messageId
    """)
    suspend fun getMessageJsonChunk(
        sessionId: String,
        messageId: String,
        start: Int,
        length: Int,
    ): String?

    @Query("""
        SELECT DISTINCT path
        FROM chat_workspace_file_refs
        WHERE sessionId = :sessionId
        ORDER BY path ASC
    """)
    suspend fun getWorkspaceFilePathsForSession(sessionId: String): List<String>

    @Query("""
        SELECT DISTINCT path
        FROM chat_workspace_file_refs
        WHERE sessionId = :sessionId AND messageId IN (:messageIds)
        ORDER BY path ASC
    """)
    suspend fun getWorkspaceFilePathsForMessages(
        sessionId: String,
        messageIds: List<String>,
    ): List<String>

    @Query("""
        SELECT sessionId, messageId, path
        FROM chat_workspace_file_refs
        WHERE path IN (:paths)
        ORDER BY path ASC
    """)
    suspend fun getWorkspaceFileRefsForPaths(paths: List<String>): List<ChatWorkspaceFileRefEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMeta(meta: ChatStateMetaEntity)

    @Upsert
    suspend fun upsertSessions(sessions: List<ChatSessionEntity>)

    @Upsert
    suspend fun upsertAgentSession(session: ChatAgentSessionEntity)

    @Upsert
    suspend fun upsertAgentMessageRefs(refs: List<ChatAgentMessageRefEntity>)

    @Query("UPDATE chat_sessions SET selectedModelKey = :selectedModelKey WHERE id = :sessionId")
    suspend fun updateSelectedModelKey(sessionId: String, selectedModelKey: String)

    @Upsert
    suspend fun upsertMessages(messages: List<ChatMessageEntity>)

    @Upsert
    suspend fun upsertWorkspaceFileRefs(refs: List<ChatWorkspaceFileRefEntity>)

    @Query("DELETE FROM chat_workspace_file_refs WHERE sessionId = :sessionId AND messageId = :messageId")
    suspend fun deleteWorkspaceFileRefsForMessage(sessionId: String, messageId: String)

    @Query("DELETE FROM chat_workspace_file_refs WHERE sessionId = :sessionId AND messageId IN (SELECT id FROM chat_messages WHERE sessionId = :sessionId AND responseGroupId = :responseGroupId AND position >= :fromPosition)")
    suspend fun deleteWorkspaceFileRefsForResponseGroup(
        sessionId: String,
        responseGroupId: String,
        fromPosition: Int,
    )

    @Query("DELETE FROM chat_workspace_file_refs WHERE sessionId = :sessionId AND messageId IN (SELECT id FROM chat_messages WHERE sessionId = :sessionId AND position >= :fromPosition)")
    suspend fun deleteWorkspaceFileRefsFromPosition(sessionId: String, fromPosition: Int)

    @Query("DELETE FROM chat_workspace_file_refs WHERE sessionId = :sessionId")
    suspend fun deleteWorkspaceFileRefsForSession(sessionId: String)

    @Query("DELETE FROM chat_workspace_file_refs WHERE sessionId NOT IN (:sessionIds)")
    suspend fun deleteWorkspaceFileRefsExceptSessions(sessionIds: List<String>)

    @Query("DELETE FROM chat_workspace_file_refs")
    suspend fun deleteAllWorkspaceFileRefs()

    @Query("DELETE FROM chat_messages WHERE sessionId = :sessionId AND position >= :fromPosition")
    suspend fun deleteMessagesFromPosition(sessionId: String, fromPosition: Int)

    @Query("DELETE FROM chat_messages WHERE sessionId = :sessionId AND responseGroupId = :responseGroupId AND position >= :fromPosition")
    suspend fun deleteMessagesForResponseGroup(
        sessionId: String,
        responseGroupId: String,
        fromPosition: Int,
    )

    @Query("""
        SELECT id
        FROM chat_messages
        WHERE sessionId = :sessionId
            AND position >= :fromPosition
            AND position < :toPosition
            AND (responseGroupId IS NULL OR responseGroupId != :responseGroupId)
    """)
    suspend fun getMessageIdsToParkOutsideResponseGroup(
        sessionId: String,
        responseGroupId: String,
        fromPosition: Int,
        toPosition: Int,
    ): List<String>

    @Query("""
        UPDATE chat_messages
        SET position = -position - 1
        WHERE sessionId = :sessionId
            AND position >= :fromPosition
            AND position < :toPosition
            AND (responseGroupId IS NULL OR responseGroupId != :responseGroupId)
    """)
    suspend fun parkMessagesFromPositionOutsideResponseGroup(
        sessionId: String,
        responseGroupId: String,
        fromPosition: Int,
        toPosition: Int,
    )

    @Query("""
        UPDATE chat_messages
        SET position = (-position - 1) + :positionDelta
        WHERE sessionId = :sessionId
            AND id IN (:parkedMessageIds)
            AND position >= (0 - :toPosition)
            AND position <= (0 - :fromPosition) - 1
            AND (-position - 1) + :positionDelta >= :checkpointEndPosition
            AND (responseGroupId IS NULL OR responseGroupId != :responseGroupId)
    """)
    suspend fun restoreParkedMessagesOutsideResponseGroup(
        sessionId: String,
        responseGroupId: String,
        fromPosition: Int,
        toPosition: Int,
        checkpointEndPosition: Int,
        parkedMessageIds: List<String>,
        positionDelta: Int,
    )

    @Query("DELETE FROM chat_sessions WHERE id = :sessionId")
    suspend fun deleteSession(sessionId: String)

    @Query("DELETE FROM chat_agent_sessions WHERE chatSessionId = :sessionId")
    suspend fun deleteAgentSession(sessionId: String)

    @Query("DELETE FROM chat_agent_message_refs WHERE chatSessionId = :sessionId")
    suspend fun deleteAgentMessageRefs(sessionId: String)

    @Query("DELETE FROM chat_sessions WHERE id NOT IN (:sessionIds)")
    suspend fun deleteSessionsExcept(sessionIds: List<String>)

    @Query("DELETE FROM chat_messages WHERE sessionId = :sessionId")
    suspend fun deleteMessagesForSession(sessionId: String)

    @Query("DELETE FROM chat_messages WHERE sessionId NOT IN (:sessionIds)")
    suspend fun deleteMessagesExceptSessions(sessionIds: List<String>)

    @Query("DELETE FROM chat_messages")
    suspend fun deleteAllMessages()

    @Query("DELETE FROM chat_sessions")
    suspend fun deleteAllSessions()
}
