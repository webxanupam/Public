package com.arix.app.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.ArrowDropDown
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.Login
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.arix.app.data.platformCurrentTimeMillis
import com.arix.app.data.platformRandomUuid
import com.arix.app.shared.resources.Res
import com.arix.app.shared.resources.*
import org.jetbrains.compose.resources.stringResource
import com.arix.app.data.LlmProviderConfig
import com.arix.app.data.LlmCustomHeader
import com.arix.app.data.PiProviderCatalog
import com.arix.app.data.DefaultPiProviderId
import com.arix.app.data.PiProviderDefinition
import com.arix.app.data.PiProviderEnvironmentVariable
import com.arix.app.data.ProviderAuthMethod
import com.arix.app.data.defaultAuthMethod
import com.arix.app.data.isValidProviderId
import com.arix.app.data.normalizeLlmUserAgent
import com.arix.app.data.sanitizeProviderId
import com.arix.app.data.sortedByPreferredModelName
import com.arix.app.data.pi.PiOAuthPrompt
import com.arix.app.data.pi.PiProviderAuthState
import com.arix.app.platform.PlatformServices
import com.arix.app.ui.theme.ArixError
import com.arix.app.ui.theme.ArixOnPrimary
import com.arix.app.ui.theme.ArixOnSurface
import com.arix.app.ui.theme.ArixOnSurfaceVariant
import com.arix.app.ui.theme.ArixPrimary
import com.arix.app.ui.theme.ArixSettingsBackground
import com.arix.app.ui.theme.ArixSurface
import com.arix.app.ui.theme.ArixSurfaceHigh
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val ProviderFormPrimary = Color(0xFF5C5C5C)
private val ProviderWizardEasing = CubicBezierEasing(0.22f, 0.84f, 0.18f, 1f)
private val InteractiveCredentialProviderIds = setOf(
    "cloudflare-ai-gateway",
    "cloudflare-workers-ai",
)

private val KeylessFreeTierProviderIds = setOf(
    "kilo",
    "pollinations",
    "llm7",
)

internal val LocalPlatformServices = staticCompositionLocalOf<PlatformServices?> { null }

@Stable
class ProviderFormState constructor(
    private val existingConfig: LlmProviderConfig?,
    providerId: String,
    name: String,
    piProviderId: String,
    authMethodStorageValue: String,
    apiKey: String,
    additionalApiKeys: List<String> = emptyList(),
    multiKeyEnabled: Boolean = additionalApiKeys.isNotEmpty(),
    keyRotationStrategy: String = com.arix.app.data.KeyRotationStrategySequential,
    keyCooldownMinutes: Int = com.arix.app.data.DefaultKeyCooldownMinutes,
    keySwitchStatusCodesCsv: String = "",
    oauthCredentialJson: String,
    providerEnvironmentVariables: List<PiProviderEnvironmentVariable>,
    baseUrl: String,
    modelId: String,
    userAgent: String,
    customHeaders: List<LlmCustomHeader>,
    compatibilityMode: Boolean,
    serviceTier: String = "",
    cachedModels: List<String>,
    enabledModelIds: List<String>,
    providerIdManuallyEdited: Boolean = existingConfig != null,
    lastAutoGeneratedProviderId: String = providerId,
) {
    var providerId by mutableStateOf(providerId)
    var name by mutableStateOf(name)
    var piProviderId by mutableStateOf(piProviderId)
    var authMethodStorageValue by mutableStateOf(authMethodStorageValue)
    var apiKey by mutableStateOf(apiKey)
    var additionalApiKeys by mutableStateOf(additionalApiKeys)
    var multiKeyEnabled by mutableStateOf(multiKeyEnabled)
    var keyRotationStrategy by mutableStateOf(keyRotationStrategy)
    var keyCooldownMinutes by mutableStateOf(keyCooldownMinutes)
    var keySwitchStatusCodesCsv by mutableStateOf(keySwitchStatusCodesCsv)
    var oauthCredentialJson by mutableStateOf(oauthCredentialJson)
    var providerEnvironmentVariables by mutableStateOf(providerEnvironmentVariables)
    var baseUrl by mutableStateOf(baseUrl)
    var modelId by mutableStateOf(modelId)
    var userAgent by mutableStateOf(userAgent)
    var customHeaders by mutableStateOf(customHeaders)
    var serviceTier by mutableStateOf(serviceTier)
    var compatibilityMode by mutableStateOf(compatibilityMode)
    var cachedModels by mutableStateOf(cachedModels)
    var enabledModelIds by mutableStateOf(enabledModelIds)
    var isFetchingModelsLocally by mutableStateOf(false)
    private var providerIdManuallyEdited by mutableStateOf(providerIdManuallyEdited)
    private var lastAutoGeneratedProviderId by mutableStateOf(lastAutoGeneratedProviderId)

    val selectedDefinition: PiProviderDefinition
        get() = PiProviderCatalog.resolve(piProviderId)

    val authMethod: ProviderAuthMethod
        get() = ProviderAuthMethod.fromStorage(
            authMethodStorageValue,
            selectedDefinition.defaultAuthMethod(),
        )

    val allModels: List<String>
        get() = normalizeModelIds(cachedModels + manualModelIds)

    private val manualModelIds: List<String>
        get() = parseManualModelIds(modelId)

    val effectiveModelId: String
        get() = enabledModelIds.firstOrNull()
            ?: manualModelIds.firstOrNull()
            ?: allModels.firstOrNull().orEmpty()

    val isCurrentlyEnabled: Boolean
        get() = existingConfig?.isEnabled ?: true

    val isProviderIdManuallyEdited: Boolean
        get() = providerIdManuallyEdited

    val originalProviderId: String
        get() = existingConfig?.providerId.orEmpty()

    val currentAutoGeneratedProviderId: String
        get() = lastAutoGeneratedProviderId

    fun updateName(value: String) {
        name = value
        updateAutoGeneratedProviderId()
    }

    fun setProviderIdFromUser(value: String) {
        providerId = value
        providerIdManuallyEdited = value.isNotBlank() && value != lastAutoGeneratedProviderId
    }

    fun isValid(existingProviderIds: Set<String>): Boolean {
        val trimmedProviderId = providerId.trim()
        val providerIdAvailable = trimmedProviderId !in (existingProviderIds - setOf(existingConfig?.providerId.orEmpty()))
        return providerIdAvailable &&
            isValidProviderId(trimmedProviderId) &&
            buildConfig().let { config ->
                val definition = PiProviderCatalog.resolve(config.piProviderId)
                (!definition.requiresBaseUrl || config.baseUrl.isNotBlank()) &&
                    when (config.authMethod) {
                        ProviderAuthMethod.ApiKey ->
                            !definition.supportsApiKey ||
                                config.apiKey.isNotBlank() ||
                                !definition.isBuiltIn

                        ProviderAuthMethod.OAuth ->
                            definition.supportsOAuth && config.oauthCredentialJson.isNotBlank()

                        ProviderAuthMethod.Browser -> false

                        ProviderAuthMethod.Ambient -> definition.supportsAmbientAuth
                    }
            }
    }

    fun applyProviderDefaults(definition: PiProviderDefinition) {
        val previousDefinition = selectedDefinition
        piProviderId = definition.id
        serviceTier = ""
        compatibilityMode = false
        authMethodStorageValue = definition.defaultAuthMethod().storageValue
        oauthCredentialJson = ""
        if (
            baseUrl.isBlank() ||
            baseUrl.trim() == previousDefinition.defaultBaseUrl
        ) {
            baseUrl = definition.defaultBaseUrl
        }
        modelId = ""
        cachedModels = emptyList()
        enabledModelIds = emptyList()
        if (definition.defaultModelIds.isNotEmpty()) {
            cachedModels = definition.defaultModelIds
            enabledModelIds = listOf(definition.defaultModelId)
        }
        if (!providerIdManuallyEdited) {
            updateAutoGeneratedProviderId()
        } else if (providerId.isBlank() || providerId.trim() == previousDefinition.id) {
            providerId = definition.id.sanitizeProviderId()
        }
    }

    fun setAuthMethod(method: ProviderAuthMethod) {
        authMethodStorageValue = method.storageValue
    }

    fun ensureAvailableProviderId(existingProviderIds: Set<String>) {
        if (providerIdManuallyEdited || providerId.trim() !in existingProviderIds) return
        val baseId = selectedDefinition.id.sanitizeProviderId().ifBlank { "provider" }
        var suffix = 2
        var candidate = "${baseId}_$suffix"
        while (candidate in existingProviderIds) {
            suffix += 1
            candidate = "${baseId}_$suffix"
        }
        providerId = candidate
        lastAutoGeneratedProviderId = candidate
    }

    fun isAuthenticationConfigured(): Boolean {
        val config = buildConfig()
        val definition = PiProviderCatalog.resolve(config.piProviderId)
        if ((definition.requiresBaseUrl || !definition.isBuiltIn) && config.baseUrl.isBlank()) {
            return false
        }
        return when (config.authMethod) {
            ProviderAuthMethod.ApiKey ->
                !definition.supportsApiKey ||
                    config.apiKey.isNotBlank() ||
                    !definition.isBuiltIn

            ProviderAuthMethod.OAuth ->
                definition.supportsOAuth && config.oauthCredentialJson.isNotBlank()

            ProviderAuthMethod.Browser -> false

            ProviderAuthMethod.Ambient -> definition.supportsAmbientAuth
        }
    }

    private fun updateAutoGeneratedProviderId() {
        if (providerIdManuallyEdited) return
        val generatedProviderId = name.sanitizeProviderId()
            .ifBlank { selectedDefinition.id.sanitizeProviderId() }
        providerId = generatedProviderId
        lastAutoGeneratedProviderId = generatedProviderId
    }

    fun setModelEnabled(
        model: String,
        enabled: Boolean,
    ) {
        val normalizedModel = model.trim()
        enabledModelIds = if (enabled) {
            normalizeModelIds(enabledModelIds + normalizedModel)
        } else {
            enabledModelIds.filterNot { it == normalizedModel }
        }
    }

    fun setAllModelsEnabled(enabled: Boolean) {
        enabledModelIds = if (enabled) allModels else emptyList()
    }

    fun applyFetchedModels(models: List<String>) {
        if (models.none { it.trim().isNotEmpty() }) {
            return
        }
        val normalizedCurrent = allModels.toSet()
        val normalizedModels = models
            .map(String::trim)
            .filter(String::isNotEmpty)
            .distinct()
        cachedModels = normalizedModels
        val availableModels = normalizeModelIds(normalizedModels + manualModelIds)
        val newlyFetchedModels = normalizedModels.filter { model -> !normalizedCurrent.contains(model) }
        enabledModelIds = normalizeModelIds(enabledModelIds + newlyFetchedModels)
            .filter(availableModels::contains)
    }

    fun addCustomHeader() {
        customHeaders = customHeaders + LlmCustomHeader("", "")
    }

    fun addAdditionalApiKey() {
        additionalApiKeys = additionalApiKeys + ""
    }

    fun updateAdditionalApiKey(index: Int, value: String) {
        additionalApiKeys = additionalApiKeys.mapIndexed { keyIndex, key ->
            if (keyIndex == index) value else key
        }
    }

    fun removeAdditionalApiKey(index: Int) {
        additionalApiKeys = additionalApiKeys.filterIndexed { keyIndex, _ -> keyIndex != index }
    }

    fun updateMultiKeyEnabled(enabled: Boolean) {
        multiKeyEnabled = enabled
        if (enabled && additionalApiKeys.all { it.isBlank() } && apiKey.isNotBlank()) {
            additionalApiKeys = additionalApiKeys + ""
        }
    }

    fun updateKeyRotationStrategy(strategy: String) {
        keyRotationStrategy = if (strategy == com.arix.app.data.KeyRotationStrategyRoundRobin) {
            com.arix.app.data.KeyRotationStrategyRoundRobin
        } else {
            com.arix.app.data.KeyRotationStrategySequential
        }
    }

    fun updateKeyCooldownMinutes(minutes: Int) {
        keyCooldownMinutes = minutes.coerceIn(0, 120)
    }

    fun updateKeySwitchStatusCodesCsv(value: String) {
        keySwitchStatusCodesCsv = value.filter { it.isDigit() || it == ',' }
    }

    fun parsedKeySwitchStatusCodes(): List<Int> = keySwitchStatusCodesCsv
        .split(",")
        .mapNotNull { it.trim().toIntOrNull() }
        .filter { it in 100..599 }
        .distinct()

    fun poolKeyCount(): Int {
        val primary = apiKey.trim()
        val extras = additionalApiKeys.map(String::trim).count { it.isNotEmpty() && it != primary }
        return (if (primary.isNotEmpty()) 1 else 0) + extras
    }

    fun updateCustomHeader(
        index: Int,
        name: String = customHeaders.getOrNull(index)?.name.orEmpty(),
        value: String = customHeaders.getOrNull(index)?.value.orEmpty(),
    ) {
        customHeaders = customHeaders.mapIndexed { headerIndex, header ->
            if (headerIndex == index) {
                header.copy(name = name, value = value)
            } else {
                header
            }
        }
    }

    fun removeCustomHeader(index: Int) {
        customHeaders = customHeaders.filterIndexed { headerIndex, _ -> headerIndex != index }
    }

    fun addProviderEnvironmentVariable() {
        providerEnvironmentVariables = providerEnvironmentVariables +
            PiProviderEnvironmentVariable("", "")
    }

    fun updateProviderEnvironmentVariable(
        index: Int,
        name: String = providerEnvironmentVariables.getOrNull(index)?.name.orEmpty(),
        value: String = providerEnvironmentVariables.getOrNull(index)?.value.orEmpty(),
    ) {
        providerEnvironmentVariables = providerEnvironmentVariables.mapIndexed { variableIndex, variable ->
            if (variableIndex == index) {
                variable.copy(name = name, value = value)
            } else {
                variable
            }
        }
    }

    fun removeProviderEnvironmentVariable(index: Int) {
        providerEnvironmentVariables = providerEnvironmentVariables
            .filterIndexed { variableIndex, _ -> variableIndex != index }
    }

    fun buildConfig(): LlmProviderConfig = LlmProviderConfig(
        id = existingConfig?.id ?: platformRandomUuid(),
        providerId = providerId.trim().sanitizeProviderId(),
        name = name.trim().ifBlank { selectedDefinition.displayName },
        piProviderId = selectedDefinition.id,
        authMethod = authMethod,
        apiKey = apiKey.trim(),
        apiKeys = additionalApiKeys
            .map(String::trim)
            .filter { it.isNotEmpty() && it != apiKey.trim() },
        multiKeyEnabled = multiKeyEnabled,
        keyRotationStrategy = keyRotationStrategy,
        keyCooldownMinutes = keyCooldownMinutes.coerceIn(0, 120),
        keySwitchStatusCodes = parsedKeySwitchStatusCodes(),
        oauthCredentialJson = oauthCredentialJson,
        providerEnvironmentVariables = providerEnvironmentVariables
            .map { variable ->
                PiProviderEnvironmentVariable(variable.name.trim(), variable.value)
            }
            .filter { variable -> variable.name.isNotBlank() },
        baseUrl = baseUrl.trim(),
        modelId = effectiveModelId,
        manualModelIds = manualModelIds,
        userAgent = normalizeLlmUserAgent(userAgent),
        customHeaders = customHeaders
            .map { header -> LlmCustomHeader(header.name.trim(), header.value) }
            .filter { header ->
                header.name.isNotBlank() &&
                    !header.name.equals("User-Agent", ignoreCase = true)
            },
        developerRoleUnsupported = existingConfig?.developerRoleUnsupported ?: false,
        serviceTier = serviceTier.trim(),
        compatibilityMode = selectedDefinition.id == DefaultPiProviderId && compatibilityMode,
        cachedModels = normalizeModelIds(cachedModels),
        enabledModelIds = enabledModelIds
            .map(String::trim)
            .filter { it.isNotEmpty() && allModels.contains(it) }
            .distinct(),
        isEnabled = existingConfig?.isEnabled ?: true,
        createdAtMillis = existingConfig?.createdAtMillis ?: platformCurrentTimeMillis(),
    )

    companion object {
        fun fromConfig(existingConfig: LlmProviderConfig?): ProviderFormState {
            val initialDefinition = PiProviderCatalog.resolve(existingConfig?.piProviderId ?: "openai")
            val initialModelId = existingConfig?.modelId.orEmpty()
            val initialManualModels = existingConfig?.manualModelIds
                ?.takeIf { it.isNotEmpty() }
                ?: listOf(initialModelId).filter(String::isNotBlank)
            val initialModels = (existingConfig?.cachedModels.orEmpty() + initialManualModels)
                .map(String::trim)
                .filter(String::isNotEmpty)
                .distinct()
            val initialEnabledModels = if (existingConfig != null) {
                existingConfig.enabledModelIds
                    .map(String::trim)
                    .filter { it.isNotEmpty() && initialModels.contains(it) }
                    .distinct()
            } else {
                emptyList()
            }
            return ProviderFormState(
                existingConfig = existingConfig,
                providerId = existingConfig?.providerId ?: initialDefinition.id.sanitizeProviderId(),
                name = existingConfig?.name.orEmpty(),
                piProviderId = existingConfig?.piProviderId ?: initialDefinition.id,
                authMethodStorageValue = existingConfig?.authMethod?.storageValue
                    ?: initialDefinition.defaultAuthMethod().storageValue,
                apiKey = existingConfig?.apiKey.orEmpty(),
                additionalApiKeys = existingConfig?.apiKeys.orEmpty(),
                multiKeyEnabled = existingConfig?.multiKeyEnabled
                    ?: (existingConfig?.apiKeys?.any { it.isNotBlank() } == true),
                keyRotationStrategy = existingConfig?.keyRotationStrategy
                    ?: com.arix.app.data.KeyRotationStrategySequential,
                keyCooldownMinutes = existingConfig?.keyCooldownMinutes
                    ?: com.arix.app.data.DefaultKeyCooldownMinutes,
                keySwitchStatusCodesCsv = existingConfig?.keySwitchStatusCodes
                    ?.joinToString(",")
                    .orEmpty(),
                oauthCredentialJson = existingConfig?.oauthCredentialJson.orEmpty(),
                providerEnvironmentVariables = existingConfig?.providerEnvironmentVariables.orEmpty(),
                baseUrl = existingConfig?.baseUrl ?: initialDefinition.defaultBaseUrl,
                modelId = initialManualModels.joinToString("\n"),
                userAgent = normalizeLlmUserAgent(existingConfig?.userAgent),
                customHeaders = existingConfig?.customHeaders.orEmpty(),
                serviceTier = existingConfig?.serviceTier.orEmpty(),
                compatibilityMode = existingConfig?.compatibilityMode ?: false,
                cachedModels = existingConfig?.cachedModels.orEmpty(),
                enabledModelIds = initialEnabledModels,
            )
        }
    }
}

@Composable
fun rememberProviderFormState(
    existingConfig: LlmProviderConfig?,
): ProviderFormState = key(existingConfig?.id) {
    rememberSaveable(
        saver = providerFormStateSaver(existingConfig),
    ) {
        ProviderFormState.fromConfig(existingConfig)
    }
}

@Composable
fun ProviderConfigurationForm(
    state: ProviderFormState,
    existingProviderIds: Set<String>,
    isFetchingModels: Boolean,
    onFetchModels: (LlmProviderConfig, (List<String>) -> Unit) -> Unit,
    onManageKeys: () -> Unit = {},
    onModelEnabledChange: (LlmProviderConfig) -> Unit = {},
    authState: PiProviderAuthState = PiProviderAuthState(),
    onStartProviderLogin: (String, String, ProviderAuthMethod, String) -> Unit = { _, _, _, _ -> },
    onSubmitAuthPrompt: (String, String, Boolean) -> Unit = { _, _, _ -> },
    onClearAuthState: () -> Unit = {},
    modifier: Modifier = Modifier,
    cardColor: Color = ArixSurface,
) {
    val selectedDefinition = state.selectedDefinition
    val relevantAuthState = authState.takeIf {
        it.providerId == selectedDefinition.id && it.authMethod == state.authMethod
    }
    ProviderAuthStateEffects(state, relevantAuthState, onSubmitAuthPrompt)
    val providerIdAlreadyUsed = state.providerId.trim() in
        (existingProviderIds - setOf(state.originalProviderId))
    val providerIdError = when {
        state.providerId.isBlank() -> stringResource(Res.string.provider_form_provider_id_required)
        !isValidProviderId(state.providerId.trim()) -> stringResource(Res.string.provider_form_provider_id_invalid)
        providerIdAlreadyUsed -> stringResource(Res.string.provider_form_provider_id_in_use)
        else -> ""
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        ProviderFormCard(cardColor = cardColor) {
            ProviderFormTextField(
                label = stringResource(Res.string.provider_form_provider_name),
                value = state.name,
                onValueChange = state::updateName,
            )
            ProviderFormDivider()
            ProviderFormTextField(
                label = stringResource(Res.string.provider_form_provider_id),
                value = state.providerId,
                onValueChange = state::setProviderIdFromUser,
            )
        }

        if (providerIdError.isNotBlank()) {
            Text(
                text = providerIdError,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(horizontal = 4.dp),
            )
        }

        ProviderFormCard(cardColor = cardColor) {
            ProviderFormDropdownField(
                label = stringResource(Res.string.provider_form_provider),
                selectedValue = selectedDefinition.displayName,
                options = PiProviderCatalog.providers,
                onSelected = state::applyProviderDefaults,
            )
        }

        if (selectedDefinition.id == DefaultPiProviderId) {
            ProviderFormCard(cardColor = cardColor) {
                ProviderCompatibilityModeField(
                    enabled = state.compatibilityMode,
                    onEnabledChange = { state.compatibilityMode = it },
                )
            }
        }

        Text(
            text = if (selectedDefinition.isBuiltIn) {
                stringResource(Res.string.provider_form_pi_builtin_description)
            } else {
                stringResource(Res.string.provider_form_pi_custom_description)
            },
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp),
        )

        ProviderFormCard(cardColor = cardColor) {
            ProviderAuthMethodField(
                definition = selectedDefinition,
                selectedMethod = state.authMethod,
                onSelected = state::setAuthMethod,
            )
        }

        when (state.authMethod) {
            ProviderAuthMethod.ApiKey -> ProviderFormCard(cardColor = cardColor) {
                if (!state.multiKeyEnabled) {
                    ProviderFormTextField(
                        label = stringResource(Res.string.provider_form_api_key),
                        value = state.apiKey,
                        onValueChange = { state.apiKey = it },
                        isSecret = true,
                    )
                }
                ProviderAdditionalApiKeysFields(state = state, onManageKeys = onManageKeys)
            }

            ProviderAuthMethod.OAuth -> if (selectedDefinition.supportsOAuth) {
                ProviderOAuthSignInField(
                    definition = selectedDefinition,
                    configured = state.oauthCredentialJson.isNotBlank(),
                    authState = relevantAuthState,
                    onStartLogin = {
                        onClearAuthState()
                        onStartProviderLogin(
                            state.buildConfig().id,
                            selectedDefinition.id,
                            ProviderAuthMethod.OAuth,
                            "",
                        )
                    },
                    onDisconnect = {
                        state.oauthCredentialJson = ""
                        onClearAuthState()
                    },
                    cardColor = cardColor,
                )
            } else {
                ProviderFormCard(cardColor = cardColor) {
                    Text(
                        text = "Subscription sign-in authentication was removed in this version. " +
                            "Switch the authentication method to an API key to keep using this provider.",
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 4.dp),
                    )
                }
            }

            ProviderAuthMethod.Browser -> ProviderFormCard(cardColor = cardColor) {
                Text(
                    text = "The Gemini Web (free & unlimited) provider was removed in this " +
                        "version. Switch the authentication method to an API key — the API-key " +
                        "Google Gemini provider offers the same Gemini models.",
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 4.dp),
                )
            }

            ProviderAuthMethod.Ambient -> ProviderFormCard(cardColor = cardColor) {
                Text(
                    text = "Environment-credentials (ambient) authentication was removed in this version. " +
                        "Switch the authentication method to an API key " +
                        "to keep using this provider.",
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 4.dp),
                )
            }
        }

        ProviderFormCard(cardColor = cardColor) {
            ProviderBaseUrlField(
                state = state,
                definition = selectedDefinition,
            )
            ProviderFormDivider()
            ProviderFormTextField(
                label = stringResource(Res.string.provider_form_manual_model_ids),
                value = state.modelId,
                onValueChange = { state.modelId = it },
            )
            ProviderFormDivider()
            ProviderModelListField(
                models = state.allModels,
                enabledModelIds = state.enabledModelIds,
                isFetchingModels = state.isFetchingModelsLocally || isFetchingModels,
                onToggleModel = { model, enabled ->
                    state.setModelEnabled(model, enabled)
                    onModelEnabledChange(state.buildConfig())
                },
                onSetAllModelsEnabled = { enabled ->
                    state.setAllModelsEnabled(enabled)
                    onModelEnabledChange(state.buildConfig())
                },
                onFetchModels = {
                    state.isFetchingModelsLocally = true
                    onFetchModels(state.buildConfig()) { models ->
                        state.applyFetchedModels(models)
                        state.isFetchingModelsLocally = false
                    }
                },
            )
            ProviderFormDivider()
            ProviderFormTextField(
                label = stringResource(Res.string.provider_form_user_agent),
                value = state.userAgent,
                onValueChange = { state.userAgent = it },
            )
            ProviderFormDivider()
            ProviderFormTextField(
                label = stringResource(Res.string.provider_form_service_tier),
                value = state.serviceTier,
                onValueChange = { state.serviceTier = it },
            )
            ProviderFormDivider()
            ProviderCustomHeadersField(
                headers = state.customHeaders,
                onAddHeader = state::addCustomHeader,
                onUpdateHeader = state::updateCustomHeader,
                onRemoveHeader = state::removeCustomHeader,
            )
        }

        Text(
            text = if (
                state.authMethod == ProviderAuthMethod.ApiKey &&
                selectedDefinition.supportsApiKey
            ) {
                stringResource(Res.string.provider_form_model_picker_api_key_hint)
            } else {
                stringResource(Res.string.provider_form_model_picker_refresh_hint)
            },
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
    }
    ProviderAuthPromptDialog(
        prompt = relevantAuthState?.prompt,
        onSubmitPrompt = onSubmitAuthPrompt,
    )
}

@Composable
private fun ProviderAuthStateEffects(
    state: ProviderFormState,
    authState: PiProviderAuthState?,
    onSubmitAuthPrompt: (String, String, Boolean) -> Unit,
) {
    val uriHandler = LocalUriHandler.current
    val platformServices = LocalPlatformServices.current
    var authenticationCallback by remember { mutableStateOf("") }
    LaunchedEffect(authState?.authorizationUrl) {
        authState?.authorizationUrl
            ?.takeIf(String::isNotBlank)
            ?.let { url ->
                runCatching {
                    if (platformServices?.openAuthenticationUrl(
                            url = url,
                            onCallback = { authenticationCallback = it },
                            onCancelled = {
                                authState.prompt?.id?.takeIf(String::isNotBlank)?.let { promptId ->
                                    onSubmitAuthPrompt(promptId, "", true)
                                }
                            },
                        ) != true
                    ) {
                        uriHandler.openUri(url)
                    }
                }
            }
    }
    LaunchedEffect(authenticationCallback, authState?.prompt?.id) {
        val callback = authenticationCallback.takeIf(String::isNotBlank) ?: return@LaunchedEffect
        val prompt = authState?.prompt?.takeIf { it.type == "manual_code" } ?: return@LaunchedEffect
        authenticationCallback = ""
        onSubmitAuthPrompt(prompt.id, callback, false)
    }
    LaunchedEffect(authState?.verificationUrl) {
        authState?.verificationUrl
            ?.takeIf(String::isNotBlank)
            ?.let { url -> runCatching { uriHandler.openUri(url) } }
    }
    LaunchedEffect(
        authState?.authMethod,
        authState?.oauthCredentialJson,
        authState?.apiKey,
        authState?.providerEnvironmentVariables,
    ) {
        authState?.let { applyProviderAuthResult(state, it) }
    }
}

fun applyProviderAuthResult(
    state: ProviderFormState,
    authState: PiProviderAuthState,
) {
    when (authState.authMethod) {
        ProviderAuthMethod.OAuth -> authState.oauthCredentialJson
            .takeIf(String::isNotBlank)
            ?.let { credential ->
                state.oauthCredentialJson = credential
                state.setAuthMethod(ProviderAuthMethod.OAuth)
            }

        ProviderAuthMethod.ApiKey -> {
            authState.apiKey.takeIf(String::isNotBlank)?.let { state.apiKey = it }
            if (authState.providerEnvironmentVariables.isNotEmpty()) {
                state.providerEnvironmentVariables = authState.providerEnvironmentVariables
            }
        }

        ProviderAuthMethod.Browser -> Unit

        ProviderAuthMethod.Ambient -> Unit
    }
}

@Composable
fun ProviderAuthenticationSetup(
    state: ProviderFormState,
    authState: PiProviderAuthState,
    onStartProviderLogin: (String, String, ProviderAuthMethod, String) -> Unit,
    onSubmitAuthPrompt: (String, String, Boolean) -> Unit,
    onClearAuthState: () -> Unit,
    onManageKeys: () -> Unit = {},
    cardColor: Color = ArixSurface,
    modifier: Modifier = Modifier,
) {
    val definition = state.selectedDefinition
    val relevantAuthState = authState.takeIf {
        it.providerId == definition.id && it.authMethod == state.authMethod
    }
    ProviderAuthStateEffects(state, relevantAuthState, onSubmitAuthPrompt)

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(
            text = stringResource(
                Res.string.provider_add_configure_provider,
                definition.displayName,
            ),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            color = ArixOnSurface,
        )
        Text(
            text = when (state.authMethod) {
                ProviderAuthMethod.ApiKey ->
                    if (definition.id in KeylessFreeTierProviderIds) {
                        "${definition.displayName} is FREE and needs no key, no account and no " +
                            "sign-up — leave the key empty and just continue. Requests use the " +
                            "gateway's anonymous free tier (rate-limited per network). Paste a " +
                            "personal API key only if you want higher limits or paid models."
                    } else {
                        stringResource(Res.string.provider_add_api_key_guidance)
                    }
                ProviderAuthMethod.OAuth -> if (definition.supportsOAuth) {
                    "Sign in with your Google account — no API key. Works with every Google " +
                        "account; Google AI Pro / AI Ultra subscribers get their higher limits " +
                        "and flagship models."
                } else {
                    "Subscription sign-in authentication was removed in this version."
                }
                ProviderAuthMethod.Browser ->
                    "The Gemini Web (free & unlimited) provider was removed in this version. " +
                        "Switch the authentication method to an API key — the API-key " +
                        "Google Gemini provider offers the same Gemini models."
                ProviderAuthMethod.Ambient ->
                    "Environment-credentials authentication was removed in this version."
            },
            style = MaterialTheme.typography.bodyMedium,
            color = ArixOnSurfaceVariant,
        )

        when (state.authMethod) {
            ProviderAuthMethod.ApiKey -> {
                if (definition.id in InteractiveCredentialProviderIds) {
                    ProviderApiKeyLoginField(
                        definition = definition,
                        configured = state.apiKey.isNotBlank(),
                        authState = relevantAuthState,
                        onStartLogin = {
                            onClearAuthState()
                            onStartProviderLogin(state.buildConfig().id, definition.id, ProviderAuthMethod.ApiKey, "")
                        },
                        onDisconnect = {
                            state.apiKey = ""
                            state.providerEnvironmentVariables = emptyList()
                            onClearAuthState()
                        },
                        cardColor = cardColor,
                    )
                } else {
                    ProviderFormCard(cardColor = cardColor) {
                        ProviderFormTextField(
                            label = if (definition.id in KeylessFreeTierProviderIds) {
                                stringResource(
                                    Res.string.provider_add_provider_api_key,
                                    definition.displayName,
                                ) + " (optional)"
                            } else {
                                stringResource(
                                    Res.string.provider_add_provider_api_key,
                                    definition.displayName,
                                )
                            },
                            value = state.apiKey,
                            onValueChange = { state.apiKey = it },
                            isSecret = true,
                        )
                        ProviderAdditionalApiKeysFields(state = state, onManageKeys = onManageKeys)
                        if (definition.supportsCustomBaseUrl) {
                            ProviderFormDivider()
                            ProviderBaseUrlField(
                                state = state,
                                definition = definition,
                                resetToDefaultWhenBlank = true,
                            )
                        }
                    }
                }
            }

            ProviderAuthMethod.OAuth -> if (definition.supportsOAuth) {
                ProviderOAuthSignInField(
                    definition = definition,
                    configured = state.oauthCredentialJson.isNotBlank(),
                    authState = relevantAuthState,
                    onStartLogin = {
                        onClearAuthState()
                        onStartProviderLogin(
                            state.buildConfig().id,
                            definition.id,
                            ProviderAuthMethod.OAuth,
                            "",
                        )
                    },
                    onDisconnect = {
                        state.oauthCredentialJson = ""
                        onClearAuthState()
                    },
                    cardColor = cardColor,
                )
            } else {
                ProviderFormCard(cardColor = cardColor) {
                    Text(
                        text = "Subscription sign-in authentication was removed in this version. " +
                            "Switch the authentication method to an API key to keep using this provider.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = ArixOnSurfaceVariant,
                    )
                }
            }

            ProviderAuthMethod.Browser -> ProviderFormCard(cardColor = cardColor) {
                Text(
                    text = "The Gemini Web (free & unlimited) provider was removed in this " +
                        "version. Switch the authentication method to an API key — the " +
                        "API-key Google Gemini provider offers the same Gemini models.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = ArixOnSurfaceVariant,
                )
            }

            ProviderAuthMethod.Ambient -> ProviderFormCard(cardColor = cardColor) {
                Text(
                    text = "Environment-credentials (ambient) authentication was removed in this version. " +
                        "Switch the authentication method to an API key " +
                        "to keep using this provider.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = ArixOnSurfaceVariant,
                )
            }
        }

        if (
            definition.requiresBaseUrl || (!definition.isBuiltIn && !definition.supportsCustomBaseUrl)
        ) {
            ProviderFormCard(cardColor = cardColor) {
                ProviderBaseUrlField(
                    state = state,
                    definition = definition,
                )
            }
        }

        if (definition.id == DefaultPiProviderId) {
            ProviderFormCard(cardColor = cardColor) {
                ProviderCompatibilityModeField(
                    enabled = state.compatibilityMode,
                    onEnabledChange = { state.compatibilityMode = it },
                )
            }
        }
    }

    ProviderAuthPromptDialog(
        prompt = relevantAuthState?.prompt,
        onSubmitPrompt = onSubmitAuthPrompt,
    )
}

@Composable
private fun ProviderApiKeyLoginField(
    definition: PiProviderDefinition,
    configured: Boolean,
    authState: PiProviderAuthState?,
    onStartLogin: () -> Unit,
    onDisconnect: () -> Unit,
    cardColor: Color,
) {
    ProviderFormCard(cardColor = cardColor) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(
                text = stringResource(
                    Res.string.provider_add_provider_api_key,
                    definition.displayName,
                ),
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
            )
            Text(
                text = when {
                    authState?.errorMessage?.isNotBlank() == true -> authState.errorMessage
                    authState?.statusMessage?.isNotBlank() == true -> authState.statusMessage
                    configured -> stringResource(Res.string.provider_add_api_key_configured)
                    else -> stringResource(Res.string.provider_add_api_key_not_configured)
                },
                style = MaterialTheme.typography.bodyMedium,
                color = if (authState?.errorMessage?.isNotBlank() == true) {
                    MaterialTheme.colorScheme.error
                } else {
                    ArixOnSurface
                },
            )
            ProviderActionRow(
                icon = Icons.Rounded.Key,
                label = when {
                    authState?.isRunning == true -> stringResource(Res.string.provider_add_waiting_for_input)
                    configured -> stringResource(Res.string.provider_add_reconfigure_api_key)
                    else -> stringResource(Res.string.provider_add_configure_credentials)
                },
                onClick = onStartLogin,
                enabled = authState?.isRunning != true,
            )
            if (configured) {
                ProviderActionRow(
                    icon = Icons.Rounded.Delete,
                    label = stringResource(Res.string.provider_add_remove_api_key),
                    onClick = onDisconnect,
                    enabled = true,
                    trailingIcon = null,
                )
            }
        }
    }
}

@Composable
private fun ProviderOAuthSignInField(
    definition: PiProviderDefinition,
    configured: Boolean,
    authState: PiProviderAuthState?,
    onStartLogin: () -> Unit,
    onDisconnect: () -> Unit,
    cardColor: Color,
) {
    ProviderFormCard(cardColor = cardColor) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(
                text = "Sign in with Google — ${definition.displayName}",
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
            )
            Text(
                text = when {
                    authState?.errorMessage?.isNotBlank() == true -> authState.errorMessage
                    authState?.statusMessage?.isNotBlank() == true -> authState.statusMessage
                    configured -> "Signed in with your Google account."
                    else -> "Not signed in — no API key needed."
                },
                style = MaterialTheme.typography.bodyMedium,
                color = if (authState?.errorMessage?.isNotBlank() == true) {
                    MaterialTheme.colorScheme.error
                } else {
                    ArixOnSurface
                },
            )
            ProviderActionRow(
                icon = Icons.Rounded.Login,
                label = when {
                    authState?.isRunning == true -> stringResource(Res.string.provider_add_waiting_for_input)
                    configured -> "Sign in with a different account"
                    else -> "Sign in with Google"
                },
                onClick = onStartLogin,
                enabled = authState?.isRunning != true,
            )
            if (configured) {
                ProviderActionRow(
                    icon = Icons.Rounded.Delete,
                    label = "Sign out",
                    onClick = onDisconnect,
                    enabled = true,
                    trailingIcon = null,
                )
            }
        }
    }
}

@Composable
private fun ProviderAuthPromptDialog(
    prompt: PiOAuthPrompt?,
    onSubmitPrompt: (String, String, Boolean) -> Unit,
) {
    if (prompt == null) return
    var promptValue by rememberSaveable(prompt.id) { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = {
            onSubmitPrompt(prompt.id, "", true)
        },
        containerColor = ArixSurface,
        title = {
            Text(
                text = stringResource(Res.string.provider_form_oauth_prompt_title),
                color = ArixOnSurface,
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (prompt.type != "manual_code") {
                    Text(prompt.message, color = ArixOnSurface)
                }
                if (prompt.options.isNotEmpty()) {
                    prompt.options.forEach { option ->
                        ProviderModelListActionButton(
                            label = option.label,
                            onClick = { onSubmitPrompt(prompt.id, option.id, false) },
                            enabled = true,
                        )
                        option.description.takeIf(String::isNotBlank)?.let { description ->
                            Text(
                                text = description,
                                style = MaterialTheme.typography.bodySmall,
                                color = ArixOnSurfaceVariant,
                            )
                        }
                    }
                } else {
                    ProviderFormTextField(
                        label = prompt.placeholder.ifBlank {
                            stringResource(Res.string.provider_form_oauth_prompt_value)
                        },
                        value = promptValue,
                        onValueChange = { promptValue = it },
                        isSecret = prompt.type == "secret",
                        showLabel = prompt.type != "manual_code",
                    )
                }
            }
        },
        confirmButton = {
            if (prompt.options.isEmpty()) {
                TextButton(
                    onClick = { onSubmitPrompt(prompt.id, promptValue, false) },
                ) {
                    Text(stringResource(Res.string.common_continue))
                }
            }
        },
        dismissButton = {
            TextButton(
                onClick = { onSubmitPrompt(prompt.id, "", true) },
            ) {
                Text(stringResource(Res.string.common_cancel))
            }
        },
    )
}

private enum class AddProviderStage {
    Provider,
    Credentials,
    Models,
}

@Composable
fun AddProviderWizard(
    state: ProviderFormState,
    existingProviderIds: Set<String>,
    isFetchingModels: Boolean,
    onFetchModels: (LlmProviderConfig, (List<String>) -> Unit) -> Unit,
    authState: PiProviderAuthState,
    onStartProviderLogin: (String, String, ProviderAuthMethod, String) -> Unit,
    onSubmitAuthPrompt: (String, String, Boolean) -> Unit,
    onClearAuthState: () -> Unit,
    onManageKeys: () -> Unit = {},
    onSave: (LlmProviderConfig) -> Unit,
    modifier: Modifier = Modifier,
    saveLabel: String = stringResource(Res.string.common_save),
    onStageChanged: (Int) -> Unit = {},
) {
    var stageName by rememberSaveable { mutableStateOf(AddProviderStage.Provider.name) }
    var providerSearch by rememberSaveable { mutableStateOf("") }
    var showAdvanced by rememberSaveable { mutableStateOf(false) }
    val stage = AddProviderStage.valueOf(stageName)
    val matchingProviders = remember(providerSearch) {
        val query = providerSearch.trim().lowercase()
        PiProviderCatalog.providers.filter { provider ->
            (provider.supportsInteractiveApiKey || provider.supportsOAuth) && (
                query.isBlank() ||
                    provider.displayName.lowercase().contains(query) ||
                    provider.id.lowercase().contains(query) ||
                    provider.category.lowercase().contains(query)
                )
        }
    }
    val isLoadingModels = state.isFetchingModelsLocally || isFetchingModels

    LaunchedEffect(stage) {
        onStageChanged(stage.ordinal)
    }

    Column(
        modifier = modifier.fillMaxWidth(),
    ) {
        AnimatedContent(
            targetState = stage,
            transitionSpec = {
                val movingForward = targetState.ordinal > initialState.ordinal
                val enter = slideInHorizontally(
                    animationSpec = tween(340, easing = ProviderWizardEasing),
                    initialOffsetX = { width -> if (movingForward) width / 2 else -width / 2 },
                ) + fadeIn(
                    animationSpec = tween(
                        durationMillis = 220,
                        delayMillis = 80,
                        easing = ProviderWizardEasing,
                    ),
                )
                val exit = slideOutHorizontally(
                    animationSpec = tween(260, easing = ProviderWizardEasing),
                    targetOffsetX = { width -> if (movingForward) -width / 2 else width / 2 },
                ) + fadeOut(animationSpec = tween(110, easing = ProviderWizardEasing))
                enter togetherWith exit
            },
            label = "add_provider_stage",
        ) { animatedStage ->
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(18.dp),
            ) {
                Column {
                    Text(
                        text = stringResource(
                            Res.string.provider_add_step,
                            animatedStage.ordinal + 1,
                            AddProviderStage.entries.size,
                        ),
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = when (animatedStage) {
                            AddProviderStage.Provider ->
                                stringResource(Res.string.provider_add_choose_provider_title)
                            AddProviderStage.Credentials ->
                                stringResource(Res.string.provider_add_credentials_title)
                            AddProviderStage.Models ->
                                stringResource(Res.string.provider_add_models_title)
                        },
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = ArixOnSurface,
                    )
                }
                when (animatedStage) {
            AddProviderStage.Provider -> {
                Text(
                    text = stringResource(Res.string.provider_add_choose_auth_provider_description),
                    style = MaterialTheme.typography.bodyMedium,
                    color = ArixOnSurfaceVariant,
                )
                SharedProviderPickerContent(
                    providerSearch = providerSearch,
                    onProviderSearchChange = { providerSearch = it },
                    providerChoices = matchingProviders,
                    onProviderSelected = { provider ->
                        onClearAuthState()
                        state.applyProviderDefaults(provider)
                        state.ensureAvailableProviderId(existingProviderIds)
                        stageName = AddProviderStage.Credentials.name
                    },
                )
            }

            AddProviderStage.Credentials -> {
                ProviderAuthenticationSetup(
                    state = state,
                    authState = authState,
                    onStartProviderLogin = onStartProviderLogin,
                    onSubmitAuthPrompt = onSubmitAuthPrompt,
                    onClearAuthState = onClearAuthState,
                    onManageKeys = onManageKeys,
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    ProviderWizardSecondaryButton(
                        label = stringResource(Res.string.common_back),
                        onClick = {
                            onClearAuthState()
                            stageName = AddProviderStage.Provider.name
                        },
                        modifier = Modifier.weight(1f),
                    )
                    ProviderWizardPrimaryButton(
                        label = if (isLoadingModels) {
                            stringResource(Res.string.onboarding_loading_models)
                        } else {
                            stringResource(Res.string.common_continue)
                        },
                        enabled = state.isAuthenticationConfigured() && !isLoadingModels,
                        isLoading = isLoadingModels,
                        onClick = {
                            state.isFetchingModelsLocally = true
                            onFetchModels(state.buildConfig()) { models ->
                                state.applyFetchedModels(models)
                                state.isFetchingModelsLocally = false
                                stageName = AddProviderStage.Models.name
                            }
                        },
                        modifier = Modifier.weight(1f),
                    )
                }
            }

            AddProviderStage.Models -> {
                Text(
                    text = stringResource(
                        Res.string.provider_add_models_description,
                        state.selectedDefinition.displayName,
                    ),
                    style = MaterialTheme.typography.bodyMedium,
                    color = ArixOnSurfaceVariant,
                )
                ProviderFormCard(cardColor = ArixSurface) {
                    ProviderFormTextField(
                        label = stringResource(Res.string.provider_form_manual_model_ids),
                        value = state.modelId,
                        onValueChange = { state.modelId = it },
                    )
                    ProviderFormDivider()
                    ProviderModelListField(
                        models = state.allModels,
                        enabledModelIds = state.enabledModelIds,
                        isFetchingModels = isLoadingModels,
                        onToggleModel = state::setModelEnabled,
                        onSetAllModelsEnabled = state::setAllModelsEnabled,
                        onFetchModels = {
                            state.isFetchingModelsLocally = true
                            onFetchModels(state.buildConfig()) { models ->
                                state.applyFetchedModels(models)
                                state.isFetchingModelsLocally = false
                            }
                        },
                    )
                }
                ProviderWizardSecondaryButton(
                    label = if (showAdvanced) {
                        stringResource(Res.string.provider_add_hide_advanced)
                    } else {
                        stringResource(Res.string.provider_add_show_advanced)
                    },
                    onClick = { showAdvanced = !showAdvanced },
                )
                if (showAdvanced) {
                    ProviderFormCard(cardColor = ArixSurface) {
                        ProviderFormTextField(
                            label = stringResource(Res.string.provider_form_provider_name),
                            value = state.name,
                            onValueChange = state::updateName,
                        )
                        ProviderFormDivider()
                        ProviderFormTextField(
                            label = stringResource(Res.string.provider_form_provider_id),
                            value = state.providerId,
                            onValueChange = state::setProviderIdFromUser,
                        )
                        if (
                            !state.selectedDefinition.requiresBaseUrl &&
                            state.selectedDefinition.isBuiltIn
                        ) {
                            ProviderFormDivider()
                            ProviderBaseUrlField(
                                state = state,
                                definition = state.selectedDefinition,
                            )
                        }
                        ProviderFormDivider()
                        ProviderFormTextField(
                            label = stringResource(Res.string.provider_form_user_agent),
                            value = state.userAgent,
                            onValueChange = { state.userAgent = it },
                        )
                        ProviderFormDivider()
                        ProviderFormTextField(
                            label = stringResource(Res.string.provider_form_service_tier),
                            value = state.serviceTier,
                            onValueChange = { state.serviceTier = it },
                        )
                        ProviderFormDivider()
                        ProviderCustomHeadersField(
                            headers = state.customHeaders,
                            onAddHeader = state::addCustomHeader,
                            onUpdateHeader = state::updateCustomHeader,
                            onRemoveHeader = state::removeCustomHeader,
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    ProviderWizardSecondaryButton(
                        label = stringResource(Res.string.common_back),
                        onClick = { stageName = AddProviderStage.Credentials.name },
                        modifier = Modifier.weight(1f),
                    )
                    ProviderWizardPrimaryButton(
                        label = saveLabel,
                        enabled = state.isValid(existingProviderIds),
                        onClick = { onSave(state.buildConfig()) },
                        modifier = Modifier.weight(1f),
                    )
                }
            }
                }
            }
        }
    }
}
@Composable
private fun ProviderWizardPrimaryButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    isLoading: Boolean = false,
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(48.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(
                if (enabled) ArixPrimary else ArixSurfaceHigh.copy(alpha = 0.65f)
            )
            .clickable(enabled = enabled && !isLoading, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        if (isLoading) {
            CircularProgressIndicator(
                modifier = Modifier.size(20.dp),
                strokeWidth = 2.dp,
                color = ArixOnPrimary,
            )
        } else {
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                color = if (enabled) ArixOnPrimary else ArixOnSurfaceVariant.copy(alpha = 0.6f),
            )
        }
    }
}

@Composable
private fun ProviderWizardSecondaryButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(48.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(ArixSurface)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            color = ArixOnSurface,
        )
    }
}

private fun providerFormStateSaver(
    existingConfig: LlmProviderConfig?,
): Saver<ProviderFormState, Any> = listSaver(
    save = { state ->
        listOf(
            state.providerId,
            state.name,
            state.piProviderId,
            state.authMethodStorageValue,
            state.providerEnvironmentVariables.map { listOf(it.name, it.value) },
            state.baseUrl,
            state.modelId,
            state.userAgent,
            state.customHeaders.map { listOf(it.name, it.value) },
            state.cachedModels,
            state.enabledModelIds,
            state.isProviderIdManuallyEdited,
            state.currentAutoGeneratedProviderId,
            state.compatibilityMode,
            state.additionalApiKeys,
            state.multiKeyEnabled,
            state.keyRotationStrategy,
            state.keyCooldownMinutes,
            state.keySwitchStatusCodesCsv,
            state.serviceTier,
        )
    },
    restore = { restored ->
        val hasUserAgent = restored.getOrNull(7) is String
        val customHeadersIndex = if (hasUserAgent) 8 else 7
        val cachedModelsIndex = if (hasUserAgent) 9 else 8
        val enabledModelIdsIndex = if (hasUserAgent) 10 else 9
        val manuallyEditedIndex = if (hasUserAgent) 11 else 10
        val autoProviderIdIndex = if (hasUserAgent) 12 else 11
        val compatibilityIndex = if (hasUserAgent) 13 else 12
        val additionalApiKeysIndex = if (hasUserAgent) 14 else 13
        val multiKeyEnabledIndex = if (hasUserAgent) 15 else 14
        val keyRotationStrategyIndex = if (hasUserAgent) 16 else 15
        val keyCooldownMinutesIndex = if (hasUserAgent) 17 else 16
        val keySwitchStatusCodesIndex = if (hasUserAgent) 18 else 17
        val restoredProviderId = restored.getOrNull(0) as? String ?: ""
        val restoredEnvironmentVariables =
            (restored.getOrNull(4) as? List<*> ?: emptyList<Any>()).mapNotNull { item ->
                val values = item as? List<*> ?: return@mapNotNull null
                PiProviderEnvironmentVariable(
                    name = values.getOrNull(0) as? String ?: "",
                    value = values.getOrNull(1) as? String ?: "",
                )
            }
        val restoredCustomHeaders = (restored.getOrNull(customHeadersIndex) as? List<*> ?: emptyList<Any>())
                .mapNotNull { item ->
                    val values = item as? List<*> ?: return@mapNotNull null
                    LlmCustomHeader(
                        name = values.getOrNull(0) as? String ?: "",
                        value = values.getOrNull(1) as? String ?: "",
                    )
                }
        ProviderFormState(
            existingConfig = existingConfig,
            providerId = restoredProviderId,
            name = restored.getOrNull(1) as? String ?: "",
            piProviderId = restored.getOrNull(2) as? String ?: "",
            authMethodStorageValue = restored.getOrNull(3) as? String ?: "",
            apiKey = existingConfig?.apiKey.orEmpty(),
            additionalApiKeys = (restored.getOrNull(additionalApiKeysIndex) as? List<*>)
                ?.filterIsInstance<String>()
                ?: existingConfig?.apiKeys.orEmpty(),
            multiKeyEnabled = (restored.getOrNull(multiKeyEnabledIndex) as? Boolean)
                ?: existingConfig?.multiKeyEnabled
                ?: (existingConfig?.apiKeys?.any { it.isNotBlank() } == true),
            keyRotationStrategy = (restored.getOrNull(keyRotationStrategyIndex) as? String)
                ?.takeIf(String::isNotBlank)
                ?: existingConfig?.keyRotationStrategy
                ?: com.arix.app.data.KeyRotationStrategySequential,
            keyCooldownMinutes = (restored.getOrNull(keyCooldownMinutesIndex) as? Int)
                ?: existingConfig?.keyCooldownMinutes
                ?: com.arix.app.data.DefaultKeyCooldownMinutes,
            keySwitchStatusCodesCsv = (restored.getOrNull(keySwitchStatusCodesIndex) as? String)
                ?: existingConfig?.keySwitchStatusCodes?.joinToString(",").orEmpty(),
            oauthCredentialJson = existingConfig?.oauthCredentialJson.orEmpty(),
            providerEnvironmentVariables = restoredEnvironmentVariables,
            baseUrl = restored.getOrNull(5) as? String ?: "",
            modelId = restored.getOrNull(6) as? String ?: "",
            userAgent = if (hasUserAgent) {
                restored.getOrNull(7) as? String ?: ""
            } else {
                normalizeLlmUserAgent(existingConfig?.userAgent)
            },
            customHeaders = restoredCustomHeaders,
            cachedModels = (restored.getOrNull(cachedModelsIndex) as? List<*>)
                ?.filterIsInstance<String>()
                ?: emptyList(),
            enabledModelIds = (restored.getOrNull(enabledModelIdsIndex) as? List<*>)
                ?.filterIsInstance<String>()
                ?: emptyList(),
            providerIdManuallyEdited = restored.getOrNull(manuallyEditedIndex) as? Boolean
                ?: (existingConfig != null),
            lastAutoGeneratedProviderId = restored.getOrNull(autoProviderIdIndex) as? String
                ?: restoredProviderId,
            serviceTier = if (hasUserAgent) {
                restored.getOrNull(19) as? String ?: existingConfig?.serviceTier.orEmpty()
            } else {
                existingConfig?.serviceTier.orEmpty()
            },
            compatibilityMode = restored.getOrNull(compatibilityIndex) as? Boolean
                ?: existingConfig?.compatibilityMode
                ?: false,
        )
    },
)

fun parseManualModelIds(value: String): List<String> =
    normalizeModelIds(value.split('\n', ',', ';').map(String::trim))

private fun normalizeModelIds(values: List<String>): List<String> =
    values
        .map(String::trim)
        .filter(String::isNotEmpty)
        .distinct()
        .sortedByPreferredModelName()

@Composable
private fun ProviderFormCard(
    cardColor: Color,
    content: @Composable () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(cardColor, RoundedCornerShape(8.dp)),
    ) {
        content()
    }
}

@Composable
private fun ProviderFormDivider() {
    Spacer(modifier = Modifier.height(8.dp))
}

@Composable
private fun ProviderCompatibilityModeField(
    enabled: Boolean,
    onEnabledChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onEnabledChange(!enabled) }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = stringResource(Res.string.provider_form_compatibility_mode),
                style = MaterialTheme.typography.bodyLarge,
                color = ArixOnSurface,
            )
            Text(
                text = stringResource(Res.string.provider_form_compatibility_mode_description),
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
            )
        }
        Switch(
            checked = enabled,
            onCheckedChange = onEnabledChange,
        )
    }
}

@Composable
private fun ProviderBaseUrlField(
    state: ProviderFormState,
    definition: PiProviderDefinition,
    resetToDefaultWhenBlank: Boolean = false,
) {
    ProviderFormTextField(
        label = stringResource(Res.string.provider_form_base_url),
        value = state.baseUrl,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
        onValueChange = { value ->
            state.baseUrl = if (resetToDefaultWhenBlank) {
                value.ifBlank { definition.defaultBaseUrl }
            } else {
                value
            }
        },
    )
}

@Composable
private fun ProviderFormTextField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    isSecret: Boolean = false,
    showLabel: Boolean = true,
) {
    var fieldValue by rememberSaveable(label, stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(value, selection = TextRange(value.length)))
    }
    var passwordVisible by rememberSaveable(label) { mutableStateOf(false) }

    LaunchedEffect(value) {
        if (value != fieldValue.text) {
            fieldValue = TextFieldValue(value, selection = TextRange(value.length))
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 14.dp),
    ) {
        if (showLabel) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
            )
            Spacer(modifier = Modifier.height(6.dp))
        }
        BasicTextField(
            value = fieldValue,
            onValueChange = {
                fieldValue = it
                onValueChange(it.text)
            },
            modifier = Modifier.fillMaxWidth(),
            textStyle = MaterialTheme.typography.bodyLarge.copy(color = ArixOnSurface),
            cursorBrush = SolidColor(ProviderFormPrimary),
            keyboardOptions = keyboardOptions,
            visualTransformation = if (isSecret && !passwordVisible) {
                PasswordVisualTransformation()
            } else {
                VisualTransformation.None
            },
            decorationBox = { innerTextField ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.weight(1f)) {
                        if (fieldValue.text.isEmpty()) {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.bodyLarge,
                                color = ArixOnSurfaceVariant.copy(alpha = 0.5f),
                            )
                        }
                        innerTextField()
                    }
                    if (isSecret) {
                        IconButton(
                            onClick = { passwordVisible = !passwordVisible },
                            modifier = Modifier.size(40.dp),
                        ) {
                            Icon(
                                imageVector = if (passwordVisible) {
                                    Icons.Rounded.VisibilityOff
                                } else {
                                    Icons.Rounded.Visibility
                                },
                                contentDescription = stringResource(
                                    if (passwordVisible) {
                                        Res.string.common_hide_password
                                    } else {
                                        Res.string.common_show_password
                                    }
                                ),
                                tint = ArixOnSurfaceVariant,
                                modifier = Modifier.size(20.dp),
                            )
                        }
                    }
                }
            },
        )
    }
}

@Composable
private fun ProviderFormDropdownField(
    label: String,
    selectedValue: String,
    options: List<PiProviderDefinition>,
    onSelected: (PiProviderDefinition) -> Unit,
) {
    var expanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = true }
            .padding(horizontal = 16.dp, vertical = 14.dp),
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
        )
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = selectedValue,
                style = MaterialTheme.typography.bodyLarge,
                color = ArixOnSurface,
            )
            Icon(
                imageVector = Icons.Rounded.ArrowDropDown,
                contentDescription = stringResource(Res.string.provider_form_choose_provider),
                tint = ArixOnSurfaceVariant,
            )
        }
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            containerColor = ArixSurface,
        ) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = {
                        Column {
                            Text(option.displayName, color = ArixOnSurface)
                            Text(
                                option.category,
                                style = MaterialTheme.typography.bodySmall,
                                color = ArixOnSurfaceVariant,
                            )
                        }
                    },
                    trailingIcon = if (option.displayName == selectedValue) {
                        { Icon(Icons.Rounded.Check, contentDescription = null, tint = ArixPrimary) }
                    } else {
                        null
                    },
                    onClick = {
                        expanded = false
                        onSelected(option)
                    },
                )
            }
        }
    }
}

@Composable
private fun ProviderAuthMethodField(
    definition: PiProviderDefinition,
    selectedMethod: ProviderAuthMethod,
    onSelected: (ProviderAuthMethod) -> Unit,
) {
    val methods = buildList {
        if (definition.supportsInteractiveApiKey) add(ProviderAuthMethod.ApiKey)
        if (definition.supportsOAuth) add(ProviderAuthMethod.OAuth)
    }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(
            text = stringResource(Res.string.provider_form_authentication),
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            methods.forEach { method ->
                val label = when (method) {
                    ProviderAuthMethod.ApiKey -> stringResource(Res.string.provider_form_auth_api_key)
                    ProviderAuthMethod.OAuth -> stringResource(Res.string.provider_form_auth_oauth)
                    ProviderAuthMethod.Browser -> stringResource(Res.string.provider_form_auth_api_key)
                    ProviderAuthMethod.Ambient -> stringResource(Res.string.provider_form_auth_ambient)
                }
                ProviderModelListActionButton(
                    label = label,
                    onClick = { onSelected(method) },
                    enabled = method != selectedMethod,
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }
}
@Composable
private fun ProviderActionRow(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    enabled: Boolean,
    trailingIcon: ImageVector? = Icons.Rounded.ArrowForward,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(ArixSurface)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (enabled) ProviderFormPrimary else ArixOnSurfaceVariant.copy(alpha = 0.45f),
            modifier = Modifier.size(22.dp),
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.Medium,
            color = if (enabled) ArixOnSurface else ArixOnSurfaceVariant.copy(alpha = 0.45f),
            modifier = Modifier.weight(1f),
        )
        trailingIcon?.let { iconVector ->
            Icon(
                imageVector = iconVector,
                contentDescription = null,
                tint = if (enabled) ArixOnSurfaceVariant else ArixOnSurfaceVariant.copy(alpha = 0.35f),
                modifier = Modifier.size(20.dp),
            )
        }
    }
}

@Composable
private fun ProviderModelListField(
    models: List<String>,
    enabledModelIds: List<String>,
    isFetchingModels: Boolean,
    onToggleModel: (String, Boolean) -> Unit,
    onSetAllModelsEnabled: (Boolean) -> Unit,
    onFetchModels: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 14.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(Res.string.provider_form_model_list),
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (models.isEmpty()) {
                        stringResource(Res.string.provider_form_no_models_loaded)
                    } else {
                        stringResource(Res.string.provider_form_models_enabled_count, enabledModelIds.size, models.size)
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = ArixOnSurface,
                )
            }
            if (isFetchingModels) {
                CircularProgressIndicator(
                    modifier = Modifier.size(24.dp),
                    strokeWidth = 2.dp,
                    color = ProviderFormPrimary,
                )
            } else {
                IconButton(onClick = onFetchModels) {
                    Icon(
                        imageVector = Icons.Rounded.Refresh,
                        contentDescription = stringResource(Res.string.provider_form_fetch_models),
                        tint = ProviderFormPrimary,
                    )
                }
            }
        }

        if (models.isNotEmpty()) {
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                ProviderModelListActionButton(
                    label = stringResource(Res.string.provider_form_select_all_models),
                    onClick = { onSetAllModelsEnabled(true) },
                    enabled = enabledModelIds.size < models.size,
                    modifier = Modifier.weight(1f),
                )
                ProviderModelListActionButton(
                    label = stringResource(Res.string.provider_form_clear_all_models),
                    onClick = { onSetAllModelsEnabled(false) },
                    enabled = enabledModelIds.isNotEmpty(),
                    modifier = Modifier.weight(1f),
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            LazyColumn(
                modifier = Modifier.fillMaxWidth().heightIn(max = 480.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                items(models, key = { model -> model }) { model ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onToggleModel(model, !enabledModelIds.contains(model)) }
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(
                            checked = enabledModelIds.contains(model),
                            onCheckedChange = { checked -> onToggleModel(model, checked) },
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = model,
                            style = MaterialTheme.typography.bodyMedium,
                            color = ArixOnSurface,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ProviderModelListActionButton(
    label: String,
    onClick: () -> Unit,
    enabled: Boolean,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(
                if (enabled) {
                    ProviderFormPrimary.copy(alpha = 0.10f)
                } else {
                    ArixSurfaceHigh.copy(alpha = 0.55f)
                }
            )
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            color = if (enabled) ProviderFormPrimary else ArixOnSurfaceVariant.copy(alpha = 0.55f),
        )
    }
}

@Composable
private fun ProviderCustomHeadersField(
    headers: List<LlmCustomHeader>,
    onAddHeader: () -> Unit,
    onUpdateHeader: (Int, String, String) -> Unit,
    onRemoveHeader: (Int) -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 14.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(Res.string.provider_form_custom_request_headers),
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (headers.isEmpty()) stringResource(Res.string.common_optional) else stringResource(Res.string.provider_form_headers_configured_count, headers.size),
                    style = MaterialTheme.typography.bodyMedium,
                    color = ArixOnSurface,
                )
            }
            IconButton(onClick = onAddHeader) {
                Icon(
                    imageVector = Icons.Rounded.Add,
                    contentDescription = stringResource(Res.string.provider_form_add_header),
                    tint = ProviderFormPrimary,
                )
            }
        }

        if (headers.isNotEmpty()) {
            Spacer(modifier = Modifier.height(10.dp))
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                headers.forEachIndexed { index, header ->
                    ProviderCustomHeaderRow(
                        header = header,
                        onNameChange = { name -> onUpdateHeader(index, name, header.value) },
                        onValueChange = { value -> onUpdateHeader(index, header.name, value) },
                        onRemove = { onRemoveHeader(index) },
                    )
                }
            }
        }
    }
}

@Composable
private fun ProviderAdditionalApiKeysFields(
    state: ProviderFormState,
    onManageKeys: () -> Unit = {},
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(0.dp),
    ) {
        ProviderFormDivider()
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { state.updateMultiKeyEnabled(!state.multiKeyEnabled) }
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(Res.string.provider_multi_key_title),
                    style = MaterialTheme.typography.bodyLarge,
                    color = ArixOnSurface,
                )
                Text(
                    text = stringResource(Res.string.provider_multi_key_subtitle),
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                )
            }
            Switch(
                checked = state.multiKeyEnabled,
                onCheckedChange = state::updateMultiKeyEnabled,
            )
        }
        if (state.multiKeyEnabled) {
            ProviderFormDivider()
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onManageKeys)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Icon(
                    imageVector = Icons.Rounded.Key,
                    contentDescription = null,
                    tint = ArixOnSurfaceVariant,
                    modifier = Modifier.size(22.dp),
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = stringResource(Res.string.provider_multi_key_manage),
                        style = MaterialTheme.typography.bodyLarge,
                        color = ArixOnSurface,
                    )
                    Text(
                        text = stringResource(
                            Res.string.provider_multi_key_summary,
                            state.poolKeyCount(),
                            keyRotationStrategyLabel(state.keyRotationStrategy),
                        ),
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                    )
                }
                Icon(
                    imageVector = Icons.Rounded.ArrowForward,
                    contentDescription = null,
                    tint = ArixOnSurfaceVariant,
                    modifier = Modifier.size(16.dp),
                )
            }
        }
    }
}

private fun maskedKeyPreview(value: String): String {
    val trimmed = value.trim()
    if (trimmed.isEmpty()) return ""
    if (trimmed.length <= 8) return "********"
    return trimmed.take(2) + "*****" + trimmed.takeLast(4)
}

@Composable
private fun keyRotationStrategyLabel(strategy: String): String = when (strategy) {
    com.arix.app.data.KeyRotationStrategyRoundRobin ->
        stringResource(Res.string.provider_multi_key_strategy_round_robin)
    else -> stringResource(Res.string.provider_multi_key_strategy_sequential)
}

@Composable
fun ProviderManageKeysPage(
    state: ProviderFormState,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ArixSettingsBackground),
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .navigationBarsPadding(),
        ) {
            Spacer(Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = stringResource(Res.string.provider_multi_key_manage),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = ArixOnSurface,
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = state::addAdditionalApiKey) {
                    Icon(
                        imageVector = Icons.Rounded.Add,
                        contentDescription = stringResource(Res.string.provider_multi_key_add),
                        tint = ArixOnSurface,
                    )
                }
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = stringResource(Res.string.common_back),
                        tint = ArixOnSurface,
                    )
                }
            }
            Spacer(Modifier.height(8.dp))

            Text(
                text = stringResource(Res.string.provider_multi_key_list),
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.SemiBold,
                color = ArixOnSurfaceVariant,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 8.dp),
            )
            ProviderFormCard(cardColor = ArixSurface) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(Res.string.provider_multi_key_item, 1),
                            style = MaterialTheme.typography.bodyLarge,
                            color = ArixOnSurface,
                        )
                        Text(
                            text = maskedKeyPreview(state.apiKey)
                                .ifEmpty { stringResource(Res.string.provider_multi_key_primary_empty) },
                            style = MaterialTheme.typography.bodySmall,
                            color = ArixOnSurfaceVariant,
                        )
                    }
                    Text(
                        text = stringResource(Res.string.provider_multi_key_primary_badge),
                        style = MaterialTheme.typography.labelSmall,
                        color = ArixOnSurfaceVariant,
                    )
                }
                state.additionalApiKeys.forEachIndexed { index, key ->
                    ProviderFormDivider()
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        ProviderFormTextField(
                            label = stringResource(Res.string.provider_multi_key_item, index + 2),
                            value = key,
                            onValueChange = { value -> state.updateAdditionalApiKey(index, value) },
                            isSecret = true,
                            modifier = Modifier.weight(1f),
                        )
                        IconButton(onClick = { state.removeAdditionalApiKey(index) }) {
                            Icon(
                                imageVector = Icons.Rounded.Close,
                                contentDescription = stringResource(
                                    Res.string.provider_multi_key_remove,
                                    index + 2,
                                ),
                                tint = ArixError,
                            )
                        }
                    }
                }
                if (state.additionalApiKeys.isEmpty()) {
                    ProviderFormDivider()
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(onClick = state::addAdditionalApiKey)
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Add,
                            contentDescription = null,
                            tint = ArixOnSurfaceVariant,
                            modifier = Modifier.size(18.dp),
                        )
                        Text(
                            text = stringResource(Res.string.provider_multi_key_empty),
                            style = MaterialTheme.typography.bodyMedium,
                            color = ArixOnSurfaceVariant,
                        )
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                text = stringResource(Res.string.provider_multi_key_list_hint),
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
                modifier = Modifier.padding(horizontal = 4.dp),
            )

            Text(
                text = stringResource(Res.string.provider_multi_key_strategy),
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.SemiBold,
                color = ArixOnSurfaceVariant,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 8.dp),
            )
            ProviderFormCard(cardColor = ArixSurface) {
                ProviderStrategyChoiceRow(
                    title = stringResource(Res.string.provider_multi_key_strategy_sequential),
                    description = stringResource(Res.string.provider_multi_key_strategy_sequential_desc),
                    selected = state.keyRotationStrategy == com.arix.app.data.KeyRotationStrategySequential,
                    onClick = {
                        state.updateKeyRotationStrategy(com.arix.app.data.KeyRotationStrategySequential)
                    },
                )
                ProviderFormDivider()
                ProviderStrategyChoiceRow(
                    title = stringResource(Res.string.provider_multi_key_strategy_round_robin),
                    description = stringResource(Res.string.provider_multi_key_strategy_round_robin_desc),
                    selected = state.keyRotationStrategy == com.arix.app.data.KeyRotationStrategyRoundRobin,
                    onClick = {
                        state.updateKeyRotationStrategy(com.arix.app.data.KeyRotationStrategyRoundRobin)
                    },
                )
            }

            Text(
                text = stringResource(Res.string.provider_multi_key_failover),
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.SemiBold,
                color = ArixOnSurfaceVariant,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 8.dp),
            )
            ProviderFormCard(cardColor = ArixSurface) {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                    Text(
                        text = stringResource(Res.string.provider_multi_key_status_codes),
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = stringResource(Res.string.provider_multi_key_status_codes_hint),
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant.copy(alpha = 0.8f),
                    )
                    Spacer(Modifier.height(8.dp))
                    ProviderFormTextField(
                        label = stringResource(Res.string.provider_multi_key_status_codes),
                        value = state.keySwitchStatusCodesCsv,
                        onValueChange = state::updateKeySwitchStatusCodesCsv,
                        showLabel = false,
                    )
                }
                ProviderFormDivider()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(Res.string.provider_multi_key_cooldown),
                            style = MaterialTheme.typography.bodyLarge,
                            color = ArixOnSurface,
                        )
                        Text(
                            text = stringResource(Res.string.provider_multi_key_cooldown_desc),
                            style = MaterialTheme.typography.bodySmall,
                            color = ArixOnSurfaceVariant,
                        )
                    }
                    Text(
                        text = if (state.keyCooldownMinutes == 0) {
                            stringResource(Res.string.provider_multi_key_cooldown_off)
                        } else {
                            stringResource(
                                Res.string.provider_multi_key_cooldown_value,
                                state.keyCooldownMinutes,
                            )
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = ArixOnSurface,
                        modifier = Modifier.width(72.dp),
                        textAlign = TextAlign.Center,
                    )
                    IconButton(
                        onClick = { state.updateKeyCooldownMinutes(state.keyCooldownMinutes - 1) },
                        enabled = state.keyCooldownMinutes > 0,
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Remove,
                            contentDescription = null,
                            tint = if (state.keyCooldownMinutes > 0) ArixOnSurface else ArixOnSurfaceVariant.copy(alpha = 0.4f),
                        )
                    }
                    IconButton(
                        onClick = { state.updateKeyCooldownMinutes(state.keyCooldownMinutes + 1) },
                        enabled = state.keyCooldownMinutes < 120,
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Add,
                            contentDescription = null,
                            tint = if (state.keyCooldownMinutes < 120) ArixOnSurface else ArixOnSurfaceVariant.copy(alpha = 0.4f),
                        )
                    }
                }
            }
            Spacer(Modifier.height(32.dp))
        }
    }
}

@Composable
private fun ProviderStrategyChoiceRow(
    title: String,
    description: String,
    selected: Boolean,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                color = ArixOnSurface,
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
            )
        }
        if (selected) {
            Icon(
                imageVector = Icons.Rounded.Check,
                contentDescription = null,
                tint = ProviderFormPrimary,
            )
        }
    }
}

@Composable
private fun ProviderCustomHeaderRow(
    header: LlmCustomHeader,
    onNameChange: (String) -> Unit,
    onValueChange: (String) -> Unit,
    onRemove: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        ProviderFormTextField(
            label = stringResource(Res.string.provider_form_header_name),
            value = header.name,
            onValueChange = onNameChange,
            modifier = Modifier.weight(0.42f),
        )
        ProviderFormTextField(
            label = stringResource(Res.string.provider_form_header_value),
            value = header.value,
            onValueChange = onValueChange,
            modifier = Modifier.weight(0.58f),
        )
        IconButton(onClick = onRemove) {
            Icon(
                imageVector = Icons.Rounded.Delete,
                contentDescription = stringResource(Res.string.provider_form_remove_header),
                tint = ArixOnSurfaceVariant,
            )
        }
    }
}

private val SharedProviderTourTextPrimary: Color
    get() = ArixOnSurface
private val SharedProviderTourTextSecondary: Color
    get() = ArixOnSurfaceVariant
private val SharedProviderTourTextTertiary: Color
    get() = ArixOnSurfaceVariant.copy(alpha = 0.72f)
private val SharedProviderTourSurface: Color
    get() = ArixSurface

@Composable
internal fun SharedProviderPickerContent(
    providerSearch: String,
    onProviderSearchChange: (String) -> Unit,
    providerChoices: List<PiProviderDefinition>,
    onProviderSelected: (PiProviderDefinition) -> Unit,
    footnote: String? = null,
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        SharedProviderMinimalInputField(
            label = stringResource(Res.string.common_search),
            value = providerSearch,
            placeholder = stringResource(Res.string.onboarding_provider_search_placeholder),
            onValueChange = onProviderSearchChange,
        )
        providerChoices.forEach { provider ->
            SharedProviderStageButton(
                label = provider.displayName,
                subtitle = "${provider.category} · ${provider.id}",
                provider = provider,
                onClick = { onProviderSelected(provider) },
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        if (footnote != null) {
            Text(
                text = footnote,
                style = MaterialTheme.typography.bodySmall,
                color = SharedProviderTourTextSecondary,
            )
            Spacer(modifier = Modifier.height(6.dp))
        }
        Text(
            text = stringResource(Res.string.onboarding_change_later_settings),
            style = MaterialTheme.typography.bodySmall,
            color = SharedProviderTourTextSecondary,
        )
    }
}

@Composable
private fun SharedProviderStageButton(
    label: String,
    subtitle: String,
    provider: PiProviderDefinition,
    onClick: () -> Unit,
) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(86.dp),
        shape = RoundedCornerShape(26.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = SharedProviderTourSurface,
            contentColor = SharedProviderTourTextPrimary,
        ),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            ProviderBrandIconBadge(provider = provider)
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp),
                horizontalAlignment = Alignment.Start,
            ) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.titleMedium,
                    color = SharedProviderTourTextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = SharedProviderTourTextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
private fun SharedProviderMinimalInputField(
    label: String,
    value: String,
    placeholder: String,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    onValueChange: (String) -> Unit,
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            color = SharedProviderTourTextSecondary,
        )
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(SharedProviderTourSurface)
                .padding(horizontal = 14.dp, vertical = 12.dp)
                .sharedProviderBringIntoViewOnFocus(),
            textStyle = MaterialTheme.typography.bodyLarge.copy(color = SharedProviderTourTextPrimary),
            cursorBrush = SolidColor(SharedProviderTourTextPrimary),
            singleLine = true,
            keyboardOptions = keyboardOptions,
            decorationBox = { innerTextField ->
                Box(modifier = Modifier.fillMaxWidth()) {
                    if (value.isBlank()) {
                        Text(
                            text = placeholder,
                            style = MaterialTheme.typography.bodyLarge,
                            color = SharedProviderTourTextTertiary,
                        )
                    }
                    innerTextField()
                }
            },
        )
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
private fun Modifier.sharedProviderBringIntoViewOnFocus(): Modifier = composed {
    val requester = remember { BringIntoViewRequester() }
    val scope = rememberCoroutineScope()

    bringIntoViewRequester(requester)
        .onFocusChanged { focusState ->
            if (focusState.isFocused) {
                scope.launch {
                    delay(250)
                    requester.bringIntoView()
                }
            }
        }
}

internal fun prioritizedSharedProviderModelOptions(
    piProviderId: String?,
    cachedModels: List<String>,
): List<String> {
    return cachedModels
        .map(String::trim)
        .filter(String::isNotBlank)
        .distinctBy { it.lowercase() }
        .sortedByPreferredModelName()
}
