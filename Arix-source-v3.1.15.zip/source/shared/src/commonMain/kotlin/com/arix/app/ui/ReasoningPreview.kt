package com.arix.app.ui

fun pendingReasoningPreview(rawText: String): String {
    val words = Regex("\\S+").findAll(rawText).take(100).toList()
    return words.lastOrNull()?.let { rawText.substring(0, it.range.last + 1).trimStart() }.orEmpty()
}
