package com.arix.app.runtime

interface RuntimeFileSystem {
    suspend fun exists(path: String): Boolean
    suspend fun createDirectories(path: String)
    suspend fun read(path: String): ByteArray
    suspend fun read(path: String, maximumBytes: Long): ByteArray {
        require(maximumBytes >= 0) { "maximumBytes must not be negative." }
        return read(path).also { bytes ->
            require(bytes.size.toLong() <= maximumBytes) { "File exceeds the allowed size." }
        }
    }
    suspend fun readPrefix(path: String, maximumBytes: Long): ByteArray {
        require(maximumBytes >= 0) { "maximumBytes must not be negative." }
        if (maximumBytes == 0L) return ByteArray(0)
        val bytes = read(path)
        return bytes.copyOf(minOf(bytes.size.toLong(), maximumBytes).toInt())
    }
    suspend fun write(path: String, content: ByteArray, executable: Boolean = false)
    suspend fun remove(path: String, recursive: Boolean = false)
    suspend fun bindHostDirectory(hostPath: String, guestPath: String, readOnly: Boolean = false)
}

interface MultiplatformLocalRuntime {
    val homeDirectory: String
    val workspaceRoot: String
    val fileSystem: RuntimeFileSystem

    suspend fun isReady(): Boolean = fileSystem.exists("/etc/termux-release")
    suspend fun initialize(onProgress: (RuntimeSetupProgress) -> Unit = {})
    suspend fun reset() {
        throw UnsupportedOperationException("This runtime cannot be reset.")
    }
}

data class RuntimeSetupProgress(
    val phase: String,
    val detail: String = "",
    val fraction: Float? = null,
    val output: String = "",
)
