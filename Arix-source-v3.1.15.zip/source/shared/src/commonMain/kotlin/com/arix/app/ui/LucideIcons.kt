package com.arix.app.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

object LucideIcons {
    val Search: ImageVector
        get() {
            if (_search != null) return _search!!

            _search = ImageVector.Builder(
                name = "search",
                defaultWidth = 24.dp,
                defaultHeight = 24.dp,
                viewportWidth = 24f,
                viewportHeight = 24f,
            ).apply {
                path(
                    fill = SolidColor(Color.Transparent),
                    stroke = SolidColor(Color(0xFF000000)),
                    strokeLineWidth = 2f,
                    strokeLineCap = StrokeCap.Round,
                    strokeLineJoin = StrokeJoin.Round,
                ) {
                    moveTo(21f, 21f)
                    lineToRelative(-4.34f, -4.34f)
                }
                path(
                    fill = SolidColor(Color.Transparent),
                    stroke = SolidColor(Color(0xFF000000)),
                    strokeLineWidth = 2f,
                    strokeLineCap = StrokeCap.Round,
                    strokeLineJoin = StrokeJoin.Round,
                ) {
                    moveTo(19f, 11f)
                    arcTo(8f, 8f, 0f, false, true, 11f, 19f)
                    arcTo(8f, 8f, 0f, false, true, 3f, 11f)
                    arcTo(8f, 8f, 0f, false, true, 19f, 11f)
                    close()
                }
            }.build()

            return _search!!
        }

    val SquarePen: ImageVector
        get() {
            if (_squarePen != null) return _squarePen!!

            _squarePen = ImageVector.Builder(
                name = "square-pen",
                defaultWidth = 24.dp,
                defaultHeight = 24.dp,
                viewportWidth = 24f,
                viewportHeight = 24f,
            ).apply {
                path(
                    fill = SolidColor(Color.Transparent),
                    stroke = SolidColor(Color(0xFF000000)),
                    strokeLineWidth = 2f,
                    strokeLineCap = StrokeCap.Round,
                    strokeLineJoin = StrokeJoin.Round,
                ) {
                    moveTo(12f, 3f)
                    horizontalLineTo(5f)
                    arcToRelative(2f, 2f, 0f, false, false, -2f, 2f)
                    verticalLineToRelative(14f)
                    arcToRelative(2f, 2f, 0f, false, false, 2f, 2f)
                    horizontalLineToRelative(14f)
                    arcToRelative(2f, 2f, 0f, false, false, 2f, -2f)
                    verticalLineToRelative(-7f)
                }
                path(
                    fill = SolidColor(Color.Transparent),
                    stroke = SolidColor(Color(0xFF000000)),
                    strokeLineWidth = 2f,
                    strokeLineCap = StrokeCap.Round,
                    strokeLineJoin = StrokeJoin.Round,
                ) {
                    moveTo(18.375f, 2.625f)
                    arcToRelative(1f, 1f, 0f, false, true, 3f, 3f)
                    lineToRelative(-9.013f, 9.014f)
                    arcToRelative(2f, 2f, 0f, false, true, -0.853f, 0.505f)
                    lineToRelative(-2.873f, 0.84f)
                    arcToRelative(0.5f, 0.5f, 0f, false, true, -0.62f, -0.62f)
                    lineToRelative(0.84f, -2.873f)
                    arcToRelative(2f, 2f, 0f, false, true, 0.506f, -0.852f)
                    close()
                }
            }.build()

            return _squarePen!!
        }

    val Copy: ImageVector
        get() {
            if (_copy != null) return _copy!!

            _copy = ImageVector.Builder(
                name = "copy",
                defaultWidth = 24.dp,
                defaultHeight = 24.dp,
                viewportWidth = 24f,
                viewportHeight = 24f,
            ).apply {
                path(
                    fill = SolidColor(Color.Transparent),
                    stroke = SolidColor(Color(0xFF000000)),
                    strokeLineWidth = 2f,
                    strokeLineCap = StrokeCap.Round,
                    strokeLineJoin = StrokeJoin.Round,
                ) {
                    moveTo(9f, 9f)
                    horizontalLineToRelative(11f)
                    arcToRelative(2f, 2f, 0f, false, true, 2f, 2f)
                    verticalLineToRelative(9f)
                    arcToRelative(2f, 2f, 0f, false, true, -2f, 2f)
                    horizontalLineTo(9f)
                    arcToRelative(2f, 2f, 0f, false, true, -2f, -2f)
                    verticalLineToRelative(-9f)
                    arcToRelative(2f, 2f, 0f, false, true, 2f, -2f)
                    close()
                }
                path(
                    fill = SolidColor(Color.Transparent),
                    stroke = SolidColor(Color(0xFF000000)),
                    strokeLineWidth = 2f,
                    strokeLineCap = StrokeCap.Round,
                    strokeLineJoin = StrokeJoin.Round,
                ) {
                    moveTo(5f, 15f)
                    horizontalLineTo(4f)
                    arcToRelative(2f, 2f, 0f, false, true, -2f, -2f)
                    verticalLineTo(4f)
                    arcToRelative(2f, 2f, 0f, false, true, 2f, -2f)
                    horizontalLineToRelative(9f)
                    arcToRelative(2f, 2f, 0f, false, true, 2f, 2f)
                    verticalLineToRelative(1f)
                }
            }.build()

            return _copy!!
        }

    val RotateCcw: ImageVector
        get() {
            if (_rotateCcw != null) return _rotateCcw!!

            _rotateCcw = ImageVector.Builder(
                name = "rotate-ccw",
                defaultWidth = 24.dp,
                defaultHeight = 24.dp,
                viewportWidth = 24f,
                viewportHeight = 24f,
            ).apply {
                path(
                    fill = SolidColor(Color.Transparent),
                    stroke = SolidColor(Color(0xFF000000)),
                    strokeLineWidth = 2f,
                    strokeLineCap = StrokeCap.Round,
                    strokeLineJoin = StrokeJoin.Round,
                ) {
                    moveTo(3f, 12f)
                    arcToRelative(9f, 9f, 0f, true, false, 9f, -9f)
                    arcToRelative(9.75f, 9.75f, 0f, false, false, -6.74f, 2.74f)
                    lineTo(3f, 8f)
                }
                path(
                    fill = SolidColor(Color.Transparent),
                    stroke = SolidColor(Color(0xFF000000)),
                    strokeLineWidth = 2f,
                    strokeLineCap = StrokeCap.Round,
                    strokeLineJoin = StrokeJoin.Round,
                ) {
                    moveTo(3f, 3f)
                    verticalLineToRelative(5f)
                    horizontalLineToRelative(5f)
                }
            }.build()

            return _rotateCcw!!
        }

    val Trash2: ImageVector
        get() {
            if (_trash2 != null) return _trash2!!

            _trash2 = ImageVector.Builder(
                name = "trash-2",
                defaultWidth = 24.dp,
                defaultHeight = 24.dp,
                viewportWidth = 24f,
                viewportHeight = 24f,
            ).apply {
                path(
                    fill = SolidColor(Color.Transparent),
                    stroke = SolidColor(Color(0xFF000000)),
                    strokeLineWidth = 2f,
                    strokeLineCap = StrokeCap.Round,
                    strokeLineJoin = StrokeJoin.Round,
                ) {
                    moveTo(3f, 6f)
                    horizontalLineToRelative(18f)
                }
                path(
                    fill = SolidColor(Color.Transparent),
                    stroke = SolidColor(Color(0xFF000000)),
                    strokeLineWidth = 2f,
                    strokeLineCap = StrokeCap.Round,
                    strokeLineJoin = StrokeJoin.Round,
                ) {
                    moveTo(8f, 6f)
                    verticalLineTo(4f)
                    arcToRelative(2f, 2f, 0f, false, true, 2f, -2f)
                    horizontalLineToRelative(4f)
                    arcToRelative(2f, 2f, 0f, false, true, 2f, 2f)
                    verticalLineToRelative(2f)
                }
                path(
                    fill = SolidColor(Color.Transparent),
                    stroke = SolidColor(Color(0xFF000000)),
                    strokeLineWidth = 2f,
                    strokeLineCap = StrokeCap.Round,
                    strokeLineJoin = StrokeJoin.Round,
                ) {
                    moveTo(19f, 6f)
                    lineToRelative(-1f, 14f)
                    arcToRelative(2f, 2f, 0f, false, true, -2f, 2f)
                    horizontalLineTo(8f)
                    arcToRelative(2f, 2f, 0f, false, true, -2f, -2f)
                    lineTo(5f, 6f)
                }
                path(
                    fill = SolidColor(Color.Transparent),
                    stroke = SolidColor(Color(0xFF000000)),
                    strokeLineWidth = 2f,
                    strokeLineCap = StrokeCap.Round,
                    strokeLineJoin = StrokeJoin.Round,
                ) {
                    moveTo(10f, 11f)
                    verticalLineToRelative(6f)
                }
                path(
                    fill = SolidColor(Color.Transparent),
                    stroke = SolidColor(Color(0xFF000000)),
                    strokeLineWidth = 2f,
                    strokeLineCap = StrokeCap.Round,
                    strokeLineJoin = StrokeJoin.Round,
                ) {
                    moveTo(14f, 11f)
                    verticalLineToRelative(6f)
                }
            }.build()

            return _trash2!!
        }

    val ChartNoAxesColumn: ImageVector
        get() {
            if (_chartNoAxesColumn != null) return _chartNoAxesColumn!!

            _chartNoAxesColumn = ImageVector.Builder(
                name = "chart-no-axes-column",
                defaultWidth = 24.dp,
                defaultHeight = 24.dp,
                viewportWidth = 24f,
                viewportHeight = 24f,
            ).apply {
                path(
                    fill = SolidColor(Color.Transparent),
                    stroke = SolidColor(Color(0xFF000000)),
                    strokeLineWidth = 2f,
                    strokeLineCap = StrokeCap.Round,
                    strokeLineJoin = StrokeJoin.Round,
                ) {
                    moveTo(5f, 21f)
                    verticalLineToRelative(-6f)
                }
                path(
                    fill = SolidColor(Color.Transparent),
                    stroke = SolidColor(Color(0xFF000000)),
                    strokeLineWidth = 2f,
                    strokeLineCap = StrokeCap.Round,
                    strokeLineJoin = StrokeJoin.Round,
                ) {
                    moveTo(12f, 21f)
                    verticalLineTo(9f)
                }
                path(
                    fill = SolidColor(Color.Transparent),
                    stroke = SolidColor(Color(0xFF000000)),
                    strokeLineWidth = 2f,
                    strokeLineCap = StrokeCap.Round,
                    strokeLineJoin = StrokeJoin.Round,
                ) {
                    moveTo(19f, 21f)
                    verticalLineTo(3f)
                }
            }.build()

            return _chartNoAxesColumn!!
        }

    val Zap: ImageVector
        get() {
            if (_zap != null) return _zap!!

            _zap = ImageVector.Builder(
                name = "zap",
                defaultWidth = 24.dp,
                defaultHeight = 24.dp,
                viewportWidth = 24f,
                viewportHeight = 24f,
            ).apply {
                path(
                    fill = SolidColor(Color.Transparent),
                    stroke = SolidColor(Color(0xFF000000)),
                    strokeLineWidth = 2f,
                    strokeLineCap = StrokeCap.Round,
                    strokeLineJoin = StrokeJoin.Round,
                ) {
                    moveTo(4f, 14f)
                    arcToRelative(1f, 1f, 0f, false, true, -0.78f, -1.63f)
                    lineToRelative(9.9f, -10.2f)
                    arcToRelative(0.5f, 0.5f, 0f, false, true, 0.86f, 0.46f)
                    lineToRelative(-1.92f, 6.02f)
                    arcTo(1f, 1f, 0f, false, false, 13f, 10f)
                    horizontalLineToRelative(7f)
                    arcToRelative(1f, 1f, 0f, false, true, 0.78f, 1.63f)
                    lineToRelative(-9.9f, 10.2f)
                    arcToRelative(0.5f, 0.5f, 0f, false, true, -0.86f, -0.46f)
                    lineToRelative(1.92f, -6.02f)
                    arcTo(1f, 1f, 0f, false, false, 11f, 14f)
                    close()
                }
            }.build()

            return _zap!!
        }

    val Brain: ImageVector
        get() {
            if (_brain != null) return _brain!!

            _brain = ImageVector.Builder(
                name = "brain",
                defaultWidth = 24.dp,
                defaultHeight = 24.dp,
                viewportWidth = 24f,
                viewportHeight = 24f,
            ).apply {
                path(
                    fill = SolidColor(Color.Transparent),
                    stroke = SolidColor(Color(0xFF000000)),
                    strokeLineWidth = 2f,
                    strokeLineCap = StrokeCap.Round,
                    strokeLineJoin = StrokeJoin.Round,
                ) {
                    moveTo(12f, 5f)
                    arcToRelative(3f, 3f, 0f, true, false, -5.997f, 0.125f)
                    arcToRelative(4f, 4f, 0f, false, false, -2.526f, 5.77f)
                    arcToRelative(4f, 4f, 0f, false, false, 0.556f, 6.588f)
                    arcTo(4f, 4f, 0f, true, false, 12f, 18f)
                    close()
                }
                path(
                    fill = SolidColor(Color.Transparent),
                    stroke = SolidColor(Color(0xFF000000)),
                    strokeLineWidth = 2f,
                    strokeLineCap = StrokeCap.Round,
                    strokeLineJoin = StrokeJoin.Round,
                ) {
                    moveTo(12f, 5f)
                    arcToRelative(3f, 3f, 0f, true, true, 5.997f, 0.125f)
                    arcToRelative(4f, 4f, 0f, false, true, 2.526f, 5.77f)
                    arcToRelative(4f, 4f, 0f, false, true, -0.556f, 6.588f)
                    arcTo(4f, 4f, 0f, true, true, 12f, 18f)
                    close()
                }
                path(
                    fill = SolidColor(Color.Transparent),
                    stroke = SolidColor(Color(0xFF000000)),
                    strokeLineWidth = 2f,
                    strokeLineCap = StrokeCap.Round,
                    strokeLineJoin = StrokeJoin.Round,
                ) {
                    moveTo(15f, 13f)
                    arcToRelative(4.5f, 4.5f, 0f, false, false, -3f, -4f)
                    arcToRelative(4.5f, 4.5f, 0f, false, false, -3f, 4f)
                }
            }.build()

            return _brain!!
        }

    private var _search: ImageVector? = null
    private var _squarePen: ImageVector? = null
    private var _copy: ImageVector? = null
    private var _rotateCcw: ImageVector? = null
    private var _trash2: ImageVector? = null
    private var _chartNoAxesColumn: ImageVector? = null
    private var _zap: ImageVector? = null
    private var _brain: ImageVector? = null
}
