package com.arix.app.data

import kotlinx.serialization.Serializable

@Serializable
enum class ProviderAuthMethod(
    val storageValue: String,
) {
    ApiKey("api_key"),
    OAuth("oauth"),

    @Deprecated("Browser-auth (Gemini Web) was removed in v3.0.61.")
    Browser("browser"),

    @Deprecated("Environment-credentials auth was removed in v2.9.16.")
    Ambient("ambient");

    companion object {
        fun fromStorage(
            value: String?,
            defaultValue: ProviderAuthMethod = ApiKey,
        ): ProviderAuthMethod =
            entries.firstOrNull { it.storageValue == value } ?: defaultValue
    }
}

@Serializable
data class PiProviderEnvironmentVariable(
    val name: String,
    val value: String,
)

data class PiProviderDefinition(
    val id: String,
    val displayName: String,
    val defaultBaseUrl: String,
    val defaultModelId: String,
    val supportsApiKey: Boolean = true,
    val supportsInteractiveApiKey: Boolean = supportsApiKey,
    val supportsOAuth: Boolean = false,
    val supportsAmbientAuth: Boolean = false,
    @Deprecated("Browser auth (Gemini Web) was removed in v3.0.61.")
    val supportsBrowserAuth: Boolean = false,
    val requiresBaseUrl: Boolean = false,
    val supportsCustomBaseUrl: Boolean = false,
    val isBuiltIn: Boolean = true,
    val category: String = "Other",
    val defaultModelIds: List<String> = emptyList(),
)

const val DefaultPiProviderId = "openai-compatible"
const val DefaultCustomProviderBaseUrl = "https://api.openai.com/v1"
const val DefaultCustomModelId = "gpt-5.4"

object PiProviderCatalog {

    val providers: List<PiProviderDefinition> = listOf(
        builtin("google", "Google Gemini", "https://generativelanguage.googleapis.com/v1beta", "gemini-2.5-flash", category = "Recommended"),
        builtin("openrouter", "OpenRouter", "https://openrouter.ai/api/v1", "openai/gpt-5.4", category = "Recommended"),
        keyless(
            "kilo", "Kilo · Free (No Key)", "https://api.kilo.ai/api/gateway", "kilo-auto/free",
            defaultModelIds = listOf(
                "kilo-auto/free",
                "kilo-auto/efficient",
                "kilo-auto/balanced",
                "nvidia/nemotron-3.5-lightning:free",
                "nvidia/nemotron-3-super-120b-a12b:free",
                "poolside/laguna-s-2.1:free",
                "cohere/north-mini-code:free",
                "thinkingmachines/inkling-small:free",
                "liquid/lfm-2.5-2.6b:free",
            ),
        ),
        keyless(
            "pollinations", "Pollinations · Free (No Key)", "https://text.pollinations.ai/openai", "openai-fast",
            defaultModelIds = listOf(
                "openai-fast",
                "openai",
                "gpt-oss-20b",
            ),
        ),
        keyless(
            "llm7", "LLM7 · Free (No Key)", "https://api.llm7.io/v1", "gpt-4.1-nano-2025-04-14",
            defaultModelIds = listOf(
                "gpt-4.1-nano-2025-04-14",
            ),
        ),
        builtin("cloudflare-ai-gateway", "Cloudflare AI Gateway", "", "claude-3-5-haiku", category = "Cloud"),
        builtin("cloudflare-workers-ai", "Cloudflare Workers AI", "", "@cf/google/gemma-4-26b-a4b-it", category = "Cloud"),
        builtin("groq", "Groq", "https://api.groq.com/openai/v1", "llama-3.3-70b-versatile", category = "Model labs"),
        builtin("nvidia", "NVIDIA", "https://integrate.api.nvidia.com/v1", "meta/llama-3.3-70b-instruct", category = "Model labs"),
        builtin("huggingface", "Hugging Face", "https://router.huggingface.co/v1", "MiniMaxAI/MiniMax-M2.7", category = "Aggregators"),
        custom(DefaultPiProviderId, "OpenAI-compatible endpoint"),
    )

    val builtInProviders: List<PiProviderDefinition>
        get() = providers.filter(PiProviderDefinition::isBuiltIn)

    val recommendedProviders: List<PiProviderDefinition>
        get() = providers.filter { it.category == "Recommended" }

    fun find(id: String?): PiProviderDefinition? =
        providers.firstOrNull { it.id == id?.trim() }

    fun resolve(id: String?): PiProviderDefinition =
        find(id) ?: providers.first { it.id == DefaultPiProviderId }
}

fun PiProviderDefinition.modelsDevProviderIds(): List<String> = when (id) {
    else -> listOf(id)
}

fun inferLegacyPiProviderId(
    legacyProviderStorageValue: String?,
    baseUrl: String,
): String = when (legacyProviderStorageValue?.trim()) {
    "openai_responses" -> DefaultPiProviderId
    "anthropic_messages" -> DefaultPiProviderId
    "vertex_express" -> DefaultPiProviderId
    "openai_compatible" -> builtInProviderIdForHost(hostOf(baseUrl)) ?: DefaultPiProviderId
    else -> builtInProviderIdForHost(hostOf(baseUrl)) ?: DefaultPiProviderId
}

fun PiProviderDefinition.defaultAuthMethod(): ProviderAuthMethod = when {
    !supportsApiKey && supportsOAuth -> ProviderAuthMethod.OAuth
    else -> ProviderAuthMethod.ApiKey
}

private fun builtin(
    id: String,
    displayName: String,
    defaultBaseUrl: String,
    defaultModelId: String,
    supportsApiKey: Boolean = true,
    supportsInteractiveApiKey: Boolean = supportsApiKey,
    supportsOAuth: Boolean = false,
    supportsAmbientAuth: Boolean = false,
    requiresBaseUrl: Boolean = false,
    supportsCustomBaseUrl: Boolean = false,
    category: String,
    defaultModelIds: List<String> = emptyList(),
): PiProviderDefinition = PiProviderDefinition(
    id = id,
    displayName = displayName,
    defaultBaseUrl = defaultBaseUrl,
    defaultModelId = defaultModelId,
    supportsApiKey = supportsApiKey,
    supportsInteractiveApiKey = supportsInteractiveApiKey,
    supportsOAuth = supportsOAuth,
    supportsAmbientAuth = supportsAmbientAuth,
    requiresBaseUrl = requiresBaseUrl,
    supportsCustomBaseUrl = supportsCustomBaseUrl,
    category = category,
    defaultModelIds = defaultModelIds,
)

private fun custom(
    id: String,
    displayName: String,
): PiProviderDefinition = PiProviderDefinition(
    id = id,
    displayName = displayName,
    defaultBaseUrl = DefaultCustomProviderBaseUrl,
    defaultModelId = DefaultCustomModelId,
    supportsApiKey = true,
    requiresBaseUrl = true,
    isBuiltIn = false,
    category = "Custom",
)

private fun keyless(
    id: String,
    displayName: String,
    defaultBaseUrl: String,
    defaultModelId: String,
    defaultModelIds: List<String> = emptyList(),
): PiProviderDefinition = PiProviderDefinition(
    id = id,
    displayName = displayName,
    defaultBaseUrl = defaultBaseUrl,
    defaultModelId = defaultModelId,
    supportsApiKey = true,
    requiresBaseUrl = true,
    supportsCustomBaseUrl = true,
    isBuiltIn = false,
    category = "Recommended",
    defaultModelIds = defaultModelIds,
)

private fun hostOf(baseUrl: String): String {
    val authority = baseUrl.trim()
        .substringAfter("://", missingDelimiterValue = "")
        .substringBefore('/')
        .substringBefore('?')
        .substringBefore('#')
        .substringAfterLast('@')
    return authority.substringBefore(':').lowercase()
}

private fun builtInProviderIdForHost(host: String): String? = when (host) {
    "generativelanguage.googleapis.com" -> "google"
    "openrouter.ai" -> "openrouter"
    "api.groq.com" -> "groq"
    "integrate.api.nvidia.com" -> "nvidia"
    "router.huggingface.co" -> "huggingface"
    "api.kilo.ai" -> "kilo"
    "text.pollinations.ai" -> "pollinations"
    "api.llm7.io" -> "llm7"
    else -> null
}
