package com.arix.app.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.arix.app.platform.LocalReduceMotion
import com.arix.app.ui.theme.ArixSurface


@Composable
fun ArixConversationTopBarFrame(
    menuDescription: String,
    onMenu: () -> Unit,
    showMenu: Boolean = true,
    showCompanion: Boolean = false,
    companionSlot: @Composable () -> Unit = {},
    modifier: Modifier = Modifier,
    centerContent: @Composable BoxScope.() -> Unit,
) {
    val reduceMotion = LocalReduceMotion.current
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 15.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (showMenu) {
            HeaderCircleButton(
                icon = Icons.Rounded.Menu,
                contentDescription = menuDescription,
                onClick = onMenu,
                size = 38.dp,
                iconSize = 19.dp,
                containerColor = ArixSurface.copy(alpha = 0.96f),
            )
        }
        Box(
            modifier = Modifier
                .weight(1f)
                .padding(
                    start = if (showMenu) 12.dp else 5.dp,
                    end = 12.dp,
                ),
            content = centerContent,
        )
        if (showCompanion) {
            companionSlot()
        }
    }
}
